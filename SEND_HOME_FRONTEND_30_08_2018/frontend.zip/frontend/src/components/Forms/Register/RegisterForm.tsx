import * as React from 'react';
import {Control, Errors, /*actions*/ Form} from 'react-redux-form';
import {IRegisterFormData} from '../../../redux/forms';
import './Register.css';

import {Link} from "react-router-dom";
import {PATH_PRIVACY, PATH_ROOT, PATH_TERMS} from "../../../router/paths";
import {maxLength100, maxLength200, maxLength5, maxLength50, minLength3, minLength5, isEmail} from "../validator";

interface IProps {
    onSubmit: (values: IRegisterFormData) => void;
}

export default class RegisterForm extends React.Component<IProps> {

    // private formDispatch: any;

    public render() {
        return (
            <div className="container">
                <Form
                    model="forms.register"
                    validators={{
                        '': {
                          passwordsMatch: (vals) => vals.password === vals.confirmPassword,
                        },
                      }}
                    validateOn="change"
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                    <div>
                        <div className="bottomSeparator">
                            <p>Account Credentials</p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control
                                    model=".firstName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "First Name",
                                    }}
                                />
                                <Errors className="errors"
                                        model=".firstName"
                                        show="touched"
                                        messages={{
                                            required:'This field is required',
                                            maxLength50: 'First name is too long'
                                        }}
                                />
                            </div>
                            <div className="grid50">
                                <Control
                                    model=".lastName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "Last Name",
                                    }}
                                />
                                <Errors className="errors"
                                        model=".lastName"
                                        show="touched"
                                        messages={{
                                            required: 'This field is required',
                                            maxLength50: 'Last name is too long'
                                        }}
                                />
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".email"
                                type="email"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength5,
                                    maxLength200,
                                    isEmail
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Email",
                                }}
                            />
                            <Errors className="errors"
                                    model=".email"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required',
                                        isEmail: 'Invalid email address'
                                    }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".password"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength5,
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Password",
                                }}
                            />
                            <Errors className="errors"
                                    model=".password"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required',
                                        minLength5: 'Please use at least 5 characters',
                                        maxLength50: 'Password is too long',
                                    }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".confirmPassword"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Confirm Password",
                                }}
                            />
                            <Errors className="errors" 
                                    model="forms.register"
                                    show="touched"
                                    messages={{
                                        passwordsMatch: 'Passwords do not match.'
                                    }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".phoneNumber"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Phone Number",
                                }}
                            />
                            <Errors className="errors"
                                    model=".phoneNumber"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required',
                                        minLength5: 'Please use at least 5 characters',
                                        maxLength50: 'Phone number is too long'
                                    }}
                            />
                        </div>
                    </div>

                    <div>
                        <div className="bottomSeparator">
                            <p>Payment Address Data </p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control
                                    model=".paymentFirstName"
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "First Name",
                                    }}
                                />
                            </div>
                            <div className="grid50">
                                <Control
                                    model=".paymentLastName"
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "Last Name",
                                    }}
                                />
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".companyName"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength3,
                                    maxLength100
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Company Name",
                                }}
                            />
                            <Errors className="errors"
                                    model=".companyName"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required',
                                        minLength5: 'Please use at least 5 characters',
                                        maxLength50: 'Company name is too long'
                                    }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".streetAddress"
                                validators={{
                                    required: (val) => val && val.length,
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Street Address",
                                }}
                            />
                            <Errors className="errors"
                                    model=".streetAddress"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required',
                                        minLength5: 'Please use at least 5 characters',
                                        maxLength50: 'Street Address is too long'
                                    }}
                            />
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control
                                    model=".city"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "City",
                                    }}
                                />
                                <Errors className="errors"
                                        model=".city"
                                        show="touched"
                                        messages={{
                                            required: 'This field is required',
                                            minLength5: 'Please use at least 5 characters',
                                            maxLength50: 'City is too long'
                                        }}
                                />
                            </div>
                            <div className="grid50">
                                <Control
                                    model=".state"
                                    validators={{
                                        required: (val) => val && val.length,
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton",
                                        placeholder: "State",
                                    }}
                                />
                                <Errors className="errors"
                                        model=".state"
                                        show="touched"
                                        messages={{
                                            required: 'This field is required',
                                            minLength5: 'Please use at least 5 characters',
                                            maxLength50: 'State is too long'
                                        }}
                                />
                            </div>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control
                                    model=".zipCode"
                                    validators={{
                                        required: (val) => val && val.length,
                                        minLength5,
                                        maxLength5
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton",
                                        placeholder: "Postal/Zip Code",
                                    }}
                                />
                                <Errors className="errors"
                                        model=".zipCode"
                                        show="touched"
                                        messages={{
                                            required: 'This field is required',
                                            minLength5: 'Please use 5 characters',
                                        }}
                                />
                            </div>
                            <div className="grid50">
                                <Control.select
                                    model=".country"
                                    className="selectButton inputButton">
                                    <option value="Germany">Germany</option>
                                </Control.select>
                            </div>
                        </div>

                        <div className="submit">
                            <Link to={PATH_ROOT} role="button" type="submit" className="logIn bp3-button bp3-minimal">
                                Sign up
                            </Link>
                            <p>By signing up, you agree to our <Link to={PATH_TERMS}>Terms of Use</Link> and <Link
                                to={PATH_PRIVACY}>Privacy
                                Policy</Link>.</p>
                        </div>
                    </div>
                </Form>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        // this.formDispatch = dispatch;
    }

    /*
    private changeFooToBar = () => {
        this.formDispatch(actions.change('user.foo', 'bar'));
    }
    */
}