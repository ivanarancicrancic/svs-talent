import { I18nState } from 'react-redux-i18n';

export interface ITranslatable {
    i18n: I18nState;
}

export const translations = {
    de: require('./german.json'),
    en: require('./english.json')
}