import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'

import { RouteComponentProps, Switch, Route } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_LOGIN, PATH_DASHBOARD, PATH_CAMPAIGN_EDIT } from '../../router/paths';
// import { Button } from '@blueprintjs/core';
import { loginLogout } from '../../redux/auth/actions';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
// import { DashboardContainer } from '../DashboardContainer';
import EditCampaign from '../../components/Campaign/EditCampaign';
import DashboardLayout from '../../components/Dashboard/DashboardLayout';

interface IPropsStateMap {
  auth: IAuthState
}

interface IPropsDispatchMap {
  loginLogout: typeof loginLogout;
}

type IProps = RouteComponentProps<{}> & IPropsStateMap & IPropsDispatchMap;

class App extends React.Component<IProps> {

  public componentWillReceiveProps(nextProps: IProps) {
    if(this.props.auth.token != null && nextProps.auth.token == null) {
      this.props.history.replace(PATH_LOGIN);
    }
  }

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_DASHBOARD} exact={true} component={DashboardLayout} />
            <Route path={PATH_CAMPAIGN_EDIT} exact={true} component={EditCampaign} />
          </Switch>
          
          {/* <div>
            <Button text="Logout" icon="user" onClick={this.onLogout} />
          </div> */}
        </div>
        <Footer />
      </div>
    );
  }

  // private onLogout = () => {
  //   this.props.loginLogout();
  // }

}

const mapStateToProps = (state: IRootState) => ({
  auth: state.auth
});

export default connect(mapStateToProps, {loginLogout})(App);
