// import { Action } from 'redux'
import { IAudiosAction } from '../actions/localCampaignsActions'
import { HANDLE_SET_CONTENTS, HANDLE_FETCH_CONTENTS_FAILED, HANDLE_GET_ALL_CONTENTS } from '../actions/actionTypes'
import { IAudioContent } from '../../models/CampaignsModelHelper'

export interface IAudioContentsData {
    audios: IAudioContent[],
    error: boolean

}

const INITIAL_STATE: IAudioContentsData = {
    audios: [],
    error: false
}

export function audiosReducer(state: IAudioContentsData = INITIAL_STATE, action: IAudiosAction): IAudioContentsData {
    switch(action.type) {
        case HANDLE_GET_ALL_CONTENTS:
            return {
                ...action.payload
            };
        case HANDLE_SET_CONTENTS:
        console.log("CALLLED HANDLE_SET_CONTENTS");  
        return {
            ...state,
             audios: action.payload,
            error:false
          }; 
      case HANDLE_FETCH_CONTENTS_FAILED:
          return {
            ...state,
            error: true
          }; 
          
        default:
            return state
    }
}
