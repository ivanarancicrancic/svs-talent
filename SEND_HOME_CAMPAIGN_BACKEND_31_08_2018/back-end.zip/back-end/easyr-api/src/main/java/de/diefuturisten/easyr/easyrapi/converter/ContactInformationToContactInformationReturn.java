package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class ContactInformationToContactInformationReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation, ContactInformationReturn> {


    public ContactInformationToContactInformationReturn(){}

    @Override
    public ContactInformationReturn convert(de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation source) {
        if(source == null){
            return null;
        }
        ContactInformationReturn contactInformationReturn = new ContactInformationReturn();

        contactInformationReturn.setId(source.getId());
        contactInformationReturn.setName(source.getName());
        contactInformationReturn.setCompany(source.getCompany());
        contactInformationReturn.setHomepage(source.getHomepage());
        contactInformationReturn.setEmail(source.getEmail());
        contactInformationReturn.setAddress(source.getAddress());
        contactInformationReturn.setAddress2(source.getAddress2());
        contactInformationReturn.setName(source.getNumber());
        contactInformationReturn.setZip(source.getZip());
        contactInformationReturn.setCity(source.getCity());

        return contactInformationReturn;
    }
}
