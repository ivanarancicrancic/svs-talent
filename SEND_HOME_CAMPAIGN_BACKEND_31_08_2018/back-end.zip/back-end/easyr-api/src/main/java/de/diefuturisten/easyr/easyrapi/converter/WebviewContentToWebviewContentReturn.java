package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class WebviewContentToWebviewContentReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent, WebviewContentReturn> {

    public WebviewContentToWebviewContentReturn(){}

    @Override
    public WebviewContentReturn convert(de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent source) {
        WebviewContentReturn webviewContentReturn = new WebviewContentReturn();
        webviewContentReturn.setId(source.getId());
        webviewContentReturn.setWeight(source.getWeight());
        webviewContentReturn.setName(source.getName());
        webviewContentReturn.setUrl(source.getUrl());
        return webviewContentReturn;
    }

}
