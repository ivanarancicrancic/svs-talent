package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.repository.AudioContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AudioContentService {

    private AudioContentRepository audioContentRepository;
    private CampaignRepository campaignRepository;

    public AudioContentService(AudioContentRepository audioContentRepository, CampaignRepository campaignRepository) {
        this.audioContentRepository = audioContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public List<AudioContent> findAllAudios() {
        return  audioContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public AudioContent createAudioByCampaign(long id, AudioContent audioContent){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().add(audioContent);
        campaignRepository.save(optionalCampaign.get());
        audioContentRepository.save(audioContent);
        return  audioContent;
    }

    public AudioContent findAudioByCampaign(long id, long audioId){
        return (AudioContent) campaignRepository.findById(id).get().getContents().stream().filter(content -> content.getId()==audioId).findAny().get();
    }

    public void deleteAudioByCampaign(long id, long audioId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(audioContentRepository.findById(audioId).get());
        campaignRepository.save(optionalCampaign.get());
    }

    public void saveAudioByCampaign(long id, AudioContent audioContent,long audioId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(audioContentRepository.findById(audioId).get());
        optionalCampaign.get().getContents().add(audioContent);
        campaignRepository.save(optionalCampaign.get());
    }


    public List<AudioContent> findByCampagin(Campaign campaign) {
        return audioContentRepository.findByCampaign(campaign);
    }
}
