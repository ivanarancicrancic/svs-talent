package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class SlideshowImageToSlideshowImageReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage, SlideshowImageReturn> {

    public SlideshowImageToSlideshowImageReturn(){}

    @Override
    public SlideshowImageReturn convert(de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage source) {
        SlideshowImageReturn slideshowImageReturn = new SlideshowImageReturn();
        slideshowImageReturn.setId(source.getId());
        slideshowImageReturn.setWeight(source.getWeight());
        return slideshowImageReturn;
    }
}
