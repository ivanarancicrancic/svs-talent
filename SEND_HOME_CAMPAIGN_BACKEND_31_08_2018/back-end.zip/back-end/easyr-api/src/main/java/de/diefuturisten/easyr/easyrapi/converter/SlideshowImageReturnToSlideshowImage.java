package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class SlideshowImageReturnToSlideshowImage implements org.springframework.core.convert.converter.Converter<SlideshowImageReturn, de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage> {

    public SlideshowImageReturnToSlideshowImage(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage convert(SlideshowImageReturn source) {
        de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage slideshowImage = new de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage();
        slideshowImage.setId(source.getId());
        slideshowImage.setWeight(source.getWeight());
        return slideshowImage;
    }
}
