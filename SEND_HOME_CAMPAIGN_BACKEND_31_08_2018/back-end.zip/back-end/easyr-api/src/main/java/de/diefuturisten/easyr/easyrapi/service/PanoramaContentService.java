package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.PanoramaContentRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class PanoramaContentService {

    private PanoramaContentRepository panoramaContentRepository;
    private CampaignRepository campaignRepository;

    public PanoramaContentService(PanoramaContentRepository panoramaContentRepository, CampaignRepository campaignRepository) {
        this.panoramaContentRepository = panoramaContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public List<PanoramaContent> findAllPanoramas() {
        return panoramaContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public PanoramaContent findPanorama(long panoramaId){
       return panoramaContentRepository.findById(panoramaId).get();
    }

    public List<PanoramaContent> findPanoramaByCampagin(Campaign campaign){
        return panoramaContentRepository.findByCampaign(campaign);
    }

    public PanoramaContent saveByCampaign(long id, PanoramaContent panoramaContent, long panoramaid){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(panoramaContentRepository.findById(panoramaid));
        optionalCampaign.get().getContents().add(panoramaContent);
        campaignRepository.save(optionalCampaign.get());
        return  panoramaContent;
    }

    public void deletePanoramaByCampaign(long id, long panoramaId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(panoramaContentRepository.findById(panoramaId));
        campaignRepository.save(optionalCampaign.get());
    }

    public PanoramaContent createPanoramaByCampaign(long id, PanoramaContent panoramaContent){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().add(panoramaContent);
        campaignRepository.save(optionalCampaign.get());
        panoramaContentRepository.save(panoramaContent);
        return panoramaContent;
    }


}
