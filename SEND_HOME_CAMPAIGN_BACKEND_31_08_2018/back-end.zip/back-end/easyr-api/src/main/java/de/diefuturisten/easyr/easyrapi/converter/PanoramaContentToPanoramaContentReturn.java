package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class PanoramaContentToPanoramaContentReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent, PanoramaContentReturn> {

    public PanoramaContentToPanoramaContentReturn(){}


    @Override
    public PanoramaContentReturn convert(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent source) {

        PanoramaContentReturn panoramaContentReturn = new PanoramaContentReturn();

        panoramaContentReturn.setId(source.getId());

        panoramaContentReturn.setWeight(source.getWeight());

        panoramaContentReturn.setName(source.getName());

        panoramaContentReturn.setType(null);
        panoramaContentReturn.setUrl(source.getUrl());
       return  panoramaContentReturn;
    }

    }
