package de.diefuturisten.easyr.easyrapi.model.response;

public class SignedUploadURLResponse {

    private String signedUrl;

    public SignedUploadURLResponse() { }

    public SignedUploadURLResponse(String signedUrl) {
        this.signedUrl = signedUrl;
    }

    public String getSignedUrl() {
        return signedUrl;
    }

    public void setSignedUrl(String signedUrl) {
        this.signedUrl = signedUrl;
    }
}
