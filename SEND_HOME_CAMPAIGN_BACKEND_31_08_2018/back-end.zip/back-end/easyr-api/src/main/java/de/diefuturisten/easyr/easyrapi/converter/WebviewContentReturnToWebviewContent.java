package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class WebviewContentReturnToWebviewContent implements org.springframework.core.convert.converter.Converter<WebviewContentReturn, de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent> {

    public WebviewContentReturnToWebviewContent(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent convert(WebviewContentReturn source) {
        de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent webviewContent = new de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent();
        webviewContent.setId(source.getId());
        webviewContent.setWeight(source.getWeight());
        webviewContent.setName(source.getName());
        webviewContent.setUrl(source.getUrl());
        return webviewContent;
    }

}
