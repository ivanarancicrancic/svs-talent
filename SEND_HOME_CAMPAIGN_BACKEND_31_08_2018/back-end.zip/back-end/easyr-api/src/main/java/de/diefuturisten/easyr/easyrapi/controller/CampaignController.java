package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;

@RestController
@RequestMapping("/api")
@org.springframework.web.bind.annotation.CrossOrigin(origins = "http://localhost:3000")
public class CampaignController {

    de.diefuturisten.easyr.easyrapi.converter.MovieContentToMovieContentReturn movieContentToMovieContentReturn = new de.diefuturisten.easyr.easyrapi.converter.MovieContentToMovieContentReturn();
    de.diefuturisten.easyr.easyrapi.converter.AudioContentToAudioContentReturn audioContentToAudioContentReturn = new de.diefuturisten.easyr.easyrapi.converter.AudioContentToAudioContentReturn();
    de.diefuturisten.easyr.easyrapi.converter.PanoramaContentToPanoramaContentReturn panoramaContentToPanoramaContentReturn = new de.diefuturisten.easyr.easyrapi.converter.PanoramaContentToPanoramaContentReturn();
//    de.diefuturisten.easyr.easyrapi.converter.SphereContentToSphereContentReturn sphereContentToSphereContentReturn = new de.diefuturisten.easyr.easyrapi.converter.SphereContentToSphereContentReturn();


    @Autowired
    CampaignService campaignService;

    @Autowired
    SlideshowContentService slideShowContentService;

    @Autowired
    AudioContentService audioContentService;

    @Autowired
    MovieContentService movieContentService;

    @Autowired
    PanoramaContentService panoramaContentService;


    public CampaignController(CampaignService campaignService, SlideshowContentService slideShowContentService, AudioContentService audioContentService, MovieContentService movieContentService, PanoramaContentService panoramaContentService) {
        this.campaignService = campaignService;
        this.slideShowContentService = slideShowContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
        this.panoramaContentService = panoramaContentService;
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_LIST)
    public List<de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand> getCampaigns() throws Exception
    {
        System.out.println("Entered /campaigns");
        List<de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand> campaigns = new ArrayList<>();
        try{
            campaigns = campaignService.getAllCampaigns();
            return campaigns;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    //    @GetMapping("/campaign/{id}/slideshows")
//    @ResponseStatus(HttpStatus.OK)
////    @PreAuthorize(de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority.SLIDESHOWS_LIST)
//    public SlideshowListEntry getSlideshowsByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/slideshows");
//        List<SlideshowContent> slideshows = null;
//        List<SlideshowContent> allSlideshows = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allSlideshows = slideShowContentService.findAllSlides();
//            for(SlideshowContent slideshowContent: allSlideshows)
//            {
//                if(slideshowContent.getCampaign().getId() == new Long(id))
//                {
//                    slideshows.add(slideshowContent);
//                }
//            }
//            return new SlideshowListEntry(slideshows);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//
    @GetMapping("/campaign/{id}/audios")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.AUDIO_LIST)
    public List<de.diefuturisten.easyr.easyrapi.model.response.AudioContentReturn> getAudiosByCampaign(@PathVariable String id) throws Exception
    {
        System.out.println("Entered /campaign/{id}/audios");
        List<de.diefuturisten.easyr.easyrapi.model.response.AudioContentReturn> audios = new java.util.ArrayList<>();
        List<AudioContent> allAudios = new java.util.ArrayList<>();
        List<Content> contents = null;
        try{
            allAudios= audioContentService.findAllAudios();
            for(AudioContent audioContent: allAudios)
            {
                if(audioContent.getCampaign().getId() == new Long(id))
                {
                    audios.add(audioContentToAudioContentReturn.convert(audioContent));
                }
            }
            return audios;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }



    @GetMapping("/campaign/{id}/movies")
    @ResponseStatus(HttpStatus.OK)
//@PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.MOVIES_LIST)
    public List<de.diefuturisten.easyr.easyrapi.model.response.MovieContentReturn> getMoviesByCampaign(@PathVariable String id) throws Exception
    {
        System.out.println("Entered /campaign/{id}/movies");
        List<de.diefuturisten.easyr.easyrapi.model.response.MovieContentReturn> movies = new java.util.ArrayList<>();
        List<MovieContent> allMovies = new java.util.ArrayList<>();
        try{
            allMovies= movieContentService.findAllMovies();
            for(MovieContent movieContent: allMovies)
            {
                if(movieContent.getCampaign().getId() == new Long(id))
                {
                    movies.add(movieContentToMovieContentReturn.convert(movieContent));
                }
            }
            return movies;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }




    @GetMapping("/campaign/{id}/panoramas")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PANORAMA_LIST)
    public List<de.diefuturisten.easyr.easyrapi.model.response.PanoramaContentReturn> getPanoramasByCampaign(@PathVariable String id) throws Exception
    {
        System.out.println("Entered /campaign/{id}/panoramas");
        List<de.diefuturisten.easyr.easyrapi.model.response.PanoramaContentReturn> panoramas = new java.util.ArrayList<>();
        List<PanoramaContent> allPanoramas = new java.util.ArrayList<>();
        try{
            allPanoramas= panoramaContentService.findAllPanoramas();
            for(PanoramaContent panoramaContent: allPanoramas)
            {
                if(panoramaContent.getCampaign().getId() == new Long(id))

                {
                    panoramas.add(panoramaContentToPanoramaContentReturn.convert(panoramaContent));
                }
            }
            return panoramas;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }



//    @GetMapping("/campaign/{id}/spheres")
//    @ResponseStatus(HttpStatus.OK)
////    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.SPHERE_LIST)
//    public java.util.List<de.diefuturisten.easyr.easyrapi.model.response.SphereContentReturn> getSpheresByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/sphere");
//        List<de.diefuturisten.easyr.easyrapi.model.response.SphereContentReturn> spheres = new java.util.ArrayList<>();
//        List<SphereContent> allSpheres = new java.util.ArrayList<>();
//        try{
//            allSpheres= sphereContentService.findAllSpheres();
//            for(SphereContent sphereContent: allSpheres)
//            {
//                if(sphereContent.getCampaign().getId() == new Long(id))
//
//                {
//                    spheres.add(sphereContentToSphereContentReturn.convert(sphereContent));
//                }
//            }
//            return spheres;
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//



    @GetMapping("/campaign/show/{id}")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_VIEW)
    public de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand showById(@PathVariable String id) throws  Exception{
        System.out.println("entered campaign/show/{id}");
        try{
            de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
            return campaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PostMapping("/campaign/create")
    @ResponseStatus(HttpStatus.CREATED)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_CREATE)
    public Campaign createCampaign(@RequestBody Campaign campaignCommand) throws Exception{
        System.out.println("BEFORE CREATING CAMPAIGN: " + campaignCommand.getTracker());


        try{
            Campaign createdCampaignCommand = campaignService.createCampaign(campaignCommand);
            System.out.println("Id of campaign created:" + createdCampaignCommand.getId());
            return createdCampaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PutMapping("/campaign/update")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_EDIT)
    public Campaign saveOrUpdate(@RequestBody Campaign campaign) throws  Exception{
        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID:" + campaign.getId());
        Campaign savedCampaign = campaignService.updateCampaign(campaign);
        System.out.println("Id of campaign updated:" + savedCampaign.getId());
        System.out.println("Contents of campaign updated: ");
        for(Content campaignContent1 : savedCampaign.getContents())
            System.out.println("Content: " +  campaignContent1.getName());
        try{
            return campaign;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("campaign/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_DELETE)
    public de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand deleteCampaign(@PathVariable String id){
        System.out.println("Entered deleting campaign");
        de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
        campaignService.deleteCampaign(Long.valueOf(id));
        return campaignCommand;

    }



}
