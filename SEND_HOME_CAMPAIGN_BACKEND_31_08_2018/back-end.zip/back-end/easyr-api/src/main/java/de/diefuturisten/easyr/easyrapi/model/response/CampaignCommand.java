package de.diefuturisten.easyr.easyrapi.model.response;

public class CampaignCommand {

    private Long id;

    private UserReturn user;

    private java.util.List<TrackerReturn> tracker = new java.util.ArrayList<>();

    private java.util.List<ContentReturn> contents = new java.util.ArrayList<>();

    private ContactInformationReturn contact;

    public CampaignCommand(){};

    public CampaignCommand(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserReturn getUser() {
        return user;
    }

    public void setUser(UserReturn user) {
        this.user = user;
    }

    public java.util.List<TrackerReturn> getTracker() {
        return tracker;
    }

    public void setTracker(java.util.List<TrackerReturn> tracker) {
        this.tracker = tracker;
    }

    public java.util.List<ContentReturn> getContents() {
        return contents;
    }

    public void setContents(java.util.List<ContentReturn> contents) {
        this.contents = contents;
    }

    public ContactInformationReturn getContact() {
        return contact;
    }

    public void setContact(ContactInformationReturn contact) {
        this.contact = contact;
    }
}
