package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;

import java.util.List;

public class SlideshowListEntry {
    List<SlideshowContent> slideshows;

    public SlideshowListEntry(){}
    public SlideshowListEntry(List<SlideshowContent> slideshows) {
        this.slideshows = slideshows;
    }

    public List<SlideshowContent> getSlideshows() {
        return slideshows;
    }

    public void setSlideshows(List<SlideshowContent> slideshows) {
        this.slideshows = slideshows;
    }
}
