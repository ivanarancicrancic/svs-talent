package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class MovieContentReturnToMovieContent implements org.springframework.core.convert.converter.Converter<MovieContentReturn, de.diefuturisten.easyr.easyrapi.entity.content.MovieContent> {

    public MovieContentReturnToMovieContent(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.content.MovieContent convert(MovieContentReturn source) {

        de.diefuturisten.easyr.easyrapi.entity.content.MovieContent movieContent = new de.diefuturisten.easyr.easyrapi.entity.content.MovieContent();

        movieContent.setId(source.getId());

        movieContent.setWeight(source.getWeight());

        movieContent.setName(source.getName());

        movieContent.setType(null);
        movieContent.setUrl(source.getUrl());

        if(source.getDownload()== "true")
            movieContent.setDownload(true);
        else
            movieContent.setDownload(false);

        if(source.getSeekbar() == "true")
        movieContent.setSeekbar(true);
        else
            movieContent.setSeekbar(false);

        movieContent.setPositionX(source.getPositionX());
        movieContent.setPositionY(source.getPositionY());
        movieContent.setPositionZ(source.getPositionZ());
        movieContent.setRotationX(source.getRotationX());
        movieContent.setRotationY(source.getRotationY());
        movieContent.setRotationZ(source.getRotationZ());

        movieContent.setScaleX(source.getScaleX());
        movieContent.setScaleY(source.getScaleY());
        movieContent.setScaleZ(source.getScaleZ());

        if(source.getRenderOnTrackingLost() == "true")
             movieContent.setRenderOnTrackingLost(true);
        else
            movieContent.setRenderOnTrackingLost(false);

        if(source.getExtendedTracking() == "true")
            movieContent.setExtendedTracking(true);
        else
            movieContent.setExtendedTracking(false);

        return movieContent;
    }

    }
