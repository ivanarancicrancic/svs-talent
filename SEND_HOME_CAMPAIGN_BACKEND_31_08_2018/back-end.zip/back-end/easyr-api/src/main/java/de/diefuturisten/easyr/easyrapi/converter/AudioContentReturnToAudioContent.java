package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class AudioContentReturnToAudioContent implements org.springframework.core.convert.converter.Converter<AudioContentReturn, de.diefuturisten.easyr.easyrapi.entity.content.AudioContent> {

    public AudioContentReturnToAudioContent(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.content.AudioContent convert(AudioContentReturn source) {
        de.diefuturisten.easyr.easyrapi.entity.content.AudioContent audioContent = new de.diefuturisten.easyr.easyrapi.entity.content.AudioContent();
        audioContent.setId(source.getId());
        audioContent.setWeight(source.getWeight());
        audioContent.setName(source.getName());
        audioContent.setUrl(source.getUrl());
        if(source.getRenderOnTrackingLost() == "true")
            audioContent.setRenderOnTrackingLost(true);
        else
            audioContent.setRenderOnTrackingLost(false);

        return audioContent;
    }
}
