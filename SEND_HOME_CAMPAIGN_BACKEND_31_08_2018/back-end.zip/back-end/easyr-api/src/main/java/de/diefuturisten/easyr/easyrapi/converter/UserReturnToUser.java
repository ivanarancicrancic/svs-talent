package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class UserReturnToUser implements org.springframework.core.convert.converter.Converter<UserReturn, de.diefuturisten.easyr.easyrapi.entity.user.User> {

    public UserReturnToUser(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.user.User convert(UserReturn source) {

        de.diefuturisten.easyr.easyrapi.entity.user.User user= new de.diefuturisten.easyr.easyrapi.entity.user.User();

       user.setId(source.getId());
       user.setLanguage(source.getLanguage());
       user.setActive(source.isActive());
       user.setEmail(source.getEmail());
       user.setPassword(source.getPassword());
       user.setGender(source.isGender());
       user.setFirstname(source.getFirstname());
       user.setLastname(source.getLastname());
       user.setResetPasswordTokens(null);
       user.setRoles(null);
        return user;
    }
}
