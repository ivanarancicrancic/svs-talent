package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

@Entity
@Table(name="content_panoramas")
public class PanoramaContent extends Content {

    public enum Type { X180, X360, SPHERE }

    @Enumerated(EnumType.STRING)
    @Column(name="type", nullable = false)
    private Type type;

    @Column(name="url", nullable = false)
    private String url;

    // getter & setter

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
