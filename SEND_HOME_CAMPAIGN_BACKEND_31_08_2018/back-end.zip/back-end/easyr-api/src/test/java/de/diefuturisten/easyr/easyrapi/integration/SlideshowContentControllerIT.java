package de.diefuturisten.easyr.easyrapi.integration;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.controller.SlideshowContentController;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.*;
import de.diefuturisten.easyr.easyrapi.repository.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import static org.junit.Assert.assertNotNull;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class SlideshowContentControllerIT {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ContactInformationRepository contactInformationRepository;
    @Autowired
    private CampaignRepository campaignRepository;
    @Autowired
    private SlideshowContentRepository slideshowContentRepository;
    @Autowired
    private SlideshowImageRepository slideshowImageRepository;
    @Autowired
    private UserRoleRepository userRoleRepository;
    @Autowired
    private UserRightRepository userRightRepository;
    @Autowired
    private AudioContentRepository audioContentRepository;
    @Autowired
    private WebviewContentRepository webviewContentRepository;
    @Autowired
    private PanoramaContentRepository panoramaContentRepository;
    @Autowired
    private MovieContentRepository movieContentRepository;
    @Autowired
    private UnityContentRepository unityContentRepository;



    private Campaign campaign;
    private SlideshowContent slideshowContent;
    private SlideshowContent slideshowContentToPost;
    private SlideshowImage slideshowImage;
    private AudioContent audioContent;
    private AudioContent audioContentToSave;
    private WebviewContent webviewContent;
    private WebviewContent webviewContentToSave;
    private PanoramaContent panoramaContent;
    private PanoramaContent panoramaContentToSave;
    private MovieContent movieContent;
    private MovieContent movieContentToSave;
    private UnityContent unityContent;
    private UnityContent unityContentToSave;
    private ObjectMapper mapper;
    private String token;


    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
        IntegrationTestHelper.prepareContactData(contactInformationRepository);
        System.out.println("user's id is"+userRepository.findByEmail("ivica.taskovski@app-logik.de").get().getId());
        IntegrationTestHelper.prepareCampaignData(campaignRepository, userRepository.findByEmail("ivica.taskovski@app-logik.de"),contactInformationRepository.findByEmail("ivica.taskovski@app-logik.de") );
        System.out.println("so we have a campaign saved if a numbers shows after "+campaignRepository.findAll().size());
        this.campaign = campaignRepository.findAll().stream().findFirst().get();
        System.out.println("Campaign's number is"+campaignRepository.findAll().stream().findFirst().get().getId());
        this.slideshowContent = new SlideshowContent();
        slideshowContent.setCampaign(campaign);
        slideshowContent.setWeight(3);
        slideshowContent.setName("Neu Slideshow");
        slideshowContent.setExtendedTracking(true);
        slideshowContent.setPositionX(0);
        slideshowContent.setPositionY(1);
        slideshowContent.setPositionZ(0);
        slideshowContent.setRotationX(3);
        slideshowContent.setRotationY(2);
        slideshowContent.setRotationZ(1);
        slideshowContent.setRenderOnTrackingLost(false);

        this.slideshowContentToPost = new SlideshowContent();
        slideshowContentToPost.setCampaign(campaign);
        slideshowContentToPost.setWeight(3);
        slideshowContentToPost.setName("Zweite Slideshow");
        slideshowContentToPost.setExtendedTracking(true);
        slideshowContentToPost.setPositionX(0);
        slideshowContentToPost.setPositionY(1);
        slideshowContentToPost.setPositionZ(0);
        slideshowContentToPost.setRotationX(3);
        slideshowContentToPost.setRotationY(2);
        slideshowContentToPost.setRotationZ(1);
        slideshowContentToPost.setRenderOnTrackingLost(false);

        slideshowContentRepository.save(slideshowContent);
        System.out.println("we have a slideshow content if number shows after"+ slideshowContentRepository.findByName("Neu Slideshow").get().getId());
        this.slideshowImage = new SlideshowImage();
        slideshowImage.setSlideshow(slideshowContent);
        slideshowImage.setWeight(4);
        slideshowImage.setUrl("http://www.example.org/test.png");


        slideshowImageRepository.save(slideshowImage);
        System.out.println("we have a slideshow image saved if number shows after"+ slideshowImageRepository.findAll().stream().findFirst().get().getId());
        System.out.println("with a slide show id"+slideshowImage.getSlideshow().getId());

        IntegrationTestHelper.prepareAudioData(campaignRepository, audioContentRepository);

        this.audioContent = audioContentRepository.findByName("New Audio content").get();
        this.audioContentToSave = audioContentRepository.findByName("Audio To Save").get();

        IntegrationTestHelper.prepareWebvies(campaignRepository, webviewContentRepository);
        this.webviewContent = webviewContentRepository.findByName("New webView").get();
        this.webviewContentToSave = webviewContentRepository.findByName("webView to be saved").get();

        IntegrationTestHelper.praparePanoramas(campaignRepository, panoramaContentRepository);
        this.panoramaContent = panoramaContentRepository.findByName("New Panorama").get();
        this.panoramaContentToSave = panoramaContentRepository.findByName("Panorama to be saved").get();

        IntegrationTestHelper.prepareMovies(campaignRepository, movieContentRepository);
        this.movieContent= movieContentRepository.findByName("new movie").get();
        this.movieContentToSave = movieContentRepository.findByName("movie to save").get();

        IntegrationTestHelper.prepareUnities(campaignRepository, unityContentRepository);
        this.unityContent = unityContentRepository.findByName("new Unity").get();
        this.unityContentToSave = unityContentRepository.findByName("Unity to save").get();



        mapper = new ObjectMapper();
        token = IntegrationTestHelper.createLoginToken(userRepository.findByEmail("ivica.taskovski@app-logik.de").get());


    }


    @Test
    @Transactional
    public void testContent(){
        slideshowContentRepository.findByName("Neu Slideshow").get();
    }

    @Test
    @Transactional
    public void testSlideById() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = get("/api/slideshows/"+slideshowContent.getId()).header("Content-Type", "application/json").header("Authorization", token);
        this.mvc.perform(request).andExpect(status().isOk());
    }

//    @Test
//    @Transactional
//    public void testPostSlide() throws Exception{
//        this.mvc.perform((post(SlideshowContentController.BASE_URL).
//                contentType("application/json")).
//                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
//                        .writeValueAsString(slideshowContentToPost)))
//                .andExpect(status().isForbidden());
//
//    }
    @Test
    @Transactional
    public void testImagesBySlide() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = get("/api/slideshows/"+slideshowContent.getId()+"/images").header("Content-Type", "application/json").header("Authorization", token);
        this.mvc.perform(request).andExpect(status().isOk());
    }
    @Test
    @Transactional
    public void postImageBySlide() throws Exception{
        assertNotNull(token);
        this.mvc.perform((post("/api/slideshows/"+slideshowImage.getSlideshow().getId()+"/images").
                contentType("application/json").header("Authorization", token)).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                    writeValueAsString(slideshowImage)))
                .andExpect(status().isCreated());
    }


    @Test
    @Transactional
    public void deleteImageBySlide() throws Exception{
        assertNotNull(token);
        this.mvc.perform((delete("/api/slideshows/"+slideshowImage.getSlideshow().
                getId()+"/images/"+slideshowImage.getId())
                .contentType("application/json").header("Authorization", token)).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .writeValueAsString(slideshowImage))).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void postAudioByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = post("/api/campaigns/"+audioContent.getCampaign().getId()+"/audios/").header("Content-Type", "application/json").header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                writeValueAsString(audioContent));
        this.mvc.perform(request).andExpect(status().isCreated());
    }

    @Test
    @Transactional
    public void deleteAudioByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = delete("/api/campaigns/"+audioContent.getCampaign().getId()+"/audios/"+audioContent.getId()).header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(audioContent));
        this.mvc.perform(request).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void saveAudioByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = put("/api/campaigns/"+audioContent.getCampaign().getId()+"/audios/"+audioContent.getId()).header("Content-Type", "application/json").header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                writeValueAsString(audioContentToSave));
        this.mvc.perform(request).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void modifyWebviewByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaigns/"+webviewContent.getCampaign().getId()+"/webviews/"+webviewContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(webviewContentToSave));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void createWebviewByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaigns/"+webviewContent.getCampaign().getId()+"/webviews/").header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(webviewContent));
        this.mvc.perform(requestBuilder).andExpect(status().isCreated());
    }

    @Test
    @Transactional
    public void deleteWebviewByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = delete("/api/campaigns/"+webviewContent.getCampaign().getId()+"/webviews/"+webviewContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(webviewContent));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void createPanoramaByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaigns/"+panoramaContent.getCampaign().getId()+"/panoramas/").
                header("Content-Type", "application/json").
                header("Authorization", token).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                writeValueAsString(panoramaContent));
        this.mvc.perform(requestBuilder).andExpect(status().isCreated());
    }

    @Test
    @Transactional
    public void deletePanoramaByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = delete("/api/campaigns/"+panoramaContent.getCampaign().getId()+"/panoramas/"+panoramaContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(panoramaContent));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void modifyPanoramaByCampaign() throws Exception{
        assertNotNull((token));
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaigns/"+panoramaContent.getCampaign().getId()+"/panoramas/"+panoramaContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(panoramaContentToSave));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void modifyMovieByCampaign() throws Exception{
        assertNotNull((token));
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaigns/"+movieContent.getCampaign().getId()+"/movies/"+movieContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(movieContentToSave));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void createMovieByCampaign() throws Exception{
        assertNotNull((token));
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaigns/"+movieContent.getCampaign().getId()+"/movies/").header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(movieContent));
        this.mvc.perform(requestBuilder).andExpect(status().isCreated());
    }

    @Test
    @Transactional
    public void deleteMovieByCampaign() throws Exception{
        assertNotNull((token));
        MockHttpServletRequestBuilder requestBuilder = delete("/api/campaigns/"+movieContent.getCampaign().getId()+"/movies/"+movieContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(movieContent));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void modifyUnityByCampaign() throws Exception{
        assertNotNull((token));
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaigns/"+unityContent.getCampaign().getId()+"/unities/"+unityContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(unityContentToSave));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void deleteUnityByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = delete("/api/campaigns/"+unityContent.getCampaign().getId()+"/unities/"+unityContent.getId()).header("Content-Type", "application/json").
                header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(unityContent));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void createUnityByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaigns/"+unityContent.getCampaign().getId()+"/unities/").
                header("Content-Type", "application/json").
                header("Authorization", token).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                        writeValueAsString(unityContent));
        this.mvc.perform(requestBuilder).andExpect(status().isCreated());
    }



    @After
    public void cleanup(){
        java.util.List<de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage> slideshowImageList = slideshowContentRepository.findById(slideshowImage.getSlideshow().getId()).get().getImages();

    }

}
