package de.diefuturisten.easyr.easyrapi.integration;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.repository.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.transaction.annotation.Transactional;

import static org.junit.Assert.assertNotNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class CampaignControllerIT {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ContactInformationRepository contactInformationRepository;
    @Autowired
    private CampaignRepository campaignRepository;
    @Autowired
    private UserRoleRepository userRoleRepository;
    @Autowired
    private UserRightRepository userRightRepository;

    private Campaign campaign;
    private ObjectMapper mapper;
    private String token;


   @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
        IntegrationTestHelper.prepareContactData(contactInformationRepository);
        System.out.println("user's id is"+userRepository.findByEmail("ivica.taskovski@app-logik.de").get().getId());
        IntegrationTestHelper.prepareCampaignData(campaignRepository, userRepository.findByEmail("ivica.taskovski@app-logik.de"),contactInformationRepository.findByEmail("ivica.taskovski@app-logik.de") );
        System.out.println("so we have a campaign saved if a numbers shows after "+campaignRepository.findAll().size());
        this.campaign = campaignRepository.findAll().stream().findFirst().get();
        System.out.println("Campaign's number is "+campaign.getId());

        this.campaign =  campaignRepository.findAll().stream().findFirst().get();
        campaign.setContents(null);

        mapper = new ObjectMapper();
        token = IntegrationTestHelper.createLoginToken(userRepository.findByEmail("ivica.taskovski@app-logik.de").get());
    }


    @Test
    @Transactional
    public void testContent(){
       // slideshowContentRepository.findByName("Neu Slideshow").get();
    }

    @Test
    @Transactional
    public void postCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaign/create").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(campaign));
        this.mvc.perform(requestBuilder).andExpect(status().isCreated());
    }

    @Test
    @Transactional
    public void updateCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaign/update").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).writeValueAsString(campaign));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void getCampaignByCampaignId() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/show/" + campaign.getId()).header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void getMoviesByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/" + campaign.getId() + "/movies").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void getAudiosByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/" + campaign.getId() + "/audios").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void getPanoramasByCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/" + campaign.getId() + "/panoramas").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @After
    public void cleanup(){

    }

}
