package springwebapp.repository;

import org.springframework.stereotype.Component;
import springwebapp.model.TableAtrtributes;

@Component
public class TableAttributeRepositoryImpl implements TableAttributeRepository {

    @Override
    public TableAtrtributes getEnglishTableAttributes() {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Title", "Publisher", "Book List");
        return tableAtrtributes;
    }

    @Override
    public TableAtrtributes getSpanishTableAttributes()
    {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Título", "Publicador", "lista de libros");
        return tableAtrtributes;
    }

    @Override
    public TableAtrtributes getGermanTableAttributes() {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Titel", "Verleger", "Buchliste");
        return tableAtrtributes;

    }

}
