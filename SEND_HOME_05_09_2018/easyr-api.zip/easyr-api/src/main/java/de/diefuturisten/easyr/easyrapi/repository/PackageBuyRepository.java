package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface PackageBuyRepository extends JpaRepository<PackageBuy, Long> {
    @Query("SELECT count(x) FROM PackageBuy x WHERE x.user = ?1 and x.runtimePackage = ?2 and x.usedOnRuntime is null")
    Long countAvailable(User user, RuntimePackage runtimePackage);

    @Query("SELECT count(x) FROM PackageBuy x WHERE x.user = ?1 and x.runtimePackage = ?2 and x.usedOnRuntime is not null")
    Long countUsed(User user, RuntimePackage runtimePackage);

    Optional<PackageBuy> findFirstByUserAndRuntimePackageAndUsedOnRuntimeIsNull(User user, RuntimePackage runtimePackage);
}
