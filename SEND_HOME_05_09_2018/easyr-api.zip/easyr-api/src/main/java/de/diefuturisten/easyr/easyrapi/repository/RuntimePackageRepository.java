package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.stream.Stream;

public interface RuntimePackageRepository extends JpaRepository<RuntimePackage, Long> {
}
