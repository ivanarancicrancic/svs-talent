package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.user.ResetPasswordToken;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordModel;
import de.diefuturisten.easyr.easyrapi.repository.ResetPasswordTokenRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.security.SecurityConstants;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private ResetPasswordTokenRepository resetPasswordTokenRepository;
    private MailingService mailingService;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, ResetPasswordTokenRepository resetPasswordTokenRepository, MailingService mailingService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.resetPasswordTokenRepository = resetPasswordTokenRepository;
        this.mailingService = mailingService;
    }

    public User getUserByUsername(String username) {
        return userRepository.findByEmail(username).orElseThrow(NoSuchElementException::new);
    }


    public User getUserByUserId(long userId) {
        return userRepository.findById(userId).orElseThrow(NoSuchElementException::new);
    }

    public User create(CreateAccountModel model) {
        User user = new User();

        user.setActive(true);
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());
        user.setEmail(model.getEmail());
        user.setPassword(passwordEncoder.encode(model.getPassword()));
        user.setLanguage(model.getLanguage());

        userRepository.save(user);

        try {
            mailingService.sendNewUserWelcome(user);
        } catch (CannotSendEmailException e) {
            log.error(String.format("Welcome E-Mail could not be send for user:", user.getEmail()));
        }

        return user;
    }

    public void forgotPassword(ForgotPasswordModel model) throws CannotSendEmailException {
        try {
            User user = getUserByUsername(model.getEmail());
            deleteOldToken(user);
            ResetPasswordToken token = createAndSaveNewToken(user);
            mailingService.sendPasswordResetToken(user, token.getToken());
        } catch(NoSuchElementException e) {
            return;
        }

    }

    private void deleteOldToken(User user) {
        resetPasswordTokenRepository.findByUser(user).ifPresent(token -> resetPasswordTokenRepository.delete(token)); // NOSONAR
    }

    private ResetPasswordToken createAndSaveNewToken(User user) {
        String tokenValue = UUID.randomUUID().toString().replace("-", "").substring(0, SecurityConstants.PASSWORD_RESET_TOKEN_LENGTH).toUpperCase();

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, SecurityConstants.PASSWORD_RESET_TOKEN_EXPIRE_DAYS);

        ResetPasswordToken token = new ResetPasswordToken(user, cal.getTime(), tokenValue);
        resetPasswordTokenRepository.save(token);

        log.info(String.format("Created ResetPasswordToken for user %s: %s", user.getEmail(), token.getToken()));

        return token;
    }


    public boolean resetPassword(User user, String tokenValue, String userDefinedPassword) throws CannotSendEmailException {
        Optional<ResetPasswordToken> savedToken = resetPasswordTokenRepository.findByUserAndToken(user, tokenValue);
        if( !savedToken.isPresent() ){
            return false;
        }

        // check validity
        boolean valid = new Date().before(savedToken.get().getExpires());

        // delete token
        deleteOldToken(user);

        // set new password
        user.setPassword(passwordEncoder.encode(userDefinedPassword));

        // send email to user
        mailingService.sendNewPassword(user);

        return valid;
    }

    public List<User> getAllUser() {
        return userRepository.findAll();
    }
}
