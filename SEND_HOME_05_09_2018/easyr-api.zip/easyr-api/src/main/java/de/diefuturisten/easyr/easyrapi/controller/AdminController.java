package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserModelForAdmin;
import de.diefuturisten.easyr.easyrapi.service.AdminService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private AdminService adminService;

    private CampaignService campaignService;

    public AdminController(AdminService adminService, CampaignService campaignService) {
        this.adminService = adminService;
        this.campaignService = campaignService;
    }

    // TODO: add check for admin role/rules to all requests

    @RequestMapping(value = "/admin/users", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(Collectors.toList());
    }

    @RequestMapping(value = "/admin/campaigns", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<CampaignOverviewModel> listAllCampaigns() {

        return campaignService.findAllCampaigns();
    }

    @RequestMapping(value = "/admin/campaigns/{userId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<CampaignOverviewModel> listCampaignsForUser(@PathVariable long userId) {

        return campaignService.getCampaignsForUser(adminService.getUserByID(userId));
    }

    @RequestMapping(value = "/admin/coupon", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public Coupon listCampaignsForUser(@Valid @RequestBody CreateCouponAdminModel model) {
        /*
         * TODO: create a coupon for the given user and package
         */
        return null;
    }
}
