package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;

@Service
@Transactional
public class CampaignService {

    private final CampaignRepository campaignRepository;
    private final CampaignRuntimeService campaignRuntimeService;

    public CampaignService(CampaignRepository campaignRepository, CampaignRuntimeService campaignRuntimeService) {
        this.campaignRepository = campaignRepository;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    public List<CampaignOverviewModel> findAllCampaigns() {
       List<Campaign> campaigns = campaignRepository.findAll().stream().collect(Collectors.toList());
    List<CampaignOverviewModel> campaignOverviewModels = new ArrayList<>();
      CampaignOverviewModel campaignOverviewModel = new CampaignOverviewModel();
       for(Campaign campaign: campaigns){
           campaignOverviewModel.setId(campaign.getId());
           campaignOverviewModel.setName(campaign.getName());
           campaignOverviewModel.setTrackerUrl(campaign.getTrackerUrl());
           campaignOverviewModel.setNumberOfViews(campaign.getNumberOfViews());
            campaignOverviewModels.add(campaignOverviewModel);
       }
       return campaignOverviewModels;
    }

    public List<CampaignOverviewModel> getCampaignsForUser(User user) {

        List<Campaign> campaigns = campaignRepository.findByUser(user).collect(Collectors.toList());
        List<CampaignOverviewModel> campaignOverviewModels = new ArrayList<>();
        CampaignOverviewModel campaignOverviewModel = new CampaignOverviewModel();
        for(Campaign campaign: campaigns){
            campaignOverviewModel.setId(campaign.getId());
            campaignOverviewModel.setName(campaign.getName());
            campaignOverviewModel.setTrackerUrl(campaign.getTrackerUrl());
            campaignOverviewModel.setNumberOfViews(campaign.getNumberOfViews());
            campaignOverviewModels.add(campaignOverviewModel);
        }
        return campaignOverviewModels;
    }

    public Optional<Campaign> getCampaign(long id) {

        return this.campaignRepository.findById(id);
//        Campaign campaign = this.campaignRepository.findById(id).get();
//
//        CampaignOverviewModel campaignOverviewModel = new CampaignOverviewModel();
//            campaignOverviewModel.setId(campaign.getId());
//            campaignOverviewModel.setName(campaign.getName());
//            campaignOverviewModel.setTrackerUrl(campaign.getTrackerUrl());
//            campaignOverviewModel.setNumberOfViews(campaign.getNumberOfViews());
//            return campaignOverviewModel;
         }


    public CampaignDetailModel createCampaignForUser(CreateCampaignModel createCampaignModel, User user) throws NoRuntimePackageAvailableException {
        PackageBuy availablePackage = campaignRuntimeService.userHasPackageAvailable(user, createCampaignModel.getPackageId());

        if(availablePackage == null) {
            throw new NoRuntimePackageAvailableException();
        }

        Campaign campaign = new Campaign();
        campaign.setUser(user);
        campaign.setName("Campaign Name");
        campaign.setDescription("Campaign Description");
        campaign = this.campaignRepository.save(campaign);

        campaignRuntimeService.createRuntime(campaign, availablePackage);

        CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
        campaignDetailModel.setId(campaign.getId());
        campaignDetailModel.setName(campaign.getName());
        campaignDetailModel.setTrackerUrl(campaign.getTrackerUrl());

        return campaignDetailModel;

        }

    public CampaignDetailModel editCampaign(Campaign campaign, EditCampaignModel editCampaignModel) {
        campaign.setName(editCampaignModel.getName());
        campaign.setDescription(editCampaignModel.getDescription());
         this.campaignRepository.save(campaign);

      CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
        campaignDetailModel.setId(editCampaignModel.getId());
        campaignDetailModel.setName(editCampaignModel.getName());
     campaignDetailModel.setDescription(editCampaignModel.getDescription());

        return campaignDetailModel;

    }

}
