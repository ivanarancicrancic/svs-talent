import { applyMiddleware } from 'redux';
import { routerMiddleware } from 'react-router-redux';
import { createStore, compose } from 'redux';
import { syncTranslationWithStore, loadTranslations, setLocale } from 'react-redux-i18n';

import thunk from 'redux-thunk';
import { createLogicMiddleware } from 'redux-logic';

import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

import { translations } from '../translation';
import { reducers } from '.';
import { history } from '../router';

import orderListLogics from './order-list/logics';
import filterOrderFetchLogic from './filterOrders/logics';
import { orderDetailFetchLogic } from './order-detail/logics';

const persistConfig = {
    key: 'root',
    storage,
    whitelist: ['auth']
};

const persistedReducer = persistReducer(persistConfig, reducers);

const composeEnhancers = (
    process.env.NODE_ENV === 'development' && window && (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
  ) || compose;

const logicMiddleware = createLogicMiddleware([
    ...orderListLogics,
    ...filterOrderFetchLogic,
    ...orderDetailFetchLogic
 
], {});

const enhancer = composeEnhancers(
    applyMiddleware(routerMiddleware(history), thunk, logicMiddleware)
);

export const store = createStore(persistedReducer, {}, enhancer);
export const persistor = persistStore(store);

syncTranslationWithStore(store);
store.dispatch(loadTranslations(translations));
store.dispatch(setLocale('de'));