import { IRootState } from '..'

export const getFilteredOrder = (state: IRootState) => state.filteredOrders.data;
export const getFilteredOrderLoading = (state: IRootState) => state.filteredOrders.loading;
export const getFilteredOrderHasError = (state: IRootState) => state.filteredOrders.error;