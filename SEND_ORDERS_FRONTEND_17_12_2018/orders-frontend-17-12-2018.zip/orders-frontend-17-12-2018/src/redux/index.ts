import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';
import { IOrderListState, OrderListActions, orderListReducer } from './order-list/reducer';
import { IFilteredOrderState, FilterOrderActions, filterOrderReducer } from './filterOrders/reducer';
import { IOrderDetailState, OrderDetailActions, orderDetailReducer } from './order-detail/reducer';
import { IOrderArticlesState, GetOrderArtictlesActions, getOrderArticlesReducer } from './order-articles/reducer';

export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    orderList: IOrderListState;
    filteredOrders: IFilteredOrderState;
    orderDetail: IOrderDetailState;
    orderArticles: IOrderArticlesState;
}

export type RootAction = RouterAction
    | LocationChangeAction
    | OrderListActions
    | FilterOrderActions 
    | OrderDetailActions
    | GetOrderArtictlesActions

export const reducers = combineReducers<IRootState>({
    router: routerReducer,
    i18n: i18nReducer, 
    orderList: orderListReducer,
    filteredOrders: filterOrderReducer,
    orderDetail: orderDetailReducer,
    orderArticles: getOrderArticlesReducer
});