declare module 'react-editable-label';
