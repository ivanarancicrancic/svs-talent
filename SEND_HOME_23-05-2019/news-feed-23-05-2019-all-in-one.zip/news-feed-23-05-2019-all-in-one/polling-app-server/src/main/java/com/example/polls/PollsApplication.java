package com.example.polls;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.convert.threeten.Jsr310JpaConverters;

import javax.annotation.PostConstruct;
import java.util.TimeZone;
import com.chilkatsoft.*;

@SpringBootApplication
@EntityScan(basePackageClasses = {
		PollsApplication.class,
		Jsr310JpaConverters.class
})
public class PollsApplication {

	@PostConstruct
	void init() {
		TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
	}

	public static void main(String[] args) {


		CkRss rss = new CkRss();

		// Download from the feed URL:
		boolean success = rss.DownloadRss("http://www.nytimes.com/services/xml/rss/nyt/HomePage.xml");
		if (success != true) {
			System.out.println(rss.lastErrorText());
			return;
		}

		// Get the 1st channel.
		CkRss rssChannel = rss.GetChannel(0);
		if (rss.get_LastMethodSuccess() == false) {
			System.out.println("No channel found in RSS feed.");
			return;
		}

		// Display the various pieces of information about the channel:
		System.out.println("Title: " + rssChannel.getString("title"));
		System.out.println("Link: " + rssChannel.getString("link"));
		System.out.println("Description: " + rssChannel.getString("description"));

		// For each item in the channel, display the title, link,
		// publish date, and categories assigned to the post.
		int numItems = rssChannel.get_NumItems();
		int i;

		for (i = 0; i <= numItems - 1; i++) {
			CkRss rssItem = rssChannel.GetItem(i);

			System.out.println("----");
			System.out.println("Title: " + rssItem.getString("title"));
			System.out.println("Link: " + rssItem.getString("link"));
			System.out.println("pubDate: " + rssItem.getString("pubDate"));

			int numCategories = rssItem.GetCount("category");
			int j;
			if (numCategories > 0) {
				for (j = 0; j <= numCategories - 1; j++) {
					System.out.println("    category: " + rssItem.mGetString("category",j));
				}

			}

		}



		SpringApplication.run(PollsApplication.class, args);
	}
}
