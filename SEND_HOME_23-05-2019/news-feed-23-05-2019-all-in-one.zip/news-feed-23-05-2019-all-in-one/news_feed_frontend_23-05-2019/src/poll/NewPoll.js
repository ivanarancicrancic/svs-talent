import React, { Component } from 'react';
import { createPoll } from '../util/APIUtils';
import { POLL_NEWSFEED_MAX_LENGTH } from '../constants';
import './NewPoll.css';  
import { Form, Input, Button, notification } from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input

class NewPoll extends Component {
    constructor(props) {
        super(props);
        this.state = {
            newsfeed: {
                text: ''
            },
            choices: [{
                text: 'I find this info very useful'
            }, {
                text: 'I find this info not so useful'
            }],
            pollLength: {
                days: 1,
                hours: 0
            }
        };
      
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleNewsfeedChange = this.handleNewsfeedChange.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
    }


    handleSubmit(event) {
        event.preventDefault();
        const pollData = {
            question: this.state.newsfeed.text,
            choices: this.state.choices.map(choice => {
                return {text: choice.text} 
            }),
            pollLength: this.state.pollLength
        };

        createPoll(pollData)
        .then(response => {
            this.props.history.push("/");
        }).catch(error => {
            if(error.status === 401) {
                this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create poll.');    
            } else {
                notification.error({
                    message: 'Polling App',
                    description: error.message || 'Sorry! Something went wrong. Please try again!'
                });              
            }
        });
    }

    validateNewsfeed = (newsfeedText) => {
        if(newsfeedText.length === 0) {
            return {
                validateStatus: 'error',
                errorMsg: 'Please enter your news feed!'
            }
        } else if (newsfeedText.length > POLL_NEWSFEED_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `News feed is too long (Maximum ${POLL_NEWSFEED_MAX_LENGTH} characters allowed)`
            }    
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        }
    }

    handleNewsfeedChange(event) {
        const value = event.target.value;
        this.setState({
            newsfeed: {
                text: value,
                ...this.validateNewsfeed(value)
            }
        });
    }

    validateChoice = (choiceText) => {
     
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        
    }




    isFormInvalid() {
        if(this.state.newsfeed.validateStatus !== 'success') {
            return true;
        }
    

    }

    render() {
        const choiceViews = [];
        this.state.choices.forEach((choice, index) => {
            choiceViews.push(<PollChoice key='1' choice={choice} choiceNumber={index} />);
         
        });

        return (
            <div className="new-poll-container">
                <h1 className="page-title">Create your news feed</h1>
                <div className="new-poll-content">
                    <Form onSubmit={this.handleSubmit} className="create-poll-form">
                        <FormItem validateStatus={this.state.newsfeed.validateStatus}
                            help={this.state.newsfeed.errorMsg} className="poll-form-row">
                        <TextArea 
                            placeholder="Enter your info news here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "newsfeed"
                            value = {this.state.newsfeed.text}
                            onChange = {this.handleNewsfeedChange} />
                        </FormItem>
                        {choiceViews}
                    
                        <FormItem className="poll-form-row">
                            <Button type="primary" 
                                htmlType="submit" 
                                size="large" 
                                disabled={this.isFormInvalid()}
                                className="create-poll-form-button">Create News Feed</Button>
                        </FormItem>
                    </Form>
                </div>    
            </div>
        );
    }
}

function PollChoice(props) {
    return (
        <FormItem validateStatus={props.choice.validateStatus}
        help={props.choice.errorMsg} className="poll-form-row">
         
        </FormItem>
    );
}


export default NewPoll;