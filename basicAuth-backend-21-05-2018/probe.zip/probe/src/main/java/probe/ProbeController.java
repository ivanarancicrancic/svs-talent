package probe;

import com.google.gson.Gson;
import org.activiti.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
public class ProbeController {

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/start", method = RequestMethod.GET)
    public void startHireProcess() {
        System.out.println("Start!");
    }



}