package de.ersatzteil.ersatzteilhandel24api.service;

import de.ersatzteil.ersatzteilhandel24api.entity.product.Product;
import de.ersatzteil.ersatzteilhandel24api.repository.ProductRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class ProductService {
    private final ProductRepository productRepository;

    public ProductService(
            ProductRepository contentRepository
   ) {
        this.productRepository = contentRepository;
    }

    public Optional<Product> getById(long id) {
        return this.productRepository.findById(id);
    }

    public boolean deleteProduct(Product product) {
        this.productRepository.delete(product);
        return true;
    }

}
