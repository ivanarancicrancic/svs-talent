package de.ersatzteil.ersatzteilhandel24api.repository;

import de.ersatzteil.ersatzteilhandel24api.entity.product.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface ProductRepository extends JpaRepository<Product, Long> {
}
