package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.user.User;
import de.ersatzteil.ersatzteilhandel24api.model.response.CategoryOverviewModel;
import de.ersatzteil.ersatzteilhandel24api.model.response.UserModelForAdmin;
import de.ersatzteil.ersatzteilhandel24api.service.AdminService;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import de.ersatzteil.ersatzteilhandel24api.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.ersatzteil.ersatzteilhandel24api.service.CategoryService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/api")
public class AdminController {

    private final AdminService adminService;
    private final CategoryService categoryService;

    public AdminController(AdminService adminService, CategoryService categoryService) {
        this.adminService = adminService;
        this.categoryService = categoryService;
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/users", method = RequestMethod.GET)
    public List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/categories", method = RequestMethod.GET)
    public List<CategoryOverviewModel> listAllCategories() {
        return categoryService.findAllCategories().stream()
                .map(CategoryOverviewModel::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/categories/{userId}", method = RequestMethod.GET)
    public List<CategoryOverviewModel> listCategoriesForUser(@PathVariable long userId) {
        User user = adminService.getUserByID(userId).orElseThrow(NoSuchElementException::new);
        return categoryService.getCategoriesForUser(user).stream()
                .map(CategoryOverviewModel::new)
                .collect(Collectors.toList());
    }

}
