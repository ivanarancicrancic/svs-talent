package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.model.response.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class UserController {

    private final AuthenticationFacade authenticationFacade;

    public UserController(AuthenticationFacade authenticationFacade) {
        this.authenticationFacade = authenticationFacade;
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.USER_GET)
    public UserModel createAccount() {
        return new UserModel(authenticationFacade.getAuthenticatedUser());
    }
}
