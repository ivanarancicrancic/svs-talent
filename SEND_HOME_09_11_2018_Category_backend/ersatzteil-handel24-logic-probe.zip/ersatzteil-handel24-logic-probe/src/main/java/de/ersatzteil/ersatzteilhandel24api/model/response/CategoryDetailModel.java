package de.ersatzteil.ersatzteilhandel24api.model.response;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;
import de.ersatzteil.ersatzteilhandel24api.entity.product.*;

import java.util.List;

public class CategoryDetailModel {

    private long id;
    private String name;
    private String description;
    private List<ProductModel> products;
    private boolean temporary;

    private Long activePackageId;

    public CategoryDetailModel() {
    }

    private ProductModel productToModel(Product product) {
            return new ProductModel(product);
    }

    public CategoryDetailModel(Category category) {
        this.id = category.getId();
        this.name = category.getName();
        this.description = category.getDescription();

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<ProductModel> getProducts() {
        return products;
    }

    public void setProducts(List<ProductModel> products) {
        this.products = products;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    public Long getActivePackageId() {
        return activePackageId;
    }

    public void setActivePackageId(Long activePackageId) {
        this.activePackageId = activePackageId;
    }
}
