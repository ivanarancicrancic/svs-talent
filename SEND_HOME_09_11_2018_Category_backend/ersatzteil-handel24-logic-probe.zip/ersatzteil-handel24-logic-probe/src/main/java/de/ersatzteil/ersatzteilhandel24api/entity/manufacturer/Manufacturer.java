package de.ersatzteil.ersatzteilhandel24api.entity.manufacturer;

import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.entity.product.Product;
import javax.persistence.*;
import java.util.List;
import de.ersatzteil.ersatzteilhandel24api.entity.category.Category;

@Entity
@Table(name="manufacturers")
public class Manufacturer {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_manufacturer")
    private long id;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="manufacturer")
    private List<Product> products = new java.util.ArrayList<>();

    @ManyToMany(mappedBy = "manufacturers", fetch = javax.persistence.FetchType.EAGER)
    private java.util.Set<Category> categories;

    // getter & setter
    public Manufacturer(){}

    public Manufacturer(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long manufacturerId) {
        this.id = manufacturerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public java.util.List<de.ersatzteil.ersatzteilhandel24api.entity.product.Product> getProducts() {
        return products;
    }

    public void setProducts(java.util.List<de.ersatzteil.ersatzteilhandel24api.entity.product.Product> products) {
        this.products = products;
    }
}
