package de.ersatzteil.ersatzteilhandel24api.repository;

import de.ersatzteil.ersatzteilhandel24api.entity.product.CategoryImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryImageRepository extends JpaRepository<CategoryImage, Long> {
}
