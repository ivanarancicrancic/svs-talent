package de.ersatzteil.ersatzteilhandel24api.security;

public final class BuiltInRights {

    public static final String CATEGORY_CREATE = "CATEGORY_CREATE";
    public static final String CATEGORY_LIST = "CATEGORY_LIST";
    public static final String CATEGORY_EDIT = "CATEGORY_EDIT";
    public static final String CATEGORY_GET = "CATEGORY_GET";
    public static final String PRODUCT_CREATE = "PRODUCT_CREATE";
    public static final String PRODUCT_EDIT = "PRODUCT_EDIT";
    public static final String PRODUCT_DELETE = "PRODUCT_DELETE";
    public static final String IMAGE_DELETE = "IMAGE_DELETE";
    public static final String IMAGE_CREATE = "IMAGE_CREATE";
    public static final String USER_GET = "USER_GET";
    public static final String ADMIN_RIGHT = "ADMIN_RIGHT";

    private BuiltInRights() {
    }

}
