package de.ersatzteil.ersatzteilhandel24api.entity.product;

import de.ersatzteil.ersatzteilhandel24api.entity.category.Category;
import javax.persistence.*;
import de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer;

@Entity
@Table(name="products")
public class Product {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_product")
    private long id;

    @Column(name="name", nullable = false)
    private String name;

    @Column(name="description", nullable = false)
    private String description;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="fk_categories", nullable = false)
    private Category category;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="fk_manufacturer", nullable = false)
    private Manufacturer manufacturer;

    // getter & setter
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer manufacturer) {
        this.manufacturer = manufacturer;
    }
}
