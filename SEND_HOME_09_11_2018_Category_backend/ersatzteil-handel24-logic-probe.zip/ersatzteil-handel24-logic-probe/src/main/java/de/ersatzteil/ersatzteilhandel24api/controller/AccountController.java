package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.model.request.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {

    private final UserService userService;

    public AccountController(UserService userService) {
        this.userService = userService;
       }

    public ResponseEntity createAccount(@RequestBody CreateAccountModel model) {
            userService.create(model);
            return new ResponseEntity(HttpStatus.OK);
    }

}
