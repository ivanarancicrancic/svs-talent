package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.product.*;
import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.exceptions.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {

    private final AuthenticationFacade authenticationFacade;
    private final ProductService productService;
    private final CategoryService categoryService;

    public ProductController(AuthenticationFacade authenticationFacade, ProductService productService, CategoryService categoryService) {
        this.authenticationFacade = authenticationFacade;
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @DeleteMapping("/category/product/{productId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PRODUCT_DELETE)
    public boolean deleteProduct(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);

//        if(!product.getCategory().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }

        productService.deleteProduct(product);
        return true;
    }

}