package de.ersatzteil.ersatzteilhandel24api.entity.user;

import com.fasterxml.jackson.annotation.JsonIgnore;
import de.ersatzteil.ersatzteilhandel24api.entity.category.*;

import javax.persistence.*;
import java.util.*;
import java.util.stream.Collectors;

@Entity
@Table(name="users")
public class User {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_user")
    private long id;

    @Column(name="language", length = 2, nullable = false)
    private String language;

    @Column(name="active", nullable = false)
    private boolean active = false;

    @Column(name="email", nullable=false, unique=true)
    private String email;

    @Column(name="password", nullable = false)
    private String password;

    @Column(name="gender", nullable = false)
    private boolean gender;

    @Column(name="firstname", nullable = false)
    private String firstname;

    @Column(name="lastname", nullable = false)
    private String lastname;

    // TODO: additional fields

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_has_roles",
            joinColumns = { @JoinColumn(name = "fk_user") },
            inverseJoinColumns = { @JoinColumn(name = "fk_userrole") }
    )
    private Set<UserRole> roles = new HashSet<>();

    @OneToMany(mappedBy="user")
    private List<Category> categories = new LinkedList<>();

    public User() {
    }

    public User(long id) {
        this.id = id;
    }


    public boolean hasRight(String name) {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(Collection::stream)
                .anyMatch(x -> x.getName().equals(name));
    }

    public List<UserRight> getRights() {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    // Getter and Setter methods
    public Long getId() {
        return id;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return email;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getName() {
        return String.format("%s %s", firstname, lastname);
    }

    public Locale getPreferedLanguage() {
        Locale locale = null;
        if(this.language == null) {
            locale = Locale.GERMAN;
        } else {
            switch(this.language) {
                case "de":
                    locale = Locale.GERMAN;
                    break;
                case "en":
                    locale = Locale.ENGLISH;
                    break;
                default:
                    locale = Locale.GERMAN;
            }
        }

        return locale;
    }

    @JsonIgnore
    public Set<UserRole> getRoles() {
        return roles;
    }

    public void addRole(UserRole userRole) {
        this.roles.add(userRole);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public boolean getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public List<Category> getCategories() {
        return categories;
    }

    public void setCategories(List<Category> categories) {
        this.categories = categories;
    }


    @Override
    public boolean equals(Object o) {
        if( this == o ) {
            return true;
        }
        if( o == null || getClass() != o.getClass() ) {
            return false;
        }
        User user = (User) o;
        return id == user.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}