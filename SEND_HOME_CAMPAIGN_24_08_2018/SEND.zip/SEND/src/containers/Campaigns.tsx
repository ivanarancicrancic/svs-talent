import * as React from 'react'
import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedCampaigns} from '../redux/actions/localCampaignsActions'
import { IRealCampaign} from '../models/CampaignsModelHelper'
import { IRootState } from '../redux/index';
import './DashboardContainer/DashboardLayout.css';
import {Link} from "react-router-dom";
// import store from '../redux/store/store'

interface ICampaignsState {
    entry: string
     campaignsData?: IRealCampaign[],
     error?: any
}
interface ICampaignsProps {
    getAllCampaigns: any
    editCampaignData: any,
    campaignsData: any
}

class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        this.state = {
            entry: ''
            //  campaignsData: [],
            //  error: false
        }
    }

    public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
        // this.setState({campaignsData: realCampaignData.campaigns})
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)

            this.editCampaign(event)
        }
    }

  public render() {
        return (
            <div>
                <div>
                    {/* <span>FORM</span> */}
                    <br />
                    <input 
                        type='text' 
                        placeholder='ENTRY'
                        onChange={ e => this.handleAddress(e) }
                        onKeyPress={ e => this.handleKeyPress(e) }
                    />
                    <button
                        onClick={ e => this.editCampaign(e) }
                    >
                    Submit for info
                    </button>
                </div>
               <div className="grid100">
                   
    <div className="grid50">
                    <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
                        <thead>
                            <tr>
                            <th>Campaign ID<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th >User fullname<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th>Contact</th>
                            <th>Tracker image </th>      
                            </tr>
                        </thead>
                        <tbody >
                        {
                  this.props.campaignsData.map((campaign: IRealCampaign) =>
                   
                    <tr key={campaign.id}>
                      <td>{campaign.id}</td> 
                      <td>  {campaign.user.firstname}    {campaign.user.lastname} {campaign.user.language} </td>
                      <td>{campaign.contact.email}</td>
                      <td> <img src={campaign.tracker[campaign.tracker.length - 1].url} /></td>
                            <td><Link to="/dashboard/edit" className="bp3-button bp3-icon-edit bp3-minimal" /></td>
                           
                    </tr>
                  )
                    }
                     <tr>
                            <td colSpan={5} className="text-center" >
                                <a className="bp3-button bp3-icon-add bp3-minimal"/>
                            </td>
                            </tr>
                        </tbody>
                    </table>
                </div>



                    </div>
            </div>
        )
    }


    public componentDidMount() {
        this.props.getAllCampaigns();
    }

    public componentWillReceiveProps(newProps: ICampaignsProps) {

        this.setState({
            ...newProps.campaignsData
        })
        console.log(this.state)
    }
}


const mapStateToProps = (state: IRootState) => {
    return {
        // ...state
        campaignsData: state.allCampaign.realCampaigns,
        error: state.allCampaign.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllCampaigns: () => dispatch(getListedCampaigns()),
        editCampaignData: (entry: number) => dispatch(editAndGetCampaigns(entry))
        
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)
