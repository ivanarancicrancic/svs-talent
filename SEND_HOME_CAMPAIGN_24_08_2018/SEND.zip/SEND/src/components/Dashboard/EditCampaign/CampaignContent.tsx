import * as React from 'react';
import './CampaignContent.css';

export default class CampaignContent extends React.Component {

    public render() {
        return (
            <div className="grid100 campaignBox">
                <table className="grid100 table bp3-html-table bp3-html-table-bordered bp3-interactive">
                    <tbody >
                        <tr>
                        <td> <button className="circle"> <span className="bp3-icon-standard bp3-icon-media" /> </button> Slideshow
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td> <button className="circle"> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button> Audio
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td> 
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button> Movie
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>    
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td> 
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-box" /> </button> Slideshow
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td colSpan={2}> 
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-media" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-box" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }

}
