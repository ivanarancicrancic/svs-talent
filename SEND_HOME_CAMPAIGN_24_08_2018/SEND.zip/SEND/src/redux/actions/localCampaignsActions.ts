import { HANDLE_GET_ALL_CAMPAIGNS, HANDLE_SET_CAMPAIGNS, HANDLE_FETCH_CAMPAIGNS_FAILED, HANDLE_FETCH_CONTENTS_FAILED, HANDLE_FETCH_TRACKERS_FAILED, HANDLE_SET_CONTENTS, HANDLE_SET_TRACKERS} from './actionTypes'
import { getFromBackend, postToBackend } from '../../api/api'
import { IRealCampaign, IContent, ITracker} from '../../models/CampaignsModelHelper';

interface ICampaignAction<Action> {
    type: string
    payload?: any
}

interface ITrackerAction {
    type: string
    payload?: any
}

interface IRealCampaignData {
    "campaigns": IRealCampaign[] 
}

const realCampaignData:IRealCampaignData = {
    "campaigns": []
}

const setCampaigns = (campaigns: IRealCampaign[]) => {
    return {
      type: HANDLE_SET_CAMPAIGNS,
      payload: campaigns
    }

}

const setContents = (contents: IContent[]) => {
    return {
      type: HANDLE_SET_CONTENTS,
      payload: contents
    }
}

const setTrackers = (tracker: ITracker[]) => {
    return {
      type: HANDLE_SET_TRACKERS,
      payload: tracker
    }
}

/* tslint:disable:no-string-literal */
const getListedCampaigns = () => {
    const url: string = '/testCampaigns'
   console.log("ENTERED getListedCampaigns!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:IRealCampaign[]) => {
              
                 dispatch(setCampaigns(response)); 
            }).catch((error:any) => {
                  dispatch(campaignDataFaied(error))
            })
    }
}

const getListedContents = () => {
    const url: string = '/campaign/1/audios'
   console.log("ENTERED getListedContents!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:IContent[]) => {
              
                 dispatch(setContents(response)); 
            }).catch((error:any) => {
                  dispatch(contentsDataFaied(error))
            })
    }
}


const getListedTrackers = () => {
    const url: string = '/campaign/1/trackers'
   console.log("ENTERED getListedTrackers!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:ITracker[]) => {
              
                 dispatch(setTrackers(response)); 
            }).catch((error:any) => {
                  dispatch(trackersDataFaied(error))
            })
    }
}
/* tslint:enable:no-string-literal */


const getEditedCampaigns = (repResponseData: any, dispatch: any) => {
    const url: string = '/testCampaigns'

    return getFromBackend(url).then(response => {
        dispatch(addressDataSuccess(response.data))
    }).catch(error => {
          dispatch(campaignDataFaied(error))
    })
}

/* tslint:disable:no-string-literal */
const editAndGetCampaigns = (name: number) => {
    const url: string = '/campaign/update'
    const data = {
        'id': name
    }
    return (dispatch :any, getState:any) => {  
            return postToBackend(url, data).then( (response:IRealCampaign) => {
                const repData = {
                    edited_campaign: response              
                }
                 getEditedCampaigns(repData, dispatch) 
            }).catch((error:any) => {
                  dispatch(campaignDataFaied(error))
            })
    }
}
/* tslint:enable:no-string-literal */

const addressDataSuccess = (addressData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: addressData
    }
}

const campaignDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_CAMPAIGNS_FAILED,
        payload: error
    }
}

const trackersDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_TRACKERS_FAILED,
        payload: error
    }
}


const contentsDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_CONTENTS_FAILED,
        payload: error
    }
}



export {
    editAndGetCampaigns, ICampaignAction, realCampaignData, getListedCampaigns, getListedContents, getListedTrackers, ITrackerAction
}