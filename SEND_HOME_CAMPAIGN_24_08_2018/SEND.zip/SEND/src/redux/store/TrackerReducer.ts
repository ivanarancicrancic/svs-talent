// import { Action } from 'redux'
import { ITrackerAction } from '../actions/localCampaignsActions'
import { HANDLE_SET_TRACKERS, HANDLE_FETCH_TRACKERS_FAILED, HANDLE_GET_ALL_TRACKERS } from '../actions/actionTypes'
import { ITracker } from '../../models/CampaignsModelHelper'

export interface ITrackersData {
    trackers: ITracker[],
    error: boolean

}

const INITIAL_STATE: ITrackersData = {
    trackers: [],
    error: false
}

export function trackerReducer(state: ITrackersData = INITIAL_STATE, action: ITrackerAction): ITrackersData {
    switch(action.type) {
        case HANDLE_GET_ALL_TRACKERS:
            return {
                ...action.payload
            };
        case HANDLE_SET_TRACKERS:
        console.log("CALLLED HANDLE_SET_TRACKERS");  
        return {
            ...state,
            trackers: action.payload,
            error:false
          }; 
      case HANDLE_FETCH_TRACKERS_FAILED:
          return {
            ...state,
            error: true
          }; 
          
        default:
            return state
    }
}
