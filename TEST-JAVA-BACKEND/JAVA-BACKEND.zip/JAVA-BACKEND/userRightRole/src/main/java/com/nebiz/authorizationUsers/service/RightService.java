package com.nebiz.authorizationUsers.service;

import com.nebiz.authorizationUsers.model.Rights;
import com.nebiz.authorizationUsers.model.RightsReturn;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface RightService {
    public List<RightsReturn> getAllRights();

    public List<RightsReturn> getRightsForRole(int id);

    public RightsReturn getRightByID(int id);

    public void createRight(RightsReturn right);
}
