package de.diefuturisten.easyr.easyrapi.controllers;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignListCommand;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import javassist.NotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class CampaignController {

    @Autowired
    CampaignService campaignService;

    public CampaignController(CampaignService campaignService) {
        this.campaignService = campaignService;
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
    public CampaignListCommand getCampaigns() throws Exception
    {
        System.out.println("Entered /campaigns");
        List<CampaignCommand> campaigns = null;
        String campaign_str = null;
        try{
            campaigns = campaignService.getAllCampaigns();
              CampaignListCommand campaignListCommand = new CampaignListCommand(campaigns);

            return campaignListCommand;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @GetMapping("/campaign/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    public CampaignCommand showById(@PathVariable String id) throws  Exception{
        System.out.println("entered campaign/show/{id}");
        try{
            CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
            return campaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PostMapping("/campaign/create")
    @ResponseStatus(HttpStatus.CREATED)
    public CampaignCommand createCampaign(@RequestBody CampaignCommand campaignCommand) throws Exception{
        System.out.println("BEFORE CREATING CAMPAIGN: " + campaignCommand.getTracker());
        try{
        CampaignCommand createdCampaignCommand = campaignService.createCampaign(campaignCommand);
        System.out.println("Id of campaign created:" + createdCampaignCommand.getId());
            return createdCampaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PutMapping("/campaign/update")
    @ResponseStatus(HttpStatus.OK)
    public CampaignCommand saveOrUpdate(@RequestBody CampaignCommand campaignCommand) throws  Exception{
        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID:" + campaignCommand.getId());
        CampaignCommand savedCampaignCommand = campaignService.updateCampaign(campaignCommand);
        System.out.println("Id of campaign updated:" + savedCampaignCommand.getId());
        System.out.println("Contents of campaign updated: ");
        for(Content campaignContent1 : savedCampaignCommand.getContents())
            System.out.println("Content: " +  campaignContent1.getName());
        try{
            return campaignCommand;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("campaign/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    public CampaignCommand deleteCampaign(@PathVariable String id){
        System.out.println("Entered deleting campaign");
        CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
        campaignService.deleteCampaign(Long.valueOf(id));
        return campaignCommand;

    }

}
