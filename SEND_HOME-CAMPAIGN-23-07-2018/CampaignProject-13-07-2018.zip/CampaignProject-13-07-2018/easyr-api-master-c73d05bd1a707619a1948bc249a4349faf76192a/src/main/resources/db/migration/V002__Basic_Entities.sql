create table if not exists contactinfos
(
	key_contactinfo bigserial not null
		constraint contactinfos_pkey
			primary key,
	address varchar(255),
	address2 varchar(255),
	city varchar(255),
	company varchar(255),
	email varchar(255),
	homepage varchar(255),
	name varchar(255),
	number varchar(255),
	zip varchar(255)
);

create table if not exists userrights
(
	key_userright bigserial not null
		constraint userrights_pkey
			primary key,
	description varchar(245),
	name varchar(45)
);

create table if not exists userroles
(
	key_userrole bigserial not null
		constraint userroles_pkey
			primary key,
	description varchar(245),
	name varchar(45)
);

create table if not exists role_has_rights
(
	fk_userrole bigint not null
		constraint fksild0wf8nh8pglno33yb372sy
			references userroles,
	fk_userright bigint not null
		constraint fk25qqx2ys3kprig37tdkdvsji3
			references userrights,
	constraint role_has_rights_pkey
		primary key (fk_userrole, fk_userright)
);

create table if not exists users
(
	key_user bigserial not null
		constraint users_pkey
			primary key,
	active boolean not null,
	email varchar(255) not null
		constraint uk_6dotkott2kjsp8vw4d0m25fb7
			unique,
	firstname varchar(255) not null,
	gender boolean not null,
	language varchar(2) not null,
	lastname varchar(255) not null,
	password varchar(255) not null
);

create table if not exists campaigns
(
	key_campaign bigserial not null
		constraint campaigns_pkey
			primary key,
	fk_contact bigint
		constraint fkr61qqo2uywsg0ot73d7dfcxhm
			references contactinfos,
	fk_user bigint not null
		constraint fk524y3k4qy05h4avtlffuurpcm
			references users
);

create table if not exists content
(
	key_content bigserial not null
		constraint content_pkey
			primary key,
	name varchar(255) not null,
	weight integer not null,
	fk_campaign bigint not null
		constraint fk6cvqjb1lg7e9sh8ve73www6yu
			references campaigns
);

create table if not exists content_3dmodels
(
	android_url varchar(255),
	extended_tracking boolean not null,
	ios_url varchar(255),
	position_x real not null,
	position_y real not null,
	position_z real not null,
	render_on_tracking_lost boolean not null,
	rotation_x real not null,
	rotation_y real not null,
	rotation_z real not null,
	scale_x real not null,
	scale_y real not null,
	scale_z real not null,
	key_content bigint not null
		constraint content_3dmodels_pkey
			primary key
		constraint fkdyu3t78j2hnx6bmex2w0ue1lw
			references content
);

create table if not exists content_audios
(
	render_on_tracking_lost boolean not null,
	url varchar(255) not null,
	key_content bigint not null
		constraint content_audios_pkey
			primary key
		constraint fki1eto2oviqdclg3b8pw0gv7hn
			references content
);

create table if not exists content_movies
(
	download boolean not null,
	extended_tracking boolean not null,
	position_x real not null,
	position_y real not null,
	position_z real not null,
	render_on_tracking_lost boolean not null,
	rotation_x real not null,
	rotation_y real not null,
	rotation_z real not null,
	scale_x real not null,
	scale_y real not null,
	scale_z real not null,
	seekbar boolean not null,
	type varchar(255) not null,
	url varchar(255) not null,
	key_content bigint not null
		constraint content_movies_pkey
			primary key
		constraint fkat3678xp32pqyww6hudj5l5mf
			references content
);

create table if not exists content_panoramas
(
	type varchar(255) not null,
	url varchar(255) not null,
	key_content bigint not null
		constraint content_panoramas_pkey
			primary key
		constraint fk1reoky1s187m8jphg60pxa5gx
			references content
);

create table if not exists content_slideshows
(
	extended_tracking boolean not null,
	position_x real not null,
	position_y real not null,
	position_z real not null,
	render_on_tracking_lost boolean not null,
	rotation_x real not null,
	rotation_y real not null,
	rotation_z real not null,
	scale_x real not null,
	scale_y real not null,
	scale_z real not null,
	key_content bigint not null
		constraint content_slideshows_pkey
			primary key
		constraint fkgf0m2fulcwdu89n6n21siu48n
			references content
);

create table if not exists content_spheres
(
	url varchar(255) not null,
	key_content bigint not null
		constraint content_spheres_pkey
			primary key
		constraint fkrw1mxsmaphn8bce3svpomj7df
			references content
);

create table if not exists content_webviews
(
	url varchar(255) not null,
	key_content bigint not null
		constraint content_webviews_pkey
			primary key
		constraint fkptsym3f50swkjclnrtqkj9ant
			references content
);

create table if not exists reset_password_tokens
(
	key_token bigserial not null
		constraint reset_password_tokens_pkey
			primary key,
	expires timestamp not null,
	token varchar(255) not null,
	fk_user bigint not null
		constraint fkqawo8fhyalurj08wdti3p3rxn
			references users
);

create table if not exists slideshow_images
(
	key_slideshowimage bigserial not null
		constraint slideshow_images_pkey
			primary key,
	weight integer not null,
	key_content bigint not null
		constraint fkiw45w4sndlaaqf41k80m2oxjc
			references content_slideshows
);

create table if not exists trackers
(
	key_tracker bigserial not null
		constraint trackers_pkey
			primary key,
	url varchar(255) not null,
	vuforia_id varchar(255) not null,
	fk_campaign bigint not null
		constraint fkc807c7u5oxcrqkd1cqo59dmi5
			references campaigns
);

create table if not exists user_has_roles
(
	fk_user bigint not null
		constraint fk6gxg60sqvx38uexpnc4cgk99c
			references users,
	fk_userrole bigint not null
		constraint fksymyxbnkby56lpk1m569m8uxv
			references userroles,
	constraint user_has_roles_pkey
		primary key (fk_user, fk_userrole)
);