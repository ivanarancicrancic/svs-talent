package de.ersatzteil.ersatzteilhandel24api.model;

import java.sql.Date;

public class Order {

    private int odrerId ;
    private String AdditionalInnfo;
    private Date Created ;

    public Order(){}

    public Order(int odrerId, String additionalInnfo, Date created) {
        this.odrerId = odrerId;
        AdditionalInnfo = additionalInnfo;
        Created = created;
    }

    public int getOdrerId() {
        return odrerId;
    }

    public void setOdrerId(int odrerId) {
        this.odrerId = odrerId;
    }

    public String getAdditionalInnfo() {
        return AdditionalInnfo;
    }

    public void setAdditionalInnfo(String additionalInnfo) {
        AdditionalInnfo = additionalInnfo;
    }

    public Date getCreated() {
        return Created;
    }

    public void setCreated(Date created) {
        Created = created;
    }
}
