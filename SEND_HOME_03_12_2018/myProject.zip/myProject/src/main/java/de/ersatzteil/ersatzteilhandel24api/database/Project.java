package de.ersatzteil.ersatzteilhandel24api.database;

import de.ersatzteil.ersatzteilhandel24api.model.Order;

import javax.ws.rs.WebApplicationException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Project {

    public Integer NVL(Integer a){
        if (a==null)
        {
            return 0;
        }
        else
        {
            return a;
        }
    }


    public List<Order> getOrderList(Connection connection) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("CALL ORDERLIST()");
            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next())
            {
                Order order = new Order(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getDate(3)
                );
                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                throw new WebApplicationException(404);
            }
            else
            {
                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public Order insertOrder(Connection connection, Order order) throws Exception
    {
        PreparedStatement ps=null;
        Order result=new Order();

        try
        {
            ps =connection.prepareStatement("call InsertOrder(?,?)", java.sql.Statement.RETURN_GENERATED_KEYS);
            ps.setString(1,order.getAdditionalInnfo());
            ps.setDate(2,order.getCreated());
            ResultSet rs = ps.executeQuery();
            return order;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

        finally {
            ps.close();
            connection.close();
        }
    }


}
