package de.ersatzteil.ersatzteilhandel24api.webService;

import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

//import javax.ws.rs.GET;
//import javax.ws.rs.Path;
//import javax.ws.rs.Produces;
//import java.util.List;
//
//@Path("/api")
public class OrderService {
//
//    @GET
//    @Path("/orders")
//    @Produces("application/json")
//    public List<Order> GetOrders() throws Exception
//    {
//        System.out.println("init");
//        List<Order> order_items = null;
//
//        try{
//            ProjectManager projectManager= new ProjectManager();
//
//            order_items = projectManager.getOrderList();
//            return order_items;
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }

}
