import * as React from 'react';

export default class ProductContent extends React.Component {

    public render() {
        return (
            <pre>
                <div>
                        <label>
                           Product
                        </label>
                 </div>        
            </pre>
        )
    }
}