

export const minLength3 = (val:string) => val.length >= 3;

export const minLength5 = (val:string) => val.length >= 5;

export const maxLength5 = (val:string) => val.length <= 5;

export const maxLength50 = (val:string) => val.length <= 50;

export const maxLength100 = (val:string) => val.length <= 100;

export const maxLength200 = (val:string) => val.length <= 200;

export const isEmail = (value:any) =>
    value && /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value);