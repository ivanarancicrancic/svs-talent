import * as React from 'react';
import {Control, Errors, actions as formActions, Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import {Icon} from '@blueprintjs/core';

import './LoginForm.css';
import {Link} from "react-router-dom";
import {PATH_FORGOT_PASSWORD_REQUEST, PATH_REGISTER} from "../../../router/paths";
import {maxLength50} from "../validator";
import { connect } from 'react-redux';
import { IRootState } from '../../../redux';

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
    formActions: typeof formActions;
}

class LoginForm extends React.Component<IProps> {

    private formDispatch?: any;

    public componentWillUnmount(){
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.login'));
        }
    }

    public render() {
        return (
            <div>
                <div className="loginBox">
                    <Form
                        model="forms.login"
                        onSubmit={(values) => this.props.onSubmit(values)}
                        getDispatch={(dispatch: any) => this.formDispatch = dispatch}
                    >
                            <div className="userIcon">
                                <Icon icon="user" iconSize={60}/>
                            </div>
                            <div className="bp3-input-group">
                                <Control
                                    model=".username"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton",
                                        placeholder: "E-Mail"
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".username"
                                    show="touched"
                                    messages={{
                                        required:'This field is required',
                                        maxLength50: 'Email is too long'
                                    }}
                                />
                            </div>
                            <div className="bp3-input-group">
                                <Control
                                    model=".password"
                                    validators={{
                                        required: (val) => val && val.length,
                                        /* minLength5, */
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        type: "password",
                                        placeholder: "Passwort"
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".password"
                                    show="touched"
                                    messages={{
                                        required:'This field is required',
                                        maxLength50: 'Password is too long'
                                    }}
                                />
                                <div className="loginBtn">
                                    <button className="logIn">
                                        Anmelden
                                    </button>
                                </div>
                                <div className="inputButton" />
                                <div className="forgotPass">
                                    <Link to={PATH_FORGOT_PASSWORD_REQUEST} > Password vergessen? </Link>
                                </div>
                            </div>
                    </Form>
                </div>

                <div className="signUp">
                    <div> <span> Du hast noch kein Konto? </span> </div>
                    <div> <Link to={PATH_REGISTER} role="button"> Registriere Dich hier! </Link> </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
    form: state.forms.forms.login
});

const actions = {
    formActions
};

export default connect(mapStateToProps, actions)(LoginForm);