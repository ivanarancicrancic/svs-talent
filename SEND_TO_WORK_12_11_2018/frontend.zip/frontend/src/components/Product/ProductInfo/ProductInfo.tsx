import * as React from 'react';
import './ProductInfo.css';
import {  searchProductByArtileNumberFetch } from '../../../redux/product/actions';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct } from '../../../redux/product/selectors';
import { RouteComponentProps } from 'react-router';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';

interface IPropsDispatchMap {
    searchProductByArtileNumberFetch: typeof searchProductByArtileNumberFetch;

}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
}


type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{id: number}>

 class ProductInfo  extends React.Component<IProps> {

    public componentWillMount() {
        const id = this.props.match.params.id;
        this.props.searchProductByArtileNumberFetch({id});
      }


    public render() {
        if(this.props.productData == null) {
            return null;
        }

        return (
            <div className="infoBox">
                <h2> Product </h2>
                <p> This is product part for.... </p>
                <b>{this.props.productData.name} PRoductt details</b>
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state)
});

export default connect(mapStateToProps, {searchProductByArtileNumberFetch})(ProductInfo)