import * as React from 'react';

import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import { loginUserFetch } from '../../redux/auth/actions';
import { RouteComponentProps } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import {  PATH_DASHBOARD } from '../../router/paths';
import LoginForm from '../../components/Forms/Login/LoginForm';
import { ILoginFormData } from '../../redux/forms';


interface IPropsDispatchMap {
    loginUserFetch: typeof loginUserFetch;
}
interface IPropsStateMap {
    auth: IAuthState
}

type IProps = IPropsStateMap & IPropsDispatchMap & RouteComponentProps<{}>

class LoginContainer extends React.Component<IProps, any> {

    public componentWillReceiveProps(nextProps: IProps) {
        // auth token becomes available, so "redirect" to dashboard view
        if(this.props.auth.token == null && nextProps.auth.token != null) {
            this.props.history.replace(PATH_DASHBOARD);
        }
    }

    public onSubmitLoginForm = (values: ILoginFormData)  => {
        this.props.loginUserFetch(values);
    }

    public render() {
        return (
            <div>
                <LoginForm onSubmit={this.onSubmitLoginForm} />
            </div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

export default connect(mapStateToProps, {loginUserFetch})(LoginContainer)