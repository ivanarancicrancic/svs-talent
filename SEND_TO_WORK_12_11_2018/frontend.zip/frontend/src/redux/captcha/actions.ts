import { CAPTCHA_FETCH, CAPTCHA_FAIL, CAPTCHA_SUCCESS, ICaptchaResponseModel } from './types';

import { createStandardAction } from 'typesafe-actions';

export const captchaFetch = createStandardAction(CAPTCHA_FETCH)();
export const captchaSuccess = createStandardAction(CAPTCHA_SUCCESS)<ICaptchaResponseModel>();
export const captchaFail = createStandardAction(CAPTCHA_FAIL)<string>();