import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';

import { ICaptchaState, CaptchaActions, captchaReducer } from './captcha/reducer';
import { IAuthState, AuthActions, authReducer } from './auth/reducer';
import { ICategoryListState, CategoryListActions, categoryListReducer } from './category-list/reducer';
import { IProductListState, ProductListActions, productListReducer } from './product-list/reducer';
import { IManufacturerListState, ManufacturerListActions, manufacturerListReducer } from './manufacturer-list/reducer';
import { IUserSelfInfoState, UserSelfInfoActions, userSelfInfoReducer } from './user-self-info/reducer';
import { IRegistrationState, RegistrationActions, registerReducer } from './register/reducer';
import { IForgotPasswordState, ForgotPasswordActions, forgotPasswordReducer } from './forgot-password/reducer';
import { ICategoryDetailState, CategoryDetailActions, categoryDetailReducer } from './category/reducer';
import { IProductByArticleNumberState, ProductDetailActions, searchProductByArtileNumberReducer } from './product/reducer';
import { IManufacturerDetailState, ManufacturerDetailActions, manufacturerDetailReducer } from './manufacturer/reducer';
import { IUIState, UIActions, uiReducer } from './ui/reducer';
import { IMessageState, MessageActions, messageReducer } from './messages/reducer';

import { formsReducer } from './forms';
export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    ui: IUIState;
    messages: IMessageState;
    captcha: ICaptchaState;
    auth: IAuthState;
    categoryList: ICategoryListState;
    productList: IProductListState;
    manufacturerList: IManufacturerListState;
    category: ICategoryDetailState;
    product: IProductByArticleNumberState;
    manufacturer: IManufacturerDetailState;
    userSelfInfo: IUserSelfInfoState;
    register: IRegistrationState;
    forgotPassword: IForgotPasswordState;
    forms: any;

}

export type RootAction = RouterAction
    | LocationChangeAction
    | AuthActions
    | CategoryListActions
    | ProductListActions
    | ManufacturerListActions
    | CategoryDetailActions
    | ProductDetailActions
    | ManufacturerDetailActions
    | UserSelfInfoActions
    | RegistrationActions
    | CaptchaActions
    | ForgotPasswordActions
    | UIActions
    | MessageActions;


export const reducers = combineReducers<IRootState>({
    router: routerReducer,
    i18n: i18nReducer,
    ui: uiReducer,
    messages: messageReducer,
    captcha: captchaReducer,
    auth: authReducer,
    categoryList: categoryListReducer,
    productList: productListReducer,
    manufacturerList: manufacturerListReducer,
    category: categoryDetailReducer,
    product: searchProductByArtileNumberReducer,
    manufacturer: manufacturerDetailReducer,
    userSelfInfo: userSelfInfoReducer,
    register: registerReducer,
    forgotPassword: forgotPasswordReducer,
    forms: formsReducer
});