import {
    PRODUCT_DETAIL_FETCH,
    PRODUCT_DETAIL_SUCCESS,
    PRODUCT_DETAIL_FAIL,
    
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH,
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_SUCCESS,
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FAIL,

    PRODUCT_CREATE_FETCH,
    PRODUCT_CREATE_SUCCESS,
    PRODUCT_CREATE_FAIL,

    PRODUCT_SAVE_FETCH,
    PRODUCT_SAVE_SUCCESS,
    PRODUCT_SAVE_FAIL,

    PRODUCT_EDIT_FETCH,
    PRODUCT_EDIT_SUCCESS,
    PRODUCT_EDIT_FAIL,

    PRODUCTPART_DELETE_FETCH,
    PRODUCTPART_DELETE_SUCCESS,
    PRODUCTPART_DELETE_FAIL,

    PRODUCTPART_CREATE_FETCH,
    PRODUCTPART_CREATE_SUCCESS,
    PRODUCTPART_CREATE_FAIL,

    PRODUCTPART_EDIT_FETCH,
    PRODUCTPART_EDIT_SUCCESS,
    PRODUCTPART_EDIT_FAIL,
     
    IProductDetailResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IProductRequestModel, IProductResponseModel, PRODUCTPART_RENAME_FETCH, PRODUCTPART_RENAME_SUCCESS, PRODUCTPART_RENAME_FAIL } from './types';


export const searchProductByArtileNumberFetch = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH)<{id: number}>();
export const searchProductByArtileNumberSuccess = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_SUCCESS)<IProductResponseModel>();
export const searchProductByArtileNumberFail = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FAIL)<string>();

export const productDetailFetch = createStandardAction(PRODUCT_DETAIL_FETCH)<{id: number}>();
export const productDetailSuccess = createStandardAction(PRODUCT_DETAIL_SUCCESS)<IProductDetailResponseModel>();
export const productDetailFail = createStandardAction(PRODUCT_DETAIL_FAIL)<string>();

export const productCreateFetch = createStandardAction(PRODUCT_CREATE_FETCH)();
export const productCreateSuccess = createStandardAction(PRODUCT_CREATE_SUCCESS)<IProductDetailResponseModel>();
export const productCreateFail = createStandardAction(PRODUCT_CREATE_FAIL)<string>();

export const productSaveFetch = createStandardAction(PRODUCT_SAVE_FETCH)<{productId: number, packageId: number}>();
export const productSaveSuccess = createStandardAction(PRODUCT_SAVE_SUCCESS)<IProductDetailResponseModel>();
export const productSaveFail = createStandardAction(PRODUCT_SAVE_FAIL)<string>();

export const productEditFetch = createStandardAction(PRODUCT_EDIT_FETCH)<{id: number, name: string}>();
export const productEditSuccess = createStandardAction(PRODUCT_EDIT_SUCCESS)<IProductDetailResponseModel>();
export const productEditFail = createStandardAction(PRODUCT_EDIT_FAIL)<string>();

export const productPartDeleteFetch = createStandardAction(PRODUCTPART_DELETE_FETCH)<{productId: number}>();
export const productPartDeleteSuccess = createStandardAction(PRODUCTPART_DELETE_SUCCESS)<{productId: number}>();
export const productPartDeleteFail = createStandardAction(PRODUCTPART_DELETE_FAIL)<string>();

export const productPartCreateFetch = createStandardAction(PRODUCTPART_CREATE_FETCH)<{categoryId: number, data: IProductRequestModel}>();
export const productPartCreateSuccess = createStandardAction(PRODUCTPART_CREATE_SUCCESS)<IProductResponseModel>();
export const productPartCreateFail = createStandardAction(PRODUCTPART_CREATE_FAIL)<string>();

export const productPartEditFetch = createStandardAction(PRODUCTPART_EDIT_FETCH)<{data: IProductRequestModel}>();
export const productPartEditSuccess = createStandardAction(PRODUCTPART_EDIT_SUCCESS)<IProductResponseModel>();
export const productPartEditFail = createStandardAction(PRODUCTPART_EDIT_FAIL)<string>();

export const productPartRenameFetch = createStandardAction(PRODUCTPART_RENAME_FETCH)<{productId: number, name: string}>();
export const productPartRenameSuccess = createStandardAction(PRODUCTPART_RENAME_SUCCESS)<IProductResponseModel>();
export const productPartRenameFail = createStandardAction(PRODUCTPART_RENAME_FAIL)<string>();