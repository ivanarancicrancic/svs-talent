export const PRODUCT_DETAIL_FETCH = '@@user/product/detail/FETCH';
export const PRODUCT_DETAIL_SUCCESS = '@@user/product/detail/SUCCESS';
export const PRODUCT_DETAIL_FAIL = '@@user/product/detail/FAIL';

export const SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH = '@@user/product/byArticleNumer/FETCH';
export const SEARCH_PRODUCT_BY_ARTICLE_NUMBER_SUCCESS = '@@user/product/byArticleNumer/SUCESS';
export const SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FAIL = '@@user/product/byArticleNumer/FAIL';

export const PRODUCT_CREATE_FETCH = '@@product/create/FETCH';
export const PRODUCT_CREATE_SUCCESS = '@@product/create/SUCCESS';
export const PRODUCT_CREATE_FAIL = '@@product/create/FAIL';

export const PRODUCT_SAVE_FETCH = '@@product/save/FETCH';
export const PRODUCT_SAVE_SUCCESS = '@@product/save/SUCCESS';
export const PRODUCT_SAVE_FAIL = '@@product/save/FAIL';

export const PRODUCT_EDIT_FETCH = '@@product/edit/FETCH';
export const PRODUCT_EDIT_SUCCESS = '@@product/edit/SUCCESS';
export const PRODUCT_EDIT_FAIL = '@@product/edit/FAIL';

export const PRODUCT_UPLOAD_FETCH = '@@category/product/upload/FETCH';
export const PRODUCT_UPLOAD_SUCCESS = '@@category/product/upload/SUCCESS';
export const PRODUCT_UPLOAD_FAIL = '@@category/product/upload/FAIL';

export const PRODUCT_DELETE_FETCH = '@@category/product/delete/FETCH';
export const PRODUCT_DELETE_SUCCESS = '@@category/product/delete/SUCCESS';
export const PRODUCT_DELETE_FAIL = '@@category/product/delete/FAIL';

export const PRODUCTPART_DELETE_FETCH = '@@product/productPart/delete/FETCH';
export const PRODUCTPART_DELETE_SUCCESS = '@@product/productPart/delete/SUCCESS';
export const PRODUCTPART_DELETE_FAIL = '@@product/productPart/delete/FAIL';

export const PRODUCTPART_CREATE_FETCH = '@@product/productPart/create/FETCH';
export const PRODUCTPART_CREATE_SUCCESS = '@@product/productPart/create/SUCCESS';
export const PRODUCTPART_CREATE_FAIL = '@@product/productPart/create/FAIL';

export const PRODUCTPART_EDIT_FETCH = '@@product/productPart/edit/FETCH';
export const PRODUCTPART_EDIT_SUCCESS = '@@product/productPart/edit/SUCCESS';
export const PRODUCTPART_EDIT_FAIL = '@@product/productPart/edit/FAIL';

export const PRODUCTPART_RENAME_FETCH = '@@product/productPart/renamePart/FETCH';
export const PRODUCTPART_RENAME_SUCCESS = '@@product/productPart/rename/SUCCESS';
export const PRODUCTPART_RENAME_FAIL = '@@product/productPart/rename/FAIL';

// PRODUCT_PART
export interface IProductPartResponseModel {
    id: number;
    type: ProductType;
    weight: number;
    name: string;
    subType: ProductSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

// PRODUCT
type ProductType =  'KITCHEN';

export interface IProduct1ResponseModel {
    id: number;
    type: ProductType;
    name: string;
    weight: number;
}

export interface IProductResponseModel {
    id: number;
    name: string;
    description: string;
}

// PRODUCT TYPES
export type ProductSubtype = 'KITCHEN' | 'HOUSE';

interface IProductFields {
    subType: ProductSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IProductResponseModel extends IProduct1ResponseModel, IProductFields {}

export interface IProductRequestModel extends IProductFields {
    id?: number;
    name: string;
}


// CATEGORY
export interface IProductDetailResponseModel {
    id: number;
    name: string;
    description: string;
    productPart: IProductPartResponseModel[];
    products: IProductResponseModel[]
    temporary: boolean;
    activePackageId: number | null
};