import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IProductDetailResponseModel, IProductResponseModel } from './types';

export type ProductDetailActions = ActionType<typeof actions>;
export type ProductByArticleNumberActions = ActionType<typeof actions>;

export interface IProductDetailState {
    readonly data: IProductDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;

    readonly createLoading: boolean;
    readonly imageLoading: boolean;
    readonly contentLoading: boolean;

    readonly lastCreatedId: number | null;

    readonly saveLoading: boolean;
    readonly saveError: any | null;
};
  
const INITIAL_STATE: IProductDetailState = {
    data: null,
    loading: false,
    error: null,

    createLoading: false,
    imageLoading: false,
    contentLoading: false,

    lastCreatedId: null,

    saveLoading: false,
    saveError: null
};
  
export interface IProductByArticleNumberState {
    readonly data: IProductResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
      
     

};
  
const INITIAL_PRODUCT_BY_ARTICLE_STATE: IProductByArticleNumberState = {
    data: null,
    loading: false,
    error: null


  
};

export function searchProductByArtileNumberReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by article number
        case getType(actions.searchProductByArtileNumberFetch):
            return {...state, loading: true, error: null};
        case getType(actions.searchProductByArtileNumberSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.searchProductByArtileNumberFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}


export function productDetailReducer(state: IProductDetailState = INITIAL_STATE, action: ProductDetailActions): IProductDetailState  {
    switch (action.type) {

        // detail
        case getType(actions.productDetailFetch):
            return {...state, loading: true, error: null};
        case getType(actions.productDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.productDetailFail):
            return {...state, loading: false, error: action.payload};

        // create
        case getType(actions.productCreateFetch):
            return {...state, createLoading: true, error: null};
        case getType(actions.productCreateSuccess):
            return {...state, createLoading: false, error: null, lastCreatedId: action.payload.id};
        case getType(actions.productCreateFail):
            return {...state, createLoading: false, error: action.payload};

        // save
        case getType(actions.productSaveFetch):
            return {...state, saveLoading: true, saveError: null};
        case getType(actions.productSaveSuccess):
            return {...state, saveLoading: false, saveError: null, data: action.payload};
        case getType(actions.productSaveFail):
            return {...state, saveLoading: false, saveError: action.payload};


        // product delete
        case getType(actions.productPartDeleteFetch):
            return {...state, contentLoading: true};

        case getType(actions.productPartDeleteSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false}
            }

            const contentsAfterDelete = state.data.products.filter(x => x.id !== action.payload.productId);

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: contentsAfterDelete
                }
            }
        
        case getType(actions.productPartDeleteFetch):
            return {...state, contentLoading: false};

        // product create
        case getType(actions.productPartCreateFetch):
            return {...state, contentLoading: true};

        case getType(actions.productPartCreateSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: [
                        ...state.data.products,
                        action.payload
                    ]
                }
            };

        case getType(actions.productPartCreateFail):
            return {...state, contentLoading: false};


        // product edit
        case getType(actions.productPartEditFetch):
           return {...state, contentLoading: true};

        case getType(actions.productPartEditSuccess):
        case getType(actions.productPartRenameSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            const elementToUpdate = action.payload;
            const idxOfIdToUpdate = state.data.products.findIndex( x => x.id === elementToUpdate.id );

            if(idxOfIdToUpdate === -1) {
                return state;
            }

            const updatedProducts = [...state.data.products];
            updatedProducts[idxOfIdToUpdate] = action.payload;

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: updatedProducts
                }
            };

        case getType(actions.productEditFail):
            return {...state, contentLoading: false};

        default:
            return state;
    }
}