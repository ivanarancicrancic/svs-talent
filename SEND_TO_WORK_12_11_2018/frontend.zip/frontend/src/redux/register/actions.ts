import { REGISTER_FETCH, REGISTER_SUCCESS, REGISTER_FAIL } from './types';

import { createStandardAction } from 'typesafe-actions';
import { IRegisterFormData } from '../forms';

export const registerFetch = createStandardAction(REGISTER_FETCH)<IRegisterFormData>();
export const registerSuccess = createStandardAction(REGISTER_SUCCESS)();
export const registerFail = createStandardAction(REGISTER_FAIL)<string>();