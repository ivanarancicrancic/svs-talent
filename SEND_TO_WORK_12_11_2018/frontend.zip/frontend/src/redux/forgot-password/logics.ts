import { createLogic } from 'redux-logic';
import axios from 'axios';

import { FORGOT_PASSWORD_FETCH, RESET_PASSWORD_FETCH } from './types';
import { forgotPasswordSuccess, forgotPasswordFetch, forgotPasswordFail, resetPasswordFetch, resetPasswordSuccess, resetPasswordFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

interface IForgotPasswordRequestModel {
    email: string;
    captcha: {
        id: string;
        answer: string;
    }
};

interface IResetPasswordRequestModel {
    email: string;
    newPassword: string;
    token: string;
};

export const forgotPasswordFetchLogic = createLogic({
    type: FORGOT_PASSWORD_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(forgotPasswordFetch)(action)) {

            const state = getState() as IRootState;
            
            const formValues = action.payload;

            const requestModel: IForgotPasswordRequestModel = {
                email: formValues.email,
	            captcha: {
		            id: state.captcha.data && state.captcha.data.id || "",
		            answer: formValues.captcha
	            }
            }

            axios({
                method: 'post',
                url: API_ROOT + '/forgotpw',
                headers: {"Content-Type": "application/json"},
                data: JSON.stringify(requestModel)
            }).then(response => {
                dispatch(forgotPasswordSuccess());
            }).catch(error => {
                dispatch(forgotPasswordFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const resetPasswordFetchLogic = createLogic({
    type: RESET_PASSWORD_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(resetPasswordFetch)(action)) {
            
            const formValues = action.payload;

            const requestModel: IResetPasswordRequestModel = {
                email: formValues.email,
                token: formValues.token,
                newPassword: formValues.password
            }

            axios({
                method: 'post',
                url: API_ROOT + '/resetpw',
                headers: {"Content-Type": "application/json"},
                data: JSON.stringify(requestModel)
            }).then(response => {
                dispatch(resetPasswordSuccess());
            }).catch(error => {
                dispatch(resetPasswordFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    forgotPasswordFetchLogic,
    resetPasswordFetchLogic
];
