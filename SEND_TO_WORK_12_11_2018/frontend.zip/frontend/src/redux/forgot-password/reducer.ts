import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

export type ForgotPasswordActions = ActionType<typeof actions>;

export interface IForgotPasswordState {
    readonly forgotLoading: boolean;
    readonly resetLoading: boolean;
    readonly forgotError: string | null;
    readonly resetError: string | null;
};
  
const INITIAL_STATE: IForgotPasswordState = {
    forgotLoading: false,
    resetLoading: false,
    forgotError: null,
    resetError: null
};
  
export function forgotPasswordReducer(state: IForgotPasswordState = INITIAL_STATE, action: ForgotPasswordActions): IForgotPasswordState  {
    switch (action.type) {
        case getType(actions.forgotPasswordFetch):
            return {...state, forgotLoading: true, forgotError: null};
        case getType(actions.forgotPasswordSuccess):
            return {...state, forgotLoading: false, forgotError: null};
        case getType(actions.forgotPasswordFail):
            return {...state, forgotLoading: false, forgotError: action.payload};

        case getType(actions.forgotPasswordFetch):
            return {...state, resetLoading: true, resetError: null};
        case getType(actions.forgotPasswordSuccess):
            return {...state, resetLoading: false, resetError: null};
        case getType(actions.forgotPasswordFail):
            return {...state, resetLoading: false, resetError: action.payload};
        default:
            return state;
    }
}