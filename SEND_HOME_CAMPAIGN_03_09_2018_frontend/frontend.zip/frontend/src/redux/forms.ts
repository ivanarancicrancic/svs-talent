import { combineForms } from 'react-redux-form';

export interface ILoginFormData {
    username: string;
    password: string;
}

const loginForm: ILoginFormData = {
    username: '',
    password: ''
};

export interface IRegisterFormData {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    confirmPassword: string;
    phoneNumber: string;
    paymentFirstName: string;
    paymentLastName: string;
    companyName: string;
    streetAddress: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
};

const registerForm: IRegisterFormData = {
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    paymentFirstName: '',
    paymentLastName: '',
    companyName: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: ''
};

export const formsReducer = combineForms({
    login: loginForm,
    register: registerForm,
}, 'forms');