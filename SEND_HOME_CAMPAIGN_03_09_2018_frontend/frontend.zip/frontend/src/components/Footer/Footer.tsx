import * as React from 'react';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';

import { getUserIsLoggedIn } from '../../redux/auth/selectors';

import PreAuthFooter from './PreAuthFooter';
import PostAuthFooter from './PostAuthFooter';

import './Footer.css';

interface IPropsStateMap {
    isLoggedIn: boolean;
  }

type Props = IPropsStateMap;

class Footer extends React.Component<Props> {
    public render() {
        const { isLoggedIn } = this.props;
        return isLoggedIn ? <PostAuthFooter /> : <PreAuthFooter />
    }
}

const mapStateToProps = (state: IRootState) => ({
    isLoggedIn: getUserIsLoggedIn(state)
});

export default connect(mapStateToProps, {})(Footer)