import * as React from 'react';
import './TrackerImages.css';

import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedTrackers} from '../../../redux/actions/localCampaignsActions'
import { ITracker } from '../../../models/CampaignsModelHelper'
import { IRootState } from '../../../redux/index';
import { idCampaign } from '../../Dashboard/Campaigns';

// import {  FormGroup, Label, Input } from 'reactstrap';

import ReactDropzone from 'react-dropzone';
 import * as request from "superagent";

interface ICampaignInfosState {
    entry: string,
    tracker?: ITracker[],
     error?: any,
     deleted? : string,
     selected? : boolean,
     selectedUrl? : string,
     files? : any;

}
interface ICampaignInfosProps {
    getAllTrackers: any,
    editCampaignData: any,
    tracker: any
}

type IProps = ICampaignInfosProps

class TrackerImages extends React.Component<IProps, ICampaignInfosState> {
    constructor(props: IProps) {
        super(props)
        this.state = {
            entry: '',
            deleted: 'false',
            selected: false,
            selectedUrl: '',
            files: []
        }
    }

   public uploadFile(event: any) {
        event.preventDefault();
        const formData = new FormData();
        formData.append('file', event.target.myimage.files[0]);
        formData.append('tcknVkn', event.target.tcknVkn.value);
        formData.append('proclamationYear', event.target.proclamationYear.value);
        fetch('http://localhost:8080/api/campaign/' + idCampaign.id + '/tracker', {
            method: 'CREATE',
            credentials: 'include',
            headers: {
                'Content-Type': 'multipart/form-data',
                'Accept': 'application/json'
            },
            body: formData
        })
    }

    public deleteTracker(id:string) {
        this.setState({deleted: 'true'});
        this.props.editCampaignData(id);
        console.log(" STATE FOR DELETE" + this.state);    
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
        }
    }

    public postSelectedHandler = (id:string) => {
        console.log("Selected tracker! With id: " + id);
         this.setState({selected: true});
         this.setState({selectedUrl: id}) 
    }
  /* tslint:enable:no-string-literal */
    
  public onDrop = (files:any) => {
  const formData = new FormData();

    console.log("UPLOAD FILE BEFEORE BE CALLED" + JSON.stringify(files[0]));
    console.log("UPLOAD FILE NAME BEFEORE BE CALLED" + files[0].name);
    const file = new Blob([files[0]], { type: 'image/jpg' });

    formData.append('file', file);
      formData.append('filename', files[0].name);


request.post('http://localhost:8080/api/campaign/' + idCampaign.id + '/tracker')
.send(formData)
.end((err, resp) => {
  if (err) {
    console.error(err);
  }
  else {console.log(JSON.stringify(resp));}
  return resp;
});

}

public onPreviewDrop = (files: any) => {
        console.log("ENTERED onPreviewDrop");     
        // this.setState({
        //     files: this.state.files.concat(files),
        //     });
         this.onDrop(files);
}



    public render() {
        return (
            <div className="trackerBox">
            
                <div className="trackerLeft">
                    <div>
                    {
                  this.props.tracker.map((t: ITracker) =>
                  
                  <div key= {t.id}  onClick={() => this.postSelectedHandler(t.url)}>
                    <img src= {t.url} className="trackerImg" />
                    <img     
                                alt="Preview"
                                key={t.url}
                                src={t.url}
                                // style={previewStyle}
                                className="trackerImg" 
                                />

                    <button className="bp3-button bp3-minimal" onClick={() => this.deleteTracker(t.id) }> <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                  </div>
                  )
                    }
                </div>
                <div className="bp3-button bp3-minimal" >
                        <label className="bp3-file-input .modifier addImg">
                            <ReactDropzone
                                className="dropzone"
                                accept=".jpg, .png, image/*"
                                onDrop={this.onPreviewDrop}>
                            <span className="bp3-file-upload-input bp3-icon-standard bp3-icon-add" />
                            </ReactDropzone>
                        </label>
                    </div>



                {/* <div className="bp3-button bp3-minimal" >
                        <label className="bp3-file-input .modifier addImg">
                        <form className="uploader" encType="multipart/form-data" >
                         <br />
                    <FormGroup>
                        <Label for="proclamationYear">Beyanname Yılı</Label>
                        <Input type="text" name="proclamationYear" id="proclamationYear" placeholder="Beyanname Yılını Giriniz." onChange={this.proclamationYearChange} value={this.state.proclamationYear} />
                    </FormGroup>
                    <FormGroup>
                        <Label for="tcknVkn">Tckn/Vkn</Label>
                        <Input type="text" name="tcknVkn" id="tcknVkn" placeholder="Tckn/Vkn Giriniz." onChange={this.tcknVknChange} value={this.state.tcknVkn} />
                    </FormGroup>

                    <input  type="file" name="file" className="upload-file" onChange={this.fileChange} />
                    <input type="button"  value="Beyanname Yükle" onClick={this.uploadFile} />
                </form>
                        </label>
                    </div> */}

                </div>
                <div className="trackerRight">
                 
                <div> <img className="trackerMainImg" src= {this.state.selectedUrl} /> </div>
                 
                   <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                </div>
            </div>
        )
    }

    public componentDidMount() {
    //     if(idCampaign.create){
    //     this.props.getAllTrackers(idCampaign.id);
    // }
}

   public componentDidUpdate(){

        this.props.getAllTrackers(idCampaign.id);
   }

    public componentWillReceiveProps(newProps: ICampaignInfosProps) {
       
        if(idCampaign.create){
            this.props.getAllTrackers(idCampaign.id);}
        }
}

const mapStateToProps = (state: IRootState) => {
    return {
        tracker: state.allTrackers.trackers,
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllTrackers: (idCam: string) => dispatch(getListedTrackers(idCam)),
        editCampaignData: (entry: string) => dispatch(editAndGetCampaigns(entry))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TrackerImages)


