import * as React from 'react'
import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedCampaigns, updateSelectedCampaign} from '../../redux/actions/localCampaignsActions'
import { IRealCampaign} from '../../models/CampaignsModelHelper'
import { IRootState } from '../../redux/index';
import './DashboardLayout.css';
import {Link} from "react-router-dom";

interface IIDCampaignData {
    "id":string,
    "create": boolean

}

const idCampaign:IIDCampaignData = {
    "id":'',
    "create": false
}

interface ICampaignsState {
    entry: string
     campaignsData?: IRealCampaign[],
     error?: any,
     selectedCampaignId: string,
     create: boolean
}
interface ICampaignsProps {
    getAllCampaigns: any
    editCampaignData: any,
    campaignsData: any,
    editSelectedCampaign: any
}

class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        this.state = {
            entry: '',
            selectedCampaignId: '',
            create: false
        }
    }

    public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
            this.editCampaign(event)
        }
    }

    public postSelectedHandler = (id:string) => {
        console.log("Selected campaign! With id: " + id);
        this.props.editSelectedCampaign(id)
        idCampaign['id'] = id;
    }

    public setCreateHandler = () => {
        idCampaign['create'] = true;
    }
 /* tslint:enable:no-string-literal */

  public render() {
        return (
      <div>           
         <div className="grid50">
                    <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
                        <thead>
                            <tr>
                            <th>Campaign ID<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th>Campaign name<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th>Campaign description<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            {/* <th >User fullname<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th> */}
                            {/* <th>Contact</th> */}
                            <th>Tracker image </th>
                            <th>Number Of Views</th>      
                                                  
                            </tr>
                        </thead>
                        <tbody >
                        {
                  this.props.campaignsData.map((campaign: IRealCampaign) =>
                    <tr key={campaign.id} onClick={() => this.postSelectedHandler(campaign.id)}>
                      <td>{campaign.id}</td> 
                      <td>{campaign.name}</td> 
                      <td>{campaign.description}</td>
                      {/* <td>  {campaign.user.firstname}    {campaign.user.lastname} {campaign.user.language} </td> */}
                      {/* <td>{campaign.contact.email}</td> */}
                      <td> <img className="campaignImg" src={campaign.trackerUrl} /></td>
                      <td> <img className="campaignImg" src={campaign.numberOfViews} /></td>                   
                            <td onClick={() => this.setCreateHandler()}>< Link to={"/dashboard/edit/" + campaign.id}  className="bp3-button bp3-icon-edit bp3-minimal" /></td>
                    </tr>
                  )
                    }
                     <tr>
                            <td colSpan={5} className="text-center" ><Link to={"/dashboard/edit/1"} className="bp3-button bp3-icon-add bp3-minimal"/>  
                            </td>
                            </tr>
                        </tbody>
                    </table>
                </div>      
            </div>
        )
    }

    public componentDidMount() {
        this.props.getAllCampaigns();
    }

    public componentWillReceiveProps(newProps: ICampaignsProps) {

        this.setState({
            ...newProps.campaignsData
        })
        console.log(this.state)
    }
}


const mapStateToProps = (state: IRootState) => {
    return {
        campaignsData: state.allCampaign.realCampaigns,
        error: state.allCampaign.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllCampaigns: () => dispatch(getListedCampaigns()),
        editCampaignData: (entry: string) => dispatch(editAndGetCampaigns(entry)),
        editSelectedCampaign: (id: string) => dispatch(updateSelectedCampaign(id))
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)

export { idCampaign }
