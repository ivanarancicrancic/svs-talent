import * as React from 'react';
import './Webview.css';

export default class WebviewContent extends React.Component {

    public render() {
        return (
            <pre>
                <div className="panoramaBox">
                    <table className="bp3-html-table">
                        <tbody>
                            <tr>
                                <td>
                                    <form className="webviewForm">
                                        <input name="my_url" type="url" placeholder="your website goes here" pattern="https?://.+" />
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>        
            </pre>
        )
    }
}