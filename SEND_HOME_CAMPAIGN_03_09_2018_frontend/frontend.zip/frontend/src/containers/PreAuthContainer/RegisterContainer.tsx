import * as React from 'react';

import { connect } from 'react-redux';
import {loginUserFetch} from '../../redux/auth/actions';
import {IRegisterFormData} from "../../redux/forms";
import {IRootState} from "../../redux";
import RegisterForm from "../../components/Forms/Register/RegisterForm";
import './RegisterContainer.css';

class RegisterContainer extends React.Component {

    public componentWillMount() {
        console.log(this.props);
    }

    public render() {
        return (
            <div className="grid60">
                <div>
                    <RegisterForm onSubmit={this.onSubmitLoginForm} />
                </div>

            </div>
        )
    }

    private onSubmitLoginForm = (values: IRegisterFormData) => {
        // this.props.loginUserFetch(values);
    }

}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

export default connect(mapStateToProps, {loginUserFetch})(RegisterContainer)