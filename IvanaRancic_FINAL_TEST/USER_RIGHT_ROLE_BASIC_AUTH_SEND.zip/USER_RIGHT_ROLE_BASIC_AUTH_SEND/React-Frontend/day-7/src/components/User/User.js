import React from 'react';
import Modal from 'react-modal';

import MenuButton from './MenuButton';
var appElement = document.getElementById('example');
Modal.setAppElement(appElement);

var bgColors = { "Default": "#81b71a",
                    "Blue": "#00B1E1",
                    "Cyan": "#37BC9B",
                    "Green": "#8CC152",
                    "Red": "#E9573F",
                    "Yellow": "#F6BB42",
};

interface UserResult {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  mdbid: string;
  country_code: string;
  username: string;
  gender: number;
}

interface UserListProps {
}

interface UserListState {
  users: Array<UserResult>;
  isLoading: boolean;
  
}

// Don't do it like this. This is for example only
class User extends React.Component<UserListProps, UserListState> {
	constructor(props: UserListProps) {
    super(props);
    
    this.state = {
      users: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: "",
	  modalIsOpen: false

    };
  
  this.handleChangeGetUserById_userID = this.handleChangeGetUserById_userID.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChangeAddRoleToUser_roleID = this.handleChangeAddRoleToUser_roleID.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChangeAddRoleToUser_userID = this.handleChangeAddRoleToUser_userID.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);

	}
	
	openModal = () => {
    this.setState({modalIsOpen: true});
  }

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  handleModalCloseRequest = () => {
    // opportunity to validate something and keep the modal open even if it
    // requested to be closed
    this.setState({modalIsOpen: false});
  }

  handleSaveClicked = (e) => {
    alert('Save button was clicked');
  }

  
  handleChangeGetUserById_userID(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmit(event) {
    event.preventDefault();

    fetch('http://localhost:8080/api/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_roleID(event) {
    this.setState({value2: event.target.value});
  }

  handleSubmit1(event) {
    alert('User id entered: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/api/getUserByID/userID=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_userID(event) {
	 this.setState({value1: event.target.value});
  }

  handleSubmit2(event) {
    alert('user_id: ' + this.state.value1 + ', role_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/api/addRoleToUser/user_id=' + this.state.value1 + '&role_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }

  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/api/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
	
	
  render() {
	   const {users, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
  
      <div className="container notificationsFrame" style={{
        backgroundColor: "#add8e6",
        borderRadius: "2px"
      }} >
        <div className="panel">
          <div className="header" >

            <MenuButton />

            <span className="title">List of users that exist:</span>
          </div>
          <div className="content">           
		
	  <div className="container" >
   <div style={{
        backgroundColor: "#DCDCDC",
        borderRadius: "2px"
      }}>
    <table className="table table-bordered" >
            <thead>
              <tr >
                <th>
                ID:
                </th>
                <th>
                First Name:
                </th>
                <th>
                Last Name:
                </th>
                <th>
                Username:
                </th>
                <th>
                Email:
                </th>
                <th>
                Country code:
                </th>
                <th>
                 Gender:
                </th>
                <th>
                MDBID:
                </th>
              </tr>
            </thead>
            
            <tbody>
        {users.map((user: UserResult) =>
		    //  alert(idUser),
			
 		      //  <div>
              <tr  key={user.id} onClick={this.openModal}>
                <td>{user.id}</td>
                <td>{user.first_name}</td>
                <td>{user.last_name}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.country_code}</td>
                <td>{user.gender}</td>
                <td>{user.mdbid}</td>
              </tr>


                /* <p><b> ID: </b> {user.id},  <b> First name: </b> {user.first_name},  <b> Last name: </b> {user.last_name} </p> <br/><br/><br/> */
            // </div>
        )}
        </tbody>
        </table>
        </div>
     <b> This is also the result that is returned on loading on the page: </b> <br/>
		<form onSubmit={this.handleSubmit}>
  <input type="submit" value="getAllUsers" className="btn btn-primary"/>
</form>
<br/><br/>
<b> Enter existing user_id to be searched:</b> <br/>
		<form className="form-group" onSubmit={this.handleSubmit1}>
  <label>
    User_id: 
    <input type="text" name="name1" id="textBox" className="form-control" value={this.state.value} onChange={this.handleChangeGetUserById_userID} />
  </label>
  <input type="submit" value="getUserById" className="btn btn-primary small"/>
</form>
<br/><br/>
<b> Enter existing role_id to be added to existing user_id:</b> <br/>
		<form className="form-group" onSubmit={this.handleSubmit2}>
		  <label>
    User_id:
    <input type="text" name="name" className="form-control" id="textBox" value={this.state.value1} onChange={this.handleChangeAddRoleToUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRoleToUser_roleID} />
	</label>	
  <input type="submit" value="addRoleToUser"  className="btn btn-primary"/>
</form>



      </div>  
	  </div>
	  </div>
    
	
	 <Modal visible style={{overlay: {zIndex: 10}}}
          className="Modal__Bootstrap modal-dialog"
          closeTimeoutMS={150}
          isOpen={this.state.modalIsOpen}
          onRequestClose={this.handleModalCloseRequest}
        >
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">USER INFO</h4>
              <button type="button" className="close" onClick={this.handleModalCloseRequest}>
                <span aria-hidden="true">&times;</span>
                <span className="sr-only">Close</span>
              </button>
            </div>
            <div className="modal-body">
              <h4>Really long content...</h4>
			
              <p>User</p>
              <p>Here should be displayed some user info:</p>
              <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, commodo vitae, ornare sit amet, wisi. Aenean fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui. Donec non enim in turpis pulvinar facilisis. Ut felis. Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus</p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={this.handleModalCloseRequest}>Close</button>
              <button type="button" className="btn btn-primary" onClick={this.handleSaveClicked}>Save changes</button>
            </div>
          </div>
        </Modal>
	  </div>
    )
  }
}

export default User
