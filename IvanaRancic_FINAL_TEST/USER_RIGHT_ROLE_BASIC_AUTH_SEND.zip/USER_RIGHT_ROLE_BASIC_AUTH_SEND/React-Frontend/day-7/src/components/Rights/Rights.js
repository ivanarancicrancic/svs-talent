import React from 'react';
import Modal from 'react-modal';
import MenuButton from './MenuButton';
var appElement = document.getElementById('example');
Modal.setAppElement(appElement);


// Could be fetched from a server
const activities = require('../../data.json')

interface Right {
  id: string;
  right_name: string;
  description: string;
}

interface RightsListProps {
}

interface RightListState {
  rights: Array<Right>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Rights extends React.Component<RightsListProps, RightListState> {
	constructor(props: RightsListProps) {
    super(props);

    this.state = {
      rights: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: "",
	  value3: "",
	  value4: "",
	  value5: "",
	  modalIsOpen: false
    };
  
  this.handleChangeGetRightsForRole = this.handleChangeGetRightsForRole.bind(this);
  this.handleSubmitGetRightsForRole = this.handleSubmitGetRightsForRole.bind(this);
  this.handleChangeGetRightsById_rightID = this.handleChangeGetRightsById_rightID.bind(this);
  this.handleSubmitGetRightsById = this.handleSubmitGetRightsById.bind(this);
  this.handleChangeAddRightsToRole_roleID = this.handleChangeAddRightsToRole_roleID.bind(this);
  this.handleChangeAddRightsToRole_rightID = this.handleChangeAddRightsToRole_rightID.bind(this);
  this.handleSubmitAddRightsToRole = this.handleSubmitAddRightsToRole.bind(this);	
  this.handleChangeRemoveRightsFromRole_roleID = this.handleChangeRemoveRightsFromRole_roleID.bind(this);
  this.handleChangeRemoveRightsFromRole_rightID = this.handleChangeRemoveRightsFromRole_rightID.bind(this);
  this.handleSubmitRemoveRightsFromRole = this.handleSubmitRemoveRightsFromRole.bind(this);	
	}
  
  		openModal = () => {
    this.setState({modalIsOpen: true});
  }

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  handleModalCloseRequest = () => {
    // opportunity to validate something and keep the modal open even if it
    // requested to be closed
    this.setState({modalIsOpen: false});
  }

  handleSaveClicked = (e) => {
    alert('Save button was clicked');
  }

  
  handleChangeGetRightsForRole(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmitGetRightsForRole(event) {
    alert('Imetooooooo: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/api/getRightsForRole/role_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChangeGetRightsById_rightID(event) {
this.setState({value1: event.target.value});   
  }

  handleSubmitGetRightsById(event) {
    alert('Imeto: ' + this.state.value1);
    event.preventDefault();
    fetch('http://localhost:8080/api/getRightsByID/right_id=' + this.state.value1)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChangeAddRightsToRole_roleID(event) {
    this.setState({value2: event.target.value});
  }

   handleChangeAddRightsToRole_rightID(event) {
    this.setState({value3: event.target.value});
  }
  
  handleSubmitAddRightsToRole(event) {
    alert('Role_id: ' + this.state.value2 + ', Right_id: ' + this.state.value3);
    event.preventDefault();
    fetch('http://localhost:8080/api/addRightToRole/role_id=' + this.state.value2 + '&right_id=' + this.state.value3)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
   
  handleChangeRemoveRightsFromRole_roleID(event) {
    this.setState({value4: event.target.value});
  }

   handleChangeRemoveRightsFromRole_rightID(event) {
    this.setState({value5: event.target.value});
  } 
   
  handleSubmitRemoveRightsFromRole(event) {
    alert('Role_id: ' + this.state.value4 + ', Right_id: ' + this.state.value5);
    event.preventDefault();
    fetch('http://localhost:8080/api/removeRightFromRole/role_id=' + this.state.value4 + '&right_id=' + this.state.value5)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
   
  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/api/getAllRights')
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
	
	
  render() {
	   const {rights, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="container notificationsFrame"  style={{
        backgroundColor: "#8FBC8F",
        borderRadius: "2px"
      }} >
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">LIST OF RIGHTS FROM DATABASE</span>
          </div>
          <div className="content">           
		   
		
	  <div className="container">
    <div style={{
        backgroundColor: "#CCCC00",
        borderRadius: "2px"
      }}>
    <table className="table table-bordered" >
            <thead>
              <tr>
                <th>
                ID:
                </th>
                <th>
                Right Name:
                </th>
                <th>
                Description:
                </th>
               
              </tr>
            </thead>
            
            <tbody>
        {rights.map((right: Right) =>
 		      //  <div>
              <tr  key={right.id} onClick={this.openModal}>
                <td>{right.id}</td>
                <td>{right.right_name}</td>
                <td>{right.description}</td>     
              </tr>


                /* <p><b> ID: </b> {user.id},  <b> First name: </b> {user.first_name},  <b> Last name: </b> {user.last_name} </p> <br/><br/><br/> */
            // </div>
        )}
        </tbody>
        </table>
        </div>
		<form onSubmit={this.handleSubmitGetRightsForRole}>
  <label>
    Role_id:
    <input type="text" name="name" id="textBox" value={this.state.value} onChange={this.handleChangeGetRightsForRole} />
  </label>
  <input type="submit" value="getRightsForRole" className="btn btn-primary"/>
</form>
<br/><br/>
		<form onSubmit={this.handleSubmitGetRightsById}>
  <label>
    Right_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value1} onChange={this.handleChangeGetRightsById_rightID} />
  </label>
  <input type="submit" value="getRightsById" className="btn btn-primary"/>
</form>
<br/><br/>
		<form onSubmit={this.handleSubmitAddRightsToRole}>
  <label>
    Role_id:  
    <input type="text" name="name2" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRightsToRole_roleID} />
	</label>
  <label>
    Right_id:  
    <input type="text" name="name3" id="textBox" value={this.state.value3} onChange={this.handleChangeAddRightsToRole_rightID} />
	</label>	
  <input type="submit" value="addRightsToRole" className="btn btn-primary"/>
</form>

<br/><br/>
		<form onSubmit={this.handleSubmitRemoveRightsFromRole}>
  <label>
    Role_id:  
    <input type="text" name="name2" id="textBox" value={this.state.value4} onChange={this.handleChangeRemoveRightsFromRole_roleID} />
	</label>
  <label>
    Right_id:  
    <input type="text" name="name3" id="textBox" value={this.state.value5} onChange={this.handleChangeRemoveRightsFromRole_rightID} />
	</label>	
  <input type="submit" value="removeRightsFromRole" className="btn btn-primary"/>
</form>
		
      </div>  
	  </div>
	  </div>
	   <Modal visible style={{overlay: {zIndex: 10}}}
          className="Modal__Bootstrap modal-dialog"
          closeTimeoutMS={150}
          isOpen={this.state.modalIsOpen}
          onRequestClose={this.handleModalCloseRequest}
        >
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">RIGHT INFO</h4>
              <button type="button" className="close" onClick={this.handleModalCloseRequest}>
                <span aria-hidden="true">&times;</span>
                <span className="sr-only">Close</span>
              </button>
            </div>
            <div className="modal-body">
              <h4>Really long content...</h4>
			
              <p>Right</p>
              <p>Here should be displayed some right info:</p>
              <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, commodo vitae, ornare sit amet, wisi. Aenean fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui. Donec non enim in turpis pulvinar facilisis. Ut felis. Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus</p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={this.handleModalCloseRequest}>Close</button>
              <button type="button" className="btn btn-primary" onClick={this.handleSaveClicked}>Save changes</button>
            </div>
          </div>
        </Modal>
	  
	  </div>
    )
  }
}

export default Rights
