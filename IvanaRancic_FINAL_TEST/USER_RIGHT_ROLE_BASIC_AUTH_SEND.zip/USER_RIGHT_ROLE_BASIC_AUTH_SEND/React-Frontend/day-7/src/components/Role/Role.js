import React from 'react';
import Modal from 'react-modal';
import MenuButton from './MenuButton';
var appElement = document.getElementById('example');
Modal.setAppElement(appElement);

interface RoleResult {
  id: string;
  userrole: string;
  description: string;
}

interface RoleListProps {
}

interface RoleListState {
  roles: Array<RoleResult>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Role extends React.Component<RoleListProps, RoleListState> {
	constructor(props: RoleListProps) {
    super(props);

    this.state = {
      roles: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: "",
	  value3: "",
	  value4: "",
	  value5: "",
	  modalIsOpen: false
    };
  
  this.handleChangeGetRoleById_roleID = this.handleChangeGetRoleById_roleID.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChangeAddRoleToUser_userID = this.handleChangeAddRoleToUser_userID.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChangeAddRoleToUser_roleID = this.handleChangeAddRoleToUser_roleID.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);
	this.handleChangeGetRolesForUser_userID = this.handleChangeGetRolesForUser_userID.bind(this);
	this.handleSubmit3 = this.handleSubmit3.bind(this);
	this.handleChangeRemoveRoleFromUser_userID = this.handleChangeRemoveRoleFromUser_userID.bind(this);
    this.handleChangeRemoveRoleFromUser_roleID = this.handleChangeRemoveRoleFromUser_roleID.bind(this);
	this.handleSubmit4 = this.handleSubmit4.bind(this);
	}
	
		openModal = () => {
    this.setState({modalIsOpen: true});
  }

  closeModal = () => {
    this.setState({modalIsOpen: false});
  }

  handleModalCloseRequest = () => {
    // opportunity to validate something and keep the modal open even if it
    // requested to be closed
    this.setState({modalIsOpen: false});
  }

  handleSaveClicked = (e) => {
    alert('Save button was clicked');
  }

  
  handleChangeGetRoleById_roleID(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmit(event) {
    event.preventDefault();
    fetch('http://localhost:8080/api/getAllRoles')
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_roleID(event) {
    this.setState({value2: event.target.value});
  }

  handleSubmit1(event) {
    alert('User id entered: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/api/getRolesByID/role_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_userID(event) {
	 this.setState({value1: event.target.value});
  }

  handleSubmit2(event) {
    alert('user_id: ' + this.state.value1 + ', role_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/api/addRoleToUser/user_id=' + this.state.value1 + '&role_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }

  handleChangeGetRolesForUser_userID(event){
	  this.setState({value3: event.target.value});
  }
  
   handleSubmit3(event) {
    alert('Entered user_id: ' + this.state.value3);
    event.preventDefault();
    fetch('http://localhost:8080/api/getRolesForUser/user_id=' + this.state.value3)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeRemoveRoleFromUser_userID(event){
	  this.setState({value4: event.target.value});
  }
  
  handleChangeRemoveRoleFromUser_roleID(event){
	  this.setState({value5: event.target.value});
  }
  
  handleSubmit4(event) {
    alert('user_id: ' + this.state.value4 + ', role_id: ' + this.state.value5);
    event.preventDefault();
       fetch('http://localhost:8080/api/removeRoleFromUser/user_id=' + this.state.value4 + '&role_id=' + this.state.value5)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  
  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/api/getAllRoles')
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
	
	
  render() {
	   const {roles, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
   
      <div className="container notificationsFrame"  style={{
        backgroundColor: "#8FBC8F",
        borderRadius: "2px"
      }}  >
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">LIST OF ROLES FROM DATABASE</span>
          </div>
          <div className="content">           
		  
		
	  <div className="container">
   <div style={{
        backgroundColor: "#32CD32",
        borderRadius: "2px"
      }}>
    <table className="table table-bordered" >
            <thead>
              <tr>
                <th>
                ID:
                </th>
                <th>
                First Name:
                </th>
                <th>
                Last Name:
                </th>
               
              </tr>
            </thead>
            
            <tbody>
        {roles.map((role: RoleResult) =>
 		      //  <div>
              <tr  key={role.id} onClick={this.openModal}>
                <td>{role.id}</td>
                <td>{role.userrole}</td>
                <td>{role.description}</td>
              
              </tr>


                /* <p><b> ID: </b> {user.id},  <b> First name: </b> {user.first_name},  <b> Last name: </b> {user.last_name} </p> <br/><br/><br/> */
            // </div>
        )}
        </tbody>
        </table>
        </div>
     <b> This is also the result that is returned on loading on the page: </b> <br/>
		<form onSubmit={this.handleSubmit}>
  <input type="submit" value="getAllRoles"  className="btn btn-primary"/>
</form>
<br/><br/>
<b> Enter existing role_id to be searched:</b> <br/>
		<form onSubmit={this.handleSubmit1}>
  <label>
    Role_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value} onChange={this.handleChangeGetRoleById_roleID} />
  </label>
  <input type="submit" value="getRoleById"  className="btn btn-primary"/>
</form>
<br/><br/>

<b> Enter existing user_id to be serached roles that corresponds to it:</b> <br/>
	<form onSubmit={this.handleSubmit3}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value3} onChange={this.handleChangeGetRolesForUser_userID} />
  </label>
			
  <input type="submit" value="getRolesForUser"  className="btn btn-primary"/>
</form>
<br/><br/>
<b> Enter existing role_id to be added to existing user_id:</b> <br/>
		<form onSubmit={this.handleSubmit2}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value1} onChange={this.handleChangeAddRoleToUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRoleToUser_roleID} />
	</label>	
  <input type="submit" value="addRoleToUser"  className="btn btn-primary"/>
</form>
<br/><br/>
<b> Enter existing role_id to be removed to existing user_id:</b> <br/>
		<form onSubmit={this.handleSubmit4}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value4} onChange={this.handleChangeRemoveRoleFromUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value5} onChange={this.handleChangeRemoveRoleFromUser_roleID} />
	</label>	
  <input type="submit" value="removeRoleFromUser"  className="btn btn-primary"/>
</form>
	
      </div>  
	  </div>
	  </div>
	  
	  
	 <Modal visible style={{overlay: {zIndex: 10}}}
          className="Modal__Bootstrap modal-dialog"
          closeTimeoutMS={150}
          isOpen={this.state.modalIsOpen}
          onRequestClose={this.handleModalCloseRequest}
        >
          <div className="modal-content">
            <div className="modal-header">
              <h4 className="modal-title">ROLE INFO</h4>
              <button type="button" className="close" onClick={this.handleModalCloseRequest}>
                <span aria-hidden="true">&times;</span>
                <span className="sr-only">Close</span>
              </button>
            </div>
            <div className="modal-body">
              <h4>Really long content...</h4>
			
              <p>Role</p>
              <p>Here should be displayed some role info:</p>
              <p>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget, tempor sit amet, ante. Donec eu libero sit amet quam egestas semper. Aenean ultricies mi vitae est. Mauris placerat eleifend leo. Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, commodo vitae, ornare sit amet, wisi. Aenean fermentum, elit eget tincidunt condimentum, eros ipsum rutrum orci, sagittis tempus lacus enim ac dui. Donec non enim in turpis pulvinar facilisis. Ut felis. Praesent dapibus, neque id cursus faucibus, tortor neque egestas augue, eu vulputate magna eros eu erat. Aliquam erat volutpat. Nam dui mi, tincidunt quis, accumsan porttitor, facilisis luctus, metus</p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" onClick={this.handleModalCloseRequest}>Close</button>
              <button type="button" className="btn btn-primary" onClick={this.handleSaveClicked}>Save changes</button>
            </div>
          </div>
        </Modal>
	  
	  </div>
    )
  }
}

export default Role