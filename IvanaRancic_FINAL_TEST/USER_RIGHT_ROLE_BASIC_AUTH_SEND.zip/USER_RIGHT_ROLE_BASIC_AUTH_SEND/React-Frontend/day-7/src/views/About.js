import React from 'react';
import Rights from '../components/Rights/Rights';
import ReactDOM from 'react-dom';

class About extends React.Component {
  render() {
    return (
        <Rights/>
          );
  }
}

export default About;