CREATE DATABASE  IF NOT EXISTS `userrolerightdata` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `userrolerightdata`;

DROP TABLE IF EXISTS `rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rights` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `right_name` varchar(45) DEFAULT NULL,
  `description` varchar(245) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role`
--
DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userrole` varchar(45) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `role_rights`
--
DROP TABLE IF EXISTS `role_rights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_rights` (
  `role_id` int(10) unsigned NOT NULL,
  `rights_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`rights_id`),
  KEY `fk_rolerights_rights_idx` (`rights_id`),
  CONSTRAINT `fk_rolerights_rights` FOREIGN KEY (`rights_id`) REFERENCES `rights` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rolerights_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user`
--
DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country_code` varchar(3) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `email` varchar(256) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `mdbid` varchar(45) DEFAULT NULL,
  `deactivated` date DEFAULT NULL,
  `key_user_createuser` int(11) DEFAULT NULL,
  `create_datetime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `key_user_updateuser` varchar(45) DEFAULT NULL,
  `update_datetime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


--
-- Table structure for table `user_role`
--
DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `userrole` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_userrole_role_idx` (`role_id`),
  CONSTRAINT `fk_userrole_role` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_userrole_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;


alter table role_rights drop foreign key FK3n4emdt6749mwm2q0hdo2t8m4;
alter table role_rights drop foreign key FKawustdxxrt65v7pj4btfm9sr5;
alter table user_role drop foreign key FK7ir6hi5jr98lclgjgbyxafneu;
alter table user_role drop foreign key FK859n2jvi8ivhui0rl0esws6o;
drop table if exists rights;
drop table if exists Role;
drop table if exists role_rights;
drop table if exists user;
drop table if exists user_role;
create table rights (id integer not null auto_increment, description varchar(255), right_name varchar(255), primary key (id));
create table Role (id integer not null auto_increment, description varchar(255), userrole varchar(255), primary key (id));
create table role_rights (role_id integer not null, rights_id integer not null);
create table user (id integer not null auto_increment, mdbid varchar(255), country_code varchar(255), create_datetime datetime, deactivated datetime, email varchar(255), first_name varchar(255), gender integer, key_user_createuser integer, key_user_updateuser varchar(255), last_name varchar(255), update_datetime datetime, username varchar(255), primary key (id));
create table user_role (user_id integer not null, role_id integer not null);
alter table role_rights add constraint FK3n4emdt6749mwm2q0hdo2t8m4 foreign key (rights_id) references rights (id);
alter table role_rights add constraint FKawustdxxrt65v7pj4btfm9sr5 foreign key (role_id) references Role (id);
alter table user_role add constraint FK7ir6hi5jr98lclgjgbyxafneu foreign key (role_id) references Role (id);
alter table user_role add constraint FK859n2jvi8ivhui0rl0esws6o foreign key (user_id) references user (id);
alter table role_rights drop foreign key FK3n4emdt6749mwm2q0hdo2t8m4;
alter table role_rights drop foreign key FKawustdxxrt65v7pj4btfm9sr5;
alter table user_role drop foreign key FK7ir6hi5jr98lclgjgbyxafneu;
alter table user_role drop foreign key FK859n2jvi8ivhui0rl0esws6o;
drop table if exists rights;
drop table if exists Role;
drop table if exists role_rights;
drop table if exists user;
drop table if exists user_role;
create table rights (id integer not null auto_increment, description varchar(255), right_name varchar(255), primary key (id));
create table Role (id integer not null auto_increment, description varchar(255), userrole varchar(255), primary key (id));
create table role_rights (role_id integer not null, rights_id integer not null);
create table user (id integer not null auto_increment, mdbid varchar(255), country_code varchar(255), create_datetime datetime, deactivated datetime, email varchar(255), first_name varchar(255), gender integer, key_user_createuser integer, key_user_updateuser varchar(255), last_name varchar(255), update_datetime datetime, username varchar(255), primary key (id));
create table user_role (user_id integer not null, role_id integer not null);
alter table role_rights add constraint FK3n4emdt6749mwm2q0hdo2t8m4 foreign key (rights_id) references rights (id);
alter table role_rights add constraint FKawustdxxrt65v7pj4btfm9sr5 foreign key (role_id) references Role (id);
alter table user_role add constraint FK7ir6hi5jr98lclgjgbyxafneu foreign key (role_id) references Role (id);
alter table user_role add constraint FK859n2jvi8ivhui0rl0esws6o foreign key (user_id) references user (id);
