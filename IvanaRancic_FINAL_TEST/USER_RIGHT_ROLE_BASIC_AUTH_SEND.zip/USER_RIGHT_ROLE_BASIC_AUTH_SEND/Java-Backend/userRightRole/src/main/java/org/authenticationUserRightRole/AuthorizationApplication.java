package org.authenticationUserRightRole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.EnumSet;

import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.tool.hbm2ddl.SchemaExport;
import org.hibernate.tool.schema.TargetType;
@SpringBootApplication
public class AuthorizationApplication {
    public static final String SCRIPT_FILE = "exportScript.sql";

    private static SchemaExport getSchemaExport() {

        SchemaExport export = new SchemaExport();
        // Script file.
        File outputFile = new File(SCRIPT_FILE);
        String outputFilePath = outputFile.getAbsolutePath();

        System.out.println("Export file: " + outputFilePath);

        export.setDelimiter(";");
        export.setOutputFile(outputFilePath);

        // No Stop if Error
        export.setHaltOnError(false);
        //
        return export;
    }

    public static void dropDataBase(SchemaExport export, Metadata metadata) {
        // TargetType.DATABASE - Execute on Databse
        // TargetType.SCRIPT - Write Script file.
        // TargetType.STDOUT - Write log to Console.
        EnumSet<TargetType> targetTypes = EnumSet.of(TargetType.DATABASE, TargetType.SCRIPT, TargetType.STDOUT);

        export.drop(targetTypes, metadata);
    }

    public static void createDataBase(SchemaExport export, Metadata metadata) {
        // TargetType.DATABASE - Execute on Databse
        // TargetType.SCRIPT - Write Script file.
        // TargetType.STDOUT - Write log to Console.

        EnumSet<TargetType> targetTypes = EnumSet.of(TargetType.DATABASE, TargetType.SCRIPT, TargetType.STDOUT);

        SchemaExport.Action action = SchemaExport.Action.CREATE;
        //
        export.execute(targetTypes, action, metadata);

        System.out.println("Export OK");

    }

    public static void main(String[] args){
        // Using Oracle Database.

        String configFileName = "hibernate-mysql.cfg.xml";

        // Create the ServiceRegistry from hibernate-xxx.cfg.xml
        ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()//
                .configure(configFileName).build();

        // Create a metadata sources using the specified service registry.
        Metadata metadata = new MetadataSources(serviceRegistry).getMetadataBuilder().build();

        SchemaExport export = getSchemaExport();

        System.out.println("Drop Database...");
        // Drop Database
        dropDataBase(export, metadata);

        System.out.println("Create Database...");
        // Create tables
        createDataBase(export, metadata);
        String url = "jdbc:mysql://localhost:3306/userrolerightdata?createDatabaseIfNotExist=true&useSSL=false&useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        try {
            Connection conn = DriverManager.getConnection(url,"root","password");
            Statement st = conn.createStatement();
            st.executeUpdate("INSERT INTO rights " +
                    "VALUES (7, 'edit', 'right to edit data')");

            st.executeUpdate("Insert Into rights (right_name, description) Values ('admin', 'admin right')");
            st.executeUpdate("INSERT INTO `role` VALUES (22,'MAIN_ADMIN','THis is main admin role!'),(23,'Edit','Right to edit data'),(24,'View','Right to view data'),(25,'Edit','Right to edit files')");
            st.executeUpdate("INSERT INTO `user` VALUES (34, '2109989455583','MK', '2018-05-10','2018-04-11', 'ivanarancic@gmail.com','Ivana', 1, 34, '34','Rancic', '2018-05-10', 'ivanarancic') ,(35, '2109989455583','MK', '2018-02-10', '2018-04-09', 'marija.ristova@gmail.com', 'marija', 1, 34, '34', 'ristova', '2018-01-31', 'marijac'),(36,'0204991455456', 'SR', '2018-05-10', '2018-04-10', 'somemail', 'Jana', 1, 34, '34','Belova', '2018-01-03','anac'),(37,'1510984455279', 'SR', '2018-05-10', '2018-06-10', 'JohnsonS@gmail.com', 'Sara', 1, 34, '34', 'Johnson','2018-01-01', 'SaraJ')");


            conn.close();
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
        }

        SpringApplication.run(AuthorizationApplication.class, args);
    }

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurerAdapter() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/api/**").allowedOrigins("http://localhost:3000");
            }
        };
    }


//    @Bean
//    InitializingBean usersAndGroupsInitializer(final IdentityService identityService) {
//
//        return new InitializingBean() {
//            public void afterPropertiesSet() throws Exception {
//
//                Group group = identityService.newGroup("user");
//                group.setName("users");
//                group.setType("security-role");
//                identityService.saveGroup(group);
//
//                User admin = identityService.newUser("admin123");
//                admin.setPassword("admin123");
//                identityService.saveUser(admin);
//
//            }
//        };
//    }

}
