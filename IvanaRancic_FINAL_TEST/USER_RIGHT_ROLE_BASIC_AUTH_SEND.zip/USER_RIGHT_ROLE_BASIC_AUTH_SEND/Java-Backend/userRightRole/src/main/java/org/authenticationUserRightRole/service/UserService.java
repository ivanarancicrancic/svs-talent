package org.authenticationUserRightRole.service;

import org.authenticationUserRightRole.model.UserReturn;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface UserService {

    public List<UserReturn> getAllUsers();

    public UserReturn getUserByID(int id);

    public void createUser(UserReturn user);

    public void addRoleToUser(int role_id, int user_id);

    public void removeRoleFromUser(int role_id, int user_id);

}
