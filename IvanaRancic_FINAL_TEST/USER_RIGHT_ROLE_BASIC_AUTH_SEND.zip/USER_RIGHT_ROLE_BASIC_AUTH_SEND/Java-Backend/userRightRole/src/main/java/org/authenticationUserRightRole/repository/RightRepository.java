package org.authenticationUserRightRole.repository;

import org.authenticationUserRightRole.model.Rights;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface RightRepository extends JpaRepository<Rights, Integer> {

    public Rights findById(int id);
}
