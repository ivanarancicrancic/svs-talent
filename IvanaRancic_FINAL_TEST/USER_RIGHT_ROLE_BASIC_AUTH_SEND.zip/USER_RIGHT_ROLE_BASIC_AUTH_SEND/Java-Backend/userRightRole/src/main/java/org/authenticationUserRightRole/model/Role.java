package org.authenticationUserRightRole.model;


import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Role",
        uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
@Component
public class Role {
    private int id;
    private String userrole;
    private String description;

    private List<User> users = new ArrayList<>();
    private List<Rights> rights = new ArrayList<>();

    public Role(){}

    public Role(String userrole, String description) {
        this.userrole = userrole;
        this.description = description;
    }

    public Role(int id, String userrole, String description) {
        this.id = id;
        this.userrole = userrole;
        this.description = description;
    }

    public Role(String userrole, String description, List<User> users) {
        this.userrole = userrole;
        this.description = description;
        this.users = users;
    }

    public Role(String userrole, String description, List<User> users, List<Rights> rights) {
        this.userrole = userrole;
        this.description = description;
        this.users = users;
        this.rights = rights;
    }

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "role_rights", joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "rights_id", referencedColumnName = "id"))
    public List<Rights> getRights() {
        return rights;
    }

    public void setRights(List<Rights> rights) {
        this.rights = rights;
    }

    @Column(name = "userrole")
    public String getUserrole() {
        return userrole;
    }

    public void setUserrole(String userrole) {
        this.userrole = userrole;
    }

    @Column(name = "description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Basic
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @ManyToMany(mappedBy = "roles")
    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }

    @Override
    public String toString() {
        System.out.println("Entered method role.toString() !" + "Role with id: " + id + ", role name is: " + userrole + ", description: " + description);
        String result = "Role with id: " + id + ", role name is: " + userrole + ", description: " + description;
        if (this.getUsers() != null) {
            System.out.println(" Users list is != null ");
            result += ", Users that have this role are: ";
            for(User user : users) {
                System.out.println("Entered for part, listing user by user!");
                System.out.println("user_id is: " + user.getId());
                result += String.format(
                        ", user_id='%s'",
                        user.getId());
            }
        }
        return result;
    }

}
