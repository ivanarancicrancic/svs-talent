package org.authenticationUserRightRole.model;


import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Component
@Table(name = "user",
        uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
public class User {

    private int id;
    private String country_code;
    private String username;
    private String email;
    private int gender;
    private String first_name;
    private String last_name;
    private String mdbid;
    private Date deactivated;
    private int key_user_createuser;
    private Timestamp create_datetime;
    private String key_user_updateuser;
    private Timestamp update_datetime;
    private List<Role> roles = new ArrayList<>();
    public User(){}

    public User(String country_code, String username, String email, int gender, String first_name, String last_name, String mdbid, Date deactivated, int key_user_create_user, Timestamp create_datetime, String key_user_update_user, Timestamp update_datetime) {

        this.country_code = country_code;
        this.username = username;
        this.email = email;
        this.gender = gender;
        this.first_name = first_name;
        this.last_name = last_name;
        this.mdbid = mdbid;
        this.deactivated = deactivated;
        this.key_user_createuser = key_user_create_user;
        this.create_datetime = create_datetime;
        this.key_user_updateuser = key_user_update_user;
        this.update_datetime = update_datetime;
    }
//public User(List<Role> roles){this.roles = roles;}


    public User(String country_code, String username, String email, int gender, String first_name, String last_name, String mdbid, Date deactivated, int key_user_create_user, Timestamp create_datetime, String key_user_update_user, Timestamp update_datetime, List<Role> roles) {

        this.country_code = country_code;
        this.username = username;
        this.email = email;
        this.gender = gender;
        this.first_name = first_name;
        this.last_name = last_name;
        this.mdbid = mdbid;
        this.deactivated = deactivated;
        this.key_user_createuser = key_user_create_user;
        this.create_datetime = create_datetime;
        this.key_user_updateuser = key_user_update_user;
        this.update_datetime = update_datetime;
        this.roles = roles;
    }

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Basic
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "country_code")
    public String getCountry_code() {
        return country_code;
    }

    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    @Column(name = "username")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name = "email")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(name = "gender")
    public int isGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    @Column(name = "first_name")
    public String getFirstName() {
        return first_name;
    }

    public void setFirstName(String firstName) {
        this.first_name = firstName;
    }

    @Column(name = "last_name")
    public String getLastName() {
        return last_name;
    }

    public void setLastName(String lastName) {
        this.last_name = lastName;
    }

    @Column(name = "mdbid")
    public String getMDBID() {
        return mdbid;
    }

    public void setMDBID(String MDBID) {
        this.mdbid = MDBID;
    }

    @Column(name = "deactivated")
    public Date getDeactivated() {
        return deactivated;
    }

    public void setDeactivated(Date deactivated) {
        this.deactivated = deactivated;
    }

    @Column(name = "key_user_createuser")
    public int getKey_user_createuser() {
        return key_user_createuser;
    }

    public void setKey_user_createuser(int key_user_createuser) {
        this.key_user_createuser = key_user_createuser;
    }

    @Column(name = "create_datetime")
    public Timestamp getCreate_datetime() {
        return create_datetime;
    }

    public void setCreate_datetime(Timestamp create_datetime) {
        this.create_datetime = create_datetime;
    }

    @Column(name = "key_user_updateuser")
    public String getKey_user_updateuser() {
        return key_user_updateuser;
    }

    public void setKey_user_updateuser(String key_user_updateuser) {
        this.key_user_updateuser = key_user_updateuser;
    }

    @Column(name = "update_datetime")
    public Timestamp getUpdate_datetime() {
        return update_datetime;
    }

    public void setUpdate_datetime(Timestamp update_datetime) {
        this.update_datetime = update_datetime;
    }

    @ManyToMany(cascade = CascadeType.ALL)
    @JoinTable(name = "user_role", joinColumns = @JoinColumn(name = "user_id", referencedColumnName = "id"), inverseJoinColumns = @JoinColumn(name = "role_id", referencedColumnName = "id"))
    public List<Role> getRoles() {
        return roles;
    }
    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }


    @Override
    public String toString() {
        String result = String.format(
                "User [id=%d]%n",
                id);
        if (roles != null) {
            System.out.println("Roles that this user have != null");
            for (Role role : roles) {
                System.out.println("Entered for listing role by role");
                result += String.format(
                        "Role[id=%d]%n",
                        role.getId());
                System.out.println("Role: " + result);
            }
        }

        return result;
    }

}
