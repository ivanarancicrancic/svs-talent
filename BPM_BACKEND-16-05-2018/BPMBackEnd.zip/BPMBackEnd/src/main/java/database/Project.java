package database;

import Models.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Project {

    public LoginStatus getLoginStatus(Connection connection, UserLogin ul) throws Exception
    {
        LoginStatus t_items = new LoginStatus();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getLoginStatus(?,?)");
            ps.setString(1,ul.getUsername() );
            ps.setString(2,ul.getPassword() );
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                t_items.setStatus(rs.getInt(1));
                t_items.setGroupName(rs.getString(2));
                t_items.setFormName(rs.getString(3));
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<FormsByUsername> getFormsByUsername(Connection connection, String username) throws Exception
    {
        List<FormsByUsername> t_items = new ArrayList<FormsByUsername>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getformsbyusername(?)");
            ps.setString(1,username);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                FormsByUsername p_eden = new FormsByUsername(
                        rs.getString(1)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<DocumentName> getdocumentnamebyid(Connection connection, int id ) throws Exception
    {
        List<DocumentName> t_items = new ArrayList<DocumentName>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getdocumentnamebyid(?)");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                DocumentName p_eden = new DocumentName(
                        rs.getString(1)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<LoanRequests> getloanrequests(Connection connection, String username) throws Exception
    {
        List<LoanRequests> t_items = new ArrayList<LoanRequests>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequests(?)");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequests p_eden = new LoanRequests(
                        rs.getLong (1),
                        rs.getInt (2),
                        rs.getString (3),
                        rs.getString (4),
                        rs.getInt (5),
                        rs.getString (6),
                        rs.getString (7),
                        rs.getString (8),
                        rs.getString (9),
                        rs.getInt (10),
                        rs.getString (11),
                        rs.getString (12),
                        rs.getString (13),
                        rs.getString (14),
                        rs.getInt (15),
                        rs.getInt (16),
                        rs.getInt (17),
                        rs.getString (18),
                        rs.getString (19),
                        rs.getInt (20),
                        rs.getBoolean (21),
                        rs.getInt (22),
                        rs.getInt (23),
                        rs.getInt (24),
                        rs.getInt (25),
                        rs.getInt (26),
                        rs.getBoolean (27),
                        rs.getBoolean (28),
                        rs.getInt (29),
                        rs.getString (30),
                        rs.getInt (31),
                        rs.getInt (32),
                        rs.getInt (33),
                        rs.getInt (34),
                        rs.getString (35),
                        rs.getString (36),
                        rs.getInt (37),
                        rs.getInt (38),
                        rs.getString (39),
                        rs.getString (40),
                        rs.getString (41),
                        rs.getInt (42),
                        rs.getString (43),
                        rs.getString(44),
                        rs.getString(45),
                        rs.getString(46)
                        );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<LoanRequestsDetailsByID> getloanrequestsdetailsbyid(Connection connection, long requestID) throws Exception
    {
        List<LoanRequestsDetailsByID> t_items = new ArrayList<LoanRequestsDetailsByID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsdetailsbyid(?)");
            ps.setLong(1, requestID);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequestsDetailsByID p_eden = new LoanRequestsDetailsByID(
                        rs.getLong (1),
                        rs.getInt (2),
                        rs.getString (3),
                        rs.getString (4),
                        rs.getInt (5),
                        rs.getString (6),
                        rs.getString (7),
                        rs.getString (8),
                        rs.getString (9),
                        rs.getInt (10),
                        rs.getString (11),
                        rs.getString (12),
                        rs.getString (13),
                        rs.getString (14),
                        rs.getInt (15),
                        rs.getInt (16),
                        rs.getInt (17),
                        rs.getString (18),
                        rs.getString (19),
                        rs.getInt (20),
                        rs.getBoolean (21),
                        rs.getInt (22),
                        rs.getInt (23),
                        rs.getInt (24),
                        rs.getInt (25),
                        rs.getInt (26),
                        rs.getBoolean (27),
                        rs.getBoolean (28),
                        rs.getInt (29),
                        rs.getString (30),
                        rs.getInt (31),
                        rs.getInt (32),
                        rs.getInt (33),
                        rs.getInt (34),
                        rs.getString (35),
                        rs.getString (36),
                        rs.getInt (37),
                        rs.getInt (38),
                        rs.getString (39),
                        rs.getString (40),
                        rs.getString (41),
                        rs.getBoolean (42),
                        rs.getString (43),
                        rs.getString (44),
                        rs.getString (45),
                        rs.getInt (46),
                        rs.getString (47),
                        rs.getInt (48),
                        rs.getString (49),
                        rs.getString (50),
                        rs.getString (51),
                        rs.getString (52),
                        rs.getString (53),
                        rs.getString (54),
                        rs.getString (55),
                        rs.getString (56)

                        );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<ActiveLoans> getactiveloans(Connection connection,String p_status) throws Exception
    {
        List<ActiveLoans> t_items = new ArrayList<ActiveLoans>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getactiveloans(?)");
            ps.setString(1, p_status);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                ActiveLoans p_eden = new ActiveLoans(
                        rs.getString (1),
                        rs.getInt (2),
                        rs.getInt (3),
                        rs.getInt (4),
                        rs.getInt (5),
                        rs.getInt (6),
                        rs.getString (7),
                        rs.getString (8),
                        rs.getString(10),
                        rs.getInt(9),
                        rs.getInt(11),
                        rs.getString(12),
                        rs.getString(13)

                );

                NumberFormat format = NumberFormat.getCurrencyInstance(Locale.US);
                String currency = format.format(Integer.parseInt(p_eden.getIznos()));
                currency = currency.substring(1);
                System.out.println("Iznos : " + currency);
                p_eden.setIznos(currency);
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<AttachedDocumentsForLoanRequestID> getattacheddocumentsforloanrequestid(Connection connection, long requestID) throws Exception
    {
        List<AttachedDocumentsForLoanRequestID> t_items = new ArrayList<AttachedDocumentsForLoanRequestID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getattacheddocumentsforloanrequestid(?)");
            ps.setLong(1, requestID);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                AttachedDocumentsForLoanRequestID p_eden = new AttachedDocumentsForLoanRequestID(
                        rs.getString (1),
                        rs.getString (2),
                        rs.getString (3),
                        rs.getString (4),
                        rs.getString (5)

                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }




    public List<CommentsForLoanRequestID> getcommentsforloanrequestid(Connection connection, long requestID) throws Exception
    {
        List<CommentsForLoanRequestID> t_items = new ArrayList<CommentsForLoanRequestID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getcommentsforloanrequestid(?)");
            ps.setLong(1, requestID);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                CommentsForLoanRequestID p_eden = new CommentsForLoanRequestID(
                        rs.getString (1),
                        rs.getString (2),
                        rs.getString (3)

                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<LoanType> GetLoanTypeByLoanLineID(Connection connection, Integer loanLineID) throws Exception
    {
        List<LoanType> t_items = new ArrayList<LoanType>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetLoanTypeByLoanLineID(?)");
            ps.setInt(1,loanLineID);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanType p_eden = new LoanType(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<CreditLine> GetKreditniLini(Connection connection, Integer p_type) throws Exception
    {
        List<CreditLine> t_items = new ArrayList<CreditLine>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetKreditniLini(?)");
            ps.setInt(1,p_type);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                CreditLine p_eden = new CreditLine(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<UsersByUsername> GetUsersByUsername(Connection connection, String p_username) throws Exception
    {
        List<UsersByUsername> t_items = new ArrayList<UsersByUsername>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetUsersByUsername(?)");
            ps.setString(1,p_username);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                UsersByUsername p_eden = new UsersByUsername(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<AplicantDetails> GetAplicantDetailsByEmbg(Connection connection, String p_embg ) throws Exception
    {
        List<AplicantDetails> t_items = new ArrayList<AplicantDetails>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetAplicantDetailsByEmbg(?)");
            ps.setString(1,p_embg);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                AplicantDetails p_eden = new AplicantDetails(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<UserByGroupId> GetUsersByGrpoupID(Connection connection,Integer p_groupid ) throws Exception
    {
        List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getusersbygroupid(?)");
            ps.setInt(1,p_groupid);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String fullname1 =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("fullname1 "+fullname1);
                //TreatmentItem p_eden = new TreatmentItem();
                UserByGroupId p_eden = new UserByGroupId(

                        rs.getString(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<ClientType> getClientsType(Connection connection) throws Exception
    {
        List<ClientType> t_items = new ArrayList<ClientType>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getClientsType()");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                ClientType p_eden = new ClientType(
                        rs.getInt (1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<LoanRequestsByParametar> getloanrequestsbyparametar(Connection connection, String p_type, String p_value) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1,p_type);
            ps.setString(2,p_value);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(

                        rs.getLong(1),



                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }




    public List<DocumentsForLoanTypeID> GetDocumentsForLoanTypeID(Connection connection,Integer _loanTypeID) throws Exception
    {
        List<DocumentsForLoanTypeID> t_items = new ArrayList<DocumentsForLoanTypeID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getdocumentsforloantypeid(?)");
            ps.setInt(1, _loanTypeID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                DocumentsForLoanTypeID p_eden = new DocumentsForLoanTypeID(

                        rs.getInt(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsByLoanID> GetWarningsByLoanID(Connection connection, Integer loanID) throws Exception
    {
        List<WarningsByLoanID> t_items = new ArrayList<WarningsByLoanID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getwarningsbyloanid(?)");
            ps.setInt(1, loanID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsByLoanID p_eden = new WarningsByLoanID(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }
    public List<Statusi> GetStatusByForm(Connection connection, String formName) throws Exception
    {
        List<Statusi> t_items = new ArrayList<Statusi>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getstatusibyformname(?)");
            ps.setString(1, formName);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                Statusi p_eden = new Statusi(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsDetailsByWarrningID> GetPdfWarrningsByLoanId(Connection connection, Integer loanId) throws Exception
    {
        List<WarningsDetailsByWarrningID> t_items = new ArrayList<WarningsDetailsByWarrningID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getpdfwarningsbyloanid(?)");
            ps.setInt(1, loanId);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsDetailsByWarrningID p_eden = new WarningsDetailsByWarrningID(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public void assignedTask(Connection connection, AssigneModel assigneModel) throws Exception
    {
        //List<WarningsDetailsByWarrningID> t_items = new ArrayList<WarningsDetailsByWarrningID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from assignetask(?, ?, ?)");
            ps.setString(1, assigneModel.getAssigneTo());
            ps.setString(2, assigneModel.getAssigneFrom());
            ps.setInt(3, assigneModel.getRequestid());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");


        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<LoanRequestsByParametar> GetLoanRequestsByParametar(Connection connection, String parametarName, String parametarValue) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1, parametarName);
            ps.setString(2, parametarValue);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(
                        rs.getLong(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public void CreateLoanRequest(Connection connection, LoanRequest loanRequest) throws Exception
    {
        LoanRequest loanRequest1 = new LoanRequest();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from createloanrequest(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");


            ps.setInt(1, loanRequest.getLoantypeid());
            ps.setString(2, loanRequest.getClient_embg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setString(4, loanRequest.gettKomintent());
            ps.setString(5, loanRequest.getOrg_ime());
            ps.setString(6, loanRequest.getOrg_address());
            ps.setString(7, loanRequest.getOrg_oblik());
            ps.setInt(8, loanRequest.getBr_vraboteni());
            ps.setString(9, loanRequest.getOrg_tel());
            ps.setString(10, loanRequest.getFunckija());
            ps.setString(11, loanRequest.getProfesija());
            ps.setString(12, loanRequest.getStrucna_podgotovka());
            ps.setInt(13, loanRequest.getVkupen_staz());
            ps.setInt(14, loanRequest.getStaz_vo_firma());
            ps.setString(15, loanRequest.getNedviznost());
            ps.setString(16, loanRequest.getAdresa_nedviznost());
            ps.setInt(17, loanRequest.getProceneta_vrednost());
            ps.setInt(18, loanRequest.getBroj_vozila());
            ps.setInt(19, loanRequest.getNeto_plata());
            ps.setInt(20, loanRequest.getKirija_p());
            ps.setInt(21, loanRequest.getDrugi_prihodi());
            ps.setInt(22, loanRequest.getVkupno_prihodi());
            ps.setBoolean(23, loanRequest.isPod_hipoteka());
            ps.setBoolean(24, loanRequest.isPol());
            ps.setInt(25, loanRequest.getPazarna_vrednost());
            ps.setString(26, loanRequest.getTip_vozilo());
            ps.setInt(27, loanRequest.getKirija_r());
            ps.setInt(28, loanRequest.getOsiguruvanje());
            ps.setInt(29, loanRequest.getZiovtni_trosoci());
            ps.setInt(30, loanRequest.getVkupno_rashodi());
            ps.setString(31, loanRequest.getKreditna_linija());
            ps.setString(32, loanRequest.getTip_kredit());
            ps.setInt(33, loanRequest.getBaran_iznos());
            ps.setInt(34, loanRequest.getRok_otplata());
            ps.setString(35, loanRequest.getObezbeduvanje());
            ps.setString(36, loanRequest.getOpis_obezbeduvanje());
            ps.setString(37, loanRequest.getValuta());
            ps.setInt(38, loanRequest.getDocid());
            ps.setInt(39, loanRequest.getComment_id());
            ps.setInt(40, loanRequest.getBroj_dosie());
            ps.setString(41, loanRequest.getUser_embg());
            ps.setInt(42, loanRequest.getLice_dohod_vo_stbbt());
            ps.setInt(43, loanRequest.getStatus());
            ps.setString(44, loanRequest.getAssigneto());
            ps.setString(45, loanRequest.getAssignefrom());
            ps.setInt(46, loanRequest.getGrejs_period());
            ps.setBoolean(47, loanRequest.isVozilo());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void AddNewWarningByLoanID(Connection connection, LoanWarning loanWarning) throws Exception
    {
        // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from addnewwarningbyloanid(?,?,?,?,?)");
            // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanWarning.getLoanId());
            ps.setString(2, loanWarning.getWarrningDetails());
            ps.setString(3, loanWarning.getWarrningDate());
            ps.setString(4, loanWarning.getCreatedBy());
            ps.setString(5, loanWarning.getNextContact());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public LoanRequest UpdateLoanRequestByID(Connection connection, int loanTypeID, LoanRequest loanRequest) throws Exception
    {
       // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from updateloanrequestbyid(?,?,?,?)");
           // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanTypeID);
            ps.setString(2, loanRequest.getClient_embg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setInt(4, loanRequest.getBaran_iznos());

            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            loanRequest.setLoantypeid(loanTypeID);
            return loanRequest;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<KreditenOdborGroups> GetKreditenOdborGroups(Connection connection) throws Exception
    {
        List<KreditenOdborGroups> t_items = new ArrayList<KreditenOdborGroups>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getkreditenodborgroups()");
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                KreditenOdborGroups p_eden = new KreditenOdborGroups(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }





}
