package org.activiti;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

@Component
public class RequestService implements JavaDelegate {

    public void storeRequest() {
        System.out.println("Storing request ...");
    }
    public void execute(DelegateExecution execution) throws Exception {
        //String var = (String) execution.getVariable("input");
        //var = var.toUpperCase();
        //execution.setVariable("input", var);
        System.out.println("vleze vo generiranje na dokument");
    }
}
