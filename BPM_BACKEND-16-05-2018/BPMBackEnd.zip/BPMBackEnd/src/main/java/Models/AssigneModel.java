package Models;

public class AssigneModel {
    private String assigneTo;
    private String assigneFrom;
    private int requestid;

    public AssigneModel() {
    }

    public AssigneModel(String assigneTo, String assigneFrom, int requestid) {
        this.assigneTo = assigneTo;
        this.assigneFrom = assigneFrom;
        this.requestid = requestid;
    }

    public String getAssigneTo() {
        return assigneTo;
    }

    public void setAssigneTo(String assigneTo) {
        this.assigneTo = assigneTo;
    }

    public String getAssigneFrom() {
        return assigneFrom;
    }

    public void setAssigneFrom(String assigneFrom) {
        this.assigneFrom = assigneFrom;
    }

    public int getRequestid() {
        return requestid;
    }

    public void setRequestid(int requestid) {
        this.requestid = requestid;
    }
}
