package Models;

import org.activiti.bpmn.model.parse.Warning;

public class WarningsByLoanID {

   int lonanid;
   String embg;

    public WarningsByLoanID(int lonanid, String embg, String firstname, String lastname, String warrningdatte) {
        this.lonanid = lonanid;
        this.embg = embg;
        this.firstname = firstname;
        this.lastname = lastname;
        this.warrningdatte = warrningdatte;
    }

    String firstname;
   String lastname;
   String warrningdatte;

    public int getLonanid() {
        return lonanid;
    }

    public void setLonanid(int lonanid) {
        this.lonanid = lonanid;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getWarrningdatte() {
        return warrningdatte;
    }

    public void setWarrningdatte(String warrningdatte) {
        this.warrningdatte = warrningdatte;
    }
}
