package Models;

public class WarningsDetailsByWarrningID {

 private String arrningType;
 private String sendDate;
 private String warrningDetails;
 private String embg;

    public WarningsDetailsByWarrningID() {
    }

    public WarningsDetailsByWarrningID(String arrningType, String sendDate, String warrningDetails, String embg) {
        this.arrningType = arrningType;
        this.sendDate = sendDate;
        this.warrningDetails = warrningDetails;
        this.embg = embg;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getArrningType() {
        return arrningType;
    }

    public void setArrningType(String arrningType) {
        this.arrningType = arrningType;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getWarrningDetails() {
        return warrningDetails;
    }

    public void setWarrningDetails(String warrningDetails) {
        this.warrningDetails = warrningDetails;
    }
}

