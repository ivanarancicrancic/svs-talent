package Models;

public class CommentsForLoanRequestID {

    private String comment;
    private String lice;
    private String datum_vreme;

    public CommentsForLoanRequestID(String comment, String lice, String datum_vreme) {
        this.comment = comment;
        this.lice = lice;
        this.datum_vreme = datum_vreme;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getLice() {
        return lice;
    }

    public void setLice(String lice) {
        this.lice = lice;
    }

    public String getDatum_vreme() {
        return datum_vreme;
    }

    public void setDatum_vreme(String datum_vreme) {
        this.datum_vreme = datum_vreme;
    }
}
