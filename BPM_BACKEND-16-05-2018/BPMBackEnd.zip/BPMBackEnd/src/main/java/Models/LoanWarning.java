package Models;

public class LoanWarning {

private int loanId;
private String warrningDetails;
private String warrningDate;

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    private String createdBy;
private String nextContact;

    public LoanWarning() {
    }

    public LoanWarning(int loanId, String warrningDetails, String warrningDate, String createdBy, String nextContact) {
        this.loanId = loanId;
        this.warrningDetails = warrningDetails;
        this.warrningDate = warrningDate;
        this.createdBy = createdBy;
        this.nextContact = nextContact;
    }



    public String getWarrningDetails() {
        return warrningDetails;
    }

    public void setWarrningDetails(String warrningDetails) {
        this.warrningDetails = warrningDetails;
    }

    public String getWarrningDate() {
        return warrningDate;
    }

    public void setWarrningDate(String warrningDate) {
        this.warrningDate = warrningDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getNextContact() {
        return nextContact;
    }

    public void setNextContact(String nextContact) {
        this.nextContact = nextContact;
    }
}
