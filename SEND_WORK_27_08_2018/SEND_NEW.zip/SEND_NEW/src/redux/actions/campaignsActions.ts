
import { HANDLE_GET_ALL_CAMPAIGNS } from './actionTypes'
import { getFromBackend } from '../../api/api'

interface ICampaignsAction {
    type: string
    payload?: any
}

interface ICampaignStateAction {
    type: string
    payload?: any
}


const getAllCampaigns = () => {
    const url: string = '/testCampaigns'
    return (dispatch: any, getState:any) => {

       return getFromBackend(url).then( (response : any) => {
            const campaigns = response
             dispatch(getCampaignsDataSuccess(campaigns))
            })
        .catch(error => {
                dispatch(getCampaignsDataFaied(error))
        });

            
        }
    }

    const addCampaign = () => {
        const url: string = '/testCampaigns'
        return (dispatch: any, getState:any) => {
    
           return getFromBackend(url).then( (response : any) => {
                const campaigns = response
                 dispatch(getCampaignsDataSuccess(campaigns))
                })
            .catch(error => {
                    dispatch(getCampaignsDataFaied(error))
            });
    
                
            }
        }
    
        const editCampaign = () => {
            const url: string = '/testCampaigns'
            return (dispatch: any, getState:any) => {
        
               return getFromBackend(url).then( (response : any) => {
                    const campaigns = response
                     dispatch(getCampaignsDataSuccess(campaigns))
                    })
                .catch(error => {
                        dispatch(getCampaignsDataFaied(error))
                });
        
                    
                }
            }


const getCampaignsDataSuccess = (campaignsData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: campaignsData
    }
}
const getCampaignsDataFaied = (error: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: error
    }
}

export {
    getAllCampaigns, ICampaignsAction, addCampaign, editCampaign, ICampaignStateAction
}
