// import { Action } from 'redux'
import { ICampaignStateAction } from '../actions/campaignsActions'
import { HANDLE_SET_SELECTED_CAMPAIGN } from '../actions/actionTypes'
export interface ISelectionCampaignData {
    selectedCampaign: string

}

const INITIAL_STATE: ISelectionCampaignData = {
    selectedCampaign:''
}

export function selectionReducer(state: ISelectionCampaignData = INITIAL_STATE, action: ICampaignStateAction): ISelectionCampaignData {
    switch(action.type) {
        case HANDLE_SET_SELECTED_CAMPAIGN:
        console.log("CALLLED HANDLE_SET_SELECTED_CAMPAIGN");  
        return {
            ...state,
            selectedCampaign: action.payload
          
          }; 
   
        default:
            return state
    }
}


