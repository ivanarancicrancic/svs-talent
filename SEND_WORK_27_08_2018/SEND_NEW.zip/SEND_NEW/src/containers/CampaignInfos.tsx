// import * as React from 'react'
// import { connect } from 'react-redux'
// import { editAndGetCampaigns, getListedTrackers} from '../redux/actions/localCampaignsActions'
// import { ITracker, IContent, } from '../models/CampaignsModelHelper'
// import { IRootState } from '../redux/index';
// import './DashboardContainer/DashboardLayout.css';
// import {Link} from "react-router-dom";
// import '../components/Dashboard/EditCampaign/TrackerImages.css';
// // import CampaignInfo from '../components/Dashboard/EditCampaign/CampaignInfo';
// // import store from '../redux/store/store'

// interface ICampaignInfosState {
//     entry: string
//     tracker?: ITracker[],
//     contents?: IContent[], 
//     // campaignsData?: IRealCampaign[],
//      error?: any

// }
// interface ICampaignInfosProps {
//     getAllTrackers: any,
//     // getAllContents: any,
//     editCampaignData: any,
//     // campaignsData: any
//     tracker: any,
//     // contents: any
// }

// class CampaignInfos extends React.Component<ICampaignInfosProps, ICampaignInfosState> {
//     constructor(props: ICampaignInfosProps) {
//         super(props)
//         this.state = {
//             entry: ''
//             //  campaignsData: [],
//             //  error: false
//         }
//     }

//     public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
//         event.preventDefault()
//         this.props.editCampaignData(Number(this.state.entry))
//         // this.setState({campaignsData: realCampaignData.campaigns})
//     }

//     /* tslint:disable:no-string-literal */
//    public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
//         event.preventDefault()
//         const entry1 = event.target.value
//         if (entry1 !== 'hello') {
//             this.setState({
//                 entry: entry1
//             })
//         }
//     }
// /* tslint:enable:no-string-literal */

//     public handleKeyPress = (event: any) => {
//         if (event.key === 'Enter') {
//             console.log('do thing')
//             console.log(this.state)
//             this.editCampaign(event)
//         }
//     }

//   public render() {
//         return (
//             <div>
//                 <div>
//                     {/* <span>FORM</span> */}
//                     <br />
//                     <input 
//                         type='text' 
//                         placeholder='ENTRY'
//                         onChange={ e => this.handleAddress(e) }
//                         onKeyPress={ e => this.handleKeyPress(e) }
//                     />
//                     <button
//                         onClick={ e => this.editCampaign(e) }
//                     >
//                     Submit for info
//                     </button>
//                 </div>
//                <div className="grid100">
                   
//     <div className="grid50">
//                     <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
//                         <thead>
//                             <tr>
//                             <th>Tracker ID<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
//                             <th >VufID<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
//                             <th>Image </th>      
//                             </tr>
//                         </thead>
//                         <tbody >
//                         {
//                   this.props.tracker.map((t: ITracker) =>
                   
//                     <tr key={t.id}>
//                       <td>{t.id}</td> 
//                       <td>  {t.vuforiaId} </td>
//                       <td> <img src={t.url} /></td>
//                             <td><Link to="/dashboard/edit" className="bp3-button bp3-icon-edit bp3-minimal" /></td>
                           
//                     </tr>
//                   )
//                     }
//                      <tr>
//                             <td colSpan={5} className="text-center" >
//                                 <a className="bp3-button bp3-icon-add bp3-minimal"/>
//                             </td>
//                             </tr>
//                         </tbody>
//                     </table>
//                 </div>
//                     </div>

//                      <div className="trackerBox">
//                 <div className="trackerLeft">
                   
//                     <div>
//                         <div>
//                             <img src="https://dummyimage.com/100x80/141014/fafafa.jpg" />
//                             <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-trash" /> </button>
//                         </div>
//                 </div>
//                 <div className="trackerRight">
//                     <div> <img src="https://dummyimage.com/240x200/141014/fafafa.jpg" /> </div>
//                     <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
//                 </div>
//             </div>
//             </div>
//             </div>
//         )
//     }


//     public componentDidMount() {
//         this.props.getAllTrackers();
//         // this.props.getAllContents();
//     }

//     public componentWillReceiveProps(newProps: ICampaignInfosProps) {

//         this.setState({
//             ...newProps.tracker,
//             // ...newProps.contents
//         })
//         console.log(this.state)
//     }
// }


// const mapStateToProps = (state: IRootState) => {
//     return {
//         // ...state
//         tracker: state.allTrackers.trackers,
//         // contents: state.allTrackers.realCampaigns,
//         // error: state.allTrackers.error
//     }
// }
// const mapDispatchToProps = (dispatch:any) => {
//     return {
//         getAllTrackers: () => dispatch(getListedTrackers()),
//         // getAllContents: () => dispatch(getListedContents()),
//         editCampaignData: (entry: number) => dispatch(editAndGetCampaigns(entry))
        
//     }
// }
// export default connect(mapStateToProps, mapDispatchToProps)(CampaignInfos)
