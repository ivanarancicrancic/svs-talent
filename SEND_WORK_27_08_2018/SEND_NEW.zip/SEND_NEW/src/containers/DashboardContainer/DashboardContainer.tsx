import * as React from 'react';
import { Translate } from 'react-redux-i18n';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';

import ReactS3Uploader from 'react-s3-uploader'
import Campaigns from '../Campaigns'
// import CampaignInfos from '../CampaignInfos'
// import { IRealCampaign, realCampaignData } from '../../models/CampaignsModelHelper'
import './DashboardLayout.css';
// import {Link} from "react-router-dom";
// import { PATH_CAMPAIGN_EDIT } from '../../router/paths';


const SampleCampaigns = () => {
    return (
        <Campaigns />
    )
}

// const dashboardDisplay = () => {

// return (
//        <CampaignInfos />
// )
// }


 class DashboardContainer extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            token: ""
        }
    }

    public render() {
        return (
            <div>
            <Translate value="test" /><br />
            Token: <input type="text" value={this.state.token} onChange={ (e) => this.setState({token: e.target.value}) } />
            <ReactS3Uploader
                signingUrl="/s3/sign/"
                signingUrlMethod="POST"
                accept="image/*"
                s3path="/"
                // preprocess={ () => {console.log("preprocess")} }
                // onSignedUrl={ () => {console.log("onSignedUrl")} }
                // onProgress={ () => {console.log("onProgress")} }
                // onError={ () => {console.log("onError")} }
                // onFinish={ () => {console.log("onFinish")} }
                signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.state.token }}
                // signingUrlQueryParams={{ additional: query-params }}
                signingUrlWithCredentials={false}      // in case when need to pass authentication credentials via CORS
                uploadRequestHeaders={{}}  // this is the default
                // contentDisposition="auto"
                // scrubFilename={(filename: string) => filename.replace(/[^\w\d_\-.]+/ig, '')}
                server="http://127.0.0.1:8080"
                // inputRef={cmp => this.uploadInput = cmp}
                autoUpload={true}
                />
                 <div>
                 
                 { SampleCampaigns() }
                {/* { dashboardDisplay() } */}
                 </div>
                 
                     <div>
                     <div className="grid100"> 
                   <div className="grid45">
                    <table className="table campaignTable bp3-html-table bp3-html-table-bordered">
                        <thead>
                            <tr>
                            <th colSpan={3}>Bought campaign package</th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                            <td>Bought: 5</td>
                            <td>Used: 3</td>
                            <td>Unused: 2</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
               
            </div>
            </div>

            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, {})(DashboardContainer)