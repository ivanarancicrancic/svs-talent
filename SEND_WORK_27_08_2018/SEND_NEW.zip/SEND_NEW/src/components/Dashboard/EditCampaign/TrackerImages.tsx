import * as React from 'react';
import './TrackerImages.css';

import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedTrackers} from '../../../redux/actions/localCampaignsActions'
import { ITracker } from '../../../models/CampaignsModelHelper'
import { IRootState } from '../../../redux/index';
// import {Link} from "react-router-dom";
import { idCampaign } from '../../../containers/Campaigns';
// import { RouteComponentProps } from 'react-router';

interface IIDTrackerData {
    "id":string,

}

const idTracker: IIDTrackerData = {
    "id":''
}

interface ICampaignInfosState {
    entry: string,
    tracker?: ITracker[],
     error?: any,
     deleted? : string

}
interface ICampaignInfosProps {
    getAllTrackers: any,
    editCampaignData: any,
    tracker: any
}

type IProps = ICampaignInfosProps

class TrackerImages extends React.Component<IProps, ICampaignInfosState> {

    constructor(props: IProps) {
        super(props)
        this.state = {
            entry: '',
            deleted: 'false'
        }
    }

    // public deleteTracker(event: React.MouseEvent<HTMLButtonElement>) {
    //     event.preventDefault()
    //     this.props.editCampaignData(Number(this.state.entry))
    //     // this.setState({campaignsData: realCampaignData.campaigns})
    // }

    public deleteTracker(id:string) {
        // event.preventDefault()
        this.setState({deleted: 'true'});
        this.props.editCampaignData(id);
        console.log(" STATE FOR DELETE" + this.state);
        // this.props.getAllTrackers(idCampaign.id);
        // this.setState({campaignsData: realCampaignData.campaigns})
        
    }


    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }


    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
            // this.deleteTracker(event)
        }
    }

    public postSelectedHandler = (id:string) => {
        console.log("Selected tracker! With id: " + id);
        // this.setState({selectedCampaignId: id});
        //    console.log("Changed state id: " + this.state.selectedCampaignId);
        // this.props.editSelectedCampaign(id)
        idTracker['id'] = id;

    }

  /* tslint:enable:no-string-literal */
    
    public render() {
        return (
            <div className="trackerBox">
            
                <div className="trackerLeft">
                    <div>
                    {
                  this.props.tracker.map((t: ITracker) =>
                  
                  <div key= {t.id}  onClick={() => this.postSelectedHandler(t.id)}>
                    <img src= {t.url} />
                    <button className="bp3-button bp3-minimal"  onClick={() => this.deleteTracker(t.id) }> <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                  </div>
                  )
                    }
                </div>
                    <div>
                    <button className="bp3-button bp3-minimal" ><span className="bp3-icon-standard bp3-icon-add" /> </button>
                    </div>
                </div>
                <div className="trackerRight">
                 
                <div> <img src="http://bioneers.org/wp-content/uploads/2017/11/ext-200x300.jpg" /> </div>
                 
                   <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                </div>
            </div>
        )
    }

    public componentDidMount() {
        this.props.getAllTrackers(idCampaign.id);
    }

    public componentWillReceiveProps(newProps: ICampaignInfosProps) {
        // if(this.state.deleted === 'true')
        // this.props.history.replace('http://localhost:3000/dashboard/edit/' + idCampaign.id);
    //    {      console.log("This will be reloaded!!!");
            this.props.getAllTrackers(idCampaign.id);}
        // this.setState({deleted: 'false'});
        // console.log(this.state)
    // }
    
}


const mapStateToProps = (state: IRootState) => {
    return {
        // ...state
        tracker: state.allTrackers.trackers,
        // contents: state.allTrackers.realCampaigns,
        // error: state.allTrackers.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllTrackers: (idCam: string) => dispatch(getListedTrackers(idCam)),
        // getAllContents: () => dispatch(getListedContents()),
        editCampaignData: (entry: string) => dispatch(editAndGetCampaigns(entry))
        
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(TrackerImages)


