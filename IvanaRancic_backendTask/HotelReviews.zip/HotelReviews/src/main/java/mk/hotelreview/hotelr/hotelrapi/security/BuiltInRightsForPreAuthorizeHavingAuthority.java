package mk.hotelreview.hotelr.hotelrapi.security;

public final class BuiltInRightsForPreAuthorizeHavingAuthority {

    private static final String HAS_AUTHORITY_PREFIX = "hasAuthority('";
    private static final String HAS_AUTHORITY_SUFFIX = "')";

    public static final String HOTEL_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.HOTEL_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String HOTEL_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.HOTEL_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String HOTEL_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.HOTEL_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String HOTEL_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.HOTEL_GET + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String REVIEWS_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.REVIEWS_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String REVIEWS_LIST_FOR_HOTEL = HAS_AUTHORITY_PREFIX + BuiltInRights.REVIEWS_LIST_FOR_HOTEL + HAS_AUTHORITY_SUFFIX;
    public static final String REVIEW_LIKE = HAS_AUTHORITY_PREFIX + BuiltInRights.REVIEW_LIKE + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String USER_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.USER_GET + HAS_AUTHORITY_SUFFIX;

    public static final String ADMIN_RIGHT = HAS_AUTHORITY_PREFIX + BuiltInRights.ADMIN_RIGHT + HAS_AUTHORITY_SUFFIX;

    private BuiltInRightsForPreAuthorizeHavingAuthority() {
        // NO-OP utility class
    }

}
