package mk.hotelreview.hotelr.hotelrapi.model.request;
import javax.validation.constraints.NotBlank;

public class EditCotnentModel {
    @NotBlank
    private String name;

    private String type;

    private int weight;

    public EditCotnentModel() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }


}
