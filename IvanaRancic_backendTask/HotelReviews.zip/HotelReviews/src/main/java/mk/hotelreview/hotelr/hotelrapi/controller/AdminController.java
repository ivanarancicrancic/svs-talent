package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateReviewModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelOverviewModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelReviewModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.UserModelForAdmin;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.AdminService;
import mk.hotelreview.hotelr.hotelrapi.service.HotelReviewService;
import mk.hotelreview.hotelr.hotelrapi.service.HotelService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api")
public class AdminController {

    private final AdminService adminService;

    private final HotelService hotelService;

    private final HotelReviewService hotelReviewService;

    public AdminController(AdminService adminService, HotelService hotelService, HotelReviewService hotelReviewService) {
        this.adminService = adminService;
        this.hotelService = hotelService;
        this.hotelReviewService = hotelReviewService;
       }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/users", method = RequestMethod.GET)
    public List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/hotels", method = RequestMethod.GET)
    public List<HotelOverviewModel> listAllHotels() {
        return hotelService.findAllHotels().stream()
                .map(HotelOverviewModel::new)
                .collect(Collectors.toList());
    }

//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
//    @RequestMapping(value = "/admin/hotels/{userId}", method = RequestMethod.GET)
//    public List<HotelOverviewModel> listFavoriteHotelsForUser(@PathVariable long userId) {
//        User user = adminService.getUserByID(userId).orElseThrow(NoSuchElementException::new);
//        return hotelService.getAllFavoriteHotelsForUser(user).stream()
//                .map(HotelOverviewModel::new)
//                .collect(Collectors.toList());
//    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/coupon", method = RequestMethod.POST)
    public HotelReviewModel createReviewForGivenUserAndHotel(@Valid @RequestBody CreateReviewModel model) {
        HotelReview review = hotelReviewService.createHotelReview(model);
        return new HotelReviewModel(review);
    }
}
