package mk.hotelreview.hotelr.hotelrapi.model.response;

import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;

public class SlideshowImageModel {

    private long id;
    private String url;

    public SlideshowImageModel(SlideshowImage slideshowImage) {
        this.id = slideshowImage.getId();
        this.url = slideshowImage.getUrl();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
