package mk.hotelreview.hotelr.hotelrapi.exceptions;

public class InvalidTrackerImageException extends Throwable {
}
