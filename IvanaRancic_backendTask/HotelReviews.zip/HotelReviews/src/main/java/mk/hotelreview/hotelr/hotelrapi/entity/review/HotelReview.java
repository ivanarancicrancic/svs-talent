package mk.hotelreview.hotelr.hotelrapi.entity.review;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="hotelreviews")
public class HotelReview {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_hotelreviews")
    private long id;

    @ManyToOne()
    @JoinColumn(name = "fk_user")
    private User user;

    @ManyToOne()
    @JoinColumn(name = "fk_hotel", nullable = false)
    private Hotel hotel;

    @Column(name = "comment", nullable = false)
    private String comment;

    @Column(name = "likesNumber")
    private int likesNumber;

    @Column(name = "code")
    private String code;

    @ManyToMany(fetch = javax.persistence.FetchType.EAGER)
    @JoinTable(
            name = "hotelreviews_liked_by_users",
            joinColumns = { @JoinColumn(name = "fk_hotelreview") },
            inverseJoinColumns = { @JoinColumn(name = "fk_user") }
    )
    private Set<User> usersWhoLiked = new HashSet<>();


    public HotelReview() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public String getComment(){ return comment;}

    public void setComment(String comment) { this.comment = comment; }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Set<User> getUsersWhoLiked() {
        return usersWhoLiked;
    }

    public void setUsersWhoLiked(Set<User> usersWhoLiked) {
        this.usersWhoLiked = usersWhoLiked;
    }

    public int getLikesNumber() {
        return likesNumber;
    }

    public void setLikesNumber(int likesNumber) {
        this.likesNumber = likesNumber;
    }
}
