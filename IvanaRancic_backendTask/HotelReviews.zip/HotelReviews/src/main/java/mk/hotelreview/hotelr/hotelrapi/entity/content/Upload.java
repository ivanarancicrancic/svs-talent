package mk.hotelreview.hotelr.hotelrapi.entity.content;

import mk.hotelreview.hotelr.hotelrapi.entity.user.User;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "uploads")
public class Upload {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "key_upload")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name = "url", nullable = false)
    private String url;

    @Column(name="created_at", nullable = false)
    private Date createdAt;

    public Upload() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
}
