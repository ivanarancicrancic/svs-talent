package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.exceptions.HotelNotFoundException;
import mk.hotelreview.hotelr.hotelrapi.exceptions.HotelReviewNotFoundException;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateReviewModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.LikeHotelReviewRequestModel;
import mk.hotelreview.hotelr.hotelrapi.repository.HotelRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.HotelReviewRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRepository;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class HotelReviewService {

    private final HotelReviewRepository hotelReviewRepository;
    private final HotelRepository hotelRepository;
    private final UserRepository userRepository;
    private final AdminService adminService;

    public HotelReviewService(HotelReviewRepository hotelReviewRepository, HotelRepository hotelRepository, UserRepository userRepository, AdminService adminService) {
        this.hotelReviewRepository = hotelReviewRepository;
        this.hotelRepository = hotelRepository;
        this.userRepository = userRepository;
        this.adminService = adminService;
    }

    public List<HotelReview> getAllHotelReviews() {
        return hotelReviewRepository.findAll();
    }


    public HotelReview createHotelReview(CreateReviewModel model) throws NoSuchElementException {
        HotelReview hotelReview = new HotelReview();
        Optional<User> user = adminService.getUserByID(model.getUserId());

        hotelReview.setUser(user.orElseThrow(NoSuchElementException::new));
        hotelReview.setHotel(hotelRepository.findById(model.getHotelId()).orElseThrow(NoSuchElementException::new));
        hotelReview.setComment("THIS IS SUCH A GREAT PLACE FOR REST!!");
        return hotelReviewRepository.save(hotelReview);
    }

    public void likeHotelReview(User user, LikeHotelReviewRequestModel model) {
        HotelReview hotelReviewLiked = hotelReviewRepository.findById(model.getHotelReviewId()).get();
        user.getHotelReviewsLiked().add(hotelReviewLiked);
        user.setHotelReviewsLiked(user.getHotelReviewsLiked());
        userRepository.save(user);
    }


    public List<HotelReview> getReviewsForHotel(Hotel hotel) {
        return hotel.getReviews().stream().collect(Collectors.toList());
    }

}
