package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ForbiddenException;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowImageModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.SlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.SlideshowImageModel;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.ContentService;
import mk.hotelreview.hotelr.hotelrapi.service.HotelService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;

@RestController
@RequestMapping("/api")
public class ContentController {
    private final ContentService contentService;
    private final HotelService hotelService;

    public ContentController(ContentService contentService, HotelService hotelService) {
        this.contentService = contentService;
        this.hotelService = hotelService;
    }

//    @DeleteMapping("/hotel/content/{contentId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_DELETE)
//    public boolean deleteContent(@PathVariable long contentId) {
//        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);
//        contentService.deleteContent(content);
//        return true;
//    }
//
//    @PostMapping("/hotel/{hotelId}/slideshow")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
//    public SlideshowContentModel createSlideshowContent(@PathVariable long hotelId, @RequestBody CreateSlideshowContentModel model) {
//
//        Hotel hotel = hotelService.getHotel(hotelId).orElseThrow(ForbiddenException::new);
//        SlideshowContent content = contentService.createSlideshowContent(hotel, model);
//        return new SlideshowContentModel(content);
//    }


    @PostMapping("/slideshow/{slideshowId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_CREATE)
    public SlideshowImageModel createImageToSlideshowContent(@PathVariable long slideshowId, @RequestBody CreateSlideshowImageModel model) {
        SlideshowImage image = contentService.createSlideshowImage(slideshowId, model);
        return new SlideshowImageModel(image);
    }

    @DeleteMapping("/slideshowimage/{imageId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_DELETE)
    public SlideshowImageModel deleteImageFromSlideshowContent(@PathVariable long imageId) {
        SlideshowImage image = contentService.deleteSlideshowImage(imageId);
        return new SlideshowImageModel(image);
    }

//    @PutMapping("/hotel/slideshow/{contentId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public SlideshowContentModel editSlideshowContent(@PathVariable long contentId, @Valid @RequestBody EditSlideshowContentModel model) {
//
//        SlideshowContent content = (SlideshowContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
//        SlideshowContent editedContent = contentService.editSlideshowContent(content, model);
//        return new SlideshowContentModel(editedContent);
//    }

}