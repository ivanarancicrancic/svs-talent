import * as React from 'react';
import './OrderInfo.css';

export default class OrderInfo extends React.Component {

    public render() {
        return (
            <div className="infoBox">
                <h2> Order </h2>
                <p> This is some odred description. </p>
            </div>
        )
    }

}