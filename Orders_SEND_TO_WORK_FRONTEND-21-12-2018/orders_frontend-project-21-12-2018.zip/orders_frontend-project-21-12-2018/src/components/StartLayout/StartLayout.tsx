import * as React from 'react';
import { connect } from 'react-redux';
// import { Link } from "react-router-dom";
import { history } from '../../router';
import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
// import deIcon from '../../assets/images/edit_pencil.svg';
import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import EditableLabel from 'react-editable-label';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
// import { Button } from "@blueprintjs/core";
// import Box from 'react-editable-text/Box';
import { Form, Control } from 'react-redux-form';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { IOrderSaveRequestModel } from '../../redux/order-save/types';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    
}

type IProps = IPropsDispatchMap & IPropsStateMap

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(30, 144, 255, 0.88)',
      width: '100%'
    }
  };

class StartLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modalIsOpen: false,
           modal2IsOpen: false,
           currentOrder: null,
           orderFirstNameToBeSaved: null,
           orderLastNameToBeSaved: null,
           orderCompanyNameToBeSaved: null,
           orderPaymentMethodToBeSaved: null,
           orderShippingWayToBeSaved: null,
           orderAnredeToBeSaved: null,
           orderCountryToBeSaved: null,
           orderStreetToBeSaved: null,
           orderHouseNumberToBeSaved: null,
           orderPostcodeToBeSaved: null,
           orderCityToBeSaved: null,
           orderPhoneNumberToBeSaved: null,
           orderEmailToBeSaved: null,
           orderNetPriceToBeSaved: null,
           orderGrossPriceToBeSaved: null,
           orderNetPriceWDToBeSaved: null,
           orderGrossPriceWDToBeSaved: null,
           orderToSave: null
        

      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.editOrder = this.editOrder.bind(this);
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleCancelOrder = this.handleCancelOrder.bind(this);
    }

    public componentWillMount() {
        Modal.setAppElement('body');
        this.props.orderListFetch();        
        console.log("Date on mount: " + this.state.dateFrom);
    }


    public componentWillReceiveProps(nextProps: IProps) {
            this.setState({filteredOrders: nextProps.filteredOrderData});
            this.setState({currentOrder: nextProps.orderDetailData})
            this.props.orderListFetch();  
            console.log("Filtered orders: " + this.state.filteredOrders);
            
           
    }

public editOrder(){

    console.log("Entered editORder");
    this.setState({modalIsOpen: false}); 
    this.setState({modal2IsOpen: true}); 

}

// public handleChange(event:any) {
//     console.log("orderLastNameToBeSavedDDDD: " + event.target.lastName);
//     // event.preventDefault(); 
//     this.setState({orderLastNameToBeSaved: event.target.lastName});
//     console.log("orderLastNameToBeSaved: " + this.state.orderLastNameToBeSaved);
//   }

  public handleSubmitSaveOrder(value:any) {
    
    console.log("orderFirstNameToBeSaved: " + value.firstName);
    console.log("orderLastNameToBeSaved: " + value.lastName);
   
    const newValues: IOrderSaveRequestModel = {

        order_id: value.order_id,
        orderDate: new Date(),
        paymentMethod: value.paymentMethod,
        shippingWay: value.shippingWay,
        anrede: "anrede",
        firstName: value.firstName,
        lastName: value.lastName,
        companyName: value.companyName,
        country: value.country,
        street: value.street,
        houseNumber: value.houseNumber,
        city: value.city,
        postcode: value.postcode,
        phoneNumber: value.phoneNumber, 
        email: value.email, 
        latest: 1,
        netPrice: value.netPrice,
        grossPrice: value.grossPrice,
        netPriceWD:  value.netPriceWD,
        grossPriceWD: value.grossPriceWD 

    }

    this.props.orderSaveFetch({orderToSave: newValues});
   this.props.orderDetailFetch({order_id: newValues.order_id});
   this.props.orderListFetch();      

   this.setState({modalIsOpen: false}); 
   this.setState({modal2IsOpen: false});
   const p = mapStateToProps;
   console.log(p);
   history.push('/start');

}

public handleCancelOrder(orderid:any) {
    
   
   this.props.cancelOrderFetch({order_id: orderid});
   this.props.orderListFetch();      

   this.setState({modalIsOpen: false}); 
   this.setState({modal2IsOpen: false});
   const p = mapStateToProps;
   console.log(p);
   history.push('/start');

}


public handleClick() {
    console.log('this is:', this);
  }
    
 public allOrderArticles(values:any){
        console.log("entered handle filter");
      
            this.setState({modalIsOpen: true}); 
         
      };


      public onSubmit(values:any) {
            
        // axios({
        //     method: 'get',
        //     url: API_ROOT + '/api/product/' + values.name
        // }).then(response => {
        //     const result = response.data as IProductResponseModel[];
        //     console.log(result);
        //     history.push(`/product/`+ values.name);
        // }).catch(error => {
        //     console.log("Error");
        // });

      
      
      
        // fetch('/api/product/' + values.name, {
        //     method: 'POST',
        //     body: JSON.stringify({
        //         values
        //     }),
        // });
  
       
        // this.props.searchProductByArtileNumberFetch(values.name);
        console.log("Entered onEditOrder with firstName:" + values.firstname);
        // const firstName = values.fisrtname;
        
        history.push(`/start`);
      }


    public selectedRowHandel(order: IOrderResponseModel){
        console.log("SELECTED ORDER: " + order.firstName + order.order_id);
        const order_id = order.order_id;
        this.props.orderDetailFetch({order_id});
        this.props.getOrderArticlesFetch({order_id});
            this.setState({modalIsOpen: true}); 
    }

 
    
    public handleFilter(values:any){
        console.log("entered handle filter");
        values.preventDefault();
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
         
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
        
        console.log("State for selected dateFrom: " + this.state.dateFrom) 
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
    //  this.setState({dateTo: entryDate}); 
    
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
     console.log("State for selected dateTo: " + this.state.dateTo)
 
  };


  public closeModal() {
      console.log("Modal closed!!!");
    this.setState({modalIsOpen: false});
  }


 public renderOrderList() {

    let totalNetPrice = 0;
    let totalGrossPrice = 0;
    let totalNetPriceWD = 0;
    let totalGrossPriceWD = 0;
   
    let totalNetPriceF = 0;
    let totalGrossPriceF = 0;
    let totalNetPriceWDF = 0;
    let totalGrossPriceWDF = 0;
   
    if(this.props.orderData)
            {
                console.log("this.props.filteredOrderData != null");
            const ordersNetPrices = this.props.orderData.map( order => {
                return (
                    parseInt(order.netPrice, 10)
                 )
             })

             const ordersGrossPrices = this.props.orderData.map( order => {
                return (
                    parseInt(order.grossPrice, 10)
                 )
             })
            
             const ordersNetPricesWD = this.props.orderData.map( order => {
                return (
                    parseInt(order.netPriceWD, 10)
                 )
             })

             const ordersGrossPricesWD = this.props.orderData.map( order => {
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
             })

        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPrice = ordersNetPrices.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPrice = ordersGrossPrices.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWD = ordersNetPricesWD.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWD = ordersGrossPricesWD.reduce(summingReducer3, 0);
          }
          else { 
            totalNetPrice = 0;
            totalGrossPrice = 0;
            totalNetPriceWD = 0;
            totalGrossPriceWD = 0;     
              } 

    if(this.props.filteredOrderData)
            {
                console.log("this.props.filteredOrderData != null");
        
            const ordersNetPricesF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPrice, 10)
                 )
             })

             const ordersGrossPricesF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.grossPrice, 10)
                 )
             })
            
             const ordersNetPricesWDF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPriceWD, 10)
                 )
             })

             const ordersGrossPricesWDF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
             })

     
        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPriceF = ordersNetPricesF.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPriceF = ordersGrossPricesF.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWDF = ordersNetPricesWDF.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWDF = ordersGrossPricesWDF.reduce(summingReducer3, 0);
     
          }
          else {
              
            totalNetPriceF = 0;
            totalGrossPriceF = 0;
            totalNetPriceWDF = 0;
            totalGrossPriceWDF = 0;

            }      
            console.log("FInal totalNetPrice: " + totalNetPrice);
            console.log("FInal totalGrossPrice: " + totalGrossPrice);
            console.log("FInal totalNetPriceWD: " + totalNetPriceWD);
            console.log("FInal totalGrossPriceWD: " + totalGrossPriceWD);


        if(!this.props.orderData && !this.props.filteredOrderData) 
         {    
             console.log("this.props.orderData: " + this.props.orderData);
            console.log("this.props.orderData and this.props.filteredOrderData is null");
            return null;
         }
         else if(!this.props.orderData)
             {
                 if(this.props.filteredOrderData)
                 {
                     if(this.props.filteredOrderData[0].latest === 0){
                         return(
                              <div>NO FOUND</div>

                         )
                     }
                    else{
            return (
                <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>Country </th>
                                    <th>Company</th>
                                    <th>Net price </th>
                                    <th>Gross price </th>
                                    {/* <th>Difference </th> */}
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    {/* <th>Difference (without delivery)</th> */}
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)} className = "order_hovered">
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.companyName} </td>
                                    <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    {/* <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td> */}
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                                
                                </tr>
                            )
                        })}
                      
                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPriceF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPriceF
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr> */}

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWDF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWDF
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr> */}

                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
            ) 
        }
           }
             else { return null;} 
        }

        else if(!this.props.filteredOrderData)
        {
            if(this.props.orderData)
            {
       return (
           <div className="dashboardTable">
               <table className="table bp3-html-table bp3-html-table-bordered">
               <thead>                  
               <tr >
                       <th>Order ID</th>
                       <th>Oder DATE</th>
                       <th>FirstName </th>
                               <th>LastName </th>
                               <th>Country </th>
                               <th>Company </th>
                               <th>Net price </th>
                                    <th>Gross price </th>
                                    {/* <th>Difference </th> */}
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    {/* <th>Difference (without delivery)</th> */}
                                   
                       </tr>

               </thead>
               <tbody>
                   
                   {this.props.orderData.map( order => {
                       return (
                           <tr key={order.order_id}  className = "order_hovered">
                               <td onClick={(e) => this.selectedRowHandel(order)}><b>{order.order_id}</b></td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.orderDate} </td> 
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.firstName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.lastName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.country} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.companyName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPrice} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPrice} </td>
                                    {/* <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td> */}
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPriceWD} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPriceWD} </td>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    <td><button type="button" onClick={(e) => this.handleCancelOrder(order.order_id)} className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                           </tr>
                       )
                   })}
                 
                  
                 <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr> */}

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr> */}
                   <tr>
                   <td colSpan={5} className="text-center" >
                      <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                   </td>
                   </tr>
               </tbody>
               </table>
           </div>
       ) 
      }
        else { return null;} 
   }
        
         else {
            console.log("!this.props.filteredOrderData =! NULL !!!!!!!!!!!!!!!!! AND this.props.orderData =! NULL");
           
            if(this.props.filteredOrderData[0].latest === 0){
                console.log("LATEST 0!!!");
                return(
                    <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>Country </th>
                                    <th>Company </th>
                                    <th>Net price </th>
                                    <th>Gross price </th>
                                    {/* <th>Difference </th> */}
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    {/* <th>Difference (without delivery)</th> */}
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)} className = "order_hovered"> 
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.companyName} </td>
                                    <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    {/* <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td> */}
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>

                                </tr>
                            )
                        })}
                      
                      
                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPriceF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPriceF
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr> */}

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWDF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWDF
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr> */}

                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
                )
            }
           else{
             if(this.props.orderData[0].latest> this.props.filteredOrderData[0].latest)
      {
          console.log("this.props.orderData[0].latest> this.props.filteredOrderData[0].latest !!!!!!!!!!");
             return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <thead>                  
                <tr>
                        <th>Order ID</th>
                        <th>Oder DATE</th>
                        <th>FirstName </th>
                                <th>LastName </th>
                                <th>Country </th>
                                <th>Company </th>
                                <th>Net price </th>
                                    <th>Gross price </th>
                                    {/* <th>Difference </th> */}
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    {/* <th>Difference (without delivery)</th> */}
                        </tr>

                </thead>
                <tbody>
                    
                    {this.props.orderData.map( order => {
                        return (
                            <tr key={order.order_id} onClick={(e) =>  this.selectedRowHandel(order)} className = "order_hovered">
                                <td><b>{order.order_id}</b></td>
                                <td>{order.orderDate} </td> 
                                <td>{order.firstName} </td>
                                <td>{order.lastName} </td>
                                <td>{order.country} </td>
                                <td>{order.companyName} </td>
                                <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    {/* <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td> */}
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                            </tr>
                        )
                    })}
                  

                    
                    <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr> */}

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    {/* <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr> */}

                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                    </td>
                    </tr>
                </tbody>

                </table>
            </div>
        )
    }
    else {

        console.log("this.props.orderData[0].latest < this.props.filteredOrderData[0].latest");
        return (
            <div className="dashboardTable">
            <table className="table bp3-html-table bp3-html-table-bordered"  >
            <thead>                  
            <tr>
                    <th>Ooorder ID</th>
                    <th>Oder DATE</th>
                    <th>FirstName </th>
                    <th>LastName </th>
                     <th>Country </th>
                     <th>Company </th>
                    <th>Net price </th>
                            <th>Gross price </th>
                            {/* <th>Difference </th> */}
                            <th>Net price (without delivery) </th>
                            <th>Gross price (without delivery)</th>
                            {/* <th>Difference (without delivery)</th> */}
                    </tr>

            </thead>
            <tbody>
                
                {this.props.filteredOrderData.map( order => {
                    return (
                        <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)} className = "order_hovered">
                            <td><b>{order.order_id}</b></td>
                            <td>{order.orderDate} </td> 
                            <td>{order.firstName} </td>
                            <td>{order.lastName} </td>
                            <td>{order.country} </td>
                            <td>{order.companyName} </td>
                            <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    {/* <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td> */}
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
                                    {/* <img className="bp3-button imgs" src={deIcon} alt="logo" /> */}
                                    <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                                     
                        </tr>
                    )
                })}
              
              <tr>
            <td colSpan={5} className="text-center td" >
               Total net price:  &nbsp;
              { totalNetPriceF
              } 
            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center td1" >
               Total gross price: &nbsp;
              { totalGrossPriceF
              } 

            </td>
            </tr>

            {/* <tr>
            <td colSpan={5} className="text-center" >
               Difference: &nbsp;
              { totalNetPrice - totalGrossPrice
              } 
              
            </td>
            </tr> */}

              <tr>
            <td colSpan={5} className="text-center td" >
               Total net price (without delivery): &nbsp;
              { totalNetPriceWDF
              } 
            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center td1" >
               Total gross price (without delivery): &nbsp;
              { totalGrossPriceWDF
              } 

            </td>
            </tr>

            {/* <tr>
            <td colSpan={5} className="text-center" >
               Difference (without delivery): &nbsp;
              { totalNetPriceWD - totalGrossPriceWD
              } 
              
            </td>
            </tr> */}

                <tr>
                <td colSpan={5} className="text-center" >
                   <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                </td>
                </tr>
            </tbody>
            </table>
        </div>
        )
    }
    }
}
}

public openModal(){
    this.setState({modalIsOpen: true});

}

    public render() {
        
        console.log("this.state.modalIsOpen: " + this.state.modalIsOpen);
        if(this.props.orderDetailData){
            const order_id= this.props.orderDetailData.order_id
            if(!this.props.orderArticlesData)
            {
            //  this.openModal();
            console.log("!!!!  this.props.orderDetailData = NULL");
           
        return (
            <div className="grid100">
    <Modal 
    // style={{ overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.75)' }}}
      isOpen={this.state.modalIsOpen}
    //   onAfterOpen={this.afterOpenModal}
    
    // onRequestClose={this.closeModal}
      style={customStyles}
      contentLabel="Example Modal"
    >
      {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
    
      <form>
     <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
     
      <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
      <br/>
 
     <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.firstName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.lastName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.companyName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        />  </div><br/>
     <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                            initialValue={this.props.orderDetailData.paymentMethod}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.email}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.orderDate}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.phoneNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.shippingWay}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.street}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.houseNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.postcode}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.city}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.country}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div>
     <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
     <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
     <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
     <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
     <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
     <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
     
        {/* <input /> */}
       <br/>


       <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id}) } > Included products >> </button>
      
        <div className = "modalTText">
        <button onClick={(e) => this.handleClick()}>
        Click me
      </button>
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button" onClick={this.editOrder} > Edit order </button>
       </div>
                
      </form>
    </Modal>

      <Modal 
    // style={{ overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.75)' }}}
      isOpen={this.state.modal2IsOpen}
    //   onAfterOpen={this.afterOpenModal}
    
    // onRequestClose={this.closeModal}
      style={customStyles}
      contentLabel="Example Modal"
    >
      {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
    
      <form>
     <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
     
      <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>EDIT ORDER DETAILS</div>
      <br/>
 
     <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.firstName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.lastName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.companyName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        />  </div><br/>
     <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                            initialValue={this.props.orderDetailData.paymentMethod}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.email}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.orderDate}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.phoneNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.shippingWay}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.street}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.houseNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.postcode}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.city}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.country}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div>
     <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
     <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
     <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
     <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
     <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
     <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
     
        {/* <input /> */}
       <br/>



       <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id}) } > Included products >> </button>
      
        <div className = "modalTText">
        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save changes </button>
       </div>
                
      </form>
    </Modal>
            
             <b> Filter orders by date range: </b> <br/>
             <div>
               

     <form onSubmit={ this.handleFilter }>
         <div className="bp3-input-group">
     <b>  Start date: </b> 
                             
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

        </form>

      </div>
              <br/>
                {this.renderOrderList()}   
            </div>
        )
    }
   else{
    let start =0;
    console.log("!!!!  this.props.orderDetailData = NULL");
    console.log("!!!!  this.props.orderArticlesData ! = NULL");
    return (
        <div className="grid100">
         
<Modal 
// style={{ overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.75)' }}}
  isOpen={this.state.modalIsOpen}
//   onAfterOpen={this.afterOpenModal}
  onRequestClose={this.closeModal}
  style={customStyles}
  contentLabel="Example Modal"
>
  {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
 <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
 
  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
  <br/>

 <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.firstName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.lastName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.companyName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    />  </div><br/>
 <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                        initialValue={this.props.orderDetailData.paymentMethod}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.email}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.orderDate}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.phoneNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.shippingWay}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.street}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.houseNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.postcode}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.city}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.country}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div>
 <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
 <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
 <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
 <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
 <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
 <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
  <form >
    {/* <input /> */}
   <br/>


              
            <div  style={{ position: "absolute", right: 80, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
     {this.props.orderArticlesData.map( orderArticle => {
                     start++;
                // console.log(" top:150 + start * 20 : " +  150 + start * 20 );
                const pos =  150 + start * 20;
                console.log("pos: " + pos);
                     return (
                
                        <div key={orderArticle.orderarticle_id}>
                           
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 200, height: 200, position: "absolute", right: 70, top: pos }} /> </tr>
                           <tr> <div style={{position: "absolute", right: 20, top: 370 }} > <b> ARTICLE NAME:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                           <tr> <div style={{position: "absolute", right: 135, top: 390 }} > <b> ARTICLE QUANTITY:  </b> &nbsp; {orderArticle.articleQuantity} </div></tr> 
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
                                    {/* <img className="bp3-button imgs" src={deIcon} alt="logo" /> */}
                                    {/* <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product from order </button></td> */}
                           </div>          
                       
                    )
                })}
              
         



    {/* <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
    <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id})}> Included products >> </button> */}
  
    <div className = "modalTText">
    {/* <button onClick={(e) => this.handleClick()}>
        Click me
      </button> */}
    <button type="button" className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={this.editOrder} > Edit order</button>
   </div>
            
  </form>
</Modal>
        

<Modal 
// style={{ overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.75)' }}}
  isOpen={this.state.modal2IsOpen}
//   onAfterOpen={this.afterOpenModal}
  onRequestClose={this.closeModal}
  style={customStyles}
  contentLabel="Example Modal"
>
  {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
 <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
 
  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>EDIT ORDER DETAILS</div>
  <br/>



  <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitSaveOrder(info) }
          // onSubmit={ (info) => this.onSubmit1() }
        // validateOn="submit"
                    
                >   
                 <tr>
                   <td>
               
                      <div>
                      <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: </b></label>  &nbsp;  &nbsp;  
                      <Control.text
                            className="bp3-input"
                            model=".order_id"
                            defaultValue= {this.props.orderDetailData.order_id} 
                            // onChange={this.handleChange}
                        />
                       
 
                        <br/>

                        <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
                        <Control.text
                            className="bp3-input"
                            model=".firstName"
                            defaultValue={this.props.orderDetailData.firstName} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button>

                        <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".lastName"
                            defaultValue={this.props.orderDetailData.lastName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".companyName"
                            defaultValue={this.props.orderDetailData.companyName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".paymentMethod"
                            defaultValue={this.props.orderDetailData.paymentMethod} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                          <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".shippingWay"
                            defaultValue={this.props.orderDetailData.shippingWay} 
                            // onChange={this.handleChange}
                        />
                     <br/>


                                             <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".email"
                            defaultValue={this.props.orderDetailData.email} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".phoneNumber"
                            defaultValue={this.props.orderDetailData.phoneNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                            <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".street"
                            defaultValue={this.props.orderDetailData.street} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    
                    <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".houseNumber"
                            defaultValue={this.props.orderDetailData.houseNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".postcode"
                            defaultValue={this.props.orderDetailData.postcode} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".city"
                            defaultValue={this.props.orderDetailData.city} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".country"
                            defaultValue={this.props.orderDetailData.country} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPrice"
                            defaultValue={this.props.orderDetailData.netPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>


 <label htmlFor="grossPrice" className="bp3-file-input"><b>Gross price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPrice"
                            defaultValue={this.props.orderDetailData.grossPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPriceWD"
                            defaultValue={this.props.orderDetailData.netPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     

 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderDetailData.grossPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     {/* <label hidden={true} htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderSavedData} 
                            // onChange={this.handleChange}
                        />
                     <br/> */}

                         {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Save order >> </button>  */}
                    </div> 
                  
                   </td>
            

         </tr>
         <tr>
       
                        
                        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button>
                 
                        </tr>
     
        </Form>


 
  <form >
    {/* <input /> */}
   <br/>


              
            <div  style={{ position: "absolute", right: 80, top: 130 }}> <b>PRODUCTS INCLUDED: </b></div>
     {this.props.orderArticlesData.map( orderArticle => {
                     start++;
                // console.log(" top:150 + start * 20 : " +  150 + start * 20 );
                const pos =  120 + start * 20;
                console.log("pos: " + pos);
                     return (
                
                        <div key={orderArticle.orderarticle_id}>
                
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 200, height: 200, position: "absolute", right: 70, top: pos }} /> </tr>
                           <tr> <div style={{position: "absolute", right: 20, top: 370 }} > <b> ARTICLE NAME:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                           <tr> <div style={{position: "absolute", right: 135, top: 390 }} > <b> ARTICLE QUANTITY:  </b> &nbsp; {orderArticle.articleQuantity} </div></tr>
                           <tr><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red", position: "absolute", right: 100, top: 410}} > delete from order </button></tr>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit" > <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
                                    {/* <img className="bp3-button imgs" src={deIcon} alt="logo" /> */}
                                   
                           </div>          
                       
                    )
                })}
              
         



    {/* <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
    <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id})}> Included products >> </button> */}
  
    <div className = "modalTText">
    <button onClick={(e) => this.handleClick()}>
        Click me
      </button>
    <button type="button" className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={this.editOrder}> Save order</button>
   </div>
            
  </form>
</Modal>
        



         <b> Filter orders by date range: </b> <br/>
         <div>
           

 <form onSubmit={ this.handleFilter }>
     <div className="bp3-input-group">
 <b>  Start date: </b> 
                         
      <DatePicker 
      onChange={this.handleDateFrom}
      value={this.state.dateFrom}
      />   
      &nbsp; &nbsp; &nbsp;
      <b> End date: </b>
      <DatePicker 
   onChange={this.handleDateTo} 
   value={this.state.dateTo} 
   />
      &nbsp; &nbsp; &nbsp;
                </div>
                
                <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

    </form>

  </div>
          <br/>
            {this.renderOrderList()}   
        </div>
    )


   }

    }

    else {
        return (
            <div className="grid100">
   
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderOrderList()}   
            </div>
        )
    }
}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(StartLayout)


// {this.props.orderArticlesData.map( orderArticle => {
//     return (
//         <tr key={orderArticle.orderarticle_id} className = "order_hovered">
//             <td><b>{orderArticle.orderarticle_id}</b></td>
//             <td>{orderArticle.order_id} </td> 
//             <td>{orderArticle.articleName} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>

//                     {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
//                     {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
//                     {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
//                     <img className="bp3-button imgs" src={deIcon} alt="logo" />
//                     <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                     
//         </tr>
//     )
// })}

// {this.props.orderArticlesData.map( orderArticle => {
//     return (

//         <tr key={orderArticle.orderarticle_id} >
//             <td><b>{orderArticle.order_id}</b></td>
//             <td>{orderArticle.articleName} </td> 
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>
//             <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product </button></td>
                     
//         </tr>
//     )
// })}