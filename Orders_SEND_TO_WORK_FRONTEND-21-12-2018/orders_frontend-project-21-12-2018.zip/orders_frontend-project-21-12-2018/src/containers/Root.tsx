import * as React from 'react';

import { Provider } from 'react-redux';
import { ConnectedRouter } from 'react-router-redux';
import { PersistGate } from 'redux-persist/integration/react';

import { history } from '../router';
import { store, persistor } from '../redux/store';

import App from './App/App'

import PrivateRoute from '../router/PrivateRoute';

import { Switch } from 'react-router';


import { PATH_ROOT } from '../router/paths';

class Root extends React.Component {
    public render() {
      return (
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <ConnectedRouter history={history}>
            <Switch>
              <PrivateRoute path={PATH_ROOT} component={App} />
            </Switch>
          </ConnectedRouter>
        </PersistGate>
      </Provider>
      )
    }
}

export default Root;