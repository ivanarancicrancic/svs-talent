package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public interface CampaignRespository extends JpaRepository<Campaign, Long>
{
    public Optional<Campaign> findById(Long id);
    public void deleteById(Long id);
}
