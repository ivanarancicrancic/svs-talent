package de.diefuturisten.easyr.easyrapi.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.model.request.UserLoginCredientialsModel;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.EXPIRATION_TIME;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.HEADER_STRING;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final AuthenticationManager authenticationManager;

    public JWTAuthenticationFilter(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        try {
            UserLoginCredientialsModel creds = new ObjectMapper()
                    .readValue(request.getInputStream(), UserLoginCredientialsModel.class);

            return authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            creds.getUsername(),
                            creds.getPassword(),
                            new ArrayList<>())
            );
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication auth) throws IOException, ServletException {
        String username = ((User) auth.getPrincipal()).getUsername();
        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
        response.addHeader(HEADER_STRING, TokenHelper.createToken(username, expirationTime));
    }
}
