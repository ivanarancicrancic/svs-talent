package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.*;

@Entity
@Table(name="content_spheres")
public class SphereContent extends Content {

    @Column(name="url", nullable = false)
    private String url;

}
