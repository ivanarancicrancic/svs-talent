package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignListCommand;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowListEntry;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api")
public class CampaignController {

    @Autowired
    CampaignService campaignService;

    @Autowired
    SlideshowService slideshowService;

    public CampaignController(CampaignService campaignService, SlideshowService slideshowService) {
        this.campaignService = campaignService;
        this.slideshowService = slideshowService;
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
    public CampaignListCommand getCampaigns() throws Exception
    {
        System.out.println("Entered /campaigns");
        List<CampaignCommand> campaigns = null;
        String campaign_str = null;
        try{
            campaigns = campaignService.getAllCampaigns();
              CampaignListCommand campaignListCommand = new CampaignListCommand(campaigns);
            System.out.println("BEFORE RETURN: " + campaignListCommand.getCampaigns());
            for(CampaignCommand cc : campaignListCommand.getCampaigns()){

                System.out.println("Campaign ID: " + cc.getId());
            }
            return campaignListCommand;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/campaign/{id}/slideshows")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowListEntry getSlideshowsByCampaign(@PathVariable String id) throws Exception
    {
        System.out.println("Entered /campaign/{id}/slideshows");
        List<SlideshowContent> slideshows = null;
        List<SlideshowContent> allSlideshows = null;
        List<Content> contents = null;
        try{
            contents = campaignService.findById(new Long(id)).getContents();
            allSlideshows = slideshowService.getAllSlideshows();
            for(SlideshowContent slideshowContent: allSlideshows)
            {
                if(slideshowContent.getCampaign().getId() == new Long(id))
                {
                    slideshows.add(slideshowContent);
                }
            }
            return new SlideshowListEntry(slideshows);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/campaign/{id}/slideshows/{id_slideshow}")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowContent getSlideshowBySlideshowId(@PathVariable String id, @PathVariable String id_slideshow) throws Exception
    {
        try{
          SlideshowContent  slideshow = slideshowService.findByCampaignIdAndSlideshowId(new Long(id), new Long(id_slideshow));
            return slideshow;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }



    @GetMapping("/campaign/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    public CampaignCommand showById(@PathVariable String id) throws  Exception{
        System.out.println("entered campaign/show/{id}");
        try{
            CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
            return campaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PostMapping("/campaign/create")
    @ResponseStatus(HttpStatus.CREATED)
    public Campaign createCampaign(@RequestBody Campaign campaignCommand) throws Exception{
        System.out.println("BEFORE CREATING CAMPAIGN: " + campaignCommand.getTracker());


        try{
        Campaign createdCampaignCommand = campaignService.createCampaign(campaignCommand);
        System.out.println("Id of campaign created:" + createdCampaignCommand.getId());
            return createdCampaignCommand;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @PutMapping("/campaign/update")
    @ResponseStatus(HttpStatus.OK)
    public Campaign saveOrUpdate(@RequestBody Campaign campaign) throws  Exception{
        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID:" + campaign.getId());
        Campaign savedCampaign = campaignService.updateCampaign(campaign);
        System.out.println("Id of campaign updated:" + savedCampaign.getId());
        System.out.println("Contents of campaign updated: ");
        for(Content campaignContent1 : savedCampaign.getContents())
            System.out.println("Content: " +  campaignContent1.getName());
        try{
            return campaign;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("campaign/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    public CampaignCommand deleteCampaign(@PathVariable String id){
        System.out.println("Entered deleting campaign");
        CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
        campaignService.deleteCampaign(Long.valueOf(id));
        return campaignCommand;

    }




}
