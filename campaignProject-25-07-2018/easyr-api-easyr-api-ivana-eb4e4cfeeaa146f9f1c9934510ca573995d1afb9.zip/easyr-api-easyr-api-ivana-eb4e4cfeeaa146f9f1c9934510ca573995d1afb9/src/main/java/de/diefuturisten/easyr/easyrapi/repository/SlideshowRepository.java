package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SlideshowRepository extends JpaRepository<SlideshowContent, Long>
{
    public Optional<SlideshowContent> findById(Long id);
    public void deleteById(Long id);
}
