import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IMessage } from './types';

export type MessageActions = ActionType<typeof actions>;

export interface IMessageState {
    readonly messages: IMessage[];
};
  
const INITIAL_STATE: IMessageState = {
    messages: []
};
  
export function messageReducer(state: IMessageState = INITIAL_STATE, action: MessageActions): IMessageState  {
    switch (action.type) {
        case getType(actions.messageAdd):
            return {...state, messages: [...state.messages, action.payload]};
        case getType(actions.messageRemove):
            return {...state, messages: state.messages.filter(x => x.id !== action.payload.messageId)};
        default:
            return state;
    }
}