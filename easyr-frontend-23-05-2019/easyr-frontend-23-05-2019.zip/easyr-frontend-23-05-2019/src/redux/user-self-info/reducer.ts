import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IUserResponseModel } from './types';

export type UserSelfInfoActions = ActionType<typeof actions>;

export interface IUserSelfInfoState {
    readonly data: IUserResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IUserSelfInfoState = {
    data: null,
    loading: false,
    error: null
};
  
export function userSelfInfoReducer(state: IUserSelfInfoState = INITIAL_STATE, action: UserSelfInfoActions): IUserSelfInfoState  {
    switch (action.type) {
        case getType(actions.userSelfInfoFetch):
            return {...state, loading: true, error: null};
        case getType(actions.userSelfInfoSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.userSelfInfoFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }
}