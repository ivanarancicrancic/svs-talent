export const USER_CAMPAIGN_DETAIL_FETCH = '@@user/campaign/detail/FETCH';
export const USER_CAMPAIGN_DETAIL_SUCCESS = '@@user/campaign/detail/SUCCESS';
export const USER_CAMPAIGN_DETAIL_FAIL = '@@user/campaign/detail/FAIL';

export const CAMPAIGN_CREATE_FETCH = '@@campaign/create/FETCH';
export const CAMPAIGN_CREATE_SUCCESS = '@@campaign/create/SUCCESS';
export const CAMPAIGN_CREATE_FAIL = '@@campaign/create/FAIL';

export const CAMPAIGN_SAVE_FETCH = '@@campaign/save/FETCH';
export const CAMPAIGN_SAVE_SUCCESS = '@@campaign/save/SUCCESS';
export const CAMPAIGN_SAVE_FAIL = '@@campaign/save/FAIL';

export const CAMPAIGN_EDIT_FETCH = '@@campaign/edit/FETCH';
export const CAMPAIGN_EDIT_SUCCESS = '@@campaign/edit/SUCCESS';
export const CAMPAIGN_EDIT_FAIL = '@@campaign/edit/FAIL';

export const TRACKER_UPLOAD_FETCH = '@@campaign/tracker/upload/FETCH';
export const TRACKER_UPLOAD_SUCCESS = '@@campaign/tracker/upload/SUCCESS';
export const TRACKER_UPLOAD_FAIL = '@@campaign/tracker/upload/FAIL';

export const TRACKER_DELETE_FETCH = '@@campaign/tracker/delete/FETCH';
export const TRACKER_DELETE_SUCCESS = '@@campaign/tracker/delete/SUCCESS';
export const TRACKER_DELETE_FAIL = '@@campaign/tracker/delete/FAIL';

export const CONTENT_DELETE_FETCH = '@@campaign/content/delete/FETCH';
export const CONTENT_DELETE_SUCCESS = '@@campaign/content/delete/SUCCESS';
export const CONTENT_DELETE_FAIL = '@@campaign/content/delete/FAIL';

export const CONTENT_VIDEO_CREATE_FETCH = '@@campaign/content/video/create/FETCH';
export const CONTENT_VIDEO_CREATE_SUCCESS = '@@campaign/content/video/create/SUCCESS';
export const CONTENT_VIDEO_CREATE_FAIL = '@@campaign/content/video/create/FAIL';

export const CONTENT_VIDEO_EDIT_FETCH = '@@campaign/content/video/edit/FETCH';
export const CONTENT_VIDEO_EDIT_SUCCESS = '@@campaign/content/video/edit/SUCCESS';
export const CONTENT_VIDEO_EDIT_FAIL = '@@campaign/content/video/edit/FAIL';

export const CONTENT_PANORAMA_CREATE_FETCH = '@@campaign/content/panorama/create/FETCH';
export const CONTENT_PANORAMA_CREATE_SUCCESS = '@@campaign/content/panorama/create/SUCCESS';
export const CONTENT_PANORAMA_CREATE_FAIL = '@@campaign/content/panorama/create/FAIL';

export const CONTENT_PANORAMA_EDIT_FETCH = '@@campaign/content/panorama/edit/FETCH';
export const CONTENT_PANORAMA_EDIT_SUCCESS = '@@campaign/content/panorama/edit/SUCCESS';
export const CONTENT_PANORAMA_EDIT_FAIL = '@@campaign/content/panorama/edit/FAIL';

export const CONTENT_WEBVIEW_CREATE_FETCH = '@@campaign/content/webview/create/FETCH';
export const CONTENT_WEBVIEW_CREATE_SUCCESS = '@@campaign/content/webview/create/SUCCESS';
export const CONTENT_WEBVIEW_CREATE_FAIL = '@@campaign/content/webview/create/FAIL';

export const CONTENT_WEBVIEW_EDIT_FETCH = '@@campaign/content/webview/edit/FETCH';
export const CONTENT_WEBVIEW_EDIT_SUCCESS = '@@campaign/content/webview/edit/SUCCESS';
export const CONTENT_WEBVIEW_EDIT_FAIL = '@@campaign/content/webview/edit/FAIL';

export const CONTENT_MOREINFO_CREATE_FETCH = '@@campaign/content/moreinfo/create/FETCH';
export const CONTENT_MOREINFO_CREATE_SUCCESS = '@@campaign/content/moreinfo/create/SUCCESS';
export const CONTENT_MOREINFO_CREATE_FAIL = '@@campaign/content/moreinfo/create/FAIL';

export const CONTENT_MOREINFO_EDIT_FETCH = '@@campaign/content/moreinfo/edit/FETCH';
export const CONTENT_MOREINFO_EDIT_SUCCESS = '@@campaign/content/moreinfo/edit/SUCCESS';
export const CONTENT_MOREINFO_EDIT_FAIL = '@@campaign/content/moreinfo/edit/FAIL';

export const CONTENT_AUDIO_CREATE_FETCH = '@@campaign/content/audio/create/FETCH';
export const CONTENT_AUDIO_CREATE_SUCCESS = '@@campaign/content/audio/create/SUCCESS';
export const CONTENT_AUDIO_CREATE_FAIL = '@@campaign/content/audio/create/FAIL';

export const CONTENT_AUDIO_EDIT_FETCH = '@@campaign/content/audio/edit/FETCH';
export const CONTENT_AUDIO_EDIT_SUCCESS = '@@campaign/content/audio/edit/SUCCESS';
export const CONTENT_AUDIO_EDIT_FAIL = '@@campaign/content/audio/edit/FAIL';

export const CONTENT_UNITY_CREATE_FETCH = '@@campaign/content/unity/create/FETCH';
export const CONTENT_UNITY_CREATE_SUCCESS = '@@campaign/content/unity/create/SUCCESS';
export const CONTENT_UNITY_CREATE_FAIL = '@@campaign/content/unity/create/FAIL';

export const CONTENT_UNITY_EDIT_FETCH = '@@campaign/content/unity/edit/FETCH';
export const CONTENT_UNITY_EDIT_SUCCESS = '@@campaign/content/unity/edit/SUCCESS';
export const CONTENT_UNITY_EDIT_FAIL = '@@campaign/content/unity/edit/FAIL';

export const CONTENT_SLIDESHOW_CREATE_FETCH = '@@campaign/content/slideshow/create/FETCH';
export const CONTENT_SLIDESHOW_CREATE_SUCCESS = '@@campaign/content/slideshow/create/SUCCESS';
export const CONTENT_SLIDESHOW_CREATE_FAIL = '@@campaign/content/slideshow/create/FAIL';

export const CONTENT_SLIDESHOW_EDIT_FETCH = '@@campaign/content/slideshow/edit/FETCH';
export const CONTENT_SLIDESHOW_EDIT_SUCCESS = '@@campaign/content/slideshow/edit/SUCCESS';
export const CONTENT_SLIDESHOW_EDIT_FAIL = '@@campaign/content/slideshow/edit/FAIL';

export const CONTENT_SLIDESHOW_IMAGEUP_FETCH = '@@campaign/content/slideshow/imageup/FETCH';
export const CONTENT_SLIDESHOW_IMAGEUP_SUCCESS = '@@campaign/content/slideshow/imageup/SUCCESS';
export const CONTENT_SLIDESHOW_IMAGEUP_FAIL = '@@campaign/content/slideshow/imageup/FAIL';

export const CONTENT_SLIDESHOW_IMAGEDOWN_FETCH = '@@campaign/content/slideshow/imagedown/FETCH';
export const CONTENT_SLIDESHOW_IMAGEDOWN_SUCCESS = '@@campaign/content/slideshow/imagedown/SUCCESS';
export const CONTENT_SLIDESHOW_IMAGEDOWN_FAIL = '@@campaign/content/slideshow/imagedown/FAIL';

export const CONTENT_RENAME_FETCH = '@@campaign/content/rename/FETCH';
export const CONTENT_RENAME_SUCCESS = '@@campaign/content/rename/SUCCESS';
export const CONTENT_RENAME_FAIL = '@@campaign/content/rename/FAIL';

// TRACKER
export interface ITrackerResponseModel {
    id: number;
    url: string;
}

// CONTENT
type ContentType = 'panorama' | 'webview' | 'slideshow' | 'audio' | 'movie' | 'unity' | 'moreinfo';

export interface IContentResponseModel {
    id: number;
    type: ContentType;
    name: string;
    weight: number;
}

// VIDEO TYPES
export type MovieSubtype = 'NORMAL' | 'GREENSCREEN' | 'SPHERE';

interface IMovieContentFields {
    subType: MovieSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IVideoContentResponseModel extends IContentResponseModel, IMovieContentFields {}

export interface IVideoContentRequestModel extends IMovieContentFields {
    id?: number;
    name: string;
}

// PANORAMA TYPES
export type PanoramaSubtype = 'X180' | 'X360' | 'SPHERE';

interface IPanoramaContentFields {
    subType: PanoramaSubtype;
    url: string;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IPanoramaContentResponseModel extends IContentResponseModel, IPanoramaContentFields {}

export interface IPanoramaContentRequestModel extends IPanoramaContentFields {
    id?: number;
    name: string;
}

// WEBVIEW TYPES
interface IWebviewContentFields {
    url: string;
}

export interface IWebviewContentResponseModel extends IContentResponseModel, IWebviewContentFields {}

export interface IWebviewContentRequestModel extends IWebviewContentFields {
    id?: number;
    name: string;
}

// MOREINFO TYPES
interface IMoreinfoContentFields {
    url: string;
}

export interface IMoreinfoContentResponseModel extends IContentResponseModel, IMoreinfoContentFields {}

export interface IMoreinfoContentRequestModel extends IMoreinfoContentFields {
    id?: number;
    name: string;
}

// AUDIO TYPES
interface IAudioContentFields {
    url: string;
    renderOnTrackingLost: boolean;
}

export interface IAudioContentResponseModel extends IContentResponseModel, IAudioContentFields {}

export interface IAudioContentRequestModel extends IAudioContentFields {
    id?: number;
    name: string;
}

// UNITY TYPES
interface IUnityContentFields {
    iosUrl: string;
    androidUrl: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IUnityContentResponseModel extends IContentResponseModel, IUnityContentFields {}

export interface IUnityContentRequestModel extends IUnityContentFields {
    id?: number;
    name: string;
}

// SLIDESHOW TYPES

export type SlideshowSubtype = 'NORMAL' | 'WHEEL';

export interface ISlideshowImage {
    id?: number;
    url: string;
    orgName: string;
}

interface ISlideshowContentFields {
    subType: SlideshowSubtype;
    images: ISlideshowImage[];
}

export interface ISlideshowContentResponseModel extends IContentResponseModel, ISlideshowContentFields {}

export interface ISlideshowContentRequestModel extends ISlideshowContentFields {
    id?: number;
    name: string;
}

// CAMPAIGN
export interface ICampaignDetailResponseModel {
    id: number;
    name: string;
    description: string;
    tracker: ITrackerResponseModel[];
    contents: IContentResponseModel[]
    temporary: boolean;
    activePackageId: number | null
};