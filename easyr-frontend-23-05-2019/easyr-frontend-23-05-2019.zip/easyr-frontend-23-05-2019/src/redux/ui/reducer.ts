import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

export type UIActions = ActionType<typeof actions>;

export interface IUIState {
    readonly createCampaignDialogOpen: boolean;
};
  
const INITIAL_STATE: IUIState = {
    createCampaignDialogOpen: false
};
  
export function uiReducer(state: IUIState = INITIAL_STATE, action: UIActions): IUIState  {
    switch (action.type) {
        case getType(actions.uiShowCreateCampaign):
            return {...state, createCampaignDialogOpen: true};
        case getType(actions.uiHideCreateCampaign):
        return {...state, createCampaignDialogOpen: false};
        default:
            return state;
    }
}