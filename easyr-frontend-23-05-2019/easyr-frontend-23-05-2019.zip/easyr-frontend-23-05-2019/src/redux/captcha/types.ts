export const CAPTCHA_FETCH = '@@captcha/FETCH';
export const CAPTCHA_SUCCESS = '@@captcha/SUCCESS';
export const CAPTCHA_FAIL = '@@captcha/FAIL';

export interface ICaptchaResponseModel {
    id: string;
    data: string;
};