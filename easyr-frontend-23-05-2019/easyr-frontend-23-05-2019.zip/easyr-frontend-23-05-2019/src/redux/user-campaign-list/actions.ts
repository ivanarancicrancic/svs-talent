import {
    USER_CAMPAIGN_LIST_FETCH,
    USER_CAMPAIGN_LIST_SUCCESS,
    USER_CAMPAIGN_LIST_FAIL,
    ICampaignResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const userCampaignListFetch = createStandardAction(USER_CAMPAIGN_LIST_FETCH)();
export const userCampaignListSuccess = createStandardAction(USER_CAMPAIGN_LIST_SUCCESS)<ICampaignResponseModel[]>();
export const userCampaignListFail = createStandardAction(USER_CAMPAIGN_LIST_FAIL)<string>();
