import { IRootState } from '..'

export const getUserCampaignList = (state: IRootState) => state.userCampaignList.data;
export const getUserCampaignListIsLoading = (state: IRootState) => state.userCampaignList.loading;
export const getUserCampaignListHasError = (state: IRootState) => state.userCampaignList.error;