export const USER_PACKAGE_LIST_FETCH = '@@user/package/list/FETCH';
export const USER_PACKAGE_LIST_SUCCESS = '@@user/package/list/SUCCESS';
export const USER_PACKAGE_LIST_FAIL = '@@user/package/list/FAIL';

interface IPackageCountModel {
    id: number;
    name: string;
    count: number;
}

export interface IPackagesResponseModel {
    available: IPackageCountModel[];
    used: IPackageCountModel[];
};