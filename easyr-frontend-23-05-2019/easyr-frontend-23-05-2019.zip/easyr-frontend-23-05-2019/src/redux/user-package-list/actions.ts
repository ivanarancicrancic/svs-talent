import {
    USER_PACKAGE_LIST_FETCH,
    USER_PACKAGE_LIST_SUCCESS,
    USER_PACKAGE_LIST_FAIL,
    IPackagesResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const userPackageListFetch = createStandardAction(USER_PACKAGE_LIST_FETCH)();
export const userPackageListSuccess = createStandardAction(USER_PACKAGE_LIST_SUCCESS)<IPackagesResponseModel>();
export const userPackageListFail = createStandardAction(USER_PACKAGE_LIST_FAIL)<string>();