import { IRootState } from '..'

export const getUserPackageList = (state: IRootState) => state.userPackageList.data;
export const getUserPackageListIsLoading = (state: IRootState) => state.userPackageList.loading;
export const getUserPackageListHasError = (state: IRootState) => state.userPackageList.error;