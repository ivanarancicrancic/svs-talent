import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IPackagesResponseModel } from './types';

export type UserPackageListActions = ActionType<typeof actions>;

export interface IUserPackageListState {
    readonly data: IPackagesResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IUserPackageListState = {
    data: null,
    loading: false,
    error: null
};
  
export function userPackageListReducer(state: IUserPackageListState = INITIAL_STATE, action: UserPackageListActions): IUserPackageListState  {
    switch (action.type) {
        case getType(actions.userPackageListFetch):
            return {...state, loading: true, error: null};
        case getType(actions.userPackageListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.userPackageListFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }
}