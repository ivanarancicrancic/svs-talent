import * as React from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';
import * as moment from 'moment';

import './DashboardLayout.css';
import { IRootState } from '../../redux';
import { userCampaignListFetch } from '../../redux/user-campaign-list/actions';
import { ICampaignResponseModel } from '../../redux/user-campaign-list/types';
import { getUserCampaignList } from '../../redux/user-campaign-list/selectors';
import { IPackagesResponseModel } from '../../redux/user-package-list/types';
import { getUserPackageList } from '../../redux/user-package-list/selectors';
import { userPackageListFetch } from '../../redux/user-package-list/actions';
import { campaignCreateFetch } from '../../redux/campaign/actions';

import { history } from '../../router';

interface IPropsDispatchMap {
    userCampaignListFetch: typeof userCampaignListFetch;
    userPackageListFetch: typeof userPackageListFetch;
    campaignCreateFetch: typeof campaignCreateFetch;
}
interface IPropsStateMap {
    campaignData: ICampaignResponseModel[] | null;
    packageData: IPackagesResponseModel | null;
    campaignCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.userCampaignListFetch();
        this.props.userPackageListFetch();
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const campaignCreated = this.props.campaignCreating === true && nextProps.campaignCreating === false;
        if(campaignCreated) {
            history.push(`/campaign/${nextProps.lastCreatedId}`);
        }
    }

    public renderCampaignList() {

        if(this.props.campaignData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>
                        <tr>
                        <th>Kampagne<button className="bp3-button bp3-icon-double-caret-vertical bp3-minimal"/></th>
                        <th>Haupttracker</th>
                        <th>Anzahl Trackings</th>
                        <th>Ablaufdatum</th>
                        <th/>
                        </tr>
                    </thead>
                    <tbody>
                        {this.props.campaignData.map( campaign => {
                            return (
                                <tr key={campaign.id}>
                                    <td>{campaign.name}</td>
                                    <td>{campaign.trackerUrl && <img style={{width: 50, height: 50}} src={campaign.trackerUrl} />}</td>
                                    <td>{campaign.numberOfViews}</td>
                                    <td>{campaign.expirationDate && moment(campaign.expirationDate).format('DD.MM.YYYY')}</td>
                                    <td><Link to={`/campaign/${campaign.id}`} className="fontello icon-edit"/> </td>
                                </tr>
                            )
                        })}
                        <tr>
                        <td colSpan={5} className="text-center" >
                            {!this.props.campaignCreating && <a onClick={ () => {this.props.campaignCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        );
    }

    public renderPackageList() {

        if(this.props.packageData == null) {
            return null;
        }

        return (
            <div className="boughtCampaign">
                <table className="table campaignTable bp3-html-table bp3-html-table-bordered">
                    <tbody >
                        <tr>
                            <td>Kontingente ungenutzter Kampagnen</td>
                        {this.props.packageData.available.map( packageCount => {
                            return (
                                <td key={packageCount.id}>{`${packageCount.name}: ${packageCount.count}`}</td>
                            )
                        })}
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
                {this.renderCampaignList()}
                {this.renderPackageList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    campaignData: getUserCampaignList(state),
    packageData: getUserPackageList(state),

    campaignCreating: state.campaign.createLoading,
    lastCreatedId: state.campaign.lastCreatedId,
});

export default connect(mapStateToProps, {userCampaignListFetch, campaignCreateFetch, userPackageListFetch})(DashboardLayout)