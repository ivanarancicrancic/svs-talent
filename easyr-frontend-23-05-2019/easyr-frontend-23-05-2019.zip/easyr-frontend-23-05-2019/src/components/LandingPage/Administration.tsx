import * as React from 'react';
import './LandingPage.css';

export default class Administration extends React.Component{

  
    public render() {
        return (
            <div className="administration pageBox">
                <span className="bp3-icon-standard bp3-icon-menu burger-menu" />
                <div className="NW"> <div className="centered">
                    Die Inhalte Ihrer Kampagnen können Sie
                    jederzeit ändern – ohne Zusatzkosten,
                    ohne Fachwissen und ohne uns.
                </div> </div>
                <div className="SW"> <div className="centered"> 
                    Nach Ihrer Registrierung erhalten Sie
                    Ihre persönlichen Zugangsdaten.
                </div> </div>
                <div className="SE"> <div className="centered">
                    In diesem Bereich befinden sich auch alle
                    Auswertungs- und Analysemöglichkeiten.
                </div> </div>

                 <div className="NE"> <div className="centered"> 
                   <button> Anmelden </button>
                </div> </div>

                <div className="centered">
                    <p> DIE<span>_</span>FUTURISTEN </p>
                    <p className="title"> Die Verwaltung </p>
                </div>
            </div>
        )
    }
}  