import * as React from 'react';
import './LandingPage.css';
import easyIR from '../../assets/images/easyIR.png';
import { NavLink } from 'react-router-dom';
import { PATH_ABOUT_US, PATH_ADMINISTRATION, PATH_PRODUCTS } from '../../router/paths';

export default class LandingPage extends React.Component{

  
    public render() {
        return (
            <div className="landing pageBox">
                <span className="bp3-icon-standard bp3-icon-menu burger-menu" />
                <div className="NW"> <div className="centered"><NavLink to={PATH_ABOUT_US}> Warum <span> Wir? </span> </NavLink> </div> </div>
                <div className="NE"> <div className="centered"><NavLink to={PATH_ADMINISTRATION}> Ihre <span> Verwaltung </span> </NavLink> </div> </div>
                <div className="SW"> <div className="centered"><NavLink to={PATH_PRODUCTS}> Produkte & <span> Preise </span> </NavLink> </div> </div>
                <div className="SE"> <div className="centered"> Kontakt & <span> Impressum </span> </div> </div>

                <div className="centered">
                    <p> DIE<span>_</span>FUTURISTEN </p>
                    <p> AR? - VR? - XR? </p>
                    <p> Die Antwort ist: </p>
                    <img src= { easyIR } />
                </div>
            </div>
        )
    }
}  