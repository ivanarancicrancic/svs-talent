import * as React from 'react';
import './Slideshow.css';
import { Position, Tooltip } from "@blueprintjs/core";

export default class SlideshowSettings extends React.Component {

    public render() {
        return (
            <div className="settingsBox">
                <table className="bp3-html-table .modifier">
                    <tbody>
                        <tr>
                            <td>Position:</td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">x</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">y</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">z</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td> <span className="bp3-icon-standard bp3-icon-move" /> </td>
                        </tr>
                        <tr>
                            <td>Rotation:</td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">x</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">y</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td>
                                <label className="bp3-label" htmlFor="{{form-group-input}}">z</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td> <span className="bp3-icon-standard bp3-icon-image-rotate-right" /> </td>
                        </tr>
                        <tr>
                            <td>Scale:</td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">x</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">y</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td><label className="bp3-label" htmlFor="{{form-group-input}}">z</label>
                                <input id="form-group-input" type="text" className="bp3-input"
                                placeholder="0.0" dir="auto" />
                            </td>
                            <td> <span className="bp3-icon-standard bp3-icon-zoom-to-fit" /> </td>
                        </tr>
                    </tbody>
                </table>
                <div className="checkboxes">
                    <label className="bp3-control bp3-checkbox .modifier">
                        <input type="checkbox"  />
                        <span className="bp3-control-indicator"/>
                        Checkbox
                        <Tooltip content="Some info here!" position={Position.TOP}>
                            <span className="bp3-icon-standard bp3-icon-info-sign" />
                        </Tooltip>
                    </label>

                    <label className="bp3-control bp3-checkbox .modifier">
                        <input type="checkbox"  />
                        <span className="bp3-control-indicator"/>
                        Another Checkbox
                        <Tooltip content="There is info here too!" position={Position.TOP}>
                            <span className="bp3-icon-standard bp3-icon-info-sign" />
                        </Tooltip>
                    </label>
                </div>
            </div>
        )
    }

}