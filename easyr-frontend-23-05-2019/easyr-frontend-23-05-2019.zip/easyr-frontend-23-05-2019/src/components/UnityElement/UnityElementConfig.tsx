import * as React from 'react';
import './UnityElement.css';

export default class UnityElementConfig extends React.Component {

    public render() {
        return (
            <pre>
                <table className="unityElement table bp3-html-table bp3-html-table-bordered bp3-interactive">
                    <tbody >
                        <tr>
                            <td>IOS</td>
                            <td>
                                <form className="webviewForm">
                                    <input name="my_url" type="file" />
                                </form>
                            </td>
                            
                        </tr>
                        <tr>
                            <td>Android</td>
                            <td>
                                <form className="webviewForm">
                                    <input name="my_url" type="file" />
                                </form>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </pre>
        )
    }

}