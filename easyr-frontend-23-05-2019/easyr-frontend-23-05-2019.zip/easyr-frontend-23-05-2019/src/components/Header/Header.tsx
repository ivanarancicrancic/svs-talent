import * as React from 'react';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';

import { getUserIsLoggedIn } from '../../redux/auth/selectors';

import PostAuthHeader from './PostAuthHeader';
import PreAuthHeader from './PreAuthHeader';

import './Header.css'

interface IPropsStateMap {
    isLoggedIn: boolean;
  }

type Props = IPropsStateMap;

class Header extends React.Component<Props> {
    public render() {
        const { isLoggedIn } = this.props;
        return isLoggedIn ? <PostAuthHeader /> : <PreAuthHeader />
    }
}

const mapStateToProps = (state: IRootState) => ({
    isLoggedIn: getUserIsLoggedIn(state)
});

export default connect(mapStateToProps, {})(Header)