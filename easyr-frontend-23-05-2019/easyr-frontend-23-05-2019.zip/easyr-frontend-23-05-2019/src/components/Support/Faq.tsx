import * as React from 'react';
import '../FooterComponents.css';

export default class Faq extends React.Component {

    public render() {
        return (
            <div className="container">

                <h2>Faq</h2>
                <div>
                    <h4> Lorem ipsum dolor sit amet, an his everti eleifend. His et oportere tractatos, sed id altera
                        dolores. Ius et lobortis molestiae assueverit, idque mandamus no sit. Qui dicam sanctus
                        ullamcorper in. Mei ex purto graece, option repudiandae mea ex, vero ferri altera ne sit. Ad
                        dicam interesset has, an tale harum alienum cum, ad alii legere similique sed. </h4>
                    <p> Lorem ipsum dolor sit amet, an his everti eleifend. His et oportere tractatos, sed id altera
                        dolores. Ius et lobortis molestiae assueverit, idque mandamus no sit. Qui dicam sanctus
                        ullamcorper in. Mei ex purto graece, option repudiandae mea ex, vero ferri altera ne sit. Ad
                        dicam interesset has, an tale harum alienum cum, ad alii legere similique sed.

                        Feugiat fierent aliquando vis no, nec id consetetur temporibus. Id tollit patrioque cum, id
                        aeterno regione eum, facer officiis scribentur pri te. Ut wisi senserit ullamcorper per, sit
                        augue movet an. At tincidunt temporibus scriptorem has. Ne sea vitae aliquando. Duo oratio
                        copiosae definitionem eu.

                        Choro malorum ea has, falli essent detracto te vel, zril expetenda id qui. Vix ei consul
                        eligendi, ad quo nihil everti tacimates. Mei vocibus complectitur in, sit in odio sale
                        efficiendi. Wisi ullum gubergren ius ne, maiorum indoctum sapientem eos ex.

                        Id vix quot utinam electram, duo iudicabit consequuntur conclusionemque ea. Eam in magna justo
                        scribentur, vitae intellegam est ei. In has elitr omnes, ei usu ponderum suscipiantur. At eum
                        stet virtute, ut putent prodesset quo, cu modus elaboraret referrentur nam. Saperet mentitum
                        persequeris ius ut, est ne nobis corrumpit, vis mucius phaedrum no.

                        Ius ea animal nusquam neglegentur, vel te tamquam iuvaret complectitur, cu eam noster nonumes
                        officiis. Usu in vivendo phaedrum quaerendum, eos no docendi scribentur. Sit nemore
                        concludaturque in. His exerci reformidans ut, id usu splendide referrentur. Vis zril vidisse an,
                        id ius quaeque similique neglegentur. Mel esse epicurei aliquando ei.</p>
                </div>
            </div>
        )
    }

}