import * as React from 'react';
import { IContentResponseModel, IVideoContentResponseModel, IPanoramaContentResponseModel, ISlideshowContentResponseModel } from '../../redux/campaign/types';

import paperbinWhiteImg from '../../assets/images/paperbin_white.svg';
import pencilWhiteImg from '../../assets/images/pencil_small_white.svg';

interface IDirectProps {
    content: IContentResponseModel;
    isSelected: boolean;
    index: number;
    onSelect: () => void;
    onDelete: () => void;
    onRename: (name: string) => void;
}

interface IState {
    editMode: boolean;
    nameField: string;
}

type IProps = IDirectProps;

function getContentTypeAsName(content: IContentResponseModel): string {

    switch(content.type) {
        case 'movie':
            const movie = content as IVideoContentResponseModel;
            switch(movie.subType) {
                case 'NORMAL': return "Video";
                case 'GREENSCREEN': return "Greenscreen";
                case 'SPHERE': return "360° Video";
            }
        case 'panorama':
            const panorama = content as IPanoramaContentResponseModel;
            switch(panorama.subType) {
                case 'X180': return "180° Panorama";
                case 'X360': return "360° Panorama";
                case 'SPHERE': return "Sphere";
            }
        case 'webview':
            return "Webview";
        case 'audio':
            return "Audio";
        case 'unity':
            return "3D";
        case 'slideshow':
            const slideshow = content as ISlideshowContentResponseModel;
            switch(slideshow.subType) {
                case 'NORMAL': return "Slideshow";
                case 'WHEEL': return "Wheel";
                default: return "Slideshow";
            }
    }

    return "...";
}

export class ContentTab extends React.Component<IProps, IState> {

    constructor(props: IProps) {
        super(props);

        this.state = {
            editMode: false,
            nameField: props.content.name
        }
    }

    public renderName() {

        const { content, index, isSelected } = this.props;

        if(this.state.editMode === false) {
            return (
                <span style={{
                    paddingLeft: 13, paddingRight: 5,
                    color: !isSelected ? '#e51349' : '#FFFFFF',
                    fontSize: 13,
                    fontWeight: 500
                    }}>{content.name || `Inhalt ${index+1}: ${getContentTypeAsName(content)}`}</span>
            )
        } else {
            return (
                <input
                    style={{width: 130, marginLeft: 5, paddingLeft: 5, backgroundColor: '#FFFFFF', fontSize: 13, color: '#e51349'}}
                    type="text"
                    value={this.state.nameField}
                    onChange={(e) => { this.setState({nameField: e.target.value});}}
                    onBlur={ () => {
                        if(this.state.editMode) {
                            this.props.onRename(this.state.nameField);
                            setTimeout( () => {
                                this.setState({editMode: false});
                            }, 250);
                        }
                    }}
                />
            )
        }
    }

    public render() {

        const { content, isSelected } = this.props;

        return (
            <div
                key={content.id}
                onClick={this.props.onSelect}
                style={{
                    cursor: 'pointer',
                    position: 'relative',
                    display: 'flex',
                    flexShrink: 0,
                    alignItems: 'center',
                    borderRight: '2px solid #e51349',
                    width: 188, height: 39,
                    backgroundColor: isSelected ? '#e51349' : '#FFFFFF'}}
                >

                    {this.renderName()}

                    {isSelected && <div onClick={() => { if(!this.state.editMode) {this.setState({editMode: true})} }} style={{position: 'absolute', right: 30}}>
                        <img style={{width: 16, height: 16}} src={pencilWhiteImg}/>
                    </div>}

                    {isSelected && <div onClick={this.props.onDelete} style={{position: 'absolute', right: 10}}>
                        <img style={{width: 14, height: 17}} src={paperbinWhiteImg}/>
                    </div>}

            </div>
        )
    }

}