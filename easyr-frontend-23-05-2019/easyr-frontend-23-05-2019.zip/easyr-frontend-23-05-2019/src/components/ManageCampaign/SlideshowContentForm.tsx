import * as React from 'react';
import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import ReactS3Uploader from 'react-s3-uploader';
import { LocalForm, actions } from 'react-redux-form';

import { ISlideshowContentRequestModel, ISlideshowImage, SlideshowSubtype } from '../../redux/campaign/types';
import { contentSlideshowEditFetch, contentSlideshowCreateFetch, contentSlideshowImageUpFetch, contentSlideshowImageDownFetch } from '../../redux/campaign/actions';

import './Forms.css';
import { API_ROOT } from '../../router/api-config';

import arrowLeftIcon from '../../assets/images/arrow_left.svg';
import arrowRightIcon from '../../assets/images/arrow_right.svg';
import paperbinWhiteImg from '../../assets/images/paperbin_white.svg';

interface IPropsStateMap {
    loading: boolean;
}

interface IPropsDispatchMap {
    contentSlideshowCreateFetch: typeof contentSlideshowCreateFetch;
    contentSlideshowEditFetch: typeof contentSlideshowEditFetch;
    contentSlideshowImageUpFetch: typeof contentSlideshowImageUpFetch;
    contentSlideshowImageDownFetch: typeof contentSlideshowImageDownFetch;
}

interface IDirectProps {
    token: string;
    content: ISlideshowContentRequestModel | null;
    campaignId: number;
    subType: SlideshowSubtype;
}

type IProps = IPropsDispatchMap & IPropsStateMap &  IDirectProps;

interface IState {
    uploading: boolean,
    uploadingProgress: number;
    uploadingError: boolean;
    images: ISlideshowImage[],
    touched: boolean;
}

/*
interface IPanoramaContentForm {
    //would be empty
}
*/

class SlideshowContentForm extends React.Component<IProps, IState> {

    public formDispatch: any;

    constructor(props: IProps) {
        super(props);

        this.state = {
            uploading: false,
            uploadingProgress: 0,
            uploadingError: false,
            images: [],
            touched: false
        }
    }

    public componentWillMount() {
        console.log("SlideshowContentForm componentWillMount");
    }

    public componentDidUpdate(prevProps: IProps) {
        console.log("SlideshowContentForm componentDidUpdate");
        if(this.props.content !== prevProps.content) {
            this.updateForm();
        }
    }

    public updateForm() {
        console.log("updateForm", this.props.content != null);
        if(this.props.content != null) {
            this.setState({images: this.props.content.images, touched: false});
        } else {
            this.setState({images: [], touched: false});
        }
    }

    public componentDidMount() {
        this.updateForm();
    }

    public onUploadComplete(url: string, orgName: string) {
        console.log("onUploadComplete", url);

        let images = [...this.state.images, {url: url.split("?")[0], orgName}];
        if(this.props.subType === 'WHEEL') {
            images = images.sort( (a, b) => a.orgName && b.orgName && a.orgName.localeCompare(b.orgName) || -1 );
        }

        this.setState({
            uploading: false,
            uploadingProgress: 0,
            uploadingError: false,
            images,
            touched: true
        });
    }

    public renderUploadButton() {
        if(this.state.uploading) {
            return (
                <div style={{position: 'relative', backgroundColor: '#e51249', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                        Datei wird hochgeladen ...
                    </span>
                    <div style={{position: 'absolute', bottom: 0, left: 0, height: 5, width: `${this.state.uploadingProgress}%`, backgroundColor: '#FFFFFF'}}/>
                </div>
            );
        } else {
            return (
                <div style={{cursor: 'pointer', backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#e51249', fontSize: 8, fontWeight: 500}}>
                        Foto - Dateien auswählen
                    </span>
                    <div style={{marginLeft: 5, width: 53, height: 16, backgroundColor: '#e51249', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                        <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                            hochladen
                        </span>
                    </div>

                    <ReactS3Uploader
                        style={{cursor: 'pointer', position: 'absolute', width: 173, height: 28, opacity: 0}}
                        signingUrl="/api/s3/sign/"
                        signingUrlMethod="POST"
                        accept="image/*"
                        s3path="/"
                        preprocess={ (file: any, next: any) => { this.setState({uploading: true}, () => { next(file); }) } }
                        onSignedUrl={ () => { return; } }
                        onProgress={ (progress: any) => { console.log("onProgress", progress); this.setState({uploadingProgress: progress}); } }
                        onError={ () => { console.log("onError"); this.setState({uploading: false, uploadingError: true}); } }
                        onFinish={ (signResult: {signedUrl: string}, file: any) => { this.onUploadComplete(signResult.signedUrl, file.name); } }
                        signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.props.token }}
                        signingUrlWithCredentials={false}
                        uploadRequestHeaders={{}}
                        server={API_ROOT}
                        autoUpload={true}
                        multiple={true}
                    />
                </div>
            );
        }
    }

    public onSubmit(values: {}) {

        const newValues: ISlideshowContentRequestModel = {
            id: this.props.content && this.props.content.id || undefined,
            images: this.state.images,
            subType: this.props.subType,
            name: this.props.subType === "NORMAL" ? "Slideshow" : "Wheel"
        }

        if(this.props.content === null) {
            this.props.contentSlideshowCreateFetch({
                campaignId: this.props.campaignId,
                data: newValues
            });
        } else {
            console.log("TODO: edit");
            this.props.contentSlideshowEditFetch({data: newValues});
        }

        console.log("onSubmit", this.props.content, newValues);

        this.formDispatch(actions.setUntouched('local'));
    }

    public attachDispatch(dispatch: any) {
        this.formDispatch = dispatch;
    }

    public moveUp(image: ISlideshowImage, index: number) {
        if(image.id !== undefined) {
            this.props.contentSlideshowImageUpFetch({imageId: image.id});
        }
    }

    public moveDown(image: ISlideshowImage, index: number) {
        if(image.id !== undefined) {
            this.props.contentSlideshowImageDownFetch({imageId: image.id});
        }
    }

    public deleteImage = (indexToDelete: number) => {

        const filteredImages = this.state.images.filter((img, index) => index !== indexToDelete);

        this.setState({
            images: filteredImages,
            touched: true
        })
    }

    public render() {
        return (
            <div>
                <LocalForm
                    className={"formz4"}
                    onUpdate={(form) => {console.log("onUpdate", form); this.setState({touched: form.$form.touched}) }}
                    onChange={(values) => {console.log("onChange", values)}}
                    onSubmit={(values) => { this.onSubmit(values); }}
                    getDispatch={(dispatch) => this.attachDispatch(dispatch)}
                >
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, alignSelf: 'stretch', backgroundColor: '#fdf2f0'}}>
                        {this.renderUploadButton()}
                    </div>
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', width: 190*3, alignSelf: 'stretch', backgroundColor: '#fdf2f0', overflowX: 'auto', overflowY: 'hidden'}}>
                        {this.state.images.map( (image, index) => {
                            return (
                                <div style={{position: 'relative', display: 'flex', justifyContent: 'center', alignItems: 'center', minWidth: 190, alignSelf: 'stretch', backgroundImage: `url(${image.url})`, backgroundSize: 'cover', borderRight: index === this.state.images.length-1 ? undefined : '2px solid #e51249'}} key={index}>
                                    {image.id !== undefined && index !== 0 && !this.state.touched && <div style={{cursor: 'pointer', position: 'absolute', left: 10}} onClick={ () => { this.moveUp(image, index) } }>
                                        <img style={{width: 10, height: 12, opacity: 0.5}} src={arrowLeftIcon} />
                                    </div>} 

                                    <div onClick={() => {this.deleteImage(index)}} style={{cursor: 'pointer', position: 'absolute', paddingLeft: 5, paddingRight: 5, bottom: 5, backgroundColor: '#e51249'}}>
                                        <img style={{width: 14/2, height: 17/2}} src={paperbinWhiteImg}/>
                                    </div>    

                                    {image.id !== undefined && index !== this.state.images.length - 1 && !this.state.touched && <div style={{cursor: 'pointer', position: 'absolute', right: 10}} onClick={ () => { this.moveDown(image, index) } }>
                                        <img style={{width: 10, height: 12, opacity: 0.5}} src={arrowRightIcon} />
                                    </div>}
                                </div>
                            )
                        })}
                    </div>
                </LocalForm>
                {this.state.touched && <div onClick={ () => { this.formDispatch(actions.submit('local')); } } style={{cursor: 'pointer', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e51249', padding: 5}}>
                    <span style={{color: '#FFFFFF', fontSize: 11}}>Änderungen speichern</span>
                </div>}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    loading: state.campaign.contentLoading
});

export default connect(mapStateToProps, {contentSlideshowCreateFetch, contentSlideshowEditFetch, contentSlideshowImageUpFetch, contentSlideshowImageDownFetch})(SlideshowContentForm);