import * as React from 'react';
import CreateContent from './CreateContent/CreateContent';
import TrackerImages from './TrackerImages/TrackerImages';
import CreateInfo from './CreateInfo/CreateInfo';

export default class CreateCampaign extends React.Component {

    public render() {
        return (
            <div className="createCampaign">
                <CreateInfo />
                <TrackerImages />
                <CreateContent />
            </div>
        )
    }

}