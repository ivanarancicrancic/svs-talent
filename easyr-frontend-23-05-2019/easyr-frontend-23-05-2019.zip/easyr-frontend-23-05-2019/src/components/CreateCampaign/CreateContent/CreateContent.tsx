import * as React from 'react';
import './CreateContent';
import { Button, Collapse  } from "@blueprintjs/core";
import CreateSlideshow from './CreateSlideshow/CreateSlideshow';
import CreateVideo from './CreateVideo/CreateVideo';
import CreateAudio from './CreateAudio/CreateAudio';
import CreatePanorama from './CreatePanorama/CreatePanorama';
import CreateUnityElement from './CreateUnityElement/CreateUnityElement';
import CreateWebview from './CreateWebview/CreateWebview';

export default class CreateContent extends React.Component<any, any> {
    constructor(props: any) {
        super(props);

        this.state = {
            files: [],
            content: ''
          };
    }

    public onCreate = (files:any) => {
        this.setState({
            files: this.state.files.concat(files),   
        });
    }

    public ContentType( content:any ) {  
        // this.setState({
        //     content: this.state.content
        // })
        console.log('dsfdsf' + this.state.content)
        return (
          <div>
            {(() => {
              switch(content) {
                case 'slideshow':
                    return <CreateSlideshow />;
                case 'audio':
                    return <CreateAudio />;
                case 'video':
                    return <CreateVideo />;
                case 'unityel':
                    return <CreateUnityElement />;
                case 'panorama':
                    return <CreatePanorama />;
                case 'webview':
                    return <CreateWebview />;
                default:
                    return null; 
                break;
              }
            })()}
          </div>
        );
      }

    // 

    
    public render() {
        
        return (
            <div className="grid100 newCampaign">
                <table className="grid100 table bp3-html-table">
                    <tbody >
                        {this.state.files.map((file:any) => (
                        <tr>
                            <td colSpan={6}>
                                <button className="circle"> <span className="bp3-icon-standard bp3-icon-media" /> </button> Slideshow     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-trash" /></button>
                                </span>
                                <div className="editBtn">
                                    <div>
                                        <Button className="bp3-button bp3-minimal" onClick={this.handleClick}>
                                        <span className="bp3-icon-standard bp3-icon-edit" />
                                        </Button>
                                        <Collapse isOpen={this.state.isOpen}>
                                            {/* {this.state.content} */}
                                            {this.ContentType('video')}
                                        </Collapse>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        ))}
                        <tr>
                            <td> 
                                <button className="circle"  onClick={this.onCreate}> <span className="bp3-icon-standard bp3-icon-media" /> </button>
                                <p> Slideshow </p>
                            </td>
                            <td>
                                <button className="circle" onClick={this.onCreate}> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button>
                                <p> Audio </p>
                            </td>
                            <td>
                                <button className="circle" onClick={this.onCreate}> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                                <p> Video </p>
                            </td>
                            <td>
                                <button className="circle" onClick={this.onCreate}> <span className="bp3-icon-standard bp3-icon-box" /> </button>
                                <p> Unity Element </p>
                            </td>
                            <td>
                                <button className="circle" onClick={this.onCreate}>  <span className="bp3-icon-standard bp3-icon-double-caret-horizontal" /> </button>
                                <p> Panorama </p>
                            </td>
                            <td>
                                <button className="circle" onClick={this.onCreate}> <span className="bp3-icon-standard bp3-icon-globe-network" /> </button>
                                <p> Webview </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }
    private handleClick = () => {
        this.setState({ isOpen: !this.state.isOpen });
    }
}