import * as React from 'react';
import '../../CreateCampaign.css'
import { Form, Control, Errors } from 'react-redux-form';

export default class CreateWebview extends React.Component <any,any>{
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }
    
      public onSubmit(values:any) {
          console.log(values.name);
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        console.log(values)
      }

    public render() {
        return (
            <div> 
                <div className="createBox">
                    <Form
                        model="forms.webview"
                        method="post"
                        onSubmit={ (webview) => this.onSubmit(webview) }
                        validators={{
                            name: { required: (val:any) => val && val.length },
                            url: { required: (val:any) => val && val.length },
                        }}
                        validateOn="submit"
                    >
                        <div className="bp3-input-group">
                            <label htmlFor="name" className="bp3-file-input">Name</label>
                            <Control.text
                                className="bp3-input"
                                model=".name"
                            />
                            <Errors
                                model=".name"
                                messages={{
                                    required: 'This field is required',
                                }}
                                show="touched"
                                className="errors"
                            />
                        </div>
                        <div className="bp3-input-group">
                            <label htmlFor="name" className="bp3-file-input">Enter URL</label>
                            <Control.text
                                className="bp3-input"
                                model=".url"
                                type="url"
                            />
                            <Errors
                                className="errors"
                                model=".url"
                                messages={{
                                    required: 'This field is required',
                                }}
                                show="touched"
                            />
                        </div>
                        <button className="bp3-button saveBtn"> <span className="bp3-icon-standard bp3-icon-tick-circle" /> </button>
                    </Form>
                </div>
            </div>
        )
    }
}