import * as React from 'react';
import '../../CreateCampaign.css'
import { Form, Control, Errors } from 'react-redux-form';
import { Tooltip, Position } from '@blueprintjs/core';

export default class CreateAudio extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }
    
      public onSubmit(values:any) {
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        console.log(values)
      }
    
    public render() {
        return (
            <div className="createBox">
                <Form
                    model="forms.audio"
                    method="post"
                    onSubmit={ (audio) => this.onSubmit(audio) }
                    validators={{
                        name: { required: (val:any) => val && val.length },
                        audio01: { required: (val:any) => val && val.length },
                        audio02: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                >
                    <div className="bp3-input-group">
                        <label htmlFor="name" className="bp3-file-input">Name</label>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'This field is required',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                        <label className="bp3-file-input">
                            <Control.file
                                model=".audio01" name="audio01" accept=".mp3,audio/*" 
                            />
                          <span className="bp3-file-upload-input">Choose audio file...</span>
                        </label>
                        <Errors
                            model=".audio01"
                            messages={{
                                required: 'Please select an audio file',
                        }}
                        show="touched"
                        className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                        <label className="bp3-file-input">
                            <Control.file
                                model=".audio02" name="audio02" accept=".mp3,audio/*" 
                            />
                          <span className="bp3-file-upload-input">Choose audio file...</span>
                        </label>
                        <Errors
                            model=".audio02"
                            messages={{
                                required: 'Please select an audio file',
                        }}
                        show="touched"
                        className="errors"
                        />
                    </div>

                    <label>
                        <Control.checkbox model=".check" /> Checkbox  
                        <Tooltip content="Some info here!" position={Position.TOP}>
                            <span className="bp3-icon-standard bp3-icon-info-sign" />
                        </Tooltip>
                    </label>
                    <button className="bp3-button saveBtn"> <span className="bp3-icon-standard bp3-icon-tick-circle" /> </button>
                </Form>
            </div>
        )
    }
}