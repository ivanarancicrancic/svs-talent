import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";

import { RouteComponentProps, Switch, Route } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_LOGIN, PATH_DASHBOARD, PATH_CAMPAIGN_EDIT, PATH_CREATE_CAMPAIGN, PATH_CAMPAIGN_DETAIL } from '../../router/paths';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
import EditCampaign from '../../components/Campaign/EditCampaign';
import DashboardLayout from '../../components/Dashboard/DashboardLayout';
import CreateCampaign from '../../components/CreateCampaign/CreateCampaign';
import ManageCampaign from '../../components/ManageCampaign/ManageCampaign';

library.add(faEnvelope, faKey);

interface IPropsStateMap {
  auth: IAuthState
}

type IProps = RouteComponentProps<{}> & IPropsStateMap;

class App extends React.Component<IProps> {

  public componentWillReceiveProps(nextProps: IProps) {
    if(this.props.auth.token != null && nextProps.auth.token == null) {
      this.props.history.replace(PATH_LOGIN);
    }
  }

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_DASHBOARD} exact={true} component={DashboardLayout} />
            <Route path={PATH_CAMPAIGN_EDIT} exact={true} component={EditCampaign} />
            <Route path={PATH_CREATE_CAMPAIGN} exact={true} component={CreateCampaign} />
            <Route path={PATH_CAMPAIGN_DETAIL} exact={true} component={ManageCampaign} />
          </Switch>
        </div>
        <Footer />
      </div>
    );
  }

  

}
const mapStateToProps = (state: IRootState) => ({
  auth: state.auth
});

export default connect(mapStateToProps)(App);