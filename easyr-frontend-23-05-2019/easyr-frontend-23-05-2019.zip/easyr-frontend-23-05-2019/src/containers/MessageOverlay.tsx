import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../redux/index';
import { IMessage, /*createErrorMessage*/ } from '../redux/messages/types';
import { messageAdd, messageRemove } from '../redux/messages/actions';

interface IProps {
    messages: IMessage[];
    messageAdd: typeof messageAdd;
    messageRemove: typeof messageRemove;
}

class MessageOverlay extends React.Component<IProps> {

    /*
    public componentWillMount() {
        const message = createErrorMessage("Login fehlgeschlagen", "E-Mail und Passwort gibts bei uns nicht du Dreckssau!", () => {this.props.messageRemove({messageId: message.id})})
        this.props.messageAdd(message);

        setTimeout( () => {
            const message2 = createErrorMessage("!", "blablabla", () => {this.props.messageRemove({messageId: message2.id})})
            this.props.messageAdd(message2);
        }, 1000);
    }
    */

    public onClickOutside = () => {
        const message = this.props.messages[0];
        if(!!message && message.allowDismissClickOutside && message.allowDismissClickOutside === true) {
            this.props.messageRemove({messageId: message.id});
        }
    }

    public render() {

        if(this.props.messages.length === 0) {
            return null;
        }

        const message = this.props.messages[0];

        return (
            <div onClick={this.onClickOutside} style={{position: 'absolute', top: 0, right: 0, bottom: 0, left: 0, zIndex: 9999, display: 'flex', justifyContent: 'center', alignItems: 'center', backgroundColor: '#000000AA'}}>

                <div style={{display: 'flex', flexDirection: 'column', border: '2px solid #e51249', backgroundColor: '#FFFFFF', margin: 10}}>
                    <div style={{backgroundColor: '#e51249', padding: '5px'}}>
                        <span style={{color: '#FFFFFF', fontSize: 20}}>{message.title}</span>
                    </div>
                    <div style={{paddingTop: 20, paddingBottom: 20, paddingLeft: 10, paddingRight: 10}}>
                        <span style={{fontSize: 18}}>{message.body}</span>
                    </div>
                    <div style={{cursor: 'pointer', display: 'flex', flexDirection: 'row'}}>
                        {message.buttons.map( (button, index) => {
                            return (
                                <div
                                    onClick={button.onPress}
                                    key={index}
                                    style={{
                                        display: 'flex',
                                        flexGrow: 1,
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        backgroundColor: '#e51249',
                                        borderRight: (index !== (message.buttons.length-1) && message.buttons.length > 1) ? '2px solid #FFFFFF' : undefined,
                                        padding: 5,
                                        height: 40
                                    }}>
                                    <span style={{color: '#FFFFFF', fontSize: 18}}>{button.type === 'confirm' ? "Bestätigen" : button.type === 'cancel' ? "Abbrechen" : "Ok"}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        );
    }

}

const mapStateToProps = (state: IRootState) => ({
    messages: state.messages.messages
});
  
export default connect(mapStateToProps, {messageAdd, messageRemove})(MessageOverlay);