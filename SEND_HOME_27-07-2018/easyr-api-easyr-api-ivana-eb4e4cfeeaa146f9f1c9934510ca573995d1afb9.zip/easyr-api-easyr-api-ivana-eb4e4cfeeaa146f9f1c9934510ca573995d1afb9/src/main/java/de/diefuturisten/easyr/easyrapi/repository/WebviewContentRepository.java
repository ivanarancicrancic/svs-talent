package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WebviewContentRepository extends JpaRepository<WebviewContent, Long> {
}
