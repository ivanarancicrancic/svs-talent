package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class TrackerService {

    @Autowired
    private TrackerRepository trackerRepository;

    public TrackerService(TrackerRepository trackerRepository) {
        this.trackerRepository = trackerRepository;
    }

    public List<Tracker> findAllTrackers(){
        return trackerRepository.findAll().stream().collect(Collectors.toList());
    }

    public Tracker findById(Long id){
        Optional<Tracker> optionalContent =trackerRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public Tracker saveTracker(Tracker tracker){
        trackerRepository.save(tracker);
        return tracker;
    }

    public void deleteTracker(Tracker tracker){
        trackerRepository.delete(tracker);
    }

    public void deleteTrackerById(Long id){
        trackerRepository.deleteById(id);
    }

    public Tracker createTracker(Tracker tracker){
        trackerRepository.save(tracker);
        Tracker savedTracker = trackerRepository.findById(tracker.getId()).get();
        return savedTracker;
    }

    public void deleteTracker(Long id){
        String status = "deleting tracker";
        System.out.println(status);
        trackerRepository.deleteById(id);

    }


}
