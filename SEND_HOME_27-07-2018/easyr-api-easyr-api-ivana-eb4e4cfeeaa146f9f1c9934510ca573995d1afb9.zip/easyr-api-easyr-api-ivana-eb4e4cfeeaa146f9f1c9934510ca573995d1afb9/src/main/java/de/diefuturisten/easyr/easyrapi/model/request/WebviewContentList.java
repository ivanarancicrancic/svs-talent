package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;

import java.util.List;

public class WebviewContentList {
    private List<WebviewContent> trackerList;

    public WebviewContentList(List<WebviewContent> trackerList) {
        this.trackerList = trackerList;
    }

    public List<WebviewContent> getTrackerList() {
        return trackerList;
    }

    public void setTrackerList(List<WebviewContent> trackerList) {
        this.trackerList = trackerList;
    }
}
