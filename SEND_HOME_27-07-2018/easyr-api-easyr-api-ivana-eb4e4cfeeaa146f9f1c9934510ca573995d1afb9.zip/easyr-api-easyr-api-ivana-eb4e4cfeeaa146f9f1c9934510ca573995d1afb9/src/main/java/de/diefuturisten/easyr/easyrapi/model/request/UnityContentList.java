package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;

import java.util.List;

public class UnityContentList {
    private List<UnityContent> unityContents;

    public UnityContentList(List<UnityContent> unityContents) {
        this.unityContents = unityContents;
    }

    public List<UnityContent> getUnityContents() {
        return unityContents;
    }

    public void setUnityContents(List<UnityContent> unityContents) {
        this.unityContents = unityContents;
    }
}
