package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.repository.UnityContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class UnityContentService {

    @Autowired
    private UnityContentRepository unityContentRepository;

    public UnityContentService(UnityContentRepository unityContentRepository) {
        this.unityContentRepository = unityContentRepository;
        }

    public List<UnityContent> findAllUnities(){
        return unityContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public UnityContent findById(Long id){
        Optional<UnityContent> optionalContent = unityContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public UnityContent saveUnityContent(UnityContent unityContent){
        unityContentRepository.save(unityContent);
        return unityContent;
    }

    public void deleteUnityContent(UnityContent unityContent){
        unityContentRepository.delete(unityContent);
    }

    public void deleteUnityContentByUnityId(Long id){
        unityContentRepository.deleteById(id);
    }

    public UnityContent createContent(UnityContent unityContent){
        unityContentRepository.save(unityContent);
        UnityContent savedUnity= unityContentRepository.findById(unityContent.getId()).get();
        return savedUnity;
    }

    public void deleteUnity(Long id){
        String status = "deleting unity content...";
        System.out.println(status);
        unityContentRepository.deleteById(id);

    }

}
