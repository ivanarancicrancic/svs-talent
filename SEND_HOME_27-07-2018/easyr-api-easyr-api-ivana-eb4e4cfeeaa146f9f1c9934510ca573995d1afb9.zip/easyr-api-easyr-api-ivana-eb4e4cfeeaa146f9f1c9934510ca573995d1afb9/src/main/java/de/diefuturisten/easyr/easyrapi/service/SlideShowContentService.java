package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowImageList;
import de.diefuturisten.easyr.easyrapi.repository.SlideShowContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.SlideShowImageRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class SlideShowContentService {

    private SlideShowContentRepository slideShowContentRepository;
    private SlideShowImageRepository slideShowImageRepository;

    public SlideShowContentService(SlideShowContentRepository slideShowContentRepository, SlideShowImageRepository slideShowImageRepository) {
        this.slideShowContentRepository = slideShowContentRepository;
        this.slideShowImageRepository = slideShowImageRepository;
    }

    public List<SlideshowContent> findAllSlides(){
        return slideShowContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public SlideshowContent findById(Long id){
        Optional<SlideshowContent>  optionalContent =slideShowContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public SlideshowContent findByName(String name){
        return slideShowContentRepository.findByName(name).get();
    }

    public SlideshowContent saveSlideShowContent(SlideshowContent slideshowContent){
        slideShowContentRepository.save(slideshowContent);
        return slideshowContent;
    }

    public void deleteSlideShowContent(SlideshowContent slideshowContent){
        slideShowContentRepository.delete(slideshowContent);
    }

    public void deleteSlideShowContentById(Long id){
        slideShowContentRepository.deleteById(id);
    }

    public SlideshowImageList getImagesBySlide(String name){
        return new SlideshowImageList(slideShowContentRepository.findByName(name).get().getImages().stream().collect(Collectors.toList()));
    }

    public void createImageBySlide(String name, SlideshowImage slideshowImage){
        slideShowContentRepository.findByName(name).get().getImages().add(slideshowImage);
        slideShowImageRepository.save(slideshowImage);
    }

    public void deleteImageBySlide(String name, Long id){
        SlideshowImage slideImage = slideShowContentRepository.findByName(name).get().getImages().stream().filter(slideshowImage -> slideshowImage.getId()==id).findFirst().get();
        slideShowContentRepository.findByName(name).get().getImages().remove(slideImage);
    }



}
