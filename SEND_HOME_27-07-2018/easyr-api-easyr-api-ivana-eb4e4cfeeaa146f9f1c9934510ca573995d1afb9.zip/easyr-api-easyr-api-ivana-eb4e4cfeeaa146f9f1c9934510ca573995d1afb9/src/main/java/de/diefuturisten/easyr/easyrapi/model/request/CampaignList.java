package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CampaignList {

    List<Campaign> campaigns;

    public List<Campaign> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignList(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignList(){}

}
