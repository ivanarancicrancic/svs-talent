package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.repository.AudioContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class AudioContentService {

    @Autowired
    private AudioContentRepository audioContentRepository;

    public AudioContentService(AudioContentRepository audioContentRepository) {
        this.audioContentRepository = audioContentRepository;
    }

    public List<AudioContent> findAllAudios(){
        return audioContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public AudioContent findById(Long id){
        Optional<AudioContent> optionalContent =audioContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public AudioContent findByName(String name){
        return audioContentRepository.findByName(name).get();
    }

    public AudioContent saveAudioContent(AudioContent audioContent){
        audioContentRepository.save(audioContent);
        return audioContent;
    }

    public void deleteAudioContent(AudioContent audioContent){
        audioContentRepository.delete(audioContent);
    }

    public void deleteAudioContentById(Long id){
        audioContentRepository.deleteById(id);
    }

    public AudioContent createAudio(AudioContent audioContent){
        audioContentRepository.save(audioContent);
        AudioContent savedAudio = audioContentRepository.findById(audioContent.getId()).get();
        return savedAudio;
    }

    public void deleteAudio(Long id){
        String status = "deleting audio";
        System.out.println(status);
        audioContentRepository.deleteById(id);

    }


}
