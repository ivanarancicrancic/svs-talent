package de.diefuturisten.easyr.easyrapi.service;


import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRespository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Component
@Transactional
public class CampaignService {

    @Autowired
    private CampaignRespository campaignRepository;

    @Autowired
    private UserRepository userRepository;



    public CampaignService(CampaignRespository campaignRepository, UserRepository userRepository) {
        this.campaignRepository = campaignRepository;
        this.userRepository = userRepository;
    }

    public Campaign createCampaign(Campaign campaign){
        campaignRepository.save(campaign);
        Campaign savedCampaign   = campaignRepository.findById(campaign.getId()).get();
        return savedCampaign;
    }


    public List<Campaign> getAllCampaigns(){
        String status = "getting all campaigns";
        System.out.println(status);
        Iterable<Campaign> iterable = campaignRepository.findAll();
        System.out.println("Taken campaigns!");
        List<Campaign> list = new ArrayList<Campaign>();
        if(iterable != null) {
            for(Campaign e: iterable) {
                list.add(e);
            }
        }

        return list;
    }

    public Campaign updateCampaign(Campaign campaign) {
        String status = "updating campaign...";
        System.out.println(status);
        campaignRepository.save(campaign);
        return campaign;
    }


    public void deleteCampaign(Long id){
        String status = "deleting campaign...";
        System.out.println(status);
        campaignRepository.deleteById(id);

    }

    public Campaign findById(Long id){
        String status = "getting command campaign...";
        System.out.println(status);
        Optional<Campaign> campaignOptional =  campaignRepository.findById(id);

        if (!campaignOptional.isPresent()) {
           // throw new NotFoundException("Campaign Not Found for id:" + id.toString());
        }
        return campaignOptional.get();
    }

    public void addCampaignToUser(Long user_id, Long campaign_id){
        String status = "adding campaign to user...";
        System.out.println(status);
        Optional<Campaign> campaignOptional =  campaignRepository.findById(campaign_id);
        if(campaignOptional.get().getUser()==null)
        campaignOptional.get().setUser(userRepository.findById(user_id).get());
        else System.out.println("Campaign already bought!");
    }

}
