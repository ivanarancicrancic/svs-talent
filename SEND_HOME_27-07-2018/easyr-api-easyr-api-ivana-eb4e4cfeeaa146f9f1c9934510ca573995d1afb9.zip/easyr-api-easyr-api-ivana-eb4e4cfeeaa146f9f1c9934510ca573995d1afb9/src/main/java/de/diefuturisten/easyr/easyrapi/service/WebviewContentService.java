package de.diefuturisten.easyr.easyrapi.service;


import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.repository.WebviewContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class WebviewContentService {
    @Autowired
    private WebviewContentRepository webviewContentRepository;

    public WebviewContentService(WebviewContentRepository webviewContentRepository) {
        this.webviewContentRepository = webviewContentRepository;
    }

    public List<WebviewContent> findAllWebviews(){
        return webviewContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public WebviewContent findById(Long id){
        Optional<WebviewContent> optionalContent =webviewContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public WebviewContent saveWebviewContent(WebviewContent webviewContent){
        webviewContentRepository.save(webviewContent);
        return webviewContent;
    }

    public void deleteWebviewContent(WebviewContent webviewContent){
        webviewContentRepository.delete(webviewContent);
    }

    public void deleteWebviewContentById(Long id){
        webviewContentRepository.deleteById(id);
    }

    public WebviewContent createWebview(WebviewContent webviewContent){
        webviewContentRepository.save(webviewContent);
        WebviewContent savedWebview = webviewContentRepository.findById(webviewContent.getId()).get();
        return savedWebview;
    }

    public void deleteWebview(Long id){
        String status = "deleting webview";
        System.out.println(status);
        webviewContentRepository.deleteById(id);

    }

}
