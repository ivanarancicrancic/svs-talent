import * as React from 'react';

interface Beer {
  id: string;
  right_name: string;
  description: string;
}

interface RightsListProps {
}

interface RightListState {
  rights: Array<Beer>;
  isLoading: boolean;
}

class BeerList extends React.Component<RightsListProps, RightListState> {

  constructor(props: RightsListProps) {
    super(props);

    this.state = {
      rights: [],
      isLoading: false
    };
  }

  componentDidMount() {
    this.setState({isLoading: true});

    fetch('http://localhost:8080/getAllRights')
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }

  render() {
    const {rights, isLoading} = this.state;

    if (isLoading) {
      return <p>Loading...</p>;
    }

    return (
      <div>
        <h2>Right List</h2><br/>
        {rights.map((right: Beer) =>
          <div key={right.id}>
           <b> Name: </b> {right.right_name}, <b> Description: </b> {right.description} <br/><br/><br/>
          </div>
        )}
      </div>
    );
  }
}

export default BeerList;