
create table if not exists userrights
(
	key_userright bigserial not null
		constraint userrights_pkey
			primary key,
	description varchar(245),
	name varchar(45)-- Users

);

create table if not exists userroles
(
	key_userrole bigserial not null
		constraint userroles_pkey
			primary key,
	description varchar(245),
	name varchar(45)
);

create table if not exists role_has_rights
(
	fk_userrole bigint not null
		constraint fksild0wf8nh8pglno33yb372sy
			references userroles,
	fk_userright bigint not null
		constraint fk25qqx2ys3kprig37tdkdvsji3
			references userrights,
	constraint role_has_rights_pkey
		primary key (fk_userrole, fk_userright)
);

create table if not exists users
(
	key_user bigserial not null
		constraint users_pkey
			primary key,
	active boolean not null,
	email varchar(255) not null
		constraint uk_6dotkott2kjsp8vw4d0m25fb7
			unique,
	firstname varchar(255) not null,
	gender boolean not null,
	language varchar(2) not null,
	lastname varchar(255) not null,
	password varchar(255) not null,
    payment_code varchar(255)
);


create table if not exists user_has_roles
(
	fk_user bigint not null
		constraint fk6gxg60sqvx38uexpnc4cgk99c
			references users,
	fk_userrole bigint not null
		constraint fksymyxbnkby56lpk1m569m8uxv
			references userroles,
	constraint user_has_roles_pkey
		primary key (fk_user, fk_userrole)
);