UPDATE users SET firstname = 'Ana' WHERE key_user = '1';
