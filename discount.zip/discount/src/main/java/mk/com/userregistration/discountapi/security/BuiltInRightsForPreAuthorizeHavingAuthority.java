package mk.com.userregistration.discountapi.security;

public final class BuiltInRightsForPreAuthorizeHavingAuthority {

    private static final String HAS_AUTHORITY_PREFIX = "hasAuthority('";
    private static final String HAS_AUTHORITY_SUFFIX = "')";

    public static final String USER_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.USER_GET + HAS_AUTHORITY_SUFFIX;

    public static final String ADMIN_RIGHT = HAS_AUTHORITY_PREFIX + BuiltInRights.ADMIN_RIGHT + HAS_AUTHORITY_SUFFIX;

    private BuiltInRightsForPreAuthorizeHavingAuthority() {
        // NO-OP utility class
    }

}
