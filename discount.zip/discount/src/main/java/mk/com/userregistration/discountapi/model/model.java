package mk.com.userregistration.discountapi.model;

public class model {
}
