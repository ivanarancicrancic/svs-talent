package mk.com.userregistration.discountapi;

import it.ozimov.springboot.mail.configuration.EnableEmailTools;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableEmailTools
public class DiscountMainApp {

    public static void main(String[] args) {
        SpringApplication.run(DiscountMainApp.class, args);
    }

}
