package mk.com.userregistration.discountapi.controller;

import mk.com.userregistration.discountapi.model.request.CreateAccountModel;
import mk.com.userregistration.discountapi.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AccountController {

    private final UserService userService;

    public AccountController(UserService userService ) {
        this.userService = userService;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity createAccount(@RequestBody CreateAccountModel model) {

            String discountCode =  userService.getUserByUsername("ivana.rancic.r@gmail.com").getPaymentCode();
            userService.create(model, discountCode);
            return new ResponseEntity(HttpStatus.OK);
    }


}
