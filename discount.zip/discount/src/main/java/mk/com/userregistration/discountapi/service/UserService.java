package mk.com.userregistration.discountapi.service;

import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import mk.com.userregistration.discountapi.entity.user.User;
import mk.com.userregistration.discountapi.model.request.CreateAccountModel;
import mk.com.userregistration.discountapi.repository.UserRepository;
import mk.com.userregistration.discountapi.repository.UserRoleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private MailingService mailingService;
    private final UserRoleRepository userRoleRepository;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, MailingService mailingService, UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.mailingService = mailingService;
        this.userRoleRepository = userRoleRepository;
    }

    public User getUserByUsername(String username) {
        return userRepository.findByEmail(username).orElseThrow(NoSuchElementException::new);
    }


    public Optional<User> getUserByUserId(long userId) {
        return userRepository.findById(userId);
    }

    public User create(CreateAccountModel model, String code) {
        User user = new User();

        user.setId(model.getId());
        user.setActive(true);
        user.setEmail(model.getEmail());
        user.setFirstname(model.getFirstName());
        user.setGender(model.getGender());
        user.setLanguage(model.getLanguage());
        user.setLastname(model.getLastName());
        user.setPassword(passwordEncoder.encode(model.getPassword()));

        // Account Details
        user.setPaymentCode(code);

        userRoleRepository.findByName("Standard").ifPresent(defaultRole -> {
            user.addRole(defaultRole);
        });


        userRepository.save(user);


//        try {
//            mailingService.sendNewUserWelcome(user);
//        } catch (CannotSendEmailException e) {
//            log.error(String.format("Welcome E-Mail could not be send for user:", user.getEmail()));
//        }

        return user;
    }

//    public User edit(User user, EditAccountModel model) {
//
//        user.setGender(model.getGender());
//        user.setFirstname(model.getFirstName());
//        user.setLastname(model.getLastName());
//
//        if(model.getPassword().length() > 0) {
//            user.setPassword(passwordEncoder.encode(model.getPassword()));
//        }
//
//        user.setTelNumber(model.getPhoneNumber());
//        user.setPaymentTitle(model.getPaymentTitle());
//        user.setPaymentFirstname(model.getPaymentFirstName());
//        user.setPaymentLastname(model.getPaymentLastName());
//        user.setPaymentCompany(model.getCompanyName());
//        user.setPaymentStreet(model.getStreetAddress());
//        user.setPaymentCity(model.getCity());
//        user.setPaymentState(model.getState());
//        user.setPaymentCode();
//        user.setPaymentCountry(model.getCountry());
//
//        userRepository.save(user);
//        return user;
//    }


    public List<User> getAllUser() {
        return userRepository.findAll();
    }
}
