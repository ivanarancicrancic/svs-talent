package mk.com.userregistration.discountapi.controller;

import mk.com.userregistration.discountapi.entity.user.User;
import mk.com.userregistration.discountapi.model.request.CreateAccountModel;
import mk.com.userregistration.discountapi.security.SecurityConstants;
import mk.com.userregistration.discountapi.security.TokenHelper;
import mk.com.userregistration.discountapi.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
@RequestMapping("/api")
public class AdminController {

    private final UserService userService;

    public AdminController(UserService userService) {
        this.userService = userService;
    }

//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity createAccount(@RequestBody CreateAccountModel model) {
//        boolean approved = captchaService.verifyCaptcha(model.getCaptcha());
//        if(approved) {

            Date expirationTime = new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME);
            // tell the client our new JWT-token
            String code = TokenHelper.createToken(model.getEmail(), expirationTime);
            String[] tokens = code.split(" ");       // Single blank is the separator.
            code = tokens[1];
          User user = userService.create(model, code);
            return new ResponseEntity(HttpStatus.OK);
//        } else {
//            return new ResponseEntity(HttpStatus.BAD_REQUEST);
//        }
    }

}
