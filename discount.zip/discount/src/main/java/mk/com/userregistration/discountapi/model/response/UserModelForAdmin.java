package mk.com.userregistration.discountapi.model.response;


import mk.com.userregistration.discountapi.entity.user.User;

public class UserModelForAdmin {

    private long id;
    private String name;
    private String code;

    public UserModelForAdmin(User user) {
        this.id = user.getId();
        this.name = user.getName();
        this.code = "6868368369643436437HGS6786778H78678DP0";
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
