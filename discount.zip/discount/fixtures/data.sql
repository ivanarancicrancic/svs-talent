-- Users
INSERT INTO
  users(key_user, active, language, email, password, firstname, lastname, gender)
VALUES
  (1, true, 'de', 'ivana.rancic.r@gmail.com', '$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK', 'Ivana', 'Rancic', true), -- password is "wuff"
  (2, true, 'en', 'ivana.rancic@app-logik.de', '$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq', 'Ivana', 'Rancic', true); --password is "miau"


-- Roles
INSERT INTO
  userroles(key_userrole, name, description)
VALUES
  (1, 'Standard', 'normal user'),
  (2, 'Admin', 'admin user');


-- User has Roles
INSERT INTO
  user_has_roles(fk_user, fk_userrole)
VALUES
  (1, 1),
  (1, 2);

-- Rights
INSERT INTO
  userrights(key_userright, description, name)
VALUES
  (14, 'ADMIN_RIGHT', 'ADMIN_RIGHT');

-- Role Has Rights
INSERT INTO
  role_has_rights(fk_userrole, fk_userright)
VALUES
  (1, 14);

