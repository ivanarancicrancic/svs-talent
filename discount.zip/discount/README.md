Postman requests:

REQUEST: POST Path: localhost:8080/api/register Content-Type: application/json Body: { "key_user": "1", "firstName":"Ivana","lastName":"Rancic", "email":"ivana.rancic.r@gmail.com", "password":"$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK", "language":"en", "gender":true }

REQUEST: POST Path: localhost:8080/register Content-Type: application/json Body: { "key_user": "2", "firstName":"Ana","lastName":"Rancic", "email":"ivana.rancic@gmail.com", "password":"$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK", "language":"en", "gender":true }