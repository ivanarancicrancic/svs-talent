export const DECREMENT_QUANTITY_ARTICLES_FETCH = '@@user/order/acrticles/decrement/FETCH';
export const DECREMENT_QUANTITY_ARTICLES_SUCCESS = '@@user/order/acrticles/decrement/SUCCESS';
export const DECREMENT_QUANTITY_ARTICLES_FAIL = '@@user/order/acrticles/decrement/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};



export interface IOrderSaveRequestModel {
    order_id: string;
    orderDate: Date;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};


export interface IDecrementOrderArticlesQuantityRequestModel {
    order_id: string; 
    orderarticle_id: string;
};