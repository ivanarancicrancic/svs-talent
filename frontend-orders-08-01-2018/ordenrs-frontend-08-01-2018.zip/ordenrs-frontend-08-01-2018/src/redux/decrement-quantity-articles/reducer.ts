import { ActionType, getType } from 'typesafe-actions';
import { IOrderDetailResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type DecrementQuantityArticlesActions = ActionType<typeof extActions>;

export interface IDecrementQuantityArticlesState {
    readonly data: IOrderDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IDecrementQuantityArticlesState = {
    data: null,
    loading: false,
    error: null
};
  
export function decrementQuantityArticlesReducer(state: IDecrementQuantityArticlesState = INITIAL_STATE, action: DecrementQuantityArticlesActions): IDecrementQuantityArticlesState  {
    switch (action.type) {
        case getType(extActions.decrementQuantityArticlesFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.decrementQuantityArticlesSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.decrementQuantityArticlesFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}