import { IRootState } from '..'

export const getOrderWithDecrementedQuantityArticles = (state: IRootState) => state.orderWithDecrementedQuantityArticles.data;
export const getOrderWithDecrementedQuantityArticlesLoading = (state: IRootState) => state.orderWithDecrementedQuantityArticles.loading;
export const getOrderWithDecrementedQuantityArticlesHasError = (state: IRootState) => state.orderWithDecrementedQuantityArticles.error;