import {
    DECREMENT_QUANTITY_ARTICLES_FETCH,
    DECREMENT_QUANTITY_ARTICLES_SUCCESS,
    DECREMENT_QUANTITY_ARTICLES_FAIL,
    IOrderDetailResponseModel,
    IDecrementOrderArticlesQuantityRequestModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const decrementQuantityArticlesFetch = createStandardAction(DECREMENT_QUANTITY_ARTICLES_FETCH)<{decrementOrderArticlesQuantity:IDecrementOrderArticlesQuantityRequestModel}>();
export const decrementQuantityArticlesSuccess = createStandardAction(DECREMENT_QUANTITY_ARTICLES_SUCCESS)<IOrderDetailResponseModel>();
export const decrementQuantityArticlesFail = createStandardAction(DECREMENT_QUANTITY_ARTICLES_FAIL)<string>();

