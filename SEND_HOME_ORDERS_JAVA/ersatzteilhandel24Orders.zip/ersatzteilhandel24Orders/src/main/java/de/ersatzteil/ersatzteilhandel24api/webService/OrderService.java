package de.ersatzteil.ersatzteilhandel24api.webService;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;


import de.ersatzteil.ersatzteilhandel24api.model.Order;
import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;

@Path("/api")
public class OrderService {

    @GET
    @Path("/activecontacts/providerId={providerId}&&securityToken={securityToken}")
    @Produces("application/json")
    public List<Order> GetOrders() throws Exception
    {
        System.out.println("init");
        List<Order> order_items = null;

        try{
            ProjectManager projectManager= new ProjectManager();

            order_items = projectManager.getOrderList();
            //StringBuffer sb = new StringBuffer();
//            t_tems_str = gson.toJson(t_items);
//				if (t_items.isEmpty()){
//					 throw new WebApplicationException(404);
//				}
//				else
//				{
            return order_items;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


//    @GET
//    @Path("/patients/providerId={providerId}&&securityToken={securityToken}")
//    @Produces("application/json")
//    public String getPatientsAllCascade(@PathParam("providerId") Integer providerId, @PathParam("securityToken") String securityToken) throws Exception
//    {
//        System.out.println("init");
//        List<PatientsCascade> t_items = null;
//        String t_tems_str  = null;
//        try{
//            ProjectManager projectManager= new ProjectManager();
//            t_items = projectManager.getPatientsByProvider(providerId, securityToken);
//            //StringBuffer sb = new StringBuffer();
//            Gson gson = new Gson();
//            System.out.println(gson.toJson(t_items));
//            t_tems_str = gson.toJson(t_items);
//
////			if (t_items.isEmpty()){
////				 throw new WebApplicationException(404);
////			}
////			else
////			{
//            return t_tems_str;
//            //}
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }


}
