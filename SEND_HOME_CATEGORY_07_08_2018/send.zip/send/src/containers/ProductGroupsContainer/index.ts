import ProductGroupsContainer from './ProductGroupsContainer'

export { ProductGroupsContainer };