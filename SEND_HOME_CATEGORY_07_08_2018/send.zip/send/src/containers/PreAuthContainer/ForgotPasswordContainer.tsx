import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';
import { isEmail, minLength5, maxLength5 } from '../../components/Forms/validator';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { forgotPasswordFetch } from '../../redux/forgot-password/actions';
import { captchaFetch } from '../../redux/captcha/actions';
import { ICaptchaResponseModel } from '../../redux/captcha/types';
import { IForgotPasswordFormData } from '../../redux/forms';
import { RouteComponentProps } from 'react-router';
import { Button } from '@blueprintjs/core';
import { getForgotPasswordIsLoading, getForgotPasswordHasError } from '../../redux/forgot-password/selectors';
import { getCaptcha, getCaptchaIsLoading } from '../../redux/captcha/selectors';
import './Password.css';

interface IPropsDispatchMap {
    captchaFetch: typeof captchaFetch;
    forgotPasswordFetch: typeof forgotPasswordFetch
}
interface IPropsStateMap {
    captcha: ICaptchaResponseModel | null;
    captchaIsLoading: boolean;
    forgotPasswordIsLoading: boolean;
    forgotPasswordHasError: string | null;
    form: any;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{}>;

class ForgotPasswordContainer extends React.Component<IProps> {

    public componentWillMount() {
        this.props.captchaFetch();
    }

    public componentWillReceiveProps(nextProps: IProps) {
        const loadingFinished = (this.props.forgotPasswordIsLoading === true && nextProps.forgotPasswordIsLoading === false);
        const withoutErrors = nextProps.forgotPasswordHasError == null;
        if(loadingFinished && withoutErrors) {
            this.props.history.replace('/reset-password/' + this.props.form.email.value + '/');
        }
    }

    public onSubmit(values: IForgotPasswordFormData) {
        this.props.forgotPasswordFetch(values);
    }

    public renderCaptcha() {

        if(this.props.captchaIsLoading) {
            return (<p>Loading Captcha</p>)
        } else if(this.props.captcha != null) {
            return (
                <React.Fragment>
                    <div className="secondBg"> <img style={{width: 200, height: 50}} src={`data:image/png;base64,${this.props.captcha.data}`} /> </div>
                    <div className="bp3-input-group">
                        <Control
                            model=".captcha"
                            validators={{
                                required: (val) => val && val.length,
                                minLength5,
                                maxLength5,
                            }}
                            component={"input"}
                            controlProps={{
                                className: "bp3-input inputButton",
                                placeholder: "Captcha",
                            }}
                        />
                        <Errors className="arrow_box"
                            model=".captcha"
                            show="touched"
                            messages={{
                                required: 'This field is required',
                                minLength5: 'Five characters expected',
                                maxLength5: 'Five characters expected'
                            }}
                        />
                    </div>
                </React.Fragment>
            )
        } else {
            return (<p>Error Loading Captcha</p>)
        }
    }

    public render() {
        return (
            <div>
                <Form
                    model="forms.forgotpassword"
                    onSubmit={(values) => this.onSubmit(values)}
                    // getDispatch={(dispatch: any) => this.formDispatch = dispatch}
                >
                    <div className="passwordBox">
                        <div className="title">
                            <p>Passwort Vergessen</p>
                        </div>
                        <div className="position">
                            <Control
                                model=".email"
                                validators={{
                                    required: (val) => val && val.length,
                                    isEmail
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "E-Mail"
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".email"
                                show="touched"
                                messages={{
                                    required: 'This field is required',
                                }}
                            />
                        </div>
                        <div>
                            {this.renderCaptcha()}
                        </div>
                    </div>
                    <div className="submitPassword">
                        <Button type="submit" loading={this.props.forgotPasswordIsLoading}>Neues Passwort anfordern</Button>
                    </div>

                </Form>
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    captcha: getCaptcha(state),
    captchaIsLoading: getCaptchaIsLoading(state),
    forgotPasswordIsLoading: getForgotPasswordIsLoading(state),
    forgotPasswordHasError: getForgotPasswordHasError(state),
    form: state.forms.forms.forgotpassword,
});

export default connect(mapStateToProps, {forgotPasswordFetch, captchaFetch})(ForgotPasswordContainer)