export const MESSAGE_ADD = '@@message/add';
export const MESSAGE_REMOVE = '@@message/remove';

type MessageType = 'error';

type MessageButtonType = 'confirm' | 'cancel' | 'ok';

interface IMessageButton {
    type: MessageButtonType;
    onPress: () => void;
}

export interface IMessage {
    id: number;
    type: MessageType
    title: string;
    body: string;
    dismissAfter?: number;
    allowDismissClickOutside?: boolean;
    buttons: IMessageButton[];
};

export const createErrorMessage = (title: string, body: string, onClose: () => void): IMessage => {
    return {
        id: + new Date(),
        type: 'error',
        title,
        body,
        allowDismissClickOutside: true,
        buttons: [
            {
                type: "confirm",
                onPress: onClose
            },
        ]
    }
}