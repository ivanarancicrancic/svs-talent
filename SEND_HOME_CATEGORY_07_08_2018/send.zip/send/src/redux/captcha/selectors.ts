import { IRootState } from '..'

export const getCaptcha = (state: IRootState) => state.captcha.data;
export const getCaptchaIsLoading = (state: IRootState) => state.captcha.loading;
export const getCaptchaHasError = (state: IRootState) => state.captcha.error;