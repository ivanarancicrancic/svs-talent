import { ActionType, getType } from 'typesafe-actions';
import { ICategoryResponseModel } from './types';

import * as actions from './actions';
import { categoryCreateSuccess } from '../category/actions'

const extActions = {...actions, categoryCreateSuccess};
export type CategoryListActions = ActionType<typeof extActions>;

export interface ICategoryListState {
    readonly data: ICategoryResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: ICategoryListState = {
    data: null,
    loading: false,
    error: null
};
  
export function categoryListReducer(state: ICategoryListState = INITIAL_STATE, action: CategoryListActions): ICategoryListState  {
    switch (action.type) {
        case getType(extActions.categoryListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.categoryListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.categoryListFail):
            return {...state, loading: false, error: action.payload};

        case getType(extActions.categoryCreateSuccess):
            return state; 

        default:
            return state;
    }
}