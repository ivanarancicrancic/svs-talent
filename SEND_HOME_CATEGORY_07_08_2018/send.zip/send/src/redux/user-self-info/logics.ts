import { createLogic } from 'redux-logic';
import axios from 'axios';

import { USER_SELF_INFO_FETCH, IUserResponseModel } from './types';
import { userSelfInfoFetch, userSelfInfoSuccess, userSelfInfoFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const userSelfInfoFetchLogic = createLogic({
    type: USER_SELF_INFO_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(userSelfInfoFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + '/api/user',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IUserResponseModel
                dispatch(userSelfInfoSuccess(result));
            }).catch(error => {
                console.log("Unauthorized");
                dispatch(userSelfInfoFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    userSelfInfoFetchLogic
];
