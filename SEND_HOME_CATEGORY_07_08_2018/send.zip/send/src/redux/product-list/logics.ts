import { createLogic } from 'redux-logic';
import axios from 'axios';

import { PRODUCT_LIST_FETCH, IProductResponseModel } from './types';
import { productListFetch, productListSuccess, productListFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const productListFetchLogic = createLogic({
    type: PRODUCT_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productListFetch)(action)) {
            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + '/api/categories/${action.payload.id}',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductResponseModel[]
                dispatch(productListSuccess(result));
            }).catch(error => {
                dispatch(productListFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    productListFetchLogic
];
