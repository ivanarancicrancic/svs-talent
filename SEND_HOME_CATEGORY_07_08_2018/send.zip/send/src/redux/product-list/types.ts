export const PRODUCT_LIST_FETCH = '@@user/product/list/FETCH';
export const PRODUCT_LIST_SUCCESS = '@@user/product/list/SUCCESS';
export const PRODUCT_LIST_FAIL = '@@user/product/list/FAIL';

export const PRODUCT_CREATE_FETCH = '@@product/create/FETCH';
export const PRODUCT_CREATE_SUCCESS = '@@product/create/SUCCESS';
export const PRODUCT_CREATE_FAIL = '@@product/create/FAIL';

export interface IProductResponseModel {
    id: number;
    name: string;
    numberOfViews: number;
};