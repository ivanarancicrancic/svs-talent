# Ersatzteilhandel24
> This is partial code(made with Java and React Redux) for displaying some functionalities of orders !

## Table of contents
* [General info](#general-info)
* [Screenshots](#screenshots)
* [Setup](#setup)
* [Code Functionality and Testing Explanation](#code-functionality-and-testing-explanation)
* [Features](#features)
* [Status](#status)

## General info
Here we  can see functionalities of listing orders, filter orders by date, preview each order details, edit the order infromation(price, quantity), delete articles from order, and cancel order 

## Screenshots
![Example screenshot](./img/listingOrders.png)
![Example screenshot](./img/orderDetails.png)
![Example screenshot](./img/editOrderDetails.png)
![Example screenshot](./img/exampleValuesEditOrderDetails.png)
![Example screenshot](./img/exampleValuesEditOrderDetailsAfterSaveDone.png)
![Example screenshot](./img/exampleCancelOrderModal.png)
![Example screenshot](./img/exampleCancelOrderModalAfterCancelDone.png)



## Setup
To run this project only import the dump file in MySQL Workbench, start the tomcat server for the backend Java application and start the frontend using Visual Studio Code, 
opening the orders_frontend-project-21-12-2018 folder and then go to view -> Integrated Terminal and for installaling the dependencies for the project included in the package.json file write this command: 
> yarn 
And after just run with this command:
> yarn start.

## Code Functionality and Testing Explanation
1. Here on clicking the tab Orders, we get the results from the starting code which is placed in StartedLayout component where I am doing the listing of the all orders, filtering the orders 
by date(using the Starting and the Ending date with the DatePickers), calculating the total prices of the active orders, and canceling the orders.  
2. On selecting any of the orders from the table the respective order details are opened on another page(which according to this project is the code in ManageOrder component), and on this page we can view all the info 
details of the selected order.
3. And from here we can click on Edit order button and then we will see another page(represented with EditOrder component) where we can edit all the details of the order. Here we can delete the specific articles 
from the order(I plan to also add another window here that before deleting will ask if we are sure that we want to detete that product from the order). And also here at the same time  we can edit any(with any combination and and all) 
of the quantities of the articles included in that order, and on click on Save changes all the new values will be saved in the database and all the orders will be reloaded with the new details 
and also if there are any article price changes then also the total prices will be recalculated after clicking on the button Save changes.   
4. And also when we are on the starting page with all the orders(got by clicking the tab Orders), here we can also cancel the orders(by clicking on cancel button on which we get modal that ask us what is the reason of canceling and after 
entering some reason and on clicking Cancel_this_order the order is canceled by writing status canceled into the database and also the canceling reason is saved in the database)   

## Features
List of features ready and TODOs for future development
* List orders with active status
* Filter orders by date
* Calculating total prices of active orders
* Canceling orders
* Preview order details and all articles included in the order
* Edit order details, remove any of articles included in the order, and edit any of the quantities of articles included in the order
* Cancel orders with reason for canceling

To-do list:
* Add another window here that before deleting product will ask if we are sure that we want to detete that product from the order
* Include the quantity of the articles in calculation of the total prices(now it is just for quantity of article: 1) 
* Preview the images of articles dinamicly from url of specific order article after having that image previously save on some another server

## Status
Project is: in progress but waiting for review status before continue with any further tasks

