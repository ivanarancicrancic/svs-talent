import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';
import { IOrderListState, OrderListActions, orderListReducer } from './order-list/reducer';
import { IFilteredOrderState, FilterOrderActions, filterOrderReducer } from './filterOrders/reducer';
import { IOrderDetailState, OrderDetailActions, orderDetailReducer } from './order-detail/reducer';
import { IOrderArticlesState, GetOrderArtictlesActions, getOrderArticlesReducer } from './order-articles/reducer';
import { formsReducer } from './forms';
import { IOrderSaveState, OrderSaveActions, orderSaveReducer } from './order-save/reducer';
import { orderCancelReducer, OrderCancelActions } from './cancelOrders/reducer';
import { IDecrementQuantityState, DecrementQuantityActions, decrementQuantityReducer } from './decrement-quantity/reducer';
import { IDeleteArticleFromOrderState, DeleteArticleFromOrderActions, deleteArticleFromOrderReducer } from './delete-article/reducer';
import { IArticlesListState, GetArticlesActions, getArticlesReducer } from './get-articles/reducer';
import { IUpdateNetPriceState, UpdateNetPriceActions, updateNetPriceReducer } from './updateNetPrice/reducer';
import { UpdateGrossPriceActions, IUpdateGrossPriceState, updateGrossPriceReducer } from './updateArticleGrossPrice/reducer';


export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    orderList: IOrderListState;
    filteredOrders: IFilteredOrderState;
    orderDetail: IOrderDetailState;
    savedOrder: IOrderSaveState;
    orderArticles: IOrderArticlesState;
    canceledOrder: IOrderDetailState;  
    forms: any;
    decrementedQuantity: IDecrementQuantityState;
    orderWithDeletedArticle: IDeleteArticleFromOrderState;
    articlesList: IArticlesListState;
    resultUpdateNetPrice: IUpdateNetPriceState;
    resultUpdateGrossPrice: IUpdateGrossPriceState;
    
}

export type RootAction = RouterAction
    | LocationChangeAction
    | OrderListActions
    | FilterOrderActions 
    | OrderDetailActions
    | GetOrderArtictlesActions
    | OrderSaveActions
    | OrderCancelActions
    | DecrementQuantityActions
    | DeleteArticleFromOrderActions
    | GetArticlesActions
    | UpdateNetPriceActions
    | UpdateGrossPriceActions


export const reducers = combineReducers<IRootState>({
    router: routerReducer,
    i18n: i18nReducer, 
    orderList: orderListReducer,
    filteredOrders: filterOrderReducer,
    orderDetail: orderDetailReducer,
    savedOrder: orderSaveReducer,
    orderArticles: getOrderArticlesReducer,
    canceledOrder: orderCancelReducer,
    forms: formsReducer,
    decrementedQuantity: decrementQuantityReducer,
    orderWithDeletedArticle: deleteArticleFromOrderReducer,
    articlesList: getArticlesReducer,
    resultUpdateNetPrice: updateNetPriceReducer,
    resultUpdateGrossPrice: updateGrossPriceReducer
});