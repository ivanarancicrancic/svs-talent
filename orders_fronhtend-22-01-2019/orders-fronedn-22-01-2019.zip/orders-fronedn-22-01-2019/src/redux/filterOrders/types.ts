export const FILTER_ORDER_FETCH = '@@user/filter/order/FETCH';
export const FILTER_ORDER_SUCCESS = '@@user/filter/order/SUCCESS';
export const FILTER_ORDER_FAIL = '@@user/filter/order/FAIL';

export interface IOrderResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string;
};