import { IRootState } from '..'

export const getOrderDetail = (state: IRootState) => state.orderDetail.data;
export const getOrderDetailLoading = (state: IRootState) => state.orderDetail.loading;
export const getOrderDetailHasError = (state: IRootState) => state.orderDetail.error;