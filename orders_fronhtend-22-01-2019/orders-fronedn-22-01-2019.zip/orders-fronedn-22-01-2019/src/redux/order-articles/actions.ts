import {
    GET_ORDER_ARTICLES_FETCH,
    GET_ORDER_ARTICLES_SUCCESS,
    GET_ORDER_ARTICLES_FAIL,
    IOrderArticleResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const getOrderArticlesFetch = createStandardAction(GET_ORDER_ARTICLES_FETCH)<{orderId: string}>();
export const getOrderArticlesSuccess = createStandardAction(GET_ORDER_ARTICLES_SUCCESS)<IOrderArticleResponseModel[]>();
export const getOrderArticlesFail = createStandardAction(GET_ORDER_ARTICLES_FAIL)<string>();
