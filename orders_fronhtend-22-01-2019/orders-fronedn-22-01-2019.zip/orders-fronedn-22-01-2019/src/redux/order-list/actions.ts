import {
    ORDER_LIST_FETCH,
    ORDER_LIST_SUCCESS,
    ORDER_LIST_FAIL,
    IOrderResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const orderListFetch = createStandardAction(ORDER_LIST_FETCH)();
export const orderListSuccess = createStandardAction(ORDER_LIST_SUCCESS)<IOrderResponseModel[]>();
export const orderListFail = createStandardAction(ORDER_LIST_FAIL)<string>();
