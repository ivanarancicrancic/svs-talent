import { ActionType, getType } from 'typesafe-actions';
import { IOrderArticleResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type UpdateGrossPriceActions = ActionType<typeof extActions>;

export interface IUpdateGrossPriceState {
    readonly data: IOrderArticleResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IUpdateGrossPriceState = {
    data: null,
    loading: false,
    error: null
};
  
export function updateGrossPriceReducer(state: IUpdateGrossPriceState = INITIAL_STATE, action: UpdateGrossPriceActions): IUpdateGrossPriceState  {
    switch (action.type) {
        case getType(extActions.updateGrossPriceFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.updateGrossPriceSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.updateGrossPriceFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}