// import { StringOrSymbol } from "../../../node_modules/typesafe-actions/dist/types";

export const UPDATE_GROSS_PRICE_FETCH = '@@user/update/netprice/FETCH';
export const UPDATE_GROSS_PRICE_SUCCESS = '@@user/update/netprice/SUCCESS';
export const UPDATE_GROSS_PRICE_FAIL = '@@user/update/netprice/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};


export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};


export interface IOrderArticleGrossPriceRequestModel {
    grossPrice: string;
    orArId: string;
   

}
