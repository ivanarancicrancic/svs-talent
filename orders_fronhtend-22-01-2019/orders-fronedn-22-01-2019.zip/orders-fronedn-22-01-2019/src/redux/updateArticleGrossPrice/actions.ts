import {
    UPDATE_GROSS_PRICE_FETCH,
    UPDATE_GROSS_PRICE_SUCCESS,
    UPDATE_GROSS_PRICE_FAIL, 
    IOrderArticleResponseModel,
    IOrderArticleGrossPriceRequestModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const updateGrossPriceFetch = createStandardAction(UPDATE_GROSS_PRICE_FETCH)<{newGrossPriceValue:IOrderArticleGrossPriceRequestModel}>();
export const updateGrossPriceSuccess = createStandardAction(UPDATE_GROSS_PRICE_SUCCESS)<IOrderArticleResponseModel>();
export const updateGrossPriceFail = createStandardAction(UPDATE_GROSS_PRICE_FAIL)<string>();

