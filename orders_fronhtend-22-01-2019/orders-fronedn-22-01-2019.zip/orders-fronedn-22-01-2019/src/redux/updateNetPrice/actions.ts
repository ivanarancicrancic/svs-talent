import {
    UPDATE_NET_PRICE_FETCH,
    UPDATE_NET_PRICE_SUCCESS,
    UPDATE_NET_PRICE_FAIL, 
    IOrderArticleResponseModel,
    IOrderArticleNetPriceRequestModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const updateNetPriceFetch = createStandardAction(UPDATE_NET_PRICE_FETCH)<{newNetPriceValue:IOrderArticleNetPriceRequestModel}>();
export const updateNetPriceSuccess = createStandardAction(UPDATE_NET_PRICE_SUCCESS)<IOrderArticleResponseModel>();
export const updateNetPriceFail = createStandardAction(UPDATE_NET_PRICE_FAIL)<string>();

