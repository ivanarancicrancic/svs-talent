import { ActionType, getType } from 'typesafe-actions';
import { IOrderArticleResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type UpdateNetPriceActions = ActionType<typeof extActions>;

export interface IUpdateNetPriceState {
    readonly data: IOrderArticleResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IUpdateNetPriceState = {
    data: null,
    loading: false,
    error: null
};
  
export function updateNetPriceReducer(state: IUpdateNetPriceState = INITIAL_STATE, action: UpdateNetPriceActions): IUpdateNetPriceState  {
    switch (action.type) {
        case getType(extActions.updateNetPriceFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.updateNetPriceSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.updateNetPriceFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}