export const CANCEL_ORDER_FETCH = '@@user/order/cancel/FETCH';
export const CANCEL_ORDER_SUCCESS = '@@user/order/cancel/SUCCESS';
export const CANCEL_ORDER_FAIL = '@@user/order/cancel/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
    status: string;
};

export interface IOrderCancelRequestModel {
    order_id: string;
    cancelReason: string;
};