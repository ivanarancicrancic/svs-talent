import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { Form, Control } from 'react-redux-form';
import DatePicker from 'react-date-picker';
import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { IOrderCancelRequestModel } from '../../redux/cancelOrders/types';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    
}

type IProps = IPropsDispatchMap & IPropsStateMap

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(132, 132, 132, 0.88)',
      width: '100%'
    }
  };


class StartLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modal3IsOpen: false,
           currentOrder: null,
           orderToSave: null
        
      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.handleCancelOrder = this.handleCancelOrder.bind(this);
        this.handleSubmitCancelOrderWithReason = this.handleSubmitCancelOrderWithReason.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    public componentWillMount() {
        Modal.setAppElement('body');
        this.props.orderListFetch();        
    }

     public componentWillReceiveProps(nextProps: IProps) {
            this.props.orderListFetch();         
           
                 
            // if(this.props.orderDetailData && this.props.orderDetailData !== nextProps.orderDetailData && nextProps.orderDetailData && this.props.orderArticlesData)
            // {    
            //     // this.props.getOrderArticlesFetch({order_id: this.props.orderDetailData.order_id});
            //     const order_id =  nextProps.orderDetailData.order_id;
            //     const orderId = order_id;
            //     this.props.getOrderArticlesFetch({orderId});
                
            // }  

             
    }
 
    public selectedRowHandel(order: IOrderResponseModel){
        const order_id = order.order_id;
        // const orderId = order_id;
        // this.props.getOrderArticlesFetch({orderId});
        // console.log("Articles: " + this.props.orderArticlesData);
        // this.props.orderDetailFetch({orderId});
        history.push(`/order/${order_id}`); 
        // history.push(`/order/${order_id}`);  
        // history.push(`/order/${order_id}`);  
        
    }

    public handleFilter(values:any){
        values.preventDefault();
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
        history.push(`/orders/filtered`);
      };
 
   public handleDateFrom(entryDate: any){
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
     };

   public handleDateTo(entryDate: any){
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
  };

  public handleCancelOrder(order:IOrderResponseModel) { 
    const orderId = order.order_id;
    this.props.orderDetailFetch({orderId});
    this.setState({modal3IsOpen: true});

 }
 
 public handleSubmitCancelOrderWithReason(value:any) {
     if(this.props.orderDetailData)     
     {
        const cancelValues: IOrderCancelRequestModel = {
            order_id: this.props.orderDetailData.order_id,
            cancelReason: value.order_cancel_reason
        }
     
    this.setState({modal3IsOpen: false});
    this.props.cancelOrderFetch({order_to_cancel: cancelValues});
    history.push('/start'); 
    }
    else
    {
      console.log("this.props.orderDetailData == NULL");
    }
 }
 
 public closeModal() {
  this.setState({modal3IsOpen: false});
}

 public renderOrderList() {

    let totalNetPrice = 0;
    let totalGrossPrice = 0;
    let totalNetPriceWD = 0;
    let totalGrossPriceWD = 0;
  
    if(this.props.orderData)
            {
            const ordersNetPrices = this.props.orderData.map( order => {
                if(order.status === "active"){
                return (
                    parseInt(order.netPrice, 10)
                 )
                }
                else 
                { 
                    return 0;
                }
             })

             const ordersGrossPrices = this.props.orderData.map( order => {
                if(order.status === "active"){
                return (
                    parseInt(order.grossPrice, 10)
                 )
                }
                else 
                { 
                    return 0;
                }
             })
            
             const ordersNetPricesWD = this.props.orderData.map( order => {
                if(order.status === "active"){
                return (
                    parseInt(order.netPriceWD, 10)
                 )
                }
                else 
                { 
                    return 0;
                
                }
             })

             const ordersGrossPricesWD = this.props.orderData.map( order => {
                if(order.status === "active"){
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
                }
                else 
                { 
                    return 0;
                }
             })

        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPrice = ordersNetPrices.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPrice = ordersGrossPrices.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWD = ordersNetPricesWD.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWD = ordersGrossPricesWD.reduce(summingReducer3, 0);
          }
          else { 
            totalNetPrice = 0;
            totalGrossPrice = 0;
            totalNetPriceWD = 0;
            totalGrossPriceWD = 0;     
              } 
   
            if(this.props.orderData)
            {
       return (
           <div className="dashboardTable">
               <table className="table bp3-html-table bp3-html-table-bordered">
               <thead>                  
               <tr >
                       <th>Order ID</th>
                       <th>Oder DATE</th>
                       <th>FirstName </th>
                               <th>LastName </th>
                               <th>Country </th>
                               <th>Company </th>
                               <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>   
                                    <th>Status</th>  
                                    <th>Cancel reason</th> 
                       </tr>

               </thead>
               <tbody>
                   
                   {this.props.orderData.map( order => {
                    // let netPrice = 0;
                    // this.props.getOrderArticlesFetch({orderId:order.order_id});
                    //      if(this.props.orderArticlesData){
                    //         this.props.orderArticlesData.map( orderArticle => {
                    //               netPrice = netPrice + parseInt(order.netPrice,10) * parseInt(orderArticle.articleQuantity,10);  
                                   
                    //         })

                    //      }                      

                       return (
                           <tr key={order.order_id}  className = "order_hovered">
                               <td onClick={(e) => this.selectedRowHandel(order)}><b>{order.order_id}</b></td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.orderDate} </td> 
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.firstName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.lastName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.country} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.companyName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPrice} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPrice} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPriceWD} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPriceWD} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.status} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.cancelReason} </td>
                                    <td><button type="button" onClick={(e) => this.handleCancelOrder(order)} className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                           </tr>
                       )
                   })}
                 
                  
                 <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                  
               </tbody>
               </table>
           </div>
       ) 
      }
        else { return null;}  
    
}

    public render() {
        
        if(this.props.orderDetailData){     
        return (
            <div className="grid100">
    <Modal 
  isOpen={this.state.modal3IsOpen}
  onRequestClose={this.closeModal}
  style={customStyles}
  contentLabel="Example Modal"
>
 <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div> 
  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER TO CANCEL DETAILS: </div>
  <br/>

  <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitCancelOrderWithReason(info) }
                >   
                 <tr>
                   <td>
                    <div>
                        <label hidden={true} htmlFor="orderid" className="bp3-file-input" ><b>Order Id: </b> {this.props.orderDetailData.order_id}</label> &nbsp;  &nbsp; 
                        <br/>
                        <label htmlFor="order_cancel_reason" className="bp3-file-input"><b>Reason for canceling: </b></label>  &nbsp;  &nbsp;  
                        <Control.text
                            className="bp3-input"
                            model=".order_cancel_reason" 
                        /> 
                        <br/>
                    </div> 
                   </td>     
                 </tr>
                <tr>                 
               <div style={{position: 'absolute', bottom: 23, right: 33}} > <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#FF0000"}} > Cancel this order  </button>
                 </div>
                        </tr>
     
        </Form>
</Modal>

             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderOrderList()}   
            </div>
        )
    }
    else {
        return (
            <div className="grid100">
 
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderOrderList()}   
            </div>
        )


    }
    }
}


const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(StartLayout)


