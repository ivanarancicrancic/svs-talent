import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './ManageOrderLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import EditableLabel from 'react-editable-label';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { RouteComponentProps } from 'react-router';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

class StartLayout extends React.Component<IProps>{
   public state = {
           currentOrder: null,
         
      }
    
      constructor(props: any) {
        super(props);
        this.editOrder = this.editOrder.bind(this);
       
    }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        this.props.orderDetailFetch({orderId});
        // const ORDER_ID_P = orderId;
        // const ORDER_ID = ORDER_ID_P;
        this.props.getOrderArticlesFetch({orderId});

    }

    public componentWillReceiveProps(nextProps: IProps) {
        this.props.orderDetailFetch({orderId: this.props.match.params.orderId});

            if(this.props.orderDetailData && nextProps.orderDetailData )
        {

            {console.log("parseInt(this.props.orderDetailData.grossPrice,10): " + parseInt(this.props.orderDetailData.grossPrice,10))}
            console.log("Before calling getOrderArticlesFetch in componentWillReceiveProps in ManageOrder");
            this.props.getOrderArticlesFetch({orderId: nextProps.orderDetailData.order_id});
            // const order_id =  this.props.orderDetailData.order_id;
            // history.push(`/order/${order_id}`);  
        }
        
       
}

  public editOrder(orderid:any){   
    const orderId = orderid;
    history.push(`/order/edit/${orderId}`);      

}

    public render() {  
        if(this.props.orderDetailData){
            const orderid= this.props.orderDetailData.order_id;
     
            if(this.props.orderArticlesData)
            {   
               
        return (
            <div className="grid100">
        <form>
    
      <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
      <br/>
 
     <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.firstName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.lastName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.companyName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        />  </div><br/>
     <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                            initialValue={this.props.orderDetailData.paymentMethod}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.email}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.orderDate}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.phoneNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.shippingWay}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.street}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.houseNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.postcode}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.city}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.country}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div>
     <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
     <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
     
     <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
     <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
     <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
     <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.grossPriceWD,10)}</div>
       <br/>

    
        <div className = "modalTText" style={{position: "absolute", right: 20, top: 500 }}>
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
       </div>
                
      </form>
      <div  style={{ position: "absolute", left: 748, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
      {this.props.orderArticlesData.map( (orderArticle, index) => {
                     return (
                
                        <div key={orderArticle.orArId}>
                           
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130,position: "absolute", right: 160, top: 154 }} /> </tr>
                           <tr> <div style={{position: "absolute", left: 748, top: 285 + index * 100  }} > <b> ARTICLE:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                           <tr><div style={{position: "absolute", left: 748, top: 300 + index * 100 }} > <b> Net price:  </b> &nbsp;  {orderArticle.articleNetPrice} </div></tr>
                           <tr><div style={{position: "absolute", left: 748, top: 315 + index * 100 }} > <b> Gross price:  </b> &nbsp;  {orderArticle.articleGrossPrice} </div></tr>
                           <tr><div style={{position: "absolute", left: 748, top: 330 + index * 100 }} > <b> Net price WD:  </b> &nbsp;  {orderArticle.articleNetPriceWD} </div></tr>
                           <tr><div style={{position: "absolute", left: 748, top: 345 + index * 100 }} > <b> Gross price WD:  </b> &nbsp;  {orderArticle.articleGrossPriceWD} </div></tr>
                           <tr><div style={{position: "absolute", left: 748, top: 360 + index * 100 }} > <b> QUANTITY:  </b> &nbsp;  {orderArticle.articleQuantity} </div></tr>
                           
                               </div>          
                       
                    )
                })}
      
          <br/>
                </div>
    
)
                

     

   }
   else{
    return (
        <div className="grid100">
  

  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
  <br/>

 <label><b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;  {this.props.orderDetailData.firstName}
 <br/>
 <label><b>Last name: </b></label>  &nbsp;  &nbsp;  &nbsp; {this.props.orderDetailData.lastName}
                        <br/>
<label><b> Company: </b> </label> &nbsp;  &nbsp;  &nbsp;  
                       {this.props.orderDetailData.companyName}
         <br/>
<label><b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; {this.props.orderDetailData.paymentMethod}
                      <br/>
<label><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp; {this.props.orderDetailData.email}
                      <br/>
 <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.orderDate}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.phoneNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.shippingWay}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.street}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.houseNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.postcode}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.city}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.country}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div>
 <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
 <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
 <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
 <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
 <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
 <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
 
   <br/>
    <div className = "modalTText" >
    <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
   </div>
            
   <div  style={{ position: "absolute", left: 748, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
       NO ARTICLES IN THIS ORDER
      
          <br/>

      <br/>
            </div>
)
     }
      }

    else {
    return null;
    }
}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(StartLayout)

