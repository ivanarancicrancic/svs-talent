import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './EditOrder.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getDecrementedQuantity } from '../../redux/decrement-quantity/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { decrementQuantityFetch } from '../../redux/decrement-quantity/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
// import { IOrderArticleQuantityRequestModel } from '../../redux/decrement-quantity/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getArticles } from '../../redux/get-articles/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { Form, Control } from 'react-redux-form';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { deleteArticleFromOrderFetch } from '../../redux/delete-article/actions'
import { getArticlesFetch } from '../../redux/get-articles/actions'
import { IOrderSaveRequestModel } from '../../redux/order-save/types';
import { IArticleResponseModel } from '../../redux/get-articles/types';
import { RouteComponentProps } from 'react-router';
import { getSavedOrder } from '../../redux/order-save/selectors';
import * as Modal from 'react-modal';
import { IOrderArticleQuantityRequestModel } from 'src/redux/decrement-quantity/types';
import { IOrderArticleNetPriceRequestModel } from 'src/redux/updateNetPrice/types';
import { updateNetPriceFetch } from 'src/redux/updateNetPrice/actions';
import { IOrderArticleGrossPriceRequestModel } from 'src/redux/updateArticleGrossPrice/types';
import { updateGrossPriceFetch } from 'src/redux/updateArticleGrossPrice/actions';
// import { faCalendarPlus } from '../../../node_modules/@fortawesome/free-solid-svg-icons';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
    decrementQuantityFetch: typeof decrementQuantityFetch;
    deleteArticleFromOrderFetch: typeof deleteArticleFromOrderFetch;
    getArticlesFetch: typeof getArticlesFetch;
    updateNetPriceFetch: typeof updateNetPriceFetch;
    updateGrossPriceFetch: typeof updateGrossPriceFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    decrementQuantityData: IOrderArticleResponseModel | null;
    deleteArticleFromOrderData: IOrderDetailResponseModel | null;
    getArticlesData: IArticleResponseModel[] | null;
    updateNetPriceData: IOrderArticleResponseModel | null;
    updateGrossPriceData: IOrderArticleResponseModel | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(255, 0, 0, 0.7)',
      width: '100%'
    }
  };


class EditOrder extends React.Component<IProps>{
   public state = {
           orderToSave: null,
           decremented: 0,
           list: [], 
           listNetPrice: [],
           listGrossPrice: [],
           listOrArId: [],
           listIndex: [],
           listNetPriceIndex: [],
           listGrossPriceIndex: [],
           currentIndex: 0,
           currentOrArIndex: 0,
           modal3IsOpen: false,
           articleToDelete: null,
           newNetPrice: 0,
           articleNetPrices: []
      }
    
      constructor(props: any) {
        super(props);
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleDecrement = this.handleDecrement.bind(this);
        this.handleSetQuantity = this.handleSetQuantity.bind(this);
        this.handleSetCurrentIndex = this.handleSetCurrentIndex.bind(this);
        this.handleDeleteArticleFromOrder = this.handleDeleteArticleFromOrder.bind(this);
        this.handleSetNetPrice = this.handleSetNetPrice.bind(this);
        this.handleSetGrossPrice = this.handleSetGrossPrice.bind(this);
       

       }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({orderId});    
        if(this.props.orderArticlesData)
        {
            this.setState({list: this.props.orderArticlesData.map(orderArticle => {
                return orderArticle.articleQuantity;
        })});

        this.setState({articleNetPrices: this.props.orderArticlesData.map(orderArticle => {
            // console.log("OLD Article Net price: " + orderArticle.articleNetPrice);
            return orderArticle.articleNetPrice;
            })});

    
        this.setState({listNetPrice: this.props.orderArticlesData.map(orderArticle => {
            // console.log("OLD Article Net price: " + orderArticle.articleNetPrice);
            return orderArticle.articleNetPrice;
            })});

          
        
            this.setState({listGrossPrice: this.props.orderArticlesData.map(orderArticle => {
                // console.log("OLD Article Gross price: " + orderArticle.articleGrossPrice);
                return orderArticle.articleGrossPrice;
                })});
                
     
        this.setState({listOrArId: this.props.orderArticlesData.map(orderArticle => {
        return orderArticle.orArId;
         })});
        }
        
        if(this.props.orderDetailData){

            this.setState({newNetPrice: this.props.orderDetailData.netPrice});
        }
  
    }

  public componentWillReceiveProps(nextProps: IProps) {

      if(this.props.orderArticlesData){
        this.setState({listNetPrice: this.props.orderArticlesData.map(orderArticle => {
            console.log("OLD Article Net price: " + orderArticle.articleNetPrice);
            return orderArticle.articleNetPrice;
            })});

            this.state.listNetPrice.map(price => {console.log("FIRST NET PRICE: " + price)});
               
      }


   if(this.props.orderSavedData)
   {
     if(nextProps.orderSavedData !== this.props.orderSavedData)
       {
        history.push(`/start`); 
       }
    }

    return ( (e:any) => {
    e.preventDefault();       
});
}

   
  public handleDeleteArticleFromOrder(orderArticle: any){
    this.setState({modal3IsOpen: true});
    console.log("Before deleting article from order with id:" + orderArticle.orArId);
   if(this.props.orderDetailData){
//   this.props.deleteArticleFromOrderFetch({orArId: orderArticle.orArId});
//   this.props.getOrderArticlesFetch({orderId: orderArticle.order_id})
//   history.push(`/start`); 
        this.setState({articleToDelete: orderArticle.orArId}); 
}
  }


  public handleDeleteArticleFromOrderFinal(orArId: any){
  this.setState({modal3IsOpen: false});
    if(this.props.orderDetailData){
  this.props.deleteArticleFromOrderFetch({orArId});
//   this.props.getOrderArticlesFetch({orderId: orderArticle.order_id})
  history.push(`/start`); 
}
  }


public handleSetCurrentIndex(index: any, orArIndex: any){
    this.setState({currentIndex: index});
    this.setState({currentOrArIndex: orArIndex});
}

public handleDeleteArticleFromOrderCancel(){
 this.setState({modal3IsOpen: false});

}

public handleSetQuantity(event: any) {
    this.setState({list: this.state.list.map((qunatity, j) => {
        if(j === this.state.currentIndex){
            return event.target.value;
        }
        else{
            return qunatity;
        }
    })});

       let pomList: any = [];
     pomList = this.state.listIndex;
     
     let flag = false;
     this.state.listIndex.map((index, j) => {
        if(index === this.state.currentIndex){
           flag = true;
        }
        
    })
    if(flag === false)
    {
     pomList.push(this.state.currentIndex);
    }
     this.setState({listIndex: pomList});
    
}

public handleSetNetPrice(event: any){


    if(this.state.listNetPrice){
        // this.state.listNetPrice.map(price => {console.log("FIRST NET PRICE: " + price)});
        this.setState({listNetPrice: this.state.listNetPrice.map((price, j) => {
            if(j === this.state.currentIndex){
                return event.target.value;
            }
            else{
                return price;
            }
        })});
        }
           let pomList: any = [];
         pomList = this.state.listNetPriceIndex;
         
         let flag = false;
         this.state.listNetPriceIndex.map((index, j) => {
            if(index === this.state.currentIndex){
               flag = true;
            }
            
        })
        if(flag === false)
        {
         pomList.push(this.state.currentIndex);
        }
         this.setState({listNetPriceIndex: pomList});
    

    if(this.props.orderDetailData){
    
        console.log("this.props.orderDetailData =! null");
        let newNetPrice = this.state.newNetPrice;
        console.log("current netPrice: " + newNetPrice);
        let newGrossPrice = parseInt(this.props.orderDetailData.grossPrice,10);
        console.log("current grossPrice: " + newGrossPrice);
        let newNetPriceWD = parseInt(this.props.orderDetailData.netPriceWD,10);
        console.log("current newNetPriceWD: " + newNetPriceWD);
        let newGrossPriceWD = parseInt(this.props.orderDetailData.grossPriceWD,10);
        console.log("current newGrossPriceWD: " + newGrossPriceWD);
        this.props.getOrderArticlesFetch({orderId:this.props.orderDetailData.order_id});
             if(this.props.orderArticlesData){ 
                    this.state.listOrArId.map( (orArId, index)=> {
                    if(this.props.orderDetailData){
                        if(event.target.value && this.props.orderArticlesData){
                            
                            this.props.orderArticlesData.map( (orAr)=> {
                               
                                console.log("NetPrice: " + orAr.articleNetPrice);
                                console.log("GrossPrice: " + orAr.articleGrossPrice);
                                console.log("NetPriceWD: " +  orAr.articleNetPriceWD);
                                console.log("GrossPriceWD: " + orAr.articleGrossPriceWD);

                            } )

                            console.log("BASIC NET PRICE: " + this.props.orderArticlesData[index].articleNetPrice)
                    newNetPrice = newNetPrice - parseInt(this.state.listNetPrice[index],10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                    console.log("NEW partial NET PRICE SUM TO BE SAVED: " + newNetPrice);
                    console.log("NEW NET PRICE ARTICLE VALUE: " + this.state.listNetPrice[index]);

                    newNetPrice = newNetPrice + event.target.value;
                    console.log("NEW NET PRICE SUM TO BE SAVED: " + newNetPrice);

                    console.log("BASIC GROSS PRICE: " + this.props.orderArticlesData[index].articleGrossPrice)
                    newGrossPrice = newGrossPrice - parseInt(this.props.orderArticlesData[index].articleGrossPrice,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                  
                    newGrossPrice = newGrossPrice + parseInt(this.state.listGrossPrice[index],10) * parseInt(this.state.list[index],10);
                    console.log("NEW GROSS PRICE SUM TO BE SAVED: " + newGrossPrice);


                    console.log("BASIC NET PRICE WD: " + this.props.orderArticlesData[index].articleNetPriceWD)
                    newNetPriceWD = newNetPriceWD - parseInt(this.props.orderArticlesData[index].articleNetPriceWD,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                   console.log("NEW NET PRICE WD SUM TO BE SAVED: " + newNetPriceWD);

                    newNetPriceWD = newNetPriceWD + parseInt(this.props.orderArticlesData[index].articleNetPriceWD,10) * parseInt(this.state.list[index],10);
                        
                    console.log("BASIC GROSS PRICE WD: " + this.props.orderArticlesData[index].articleGrossPriceWD)
                    newGrossPriceWD = newGrossPriceWD - parseInt(this.props.orderArticlesData[index].articleGrossPriceWD,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                   console.log("NEW GROSS PRICE WD SUM TO BE SAVED: " + newGrossPriceWD);

                    newGrossPriceWD = newGrossPriceWD + parseInt(this.props.orderArticlesData[index].articleGrossPriceWD,10) * parseInt(this.state.list[index],10);

                
                }  
                }  
                    
                });
            
             }  


              this.setState({newNetPrice});

 
    }
}

public handleSetGrossPrice(event: any){
    this.setState({listGrossPrice: this.state.listGrossPrice.map((price, j) => {
        if(j === this.state.currentIndex){
            return event.target.value;
        }
        else{
            return price;
        }
    })});

       let pomList: any = [];
     pomList = this.state.listGrossPriceIndex;
     
     let flag = false;
     this.state.listGrossPriceIndex.map((index, j) => {
        if(index === this.state.currentIndex){
           flag = true;
        }
        
    })
    if(flag === false)
    {
     pomList.push(this.state.currentIndex);
    }
     this.setState({listGrossPriceIndex: pomList});

}




    public handleDecrement(index: any) {
        this.setState({list: this.state.list.map((qunatity, j) => {
            if(j === index){
                return (parseInt(qunatity,10) - 1).toString();
            }
            else{
                return qunatity;
            }
        })});
        }
    

public handleSubmitSaveOrder(value:any) {
    console.log("Entered handleSubmitSaveOrder");
    if(this.props.orderDetailData){
    
        console.log("this.props.orderDetailData =! null");
        let newNetPrice = parseInt(this.props.orderDetailData.netPrice,10);
        console.log("current netPrice: " + newNetPrice);
        let newGrossPrice = parseInt(this.props.orderDetailData.grossPrice,10);
        console.log("current grossPrice: " + newGrossPrice);
        let newNetPriceWD = parseInt(this.props.orderDetailData.netPriceWD,10);
        console.log("current newNetPriceWD: " + newNetPriceWD);
        let newGrossPriceWD = parseInt(this.props.orderDetailData.grossPriceWD,10);
        console.log("current newGrossPriceWD: " + newGrossPriceWD);
        this.props.getOrderArticlesFetch({orderId:this.props.orderDetailData.order_id});
             if(this.props.orderArticlesData){ 
                    this.state.listOrArId.map( (orArId, index)=> {
                    if(this.props.orderDetailData){
                        if(value.netPrice && this.props.orderArticlesData){
                            
                            this.props.orderArticlesData.map( (orAr)=> {
                               
                                console.log("NetPrice: " + orAr.articleNetPrice);
                                console.log("GrossPrice: " + orAr.articleGrossPrice);
                                console.log("NetPriceWD: " +  orAr.articleNetPriceWD);
                                console.log("GrossPriceWD: " + orAr.articleGrossPriceWD);

                            } )

                            console.log("BASIC NET PRICE: " + this.props.orderArticlesData[index].articleNetPrice)
                    newNetPrice = newNetPrice - parseInt(this.props.orderArticlesData[index].articleNetPrice,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                    console.log("NEW partial NET PRICE SUM TO BE SAVED: " + newNetPrice);
                    console.log("NEW NET PRICE ARTICLE VALUE: " + this.state.listNetPrice[index]);

                    newNetPrice = newNetPrice + parseInt(this.state.listNetPrice[index],10) * parseInt(this.state.list[index],10);
                    console.log("NEW NET PRICE SUM TO BE SAVED: " + newNetPrice);

                    console.log("BASIC GROSS PRICE: " + this.props.orderArticlesData[index].articleGrossPrice)
                    newGrossPrice = newGrossPrice - parseInt(this.props.orderArticlesData[index].articleGrossPrice,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                  
                    newGrossPrice = newGrossPrice + parseInt(this.state.listGrossPrice[index],10) * parseInt(this.state.list[index],10);
                    console.log("NEW GROSS PRICE SUM TO BE SAVED: " + newGrossPrice);


                    console.log("BASIC NET PRICE WD: " + this.props.orderArticlesData[index].articleNetPriceWD)
                    newNetPriceWD = newNetPriceWD - parseInt(this.props.orderArticlesData[index].articleNetPriceWD,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                   console.log("NEW NET PRICE WD SUM TO BE SAVED: " + newNetPriceWD);

                    newNetPriceWD = newNetPriceWD + parseInt(this.props.orderArticlesData[index].articleNetPriceWD,10) * parseInt(this.state.list[index],10);
                        
                    console.log("BASIC GROSS PRICE WD: " + this.props.orderArticlesData[index].articleGrossPriceWD)
                    newGrossPriceWD = newGrossPriceWD - parseInt(this.props.orderArticlesData[index].articleGrossPriceWD,10) * parseInt(this.props.orderArticlesData[index].articleQuantity,10); 
                   console.log("NEW GROSS PRICE WD SUM TO BE SAVED: " + newGrossPriceWD);

                    newGrossPriceWD = newGrossPriceWD + parseInt(this.props.orderArticlesData[index].articleGrossPriceWD,10) * parseInt(this.state.list[index],10);

                
                }  
                }  
                    
                });
            
             }                      



    const newValues: IOrderSaveRequestModel = {

        order_id: this.props.orderDetailData.order_id,
        orderDate: new Date(),
        paymentMethod: this.props.orderDetailData.paymentMethod,
        shippingWay: this.props.orderDetailData.shippingWay,
        anrede: "anrede",
        firstName: this.props.orderDetailData.firstName,
        lastName: this.props.orderDetailData.lastName,
        companyName: this.props.orderDetailData.companyName,
        country: this.props.orderDetailData.country,
        street: this.props.orderDetailData.street,
        houseNumber: this.props.orderDetailData.houseNumber,
        city: this.props.orderDetailData.city,
        postcode: this.props.orderDetailData.postcode,
        phoneNumber: this.props.orderDetailData.phoneNumber, 
        email: this.props.orderDetailData.email, 
        latest: 1,
        netPrice: String(newNetPrice),
        grossPrice: String(newGrossPrice),
        netPriceWD:  String(newNetPriceWD),
        grossPriceWD: String(newGrossPriceWD)
    }


    console.log(newValues);
    this.props.orderSaveFetch({orderToSave: newValues});

    this.state.listIndex.map(index => {
        const item = this.state.list[index];
        const orderArticle = this.state.listOrArId[index];
        const NEW_QUANTITY_VALUE: IOrderArticleQuantityRequestModel = {
          quantity: item,
          orArId: orderArticle
      }
  
      this.props.decrementQuantityFetch({newQuantityValue: NEW_QUANTITY_VALUE});
         });
      this.props.orderListFetch();      
     

    this.state.listNetPriceIndex.map(index => {
        const item = this.state.listNetPrice[index];
        const orderArticle = this.state.listOrArId[index];
        const NEW_NET_PRICE_VALUE: IOrderArticleNetPriceRequestModel = {
          netPrice: item,
          orArId: orderArticle
      }
  
      this.props.updateNetPriceFetch({newNetPriceValue: NEW_NET_PRICE_VALUE});
         });

    this.state.listGrossPriceIndex.map(index => {
        const item = this.state.listGrossPrice[index];
        const orderArticle = this.state.listOrArId[index];
        const NEW_GROSS_PRICE_VALUE: IOrderArticleGrossPriceRequestModel = {
          grossPrice: item,
          orArId: orderArticle
      }
  
      this.props.updateGrossPriceFetch({newGrossPriceValue: NEW_GROSS_PRICE_VALUE});
         });
      this.props.orderListFetch();      


   history.push(`/start`); 
    }
    else {
        console.log("Order not loaded");
    }
}

    public render() {

       if(this.state.modal3IsOpen){
     return(
        <div className="grid100">
<Modal 
  isOpen={this.state.modal3IsOpen}
  style={customStyles}
  contentLabel="Example Modal"
>

  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ARE YOU SURE YOU WANT TO REMOVE THIS ARTICLE FROM THE ORDER?  </div>
  <br/>
  <br/>
  <br/>

                <tr>                 
               <div style={{position: 'absolute', bottom: 23, right: 533}} > <button type="button" className="bp3-button" style={{backgroundColor : "green"}} onClick={(e) => this.handleDeleteArticleFromOrderFinal(this.state.articleToDelete)} >Yes  </button>
                 </div>
               
 <div style={{position: 'absolute', bottom: 23, right: 583}} > <button type="button" className="bp3-button" style={{backgroundColor : "rgb(255,255,0)"}} onClick={(e) => this.handleDeleteArticleFromOrderCancel()} >Cancel  </button>
                 </div>

                        </tr>
     
     
</Modal>

         </div>
     )
       }
       else{
        let start =0;
        const numbers:any = [];
        if(this.props.orderDetailData){
            if(this.props.orderArticlesData)
            {   
        return (
            <div className="grid100">
         <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitSaveOrder(info) }             
                >   
                 <tr>
                   <td>
               
                   <div >
                      <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                     
                        <br/>

                        <label htmlFor="firstName" className="bp3-file-input"><b>First name:  &nbsp;  &nbsp;  {this.props.orderDetailData.firstName} </b></label>  &nbsp;  &nbsp;  
                        {/* <Control.text
                            className="bp3-input"
                            model=".firstName"
                            defaultValue={this.props.orderDetailData.firstName} 
                        /> */}
                           

                     <br/>
                 
                        <label htmlFor="lastName" className="bp3-file-input"><b>Last name:  &nbsp;  &nbsp; {this.props.orderDetailData.lastName}  </b></label>
                        {/* <Control.text
                            className="bp3-input"
                            model=".lastName"
                            defaultValue={this.props.orderDetailData.lastName} 
                        /> */}
                     <br/>

                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name: &nbsp;  &nbsp; {this.props.orderDetailData.companyName} </b></label> &nbsp;  &nbsp;
                        {/* <Control.text
                            className="bp3-input"
                            model=".companyName"
                            defaultValue={this.props.orderDetailData.companyName} 
                        /> */}
                     <br/>

                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:  &nbsp;  &nbsp; {this.props.orderDetailData.paymentMethod} </b></label> &nbsp;  &nbsp;
                        {/* <Control.text
                            className="bp3-input"
                            model=".paymentMethod"
                            defaultValue={this.props.orderDetailData.paymentMethod} 
                        /> */}
                     <br/>

                          <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:  &nbsp;  &nbsp; {this.props.orderDetailData.shippingWay} </b></label>
                        {/* <Control.text
                            className="bp3-input"
                            model=".shippingWay"
                            defaultValue={this.props.orderDetailData.shippingWay} 
                        /> */}
                     <br/>


                                             <label htmlFor="email" className="bp3-file-input"><b>Email: &nbsp;  &nbsp; {this.props.orderDetailData.email}  </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".email"
                            defaultValue={this.props.orderDetailData.email} 
                        /> */}
                     <br/>

                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:  &nbsp;  &nbsp; {this.props.orderDetailData.phoneNumber}</b></label>
                        {/* <Control.text
                            className="bp3-input"
                            model=".phoneNumber"
                            defaultValue={this.props.orderDetailData.phoneNumber} 
                        /> */}
                     <br/>

                            <label htmlFor="street" className="bp3-file-input"><b>Street:  &nbsp;  &nbsp; {this.props.orderDetailData.street}  </b></label>
                        {/* <Control.text
                            className="bp3-input"
                            model=".street"
                            defaultValue={this.props.orderDetailData.street} 
                        /> */}
                     <br/>

                    
                    <label htmlFor="houseNumber" className="bp3-file-input"><b>House number: &nbsp;  &nbsp; {this.props.orderDetailData.houseNumber}  </b></label>
                        {/* <Control.text
                            className="bp3-input"
                            model=".houseNumber"
                            defaultValue={this.props.orderDetailData.houseNumber} 
                        /> */}
                     <br/>

                    <label htmlFor="postcode" className="bp3-file-input"><b>Post code:  &nbsp;  &nbsp;{this.props.orderDetailData.postcode} </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".postcode"
                            defaultValue={this.props.orderDetailData.postcode} 
                        /> */}
                     <br/>

                    <label htmlFor="city" className="bp3-file-input"><b>City: &nbsp;  &nbsp; {this.props.orderDetailData.city}</b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".city"
                            defaultValue={this.props.orderDetailData.city} 
                        /> */}
                     <br/>

                    <label htmlFor="country" className="bp3-file-input"><b>Country: &nbsp;  &nbsp;  {this.props.orderDetailData.country} </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".country"
                            defaultValue={this.props.orderDetailData.country} 
                        /> */}
                     <br/>

 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: &nbsp;  &nbsp; {this.state.newNetPrice}  </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".netPrice"
                            defaultValue={this.props.orderDetailData.netPrice} 
                        /> */}
                     <br/>


 <label htmlFor="grossPrice" className="bp3-file-input"><b>Gross price:&nbsp;  &nbsp; {this.props.orderDetailData.grossPrice}  </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".grossPrice"
                            defaultValue={this.props.orderDetailData.grossPrice} 
                        /> */}
                     <br/>

 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): &nbsp;  &nbsp; {this.props.orderDetailData.netPriceWD}  </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".netPriceWD"
                            defaultValue={this.props.orderDetailData.netPriceWD} 
                        /> */}
                     <br/>
                     

 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): &nbsp;  &nbsp;  {this.props.orderDetailData.grossPriceWD} </b></label> 
                        {/* <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderDetailData.grossPriceWD} 
                        /> */}
                     <br/>
                    </div> 
                  
                   </td>
        
         </tr>
       <div  >
      <div  style={{ position: "absolute", left: 748, top: 120  }}> <b>PRODUCTS INCLUDED: </b></div>
     {this.props.orderArticlesData.map( (orderArticle, index) => {
                     
                const pos =  140 + start*index;                 
                numbers.push(parseInt(orderArticle.articleQuantity,10));
                     return (
                        
                        <div key={orderArticle.orArId}  >
                           
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130, position: "absolute", right: 160, top: pos}} /> </tr>
                           <tr> <div style={{position: "absolute", left: 748, top: 275 + index * 185  }} > <b> Article:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                            <tr><div style={{position: "absolute", left: 748, top: 300 + index * 185  }} > <label className="bp3-file-input"><b>Net price: </b></label>  &nbsp;  &nbsp;  
                       
                       <Control.text
                           className="bp3-input"
                           model={".netPrice" + index}
                         
                           defaultValue = {orderArticle.articleNetPrice}
                           onChange={this.handleSetNetPrice}
                       onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                       /></div></tr>

                             <tr><div style={{position: "absolute", left: 748, top: 335 + index * 185  }} ><label className="bp3-file-input"><b>Gross price: </b></label>  &nbsp;  &nbsp;  
                       
                       <Control.text
                           className="bp3-input"
                           model={".grossPrice" + index}
                         
                           defaultValue = {orderArticle.articleGrossPrice}
                           onChange={this.handleSetGrossPrice}
                           onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                       /></div></tr>


                           <tr><div style={{position: "absolute", left: 748, top: 365 + index * 185 }} > <b> Quantity to save:  </b> &nbsp; {this.state.list[index]} </div></tr>
                      <br/>
            
                    <div style={{position: "absolute", left: 748, top: 369 + index*185}} >
                    <br/>
                    <label className="bp3-file-input"><b>Strict quantity: </b></label>  &nbsp;  &nbsp;  
                       
                        <Control.text
                            className="bp3-input"
                            model={".quantity1" + index}
                          

                            onChange={(e) => {this.handleSetQuantity; this.handleSetNetPrice;}}
                        onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                        />
                    </div>


                           <div style={{position: "absolute", right: 45, top: 420 + index*185}} ><button type="button"  style={{backgroundColor : "#add8e6"}} onClick={() => {if(window.confirm('Are you sure you want to delete this article from the order?')){this.handleDeleteArticleFromOrderFinal(orderArticle.orArId)};}} 
                        //    onClick={(e) => this.handleDeleteArticleFromOrder(orderArticle)} className="bp3-button" style={{backgroundColor : "red"}}
                            > Delete article </button></div>
                                 </div>          
                               
                    )
                   start ++;
               })}

 </div>

                 <tr>
       <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4", position: "absolute", left: 360, top: 700 }} > Save changes  </button>   
         
          </tr>
      </Form>
          <br/>
                </div>
    
)
   }           
            else{
        return (
            <div className="grid100">
      <Form  model="forms.info" method="post" onSubmit={ (info) => this.handleSubmitSaveOrder(info) }>   
                 <tr>
                   <td>
                      <div>
                      <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                        <br/>

                        <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
                        <Control.text
                            className="bp3-input"
                            model=".firstName"
                            defaultValue={this.props.orderDetailData.firstName} 
                        />
                     <br/>
                        <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".lastName"
                            defaultValue={this.props.orderDetailData.lastName} 
                        />
                     <br/>

                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".companyName"
                            defaultValue={this.props.orderDetailData.companyName} 
                        />
                     <br/>

                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".paymentMethod"
                            defaultValue={this.props.orderDetailData.paymentMethod} 
                          />
                     <br/>

                          <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".shippingWay"
                            defaultValue={this.props.orderDetailData.shippingWay} 
                        />
                     <br/>
                       <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".email"
                            defaultValue={this.props.orderDetailData.email} 
                        />
                     <br/>

                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".phoneNumber"
                            defaultValue={this.props.orderDetailData.phoneNumber} 
                        />
                     <br/>
                            <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".street"
                            defaultValue={this.props.orderDetailData.street} 
                        />
                     <br/>

                    
                    <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".houseNumber"
                            defaultValue={this.props.orderDetailData.houseNumber} 
                        />
                     <br/>

                    <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".postcode"
                            defaultValue={this.props.orderDetailData.postcode} 
                        />
                     <br/>

                    <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".city"
                            defaultValue={this.props.orderDetailData.city} 
                        />
                     <br/>

                    <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".country"
                            defaultValue={this.props.orderDetailData.country} 
                        />
                     <br/>

 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPrice"
                            defaultValue={this.props.orderDetailData.netPrice} 
                            />
                     <br/>


 <label htmlFor="grossPrice" className="bp3-file-input"><b>Gross price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPrice"
                            defaultValue={this.props.orderDetailData.grossPrice} 
                        />
                     <br/>

 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPriceWD"
                            defaultValue={this.props.orderDetailData.netPriceWD} 
                        />
                     <br/>
                     

 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderDetailData.grossPriceWD} 
                        />
                     <br/>
                    </div>    
                   </td>
        
         </tr>
         <tr>
                     <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4", position: "absolute", right: 30, top: 690 }} > Save changes  </button>         
                        </tr>
        </Form>



      
          <br/>
                </div>
    )
            }
    }
    else {
        return null;
    }
}

}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state),
    orderSavedData: getSavedOrder(state),
    decrementQuantityData: getDecrementedQuantity(state),
    getArticlesData: getArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch, decrementQuantityFetch, deleteArticleFromOrderFetch, getArticlesFetch, updateNetPriceFetch, updateGrossPriceFetch})(EditOrder)

