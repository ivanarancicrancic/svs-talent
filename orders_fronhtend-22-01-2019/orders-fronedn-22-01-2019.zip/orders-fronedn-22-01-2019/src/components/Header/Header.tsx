import * as React from 'react';
import PostAuthHeader from './PostAuthHeader';
import './Header.css'

export default class Header extends React.Component {
    public render() {
        return <PostAuthHeader /> 
    }
}

