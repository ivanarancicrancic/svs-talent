drop table if exists DEPARTMENT;
create table DEPARTMENT (DEPT_ID integer not null, DEPT_NO varchar(20) not null, primary key (DEPT_ID));
alter table DEPARTMENT add constraint UK504cmb4vdtk4qhlyo0gunu2ew unique (DEPT_NO);
