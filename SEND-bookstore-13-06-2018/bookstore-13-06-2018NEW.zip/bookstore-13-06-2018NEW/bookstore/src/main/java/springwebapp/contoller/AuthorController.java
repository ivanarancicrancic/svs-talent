package springwebapp.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebappservice.service.AuthorService;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

/**
 * Created by jt on 5/18/17.
 */
@Controller
@Order(1)
public class AuthorController {
    private AuthorService authorService;

    @Autowired
    private BookService bookService;

    @Autowired
    TableAttributeService tableAttributeService;

    public AuthorController(AuthorService authorService, BookService bookService, TableAttributeService tableAttributeService) {
        this.authorService = authorService;
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
    }

    @RequestMapping("/authors")
    public String getAuthors(Model model){


        model.addAttribute("authors", authorService.getAllAuthors());

        return "authors";
    }


    @GetMapping
    @RequestMapping("/book/{bookId}/authors")
    public String listAuthors(@PathVariable String bookId, Model model){

        model.addAttribute("book", bookService.findById(Long.valueOf(bookId)));
        return "book/author/list";
    }


    @GetMapping
    @RequestMapping("/book/{bookId}/author/{authorId}/show")
    public String viewAuthor(@PathVariable String bookId, @PathVariable String authorId, Model model){

        model.addAttribute("author", authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId)));


        return "book/author/show";
    }

}
