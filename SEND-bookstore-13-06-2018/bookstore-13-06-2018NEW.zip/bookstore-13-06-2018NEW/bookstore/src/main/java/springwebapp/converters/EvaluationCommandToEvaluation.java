package springwebapp.converters;

import springwebapp.commands.EvalutationCommand;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Evaluation;

@Component
public class EvaluationCommandToEvaluation implements Converter<EvalutationCommand, Evaluation> {

    @Synchronized
    @Override
    public Evaluation convert(EvalutationCommand source){

        if(source == null){
            return null;
        }

        final Evaluation evaluation = new Evaluation();
        evaluation.setId(source.getId());
        evaluation.setEvaluation(source.getEvaluation());
        return evaluation;
    }



}
