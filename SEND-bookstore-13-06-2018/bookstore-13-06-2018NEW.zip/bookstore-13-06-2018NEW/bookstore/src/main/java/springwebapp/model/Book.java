package springwebapp.model;


import com.sun.org.apache.xerces.internal.impl.xpath.XPath;
import org.hibernate.engine.internal.Cascade;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Component
public class Book{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;

    private Byte[] image;

    @ManyToOne
    private Evaluation evaluation;

    @OneToMany(mappedBy = "book", cascade = CascadeType.ALL)
    private Set<Comment> comments = new HashSet<>();

    private String description;
    private String size;
    private String url;
    private String note;

    @ManyToOne
    private Publisher publisher;

    @Enumerated(value = EnumType.STRING)
    private Difficutly difficutly;

    @ManyToMany
    @JoinTable(name = "book_category", joinColumns = @JoinColumn(name = "book_id"), inverseJoinColumns = @JoinColumn(name = "category_id"))
    private List<Category> categories;

    private String stringCategories;

    @ManyToMany
    @JoinTable(name = "author_book", joinColumns = @JoinColumn(name = "book_id"),
            inverseJoinColumns = @JoinColumn(name = "author_id"))
    private Set<Author> authors = new HashSet<>();

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public List<Category> getCategories() {
        return categories;
    }

    public void setCategories(List<Category> categories) {
        this.categories = categories;
    }


    public String getStringCategories() {
        return stringCategories;
    }

    public void setStringCategories(String stringCategories) {
        this.stringCategories = stringCategories;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Byte[] getImage() {
        return image;
    }

    public void setImage(Byte[] image) {
        this.image = image;
    }

    public Difficutly getDifficutly() {
        return difficutly;
    }

    public void setDifficutly(Difficutly difficutly) {
        this.difficutly = difficutly;
    }

//    public Book() {
//    }
//
//    public Book(String title, String isbn, Evaluation evaluation, String description, Integer duration, String url, Publisher publisher) {
//        this.id = id;
//        this.title = title;
//        this.isbn = isbn;
//      //  this.notes = notes;
//        this.evaluation = evaluation;
//
//        this.description = description;
//        this.duration = duration;
//        this.url = url;
//        this.publisher = publisher;
//        this.difficutly = null;
//        this.image = null;
//    }
//
//
//    public Book(String title, String isbn, Evaluation evaluation, List<Comment> comments, String description, Integer duration, String url, Publisher publisher, Difficutly difficutly, List<Category> categories, Set<Author> authors) {
//        this.id = id;
//        this.title = title;
//        this.isbn = isbn;
//        this.image = null;
//    //    this.notes = notes;
//        this.evaluation = evaluation;
//        this.comments = comments;
//        this.description = description;
//        this.duration = duration;
//        this.url = url;
//        this.publisher = publisher;
//        this.difficutly = difficutly;
//        this.categories = categories;
//        this.authors = authors;
//    }

    public Evaluation getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(Evaluation evaluation) {
        this.evaluation = evaluation;
    }


    public Set<Comment> getComments() {
        return comments;
    }

    public void setComments(Set<Comment> comments) {

        this.comments = comments;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public Publisher getPublisher() {
        return publisher;
    }

    public void setPublisher(Publisher publisher) {
        this.publisher = publisher;
    }

    public Set<Author> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<Author> authors) {
        this.authors = authors;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Book book = (Book) o;

        return id != null ? id.equals(book.id) : book.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", publisher='" + publisher + '\'' +
                '}';
    }



}