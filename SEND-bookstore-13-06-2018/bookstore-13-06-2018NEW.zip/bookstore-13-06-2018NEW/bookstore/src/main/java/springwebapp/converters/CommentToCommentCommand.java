package springwebapp.converters;

import springwebapp.commands.CommentCommand;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Comment;

@Component
public class CommentToCommentCommand implements Converter<Comment, CommentCommand> {

    @Synchronized
    @Override
    public CommentCommand convert(Comment source){

        if(source == null){
            return null;
        }

        final CommentCommand comment = new CommentCommand();
        comment.setId(source.getId());
        comment.setComment(source.getComment());
        return comment;
    }

}
