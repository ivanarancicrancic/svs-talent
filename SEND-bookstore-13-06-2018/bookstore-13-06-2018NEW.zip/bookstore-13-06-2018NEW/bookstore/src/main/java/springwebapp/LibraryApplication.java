package springwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import springwebapp.model.TableAtrtributes;
import springwebapp.propertybean.DataSourceClass;
import springwebapp.propertybean.SpecialDataSourceClass;

@SpringBootApplication
@ComponentScan(basePackages = {"springwebappservice.service", "springwebapp"})

public class LibraryApplication {

    public static void main(String[] args){

      ApplicationContext ctx = SpringApplication.run(LibraryApplication.class, args);

        DataSourceClass dataSourceClass = (DataSourceClass) ctx.getBean(DataSourceClass.class);

        System.out.println(dataSourceClass.getUser());
        System.out.println(dataSourceClass.getPassword());
        System.out.println(dataSourceClass.getUrl());
        System.out.println(dataSourceClass.getMainUser());
        System.out.println(dataSourceClass.getMainPassword());
        System.out.println(dataSourceClass.getMainUrl());

        SpecialDataSourceClass specialDataSourceClass = (SpecialDataSourceClass) ctx.getBean(SpecialDataSourceClass.class);

        System.out.println(specialDataSourceClass.getSpecialUser());
        System.out.println(specialDataSourceClass.getSpecailPassword());
        System.out.println(specialDataSourceClass.getSpecialUrl());

    }


}