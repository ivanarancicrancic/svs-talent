package springwebappservice.service;


import springwebapp.commands.BookCommand;
import springwebapp.model.Book;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface BookService {

    public BookCommand createBook(BookCommand book);
    public List<BookCommand> getAllBooks();
    public String getBook(Long id);
    public BookCommand updateBook(BookCommand book);
    public void deleteBook(Long id);
    public BookCommand getAuthorsByBook(Long id);
    public BookCommand findById(Long l);

}
