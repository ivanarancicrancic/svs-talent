package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.model.response.TrackerModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.FileStorageService;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api")
public class TrackerController {

    @Autowired
    private AuthenticationFacade authenticationFacade;

    @Autowired
    private TrackerService trackerService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private FileStorageService fileStorageService;

    public TrackerController(AuthenticationFacade authenticationFacade, TrackerService trackerService, CampaignService campaignService, FileStorageService fileStorageService) {
        this.authenticationFacade = authenticationFacade;
        this.trackerService = trackerService;
        this.campaignService = campaignService;
        this.fileStorageService = fileStorageService;
    }



    @PostMapping("/campaign/{campaignId}/tracker")
    @ResponseStatus(HttpStatus.CREATED)
    public DeferredResult<TrackerModel> createTracker(@PathVariable long campaignId, @RequestParam("file") MultipartFile multipartFile, @RequestParam("filename") String filename) throws IOException {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        File convertedFile = fileStorageService.storeFile(multipartFile, filename);

        DeferredResult<TrackerModel> result = new DeferredResult<>();

        CompletableFuture<Tracker> newTracker = trackerService.createTrackerForCampaign(campaign, convertedFile);
        newTracker.thenApply(tracker ->
                result.setResult(new TrackerModel(tracker))
        );
        return result;
    }

    @PutMapping("/campaign/tracker/{trackerId}")
    @ResponseStatus(HttpStatus.OK)
    public TrackerModel updateTracker(@PathVariable long trackerId, @RequestParam("file") MultipartFile multipartFile, @RequestParam("filename") String filename) {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        // TODO: generate some filename
        File convertedFile = fileStorageService.storeFile(multipartFile, filename);

        Tracker editedTracker = trackerService.editTracker(tracker, convertedFile);
        return new TrackerModel(editedTracker);
    }

    @DeleteMapping("/campaign/tracker/{trackerId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteTracker(@PathVariable long trackerId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        trackerService.deleteTracker(tracker);
    }


}
