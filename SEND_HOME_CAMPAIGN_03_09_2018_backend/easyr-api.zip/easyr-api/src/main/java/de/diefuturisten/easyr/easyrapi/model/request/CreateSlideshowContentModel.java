package de.diefuturisten.easyr.easyrapi.model.request;

public class CreateSlideshowContentModel extends CreateContentModel{

//    private List<SlideshowImageModel> images = new ArrayList<>();

    private float positionX;

    private float positionY = 0.0f;

    private float positionZ = 0.0f;

    private float rotationX = 0.0f;

    private float rotationY = 0.0f;

    private float rotationZ = 0.0f;

    private float scaleX = 0.0f;

    private float scaleY = 0.0f;

    private float scaleZ = 0.0f;

    private boolean renderOnTrackingLost = false;

    private boolean extendedTracking = false;

    public CreateSlideshowContentModel(){}




}
