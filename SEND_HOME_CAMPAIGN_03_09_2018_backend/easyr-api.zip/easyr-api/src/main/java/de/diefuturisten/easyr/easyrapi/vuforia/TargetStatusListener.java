package de.diefuturisten.easyr.easyrapi.vuforia;

public interface TargetStatusListener {

	public void OnTargetStatusUpdate(TargetState targetState);
}
