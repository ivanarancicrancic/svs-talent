package de.diefuturisten.easyr.easyrapi.entity.user;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="userroles")
public class UserRole {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_userrole")
    private long id;

    @Column(name = "name", length = 45)
    private String name;

    @Column(name = "description", length = 245)
    private String description;

    @ManyToMany(fetch = javax.persistence.FetchType.EAGER)
    @JoinTable(
            name = "role_has_rights",
            joinColumns = { @JoinColumn(name = "fk_userrole") },
            inverseJoinColumns = { @JoinColumn(name = "fk_userright") }
    )
    Set<UserRight> rights = new HashSet<>();

    @ManyToMany(mappedBy = "roles", fetch = javax.persistence.FetchType.EAGER)
    private Set<User> users;

    public UserRole() {
    }

    public UserRole(String name) {
        this.name = name;
    }

    // setter & getter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonIgnore
    public Set<UserRight> getRights() {
        return rights;
    }

    public void setRights(Set<UserRight> rights) {
        this.rights = rights;
    }

    @JsonIgnore
    public Set<User> getUsers() {
        return users;
    }

    public void setUsers(Set<User> users) {
        this.users = users;
    }

    public void addRight(UserRight ur1) {
        this.rights.add(ur1);
    }
}
