package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;

public class CampaignOverviewModel {

    private long id;
    private String name;
    private String trackerUrl;
    private long numberOfViews;

    public CampaignOverviewModel() {
    }

    public CampaignOverviewModel(Campaign campaign) {
        this.id = campaign.getId();
        this.name = campaign.getName();

        this.trackerUrl = campaign.getTracker()
                .stream()
                .map(Tracker::getUrl)
                .findFirst().orElse(null);

        this.numberOfViews = 0; // TODO: real value
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTrackerUrl() {
        return trackerUrl;
    }

    public void setTrackerUrl(String trackerUrl) {
        this.trackerUrl = trackerUrl;
    }

    public long getNumberOfViews() {
        return numberOfViews;
    }

    public void setNumberOfViews(long numberOfViews) {
        this.numberOfViews = numberOfViews;
    }
}
