package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;

@Service
@Transactional
public class UnityContentService {
    // TODO: rewrite service


    @Autowired
    private ContentRepository contentRepository;

    public UnityContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public UnityContent create(Campaign campaign, @Valid CreateUnityContentModel model) {
        UnityContent content = new UnityContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setWeight(model.getWeight());
        content.setIosUrl(model.getIosUrl());
        content.setAndroidUrl(model.getAndroidUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        content.setExtendedTracking(model.isExtendedTracking());

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public UnityContent edit(UnityContent content, @Valid CreateUnityContentModel model) {
        content.setName(model.getName());
        content.setWeight(model.getWeight());
        content.setIosUrl(model.getIosUrl());
        content.setAndroidUrl(model.getAndroidUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        content.setExtendedTracking(model.isExtendedTracking());
        return contentRepository.save(content);
    }

}
