package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="content_slideshows")
public class SlideshowContent extends Content {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "slideshow")
    private List<SlideshowImage> images = new ArrayList<>();

    @Column(name="position_x", nullable = false)
    private float positionX = 0.0f;

    @Column(name="position_y", nullable = false)
    private float positionY = 0.0f;

    @Column(name="position_z", nullable = false)
    private float positionZ = 0.0f;

    @Column(name="rotation_x", nullable = false)
    private float rotationX = 0.0f;

    @Column(name="rotation_y", nullable = false)
    private float rotationY = 0.0f;

    @Column(name="rotation_z", nullable = false)
    private float rotationZ = 0.0f;

    @Column(name="scale_x", nullable = false)
    private float scaleX = 0.0f;

    @Column(name="scale_y", nullable = false)
    private float scaleY = 0.0f;

    @Column(name="scale_z", nullable = false)
    private float scaleZ = 0.0f;

    @Column(name="render_on_tracking_lost", nullable = false)
    private boolean renderOnTrackingLost = false;

    @Column(name="extended_tracking", nullable = false)
    private boolean extendedTracking = false;

    // getter & setter

    public List<SlideshowImage> getImages() {
        return images;
    }

    public void setImages(List<SlideshowImage> images) {
        this.images = images;
    }

    public float getPositionX() {
        return positionX;
    }

    public void setPositionX(float positionX) {
        this.positionX = positionX;
    }

    public float getPositionY() {
        return positionY;
    }

    public void setPositionY(float positionY) {
        this.positionY = positionY;
    }

    public float getPositionZ() {
        return positionZ;
    }

    public void setPositionZ(float positionZ) {
        this.positionZ = positionZ;
    }

    public float getRotationX() {
        return rotationX;
    }

    public void setRotationX(float rotationX) {
        this.rotationX = rotationX;
    }

    public float getRotationY() {
        return rotationY;
    }

    public void setRotationY(float rotationY) {
        this.rotationY = rotationY;
    }

    public float getRotationZ() {
        return rotationZ;
    }

    public void setRotationZ(float rotationZ) {
        this.rotationZ = rotationZ;
    }

    public float getScaleX() {
        return scaleX;
    }

    public void setScaleX(float scaleX) {
        this.scaleX = scaleX;
    }

    public float getScaleY() {
        return scaleY;
    }

    public void setScaleY(float scaleY) {
        this.scaleY = scaleY;
    }

    public float getScaleZ() {
        return scaleZ;
    }

    public void setScaleZ(float scaleZ) {
        this.scaleZ = scaleZ;
    }

    public boolean isRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }

    public boolean isExtendedTracking() {
        return extendedTracking;
    }

    public void setExtendedTracking(boolean extendedTracking) {
        this.extendedTracking = extendedTracking;
    }
}
