UploadS3Java
============

Exemplo Upload S3 Java
Neste projeto simples, queremos mostrar como fazer um upload de arquivo em Java usando o S3 como repositório em vez do file system local. Para facilitar a comparação, teremos um servlet que faz upload para o disco e outro que faz upload para o S3. A idéia é deixar o mais simples possível a implementação para que todos possam usá-la imediatamente.
