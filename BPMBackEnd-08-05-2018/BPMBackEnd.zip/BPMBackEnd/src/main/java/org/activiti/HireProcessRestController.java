package org.activiti;

import Models.*;
import com.google.gson.Gson;
import database.ProjectManager;
import org.activiti.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class HireProcessRestController {

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private ApplicantRepository applicantRepository;
    @CrossOrigin(origins = "http://localhost:4200")
    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value="/getloginstatus", method= RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces="application/json;charset=UTF-8")
    public String getLoginStatus(@RequestBody UserLogin ul) {
        System.out.println("init");
        //LoanRequest loanRequest1=new LoanRequest();
        String t_tems_str = null;
        LoginStatus  t_items = new LoginStatus();
        try
        {
            ProjectManager projectManager= new ProjectManager();
            t_items=projectManager.getLoginStatus(ul);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;

        } catch (Exception e)
        {
            System.out.println("error");
            e.printStackTrace();
        }
        return t_tems_str;
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getClientsType", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getClientsType() throws Exception {
        List<ClientType> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getClientsType();
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getFormsByUsername/userName={userName}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getFormsByUsername(@PathVariable("userName") String username) throws Exception {
        List<FormsByUsername> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetFormsByUsername(username);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getdocumentnamebyid/id={id}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getdocumentnamebyid(@PathVariable("id") Integer id) throws Exception {
        //List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();
        List<DocumentName> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getdocumentnamebyid(id);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getloanrequests/username={username}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getloanrequests(@PathVariable("username") String username) throws Exception {
        List<LoanRequests> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getloanrequests(username);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getloanrequestsdetailsbyid/requestid={requestid}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getloanrequestsdetailsbyid(@PathVariable("requestid") long requestID) throws Exception {
        List<LoanRequestsDetailsByID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getloanrequestsdetailsbyid(requestID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getactiveloans/status={status}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getactiveloans(@PathVariable("status") int status) throws Exception {
        List<ActiveLoans> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getactiveloans(status);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getattacheddocumentsforloanrequestid/requestid={requestid}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getattacheddocumentsforloanrequestid(@PathVariable("requestid") long requestID) throws Exception {
        List<AttachedDocumentsForLoanRequestID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getattacheddocumentsforloanrequestid(requestID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getcommentsforloanrequestid/requestid={requestid}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getcommentsforloanrequestid(@PathVariable("requestid") long requestID) throws Exception {
        List<CommentsForLoanRequestID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getcommentsforloanrequestid(requestID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetKreditniLini/type={p_type}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetKreditniLini(@PathVariable("p_type") Integer p_type) throws Exception {
        //List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();

        List<CreditLine> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetKreditniLini(p_type);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetUsersByUsername/username={p_username}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetUsersByUsername(@PathVariable("p_username") String p_username) throws Exception {
        List<UsersByUsername> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetUsersByUsername(p_username);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetAplicantDetailsByEmbg/embg={p_embg}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetAplicantDetailsByEmbg(@PathVariable("p_embg") String p_embg) throws Exception {
        //List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();

        List<AplicantDetails> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetAplicantDetailsByEmbg(p_embg);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetUsersByGrpoupID/groupID={p_groupID}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetUsersByGrpoupID(@PathVariable("p_groupID") Integer p_groupID) throws Exception {
        //List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();

        System.out.println(" p_groupID "+p_groupID);
        List<UserByGroupId> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetUsersByGrpoupID(p_groupID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/start-hire-process", method = RequestMethod.POST,
            produces="application/json;charset=UTF-8")
    public void startHireProcess(@RequestBody Map<String, String> data) {

        Applicant applicant = new Applicant(data.get("name"), data.get("email"), data.get("phoneNumber"));
        applicantRepository.save(applicant);

        Map<String, Object> vars = Collections.<String, Object>singletonMap("applicant", applicant);
        runtimeService.startProcessInstanceByKey("hireProcessWithJpa", vars);
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/Getloanrequestsbyparametar/p_name={p_name}&p_value={p_value}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String getloanrequestsbyparametar(@PathVariable("p_name") String p_name,@PathVariable("p_value") String p_value ) throws Exception {
        List<LoanRequestsByParametar> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getloanrequestsbyparametar(p_name, p_value);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetLoanTypeByLoanLineID/loanLineID={p_loanLineID}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetLoanTypeByLoanLineID(@PathVariable("p_loanLineID") Integer p_loanLineID) throws Exception {
        List<LoanType> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetLoanTypeByLoanLineID(p_loanLineID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }




    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetDocumentsForLoanTypeID/_loanTypeID={_loanTypeID}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetDocumentsForLoanTypeID(@PathVariable("_loanTypeID") Integer _loanTypeID) throws Exception {
        System.out.println("Entered GetDocumentsForLoanTypeID");
        System.out.println("_loanTypeID "+ _loanTypeID);
        List<DocumentsForLoanTypeID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetDocumentsForLoanTypeID(_loanTypeID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetWarningsByLoanID/loanID={loanID}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetWarningsByLoanID(@PathVariable("loanID") Integer loanID) throws Exception {
        System.out.println("Entered GetWarningsByLoanID");
        System.out.println("loanID: "+ loanID);
        List<WarningsByLoanID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetWarningsByLoanID(loanID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetWarningsDetailsByWarrningID/warrningID={warrningID}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetWarningsDetailsByWarrningID(@PathVariable("warrningID") Integer warrningID) throws Exception {
        System.out.println("Entered GetWarningsDetailsByWarrningID");
        System.out.println("warrningID: "+ warrningID);
        List<WarningsDetailsByWarrningID> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetWarningsDetailsByWarrningID(warrningID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetLoanRequestsByParametar/parametarName={parametarName}&parametarValue={parametarValue}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetLoanRequestsByParametar(@PathVariable("parametarName") String parametarName, @PathVariable("parametarValue") String parametarValue) throws Exception {
        System.out.println("Entered GetWarningsDetailsByWarrningID");
        System.out.println("parametarName: "+ parametarName);
        System.out.println("parametarValue: "+ parametarValue);
        List<LoanRequestsByParametar> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetLoanRequestsByParametar(parametarName,parametarValue);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }





    @RequestMapping(value="/CreateLoanRequest", method= RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces="application/json;charset=UTF-8")
    public void CreateLoanRequest(@RequestBody LoanRequest loanRequest) {
        System.out.println("init");
        //LoanRequest loanRequest1=new LoanRequest();
        String t_tems_str = null;
        try
        {
            ProjectManager projectManager= new ProjectManager();
            System.out.println("init - before createLoanRequest");
            projectManager.CreateLoanRequest(loanRequest);
            System.out.println("after createLoanRequest");
            //System.out.println("flag: "+flag);
//            Gson gson = new Gson();
//            System.out.println(gson.toJson(loanRequest1));
//            t_tems_str = gson.toJson(loanRequest1);

        } catch (Exception e)
        {
            System.out.println("error");
            e.printStackTrace();
        }

    }

    @RequestMapping(value="/AddNewWarningByLoanID", method= RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public void AddNewWarningByLoanID(@RequestBody LoanWarning loanWarning)  throws Exception {
        System.out.println("init");
       LoanWarning loanWarning1=new LoanWarning();
        String t_tems_str = null;
        try
        {
            ProjectManager projectManager= new ProjectManager();
            System.out.println("init - before AddNewWarningByLoanID");
            projectManager.AddNewWarningByLoanID(loanWarning);
            System.out.println("after AddNewWarningByLoanID");
            Gson gson = new Gson();
           // System.out.println(gson.toJson(loanWarning));
            t_tems_str = gson.toJson(loanWarning1);

        } catch (Exception e)
        {
            System.out.println("error");
            e.printStackTrace();
            throw e;
        }

    }

    @RequestMapping(value="/UpdateLoanRequestByID/loanTypeID={loanTypeID}", method= RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces="application/json;charset=UTF-8")
    public String UpdateLoanRequestByID(@PathVariable("loanTypeID") int loanTypeID, @RequestBody LoanRequest loanRequest) throws Exception {
        System.out.println("init");
        LoanRequest loanRequest1=new LoanRequest();
        String t_tems_str = null;
        try
        {
            ProjectManager projectManager= new ProjectManager();
            System.out.println("init - before UpdateLoanRequestByID/loanTypeID");
            loanRequest1 = projectManager.UpdateLoanRequestByID(loanTypeID, loanRequest);
            System.out.println("after UpdateLoanRequestByID/loanTypeID");
            Gson gson = new Gson();
            // System.out.println(gson.toJson(loanWarning));
            t_tems_str = gson.toJson(loanRequest1);
            return  t_tems_str;
        } catch (Exception e)
        {
            System.out.println("error");
            e.printStackTrace();
            throw e;
        }

    }



    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetStatusByForm/formname={p_formname}", method = RequestMethod.GET,
            produces="application/json;charset=UTF-8")
    public String GetStatusByForm(@PathVariable("p_formname") String p_formname) throws Exception {
        System.out.println("Entered GetKreditenOdborGroups");
        List<Statusi> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetStatusByForm(p_formname);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetKreditenOdborGroups", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public String GetKreditenOdborGroups() throws Exception {
        System.out.println("Entered GetKreditenOdborGroups");
        List<KreditenOdborGroups> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetKreditenOdborGroups();
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }



}