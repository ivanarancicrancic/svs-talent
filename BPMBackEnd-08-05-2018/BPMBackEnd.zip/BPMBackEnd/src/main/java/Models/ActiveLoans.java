package Models;

public class ActiveLoans {

   private int status;
   private int brdosie;
    private int brrati;
    private int brplatenirati;
    private int brzadocnetirati;
    private int neplateniznost;
    private String datumposlednoplakanje;
    private String aplicantname;
    private String valuta;
    private int rokOtplata;
    private int grejsPeriod;


    public String getValuta() {
        return valuta;
    }

    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    public int getRokOtplata() {
        return rokOtplata;
    }

    public void setRokOtplata(int rokOtplata) {
        this.rokOtplata = rokOtplata;
    }

    public int getGrejsPeriod() {
        return grejsPeriod;
    }

    public void setGrejsPeriod(int grejsPeriod) {
        this.grejsPeriod = grejsPeriod;
    }

    public ActiveLoans(int status, int brdosie, int brrati, int brplatenirati, int brzadocnetirati, int neplateniznost, String datumposlednoplakanje, String aplicantname, String valuta, int rok, int grejsPeriod) {
        this.status = status;
        this.brdosie = brdosie;
        this.brrati = brrati;
        this.brplatenirati = brplatenirati;
        this.brzadocnetirati = brzadocnetirati;
        this.neplateniznost = neplateniznost;
        this.datumposlednoplakanje = datumposlednoplakanje;
        this.aplicantname = aplicantname;
        this.valuta = valuta;
        this.rokOtplata = rok;
        this.grejsPeriod = grejsPeriod;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getBrdosie() {
        return brdosie;
    }

    public void setBrdosie(int brdosie) {
        this.brdosie = brdosie;
    }

    public int getBrrati() {
        return brrati;
    }

    public void setBrrati(int brrati) {
        this.brrati = brrati;
    }

    public int getBrplatenirati() {
        return brplatenirati;
    }

    public void setBrplatenirati(int brplatenirati) {
        this.brplatenirati = brplatenirati;
    }

    public int getBrzadocnetirati() {
        return brzadocnetirati;
    }

    public void setBrzadocnetirati(int brzadocnetirati) {
        this.brzadocnetirati = brzadocnetirati;
    }

    public int getNeplateniznost() {
        return neplateniznost;
    }

    public void setNeplateniznost(int neplateniznost) {
        this.neplateniznost = neplateniznost;
    }

    public String getDatumposlednoplakanje() {
        return datumposlednoplakanje;
    }

    public void setDatumposlednoplakanje(String datumposlednoplakanje) {
        this.datumposlednoplakanje = datumposlednoplakanje;
    }

    public String getAplicantname() {
        return aplicantname;
    }

    public void setAplicantname(String aplicantname) {
        this.aplicantname = aplicantname;
    }
}
