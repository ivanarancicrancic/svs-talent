package Models;

public class AttachedDocumentsForLoanRequestID {

    private String tipdoc;
    private String doc_zabeleshka;
    private String prikaceno_od;
    private String datum_prikacuvanje;
    private String file_path;

    public AttachedDocumentsForLoanRequestID(String tipdoc, String doc_zabeleshka, String prikaceno_od, String datum_prikacuvanje, String file_path) {
        this.tipdoc = tipdoc;
        this.doc_zabeleshka = doc_zabeleshka;
        this.prikaceno_od = prikaceno_od;
        this.datum_prikacuvanje = datum_prikacuvanje;
        this.file_path = file_path;
    }

    public String getTipdoc() {
        return tipdoc;
    }

    public void setTipdoc(String tipdoc) {
        this.tipdoc = tipdoc;
    }

    public String getDoc_zabeleshka() {
        return doc_zabeleshka;
    }

    public void setDoc_zabeleshka(String doc_zabeleshka) {
        this.doc_zabeleshka = doc_zabeleshka;
    }

    public String getPrikaceno_od() {
        return prikaceno_od;
    }

    public void setPrikaceno_od(String prikaceno_od) {
        this.prikaceno_od = prikaceno_od;
    }

    public String getDatum_prikacuvanje() {
        return datum_prikacuvanje;
    }

    public void setDatum_prikacuvanje(String datum_prikacuvanje) {
        this.datum_prikacuvanje = datum_prikacuvanje;
    }

    public String getFile_path() {
        return file_path;
    }

    public void setFile_path(String file_path) {
        this.file_path = file_path;
    }
}
