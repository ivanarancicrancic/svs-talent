package Models;

public class KreditenOdborGroups {

    public KreditenOdborGroups(int groupID, String groupName) {
        this.groupID = groupID;
        this.groupName = groupName;
    }

    int groupID;
    String groupName;

    public int getGroupID() {
        return groupID;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupID(int groupID) {
        this.groupID = groupID;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }


}
