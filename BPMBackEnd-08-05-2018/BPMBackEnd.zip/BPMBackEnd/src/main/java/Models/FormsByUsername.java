package Models;

public class FormsByUsername {
    public String getImeForma() {
        return imeForma;
    }

    public void setImeForma(String imeForma) {
        this.imeForma = imeForma;
    }

    public FormsByUsername(String imeForma) {
        this.imeForma = imeForma;
    }

    public FormsByUsername() {
    }

    private  String imeForma;
}
