package Models;

public class AplicantDetails {
    private String firstName;
    private String lastName;
    private String partija;
    private String address;
    private String bracnasostojba;
    private Integer brojdeca;
    private String dokumentbroj;
    private String godinaziveenjenaadresa;
    private String kontaktadresa;
    private String telefon;
    private String mobtelefon;
    private String zivealiste;
    private String pol;

    public AplicantDetails() {
    }

    public AplicantDetails(String firstName, String lastName, String partija, String address, String bracnasostojba, Integer brojdeca, String dokumentbroj, String godinaziveenjenaadresa, String kontaktadresa, String telefon, String mobtelefon, String zivealiste, String pol) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.partija = partija;
        this.address = address;
        this.bracnasostojba = bracnasostojba;
        this.brojdeca = brojdeca;
        this.dokumentbroj = dokumentbroj;
        this.godinaziveenjenaadresa = godinaziveenjenaadresa;
        this.kontaktadresa = kontaktadresa;
        this.telefon = telefon;
        this.mobtelefon = mobtelefon;
        this.zivealiste = zivealiste;
        this.pol = pol;
    }

    public String getPol() {
        return pol;
    }

    public void setPol(String pol) {
        this.pol = pol;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPartija() {
        return partija;
    }

    public void setPartija(String partija) {
        this.partija = partija;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBracnasostojba() {
        return bracnasostojba;
    }

    public void setBracnasostojba(String bracnasostojba) {
        this.bracnasostojba = bracnasostojba;
    }

    public Integer getBrojdeca() {
        return brojdeca;
    }

    public void setBrojdeca(Integer brojdeca) {
        this.brojdeca = brojdeca;
    }

    public String getDokumentbroj() {
        return dokumentbroj;
    }

    public void setDokumentbroj(String dokumentbroj) {
        this.dokumentbroj = dokumentbroj;
    }

    public String getGodinaziveenjenaadresa() {
        return godinaziveenjenaadresa;
    }

    public void setGodinaziveenjenaadresa(String godinaziveenjenaadresa) {
        this.godinaziveenjenaadresa = godinaziveenjenaadresa;
    }

    public String getKontaktadresa() {
        return kontaktadresa;
    }

    public void setKontaktadresa(String kontaktadresa) {
        this.kontaktadresa = kontaktadresa;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getMobtelefon() {
        return mobtelefon;
    }

    public void setMobtelefon(String mobtelefon) {
        this.mobtelefon = mobtelefon;
    }

    public String getZivealiste() {
        return zivealiste;
    }

    public void setZivealiste(String zivealiste) {
        this.zivealiste = zivealiste;
    }
}
