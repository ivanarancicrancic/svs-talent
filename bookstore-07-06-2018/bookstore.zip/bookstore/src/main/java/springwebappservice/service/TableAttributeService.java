package springwebappservice.service;

import org.springframework.stereotype.Component;
import springwebapp.model.TableAtrtributes;

@Component
public interface TableAttributeService {

    public TableAtrtributes sayGreeting();

}
