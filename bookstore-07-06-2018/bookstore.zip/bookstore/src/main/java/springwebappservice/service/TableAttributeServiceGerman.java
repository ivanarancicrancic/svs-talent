package springwebappservice.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.model.TableAtrtributes;
import springwebapp.repository.TableAttributeRepository;

@Service
@Component
@Profile({"default", "german"})
public class TableAttributeServiceGerman implements TableAttributeService {

    private TableAttributeRepository greetingRepository;

    public TableAttributeServiceGerman(TableAttributeRepository greetingRepository) {
        this.greetingRepository = greetingRepository;
    }

    @Override
    public TableAtrtributes sayGreeting() {
        return greetingRepository.getGermanTableAttributes();
    }

}
