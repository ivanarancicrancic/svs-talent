package springwebappservice.service;

import springwebapp.model.Author;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.repository.AuthorRepository;

import java.util.ArrayList;
import java.util.List;


public class AuthorServiceImpl implements AuthorService {
    @Autowired
    AuthorRepository repository;

    public AuthorServiceImpl(AuthorRepository repository) {
        this.repository = repository;
    }

    @Override
    public Author creatAuthor(Author author){ return repository.save(author);}


    @Override
    public List<Author> getAllAuthors(){
        System.out.println("Entered ServiceImpl getAllAuthors..");
        Iterable<Author> iterable = repository.findAll();

        List<Author> list = new ArrayList<Author>();
        if(iterable != null) {
            for(Author e: iterable) {
                list.add(e);
            }
        }
        return list;
    }



    @Override
    public String getAuthor(Long id){
        String status = "getting author";
    System.out.println(status);
    return status; }

    @Override
    public String updateAuthor(Long id, Author libraryuser){
        String status = "Updating author";
        System.out.println(status);
        return status;

    }

    @Override
    public String deleteAuthor(Long id) {
        String status = "Deleting author";
        System.out.println(status);
        return status;
    }

}
