import App from './App'

export default App;