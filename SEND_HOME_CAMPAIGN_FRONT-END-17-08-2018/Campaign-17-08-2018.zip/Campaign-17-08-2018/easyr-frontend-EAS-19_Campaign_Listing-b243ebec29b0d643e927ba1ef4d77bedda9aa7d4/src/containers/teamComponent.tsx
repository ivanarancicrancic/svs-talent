import * as React from 'react'
import { campaignData, ICampaign} from '../models/teamModel'

interface ITeamProps {
    name: string
}
interface ITeamState {
    campaigns: ICampaign[]
}
// const teamMemberDisplay = (campaign: Campaign, index: number) => {
//     return (
//         <div key={index}>
//             <div>
//                 <div>
//                     <div>
//                         <div>{campaign.id}</div>
//                     </div>
//                 </div>
//             </div>
        
//         </div>
//     )
// }

class TeamComponent extends React.Component<ITeamProps, ITeamState> {
    constructor(props: ITeamProps) {
        super(props)
       // this.props = props
    }

   public render() {

        return (
            <div>
                {
                    campaignData.campaigns.map((campaign: ICampaign) =>
                    <div key={campaign.id}>
                      {campaign.id}<br/>
                    </div>
                  )
                  }
            </div>
        )
    }
   public componentDidMount() {
        this.setState({
            campaigns: campaignData.campaigns
        })
    }
}

export default TeamComponent
