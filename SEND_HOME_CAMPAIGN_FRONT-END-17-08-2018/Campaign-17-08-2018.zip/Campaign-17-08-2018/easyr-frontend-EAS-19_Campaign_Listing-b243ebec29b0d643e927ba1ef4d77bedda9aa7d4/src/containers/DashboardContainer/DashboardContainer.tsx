import * as React from 'react';
// import { Translate } from 'react-redux-i18n';
// import { IRootState } from '../../redux';
// import { connect } from 'react-redux';

// import { getCampaignsFetch } from '../../redux/auth/actions';
// import { RouteComponentProps } from 'react-router';
// import { IAuthState } from '../../redux/auth/reducer';
// import { PATH_ROOT } from '../../router/paths';

// import {getCampaigns} from '../../redux/auth/actions'

import { campaignData, ICampaign} from '../../models/teamModel'
// import ReactS3Uploader from 'react-s3-uploader'


interface ITeamProps {
    id: string
}
interface ITeamState {
    campaigns: ICampaign[]
}
// const teamMemberDisplay = (campaign: Campaign, index: number) => {
//     const teamMemberContainerCSS = style.create({
//         padding: '10px',
//         fontSize: '20px',
//         textAlign: 'left',
//     })
//     const imagesContainer = () => {
//         return style.create({
//             textAlign: 'center'
//         })
//     }

//     const teamMemberProfileImage = style.create({
//         backgroundImage: 'url(${teamMember.imageURL})',
//         height: '160px',
//         width: '150px',
//         borderRadius: '50px',
//         position: 'relative' as positionTypes,
//         zIndex: 16
//     })

//     return (
//         <div key={index}>
//             <div>
//                 <div>
//                     <div>
//                         <div>{campaign.id}</div>
//                     </div>
//                 </div>
//             </div>
        
//         </div>
//     )
// }


// interface IPropsDispatchMap {
//     getCampaignsFetch: typeof getCampaignsFetch;
// }

// interface IPropsStateMap {
//     auth: IAuthState,  
// }

// interface ICampaign {
//     id: string;
//   }
    
//   interface IStateDashboard {
//     camaigns: ICampaign[];
//     isLoading: boolean;
//     token: string;
//   }


// type IProps = IPropsStateMap & IPropsDispatchMap & RouteComponentProps<{}>

 // class DashboardContainer extends React.Component<IProps, IStateDashboard> {
    class DashboardContainer extends React.Component<ITeamProps, ITeamState> {
        constructor(props: ITeamProps) {
            super(props)
            this.props = props
        }
    
       public render() {
    
            return (
                <div>
                    {
                         campaignData.campaigns.map((campaign: ICampaign) =>
                                  <div key={campaign.id}>
                                    {campaign.id}<br/>
                                  </div>
                                )
                     }
                </div>
            )
        }
     public componentDidMount() {
            this.setState({
                 campaigns: campaignData.campaigns
               // probe: campaignData.returnStr
            })
        }
    }
    
    export default DashboardContainer
    
//     constructor(props: any) {
//         super(props);
//         this.state = {
//             token: "",
//             camaigns: [],
//             isLoading: false
//         }
//     }

//     public componentWillMount() {
//         console.log(this.props);
//     }

//     public componentDidMount () {
//         fetch('http://localhost:8080/api/testCampaigns', {
//             method: 'GET',
//             headers: {"Content-Type": "application/json"}
//         })
//         .then(response => response.json())
//         .then(response => {
//             console.log(response);
//             this.setState({ camaigns: response, token: "", isLoading: false})

//         })
//         .catch(err => {
//             console.log(err);
//         });
//     }


//     public render() {

//         const { camaigns} = this.state;

//         return (
//             <div>
//             <Translate value="test" /><br />
//             Token: <input type="text" value={this.state.token} onChange={ (e) => this.setState({token: e.target.value}) } />
//             <ReactS3Uploader
//                 signingUrl="/s3/sign/"
//                 signingUrlMethod="POST"
//                 accept="image/*"
//                 s3path="/"
//                 // preprocess={ () => {console.log("preprocess")} }
//                 // onSignedUrl={ () => {console.log("onSignedUrl")} }
//                 // onProgress={ () => {console.log("onProgress")} }
//                 // onError={ () => {console.log("onError")} }
//                 // onFinish={ () => {console.log("onFinish")} }
//                 signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.state.token }}
//                 // signingUrlQueryParams={{ additional: query-params }}
//                 signingUrlWithCredentials={false}      // in case when need to pass authentication credentials via CORS
//                 uploadRequestHeaders={{}}  // this is the default
//                 // contentDisposition="auto"
//                 // scrubFilename={(filename: string) => filename.replace(/[^\w\d_\-.]+/ig, '')}
//                 server="http://127.0.0.1:8080"
//                 // inputRef={cmp => this.uploadInput = cmp}
//                 autoUpload={true}
//                 />
//                  <h2>Campaign List</h2>
//         {camaigns.map((campaign: ICampaign) =>
//           <div key={campaign.id}>
//             {campaign.id}<br/>
//           </div>
//         )}
//             </div>
//         )
//     }

// }



// const mapStateToProps = (state: IRootState) => ({
//     auth: state.auth
// });

// export default connect(mapStateToProps, {})(DashboardContainer)
