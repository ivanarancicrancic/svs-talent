import * as React from 'react';
import {Link, NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD, PATH_START, PATH_CREATE_CATEGORY, PATH_INQUIRY} from "../../router/paths";

import './Header';
import { userSelfInfoFetch } from '../../redux/user-self-info/actions';
import { getUserSelfInfo } from '../../redux/user-self-info/selectors';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { IUserResponseModel } from '../../redux/user-self-info/types';
import {  Menu, MenuItem, Popover, Position } from "@blueprintjs/core";
import { loginLogout } from '../../redux/auth/actions';
import logoImg from '../../assets/images/logo.png';
import { categoryCreateFetch } from '../../redux/category/actions';

import { history } from '../../router';
import { IJWToken } from '../../redux/auth/types';

import HamburgerMenu from './HamburgerMenu';

interface IPropsDispatchMap {
    userSelfInfoFetch: typeof userSelfInfoFetch;
    categoryCreateFetch: typeof categoryCreateFetch;
    loginLogout: typeof loginLogout;
}

interface IPropsStateMap {
    userInfo: IUserResponseModel | null;
    categoryCreating: boolean;
    lastCreatedId: number | null;
    token: IJWToken | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class PostAuthHeader extends React.Component<IProps> {

    public componentWillMount() {
        if(this.props.token != null) {
            this.props.userSelfInfoFetch();
        }
    }

    public renderUser() {

        if(this.props.userInfo == null) {
            return;
        }

        return <span className="userInfo"> 
                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">{this.props.userInfo.name} 
                    <i  className="fontello icon-user" />
                </NavLink></span>;
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const categoryCreated = this.props.categoryCreating === true && nextProps.categoryCreating === false;
        if(categoryCreated) {
            history.push(`/category/${nextProps.lastCreatedId}`);
        }
    }

    public render() {
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_ROOT} className="bp3-navbar-heading"> <img src={logoImg} /> </Link>
                            </span>
                            <div className="headerBox">
                                <Link to={PATH_DASHBOARD} className="bp3-navbar-heading"> Home</Link>
                                <Link to={PATH_START} className="bp3-navbar-heading">Category</Link>
                                
                                <Link to={PATH_INQUIRY} className="bp3-navbar-heading">Inquiry</Link>
                                <div className="settings bp3-navbar-heading"> 
                                <Link to={PATH_CREATE_CATEGORY} className="bp3-navbar-heading">SEARCH PRODUCT</Link>
                                    <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span>
                                    {this.props.token && <Popover content={
                                        <Menu>
                                            <MenuItem text="Logout" className="bp3-icon-standard bp3-icon-log-out" onClick={this.onLogout} />
                                        </Menu>} 
                                        position={Position.BOTTOM}>
                                        <span className="bp3-icon-standard bp3-icon-cog" />
                                    </Popover>}
                                </div>                       
                                {this.props.token && this.renderUser()}
                            </div>
                                <div className="hamburgerMenu">
                                    <HamburgerMenu />
                                </div>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

    private onLogout = () => {
        this.props.loginLogout();
    }
}

const mapStateToProps = (state: IRootState) => ({
    userInfo: getUserSelfInfo(state),
    categoryCreating: state.category.createLoading,
    lastCreatedId: state.category.lastCreatedId,
    token: state.auth.token
});

export default connect(mapStateToProps, {userSelfInfoFetch, categoryCreateFetch, loginLogout, pure: false})(PostAuthHeader)