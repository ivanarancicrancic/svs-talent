export const CATEGORY_DETAIL_FETCH = '@@user/category/detail/FETCH';
export const CATEGORY_DETAIL_SUCCESS = '@@user/category/detail/SUCCESS';
export const CATEGORY_DETAIL_FAIL = '@@user/category/detail/FAIL';

export const CATEGORY_CREATE_FETCH = '@@category/create/FETCH';
export const CATEGORY_CREATE_SUCCESS = '@@category/create/SUCCESS';
export const CATEGORY_CREATE_FAIL = '@@category/create/FAIL';

export const CATEGORY_SAVE_FETCH = '@@category/save/FETCH';
export const CATEGORY_SAVE_SUCCESS = '@@category/save/SUCCESS';
export const CATEGORY_SAVE_FAIL = '@@category/save/FAIL';

export const CATEGORY_EDIT_FETCH = '@@category/edit/FETCH';
export const CATEGORY_EDIT_SUCCESS = '@@category/edit/SUCCESS';
export const CATEGORY_EDIT_FAIL = '@@category/edit/FAIL';

export const IMAGE_UPLOAD_FETCH = '@@category/product_image/upload/FETCH';
export const IMAGE_UPLOAD_SUCCESS = '@@category/product_image/upload/SUCCESS';
export const IMAGE_UPLOAD_FAIL = '@@category/product_image/upload/FAIL';

export const IMAGE_DELETE_FETCH = '@@category/product_image/delete/FETCH';
export const IMAGE_DELETE_SUCCESS = '@@category/product_image/delete/SUCCESS';
export const IMAGE_DELETE_FAIL = '@@category/product_image/delete/FAIL';

export const PRODUCT_DELETE_FETCH = '@@category/product/delete/FETCH';
export const PRODUCT_DELETE_SUCCESS = '@@category/product/delete/SUCCESS';
export const PRODUCT_DELETE_FAIL = '@@category/product/delete/FAIL';

export const PRODUCT_CREATE_FETCH = '@@category/product/create/FETCH';
export const PRODUCT_CREATE_SUCCESS = '@@category/product/create/SUCCESS';
export const PRODUCT_CREATE_FAIL = '@@category/product/create/FAIL';

export const PRODUCT_EDIT_FETCH = '@@category/product/edit/FETCH';
export const PRODUCT_EDIT_SUCCESS = '@@category/product/edit/SUCCESS';
export const PRODUCT_EDIT_FAIL = '@@category/product/edit/FAIL';

export const PRODUCT_RENAME_FETCH = '@@category/product/rename/FETCH';
export const PRODUCT_RENAME_SUCCESS = '@@category/product/rename/SUCCESS';
export const PRODUCT_RENAME_FAIL = '@@category/product/rename/FAIL';

// IMAGE
export interface IImageResponseModel {
    id: number;
    url: string;
}

// PRODUCT
type ContentType =  'KITCHEN';

export interface IProduct1ResponseModel {
    id: number;
    type: ContentType;
    name: string;
    weight: number;
}

// PRODUCT TYPES
export type ProductSubtype = 'KITCHEN' | 'HOUSE';

interface IProductFields {
    subType: ProductSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IProductResponseModel extends IProduct1ResponseModel, IProductFields {}

export interface IProductRequestModel extends IProductFields {
    id?: number;
    name: string;
}


// CATEGORY
export interface ICategoryDetailResponseModel {
    id: number;
    name: string;
    description: string;
    image: IImageResponseModel[];
    contents: IProductResponseModel[]
    temporary: boolean;
    activePackageId: number | null
};