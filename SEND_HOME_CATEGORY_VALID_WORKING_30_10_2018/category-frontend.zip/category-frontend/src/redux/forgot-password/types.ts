export const FORGOT_PASSWORD_FETCH = '@@forgot/password/FETCH';
export const FORGOT_PASSWORD_SUCCESS = '@@forgot/password/SUCCESS';
export const FORGOT_PASSWORD_FAIL = '@@forgot/password/FAIL';

export const RESET_PASSWORD_FETCH = '@@reset/password/FETCH';
export const RESET_PASSWORD_SUCCESS = '@@reset/password/SUCCESS';
export const RESET_PASSWORD_FAIL = '@@reset/password/FAIL';