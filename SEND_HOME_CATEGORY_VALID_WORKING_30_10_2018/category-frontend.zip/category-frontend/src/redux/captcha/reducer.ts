import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { ICaptchaResponseModel } from './types';

export type CaptchaActions = ActionType<typeof actions>;

export interface ICaptchaState {
    readonly data: ICaptchaResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: ICaptchaState = {
    data: null,
    loading: false,
    error: null
};
  
export function captchaReducer(state: ICaptchaState = INITIAL_STATE, action: CaptchaActions): ICaptchaState  {
    switch (action.type) {
        case getType(actions.captchaFetch):
            return {...state, loading: true, error: null};
        case getType(actions.captchaSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.captchaFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }
}