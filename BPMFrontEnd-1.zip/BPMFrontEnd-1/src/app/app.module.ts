import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MyDateRangePickerModule } from 'mydaterangepicker';
import { MyDatePickerModule } from 'mydatepicker';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './/app-routing.module';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { MainComponent } from './components/main/main.component';
import { LoginComponent } from './components/login/login.component';
import { NovoBaranjeComponent } from './components/novo-baranje/novo-baranje.component';
import { MonitoringComponent } from './components/monitoring/monitoring.component';
import { PregledNaBaranjaComponent } from './components/pregled-na-baranja/pregled-na-baranja.component';
import { AdministracijaComponent } from './components/administracija/administracija.component';
import { LoginService } from './services/login.service';
import { NovoBaranjeService } from './services/novo-baranje.service';
import { PregledNaBaranjaService } from './services/pregled-na-baranja.service';
import { MonitoringService } from './services/monitoring.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    MainComponent,
    LoginComponent,
    NovoBaranjeComponent,
    MonitoringComponent,
    PregledNaBaranjaComponent,
    AdministracijaComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    MyDatePickerModule, 
    MyDateRangePickerModule,
    HttpClientModule
  ],
  providers: [ LoginService, NovoBaranjeService, PregledNaBaranjaService, MonitoringService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
