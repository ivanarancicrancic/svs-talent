import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { NovoBaranjeService } from '../../services/novo-baranje.service';
declare var $;
@Component({
  selector: 'app-monitoring',
  templateUrl: './monitoring.component.html',
  styleUrls: ['./monitoring.component.css']
})
export class MonitoringComponent implements OnInit {

  datePicker: any;
  datePicker2: any;
  datePicker3: any;
  username: string = sessionStorage.getItem('username');
  name: string;
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };
  
  constructor(private novoBaranje: NovoBaranjeService) { }

  ngOnInit() {
    this.setDate();
    this.getUsersByUsername();
  }

  setDate(): void{
    let date = new Date();
    this.datePicker = {
      beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: 1},
      endDate:   {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}
    };
    this.datePicker2 = {date: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
    this.datePicker3 = {date: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
     
  }

  getUsersByUsername(){
    this.novoBaranje.getUsersByUsername(this.username)
    .subscribe(data => {
      this.name = data[0].firstName + " " + data[0].lastName;
    });
  }

  show(){
    $('#modal-default').modal('show');
  }

  showDetails(){
    $('#modal-default2').modal('show');
  }


}
