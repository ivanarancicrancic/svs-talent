import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PregledNaBaranjaComponent } from './pregled-na-baranja.component';

describe('PregledNaBaranjaComponent', () => {
  let component: PregledNaBaranjaComponent;
  let fixture: ComponentFixture<PregledNaBaranjaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PregledNaBaranjaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PregledNaBaranjaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
