import { Component, OnInit } from '@angular/core';
import { IMyDrpOptions, IMyDateRangeModel } from 'mydaterangepicker';
import { PregledNaBaranjaService } from '../../services/pregled-na-baranja.service';
declare var $;
@Component({
  selector: 'app-pregled-na-baranja',
  templateUrl: './pregled-na-baranja.component.html',
  styleUrls: ['./pregled-na-baranja.component.css']
})
export class PregledNaBaranjaComponent implements OnInit {
  
  username: string = sessionStorage.getItem('username');
  status: any;
  dosie: any;
  embg: any;
  datePicker: any;
  datePicker1: any;
  tableData: any;
  tableData1: any;
  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };


  constructor(private pregledNaBaranja: PregledNaBaranjaService) { }

  ngOnInit() {
    this.setDate();
    this.getLoanR();
	this.status="";
	this.embg="";
	this.dosie="";
	
  }

  setDate(): void {
    let date = new Date();
    this.datePicker = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
    this.datePicker1 = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
	
  }

  getLoanR(): void {
    this.pregledNaBaranja.getLoanRequest(this.username)
      .subscribe(data => {
        console.log(data);
        this.tableData = data;
        this.tableData1 = data;
        if (data.grejs_period == false) {
          this.tableData.grejs_period = "Нема";
        }
      });
  }

    getLoan(): void{
   console.log("Function called");
   console.log(this.embg);
   console.log(this.datePicker.beginDate.year);
   console.log(this.dosie);
   console.log(this.status);
   var _arr = new Array();
   console.log(this.datePicker.beginDate);
   var d1 = "";
   if(this.datePicker.beginDate.day<10)
   {
    d1 = "0" + this.datePicker.beginDate.day + "."; 
   }
   else 
   {
   d1= this.datePicker.beginDate.day + ".";
   }
   if(this.datePicker.beginDate.month<10)
   { 
   d1= d1 + "0" + this.datePicker.beginDate.month + ".";
   }
   else{
   d1= d1 + this.datePicker.beginDate.month + ".";
   }
   d1 = d1 + this.datePicker.beginDate.year;
	console.log(d1);
	
	var d2 = "";
   if(this.datePicker.endDate.day<10)
   {
    d2 = "0" + this.datePicker.endDate.day + "."; 
   }
   else 
   {
   d2= this.datePicker.endDate.day + ".";
   }
   if(this.datePicker.endDate.month<10)
   { 
   d2= d2 + "0" + this.datePicker.endDate.month + ".";
   }
   else{
   d2 = d2 + this.datePicker.endDate.month + ".";
   }
   d2 = d2 + this.datePicker.endDate.year;
	console.log(d2);
	
	
   this.tableData1.forEach(item => {
   console.log(item.requestdate);
		
	
	if(((item.broj_dosie == this.dosie)|| (this.dosie == "")) && ((this.status == "")||((this.status == "Во процес" && item.status == "се процесира") || (this.status == "Одобрено" && item.status == "одобрено") || (this.status == "Вратено на доработка" && item.status == "вратено на доработка"))) && (item.requestdate > d1 && item.requestdate < d2) && (this.embg == "" || this.embg == item.client_embg))  
	{
	_arr.push(item);
	console.log('Item:', item.broj_dosie);
	}
	
	this.tableData=_arr;	
});
   
  
  }

  setStatus(t: string): void {
    if(t=="Неодредено")
	{ this.status="";
	}
	else{
	this.status = t;
        }
	}

  showForm(id: number) {
    $('#modal-default').modal('show');
    this.pregledNaBaranja.getLoanRequestsDetailsById(id)
      .subscribe(data => {
        console.log(data);
      });
  }

}
