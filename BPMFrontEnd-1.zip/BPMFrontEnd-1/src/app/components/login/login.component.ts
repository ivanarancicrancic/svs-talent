import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
declare var $;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: FormGroup;
  userN: string;
  formNames: any;

  constructor(private loginService: LoginService,  private router: Router, private fb: FormBuilder) { 
    this.user = fb.group({
      'username': [''],
      'password': ['']
    });
  }

  ngOnInit() {
  }

  getUser() {
    this.loginService.getUser(this.user.value)
    .subscribe(data => {
     if(data.status == 1){
     console.log(data);
      sessionStorage.setItem('username', this.user.value.username);
      this.userN = sessionStorage.getItem('username');  
      
      this.loginService.getForms(this.userN)
      .subscribe(dataa => {
        this.formNames = dataa;
        let u = this.formNames[0].imeForma;
        this.router.navigate(['/glavna', u]);
        
      });     
     }else{
      $('#modal-default').modal('show');
     }
     sessionStorage.setItem('groupname', data.groupName);
    });
  }



}
