import { Component, OnInit } from '@angular/core';
declare var $;
@Component({
  selector: 'app-administracija',
  templateUrl: './administracija.component.html',
  styleUrls: ['./administracija.component.css']
})
export class AdministracijaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $('#example1').DataTable({
      'paging'      : true,
      'lengthChange': false,
      'searching'   : false,
      'info'        : false
    })
  }

}
