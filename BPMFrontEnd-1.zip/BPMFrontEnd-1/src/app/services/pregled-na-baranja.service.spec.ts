import { TestBed, inject } from '@angular/core/testing';

import { PregledNaBaranjaService } from './pregled-na-baranja.service';

describe('PregledNaBaranjaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PregledNaBaranjaService]
    });
  });

  it('should be created', inject([PregledNaBaranjaService], (service: PregledNaBaranjaService) => {
    expect(service).toBeTruthy();
  }));
});
