import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable()
export class LoginService {

  constructor(private http: HttpClient) { }

  loginAPI = "http://192.168.1.110:8080/";

  getUser(user:any): Observable<any>{
    return this.http.post<any>(this.loginAPI + 'getloginstatus', user);
  }

  getForms(userName: string): Observable<any>{
    return this.http.get<any>(this.loginAPI + 'getFormsByUsername/userName=' + userName); 
  }


}
