import { TestBed, inject } from '@angular/core/testing';

import { NovoBaranjeService } from './novo-baranje.service';

describe('NovoBaranjeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [NovoBaranjeService]
    });
  });

  it('should be created', inject([NovoBaranjeService], (service: NovoBaranjeService) => {
    expect(service).toBeTruthy();
  }));
});
