import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';


@Injectable()
export class NovoBaranjeService {

  serviceAPI = 'http://192.168.1.110:8080/';

  constructor(private http: HttpClient) { }

  getClients(): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'getClientsType');
  }

  getKreditniLinii(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetKreditniLini/type=' + id);
  }

  getTipKredit(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetLoanTypeByLoanLineID/loanLineID='+ id);
  }

  getLicniPodatoci(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetAplicantDetailsByEmbg/embg=' + id);
  }

  getUsersByUsername(username:string): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetUsersByUsername/username=' + username);
  }

  getDocuments(_loanTypeID: number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetDocumentsForLoanTypeID/_loanTypeID=' + _loanTypeID);
  }

  getDocumentNameById(id: number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'getdocumentnamebyid/id=' + id);
  }

  getUsersByGroupID(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetUsersByGrpoupID/groupID=' + id);
  }

}
