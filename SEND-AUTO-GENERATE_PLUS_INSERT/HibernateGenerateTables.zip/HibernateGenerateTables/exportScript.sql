drop table if exists DEPARTMENT;
create table DEPARTMENT (DEPT_ID integer not null AUTO_INCREMENT, DEPT_NO varchar(20) not null, EMP_DATE datetime not null, primary key (DEPT_ID));
alter table DEPARTMENT add constraint UK504cmb4vdtk4qhlyo0gunu2ew unique (DEPT_NO);



drop table if exists DEPARTMENT;
drop table if exists hibernate_sequence;
create table DEPARTMENT (DEPT_ID integer not null, DEPT_NO varchar(20) not null, EMP_DATE datetime not null, primary key (DEPT_ID));
create table hibernate_sequence (next_val bigint);
insert into hibernate_sequence values ( 1 );
drop table if exists DEPARTMENT;
drop table if exists hibernate_sequence;
create table DEPARTMENT (DEPT_ID integer not null, DEPT_NO varchar(20) not null, EMP_DATE datetime not null, primary key (DEPT_ID));
create table hibernate_sequence (next_val bigint);
insert into hibernate_sequence values ( 1 );
drop table if exists DEPARTMENT;
drop table if exists hibernate_sequence;
create table DEPARTMENT (DEPT_ID bigint not null, DEPT_NO varchar(20) not null, EMP_DATE datetime not null, primary key (DEPT_ID));
create table hibernate_sequence (next_val bigint);
insert into hibernate_sequence values ( 1 );
drop table if exists DEPARTMENT;
drop table if exists hibernate_sequence;
create table DEPARTMENT (DEPT_ID integer not null, DEPT_NO varchar(20) not null, EMP_DATE datetime not null, primary key (DEPT_ID));
create table hibernate_sequence (next_val bigint);
insert into hibernate_sequence values ( 1 );
