package org.o7planning.tutorial.hibernate.entities;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name = "DEPARTMENT",
        uniqueConstraints = { @UniqueConstraint(columnNames = { "DEPT_ID" }) })
public class Department {

    @GeneratedValue(strategy=GenerationType.AUTO)
    @Id
    @Column(name = "DEPT_ID", updatable = false, nullable = false)
    private int deptId;

    @Column(name = "DEPT_NO", length = 20, nullable = false)
    private String deptNo;
    @Column(name = "EMP_DATE", nullable = false)
    private Date empDate;

    public Department() {
    }

    public Department(int deptId, String deptName, String location, Date empDate) {
        this.deptId = deptId;
        this.deptNo = "D" + this.deptId;
        this.empDate = empDate;

    }


    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }


    public String getDeptNo() {
        return deptNo;
    }

    public void setDeptNo(String deptNo) {
        this.deptNo = deptNo;
    }


    public Date getEmp_date() {
        return empDate;
    }

    public void setEmp_date(Date empDate) {
        this.empDate = empDate;
    }

//    @OneToMany(fetch = FetchType.LAZY, mappedBy = "department")
//    public Set<Employee> getEmployees() {
//        return employees;
//    }
//
//    public void setEmployees(Set<Employee> employees) {
//        this.employees = employees;
//    }
}
