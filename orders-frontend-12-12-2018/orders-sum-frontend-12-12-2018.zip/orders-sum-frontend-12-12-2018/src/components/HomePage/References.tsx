import * as React from 'react';

export default class References extends React.Component {

    public render() {
        return (
            <h2>References</h2>
        )
    }

}