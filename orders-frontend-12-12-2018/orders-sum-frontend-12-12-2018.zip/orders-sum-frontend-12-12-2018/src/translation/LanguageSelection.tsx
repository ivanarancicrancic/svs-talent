import * as React from 'react';
import { setLocale } from 'react-redux-i18n';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { IRootState } from '../redux';
import './LanguageSelection.css';
import deIcon from '../assets/images/de.svg';
import enIcon from '../assets/images/en.svg';
import spainIcon from '../assets/images/spain.png';
import frIcon from '../assets/images/fr.png';
import itIcon from '../assets/images/it.png';
import seIcon from '../assets/images/se.png';
import cnIcon from '../assets/images/cn.png';
import hungaryIcon from '../assets/images/hungary.png';
import russiaIcon from '../assets/images/russia.png';

export interface ILanguageSelectionProps {
    setLocale: (locale: string) => Dispatch;
}

class LanguageSelection extends React.Component<ILanguageSelectionProps, any>{

    constructor(props: any) {
        super(props);
    }

    public onClickGerman() {
        this.props.setLocale('de');
    }

    public onClickEnglish() {
        this.props.setLocale('en');
    }

    public render() {
        return (
            <div className="langSelection">
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={enIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickGerman(); }}>
                    <div>
                        <img src={deIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={spainIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={frIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={seIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={itIcon} />
                    </div>
                </button>
              
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={cnIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={hungaryIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={russiaIcon} />
                    </div>
                </button>
            </div>
        );
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, { setLocale })(LanguageSelection)