import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of'; 

@Injectable()
export class LoginService {

  constructor(private http: HttpClient) { }

  loginAPI = "http://192.168.1.110:8080/";

  getUser(user:any): Observable<any>{
    return this.http.post<any>(this.loginAPI + 'getloginstatus', user);
  }

}
