import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';


@Injectable()
export class NovoBaranjeService {

  serviceAPI = 'http://192.168.1.110:8080/';

  constructor(private http: HttpClient) { }

  getClients(): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'getClientsType');
  }

  getKreditniLinii(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetKreditniLini/type=' + id);
  }

  getTipKredit(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetLoanTypeByLoanLineID/loanLineID='+ id);
  }

  getLicniPodatoci(id:number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'GetAplicantDetailsByEmbg/embg=' + id);
  }

}
