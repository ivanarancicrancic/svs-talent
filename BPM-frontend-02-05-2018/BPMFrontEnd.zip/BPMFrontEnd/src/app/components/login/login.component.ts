import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
declare var $;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user = {
    username: "",
    password: ""
  }

  constructor(private loginService: LoginService,  private router: Router) { }

  ngOnInit() {
  }

  getUser() {
    this.loginService.getUser(this.user)
    .subscribe(data => {
      console.log(data);
     if(data.status == 1){
      this.router.navigateByUrl('/glavna/novo-baranje');
     }else{
      $('#myModal').modal('show');
     }
     sessionStorage.setItem('username', this.user.username);
    });
  }

}
