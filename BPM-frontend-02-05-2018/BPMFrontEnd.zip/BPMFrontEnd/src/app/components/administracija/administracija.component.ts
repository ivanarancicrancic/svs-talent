import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-administracija',
  templateUrl: './administracija.component.html',
  styleUrls: ['./administracija.component.css']
})
export class AdministracijaComponent implements OnInit {

  showForm: boolean = false;
  datePicker: any;

  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };
  constructor() { }

  ngOnInit() {
    this.setDate();
  }

  setDate(): void{
    let date = new Date();
    this.datePicker = {date: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }
  show(): void{
    this.showForm = true;
  }

}
