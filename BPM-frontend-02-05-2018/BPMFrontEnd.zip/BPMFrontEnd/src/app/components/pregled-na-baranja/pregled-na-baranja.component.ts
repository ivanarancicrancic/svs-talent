import { Component, OnInit } from '@angular/core';
import {IMyDrpOptions, IMyDateRangeModel} from 'mydaterangepicker';

@Component({
  selector: 'app-pregled-na-baranja',
  templateUrl: './pregled-na-baranja.component.html',
  styleUrls: ['./pregled-na-baranja.component.css']
})
export class PregledNaBaranjaComponent implements OnInit {
  
  
  datePicker: any;

  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };


  constructor() { }

  ngOnInit() {
    this.setDate();
  }

  setDate(): void{
    let date = new Date();
    this.datePicker = {
      beginDate: {year: date.getFullYear(), month: date.getMonth()+1, day: 1},
      endDate:   {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}
    };
  }

}
