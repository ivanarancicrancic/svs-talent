import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { NovoBaranjeService } from '../../services/novo-baranje.service';

declare var $;

@Component({
  selector: 'app-novo-baranje',
  templateUrl: './novo-baranje.component.html',
  styleUrls: ['./novo-baranje.component.css']
})
export class NovoBaranjeComponent implements OnInit {

  datePicker: any;
  filesArray: any = [];
  komintenti: any;
  kreditniLinii: any;
  tipKredit: any;
  licniPodatoci: any;
  lp: any;
  option1: boolean;
  option2: boolean;

  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };


  constructor(private novoBaranje: NovoBaranjeService) { }

  ngOnInit() {
    this.setDate();
    this.getKomintent();
    this.lp =   {
      "firstName": "",
      "lastName": "",
      "partija": "",
      "address": "",
      "bracnasostojba": "",
      "brojdeca": 0,
      "dokumentbroj": "",
      "godinaziveenjenaadresa": "",
      "kontaktadresa": "",
      "telefon": "",
      "mobtelefon": "",
      "zivealiste": ""
  }

  }

  setDate(): void{
    let date = new Date();
    this.datePicker = {date: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }

  dodeliPodatoci(): void{
    $('#myModal').modal('show');
  }

  onChange(event: any) {
    let file = [].slice.call(event.target.files);
    let files = file.map(f => f.name);
    this.filesArray.push(files);
  }

  getKomintent(): void{
   this.novoBaranje.getClients()
   .subscribe(data => {
     console.log(data);
     this.komintenti = data;
   });
  }

  getKreditniLinii(id:number){
    this.novoBaranje.getKreditniLinii(id)
    .subscribe(data => {
      console.log(data);
      this.kreditniLinii = data;
    });
  }

  getTipKredit(id:number){
    this.novoBaranje.getTipKredit(id)
    .subscribe(data => {
      console.log(data);
      this.tipKredit = data;
    });
  }

  getLicniPodatoci(id:number){
    this.novoBaranje.getLicniPodatoci(id)
    .subscribe(data => {
      this.licniPodatoci = data;
      this.lp = this.licniPodatoci[0];
      if(this.lp.pol = "М"){ 
      this.option1 = true;
      this.option2 = false;
    }
      else{
      this.option2 = true;
      this.option1 = false;
      }
    });
  }
  

}
