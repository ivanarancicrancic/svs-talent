import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MyDateRangePickerModule } from 'mydaterangepicker';
import { MyDatePickerModule } from 'mydatepicker';
import { HttpClientModule } from '@angular/common/http';
 
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AppRoutingModule } from './app-routing.module';
import { MainComponent } from './components/main/main.component';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { NovoBaranjeComponent } from './components/novo-baranje/novo-baranje.component';
import { PregledNaBaranjaComponent } from './components/pregled-na-baranja/pregled-na-baranja.component';
import { AdministracijaComponent } from './components/administracija/administracija.component';
import { NovoBaranjeService } from './services/novo-baranje.service';
import { LoginService } from './services/login.service';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainComponent,
    HeaderComponent,
    SidebarComponent,
    NovoBaranjeComponent,
    PregledNaBaranjaComponent,
    AdministracijaComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    MyDatePickerModule, 
    MyDateRangePickerModule,
    HttpClientModule
  ],
  providers: [LoginService,NovoBaranjeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
