import React, { PureComponent } from 'react';
import './App.css';
import Persons from '../components/Persons/Persons';
import Cockpit from '../components/Cockpit/Cockpit';
import Radium, { StyleRoot } from 'radium';

class App extends PureComponent {
    constructor(props){
        super(props);
        console.log('[App.js] Entered Constructor', props)
        this.state =  {
            persons: [
                {id: '35447897', name: 'Ivana', age: 28},
                {id: '4646', name: 'Hanna', age: 25},
                {id: '565', name: 'Josh', age: 29}
            ],
            showPersons: false
        }

    }

   componentWillMount(){
        console.log('[App.js] Entered componentWillMount()');
   }

   componentDidMount(){
       console.log('[App.js] Entered componentDidMount()');

   }

    // shouldComponentUpdate(nextProps, nextState){
    //     console.log('[UPDATE Persons.js] Entered shouldComponentUpdate', nextProps, nextState);
    //    // return true;
    //     return nextState.persons !== this.state.persons || nextState.showPersons !== this.state.showPersons;
    // }

    componentWillUpdate(nextProps, nextState){
        console.log('[UPDATE App.js] Entered componentWillUpdate', nextProps, nextState);

    }

    componentDidUpdate(){
        console.log('[UPDATE App.js] Entered this.componentDidUpdate');
    }

  // state = {
  //  persons: [
  //      {id: '35447897', name: 'Ivana', age: 28},
  //      {id: '4646', name: 'Hanna', age: 25},
  //      {id: '565', name: 'Josh', age: 29}
  //  ],
  //      showPersons: false
  // }

    deletePersonHandler = (personIndex) => {
        const persons = [...this.state.persons];
        persons.splice(personIndex, 1);
   this.setState({persons: persons});
    }

    nameChangedHandler = ( event, id ) => {
      console.log("Entered nameChangedHandler!!");
      const personIndex = this.state.persons.findIndex(p => {
          console.log("Looped person id: " + p.id);
          return p.id===id;
        });

        console.log("Returned personIndex to be changed: " + personIndex);
        const person = {...this.state.persons[personIndex]};
        console.log("Person name: " + person.name);
        person.name = event.target.value;
        const persons = [...this.state.persons];
        persons[personIndex] = person;
        this.setState({
            persons: persons
        })
    }

    togglePersonsHandler = () => {
       const doesShow = this.state.showPersons;
       this.setState({showPersons: !doesShow});
    }

  render() {

        console.log('[App.js] Entered render()');
      const style = {
       backgroundColor: 'yellow',
          font: 'inherit',
          border: '1px solid blue',
          padding: '8px',
          cursor: 'pointer',
          ':hover' : {
           backgroundColor: 'lightgreen',
              color: 'black'
          }
      }

      const style1 = {
          backgroundColor: 'gray'
      }

      let persons = null;
      if(this.state.showPersons){
          persons =
                <Persons persons={this.state.persons}
                clicked={this.deletePersonHandler}
                changed={this.nameChangedHandler}/>;

      }


      const classes = [];
      if(this.state.persons.length <= 2){
          classes.push('red');
      }

  return(
      <StyleRoot>
      <div className="App" style={style1}>
          {/*<h1>I'm a React App</h1>*/}
          {/*<p className={classes.join(' ')}>This is really working!!</p>*/}
          {/*<button style={style} onClick={this.togglePersonsHandler}>Switch content</button>*/}

          <button onClick={() => {this.setState({showPersons: true})}}>Show persons</button>
          <Cockpit appTitle={this.props.title} showPersons={this.state.showPersons}
                   persons={this.state.persons}  clicked={this.togglePersonsHandler}/>
          {persons}
      </div>
      </StyleRoot>
  );
  }
}

export default Radium(App);
