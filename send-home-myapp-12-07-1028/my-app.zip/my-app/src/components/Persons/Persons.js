import  React, { Component } from 'react'
import Person from './Person/Person';

class Persons extends Component{
    constructor(props){
        super(props);
        console.log('[Persons.js] Entered Constructor', props)
    }

    componentWillMount(){
        console.log('[Persons.js] Entered componentWillMount()');
    }

    componentDidMount(){
        console.log('[Persons.js] Entered componentDidMount()');

    }

    componentWillReceiveProps(nextProps ){
        console.log('[UPDATE Persons.js] Entered componentWillReceiveProps', nextProps);
    }

    shouldComponentUpdate(nextProps, nextState){
        console.log('[UPDATE Persons.js] Entered shouldComponentUpdate', nextProps, nextState);
      return nextProps.persons !== this.props.persons || nextProps.changed !== this.props.changed || nextProps.clicked !== this.props.clicked;
    //return true;
    }

    componentWillUpdate(nextProps, nextState){
        console.log('[UPDATE Persons.js] Entered componentWillUpdate', nextProps, nextState);

    }

    componentDidUpdate(){
        console.log('[UPDATE Pesrons.js] Entered this.componentDidUpdate');
    }

    render(){
          console.log('[Persons.js] Entered render()');
         return this.props.persons.map((person, index) => {
              return <Person
                  name={person.name}
                  age={person.age}
                  key={person.id}
                  changed={(event) => this.props.changed(event, person.id)}
                  click={() => this.props.clicked(index)}/>
          });

      }
}


export  default Persons;