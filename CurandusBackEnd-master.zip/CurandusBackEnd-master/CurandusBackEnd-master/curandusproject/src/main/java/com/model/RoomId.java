package com.model;

public class RoomId {
	private String RoomId;

	public RoomId(String roomId) {
		super();
		RoomId = roomId;
	}

	public String getRoomId() {
		return RoomId;
	}

	public void setRoomId(String roomId) {
		RoomId = roomId;
	}
}
