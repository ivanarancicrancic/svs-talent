package springwebappservice.service;

import springwebapp.commands.AuthorCommand;

import springwebapp.converters.AuthorCommandToAuthor;
import springwebapp.converters.AuthorToAuthorCommand;
import springwebapp.model.Author;
import org.springframework.beans.factory.annotation.Autowired;
import springwebapp.model.Book;
import springwebapp.repository.AuthorRepository;
import springwebapp.repository.BookRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AuthorServiceImpl implements AuthorService {
    @Autowired
    AuthorRepository repository;

    @Autowired
    BookRepository bookRepository;

    AuthorToAuthorCommand authorToAuthorCommand;

    AuthorCommandToAuthor commandToAuthor;

    public AuthorServiceImpl(AuthorRepository repository, AuthorCommandToAuthor authorCommandToAuthor, AuthorToAuthorCommand authorToAuthorCommand, BookRepository bookRepository) {
        this.repository = repository;
        this.commandToAuthor = authorCommandToAuthor;
        this.authorToAuthorCommand = authorToAuthorCommand;
    }

    @Override
    public Author creatAuthor(Author author){ return repository.save(author);}


    @Override
    public List<Author> getAllAuthors(){
        System.out.println("Entered ServiceImpl getAllAuthors..");
        Iterable<Author> iterable = repository.findAll();

        List<Author> list = new ArrayList<Author>();
        if(iterable != null) {
            for(Author e: iterable) {
                System.out.println("Author: " + e.getId());
                list.add(e);
            }
        }
        return list;
    }

    @Override
    public AuthorCommand findAuthorById(Long authorId){
        String status = "getting command author by id";
        System.out.println(status);
        Author author =  repository.findById(authorId).get();

        AuthorCommand authorCommand = authorToAuthorCommand.convert(author);

        return authorCommand;
    }

    @Override
    public AuthorCommand findByBookIdAndAuthorId(Long bookId, Long authorId){
        String status = "getting command author";
        System.out.println(status);
        Optional<Author> authorOptional =  repository.findById(authorId);

        Optional<Book> bookOptional = bookRepository.findById(bookId);
        if (!bookOptional.isPresent()){
            System.out.println("book id not found. Id: " + bookId);
        }

        Book book = bookOptional.get();

        Optional<AuthorCommand> authorCommandOptional = book.getAuthors().stream()
                .filter(author -> author.getId().equals(authorId))
                .map( author -> authorToAuthorCommand.convert(author)).findFirst();

        if(!authorCommandOptional.isPresent()){
            System.out.println("Author id not found: " + authorId);
        }

        return authorCommandOptional.get();
        //AuthorCommand authorCommand = authorToAuthorCommand.convert(authorOptional.get());
        //return authorCommand;
    }



    @Override
    public AuthorCommand updateAuthor(AuthorCommand authorCommand) {
        String status = "updating Author";
        System.out.println(status);
        Author author =  commandToAuthor.convert(authorCommand);
        repository.save(author);
        System.out.println("Book id" + authorCommand.getBookId());
        return authorCommand;
    }

//    @Override
//    public AuthorCommand createAuthor(AuthorCommand authorCommand){
//        Author author = commandToAuthor.convert(authorCommand);
//        Author savedAuthor = repository.save(author);
//        return authorToAuthorCommand.convert(savedAuthor);
//    }

    @Override
    public AuthorCommand addAuthorToBook(Long bookId, AuthorCommand authorCommand){
        String status = "Adding author to book";
        System.out.println(status);
        Author author = commandToAuthor.convert(authorCommand);
       // System.out.println("Book with id: " + bookId + ", and author with id: " + authorCommand.getId());
        repository.save(author);
       Author savedAuthor  = repository.findById(author.getId()).get();

        Book book = bookRepository.findById(bookId).get();
        book.getAuthors().add(repository.findById(savedAuthor.getId()).get());
        bookRepository.save(book);
        return authorCommand;
    }

    @Override
    public void deleteAuthor(Long id) {
        String status = "Deleting author";
        System.out.println(status);
        repository.deleteById(id);
    }

   @Override
   public void deleteAuthorFromBook(Long bookId, Long authorId)
   {
       String status = "Deleting author";
       System.out.println(status);
       Book book = bookRepository.findById(bookId).get();
       book.getAuthors().remove(repository.findById(authorId).get());
       bookRepository.save(book);

   }
}
