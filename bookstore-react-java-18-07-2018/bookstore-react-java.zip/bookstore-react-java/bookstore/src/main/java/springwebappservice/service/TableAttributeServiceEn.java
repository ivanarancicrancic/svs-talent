package springwebappservice.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.model.TableAtrtributes;
import springwebapp.repository.TableAttributeRepository;

@Service
@Component
@Profile({"en"})
public class TableAttributeServiceEn implements TableAttributeService {

    private TableAttributeRepository translateRepository;

    public TableAttributeServiceEn(TableAttributeRepository translateRepository) {
        this.translateRepository = translateRepository;
    }

    @Override
    public TableAtrtributes translate() {
        return translateRepository.getEnglishTableAttributes();
    }
}
