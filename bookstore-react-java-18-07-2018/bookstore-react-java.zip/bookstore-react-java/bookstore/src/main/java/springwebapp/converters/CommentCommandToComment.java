package springwebapp.converters;

import springwebapp.commands.CommentCommand;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Comment;

@Component
public class CommentCommandToComment implements Converter<CommentCommand, Comment> {

    @Override
    public Comment convert(CommentCommand source){

        if(source == null){
            return null;
        }

        final Comment comment = new Comment();
        comment.setId(source.getId());
        comment.setComment(source.getComment());
        return comment;
    }


}
