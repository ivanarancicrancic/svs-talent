package springwebapp.converters;

import springwebapp.commands.BookCommand;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.commands.CategoryCommand;
import springwebapp.model.Book;
import springwebapp.model.Category;

import java.util.HashSet;
import java.util.Set;

@Component
public class BookToBookCommand implements Converter<Book, BookCommand> {

    private final CategoryToCategoryCommand categoryConveter;
    private final CommentToCommentCommand commentConverter;
    private final AuthorToAuthorCommand authorConverter;
    private final EvaluationToEvaluationCommand evaluationConverter;
    private final PublisherToPublisherCommand publisherConverter;

    public BookToBookCommand(CategoryToCategoryCommand categoryConveter, CommentToCommentCommand commentConverter, AuthorToAuthorCommand authorConverter, EvaluationToEvaluationCommand evaluationConverter, PublisherToPublisherCommand publisherConverter) {
        this.categoryConveter = categoryConveter;
        this.commentConverter = commentConverter;
        this.authorConverter = authorConverter;
        this.evaluationConverter = evaluationConverter;
        this.publisherConverter = publisherConverter;
    }


    @Override
    public BookCommand convert(Book source){
        if(source == null){
            return null;
        }

        System.out.println("Entered convert method");

        final BookCommand book = new BookCommand();


        book.setId(source.getId());
        System.out.println("ID:" + book.getId());

        book.setTitle(source.getTitle());
        System.out.println("Title" + book.getTitle());

        book.setImage(null);

        book.setDescription(source.getDescription());
        System.out.println("Description: " + book.getDescription());

        book.setSize(source.getSize());
        System.out.println("Size: " + book.getSize());

        book.setUrl(source.getUrl());
        System.out.println("URL: " + book.getUrl());

        book.setNote(source.getNote());
        System.out.println("Note: " + book.getNote());

        book.setStringCategories(source.getStringCategories());
        System.out.println("String categories: " + book.getStringCategories());

        book.setDifficutly(source.getDifficutly());
        System.out.println("Difficulty: " + book.getDifficutly());

        book.setPublisher(publisherConverter.convert(source.getPublisher()));
        System.out.println("Publisher: " + book.getPublisher());

        if (source.getCategories() != null){
             System.out.println("source.getCategories() != null");
            Set<CategoryCommand> categoryList = new HashSet<>();
            for(Category category : source.getCategories()){
                System.out.println("Listing book categories: " + categoryList);
               categoryList.add(categoryConveter.convert(category));
                System.out.println("Listing extended book categories: " + categoryList);
            }
            book.setCategories(categoryList);
       //             source.getCategories(
            //                    .forEach( category -> book.getCategories().add(categoryConveter.convert(category)));
        }
        if(book.getCategories()==null){
            System.out.println("Converted Categories null!!!");
        }
        else
        {
            for(CategoryCommand c : book.getCategories()){
                System.out.println("Category: " + c.getDescription());

            }

        }


        if (source.getAuthors() != null && source.getAuthors().size() > 0){
            source.getAuthors()
                    .forEach(author -> book.getAuthors().add(authorConverter.convert(author)));
        }
        System.out.println("Authors: " + book.getAuthors());

        if (source.getComments() != null && source.getComments().size() > 0){
            source.getComments()
                    .forEach(comment -> book.getComments().add(commentConverter.convert(comment)));
        }
        System.out.println("Comments: " + book.getComments());

        book.setEvaluation(evaluationConverter.convert(source.getEvaluation()));
        System.out.println("Evaluation: " + book.getEvaluation());

        return book;
    }


}
