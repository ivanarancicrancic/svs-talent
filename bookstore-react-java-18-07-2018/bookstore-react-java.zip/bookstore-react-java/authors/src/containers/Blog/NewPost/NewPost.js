import React, { Component } from 'react';

import './NewPost.css';

class NewPost extends Component {
    state = {
        title: '',
        content: '',
        description: '',
        author: 'Max',
        authors: [],
        image: '',
        evaluation: null,
        comments: null,
        size: '',
        url: '',
        note: '',
        publisher: null,
        difficutly: '',
        categories: null,
        stringCategories: '',
        authors: null
    }

    postDataHandler = () => {
        console.log("CALLED postDataHandler")
        const book= {
            title: this.state.title,
            description: this.state.description,
            image: '',
            evaluation: null,
            size: '1003',
            url: '',
            note: 'MUST READ!',
            publisher: null,
            categories: null,
            stringCategories: '',
            authors: null
        }

        fetch('http://localhost:9575/create', {
            method: 'post',
            body: JSON.stringify(book),
            headers: {"Content-Type": "application/json"}
        }).then(function(response) {
            return response.json();
        }).then(function(data) {
            console.log(data);
        });

        // fetch('http://localhost:9575/create',{
        //     method: 'POST',
        //     body: JSON.stringify({
        //         book: book
        //     }),
        //     headers: {"Content-Type": "application/json"}
        // })
        //     .then(function(response){
        //         return response.json()
        //     }).then(function(body){
        //     console.log(body);
        // });

    }

    render () {
        return (
            <div className="NewPost">
                <h1>Add a Post</h1>
                <label>Title</label>
                <input type="text" value={this.state.title} onChange={(event) => this.setState({title: event.target.value})} />
                <label>Content</label>
                <textarea rows="4" value={this.state.content} onChange={(event) => this.setState({content: event.target.value})} />
                <label>Author</label>
                <select value={this.state.author} onChange={(event) => this.setState({author: event.target.value})}>
                    <option value="Max">Max</option>
                    <option value="Manu">Manu</option>
                </select>
                <button onClick={this.postDataHandler}>Add Post</button>
            </div>
        );
    }
}

export default NewPost;