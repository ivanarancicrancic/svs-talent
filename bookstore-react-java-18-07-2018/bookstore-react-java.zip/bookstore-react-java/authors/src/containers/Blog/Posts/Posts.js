import React, { Component } from 'react';

import './Posts.css';
import Post from '../../../components/Post/Post';

class Posts extends Component{

    state =  {
        books: [
        ]
    }

    postSelectedHandler = (id) => {
        this.setState({selectedPostId: id});

    }



    deleteBookHandler = (id) => {

        fetch('http://localhost:9575/book/' + id + '/delete')
            .then(response => response.json())
            .then(data => {
                    console.log("Deleted book: " + data.title);
                    this.setState({deleted: true});
                    fetch('http://localhost:9575/books')
                        .then(response => response.json())
                        .then(data =>
                            //         {
                            //             //   this.setState({books: data});
                            //             // const books1 = this.state.books.map(book => {
                            //             //     fetch('http://localhost:9575/book/'+  book.id + '/authors')
                            //             //         .then(response => response.json())
                            //             //         .then(data => {console.log("yes", data); this.setState({authors: data}); });
                            //             //
                            //             //     return <Post title={book.title} authors={this.state.authors}/>;
                            //             // });
                            this.setState({books: data})
                        );

                }
            );

    }

    componentDidMount() {
        fetch('http://localhost:9575/books')
            .then(response => response.json())
            .then(data =>
                {
                    //   this.setState({books: data});
                    // const books1 = this.state.books.map(book => {
                    //     fetch('http://localhost:9575/book/'+  book.id + '/authors')
                    //         .then(response => response.json())
                    //         .then(data => {console.log("yes", data); this.setState({authors: data}); });
                    //
                    //     return <Post title={book.title} authors={this.state.authors}/>;
                    // });
                    this.setState({books: data}); }
            )
            .catch(error => {
              //  this.setState({error: true});
                console.log("Setstate error: " + error);
            });



    }


    render() {
       // let books = <p style={{textAlign: 'center'}}>Something went wrong! </p>;
       // if(!this.state.error)
            let books = this.state.books.map(book => { var b = book.authors.map(author => {var a = author.firstName + ' ' + author.lastName; console.log(author.firstName + ' ' + author.lastName); return a;}); console.log("Book authors: " + book.authors); return <Post key={book.id} title={book.title} authors={b} clicked={() => this.postSelectedHandler(book.id)}/>});

        return (
            <section className="Posts">
                {books}
            </section>
        );
    }
}

export default Posts;