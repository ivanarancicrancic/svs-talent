import React, { Component } from 'react';

import './FullPost.css';

class FullPost extends Component {
    state = {
        loadedBook: null,
        error: false,
        deleted: false
    }

    componentDidUpdate() {
        if (this.props.id) {

            if ((!this.state.deleted) && ((!this.state.loadedBook) || (this.state.loadedBook && this.state.loadedBook.id !== this.props.id))) {
                fetch('http://localhost:9575/book/show/' + this.props.id)
                    .then(response => response.json())
                    .then(data => {
                            console.log("Selected book: " + data.title);
                            this.setState({loadedBook: data});
                        }
                    )
                    .catch(error => {
                        this.setState({error: true});
                        console.log("Setstate error: " + this.state.error);
                    });


            }
        }
    }

    deleteBookHandler = () => {
        fetch('http://localhost:9575/book/' + this.props.id + '/delete')
            .then(response => response.json())
            .then(data => {
                    console.log("Deleted book: " + data.title);
                    this.setState({deleted: true});
                }
            );
    }

    render () {
        let post = <p style={{textAlign: 'center'}}>Please select a Book!</p>;
        if(this.props.id) {
             post = <p style={{textAlign: 'center'}}>Loading...</p>;

        }

        if(this.state.loadedBook && !this.state.error) {

            post = (
                <div className="FullPost">
                    <h1>{this.state.loadedBook.title}</h1>
                    <p>{this.state.loadedBook.description}</p>
                    <div className="Edit">
                        <button onClick={ () => this.props.clicked(this.props.id)} className="Delete">Delete</button>
                    </div>
                </div>

            );
        }

        return post;
    }
}

export default FullPost;