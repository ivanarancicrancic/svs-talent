package springwebapp.bootstrap;

import springwebapp.model.*;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import springwebapp.repository.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by jt on 5/16/17.
 */
@Component
public class DbInit implements ApplicationListener<ContextRefreshedEvent> {

    private AuthorRepository authorRepository;
    private BookRepository bookRepository;
    private PublisherRepository publisherRepository;
    private CommentRepository commentRepository;
    private EvaluationRepository evaluationRepository;
    private CategoryRepository categoryRepository;
  
    public DbInit(AuthorRepository authorRepository, BookRepository bookRepository, PublisherRepository publisherRepository, CommentRepository commentRepository, EvaluationRepository evaluationRepository, CategoryRepository categoryRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
        this.publisherRepository = publisherRepository;
        this.commentRepository = commentRepository;
        this.evaluationRepository = evaluationRepository;
        this.categoryRepository = categoryRepository;
     //   this.noteRepository = noteRepository;
    }

    @Override
    public void onApplicationEvent(ContextRefreshedEvent contextRefreshedEvent) {
        initData();
    }

    private void initData(){

        System.out.println("Init data!");
        Publisher publisher = new Publisher();
       // Note note = new Note();
       // note.setNote("This is adventure book. Not under age of 10");
        //noteRepository.save(note);



        publisher.setName("Joe");
        publisher.setAddress("Some street");
        publisherRepository.save(publisher);

        Evaluation evaluation = new Evaluation();
        evaluation.setEvaluation("8");
        evaluationRepository.save(evaluation);

        Comment comment = new Comment();
        comment.setComment("");
        commentRepository.save(comment);

//        Difficutly difficutly = new Difficutly();

        Author author = new Author();
        author.setFirstName("Ivana");
        author.setLastName("Rancic");

        Book book1 = new Book();

        Category category = categoryRepository.findByDescription("Education");
       /// if(category==null){System.out.println("Empty category");}

        Set<Category> categoryList = new HashSet<>();
        categoryList.add(category);

         Category newCategory = new Category();
         newCategory.setDescription("Programming");
        categoryRepository.save(newCategory);
        categoryList.add(newCategory);

//        String categoriesString = "";
//        for(Category c : categoryList){
//            categoriesString = categoriesString + ", " + c.getDescription();
//            System.out.println("Category description: " + c.getDescription());
//        }
       // book1.setStringCategories(categoriesString);

        book1.setStringCategories("Education");
        book1.setTitle("Java enterprise  ");
        book1.setEvaluation(evaluation);
        book1.setDescription("Education book about Java advnaced proggraming language...");
        book1.setSize("1255");
        book1.setPublisher(publisher);
        book1.setDifficutly(Difficutly.HARD);
        book1.setUrl("https://www.amazon.com/Advanced-Java%C2%AE-EE-Development-WildFly%C2%AE/dp/1783288906");
        author.getBooks().add(book1);
        book1.getAuthors().add(author);
        book1.setCategories(categoryList);
        book1.setNote("Because of the level of difficulty this book is not recommended under the age of 12.");
       // Set<Comment> comments = new HashSet<>();
        Comment comment1 = new Comment();
        comment1.setComment("This book is true challenge for all Java enthusiasts!!! Don't miss this chance to get yuor knowlegde now!");
//        comments.add(comment1);
//        book1.setComments(comments);

        authorRepository.save(author);
        bookRepository.save(book1);

        comment1.setBook(book1);
        commentRepository.save(comment1);

        Author author2 = new Author();
        author2.setFirstName("Peter"); author2.setLastName("Clark");
        Book book2 = new Book();
        book2.setTitle("LOTR");
        book2.setStringCategories("Adventure");
        book2.setEvaluation(evaluation);
        book2.setDescription("Adventure book about..");
        book2.setSize("500"); book2.setUrl(""); book2.setPublisher(publisher); author2.getBooks().add(book2);
        book2.getAuthors().add(author2);


        authorRepository.save(author2);
        bookRepository.save(book2);
   }
}
