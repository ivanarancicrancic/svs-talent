package springwebappservice.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.model.TableAtrtributes;
import springwebapp.repository.TableAttributeRepository;

@Service
@Component
@Profile({"default", "german"})
public class TableAttributeServiceGerman implements TableAttributeService {

    private TableAttributeRepository translateRepository;

    public TableAttributeServiceGerman(TableAttributeRepository translateRepository) {
        this.translateRepository = translateRepository;
    }

    @Override
    public TableAtrtributes translate() {
        return translateRepository.getGermanTableAttributes();
    }

}
