package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;

import java.util.List;

public class AudioContentList {
    private List<AudioContent> audioContentList;

    public AudioContentList(List<AudioContent> audioContentList) {
        this.audioContentList = audioContentList;
    }

    public List<AudioContent> getAudioContentList() {
        return audioContentList;
    }

    public void setAudioContentList(List<AudioContent> audioContentList) {
        this.audioContentList = audioContentList;
    }
}
