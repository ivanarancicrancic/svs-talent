package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.model.request.TrackerList;
import  de.diefuturisten.easyr.easyrapi.service.TrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.http.HttpStatus;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;

@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api1")
public class TrackerController {

    public static final String BASE_URL = "/api/trackers/";

    @Autowired
    TrackerService trackerService;

    public TrackerController(TrackerService trackerService) {
        this.trackerService = trackerService;
    }

    @GetMapping("/campaign/{id}/trackers")
    @ResponseStatus(HttpStatus.OK)
    public TrackerList getTrackersByCampaign(@PathVariable String id)
    {
        System.out.println("Entered /campaign/{id}/trackers");
        java.util.Set<Tracker> trackers = new java.util.HashSet<>();
        java.util.Set<Tracker> allTrackers = new java.util.HashSet<>();
        System.out.println(trackerService.getAllTrackers().size());
            allTrackers = trackerService.getAllTrackers();
            for(Tracker tracker: allTrackers)
            {
                System.out.println("Looped Tracker campaign vuforiaID: " + tracker.getVuforiaId());
               System.out.println("Looped tracker CAMPAIGN ID: " + tracker.getCampaign().getId());
                if(tracker.getCampaign().getId() == new Long(id))
                {
                    trackers.add(tracker);
                }
            }

            return new TrackerList(trackers);

    }



    @GetMapping("/tracker/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Tracker showById(@PathVariable String id){
        System.out.println("entered tracker/show/{id}");

            Tracker tracker =  trackerService.findById(new Long(id));
            return tracker;
    }

    @PostMapping("campaign/{id}/tracker/create")
    @ResponseStatus(HttpStatus.CREATED)
    public Tracker createTracker(@PathVariable String id, @RequestBody Tracker tracker){

        System.out.println("Before create tracker call for tracker.getURL(): " + tracker.getUrl() + "and for campaign id: " + id);
       Tracker createdTracker = trackerService.createTrackerToCampaign(Long.parseLong(id), tracker);
          //  System.out.println("Id of tracker created:" + createdTracker.getId());
            return createdTracker;

    }

    @PutMapping("campaign/{id}/tracker/update")
    @ResponseStatus(HttpStatus.OK)
    public Tracker saveOrUpdate(@RequestBody Tracker tracker) throws  Exception{
        System.out.println("Before updating tracker! TRACKER UPDATE CALLED WITH ID:" + tracker.getId());
        Tracker savedTracker = trackerService.updateTracker(tracker);
        System.out.println("Id of tracker updated:" + savedTracker.getId());
            return tracker;
    }

    @GetMapping("campaign/{id}/tracker/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    public Tracker deleteTracker(@PathVariable String id){
        System.out.println("Entered deleting tracker");
        de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker tracker =  trackerService.findById(new Long(id));
        trackerService.deleteTracker(Long.valueOf(id));
        return tracker;

    }


}
