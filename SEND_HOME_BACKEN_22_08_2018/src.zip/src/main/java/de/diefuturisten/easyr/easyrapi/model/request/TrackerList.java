package de.diefuturisten.easyr.easyrapi.model.request;

import java.util.Set;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;

public class TrackerList {

    private Set<Tracker> trackerList;

    public TrackerList(Set<Tracker> trackerList) {
        this.trackerList = trackerList;
    }

    public Set<Tracker> getTrackerList() {
        return trackerList;
    }

    public void setTrackerList(Set<Tracker> trackerList) {
        this.trackerList = trackerList;
    }
}
