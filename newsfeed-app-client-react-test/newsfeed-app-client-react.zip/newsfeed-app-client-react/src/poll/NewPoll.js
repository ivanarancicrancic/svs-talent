import React, { Component } from 'react';
import { createPoll } from '../util/APIUtils';
import { POLL_NEWSFEED_MAX_LENGTH } from '../constants';
import './NewPoll.css';  
import { Form, Input, Button, notification } from 'antd';
const FormItem = Form.Item;
const { TextArea } = Input

class NewPoll extends Component {
    constructor(props) {
        super(props);
        this.state = {
            newsfeed: {
                text: '',
                validateStatus: ''
            },
            choices: [{
                text: 'I find this info very useful'
            }, {
                text: 'I find this info not so useful'
            }],
            pollLength: {
                days: 1,
                hours: 0
            },
            title: {
                text: '', 
                validateStatus: ''
            },
            
            description: {
                text: ''
            },
            url: {
                text: ''
            },
            link: {
                text: ''
            },
            summary: {
                text: ''
            }
        };
      
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleNewsfeedChange = this.handleNewsfeedChange.bind(this);
        this.isFormInvalid = this.isFormInvalid.bind(this);
        this.handleTitleChange = this.handleTitleChange.bind(this);
        this.handleDescriptionChange = this.handleDescriptionChange.bind(this);
        this.handleUrlChange = this.handleUrlChange.bind(this);
        this.handleLinkChange = this.handleLinkChange.bind(this);
        this.handleSummaryChange = this.handleSummaryChange.bind(this); 

    }


    handleSubmit(event) {
        event.preventDefault();
        const pollData = {
            title: this.state.title.text,
            description: this.state.description.text,
            summary: this.state.summary.text,
            link: this.state.link.text,
            url: this.state.url.text,
            pollLength: this.state.pollLength
        };

        createPoll(pollData)
        .then(response => {
            this.props.history.push("/");
        }).catch(error => {
            if(error.status === 401) {
                this.props.handleLogout('/login', 'error', 'You have been logged out. Please login create poll.');    
            } else {
                notification.error({
                    message: 'Newsfeed App',
                    description: error.message || 'Sorry! Something went wrong. Please try again!'
                });              
            }
        });
    }

    validateTitle = (title) => {
        if(title.length === 0) {
            return {
                validateStatus: 'error',
                errorMsg: 'Please enter your news feed!'
            }
        } else if (title.length > POLL_NEWSFEED_MAX_LENGTH) {
            return {
                validateStatus: 'error',
                errorMsg: `News feed is too long (Maximum ${POLL_NEWSFEED_MAX_LENGTH} characters allowed)`
            }    
        } else {
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        }
    }

    handleNewsfeedChange(event) {
        const value = event.target.value;
        this.setState({
            newsfeed: {
                text: value,
                ...this.validateNewsfeed(value)
            }
        });
    }

    
    handleTitleChange(event) {
        const value = event.target.value;
        
        console.log("NEW TITLE: " + value);
        console.log("CURREENT TITLE STATE: " + this.state.title);
        this.setState({
            title: {
                text: value,
                ...this.validateTitle(value)
            }
        });
    }

    handleDescriptionChange(event) {
        const value = event.target.value;
        this.setState({
            description: {
                text: value
            }
        });
    }

    
    handleSummaryChange(event) {
        const value = event.target.value;
        this.setState({
            summary: {
                text: value
            }
        });
    }


    handleLinkChange(event) {
        const value = event.target.value;
        this.setState({
            link: {
                text: value
            }
        });
    }

    handleUrlChange(event) {
        const value = event.target.value;
        this.setState({
            url: {
                text: value
            }
        });
    }

    validateChoice = (choiceText) => {
     
            return {
                validateStatus: 'success',
                errorMsg: null
            }
        
    }




    isFormInvalid() {
        if(this.state.title.validateStatus !== 'success') {
            return true;
        }
    

    }

    render() {
        const choiceViews = [];
        this.state.choices.forEach((choice, index) => {
            choiceViews.push(<PollChoice key='1' choice={choice} choiceNumber={index} />);
         
        });

        return (
            <div className="new-poll-container">
                <h1 className="page-title">Create your news feed</h1>
                <div className="new-poll-content">
                    <Form onSubmit={this.handleSubmit} className="create-poll-form">
                     
                        <FormItem className="poll-form-row"  validateStatus={this.state.title.validateStatus}
                            help={this.state.title.errorMsg} >
                        <TextArea 
                            placeholder="Enter your title news here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "title"
                            value = {this.state.title.text}
                            onChange = {this.handleTitleChange} />
                        </FormItem>


                           <FormItem className="poll-form-row">
                        <TextArea 
                            placeholder="Enter your description here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "description"
                            value = {this.state.description.text}
                            onChange = {this.handleDescriptionChange} />
                        </FormItem>



                    <FormItem className="poll-form-row">
                        <TextArea 
                            placeholder="Enter summary here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "summary"
                            value = {this.state.summary.text}
                            onChange = {this.handleSummaryChange}
                             />
                        </FormItem>


   <FormItem className="poll-form-row">
                        <TextArea 
                            placeholder="Enter link here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "link"
                            value = {this.state.link.text}
                            onChange = {this.handleLinkChange} 
                            />
                        </FormItem>


   <FormItem className="poll-form-row">
                        <TextArea 
                            placeholder="Enter url here"
                            style = {{ fontSize: '16px' }} 
                            autosize={{ minRows: 3, maxRows: 6 }} 
                            name = "url"
                            value = {this.state.url.text}
                            onChange = {this.handleUrlChange} 
                            />
                        </FormItem>


                        {choiceViews}
                    
                        <FormItem className="poll-form-row">
                            <Button type="primary" 
                                htmlType="submit" 
                                size="large" 
                                disabled={this.isFormInvalid()}
                                className="create-poll-form-button">Create News Feed</Button>
                        </FormItem>
                    </Form>
                </div>    
            </div>
        );
    }
}

function PollChoice(props) {
    return (
        <FormItem validateStatus={props.choice.validateStatus}
        help={props.choice.errorMsg} className="poll-form-row">
         
        </FormItem>
    );
}


export default NewPoll;