package com.example.polls.model;

import com.example.polls.model.audit.UserDateAudit;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by rajeevkumarsingh on 20/11/17.
 */
@Entity
@Table(name = "polls")
public class Poll extends UserDateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="poll_id")
    private Long id;

//    @NotBlank
//    @Size(max = 140)
//    private String question;

    @ManyToOne()
    @JoinColumn(name="fk_feed")
    private Feed feed;

    @Column(name="title", nullable = false)
    String title;

    @Column(name="description", nullable = false, length = 70000)
    String description;

    @Column(name="link", nullable = false)
    String link;

    @Column(name="author", nullable = false)
    String author;

    @Column(name="guid", nullable = false)
    String guid;

    @Column(name="url", nullable = false)
    String url;

    @Column(name="summary", nullable = false, length =  70000)
    String summary;

    @Column(name="createdDate", nullable = false)
    String createdDate;

    @Column(name="imageSavedUrl", nullable = false)
    String imageSavedUrl;


//    @OneToMany(
//            mappedBy = "poll",
//            cascade = CascadeType.ALL,
//            fetch = FetchType.EAGER
//    )

//    @Size(min = 2, max = 6)
//    @Fetch(FetchMode.SELECT)
//    @BatchSize(size = 30)
@OneToMany( cascade = CascadeType.ALL)
    private List<Choice> choices = new ArrayList<>();

    @NotNull
    private Instant expirationDateTime;


    public Poll(){}


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Feed getFeed() {
        return feed;
    }

    public void setFeed(Feed feed) {
        this.feed = feed;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getImageSavedUrl() {
        return imageSavedUrl;
    }

    public void setImageSavedUrl(String imageSavedUrl) {
        this.imageSavedUrl = imageSavedUrl;
    }

    //    public String getQuestion() {
//        return question;
//    }
//
//    public void setQuestion(String question) {
//        this.question = question;
//    }

    public List<Choice> getChoices() {
        return choices;
    }

    public void setChoices(List<Choice> choices) {
        this.choices = choices;
    }

    public Instant getExpirationDateTime() {
        return expirationDateTime;
    }

    public void setExpirationDateTime(Instant expirationDateTime) {
        this.expirationDateTime = expirationDateTime;
    }

    public void addChoice(Choice choice) {
        choices.add(choice);
        choice.setPoll(this);
    }

    public void removeChoice(Choice choice) {
        choices.remove(choice);
        choice.setPoll(null);
    }
}
