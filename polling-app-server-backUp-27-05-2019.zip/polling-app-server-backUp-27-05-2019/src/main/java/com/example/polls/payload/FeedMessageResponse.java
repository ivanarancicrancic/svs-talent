package com.example.polls.payload;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;

public class FeedMessageResponse {

    private Long id;
    private String title;
    private String description;
    private String link;
    private String author;
    private String guid;
    private String summary;
    private Instant createdDate;
    private String imageSavedUrl;

//    @JsonInclude(JsonInclude.Include.NON_NULL)
//    private Long selectedChoice;
//    private Long totalVotes;
//
    public  FeedMessageResponse(){}

    public FeedMessageResponse(Long id, String title, String description, String link, String author, String guid, String summary, Instant createdDate, String imageSavedUrl) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.link = link;
        this.author = author;
        this.guid = guid;
        this.summary = summary;
        this.createdDate = createdDate;
        this.imageSavedUrl = imageSavedUrl;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Instant getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Instant createdDate) {
        this.createdDate = createdDate;
    }

    public String getImageSavedUrl() {
        return imageSavedUrl;
    }

    public void setImageSavedUrl(String imageSavedUrl) {
        this.imageSavedUrl = imageSavedUrl;
    }
}
