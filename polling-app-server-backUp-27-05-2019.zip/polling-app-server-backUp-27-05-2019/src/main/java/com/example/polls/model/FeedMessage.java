package com.example.polls.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "feedmessages")
public class FeedMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne()
    @JoinColumn(name="fk_feed")
    private Feed feed;

    @Column(name="title", nullable = false)
    String title;

    @Column(name="description", nullable = false, length = 70000)
    String description;

    @Column(name="link", nullable = false)
    String link;

    @Column(name="author", nullable = false)
    String author;

    @Column(name="guid", nullable = false)
    String guid;

    @Column(name="url", nullable = false)
    String url;

    @Column(name="summary", nullable = false, length =  70000)
    String summary;

    @Column(name="createdDate", nullable = false)
    String createdDate;

    @Column(name="imageSavedUrl", nullable = false)
    String imageSavedUrl;



    public FeedMessage(){}


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getImageSavedUrl() {
        return imageSavedUrl;
    }

    public void setImageSavedUrl(String imageSavedUrl) {
        this.imageSavedUrl = imageSavedUrl;
    }

    @Override
    public String toString() {
        return "FeedMessage [title=" + title + ", description=" + description
                + ", link=" + link + ", author=" + author + ", guid=" + guid
                + "]";
    }


}
