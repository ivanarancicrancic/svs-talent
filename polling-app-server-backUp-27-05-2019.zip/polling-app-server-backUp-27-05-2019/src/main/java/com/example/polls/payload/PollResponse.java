package com.example.polls.payload;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.time.Instant;
import java.util.List;

public class PollResponse {
    private Long id;
//    private String question;
    private List<ChoiceResponse> choices;
    private UserSummary createdBy;
//    private Instant creationDateTime;
//    private Instant expirationDateTime;
//    private Boolean isExpired;

    private String title;

    private String description;

    private String link;

    private String author;

    private String guid;

    private String url;

    private String summary;

    private String createdDate;

    private String imageSavedUrl;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long selectedChoice;
    private Long totalVotes;

//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getQuestion() {
//        return question;
//    }
//
//    public void setQuestion(String question) {
//        this.question = question;
//    }
//
    public List<ChoiceResponse> getChoices() {
        return choices;
    }

    public void setChoices(List<ChoiceResponse> choices) {
        this.choices = choices;
    }
//

//
//
//    public Instant getCreationDateTime() {
//        return creationDateTime;
//    }
//
//    public void setCreationDateTime(Instant creationDateTime) {
//        this.creationDateTime = creationDateTime;
//    }
//
//    public Instant getExpirationDateTime() {
//        return expirationDateTime;
//    }
//
//    public void setExpirationDateTime(Instant expirationDateTime) {
//        this.expirationDateTime = expirationDateTime;
//    }
//
//    public Boolean getExpired() {
//        return isExpired;
//    }
//
//    public void setExpired(Boolean expired) {
//        isExpired = expired;
//    }
//
    public Long getSelectedChoice() {
        return selectedChoice;
    }

    public void setSelectedChoice(Long selectedChoice) {
        this.selectedChoice = selectedChoice;
    }

    public Long getTotalVotes() {
        return totalVotes;
    }

    public void setTotalVotes(Long totalVotes) {
        this.totalVotes = totalVotes;
    }


    public PollResponse(){}
    public PollResponse(Long id, String title, String description, String link, String author, String guid, String url, String summary, String createdDate, String imageSavedUrl) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.link = link;
        this.author = author;
        this.guid = guid;
        this.url = url;
        this.summary = summary;
        this.createdDate = createdDate;
        this.imageSavedUrl = imageSavedUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getImageSavedUrl() {
        return imageSavedUrl;
    }

    public void setImageSavedUrl(String imageSavedUrl) {
        this.imageSavedUrl = imageSavedUrl;
    }


    public UserSummary getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(UserSummary createdBy) {
        this.createdBy = createdBy;
    }
}
