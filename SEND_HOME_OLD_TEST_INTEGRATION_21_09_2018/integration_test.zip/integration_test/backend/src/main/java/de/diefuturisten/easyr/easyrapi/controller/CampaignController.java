package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.converter.CampaignToCampaignCommand;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.model.request.*;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import de.diefuturisten.easyr.easyrapi.service.SphereContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;
import java.util.ArrayList;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@org.springframework.web.bind.annotation.CrossOrigin(origins = "http://localhost:3000")
public class CampaignController {

    @Autowired
    CampaignService campaignService;

    @Autowired
    SlideshowContentService slideShowContentService;

    @Autowired
    AudioContentService audioContentService;

    @Autowired
    MovieContentService movieContentService;

    @Autowired
    PanoramaContentService panoramaContentService;

    @Autowired
    SphereContentService sphereContentService;

    public CampaignController(CampaignService campaignService, SlideshowContentService slideShowContentService, AudioContentService audioContentService, MovieContentService movieContentService, PanoramaContentService panoramaContentService, SphereContentService sphereContentService) {
        this.campaignService = campaignService;
        this.slideShowContentService = slideShowContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
        this.panoramaContentService = panoramaContentService;
        this.sphereContentService = sphereContentService;
    }

    @GetMapping("/testCampaigns")
    @ResponseStatus(HttpStatus.OK)
    public List<de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand> getTestCampaigns() throws Exception
    {
        CampaignToCampaignCommand campaignToCampaignCommand = new CampaignToCampaignCommand();
        System.out.println("Entered /testCampaigns");
        List<Campaign> campaigns = new ArrayList<Campaign>();
//        List<de.diefuturisten.easyr.easyrapi.model.request.CampaignReturn> returns = new ArrayList<>();
//        de.diefuturisten.easyr.easyrapi.model.request.CampaignReturn campaignReturn = new de.diefuturisten.easyr.easyrapi.model.request.CampaignReturn();
        List<de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand> returns = new ArrayList<>();
        de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand campaignCommand = new de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand();
        try{
            campaigns = campaignService.getAllCampaigns();
            for(Campaign cc : campaigns){
//                campaignReturn.setId(cc.getId());
               campaignCommand = campaignToCampaignCommand.convert(cc);
                returns.add(campaignCommand);
                System.out.println("Campaign ID: " + cc.getId());
            }
            return returns;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_LIST)
    public List<Campaign> getCampaigns() throws Exception
    {
        System.out.println("Entered /campaigns");
        List<Campaign> campaigns = new ArrayList<>();

        try{
            campaigns = campaignService.getAllCampaigns();
             // CampaignListCommand campaignListCommand = new CampaignListCommand(campaigns);
           // System.out.println("BEFORE RETURN: " + campaignListCommand.getCampaigns());
//            for(CampaignCommand cc : campaignListCommand.getCampaigns()){
//
//                System.out.println("Campaign ID: " + cc.getId());
//            }
            return campaigns;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

        @PostMapping("/campaign/update")
    @ResponseStatus(HttpStatus.OK)
    public CampaignReturn saveOrUpdate(@RequestBody CampaignReturn campaign) throws  Exception{
        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID: " + campaign.getId());
        CampaignReturn savedCampaign = new CampaignReturn(campaign.getId());
        System.out.println("Id of campaign updated:" + savedCampaign.getId());
        try{
            return campaign;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

//    @GetMapping("/campaign/{id}/slideshows")
//    @ResponseStatus(HttpStatus.OK)
//    public SlideshowListEntry getSlideshowsByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/slideshows");
//        List<SlideshowContent> slideshows = null;
//        List<SlideshowContent> allSlideshows = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allSlideshows = slideShowContentService.findAllSlides();
//            for(SlideshowContent slideshowContent: allSlideshows)
//            {
//                if(slideshowContent.getCampaign().getId() == new Long(id))
//                {
//                    slideshows.add(slideshowContent);
//                }
//            }
//            return new SlideshowListEntry(slideshows);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//
//    @GetMapping("/campaign/{id}/audios")
//    @ResponseStatus(HttpStatus.OK)
//    public AudioContentList getAudiosByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/audios");
//        List<AudioContent> audios = null;
//        List<AudioContent> allAudios = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allAudios= audioContentService.findAllAudios();
//            for(AudioContent audioContent: allAudios)
//            {
//                if(audioContent.getCampaign().getId() == new Long(id))
//                {
//                   audios.add(audioContent);
//                }
//            }
//            return new AudioContentList(audios);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//@GetMapping("/campaign/{id}/movies")
//    @ResponseStatus(HttpStatus.OK)
//    public MovieContentList getMoviesByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/movies");
//        List<MovieContent> movies = null;
//        List<MovieContent> allMovies = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allMovies= movieContentService.findAllMovies();
//            for(MovieContent movieContent: allMovies)
//            {
//                if(movieContent.getCampaign().getId() == new Long(id))
//                {
//                    movies.add(movieContent);
//                }
//            }
//            return new MovieContentList(movies);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//
//    @GetMapping("/campaign/{id}/panoramas")
//    @ResponseStatus(HttpStatus.OK)
//    public PanoramaContentList getPanoramasByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/panoramas");
//        List<PanoramaContent> panoramas = null;
//        List<PanoramaContent> allPanoramas = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allPanoramas= panoramaContentService.findAllPanoramas();
//            for(PanoramaContent panoramaContent: allPanoramas)
//            {
//                if(panoramaContent.getCampaign().getId() == new Long(id))
//
//                {
//                    panoramas.add(panoramaContent);
//                }
//            }
//            return new PanoramaContentList(panoramas);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//    @GetMapping("/campaign/{id}/spheres")
//    @ResponseStatus(HttpStatus.OK)
//    public SphereContentList getSpheresByCampaign(@PathVariable String id) throws Exception
//    {
//        System.out.println("Entered /campaign/{id}/sphere");
//        List<SphereContent> spheres = null;
//        List<SphereContent> allSpheres = null;
//        List<Content> contents = null;
//        try{
//            contents = campaignService.findById(new Long(id)).getContents();
//            allSpheres= sphereContentService.findAllSpheres();
//            for(SphereContent sphereContent: allSpheres)
//            {
//                if(sphereContent.getCampaign().getId() == new Long(id))
//
//                {
//                    spheres.add(sphereContent);
//                }
//            }
//            return new SphereContentList(spheres);
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//
//
//
//    @GetMapping("/campaign/show/{id}")
//    @ResponseStatus(HttpStatus.OK)
//    public CampaignCommand showById(@PathVariable String id) throws  Exception{
//        System.out.println("entered campaign/show/{id}");
//        try{
//            CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
//            return campaignCommand;
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//    @PostMapping("/campaign/create")
//    @ResponseStatus(HttpStatus.CREATED)
//    public Campaign createCampaign(@RequestBody Campaign campaignCommand) throws Exception{
//        System.out.println("BEFORE CREATING CAMPAIGN: " + campaignCommand.getTracker());
//
//
//        try{
//        Campaign createdCampaignCommand = campaignService.createCampaign(campaignCommand);
//        System.out.println("Id of campaign created:" + createdCampaignCommand.getId());
//            return createdCampaignCommand;
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//    @PutMapping("/campaign/update")
//    @ResponseStatus(HttpStatus.OK)
//    public Campaign saveOrUpdate(@RequestBody Campaign campaign) throws  Exception{
//        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID:" + campaign.getId());
//        Campaign savedCampaign = campaignService.updateCampaign(campaign);
//        System.out.println("Id of campaign updated:" + savedCampaign.getId());
//        System.out.println("Contents of campaign updated: ");
//        for(Content campaignContent1 : savedCampaign.getContents())
//            System.out.println("Content: " +  campaignContent1.getName());
//        try{
//            return campaign;
//
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//            throw e;
//        }
//    }
//
//    @GetMapping("campaign/{id}/delete")
//    @ResponseStatus(HttpStatus.OK)
//    public CampaignCommand deleteCampaign(@PathVariable String id){
//        System.out.println("Entered deleting campaign");
//        CampaignCommand campaignCommand =  campaignService.findById(new Long(id));
//        campaignService.deleteCampaign(Long.valueOf(id));
//        return campaignCommand;
//
//    }




}
