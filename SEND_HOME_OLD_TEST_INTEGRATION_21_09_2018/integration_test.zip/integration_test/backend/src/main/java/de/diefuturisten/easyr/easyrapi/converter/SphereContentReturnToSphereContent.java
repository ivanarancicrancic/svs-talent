package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.model.request.SphereContentReturn;
import org.springframework.core.convert.converter.Converter;

public class SphereContentReturnToSphereContent implements Converter<SphereContentReturn, SphereContent> {

    public SphereContentReturnToSphereContent(){}

    @Override
    public SphereContent convert(SphereContentReturn source) {
        SphereContent sphereContent = new SphereContent();
        sphereContent.setId(source.getId());
        sphereContent.setWeight(source.getWeight());
        sphereContent.setName(source.getName());
        sphereContent.setUrl(source.getUrl());
        return sphereContent;
    }

}
