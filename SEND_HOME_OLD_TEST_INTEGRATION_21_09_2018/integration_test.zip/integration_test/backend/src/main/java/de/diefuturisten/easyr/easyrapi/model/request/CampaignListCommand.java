package de.diefuturisten.easyr.easyrapi.model.request;


import java.util.List;

public class CampaignListCommand {

    List<CampaignCommand> campaigns;

    public List<CampaignCommand> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<CampaignCommand> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignListCommand(List<CampaignCommand> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignListCommand() {
    }

}
