package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowContentReturn;
import org.springframework.core.convert.converter.Converter;

public class SlideshowContentReturnToSlideshowContent implements Converter<SlideshowContentReturn, SlideshowContent> {

    public SlideshowContentReturnToSlideshowContent(){}

    @Override
    public SlideshowContent convert(SlideshowContentReturn source) {

        SlideshowContent slideshowContent = new SlideshowContent();
        slideshowContent.setId(source.getId());
        slideshowContent.setWeight(source.getWeight());
        slideshowContent.setName(source.getName());

        slideshowContent.setImages(null);

        slideshowContent.setPositionX(source.getPositionX());
        slideshowContent.setPositionY(source.getPositionY());
        slideshowContent.setPositionZ(source.getPositionZ());
        slideshowContent.setRotationX(source.getRotationX());
        slideshowContent.setRotationY(source.getRotationY());
        slideshowContent.setRotationZ(source.getRotationZ());

        slideshowContent.setScaleX(source.getScaleX());
        slideshowContent.setScaleY(source.getScaleY());
        slideshowContent.setScaleZ(source.getScaleZ());

        if(source.getRenderOnTrackingLost()=="true")
          slideshowContent.setRenderOnTrackingLost(true);
        else
          slideshowContent.setRenderOnTrackingLost(false);

        if(source.getExtendedTracking() == "true")
            slideshowContent.setExtendedTracking(true);
        else
            slideshowContent.setExtendedTracking(false);
        return  slideshowContent;
    }

}
