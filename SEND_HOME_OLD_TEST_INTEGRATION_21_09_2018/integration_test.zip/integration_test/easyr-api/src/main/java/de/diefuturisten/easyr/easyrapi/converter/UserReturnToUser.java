package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.UserReturn;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.core.convert.converter.Converter;

public class UserReturnToUser implements Converter<UserReturn, User> {

    public UserReturnToUser(){}

    @Override
    public User convert(UserReturn source) {

        User user= new User();

       user.setId(source.getId());
       user.setLanguage(source.getLanguage());
       user.setActive(source.isActive());
       user.setEmail(source.getEmail());
       user.setPassword(source.getPassword());
       user.setGender(source.isGender());
       user.setFirstname(source.getFirstname());
       user.setLastname(source.getLastname());
       user.setResetPasswordTokens(null);
       user.setRoles(null);
        return user;
    }
}
