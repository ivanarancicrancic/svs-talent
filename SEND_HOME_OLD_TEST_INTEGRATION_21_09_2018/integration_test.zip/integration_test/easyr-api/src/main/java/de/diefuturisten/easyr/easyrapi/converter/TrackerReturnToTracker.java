package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.TrackerReturn;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import org.springframework.core.convert.converter.Converter;

public class TrackerReturnToTracker implements Converter<TrackerReturn, Tracker> {

    public TrackerReturnToTracker(){}

    @Override
    public Tracker convert(TrackerReturn source) {
        Tracker tracker = new Tracker();
        tracker.setId(source.getId());
        tracker.setUrl(source.getUrl());
        tracker.setVuforiaId(source.getVuforiaId());
        return tracker;
    }


}
