package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.AudioContentReturn;
import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;

public class AudioContentReturnToAudioContent implements Converter<AudioContentReturn, AudioContent> {

    public AudioContentReturnToAudioContent(){}

    @Override
    public AudioContent convert(AudioContentReturn source) {
        de.diefuturisten.easyr.easyrapi.entity.content.AudioContent audioContent = new AudioContent();
        audioContent.setId(source.getId());
        audioContent.setWeight(source.getWeight());
        audioContent.setName(source.getName());
        audioContent.setUrl(source.getUrl());
        if(source.getRenderOnTrackingLost() == "true")
            audioContent.setRenderOnTrackingLost(true);
        else
            audioContent.setRenderOnTrackingLost(false);

        return audioContent;
    }
}
