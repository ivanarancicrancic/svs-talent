package de.diefuturisten.easyr.easyrapi.model.response;

public class SlideshowImageReturn {

    private long id;

    private int weight;

    public SlideshowImageReturn(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
