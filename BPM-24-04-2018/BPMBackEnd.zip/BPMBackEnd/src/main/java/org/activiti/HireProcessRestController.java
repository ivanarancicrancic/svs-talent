package org.activiti;

import Models.KreditniLinii;
import Models.UserByGroupId;
import com.google.gson.Gson;
import database.ProjectManager;
import org.activiti.engine.RuntimeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.web.bind.annotation.*;

import javax.persistence.*;
import javax.websocket.server.PathParam;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@RestController
public class HireProcessRestController {

    @Autowired
    private RuntimeService runtimeService;

    @Autowired
    private ApplicantRepository applicantRepository;

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/start-hire-process", method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public void startHireProcess(@RequestBody Map<String, String> data) {

        Applicant applicant = new Applicant(data.get("name"), data.get("email"), data.get("phoneNumber"));
        applicantRepository.save(applicant);

        Map<String, Object> vars = Collections.<String, Object>singletonMap("applicant", applicant);
        runtimeService.startProcessInstanceByKey("hireProcessWithJpa", vars);
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/GetUsersByGrpoupID/groupID={p_groupID}", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public String GetUsersByGrpoupID(@PathVariable("p_groupID") Integer p_groupID) throws Exception {
        //List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();

        System.out.println(" p_groupID "+p_groupID);
        List<UserByGroupId> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.GetUsersByGrpoupID(p_groupID);
            Gson gson = new Gson();
            System.out.println(t_items);
            t_tems_str = gson.toJson(t_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/kreditniLinii", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public String kreditniLinii() throws Exception {
        Applicant applicant = new Applicant("John Doe", "john@activiti.org", "12344");
        applicantRepository.save(applicant);
        System.out.println("init");
        System.out.println("Entered getPatientsAllCascade()");
        List<KreditniLinii> t_items = null;
        String t_tems_str  = null;
        try{
            ProjectManager projectManager= new ProjectManager();
            t_items = projectManager.getTreatmentItemsByTreatment();
            //StringBuffer sb = new StringBuffer();
            Gson gson = new Gson();
            System.out.println(gson.toJson(t_items));
            t_tems_str = gson.toJson(t_items);
//			if (t_items.isEmpty()){
//				 throw new WebApplicationException(404);
//			}
//			else
//			{
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

}