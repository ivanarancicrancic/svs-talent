package database;

import Models.KreditniLinii;
import Models.UserByGroupId;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProjectManager {

    public List<UserByGroupId> GetUsersByGrpoupID(Integer p_groupid) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<UserByGroupId> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetUsersByGrpoupID(connection, p_groupid);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<KreditniLinii> getTreatmentItemsByTreatment() throws Exception
    {
       // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<KreditniLinii> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.getTreatmentItemsByTreatment(connection);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }
}
