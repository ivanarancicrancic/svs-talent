package database;

import Models.KreditniLinii;
import Models.UserByGroupId;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Project {

    public List<UserByGroupId> GetUsersByGrpoupID(Connection connection,Integer p_groupid ) throws Exception
    {
        List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getusersbygroupid(?)");
            ps.setInt(1,p_groupid);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String fullname1 =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("fullname1 "+fullname1);
                //TreatmentItem p_eden = new TreatmentItem();
                UserByGroupId p_eden = new UserByGroupId(

                        rs.getString(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<KreditniLinii> getTreatmentItemsByTreatment(Connection connection) throws Exception
    {
        List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from get_KL()");

            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                //TreatmentItem p_eden = new TreatmentItem();
                KreditniLinii p_eden = new KreditniLinii(

                        rs.getString(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

                return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }
}
