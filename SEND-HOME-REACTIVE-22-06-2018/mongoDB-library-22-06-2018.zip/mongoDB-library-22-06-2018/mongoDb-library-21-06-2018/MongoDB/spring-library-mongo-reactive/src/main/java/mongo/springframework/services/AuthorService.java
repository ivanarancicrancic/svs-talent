package mongo.springframework.services;

import mongo.springframework.commands.AuthorCommand;
import reactor.core.publisher.Mono;

public interface AuthorService {

    Mono<AuthorCommand> findByBookIdAndAuthorId(String bookId, String authorId);

    Mono<AuthorCommand> saveAuthorCommand(AuthorCommand command);

    Mono<Void> deleteById(String bookId, String idToDelete);
}
