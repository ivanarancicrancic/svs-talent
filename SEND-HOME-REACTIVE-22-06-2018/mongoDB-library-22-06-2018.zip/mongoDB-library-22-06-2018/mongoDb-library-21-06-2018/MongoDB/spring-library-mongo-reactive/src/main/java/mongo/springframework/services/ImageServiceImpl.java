package mongo.springframework.services;

import lombok.extern.slf4j.Slf4j;
import mongo.springframework.model.Book;
import mongo.springframework.repositories.reactive.BookReactiveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Mono;

import java.io.IOException;

@Slf4j
@Service
public class ImageServiceImpl implements ImageService {

    private final BookReactiveRepository bookReactiveRepository;

    public ImageServiceImpl(BookReactiveRepository bookReactiveRepository) {
        this.bookReactiveRepository = bookReactiveRepository;
    }


    //non reactive
//    @Override
//    @Transactional
//    public void saveImageFile(String bookId, MultipartFile file) {
//
//        try {
//            Book book = bookReactiveRepository.findById(bookId).get();
//            Byte[] byteObjects = new Byte[file.getBytes().length];
//            int i = 0;
//
//            for (byte b : file.getBytes()){
//                byteObjects[i++] = b;
//            }
//
//            book.setImage(byteObjects);
//
//            bookRepository.save(book);
//        } catch (IOException e) {
//            System.out.println("Error!");
//            e.printStackTrace();
//        }
//    }

 //reactive
    @Override
    @Transactional
    public Mono<Void> saveImageFile(String bookId, MultipartFile file) {
        Mono<Book> bookMono = bookReactiveRepository.findById(bookId)
                .map(book -> {
                    Byte[] byteObjects = new Byte[0];
                    try {
                        byteObjects = new Byte[file.getBytes().length];

                        int i = 0;

                        for (byte b : file.getBytes()) {
                            byteObjects[i++] = b;
                        }

                        book.setImage(byteObjects);

                        return book;

                    } catch (IOException e) {
                        e.printStackTrace();
                        throw new RuntimeException(e);
                    }
                });

        bookReactiveRepository.save(bookMono.block()).block();
        return Mono.empty();

    }

}
