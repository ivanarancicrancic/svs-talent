package mongo.springframework.converters;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.model.Book;
import mongo.springframework.model.Category;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

@Component
public class BookToBookCommand implements Converter<Book, BookCommand>{

    private final CategoryToCategoryCommand categoryConveter;
    private final AuthorToAuthorCommand authorConverter;
    private final NotesToNotesCommand notesConverter;

    public BookToBookCommand(CategoryToCategoryCommand categoryConveter, AuthorToAuthorCommand authorConverter, NotesToNotesCommand notesConverter) {
        this.categoryConveter = categoryConveter;
        this.authorConverter = authorConverter;
        this.notesConverter = notesConverter;
    }

    @Synchronized
    @Nullable
    @Override
    public BookCommand convert(Book source) {
        if (source == null) {
            return null;
        }

        final BookCommand command = new BookCommand();
        command.setId(source.getId());
        command.setSize(source.getSize());
        command.setEvaluation(source.getEvaluation());
        command.setDescription(source.getDescription());
        command.setDifficulty(source.getDifficulty());
        command.setUrl(source.getUrl());
        command.setImage(source.getImage());
        command.setNotes(notesConverter.convert(source.getNotes()));

        if (source.getCategories() != null && source.getCategories().size() > 0){
            source.getCategories()
                    .forEach((Category category) -> command.getCategories().add(categoryConveter.convert(category)));
        }

        if (source.getAuthors() != null && source.getAuthors().size() > 0){
            source.getAuthors()
                    .forEach(author -> command.getAuthorCommands().add(authorConverter.convert(author)));
        }
        return command;
    }
}
