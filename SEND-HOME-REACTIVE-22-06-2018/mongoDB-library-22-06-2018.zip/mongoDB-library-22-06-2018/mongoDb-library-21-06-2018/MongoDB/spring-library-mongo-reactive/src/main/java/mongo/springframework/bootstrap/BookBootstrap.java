package mongo.springframework.bootstrap;

import mongo.springframework.repositories.BookRepository;
import mongo.springframework.repositories.CategoryRepository;
import lombok.extern.slf4j.Slf4j;
import mongo.springframework.model.*;
//import org.apache.commons.io.IOUtils;
//
//import org.apache.tomcat.util.http.fileupload.disk.DiskFileItem;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.commons.CommonsMultipartFile;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class BookBootstrap implements ApplicationListener<ContextRefreshedEvent> {

    private final CategoryRepository categoryRepository;
    private final BookRepository bookRepository;

    public BookBootstrap(CategoryRepository categoryRepository, BookRepository bookRepository) {
        this.categoryRepository = categoryRepository;
        this.bookRepository = bookRepository;
    }

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        loadCategories();
        bookRepository.saveAll(getBooks());
        System.out.println("Loading Data");
    }

    private void loadCategories(){
        Category cat1 = new Category();
        cat1.setDescription("Education");
        categoryRepository.save(cat1);

        Category cat2 = new Category();
        cat2.setDescription("Travel");
        categoryRepository.save(cat2);

        Category cat3 = new Category();
        cat3.setDescription("Health");
        categoryRepository.save(cat3);

        Category cat4 = new Category();
        cat4.setDescription("Medical");
        categoryRepository.save(cat4);
    }



    private List<Book> getBooks() {

        List<Book> books = new ArrayList<>(2);

        //get Categories
        Optional<Category> educationCategoryOptional = categoryRepository.findByDescription("Education");

        if(!educationCategoryOptional.isPresent()){
            throw new RuntimeException("Required Category Not Found");
        }

        Optional<Category> travelCategoryOptional = categoryRepository.findByDescription("Travel");

        if(!travelCategoryOptional.isPresent()){
            throw new RuntimeException("Required Category Not Found");
        }

        Category educationCategory = educationCategoryOptional.get();
        Category travelCategory = travelCategoryOptional.get();

        Book book = new Book();
        book.setDescription("Java Platform, Enterprise Edition - Perfect knowledge to get");
        book.setSize(500);
        book.setEvaluation(10);
        book.setDifficulty(Difficulty.HARD);
        Notes bookNotes = new Notes();
        bookNotes.setNotes("Enterprises today need to extend their reach, reduce their costs, and lower the\n" +
                "response times of their services to customers, employees, and suppliers.\n" +
                "Typically, applications that provide these services must combine existing\n" +
                "enterprise information systems (EISs) with new business functions that deliver\n" +
                "services to a broad range of users");

        book.setNotes(bookNotes);

        book.addAuthor(new Author("Linda", "DeMichiel"));
        book.addAuthor(new Author("Bill", "Shannon"));

        book.getCategories().add(educationCategory);
        book.getCategories().add(travelCategory);

        book.setUrl("https://javaee.github.io/javaee-spec/download/JavaEE8_Platform_Spec_FinalRelease.pdf");

        bookRepository.save(book);

        books.add(book);

        Book book2 = new Book();
        book2.setDescription("The Lord Of The Rings: The Fellowship of the Ring - Adventure Book");
        book2.setSize(658);
        book2.setEvaluation(10);
        book2.setDifficulty(Difficulty.MODERATE);

        Notes bookNotes2 = new Notes();
        bookNotes2.setNotes("The Lord of the Rings is an epic high fantasy novel written by English author and scholar J. R. R. Tolkien. The story began as a sequel to Tolkien's 1937 fantasy novel The Hobbit, but eventually developed into a much larger work. Written in stages between 1937 and 1949, The Lord of the Rings is one of the best-selling novels ever written, with over 150 million copies sold.");

        book2.setNotes(bookNotes2);

        book2.addAuthor(new Author("John","Ronald Reuel Tolkien"));

        book2.getCategories().add(travelCategory);

       book2.setUrl("http://ae-lib.org.ua/texts-c/tolkien__the_lord_of_the_rings_1__en.htm");

       bookRepository.save(book2);

       books.add(book2);
        return books;
    }
}
