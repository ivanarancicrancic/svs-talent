package mongo.springframework.services;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.converters.BookCommandToBook;
import mongo.springframework.converters.BookToBookCommand;
import mongo.springframework.model.Book;
import mongo.springframework.repositories.BookRepository;
import lombok.extern.slf4j.Slf4j;
import mongo.springframework.repositories.reactive.BookReactiveRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class BookServiceImpl implements BookService {

    //private final BookRepository bookRepository;
    private final BookReactiveRepository bookReactiveRepository;
    private final BookToBookCommand bookToBookCommand;
    private final BookCommandToBook bookCommandToBook;

    public BookServiceImpl(BookRepository bookRepository, BookToBookCommand bookToBookCommand, BookCommandToBook bookCommandToBook, BookReactiveRepository bookReactiveRepository) {
     //   this.bookRepository = bookRepository;
        this.bookToBookCommand = bookToBookCommand;
        this.bookCommandToBook = bookCommandToBook;
        this.bookReactiveRepository = bookReactiveRepository;
    }

//non reactive
//    @Override
//    public Set<Book> getBooks() {
//        System.out.println("Entered service getBooks()!");
//
//        Set<Book> bookSet = new HashSet<>();
//        bookRRepository.findAll().iterator().forEachRemaining(bookSet::add);
//        return bookSet;
//    }

    //reactive
    @Override
    public Flux<Book> getBooks() {
        System.out.println("Entered service getBooks()!");
        return bookReactiveRepository.findAll();
    }

    @Override
    public Flux<BookCommand> getBookCommands() {
        System.out.println("Entered service getBooksReactive()!");

       return bookReactiveRepository
               .findAll()
               .map(bookToBookCommand::convert);

    }

//    @Override
//    public Set<BookCommand> getBookCommands() {
//        System.out.println("Entered service getBookCommands()!");
//
//        Set<BookCommand> bookCommandSet = new HashSet<>();
//        Set<Book> bookSet = new HashSet<>();
//        bookRepository.findAll().iterator().forEachRemaining(bookSet::add);
//        for(Book book : bookSet)
//        {
//            bookCommandSet.add(bookToBookCommand.convert(book));
//        }
//        return bookCommandSet;
//    }


//    @Override
//    public Book findById(String id) {
//
//        Optional<Book> bookOptional = bookRepository.findById(id);
//
//        if (!bookOptional.isPresent()) {
//            throw new NotFoundException("Book Not Found. ID value: " + id );
//        }
//
//        return bookOptional.get();
//    }

    @Override
    public Mono<Book> findById(String id) {

        return bookReactiveRepository.findById(id);

    }


//    @Override
//    @Transactional
//    public BookCommand findCommandById(String id) {
//        return bookToBookCommand.convert(findById(id));
//    }

        @Override
    @Transactional
    public Mono<BookCommand> findCommandById(String id) {
            return bookReactiveRepository.findById(id)
                    .map(book -> {
                        BookCommand bookCommand = bookToBookCommand.convert(book);

                        bookCommand.getAuthorCommands().forEach(authorCommand -> {
                            authorCommand.setBookId(bookCommand.getId());
                        });

                        return bookCommand;
                    });
    }

//    @Override
//    @Transactional
//    public BookCommand saveBookCommand(BookCommand command) {
//        Book detachedBook = bookCommandToBook.convert(command);
//        Book savedBook = bookRepository.save(detachedBook);
//        System.out.println("Saved RecipeId:" + savedBook.getId());
//        return bookToBookCommand.convert(savedBook);
//    }

    @Override
    @Transactional
    public Mono<BookCommand> saveBookCommand(BookCommand command) {
        return bookReactiveRepository.save(bookCommandToBook.convert(command))
                .map(bookToBookCommand::convert);
    }

//    @Override
//    public void deleteById(String idToDelete) {
//        bookRepository.deleteById(idToDelete);
//    }


    @Override
    public Mono<Void> deleteById(String idToDelete) {
        bookReactiveRepository.deleteById(idToDelete).block();
        return Mono.empty();
    }
}
