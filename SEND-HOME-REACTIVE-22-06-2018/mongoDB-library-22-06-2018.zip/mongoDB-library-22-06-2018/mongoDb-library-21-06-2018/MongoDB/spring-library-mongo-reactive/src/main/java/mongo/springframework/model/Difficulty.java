package mongo.springframework.model;

public enum Difficulty {

    EASY, MODERATE, KIND_OF_HARD, HARD
}
