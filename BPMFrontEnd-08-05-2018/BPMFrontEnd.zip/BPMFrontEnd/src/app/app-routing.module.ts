import { NgModule } from '@angular/core';
import { RouterModule, Routes, RouterLinkActive } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { MainComponent } from './components/main/main.component';
import { NovoBaranjeComponent } from './components/novo-baranje/novo-baranje.component';
import { PregledNaBaranjaComponent } from './components/pregled-na-baranja/pregled-na-baranja.component';
import { AdministracijaComponent } from './components/administracija/administracija.component';
import { MonitoringComponent } from './components/monitoring/monitoring.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'najava', component: LoginComponent },
  {
    path: 'glavna', component: MainComponent,
    children: [
      { path: 'novoBaranje', component: NovoBaranjeComponent },
      { path: 'pregledNaBaranja', component: PregledNaBaranjaComponent },
      { path: 'realizacija', component: AdministracijaComponent },
      { path: 'monitoring', component: MonitoringComponent }
    ]
  }
]

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
