import { TestBed, inject } from '@angular/core/testing';

import { AdministracijaService } from './administracija.service';

describe('AdministracijaService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdministracijaService]
    });
  });

  it('should be created', inject([AdministracijaService], (service: AdministracijaService) => {
    expect(service).toBeTruthy();
  }));
});
