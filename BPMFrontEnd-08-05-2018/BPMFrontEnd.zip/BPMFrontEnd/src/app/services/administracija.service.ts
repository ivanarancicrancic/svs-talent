import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable()
export class AdministracijaService {

  serviceAPI = 'http://192.168.1.110:8080/';

  constructor(private http: HttpClient) { }

  getActiveLoans(id: number): Observable<any>{
    return this.http.get<any>(this.serviceAPI + 'getactiveloans/status=' + id);
  }
  


}
