import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/login.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {

  username: string = sessionStorage.getItem('username');

  formNames = [];
  formNames1 = [
    {
      ImeForma: 'Ново Барање',
      ImeForma2: 'novoBaranje',
      Icon: 'fa fa-file'
    },
    {
      ImeForma: 'Преглед на барања',
      ImeForma2: 'pregledNaBaranja',
      Icon: 'fa fa-list-alt'
    },
    {
      ImeForma: 'Реализација',
      ImeForma2: 'realizacija',
      Icon: 'fa fa-users'
    },
    {
      ImeForma: 'Мониторинг и наплата',
      ImeForma2: 'monitoring',
      Icon: 'fa fa-sticky-note'
    }
  ];

  constructor(private loginService: LoginService) { }

  ngOnInit() {
    this.getForms();
  }
  
  getForms(): void{
   this.loginService.getForms(this.username)
   .subscribe(data => {
     for(var i = 0; i < data.length; i++){
      for(var j = 0; j < this.formNames1.length; j++){
        if(this.formNames1[j].ImeForma2 == data[i].imeForma){
           this.formNames[i] = this.formNames1[j];
        }
      }
    } 
   });
  }


}
