import { Component, OnInit } from '@angular/core';
import { IMyDrpOptions, IMyDateRangeModel } from 'mydaterangepicker';
import { AdministracijaService } from '../../services/administracija.service';
declare var $;
@Component({
  selector: 'app-administracija',
  templateUrl: './administracija.component.html',
  styleUrls: ['./administracija.component.css']
})
export class AdministracijaComponent implements OnInit {

  username: string = sessionStorage.getItem('username');
  status: any;
  dosie: any;
  embg: any;
  datePicker: any;
  datePicker1: any;
  tableData: any;
  tableData1: any;
  formData: any;
  filesArray: any;

    myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };
  
  constructor(private administracija: AdministracijaService) { }

  ngOnInit() {
    this.setDate();
    this.getActiveLoans();
	this.status="";
	this.embg="";
	this.dosie="";
	
  }

  setDate(): void {
    let date = new Date();
    this.datePicker = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
    this.datePicker1 = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
	
  }

  getActiveLoans(): void {
    this.administracija.getActiveLoans(7)
      .subscribe(data => {
        console.log(data);
        this.tableData = data;
        this.tableData1 = data; 
   });
}
  getLoan(): void{
   console.log("Function called");
   console.log(this.embg);
   console.log(this.datePicker.beginDate.year);
   console.log(this.dosie);
   console.log(this.status);
   var _arr = new Array();
   console.log(this.datePicker.beginDate);
 var d1 = "";
   if(this.datePicker.beginDate.day<10)
   {
    d1 = "0" + this.datePicker.beginDate.day + "."; 
   }
   else 
   {
   d1= this.datePicker.beginDate.day + ".";
   }
   if(this.datePicker.beginDate.month<10)
   { 
   d1= d1 + "0" + this.datePicker.beginDate.month + ".";
   }
   else{
   d1= d1 + this.datePicker.beginDate.month + ".";
   }
   d1 = d1 + this.datePicker.beginDate.year;
	console.log(d1);
	
	var d2 = "";
   if(this.datePicker.endDate.day<10)
   {
    d2 = "0" + this.datePicker.endDate.day + "."; 
   }
   else 
   {
   d2= this.datePicker.endDate.day + ".";
   }
   if(this.datePicker.endDate.month<10)
   { 
   d2= d2 + "0" + this.datePicker.endDate.month + ".";
   }
   else{
   d2 = d2 + this.datePicker.endDate.month + ".";
   }
   d2 = d2 + this.datePicker.endDate.year;
	console.log(d2);
	
	
   this.tableData1.forEach(item => {
   console.log(item.requestdate);
		
	if(((item.brdosie == this.dosie) || (this.dosie == "")) && ((this.status == "")||((this.status == item.status))) && (item.datumposlednoplakanje > d1 && item.datumposlednoplakanje < d2))  
	{
	_arr.push(item);
	console.log('Item:', item.brdosie);
	}
	
	this.tableData=_arr;	
});

   
  
  }

  setStatus(t: string): void {
    if(t=="Неодредено")
	{ this.status="";
	}
	else{
	this.status = t;
        }
	}

 
}
