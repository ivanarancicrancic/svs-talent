import { Component, OnInit } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import { NovoBaranjeService } from '../../services/novo-baranje.service';
import { FormGroup, FormBuilder } from '@angular/forms';

declare var $;

@Component({
  selector: 'app-novo-baranje',
  templateUrl: './novo-baranje.component.html',
  styleUrls: ['./novo-baranje.component.css']
})
export class NovoBaranjeComponent implements OnInit {

  forma: FormGroup;
  username: string = sessionStorage.getItem('username');
  groupname: string = sessionStorage.getItem('groupname');
  datePicker: any;
  filesArray: Array<{tipDoc, nameDoc, zabeleshka}> = [];
  komintenti: any;
  kreditniLinii: any;
  tipKredit: any;
  licniPodatoci: any;
  lp: any;
  option1: boolean;
  option2: boolean;
  ekspozitura: string;
  shalterskiRabotnik: string;
  documents: any;
  documentName: string;
  z: string;
  groupOfUsers: any;
  
  date: Date = new Date;
  name = sessionStorage.getItem('name');
  comment: string;
  rows: Array<{date, name, comment }> = [];

  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };


  constructor(private novoBaranje: NovoBaranjeService, private fb: FormBuilder) {
    this.forma = this.fb.group({
      "loanrequestid": [""],
        "loantypeid": [""],
        "client_embg": [""],
        "requestdate": [""],
        "broj_dosie": [""],
        "tip_komintent": [""],
        "org_ime": [""],
        "org_address": [""],
        "org_oblik": [""],
        "br_vraboteni": [""],
        "org_tel": [""],
        "funckija": [""],
        "profesija": [""],
        "strucna_podgotovka": [""],
        "vkupen_staz": [""],
        "staz_vo_firma": [""],
        "lice_dohod_vo_stbbt": [""],
        "nedviznost": [""],
        "adresa_nedviznost": [""],
        "proceneta_vrednost": [""],
        "vozilo": [""],
        "broj_vozila": [""],
        "neto_plata": [""],
        "kirija_p": [""],
        "drugi_prihodi": [""],
        "vkupno_prihodi": [""],
        "pod_hipoteka": [""],
        "pol": [""],
        "pazarna_vrednost": [""],
        "tip_vozilo": [""],
        "kirija_r": [""],
        "osiguruvanje": [""],
        "ziovtni_trosoci": [""],
        "vkupno_rashodi": [""],
        "kreditna_linija": [""],
        "tip_kredit": [""],
        "baran_iznos": [""],
        "rok_otplata": [""],
        "obezbeduvanje": [""],
        "opis_obezbeduvanje": [""],
        "valuta": [""],
        "grejs_period": [""],
        "user_embg": [""],
        "aplicantName": [""],
        "aplicantPol": [""],
        "godininazivenjenaovaaadresa": [""],
        "zivealishte": [""],
        "brDeca": [""],
        "brachnaSostojba": [""],
        "mobtel": [""],
        "telefon": [""],
        "dokumentBroj": [""],
        "kontaktAdresa": [""],
        "aplicantEmbg": [""],
        "createdBy": [""],
        "ekspozitura": [""]
    })
   }

  ngOnInit() {
    this.setDate();
    this.getKomintent();
    this.getUsersByUsername();
    this.lp =   {
      "firstName": "",
      "lastName": "",
      "partija": "",
      "address": "",
      "bracnasostojba": "",
      "brojdeca": 0,
      "dokumentbroj": "",
      "godinaziveenjenaadresa": "",
      "kontaktadresa": "",
      "telefon": "",
      "mobtelefon": "",
      "zivealiste": ""
  }

  }

  setDate(): void{
    let date = new Date();
    this.datePicker = {date: {year: date.getFullYear(), month: date.getMonth()+1, day: date.getDate()}};
  }

  dodeliPodatoci(): void{
    $('#modal-default').modal('show');
    if(this.groupname == "Шалтерски Работник"){
      this.novoBaranje.getUsersByGroupID(2)
      .subscribe(data => {
        this.groupOfUsers = data;
      });
    }
  }

  onChange(event: any) {
    let file = [].slice.call(event.target.files);
    let files = file.map(f => f.name);
    this.filesArray.push({tipDoc: this.documentName, nameDoc: files, zabeleshka: this.z});
  }

  getKomintent(): void{
   this.novoBaranje.getClients()
   .subscribe(data => {
     this.komintenti = data;
   });
  }

  getKreditniLinii(id:number){
    this.novoBaranje.getKreditniLinii(id)
    .subscribe(data => {
      this.kreditniLinii = data;
    });
  }

  getTipKredit(id:number){
    this.novoBaranje.getTipKredit(id)
    .subscribe(data => {
      console.log(data);
      this.tipKredit = data;
    });
  }

  getLicniPodatoci(id:number){
    this.novoBaranje.getLicniPodatoci(id)
    .subscribe(data => {
      this.licniPodatoci = data;
      this.lp = this.licniPodatoci[0];
      if(this.lp.pol = "М"){ 
      this.option1 = true;
      this.option2 = false;
    }
      else{
      this.option2 = true;
      this.option1 = false;
      }
    });
  }

  getUsersByUsername(){
    this.novoBaranje.getUsersByUsername(this.username)
    .subscribe(data => {
      this.ekspozitura = data[0].branchofficename;
      this.shalterskiRabotnik = data[0].firstName + " " + data[0].lastName;
      sessionStorage.setItem("name", this.shalterskiRabotnik);
    });
  }

  getDocuments(id:number){
    this.novoBaranje.getDocuments(id)
    .subscribe(data => {
      console.log(data);
      this.documents = data;
    });
  }

  getDocumentNameById(id:number){
    this.novoBaranje.getDocumentNameById(id)
    .subscribe(data => {
      this.documentName = data[0].documentName;
    });
  }

  buttonClicked(){
    this.rows.push( {date: this.date, name: this.name, comment: this.comment } );
    this.date = new Date();
    this.name = sessionStorage.getItem('name');
    this.comment = null;
  }

  postFormData() {
    console.log(this.forma.value);
    this.novoBaranje.postFormData(this.forma.value)
    .subscribe(data => {
      console.log(data);
    });
  }
  
}
