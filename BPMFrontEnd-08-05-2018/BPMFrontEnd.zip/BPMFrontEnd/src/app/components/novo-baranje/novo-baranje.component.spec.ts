import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NovoBaranjeComponent } from './novo-baranje.component';

describe('NovoBaranjeComponent', () => {
  let component: NovoBaranjeComponent;
  let fixture: ComponentFixture<NovoBaranjeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NovoBaranjeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NovoBaranjeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
