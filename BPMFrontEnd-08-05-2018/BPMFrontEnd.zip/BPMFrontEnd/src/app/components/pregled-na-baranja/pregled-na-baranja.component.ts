import { Component, OnInit } from '@angular/core';
import { IMyDrpOptions, IMyDateRangeModel } from 'mydaterangepicker';
import { PregledNaBaranjaService } from '../../services/pregled-na-baranja.service';
import { FormGroup, FormBuilder } from '@angular/forms';
declare var $;
@Component({
  selector: 'app-pregled-na-baranja',
  templateUrl: './pregled-na-baranja.component.html',
  styleUrls: ['./pregled-na-baranja.component.css']
})
export class PregledNaBaranjaComponent implements OnInit {
  
  forma: FormGroup;
  username: string = sessionStorage.getItem('username');
  status: any;
  dosie: any;
  embg: any;
  datePicker: any;
  datePicker1: any;
  tableData: any;
  tableData1: any;
  formData: any;
  filesArray: any;

  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'dd.mm.yyyy',
  };

  datum_vreme: Date = new Date;
  lice: string = sessionStorage.getItem('name');
  comment: string;
  commentsArray: Array<{datum_vreme, lice, comment }> = [];

  constructor(private pregledNaBaranja: PregledNaBaranjaService, private fb: FormBuilder) {
    this.forma = this.fb.group({
      "loanrequestid": [""],
        "loantypeid": [""],
        "client_embg": [""],
        "requestdate": [""],
        "broj_dosie": [""],
        "tip_komintent": [""],
        "org_ime": [""],
        "org_address": [""],
        "org_oblik": [""],
        "br_vraboteni": [""],
        "org_tel": [""],
        "funckija": [""],
        "profesija": [""],
        "strucna_podgotovka": [""],
        "vkupen_staz": [""],
        "staz_vo_firma": [""],
        "lice_dohod_vo_stbbt": [""],
        "nedviznost": [""],
        "adresa_nedviznost": [""],
        "proceneta_vrednost": [""],
        "vozilo": [""],
        "broj_vozila": [""],
        "neto_plata": [""],
        "kirija_p": [""],
        "drugi_prihodi": [""],
        "vkupno_prihodi": [""],
        "pod_hipoteka": [""],
        "pol": [""],
        "pazarna_vrednost": [""],
        "tip_vozilo": [""],
        "kirija_r": [""],
        "osiguruvanje": [""],
        "ziovtni_trosoci": [""],
        "vkupno_rashodi": [""],
        "kreditna_linija": [""],
        "tip_kredit": [""],
        "baran_iznos": [""],
        "rok_otplata": [""],
        "obezbeduvanje": [""],
        "opis_obezbeduvanje": [""],
        "valuta": [""],
        "grejs_period": [""],
        "user_embg": [""],
        "aplicantName": [""],
        "aplicantPol": [""],
        "godininazivenjenaovaaadresa": [""],
        "zivealishte": [""],
        "brDeca": [""],
        "brachnaSostojba": [""],
        "mobtel": [""],
        "telefon": [""],
        "dokumentBroj": [""],
        "kontaktAdresa": [""],
        "aplicantEmbg": [""],
        "createdBy": [""],
        "ekspozitura": [""]
    });
   }

  ngOnInit() {
    this.setDate();
    this.getLoanR();
	this.status="";
	this.embg="";
	this.dosie="";
	
  }

  setDate(): void {
    let date = new Date();
    this.datePicker = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
    this.datePicker1 = {
      beginDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: 1 },
      endDate: { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() }
    };
	
  }

  getLoanR(): void {
    this.pregledNaBaranja.getLoanRequest(this.username)
      .subscribe(data => {
        console.log(data);
        this.tableData = data;
        this.tableData1 = data;
        if (data.grejs_period == false) {
          this.tableData.grejs_period = "Нема";
        }
      });
  }

    getLoan(): void{
   console.log("Function called");
   console.log(this.embg);
   console.log(this.datePicker.beginDate.year);
   console.log(this.dosie);
   console.log(this.status);
   var _arr = new Array();
   console.log(this.datePicker.beginDate);
   var d1 = "";
   if(this.datePicker.beginDate.day<10)
   {
    d1 = "0" + this.datePicker.beginDate.day + "."; 
   }
   else 
   {
   d1= this.datePicker.beginDate.day + ".";
   }
   if(this.datePicker.beginDate.month<10)
   { 
   d1= d1 + "0" + this.datePicker.beginDate.month + ".";
   }
   else{
   d1= d1 + this.datePicker.beginDate.month + ".";
   }
   d1 = d1 + this.datePicker.beginDate.year;
	console.log(d1);
	
	var d2 = "";
   if(this.datePicker.endDate.day<10)
   {
    d2 = "0" + this.datePicker.endDate.day + "."; 
   }
   else 
   {
   d2= this.datePicker.endDate.day + ".";
   }
   if(this.datePicker.endDate.month<10)
   { 
   d2= d2 + "0" + this.datePicker.endDate.month + ".";
   }
   else{
   d2 = d2 + this.datePicker.endDate.month + ".";
   }
   d2 = d2 + this.datePicker.endDate.year;
	console.log(d2);
	
	
   this.tableData1.forEach(item => {
   console.log(item.requestdate);
		
	
	if(((item.broj_dosie == this.dosie)|| (this.dosie == "")) && ((this.status == "")||((this.status == "Во процес" && item.status == "се процесира") || (this.status == "Одобрено" && item.status == "одобрено") || (this.status == "Вратено на доработка" && item.status == "вратено на доработка"))) && (item.requestdate > d1 && item.requestdate < d2) && (this.embg == "" || this.embg == item.client_embg))  
	{
	_arr.push(item);
	console.log('Item:', item.broj_dosie);
	}
	
	this.tableData=_arr;	
});
   
  
  }

  setStatus(t: string): void {
    if(t=="Неодредено")
	{ this.status="";
	}
	else{
	this.status = t;
        }
	}

  showForm(id: number) {
    $('#modal-default').modal('show');
    this.pregledNaBaranja.getLoanRequestsDetailsById(id)
      .subscribe(data => {
        this.formData = data;
        this.forma.patchValue({
          loanrequestid: data[0].loanrequestid,
          loantypeid: data[0].loantypeid,
          client_embg: data[0].client_embg,
          requestdate: data[0].requestdate,
          broj_dosie: data[0].broj_dosie,
          tip_komintent: data[0].tip_komintent,
          org_ime: data[0].org_ime,
          org_address: data[0].org_address,
          org_oblik: data[0].org_oblik,
          br_vraboteni: data[0].br_vraboteni,
          org_tel: data[0].org_tel,
          funckija: data[0].funckija,
          profesija: data[0].profesija,
          strucna_podgotovka: data[0].strucna_podgotovka,
          vkupen_staz: data[0].vkupen_staz,
          staz_vo_firma: data[0].staz_vo_firma,
          lice_dohod_vo_stbbt: data[0].lice_dohod_vo_stbbt,
          nedviznost: data[0].nedviznost,
          adresa_nedviznost: data[0].adresa_nedviznost,
          proceneta_vrednost: data[0].proceneta_vrednost,
          vozilo: data[0].vozilo,
          broj_vozila: data[0].broj_vozila,
          neto_plata: data[0].neto_plata,
          kirija_p: data[0].kirija_p,
          drugi_prihodi: data[0].drugi_prihodi,
          vkupno_prihodi: data[0].vkupno_prihodi,
          pod_hipoteka: data[0].pod_hipoteka,
          pol: data[0].pol,
          pazarna_vrednost: data[0].pazarna_vrednost,
          tip_vozilo: data[0].tip_vozilo,
          kirija_r: data[0].kirija_r,
          osiguruvanje: data[0].osiguruvanje,
          ziovtni_trosoci: data[0].ziovtni_trosoci,
          vkupno_rashodi: data[0].vkupno_rashodi,
          kreditna_linija: data[0].kreditna_linija,
          tip_kredit: data[0].tip_kredit,
          baran_iznos: data[0].baran_iznos,
          rok_otplata: data[0].rok_otplata,
          obezbeduvanje: data[0].obezbeduvanje,
          opis_obezbeduvanje: data[0].opis_obezbeduvanje,
          valuta: data[0].valuta,
          grejs_period: data[0].grejs_period,
          user_embg: data[0].user_embg,
          aplicantName: data[0].aplicantName,
          aplicantPol: data[0].aplicantPol,
          godininazivenjenaovaaadresa: data[0].godininazivenjenaovaaadresa,
          zivealishte: data[0].zivealishte,
          brDeca: data[0].brDeca,
          brachnaSostojba: data[0].brachnaSostojba,
          mobtel: data[0].mobtel,
          telefon: data[0].telefon,
          dokumentBroj: data[0].dokumentBroj,
          kontaktAdresa: data[0].kontaktAdresa,
          aplicantEmbg: data[0].aplicantEmbg,
          createdBy: data[0].createdBy,
          ekspozitura: data[0].ekspozitura
        });
      });

      this.pregledNaBaranja.getAttachedDocumentsForLoanRequestId(id)
      .subscribe(data => {
        this.filesArray = data;
      });

      this.pregledNaBaranja.getCommentsForLoanRequestId(id)
      .subscribe(data => {
        this.commentsArray = data;
      });
  }

  buttonClicked(){
    this.commentsArray.push( {datum_vreme: this.datum_vreme, lice: this.lice, comment: this.comment } );
    this.datum_vreme = new Date();
    this.lice = sessionStorage.getItem('name');
    this.comment = null;
  }

}
