import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../../services/login.service';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { NovoBaranjeService } from '../../services/novo-baranje.service';
declare var $;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: FormGroup;
  userN: string;
  formNames: any;
  najavenKorisnikIme: string;

  constructor(private loginService: LoginService,  private router: Router, private fb: FormBuilder, private novoBaranje: NovoBaranjeService) { 
    this.user = fb.group({
      'username': [''],
      'password': ['']
    });
  }

  ngOnInit() {
  }

  getUser() {
    this.loginService.getUser(this.user.value)
    .subscribe(data => {
     if(data.status == 1){
     console.log(data);
      sessionStorage.setItem('username', this.user.value.username);
      this.userN = sessionStorage.getItem('username');  
      
      this.loginService.getForms(this.userN)
      .subscribe(dataa => {
        this.formNames = dataa;
        let u = this.formNames[0].imeForma;
        this.router.navigate(['/glavna', u]);
        
      });     
     }else{
      $('#modal-default').modal('show');
     }
     sessionStorage.setItem('groupname', data.groupName);
    });
    this.novoBaranje.getUsersByUsername(this.user.value.username)
    .subscribe(data => {
      this.najavenKorisnikIme = data[0].firstName + " " + data[0].lastName;
      sessionStorage.setItem("name", this.najavenKorisnikIme);
    });
  }



}
