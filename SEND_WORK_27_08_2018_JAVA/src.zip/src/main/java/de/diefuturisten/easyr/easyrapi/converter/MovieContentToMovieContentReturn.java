package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.model.request.MovieContentReturn;
import org.springframework.core.convert.converter.Converter;

public class MovieContentToMovieContentReturn  implements Converter<MovieContent, MovieContentReturn> {

    public MovieContentToMovieContentReturn(){}


    @Override
    public MovieContentReturn convert(MovieContent source) {

        MovieContentReturn movieContentReturn = new MovieContentReturn();

        movieContentReturn.setId(source.getId());

        movieContentReturn.setWeight(source.getWeight());

        movieContentReturn.setName(source.getName());

//        movieContentReturn.setType(null);
        movieContentReturn.setUrl(source.getUrl());

        if(source.isDownload()== true)
            movieContentReturn.setDownload("true");
        else
            movieContentReturn.setDownload("false");

        if(source.isSeekbar() == true)
            movieContentReturn.setSeekbar("true");
        else
            movieContentReturn.setSeekbar("false");

        movieContentReturn.setPositionX(source.getPositionX());
        movieContentReturn.setPositionY(source.getPositionY());
        movieContentReturn.setPositionZ(source.getPositionZ());
        movieContentReturn.setRotationX(source.getRotationX());
        movieContentReturn.setRotationY(source.getRotationY());
        movieContentReturn.setRotationZ(source.getRotationZ());

        movieContentReturn.setScaleX(source.getScaleX());
        movieContentReturn.setScaleY(source.getScaleY());
        movieContentReturn.setScaleZ(source.getScaleZ());

        if(source.isRenderOnTrackingLost() == true)
            movieContentReturn.setRenderOnTrackingLost("true");
        else
            movieContentReturn.setRenderOnTrackingLost("false");

        if(source.isExtendedTracking() == true)
            movieContentReturn.setExtendedTracking("true");
        else
            movieContentReturn.setExtendedTracking("false");

        return movieContentReturn;
    }

}
