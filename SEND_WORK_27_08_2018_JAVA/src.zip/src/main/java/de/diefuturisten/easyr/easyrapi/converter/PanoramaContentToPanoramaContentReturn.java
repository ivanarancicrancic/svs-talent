package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.model.request.PanoramaContentReturn;
import org.springframework.core.convert.converter.Converter;

public class PanoramaContentToPanoramaContentReturn implements Converter<PanoramaContent, PanoramaContentReturn> {

    public PanoramaContentToPanoramaContentReturn(){}


    @Override
    public PanoramaContentReturn convert(PanoramaContent source) {

        PanoramaContentReturn panoramaContentReturn = new PanoramaContentReturn();

        panoramaContentReturn.setId(source.getId());

        panoramaContentReturn.setWeight(source.getWeight());

        panoramaContentReturn.setName(source.getName());

        panoramaContentReturn.setType(null);
        panoramaContentReturn.setUrl(source.getUrl());
       return  panoramaContentReturn;
    }

    }
