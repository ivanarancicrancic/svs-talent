package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.model.request.SignedUploadURLResponse;
import de.diefuturisten.easyr.easyrapi.service.S3Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("s3/")

public class UploadController {

    private S3Service s3Service;

    public UploadController(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    @RequestMapping(value = "sign/", method = RequestMethod.POST)

    public SignedUploadURLResponse getSignedUploadURL(@RequestParam("objectName") String objectName, @RequestParam("contentType") String contentType, @RequestParam("path") String path){
        return new SignedUploadURLResponse(s3Service.signUploadRequest().toString());
    }

}
