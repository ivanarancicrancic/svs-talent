import React from 'react';

import MenuButton from './MenuButton';

var bgColors = { "Default": "#81b71a",
                    "Blue": "#00B1E1",
                    "Cyan": "#37BC9B",
                    "Green": "#8CC152",
                    "Red": "#E9573F",
                    "Yellow": "#F6BB42",
};

interface UserResult {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  mdbid: string;
  country_code: string;
  username: string;
  gender: number;
}

interface UserListProps {
}

interface UserListState {
  users: Array<UserResult>;
  isLoading: boolean;
  
}

// Don't do it like this. This is for example only
class User extends React.Component<UserListProps, UserListState> {
	constructor(props: UserListProps) {
    super(props);

    this.state = {
      users: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: ""
    };
  
  this.handleChangeGetUserById_userID = this.handleChangeGetUserById_userID.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChangeAddRoleToUser_roleID = this.handleChangeAddRoleToUser_roleID.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChangeAddRoleToUser_userID = this.handleChangeAddRoleToUser_userID.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);

	}
  
  handleChangeGetUserById_userID(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmit(event) {
    event.preventDefault();

    fetch('http://localhost:8080/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_roleID(event) {
    this.setState({value2: event.target.value});
  }

  handleSubmit1(event) {
    alert('User id entered: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/getUserByID/userID=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_userID(event) {
	 this.setState({value1: event.target.value});
  }

  handleSubmit2(event) {
    alert('user_id: ' + this.state.value1 + ', role_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/addRoleToUser/user_id=' + this.state.value1 + '&role_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }

  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
	
	
  render() {
	   const {users, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
  
      <div className="container notificationsFrame" style={{
        backgroundColor: "#add8e6",
        borderRadius: "2px"
      }} >
        <div className="panel">
          <div className="header" >

            <MenuButton />

            <span className="title">List of users that exist:</span>
          </div>
          <div className="content">           
		
	  <div className="container" >
   <div style={{
        backgroundColor: "#DCDCDC",
        borderRadius: "2px"
      }}>
    <table className="table table-bordered" >
            <thead>
              <tr>
                <th>
                ID:
                </th>
                <th>
                First Name:
                </th>
                <th>
                Last Name:
                </th>
                <th>
                Username:
                </th>
                <th>
                Email:
                </th>
                <th>
                Country code:
                </th>
                <th>
                 Gender:
                </th>
                <th>
                MDBID:
                </th>
              </tr>
            </thead>
            
            <tbody>
        {users.map((user: UserResult) =>
 		      //  <div>
              <tr  key={user.id} >
                <td>{user.id}</td>
                <td>{user.first_name}</td>
                <td>{user.last_name}</td>
                <td>{user.username}</td>
                <td>{user.email}</td>
                <td>{user.country_code}</td>
                <td>{user.gender}</td>
                <td>{user.mdbid}</td>
              </tr>


                /* <p><b> ID: </b> {user.id},  <b> First name: </b> {user.first_name},  <b> Last name: </b> {user.last_name} </p> <br/><br/><br/> */
            // </div>
        )}
        </tbody>
        </table>
        </div>
     <b> This is also the result that is returned on loading on the page: </b> <br/>
		<form onSubmit={this.handleSubmit}>
  <input type="submit" value="getAllUsers" className="btn btn-primary"/>
</form>
<br/><br/>
<b> Enter existing user_id to be searched:</b> <br/>
		<form className="form-group" onSubmit={this.handleSubmit1}>
  <label>
    User_id: 
    <input type="text" name="name1" id="textBox" className="form-control" value={this.state.value} onChange={this.handleChangeGetUserById_userID} />
  </label>
  <input type="submit" value="getUserById" className="btn btn-primary small"/>
</form>
<br/><br/>
<b> Enter existing role_id to be added to existing user_id:</b> <br/>
		<form className="form-group" onSubmit={this.handleSubmit2}>
		  <label>
    User_id:
    <input type="text" name="name" className="form-control" id="textBox" value={this.state.value1} onChange={this.handleChangeAddRoleToUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRoleToUser_roleID} />
	</label>	
  <input type="submit" value="addRoleToUser"  className="btn btn-primary"/>
</form>



      </div>  
	  </div>
	  </div>
    
	  </div>
    )
  }
}

export default User
