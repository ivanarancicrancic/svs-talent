import React from 'react';

import MenuButton from './MenuButton';

// Could be fetched from a server
const activities = require('../../data.json')

interface Right {
  id: string;
  right_name: string;
  description: string;
}

interface RightsListProps {
}

interface RightListState {
  rights: Array<Right>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Rights extends React.Component<RightsListProps, RightListState> {
	constructor(props: RightsListProps) {
    super(props);

    this.state = {
      rights: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: "",
	  value3: "",
	  value4: "",
	  value5: ""
    };
  
  this.handleChangeGetRightsForRole = this.handleChangeGetRightsForRole.bind(this);
  this.handleSubmitGetRightsForRole = this.handleSubmitGetRightsForRole.bind(this);
  this.handleChangeGetRightsById_rightID = this.handleChangeGetRightsById_rightID.bind(this);
  this.handleSubmitGetRightsById = this.handleSubmitGetRightsById.bind(this);
  this.handleChangeAddRightsToRole_roleID = this.handleChangeAddRightsToRole_roleID.bind(this);
  this.handleChangeAddRightsToRole_rightID = this.handleChangeAddRightsToRole_rightID.bind(this);
  this.handleSubmitAddRightsToRole = this.handleSubmitAddRightsToRole.bind(this);	
  this.handleChangeRemoveRightsFromRole_roleID = this.handleChangeRemoveRightsFromRole_roleID.bind(this);
  this.handleChangeRemoveRightsFromRole_rightID = this.handleChangeRemoveRightsFromRole_rightID.bind(this);
  this.handleSubmitRemoveRightsFromRole = this.handleSubmitRemoveRightsFromRole.bind(this);	
	}
  
  handleChangeGetRightsForRole(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmitGetRightsForRole(event) {
    alert('Imetooooooo: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/getRightsForRole/role_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChangeGetRightsById_rightID(event) {
this.setState({value1: event.target.value});   
  }

  handleSubmitGetRightsById(event) {
    alert('Imeto: ' + this.state.value1);
    event.preventDefault();
    fetch('http://localhost:8080/getRightsByID/right_id=' + this.state.value1)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChangeAddRightsToRole_roleID(event) {
    this.setState({value2: event.target.value});
  }

   handleChangeAddRightsToRole_rightID(event) {
    this.setState({value3: event.target.value});
  }
  
  handleSubmitAddRightsToRole(event) {
    alert('Role_id: ' + this.state.value2 + ', Right_id: ' + this.state.value3);
    event.preventDefault();
    fetch('http://localhost:8080/addRightToRole/role_id=' + this.state.value2 + '&right_id=' + this.state.value3)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
   
  handleChangeRemoveRightsFromRole_roleID(event) {
    this.setState({value4: event.target.value});
  }

   handleChangeRemoveRightsFromRole_rightID(event) {
    this.setState({value5: event.target.value});
  } 
   
  handleSubmitRemoveRightsFromRole(event) {
    alert('Role_id: ' + this.state.value4 + ', Right_id: ' + this.state.value5);
    event.preventDefault();
    fetch('http://localhost:8080/removeRightFromRole/role_id=' + this.state.value4 + '&right_id=' + this.state.value5)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
   
  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/getAllRights')
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
	
	
  render() {
	   const {rights, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="container notificationsFrame"  style={{
        backgroundColor: "#8FBC8F",
        borderRadius: "2px"
      }} >
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">LIST OF RIGHTS FROM DATABASE</span>
          </div>
          <div className="content">           
		   
		
	  <div className="container">
    <div style={{
        backgroundColor: "#CCCC00",
        borderRadius: "2px"
      }}>
    <table className="table table-bordered" >
            <thead>
              <tr>
                <th>
                ID:
                </th>
                <th>
                Right Name:
                </th>
                <th>
                Description:
                </th>
               
              </tr>
            </thead>
            
            <tbody>
        {rights.map((right: Right) =>
 		      //  <div>
              <tr  key={right.id} >
                <td>{right.id}</td>
                <td>{right.right_name}</td>
                <td>{right.description}</td>     
              </tr>


                /* <p><b> ID: </b> {user.id},  <b> First name: </b> {user.first_name},  <b> Last name: </b> {user.last_name} </p> <br/><br/><br/> */
            // </div>
        )}
        </tbody>
        </table>
        </div>
		<form onSubmit={this.handleSubmitGetRightsForRole}>
  <label>
    Role_id:
    <input type="text" name="name" id="textBox" value={this.state.value} onChange={this.handleChangeGetRightsForRole} />
  </label>
  <input type="submit" value="getRightsForRole" className="btn btn-primary"/>
</form>
<br/><br/>
		<form onSubmit={this.handleSubmitGetRightsById}>
  <label>
    Right_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value1} onChange={this.handleChangeGetRightsById_rightID} />
  </label>
  <input type="submit" value="getRightsById" className="btn btn-primary"/>
</form>
<br/><br/>
		<form onSubmit={this.handleSubmitAddRightsToRole}>
  <label>
    Role_id:  
    <input type="text" name="name2" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRightsToRole_roleID} />
	</label>
  <label>
    Right_id:  
    <input type="text" name="name3" id="textBox" value={this.state.value3} onChange={this.handleChangeAddRightsToRole_rightID} />
	</label>	
  <input type="submit" value="addRightsToRole" className="btn btn-primary"/>
</form>

<br/><br/>
		<form onSubmit={this.handleSubmitRemoveRightsFromRole}>
  <label>
    Role_id:  
    <input type="text" name="name2" id="textBox" value={this.state.value4} onChange={this.handleChangeRemoveRightsFromRole_roleID} />
	</label>
  <label>
    Right_id:  
    <input type="text" name="name3" id="textBox" value={this.state.value5} onChange={this.handleChangeRemoveRightsFromRole_rightID} />
	</label>	
  <input type="submit" value="removeRightsFromRole" className="btn btn-primary"/>
</form>
		
      </div>  
	  </div>
	  </div>
	  </div>
    )
  }
}

export default Rights
