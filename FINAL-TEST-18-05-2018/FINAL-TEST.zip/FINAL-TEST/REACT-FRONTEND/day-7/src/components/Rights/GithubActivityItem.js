import React from 'react';

class GithubActivityItem extends React.Component {
  render() {
    return (
      <div className='item'>
        <div className={'avatar'}>
        </div>
      </div>
    )
  }
}

export default GithubActivityItem