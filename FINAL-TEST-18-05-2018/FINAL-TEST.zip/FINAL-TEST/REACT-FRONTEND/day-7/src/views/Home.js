import React from 'react';
import Role from '../components/Role/Role';
export const Home = ({ auth }) => (
  <div className='home'>
	 <Role/> 
  </div>
)

export default Home