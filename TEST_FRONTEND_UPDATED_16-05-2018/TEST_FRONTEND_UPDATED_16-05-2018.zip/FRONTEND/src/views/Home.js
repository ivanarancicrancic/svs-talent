import React from 'react';
import Role from '../components/Role/Role';
export const Home = ({ auth }) => (
  <div className='home'>
    <h1>{ auth.isLoggedIn ? 'Role' : 'You need to know the secret'}</h1>
	 <Role/> 
  </div>
)

export default Home