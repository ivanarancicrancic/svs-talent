import React from 'react';
import Timeline from '../components/Timeline/Timeline';
import ReactDOM from 'react-dom';

class About extends React.Component {
  render() {
    return (
        <Timeline/>
          );
  }
}

export default About;