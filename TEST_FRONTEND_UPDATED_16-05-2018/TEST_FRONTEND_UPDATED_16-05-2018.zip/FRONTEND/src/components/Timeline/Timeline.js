import React from 'react';

import MenuButton from './MenuButton';

// Could be fetched from a server
const activities = require('../../data.json')

interface Beer {
  id: string;
  right_name: string;
  description: string;
}

interface RightsListProps {
}

interface RightListState {
  rights: Array<Beer>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Timeline extends React.Component<RightsListProps, RightListState> {
	constructor(props: RightsListProps) {
    super(props);

    this.state = {
      rights: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: ""
    };
  
  this.handleChange = this.handleChange.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChange1 = this.handleChange1.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChange2 = this.handleChange2.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);

	}
  
  handleChange(event) {
    this.setState({value: event.target.value});
	this.setState({value1: event.target.value});
  }

  handleSubmit(event) {
    alert('Imetooooooo: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/getRightsForRole/role_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChange1(event) {
    this.setState({value1: event.target.value1});
  }

  handleSubmit1(event) {
    alert('Imetooooooo: ' + this.state.value1);
    event.preventDefault();
    fetch('http://localhost:8080/getRightsByID/right_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
  
  handleChange2(event) {
	  this.setState({value1: event.target.value1});
    this.setState({value2: event.target.value2});
  }

  handleSubmit2(event) {
    alert('Role_id: ' + this.state.value1 + ', Right_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/addRightToRole/role_id=' + this.state.value1 + '&right_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }

  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/getAllRights')
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
	
	
  render() {
	   const {rights, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="notificationsFrame">
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">Autorization</span>
          </div>
          <div className="content">           
		   <div className="line"></div>  
		
	  <div>
        <h2>Right List</h2><br/>
        {rights.map((right: Beer) =>
            <div className="item">
 		       <div key={right.id}>
                <p><b> Name: </b> {right.right_name},  <b> Description: </b> {right.description} </p> <br/><br/><br/>
               </div>
            </div>
        )}
		<form onSubmit={this.handleSubmit}>
  <label>
    Role_id:
    <input type="text" name="name" id="textBox" value={this.state.value} onChange={this.handleChange} />
  </label>
  <input type="submit" value="getRightsForRole" />
</form>
<br/><br/>
		<form onSubmit={this.handleSubmit1}>
  <label>
    Right_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value} onChange={this.handleChange} />
  </label>
  <input type="submit" value="getRightsById" />
</form>
<br/><br/>
		<form onSubmit={this.handleSubmit2}>
  <label>
    Role_id:  
    <input type="text" name="name2" id="textBox" value={this.state.value1} onChange={this.handleChange2} />
	</label>
  <label>
    Right_id:  
    <input type="text" name="name3" id="textBox" value={this.state.value2} onChange={this.handleChange2} />
	</label>	
  <input type="submit" value="addRightsToRole" />
</form>

		
      </div>  
	  </div>
	  </div>
	  </div>
    )
  }
}

export default Timeline
