import React from 'react';

import MenuButton from './MenuButton';

interface UserResult {
  id: string;
  first_name: string;
  last_name: string;
}

interface UserListProps {
}

interface UserListState {
  users: Array<UserResult>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class User extends React.Component<UserListProps, UserListState> {
	constructor(props: UserListProps) {
    super(props);

    this.state = {
      users: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: ""
    };
  
  this.handleChangeGetUserById_userID = this.handleChangeGetUserById_userID.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChangeAddRoleToUser_roleID = this.handleChangeAddRoleToUser_roleID.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChangeAddRoleToUser_userID = this.handleChangeAddRoleToUser_userID.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);

	}
  
  handleChangeGetUserById_userID(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmit(event) {
    event.preventDefault();
    fetch('http://localhost:8080/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_roleID(event) {
    this.setState({value2: event.target.value});
  }

  handleSubmit1(event) {
    alert('User id entered: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/getUserByID/userID=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_userID(event) {
	 this.setState({value1: event.target.value});
  }

  handleSubmit2(event) {
    alert('user_id: ' + this.state.value1 + ', role_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/addRoleToUser/user_id=' + this.state.value1 + '&role_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }

  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/getAllUsers')
      .then(response => response.json())
      .then(data => this.setState({users: data, isLoading: false}));
  }
	
	
  render() {
	   const {users, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="notificationsFrame">
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">Autorization</span>
          </div>
          <div className="content">           
		   <div className="line"></div>  
		
	  <div>
        <h2>List of users that exist: </h2><br/>
        {users.map((user: Beer) =>
            <div className="item">
 		       <div key={user.id}>
                <p><b> Name: </b> {user.first_name},  <b> Description: </b> {user.last_name} </p> <br/><br/><br/>
               </div>
            </div>
        )}
     <b> This is also the result that is returned on loading on the page: </b> <br/>
		<form onSubmit={this.handleSubmit}>
  <input type="submit" value="getAllUsers" />
</form>
<br/><br/>
<b> Enter existing user_id to be searched:</b> <br/>
		<form onSubmit={this.handleSubmit1}>
  <label>
    User_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value} onChange={this.handleChangeGetUserById_userID} />
  </label>
  <input type="submit" value="getUserById" />
</form>
<br/><br/>
<b> Enter existing role_id to be added to existing user_id:</b> <br/>
		<form onSubmit={this.handleSubmit2}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value1} onChange={this.handleChangeAddRoleToUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRoleToUser_roleID} />
	</label>	
  <input type="submit" value="addRoleToUser" />
</form>

		
      </div>  
	  </div>
	  </div>
	  </div>
    )
  }
}

export default User
