package com.nebiz.authorizationUsers.model;

import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Component
public class Rights {
    private int id;
    private String right_name;
    private String description;
    private List<Role> roles= new ArrayList<>();

    public Rights(){}
    public Rights(String right, String description) {
        this.right_name = right;
        this.description = description;
    }

    public Rights(String right, String description, List<Role> roles) {
        this.right_name = right;
        this.description = description;
        this.roles = roles;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRight_name() {
        return right_name;
    }

    public void setRight_name(String right_name) {
        this.right_name = right_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @ManyToMany(mappedBy = "rights")
    public List<Role> getRoles() {
        return roles;
    }

    public void setRoles(List<Role> roles) {
        this.roles = roles;
    }
}
