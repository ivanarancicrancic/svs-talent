package com.nebiz.authorizationUsers.controller;


import com.google.gson.Gson;
import com.nebiz.authorizationUsers.model.*;
import com.nebiz.authorizationUsers.service.RightService;
import com.nebiz.authorizationUsers.service.RoleService;
import com.nebiz.authorizationUsers.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins = "*")
@RestController
public class AuthorizationController {

    @Autowired
    UserService user_service;

    @Autowired
    RoleService role_service;

    @Autowired
    RightService right_service;

    private int id_current_user = -1;

    @RequestMapping(value = "/secret", method = RequestMethod.GET)
    //    public List<Twittmessage> getTwitts(){
    public void getSecretMessage() {
        System.out.println("Secret");
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getAllUsers", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getUsers() throws Exception{
        List<UserReturn> users = new ArrayList<UserReturn>();
        String users_str = null;
        try{
            users = user_service.getAllUsers();
            Gson gson = new Gson();
            System.out.println(users);
            users_str = gson.toJson(users);
            System.out.println(users_str);
            return users_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }


    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getUserByID/userID={userID}", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getUserByID(@PathVariable("userID") int id) throws Exception {
        List<UserReturn> users = new ArrayList<UserReturn>();
        UserReturn user = null;
        String user_str = null;
        try {
            user = user_service.getUserByID(id);
            users.add(user);
            Gson gson = new Gson();
            System.out.println(user);
            user_str = gson.toJson(users);
            System.out.println(user_str);
            return user_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    @RequestMapping(value = "/createUser", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json;charset=UTF-8")
    public void createUser(@RequestBody UserReturn user) {
        System.out.println("Init creating user...");
        user_service.createUser(user);
        System.out.println("Successfully created user!");
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getAllRoles", method = RequestMethod.GET)
    public String getAllRoles() throws Exception{
        List<RoleReturn> roles = null;
        String roles_str = null;
        try{
            roles = role_service.getAllRoles();
            Gson gson = new Gson();
            System.out.println(roles);
            roles_str = gson.toJson(roles);
            System.out.println(roles_str);
            return roles_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getRolesForUser/user_id={user_id}", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getRolesForUser(@PathVariable("user_id") int user_id) throws Exception{
        System.out.println("Entered api!!!");
        List<RoleReturn> roles = null;
        String roles_str = null;
        try{
            roles = role_service.getRolesForUser(user_id);
            Gson gson = new Gson();
            System.out.println(roles);
            roles_str = gson.toJson(roles);
            System.out.println(roles_str);
            return roles_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getRolesByID/role_id={role_id}", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getRoleByID(@PathVariable("role_id") int role_id) throws Exception{
        List<RoleReturn> roles = new ArrayList<RoleReturn>();
        RoleReturn role = null;
        String role_str = null;
        try{
            role = role_service.getRoleByID(role_id);
            roles.add(role);
            Gson gson = new Gson();
            System.out.println(role);
            role_str = gson.toJson(roles);
            System.out.println(role_str);
            return role_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getAllRights", method = RequestMethod.GET)
    public String getAllRights() throws Exception{
        List<RightsReturn> right_items = null;
        String t_tems_str  = null;
        try{
            right_items = right_service.getAllRights();
            Gson gson = new Gson();
            System.out.println(right_items);
            t_tems_str = gson.toJson(right_items);
            System.out.println(t_tems_str);
            return t_tems_str;
            //}
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getRightsForRole/role_id={role_id}", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getRightsForRole(@PathVariable("role_id") int role_id) throws Exception{
        List<RightsReturn> rights = null;
        String rights_str = null;
        try{
            rights = right_service.getRightsForRole(role_id);
            Gson gson = new Gson();
            System.out.println(rights);
            rights_str = gson.toJson(rights);
            System.out.println(rights_str);
            return rights_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }


    @ResponseStatus(value = HttpStatus.OK)
    @RequestMapping(value = "/getRightsByID/right_id={right_id}", method = RequestMethod.GET, produces="application/json;charset=UTF-8")
    public String getRightsByID(@PathVariable("right_id") int right_id) throws Exception{

        List<RightsReturn> right = new ArrayList<RightsReturn>();
        String rights_str = null;
        try{
            right = right_service.getRightByID(right_id);
            Gson gson = new Gson();
            System.out.println(right);
            rights_str = gson.toJson(right);
            System.out.println(rights_str);
            return rights_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    @RequestMapping(value = "/createRight", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json;charset=UTF-8")
    public void createRight(@RequestBody RightsReturn right) {
        System.out.println("Init creating right...");
        System.out.println("Rightname: " + right.getRight_name() + ", Right description: " + right.getDescription());
        right_service.createRight(right);
        System.out.println("Successfully created right!");
    }


    @RequestMapping(value = "/addRightToRole/role_id={role_id}&right_id={right_id}", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public String addRightToRole(@PathVariable("role_id") int role_id, @PathVariable("right_id") int right_id) {
        List<RoleReturn> roles = new ArrayList<RoleReturn>();
        System.out.println("Init adding Right to Role...");
         String roles_str = null;
         //System.out.println("Rightname: " + right.getRight_name() + ", Right description: " + right.getDescription());
        role_service.addRightToRole(right_id, role_id);
        role_service.getAllRoles();
        System.out.println("Successfully updated Right list to Role!");
        Gson gson = new Gson();
        roles_str = gson.toJson(roles);
        System.out.println(roles_str);
        return roles_str;
        }


    @RequestMapping(value = "/addRoleToUser/user_id={user_id}&role_id={role_id}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String addRoleToUser(@PathVariable("user_id") int user_id, @PathVariable("role_id") int role_id) {
       List<UserReturn> users = new ArrayList<UserReturn>();
        System.out.println("Init adding Role to User...");
        user_service.addRoleToUser(role_id, user_id);
        users= user_service.getAllUsers();
        System.out.println("Successfully updated Role list to User!");
         String users_str = null;
        Gson gson = new Gson();
        users_str = gson.toJson(users);
        System.out.println(users_str);
        return users_str;
    }


    @RequestMapping(value = "/removeRightFromRole/role_id={role_id}&right_id={right_id}", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = "application/json;charset=UTF-8")
    public void removeRightFromRole(@PathVariable("role_id") int role_id,  @PathVariable("right_id") int right_id) {
        System.out.println("Init removing Right to Role...");
        //System.out.println("Rightname: " + right.getRight_name() + ", Right description: " + right.getDescription());
        role_service.removeRightFromRole(right_id, role_id);
        System.out.println("Successfully updated Right list to Role!");
    }


    @RequestMapping(value = "/removeRoleFromUser/user_id={user_id}&role_id={role_id}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public String removeRoleFromUser(@PathVariable("user_id") int user_id, @PathVariable("role_id") int role_id) {
        List<UserReturn> users = new ArrayList<UserReturn>();
        System.out.println("Init removing Role to User...");
        user_service.removeRoleFromUser(role_id, user_id);
        users= user_service.getAllUsers();
        System.out.println("Successfully updated Role list to User!");
        String users_str = null;
        Gson gson = new Gson();
        users_str = gson.toJson(users);
        System.out.println(users_str);
        return users_str;
    }


}
