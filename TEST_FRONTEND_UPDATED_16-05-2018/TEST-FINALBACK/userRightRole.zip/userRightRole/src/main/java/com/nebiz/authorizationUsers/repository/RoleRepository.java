package com.nebiz.authorizationUsers.repository;

import com.nebiz.authorizationUsers.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

@Component
public interface RoleRepository extends JpaRepository<Role, Integer> {

    public Role findById(int id);
}
