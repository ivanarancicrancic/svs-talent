import Modal from "./components/Modal";

export default Modal;
