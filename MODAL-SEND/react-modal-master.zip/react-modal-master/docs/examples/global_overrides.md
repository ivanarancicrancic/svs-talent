# Global Overrides

If you'll be using several modals and want to adjust styling for all of them in one location you can by modifying `Modal.defaultStyles`.

[](codepen://claydiffrient/pNXgqQ)
