## Examples

The following sub-sections contain several examples of basic usage, hosted on
[CodePen](https://codepen.io).

The `examples` directory in the project root also contains some examples which
you can run locally.  To build and run those examples using a local development
server, run either

```
$ npm start
```

or

```
$ yarn run start
```

and then point your browser to `localhost:8080`.
