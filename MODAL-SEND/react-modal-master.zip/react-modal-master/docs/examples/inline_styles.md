# Using Inline Styles

This example shows how to use inline styles to adjust the modal.

[](codepen://claydiffrient/ZBmyKz)
