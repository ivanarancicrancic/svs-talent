# Using setAppElement

This example shows how to use setAppElement to properly hide your application from screenreaders and other assistive technologies while the modal is open.

You'll notice in this example that the aria-hidden attribute is applied to the #main div rather than the document body.

[](codepen://claydiffrient/ENegGJ)
