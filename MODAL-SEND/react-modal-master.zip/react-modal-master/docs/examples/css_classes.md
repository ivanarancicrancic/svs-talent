# Using CSS Classes for Styling

If you prefer to use CSS to handle styling the modal you can.

One thing to note is that by using the className property you will override all default styles.

[](codepen://claydiffrient/KNjVrG)
