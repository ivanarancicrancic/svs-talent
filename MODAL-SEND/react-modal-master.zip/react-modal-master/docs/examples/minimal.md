# Minimal

This example shows the minimal needed to get React Modal to work.

[](codepen://claydiffrient/KNxgav)
