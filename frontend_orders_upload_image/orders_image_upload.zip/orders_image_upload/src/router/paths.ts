export const PATH_ROOT = '/';

export const PATH_LANDING = '/landing';
export const PATH_ADMINISTRATION = '/administration';
export const PATH_START = '/start';
export const PATH_USUCCESSFUL_DB = '/unsuccessfulldb';
export const PATH_SEARCH = '/search';
export const PATH_ORDER_DETAIL = '/order/:orderId';
export const PATH_ORDER_EDIT = '/order/edit/:orderId';
export const PATH_FILTERED_ORDERS = '/orders/filtered/:startDateStr/:endDateStr';  





