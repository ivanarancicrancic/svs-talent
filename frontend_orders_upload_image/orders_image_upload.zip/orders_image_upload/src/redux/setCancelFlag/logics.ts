import { createLogic } from 'redux-logic';
import { SET_CANCEL_FLAG_FETCH } from './types';
import { setCancelFlagFetch, setCancelFlagSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const setCancelFlagLogic = createLogic({
    type: SET_CANCEL_FLAG_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setCancelFlagFetch)(action)) {
            const result =  action.payload.cancelFlag;
            dispatch(setCancelFlagSuccess(result))
        } else {
            done();
        }
    }
});

export default [
    setCancelFlagLogic
];
