import { IRootState } from '..'

export const getOrderWithDeletedArticle = (state: IRootState) => state.orderWithDeletedArticle.data;
export const OrderWithDeletedArticleLoading = (state: IRootState) => state.orderWithDeletedArticle.loading;
export const OrderWithDeletedArticleHasError = (state: IRootState) => state.orderWithDeletedArticle.error;