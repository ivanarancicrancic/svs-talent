import { createLogic } from 'redux-logic';
import { SET_CURRENT_INDEX_FETCH } from './types';
import { setCurrentIndexFetch, setCurrentIndexSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const setCurrentIndexFetchLogic = createLogic({
    type: SET_CURRENT_INDEX_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setCurrentIndexFetch)(action)) {
            const result =  action.payload.newIndex;
            dispatch(setCurrentIndexSuccess(result));  
        } else {
            done();
        }
    }
});

export default [
    setCurrentIndexFetchLogic
];
