export const GET_ORDER_ARTICLES_FETCH = '@@user/order/articles/FETCH';
export const GET_ORDER_ARTICLES_SUCCESS = '@@user/order/articles/SUCCESS';
export const GET_ORDER_ARTICLES_FAIL = '@@user/order/articles/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
    articleNetPrice: string;
    articleGrossPrice: string;
    articleNetPriceWD: string;
    articleGrossPriceWD: string;
    articlePictureUrl: string;
};