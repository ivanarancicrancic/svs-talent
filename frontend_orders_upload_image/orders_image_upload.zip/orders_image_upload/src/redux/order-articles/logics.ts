import { createLogic } from 'redux-logic';
import { GET_ORDER_ARTICLES_FETCH, IOrderArticleResponseModel } from './types';
import { getOrderArticlesFetch, getOrderArticlesSuccess, getOrderArticlesFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const getOrderArticlesFetchLogic = createLogic({
    type: GET_ORDER_ARTICLES_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(getOrderArticlesFetch)(action)) {  
          fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderArticlesServlet', {
            method: 'POST',
            body: JSON.stringify({
              order_id: action.payload.orderId
            })
          }).then((response) => response.json())
            .then((responseJson) => {
                dispatch(getOrderArticlesSuccess(responseJson as IOrderArticleResponseModel[]));
            })
            .catch((error) => {
                dispatch(getOrderArticlesFail("fail"))
            });

        } else {
            done();
        }
    }
});

export default [
    getOrderArticlesFetchLogic
];
