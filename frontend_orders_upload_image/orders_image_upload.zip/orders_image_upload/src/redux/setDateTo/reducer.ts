import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

const extActions = {...actions};
export type SetDateToStateActions = ActionType<typeof extActions>;

export interface ISetDateToState {
    readonly data: Date;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: ISetDateToState = {
    data: new Date(),
    loading: false,
    error: null
};
  
export function setDateToReducer(state: ISetDateToState = INITIAL_STATE, action: SetDateToStateActions): ISetDateToState  {
    switch (action.type) {
        case getType(extActions.setDateToFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setDateToSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setDateToFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}