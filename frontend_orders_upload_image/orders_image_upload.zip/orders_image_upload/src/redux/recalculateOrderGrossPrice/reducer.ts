import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type RecalculateOrderGrossPriceActions = ActionType<typeof extActions>;

export interface IRecalculateOrderGrossPriceState {
    readonly data: string;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IRecalculateOrderGrossPriceState = {
    data: "0",
    loading: false,
    error: null
};
  
export function recalculateOrderGrossPriceReducer(state: IRecalculateOrderGrossPriceState = INITIAL_STATE, action: RecalculateOrderGrossPriceActions): IRecalculateOrderGrossPriceState  {
    switch (action.type) {
        case getType(extActions.recalculateOrderGrossPriceFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.recalculateOrderGrossPriceSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.recalculateOrderGrossPriceFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}