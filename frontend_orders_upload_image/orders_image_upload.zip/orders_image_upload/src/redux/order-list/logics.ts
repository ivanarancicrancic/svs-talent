import { createLogic } from 'redux-logic';
import { ORDER_LIST_FETCH, IOrderResponseModel } from './types';
import { orderListFetch, orderListSuccess, orderListFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const orderListFetchLogic = createLogic({
    type: ORDER_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(orderListFetch)(action)) {
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/Orders')
            .then(response => response.json())
            .then(data => {
            dispatch(orderListSuccess(data as IOrderResponseModel[]));
              })
            .catch(error =>  dispatch(orderListFail("fail")));
        } else {
            done();
        }
    }
});

export default [
    orderListFetchLogic
];
