import { createLogic } from 'redux-logic';
import { SET_MODAL3_IS_OPEN_FETCH } from './types';
import { setModal3IsOpenFetch, setModal3IsOpenSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const setModal3IsOpenFetchLogic = createLogic({
    type: SET_MODAL3_IS_OPEN_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setModal3IsOpenFetch)(action)) {
            const result =  action.payload.modal3IsOpen;
            dispatch(setModal3IsOpenSuccess(result));  
        } else {
            done();
        }
    }
});

export default [
    setModal3IsOpenFetchLogic
];
