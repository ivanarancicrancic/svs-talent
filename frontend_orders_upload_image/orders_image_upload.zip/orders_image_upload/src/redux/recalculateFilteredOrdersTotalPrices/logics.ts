import { createLogic } from 'redux-logic';
import { RECALCULATE_FILTERED_TOTAL_PRICES_FETCH, ITotalPrices } from './types';
import { recalculateFilteredTotalPricesFetch, recalculateFilteredTotalPricesSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';
import { IRootState } from '..';
import { filterOrderFetch } from '../filterOrders/actions';

export const recalculateFilteredTotalPricesFetchLogic = createLogic({
    type: RECALCULATE_FILTERED_TOTAL_PRICES_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(recalculateFilteredTotalPricesFetch)(action)){ 
                if((getState() as IRootState).dateFrom.data && (getState() as IRootState).dateTo.data){
                    const sDate = new Date((getState() as IRootState).dateFrom.data);
                    const eDate = new Date((getState() as IRootState).dateTo.data);

    fetch('http://localhost:8080/ersatzteilhandel24apiValid/RecalculateTotalPricesServlet',
    {
        method: 'POST',
        body: JSON.stringify({
          startDate: sDate,
          endDate: eDate
        })
    })
    .then(response => response.json())
    .then(data => {
        dispatch(recalculateFilteredTotalPricesSuccess(data as ITotalPrices));
    })
    .then(
        data =>  {    
            const date1 = new Date(this.props.getDateFromData);
            const date2 = new Date(this.props.getDateToData); 
            dispatch(filterOrderFetch({startDate: date1, endDate: date2}))
        }
    )    
}
    }
    }
});

export default [
    recalculateFilteredTotalPricesFetchLogic
];
