export const RECALCULATE_FILTERED_TOTAL_PRICES_FETCH = '@@user/recalculate/totalPrices/dateFrom/dateTo/FETCH';
export const RECALCULATE_FILTERED_TOTAL_PRICES_SUCCESS = '@@user/recalculate/totalPrices/dateFrom/dateTo/SUCCESS';
export const RECALCULATE_FILTERED_TOTAL_PRICES_FAIL = '@@user/recalculate/totalPrices/dateFrom/dateTo/FAIL';


export interface ITotalPrices {
    netPrice: number;
    grossPrice: number;
    netPriceWD: number;
    grossPriceWD: number;

}