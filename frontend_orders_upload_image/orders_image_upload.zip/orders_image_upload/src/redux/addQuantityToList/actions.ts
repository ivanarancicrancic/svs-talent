import {
    ADD_QUANTITY_TO_LIST_FETCH,
    ADD_QUANTITY_TO_LIST_SUCCESS,
    ADD_QUANTITY_TO_LIST_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const addQuantityToListFetch = createStandardAction(ADD_QUANTITY_TO_LIST_FETCH)<{newQuantityValue:string, indexList:number, pushFlag: boolean}>();
export const addQuantityToListSuccess = createStandardAction(ADD_QUANTITY_TO_LIST_SUCCESS)<string[]>();
export const addQuantityToListFail = createStandardAction(ADD_QUANTITY_TO_LIST_FAIL)<string>();

