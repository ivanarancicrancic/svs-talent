import { combineForms } from 'react-redux-form';

export interface IInfoFormData {
    name: string;
    package: any;
    check: boolean;
};

const infoForm: IInfoFormData = {
    name: '',
    package: '',
    check: false,
}


const fileForm: IInfoFormData = {
    name: '',
    package: '',
    check: false,
}

export const formsReducer = combineForms({
   
    info: infoForm,
    file: fileForm

}, 'forms');
