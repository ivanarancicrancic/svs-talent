import { createLogic } from 'redux-logic';
import { CANCEL_ORDER_FETCH, IOrderDetailResponseModel } from './types';
import { cancelOrderFetch, cancelOrderSuccess, cancelOrderFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { recalculateFilteredTotalPricesFetch } from '../recalculateFilteredOrdersTotalPrices/actions';
import { history } from '../../router';
import { IRootState } from '..';
import { setModal3IsOpenFetch } from '../setModal3IsOpen/actions';
import { setCancelFlagFetch } from '../setCancelFlag/actions';
import { orderListFetch } from '../order-list/actions';
import { recalculateTotalPricesFetch } from '../recalculateTotalPrices/actions';

export const cancelOrderFetchLogic = createLogic({
    type: CANCEL_ORDER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(cancelOrderFetch)(action)) {
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderCancel', {
                method: 'POST',
                body: JSON.stringify({
                  order_to_cancel: action.payload.order_to_cancel,
                })
              })
            .then(response => response.json())
            .then(data => {
                const result = data as IOrderDetailResponseModel;
                dispatch(cancelOrderSuccess(result));        
            })
            .then(() => {
                dispatch(recalculateFilteredTotalPricesFetch());
            })
            .then(() => {   
                dispatch(recalculateTotalPricesFetch());
            })
            .then(() => {
                if((getState() as IRootState).orderDetail.data){
                    dispatch(setModal3IsOpenFetch({modal3IsOpen: false}));
                }  
            })   
            .then(() => {
                if((getState() as IRootState).orderDetail.data){
                    dispatch(setCancelFlagFetch({cancelFlag: false})); 
                }  
            }) 
            .then(() => {
                if((getState() as IRootState).orderDetail.data){
                    dispatch(orderListFetch());                  
                }  
            }) 
            .then(() => {
                if((getState() as IRootState).orderDetail.data){
                    history.push('/start');
                }  
            }) 
            .catch(error =>  dispatch(cancelOrderFail("fail")));
        } else {
            done();
        }
    }
});

export default [
    cancelOrderFetchLogic
];
