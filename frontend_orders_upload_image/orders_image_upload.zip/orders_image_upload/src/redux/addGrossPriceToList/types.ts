export const ADD_GROSS_PRICE_TO_LIST_FETCH = '@@user/add/grossPrice/toList/FETCH';
export const ADD_GROSS_PRICE_TO_LIST_SUCCESS = '@@user/add/grossPrice/toList/SUCCESS';
export const ADD_GROSS_PRICE_TO_LIST_FAIL = '@@user/add/grossPrice/toList/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}
