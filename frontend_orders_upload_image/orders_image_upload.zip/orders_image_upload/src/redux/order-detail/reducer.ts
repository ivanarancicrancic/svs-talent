import { ActionType, getType } from 'typesafe-actions';
import { IOrderDetailResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type OrderDetailActions = ActionType<typeof extActions>;

export interface IOrderDetailState {
    readonly data: IOrderDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IOrderDetailState = {
    data: null,
    loading: false,
    error: null
};
  
export function orderDetailReducer(state: IOrderDetailState = INITIAL_STATE, action: OrderDetailActions): IOrderDetailState  {
    switch (action.type) {
        case getType(extActions.orderDetailFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.orderDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.orderDetailFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}