import { createLogic } from 'redux-logic';
import { ORDER_DETAIL_FETCH, IOrderDetailResponseModel } from './types';
import { orderDetailFetch, orderDetailSuccess, orderDetailFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { getOrderArticlesFetch } from '../order-articles/actions';
import { setModal3IsOpenFetch } from '../setModal3IsOpen/actions';
import { recalculateFilteredTotalPricesFetch } from '../recalculateFilteredOrdersTotalPrices/actions';
import { IRootState } from '..';

export const orderDetailFetchLogic = createLogic({
    type: ORDER_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(orderDetailFetch)(action)) {
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderDetail', {
                method: 'POST',
                body: JSON.stringify({
                  orderId: action.payload.orderId,
                })
              })
            .then(response => response.json())
            .then(data => {
            const result = data as IOrderDetailResponseModel;
            dispatch(orderDetailSuccess(result));
              })
            //   .then(data => {
            //     dispatch(getOrderArticlesFetch({orderId:action.payload.orderId}));   
            // })
            .then(data => {
                if((getState() as IRootState).cancelFlag.data){
                dispatch(setModal3IsOpenFetch({modal3IsOpen: true}));
           
                }  
            })
            .then(data => {
                if((getState() as IRootState).cancelFlag.data){
                dispatch(recalculateFilteredTotalPricesFetch());    
                }
            })
            .catch(error =>  dispatch(orderDetailFail("fail")));
        } else {
            done();
        }
    }
});

export default [
    orderDetailFetchLogic
];
