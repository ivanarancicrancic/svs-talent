import { createLogic } from 'redux-logic';
import { SET_DATE_FROM_FETCH } from './types';
import { setDateFromFetch, setDateFromSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const setDateFromFetchLogic = createLogic({
    type: SET_DATE_FROM_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setDateFromFetch)(action)) {
            let result = new Date();
            result = new Date(action.payload.newDateFrom);
            
            dispatch(setDateFromSuccess(result));  
        } else {
            done();
        }
    }
});

export default [
    setDateFromFetchLogic
];
