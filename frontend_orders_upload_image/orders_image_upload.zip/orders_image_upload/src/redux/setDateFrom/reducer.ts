import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

const extActions = {...actions};
export type SetDateFromStateActions = ActionType<typeof extActions>;

export interface ISetDateFromState {
    readonly data: Date;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: ISetDateFromState = {
    data: new Date(),
    loading: false,
    error: null
};
  
export function setDateFromReducer(state: ISetDateFromState = INITIAL_STATE, action: SetDateFromStateActions): ISetDateFromState  {
    switch (action.type) {
        case getType(extActions.setDateFromFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setDateFromSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setDateFromFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}