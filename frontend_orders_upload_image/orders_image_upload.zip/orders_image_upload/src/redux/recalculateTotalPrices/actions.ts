import {
    RECALCULATE_TOTAL_PRICES_FETCH,
    RECALCULATE_TOTAL_PRICES_SUCCESS,
    RECALCULATE_TOTAL_PRICES_FAIL,
    ITotalPrices
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const recalculateTotalPricesFetch = createStandardAction(RECALCULATE_TOTAL_PRICES_FETCH)();
export const recalculateTotalPricesSuccess = createStandardAction(RECALCULATE_TOTAL_PRICES_SUCCESS)<ITotalPrices>();
export const recalculateTotalPricesFail = createStandardAction(RECALCULATE_TOTAL_PRICES_FAIL)<string>();

