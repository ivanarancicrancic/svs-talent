import { IRootState } from '..'

export const getRecalculatedTotalPrices = (state: IRootState) => state.recalculatedTotalPrices.data;
export const getRecalculatedTotalPricesLoading = (state: IRootState) => state.recalculatedTotalPrices.loading;
export const getRecalculatedTotalPricesHasError = (state: IRootState) => state.recalculatedTotalPrices.error;