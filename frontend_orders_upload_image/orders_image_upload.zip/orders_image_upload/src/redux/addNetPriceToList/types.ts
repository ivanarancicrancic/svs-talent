export const ADD_NET_PRICE_TO_LIST_FETCH = '@@user/add/netPrice/toList/FETCH';
export const ADD_NET_PRICE_TO_LIST_SUCCESS = '@@user/add/netPRice/toList/SUCCESS';
export const ADD_NET_PRICE_TO_LIST_FAIL = '@@user/add/netPrice/toList/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}
