package Models;

public class AplicantDetails {
    private String firstName;
    private String lastName;
    private String partija;
    private String address;

    public AplicantDetails() {
    }

    public AplicantDetails(String firstName, String lastName, String partija, String address) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.partija = partija;
        this.address = address;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPartija() {
        return partija;
    }

    public void setPartija(String partija) {
        this.partija = partija;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
