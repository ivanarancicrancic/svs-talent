package Models;

public class LoanRequest {

    int loantypeid;
    String embg;
   String requestdate;
   int amount;

   public  LoanRequest(){}

    public LoanRequest(int loantypeid, String embg, String requestdate, int amount) {
        this.loantypeid = loantypeid;
        this.embg = embg;
        this.requestdate = requestdate;
        this.amount = amount;
    }

    public int getLoantypeid() {
        return loantypeid;
    }

    public void setLoantypeid(int loantypeid) {
        this.loantypeid = loantypeid;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(String requestdate) {
        this.requestdate = requestdate;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
