package Models;

public class UsersByUsername {
    private String embg;
    private String firstName;
    private String lastName;
    private String branchofficename;

    public UsersByUsername() {
    }

    public UsersByUsername(String embg, String firstName, String lastName, String branchofficename) {
        this.embg = embg;
        this.firstName = firstName;
        this.lastName = lastName;
        this.branchofficename = branchofficename;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBranchofficename() {
        return branchofficename;
    }

    public void setBranchofficename(String branchofficename) {
        this.branchofficename = branchofficename;
    }
}
