package database;

import Models.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Project {

    public List<ClientType> getClientsType(Connection connection) throws Exception
    {
        List<ClientType> t_items = new ArrayList<ClientType>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getClientsType()");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                ClientType p_eden = new ClientType(
                        rs.getInt (1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<LoanRequestsByParametar> getloanrequestsbyparametar(Connection connection, String p_type, String p_value) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1,p_type);
            ps.setString(2,p_value);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(

                        rs.getLong(1),



                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }




    public List<DocumentsForLoanTypeID> GetDocumentsForLoanTypeID(Connection connection,Integer _loanTypeID) throws Exception
    {
        List<DocumentsForLoanTypeID> t_items = new ArrayList<DocumentsForLoanTypeID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getdocumentsforloantypeid(?)");
            ps.setInt(1, _loanTypeID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                DocumentsForLoanTypeID p_eden = new DocumentsForLoanTypeID(

                        rs.getInt(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsByLoanID> GetWarningsByLoanID(Connection connection, Integer loanID) throws Exception
    {
        List<WarningsByLoanID> t_items = new ArrayList<WarningsByLoanID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getwarningsbyloanid(?)");
            ps.setInt(1, loanID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsByLoanID p_eden = new WarningsByLoanID(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsDetailsByWarrningID> GetWarningsDetailsByWarrningID(Connection connection, Integer warningID) throws Exception
    {
        List<WarningsDetailsByWarrningID> t_items = new ArrayList<WarningsDetailsByWarrningID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getwarningsdetailsbywarrningid(?)");
            ps.setInt(1, warningID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsDetailsByWarrningID p_eden = new WarningsDetailsByWarrningID(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<LoanRequestsByParametar> GetLoanRequestsByParametar(Connection connection, String parametarName, String parametarValue) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1, parametarName);
            ps.setString(2, parametarValue);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(
                        rs.getLong(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void CreateLoanRequest(Connection connection, LoanRequest loanRequest) throws Exception
    {
        LoanRequest loanRequest1 = new LoanRequest();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from createloanrequest(?,?,?,?)");
            ps.setInt(1, loanRequest.getLoantypeid());
            ps.setString(2, loanRequest.getEmbg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setInt(4, loanRequest.getAmount());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void AddNewWarningByLoanID(Connection connection, LoanWarning loanWarning) throws Exception
    {
        // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from addnewwarningbyloanid(?,?,?,?)");
            // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanWarning.getLoanid());
            ps.setString(2, loanWarning.getWarrningdetails());
            ps.setInt(3, loanWarning.getWarrningpdfid());
            ps.setString(4, loanWarning.getWarrningdatte());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public LoanRequest UpdateLoanRequestByID(Connection connection, int loanTypeID, LoanRequest loanRequest) throws Exception
    {
       // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from updateloanrequestbyid(?,?,?,?)");
           // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanTypeID);
            ps.setString(2, loanRequest.getEmbg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setInt(4, loanRequest.getAmount());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            loanRequest.setLoantypeid(loanTypeID);
            return loanRequest;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<KreditenOdborGroups> GetKreditenOdborGroups(Connection connection) throws Exception
    {
        List<KreditenOdborGroups> t_items = new ArrayList<KreditenOdborGroups>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getkreditenodborgroups()");
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                KreditenOdborGroups p_eden = new KreditenOdborGroups(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }





}
