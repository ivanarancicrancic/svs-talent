package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.repository.SphereContentRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class SphereContentService {

    private SphereContentRepository sphereContentRepository;

    public SphereContentService(SphereContentRepository sphereContentRepository) {
        this.sphereContentRepository = sphereContentRepository;
    }

    public List<SphereContent> findAllSpheres(){
        return sphereContentRepository.findAll().stream().collect(Collectors.toList());
    }



}


