package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRespository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

@Service
@Transactional
public class SlideshowService {

    private final SlideshowRepository slideshowRepository;
    private final CampaignRespository campaignRespository;

    public SlideshowService(SlideshowRepository slideshowRepository, CampaignRespository campaignRespository) {
        this.slideshowRepository = slideshowRepository;
        this.campaignRespository = campaignRespository;
    }

    public List<SlideshowContent> getAllSlideshows(){
        String status = "getting all slideshow";
        System.out.println(status);
        Iterable<SlideshowContent> iterable = slideshowRepository.findAll();
        System.out.println("Taken slideshows!");
        List<SlideshowContent> list = new ArrayList<>();
        if(iterable != null) {
            for(SlideshowContent e: iterable) {
                list.add(e);
            }
        }
        return list;
    }


}
