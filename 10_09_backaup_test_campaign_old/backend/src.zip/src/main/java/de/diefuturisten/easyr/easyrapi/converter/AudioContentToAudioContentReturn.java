package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.model.request.AudioContentReturn;
import org.springframework.core.convert.converter.Converter;

public class AudioContentToAudioContentReturn implements Converter<AudioContent, AudioContentReturn> {

    public AudioContentToAudioContentReturn(){}

    @Override
    public AudioContentReturn convert(AudioContent source) {
        AudioContentReturn audioContentReturn = new AudioContentReturn();
        audioContentReturn.setId(source.getId());
        audioContentReturn.setWeight(source.getWeight());
        audioContentReturn.setName(source.getName());
        audioContentReturn.setUrl(source.getUrl());
        if(source.isRenderOnTrackingLost() == true)
            audioContentReturn.setRenderOnTrackingLost("true");
        else
            audioContentReturn.setRenderOnTrackingLost("false");

        return audioContentReturn;
    }
}
