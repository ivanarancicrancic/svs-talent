package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.MovieContentReturn;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowImageReturn;
import org.springframework.core.convert.converter.Converter;

public class SlideshowImageReturnToSlideshowImage implements Converter<SlideshowImageReturn, SlideshowImage> {

    public SlideshowImageReturnToSlideshowImage(){}

    @Override
    public SlideshowImage convert(SlideshowImageReturn source) {
        SlideshowImage slideshowImage = new SlideshowImage();
        slideshowImage.setId(source.getId());
        slideshowImage.setWeight(source.getWeight());
        return slideshowImage;
    }
}
