package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;

import java.util.List;

public class MovieContentList {
    private List<MovieContent> movieContentList;

    public MovieContentList(List<MovieContent> movieContentList) {
        this.movieContentList = movieContentList;
    }

    public List<MovieContent> getMovieContentList() {
        return movieContentList;
    }

    public void setMovieContentList(List<MovieContent> movieContentList) {
        this.movieContentList = movieContentList;
    }
}
