package de.diefuturisten.easyr.easyrapi.model.request;

public class PanoramaContentReturn extends ContentReturn {

    public enum Type { X180, X360 }

    Type type;

    String url;

    public PanoramaContentReturn(){}

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }




}
