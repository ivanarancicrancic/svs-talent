package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowContentReturn;
import org.springframework.core.convert.converter.Converter;

public class SlideshowContentToSlideshowContentReturn implements Converter<SlideshowContent, SlideshowContentReturn> {

    public SlideshowContentToSlideshowContentReturn(){}


    @Override
    public SlideshowContentReturn convert(SlideshowContent source) {

        SlideshowContentReturn slideshowContentReturn = new SlideshowContentReturn();
        slideshowContentReturn.setId(source.getId());
        slideshowContentReturn.setWeight(source.getWeight());
        slideshowContentReturn.setName(source.getName());

        slideshowContentReturn.setImages(null);

        slideshowContentReturn.setPositionX(source.getPositionX());
        slideshowContentReturn.setPositionY(source.getPositionY());
        slideshowContentReturn.setPositionZ(source.getPositionZ());
        slideshowContentReturn.setRotationX(source.getRotationX());
        slideshowContentReturn.setRotationY(source.getRotationY());
        slideshowContentReturn.setRotationZ(source.getRotationZ());

        slideshowContentReturn.setScaleX(source.getScaleX());
        slideshowContentReturn.setScaleY(source.getScaleY());
        slideshowContentReturn.setScaleZ(source.getScaleZ());

        if(source.isRenderOnTrackingLost()==true)
            slideshowContentReturn.setRenderOnTrackingLost("true");
        else
            slideshowContentReturn.setRenderOnTrackingLost("false");

        if(source.isExtendedTracking() == true)
            slideshowContentReturn.setExtendedTracking("true");
        else
            slideshowContentReturn.setExtendedTracking("false");
        return  slideshowContentReturn;
    }

}
