package de.ersatzteil.ersatzteilhandel24api.webService;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.node.TreeTraversingParser;
import com.mysql.cj.xdevapi.JsonParser;
import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

@WebServlet("/OrderSave")
public class OrderSaveServlet extends HttpServlet {
    static String extractPostRequestBody(HttpServletRequest request) throws IOException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            Scanner s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
        return "";
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("ENTERED OrderSaveServlet doPost");

        ObjectMapper mapper = new ObjectMapper();
        String result = extractPostRequestBody(request);
        JsonNode jsonNode = mapper.readTree(result);
        System.out.println("jsonNode: " + jsonNode);

        JsonParser jp = new JsonParser();

//        JsonNode node1 = jp.getCodec().readTree(jp);
//
//        String name1 =  node.get("name").asText();


//        orderToSave = mapper.readValue(new TreeTraversingParser(jsonNode), Order.class);
//        System.out.println("OrderToSave: " + orderToSave.getFirstName());
        String orderToSaveString = jsonNode.get("orderToSave").toString();
        System.out.println("orderToSaveString: " + orderToSaveString);


        JsonNode orderJsonNode = jsonNode.get("orderToSave");
        System.out.println("orderJsonNode: " + orderJsonNode);
        Order orderToSave = new Order();

        if (orderJsonNode != null) {
            System.out.println("orderJsonNode not null!!! ");
            String firstName=(orderJsonNode.get("firstName").asText());
            System.out.println("FIRST NAME: " + firstName);

            System.out.println("ORDER ID: " + orderJsonNode.get("order_id").asText());
            orderToSave.setOrder_id(orderJsonNode.get("order_id").asText());

            orderToSave.setFirstName(orderJsonNode.get("firstName").asText());

            System.out.println("LAST NAME:" + orderJsonNode.get("lastName").asText());
            orderToSave.setLastName(orderJsonNode.get("lastName").asText());

            SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH);

            System.out.println("Date: " + orderJsonNode.get("orderDate").toString());
            String dateInString = orderJsonNode.get("orderDate").toString();
//            try{
//                Date date = formatter.parse(dateInString);
//                orderToSave.setOrderDate(date);
//            }
//            catch (ParseException e){
//                System.out.println(e.getMessage());
//            }

            System.out.println("Company name: " + orderJsonNode.get("companyName").asText());
            orderToSave.setCompanyName(orderJsonNode.get("companyName").asText());
            System.out.println("Country: " + orderJsonNode.get("country").asText());
            orderToSave.setCountry(orderJsonNode.get("country").asText());
            orderToSave.setCity(orderJsonNode.get("city").asText());
            orderToSave.setStreet(orderJsonNode.get("street").asText());
            orderToSave.setHouseNumber(orderJsonNode.get("houseNumber").asText());
            orderToSave.setPostcode(orderJsonNode.get("postcode").asText());
            orderToSave.setLatest(orderJsonNode.get("latest").asInt());
            orderToSave.setAnrede(orderJsonNode.get("anrede").asText());
            orderToSave.setEmail(orderJsonNode.get("email").asText());
            orderToSave.setGrossPrice(orderJsonNode.get("grossPrice").asText());
            orderToSave.setNetPrice(orderJsonNode.get("netPrice").asText());
            orderToSave.setGrossPriceWD(orderJsonNode.get("grossPriceWD").asText());
            orderToSave.setNetPriceWD(orderJsonNode.get("netPriceWD").asText());
            orderToSave.setPaymentMethod(orderJsonNode.get("paymentMethod").asText());
            orderToSave.setShippingWay(orderJsonNode.get("shippingWay").asText());
            orderToSave.setPhoneNumber(orderJsonNode.get("phoneNumber").asText());

            System.out.println("OrderToSaveObject email:" + orderToSave.getEmail());
        }

//         Object orderObjectToSave = orderToSaveString;
//        System.out.println("Object: "  + orderObjectToSave);

//        Order orderToSave = new Order(jsonNode.get("order_id").asText());



//        Order newOrderNode = mapper.treeToValue(jsonNode, Order.class);
//        System.out.println("Converted jsonNode: " + newOrderNode.getFirstName());
        Order order_item = new Order();
        try{
            ProjectManager projectManager= new ProjectManager();
            projectManager.editOrder(orderToSave);
            OrderServlet.latestSelected ++ ;
            order_item.setLatest(OrderServlet.latestSelected);

            response.setContentType("application/json");
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            DateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
            mapper.setDateFormat(fmt);
            System.out.println("newOrderNodeFinally: " + orderToSave.getOrder_id());
            mapper.writeValue(response.getOutputStream(), orderToSave);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
