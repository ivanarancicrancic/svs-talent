export const ORDER_DETAIL_FETCH = '@@user/order/detail/FETCH';
export const ORDER_DETAIL_SUCCESS = '@@user/order/detail/SUCCESS';
export const ORDER_DETAIL_FAIL = '@@user/order/detail/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};