export const GET_ARTICLES_FETCH = '@@user/articles/list/FETCH';
export const GET_ARTICLES_SUCCESS = '@@user/articles/list/SUCCESS';
export const GET_ARTICLES_FAIL = '@@user/articles/list/FAIL';

export interface IArticleResponseModel {
    article_id: string;
    name: string;
    description: string;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};

