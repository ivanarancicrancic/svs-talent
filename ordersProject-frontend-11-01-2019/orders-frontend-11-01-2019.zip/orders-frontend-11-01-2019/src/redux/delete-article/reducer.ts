import { ActionType, getType } from 'typesafe-actions';
import { IOrderDetailResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type DeleteArticleFromOrderActions = ActionType<typeof extActions>;

export interface IDeleteArticleFromOrderState {
    readonly data: IOrderDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IDeleteArticleFromOrderState = {
    data: null,
    loading: false,
    error: null
};
  
export function deleteArticleFromOrderReducer(state: IDeleteArticleFromOrderState = INITIAL_STATE, action: DeleteArticleFromOrderActions): IDeleteArticleFromOrderState  {
    switch (action.type) {
        case getType(extActions.deleteArticleFromOrderFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.deleteArticleFromOrderSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.deleteArticleFromOrderFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}