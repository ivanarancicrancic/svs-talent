import { createLogic } from 'redux-logic';
// import axios from 'axios';

import { IOrderDetailResponseModel, DELETE_ARTICLE_FROM_ORDER_FETCH } from './types';
import { deleteArticleFromOrderFetch, deleteArticleFromOrderSuccess, deleteArticleFromOrderFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { API_ROOT } from '../../router/api-config';

export const deleteArticleFromOrderFetchLogic = createLogic({
    type: DELETE_ARTICLE_FROM_ORDER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(deleteArticleFromOrderFetch)(action)) {
            
            console.log("Before sending orderToBeSaved: " + action.payload.orArId);
            fetch('http://localhost:8080/DeleteArticleFromOrderServlet', {
                method: 'POST',
                body: JSON.stringify({
                    orArId: action.payload.orArId,
                })
              })
            .then(response => response.json())
            .then(data => {
            // dispatch(orderDetailSuccess(data as IOrderDetailResponseModel));
            const result = data as IOrderDetailResponseModel;
            console.log("ORDER SAVE SUCCESS!");
            dispatch(deleteArticleFromOrderSuccess(result));
             console.log(result);

            // console.log("Success: " + data);

            // Catch any errors we hit and update the app
              })
            .catch(error =>  dispatch(deleteArticleFromOrderFail("fail")));
        



            // console.log("YESS");
              
            // axios({
            //     method: 'get',
            //     url: API_ROOT + '/Orders'
            // }).then(response => {
            //     console.log("Before parse response: " + response.data);
            //     const result = JSON.parse(response.data) as IOrderResponseModel[];
            //     console.log("After parsing response: " + JSON.parse(response.data));
            //     dispatch(orderListSuccess(JSON.parse(response.data) as IOrderResponseModel[]));
            //     console.log("Success: " + result);
            // }).catch(error => {
            //     dispatch(orderListFail("fail"));
            // });

        } else {
            done();
        }
    }
});

export default [
    deleteArticleFromOrderFetchLogic
];
