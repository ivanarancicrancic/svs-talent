import { createLogic } from 'redux-logic';
// import axios from 'axios';

import { DECREMENT_QUANTITY_FETCH, IOrderArticleResponseModel } from './types';
import { decrementQuantityFetch, decrementQuantitySuccess, decrementQuantityFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { API_ROOT } from '../../router/api-config';

export const decrementQuantityFetchLogic = createLogic({
    type: DECREMENT_QUANTITY_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(decrementQuantityFetch)(action)) {
            
            // console.log("Before sending orderToBeSaved: " + action.payload.);
            fetch('http://localhost:8080/DecrementOrderArticlesQuantity', {
                method: 'POST',
                body: JSON.stringify({
                    newQuantityValue: action.payload.newQuantityValue
                  })
  
              })
            .then(response => response.json())
            .then(data => {
            // dispatch(orderDetailSuccess(data as IOrderDetailResponseModel));
            const result = data as IOrderArticleResponseModel;
            console.log("ORDER SAVE SUCCESS!");
            dispatch(decrementQuantitySuccess(result));
             console.log(result);

            // console.log("Success: " + data);

            // Catch any errors we hit and update the app
              })
            .catch(error =>  dispatch(decrementQuantityFail("fail")));
        



            // console.log("YESS");
              
            // axios({
            //     method: 'get',
            //     url: API_ROOT + '/Orders'
            // }).then(response => {
            //     console.log("Before parse response: " + response.data);
            //     const result = JSON.parse(response.data) as IOrderResponseModel[];
            //     console.log("After parsing response: " + JSON.parse(response.data));
            //     dispatch(orderListSuccess(JSON.parse(response.data) as IOrderResponseModel[]));
            //     console.log("Success: " + result);
            // }).catch(error => {
            //     dispatch(orderListFail("fail"));
            // });

        } else {
            done();
        }
    }
});

export default [
    decrementQuantityFetchLogic
];
