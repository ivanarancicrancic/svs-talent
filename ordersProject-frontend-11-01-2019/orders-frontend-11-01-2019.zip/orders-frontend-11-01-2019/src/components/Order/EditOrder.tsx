import * as React from 'react';
import OrderInfo from './OrderInfo/OrderInfo';

export default class EditOrder extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <OrderInfo />
            </div>
        )
    }

}