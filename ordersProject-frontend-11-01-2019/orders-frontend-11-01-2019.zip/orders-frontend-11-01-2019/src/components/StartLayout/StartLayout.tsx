import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { Form, Control } from 'react-redux-form';
import DatePicker from 'react-date-picker';
import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
// import { IOrderSaveRequestModel } from '../../redux/order-save/types';
import { IOrderCancelRequestModel } from '../../redux/cancelOrders/types';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    
}

type IProps = IPropsDispatchMap & IPropsStateMap

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(132, 132, 132, 0.88)',
      width: '100%'
    }
  };


class StartLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modal3IsOpen: false,
           currentOrder: null,
           orderFirstNameToBeSaved: null,
           orderLastNameToBeSaved: null,
           orderCompanyNameToBeSaved: null,
           orderPaymentMethodToBeSaved: null,
           orderShippingWayToBeSaved: null,
           orderAnredeToBeSaved: null,
           orderCountryToBeSaved: null,
           orderStreetToBeSaved: null,
           orderHouseNumberToBeSaved: null,
           orderPostcodeToBeSaved: null,
           orderCityToBeSaved: null,
           orderPhoneNumberToBeSaved: null,
           orderEmailToBeSaved: null,
           orderNetPriceToBeSaved: null,
           orderGrossPriceToBeSaved: null,
           orderNetPriceWDToBeSaved: null,
           orderGrossPriceWDToBeSaved: null,
           orderToSave: null
        

      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        // this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleCancelOrder = this.handleCancelOrder.bind(this);
        this.handleSubmitCancelOrderWithReason = this.handleSubmitCancelOrderWithReason.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    public componentWillMount() {
        Modal.setAppElement('body');
        this.props.orderListFetch();        
        console.log("Date on mount: " + this.state.dateFrom);
    }

    //  public componentWillReceiveProps(nextProps: IProps) {
    //         this.props.orderListFetch();             
    // }


//   public handleSubmitSaveOrder(value:any) {
    
//     console.log("orderFirstNameToBeSaved: " + value.firstName);
//     console.log("orderLastNameToBeSaved: " + value.lastName);
   
//     const newValues: IOrderSaveRequestModel = {

//         order_id: value.order_id,
//         orderDate: new Date(),
//         paymentMethod: value.paymentMethod,
//         shippingWay: value.shippingWay,
//         anrede: "anrede",
//         firstName: value.firstName,
//         lastName: value.lastName,
//         companyName: value.companyName,
//         country: value.country,
//         street: value.street,
//         houseNumber: value.houseNumber,
//         city: value.city,
//         postcode: value.postcode,
//         phoneNumber: value.phoneNumber, 
//         email: value.email, 
//         latest: 1,
//         netPrice: value.netPrice,
//         grossPrice: value.grossPrice,
//         netPriceWD:  value.netPriceWD,
//         grossPriceWD: value.grossPriceWD 

//     }

//     this.props.orderSaveFetch({orderToSave: newValues});
//    this.props.orderDetailFetch({orderId: newValues.order_id});
//    this.props.orderListFetch();      

//    this.setState({modalIsOpen: false}); 
//    this.setState({modal2IsOpen: false});
//    const p = mapStateToProps;
//    console.log(p);
//    history.push('/start');

// }

// public handleCancelOrder(orderid:any) {
    
   
//    this.props.cancelOrderFetch({order_id: orderid});
//    this.props.orderListFetch();      

//    this.setState({modalIsOpen: false}); 
//    this.setState({modal2IsOpen: false});
//    const p = mapStateToProps;
//    console.log(p);
//    history.push('/start');

// }


public handleClick() {
    console.log('this is:', this);
  }
    
    public selectedRowHandel(order: IOrderResponseModel){
        console.log("SELECTED ORDER: " + order.firstName + order.order_id);
        const order_id = order.order_id;
        const orderId = order_id;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({order_id});
        history.push(`/order/${order_id}`);
        }

    public handleFilter(values:any){
        console.log("entered handle filter");
        values.preventDefault();
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
        history.push(`/orders/filtered`);
      };
 
   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
        console.log("State for selected dateFrom: " + this.state.dateFrom) 
     };

   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
     console.log("State for selected dateTo: " + this.state.dateTo) 
  };

  public handleCancelOrder(order:IOrderResponseModel) {
    
    const orderId = order.order_id;
    console.log("order to cancel: " + orderId);
    this.props.orderDetailFetch({orderId});
    this.setState({modal3IsOpen: true});
  
 //    this.props.cancelOrderFetch({order_id: orderid});
 //    this.props.orderListFetch();      
 
    // this.setState({modalIsOpen: false}); 
    // this.setState({modal2IsOpen: false});
 //    const p = mapStateToProps;
 //    console.log(p);
 //    history.push('/start');
 
 }
 
 public handleSubmitCancelOrderWithReason(value:any) {
     

    //  console.log("Canceling of order with id: "  + value.orderid + ", canceling reason: " + value.order_cancel_reason);
     if(this.props.orderDetailData)     
     {
        const cancelValues: IOrderCancelRequestModel = {
            order_id: this.props.orderDetailData.order_id,
            cancelReason: value.order_cancel_reason
        }
     
        console.log("2. Canceling order with id: "  + this.props.orderDetailData.order_id + ", canceling reason: " + value.order_cancel_reason)
     this.setState({modal3IsOpen: false});
  
    //  this.props.cancelOrderFetch({order_id: value.orderid, cancelReason: value.order_cancel_reason});
    this.props.cancelOrderFetch({order_to_cancel: cancelValues});
    //    this.props.orderListFetch();      
  
    //  this.setState({modalIsOpen: false}); 
    //  this.setState({modal2IsOpen: false});
     history.push('/start'); 
    
    }
     else
     {console.log("this.props.orderDetailData == NULL");}

     
 }
 
 public closeModal() {
    console.log("Modal closed!!!");
  this.setState({modal3IsOpen: false});
}


 public renderOrderList() {

    let totalNetPrice = 0;
    let totalGrossPrice = 0;
    let totalNetPriceWD = 0;
    let totalGrossPriceWD = 0;
  
    if(this.props.orderData)
            {
                console.log("this.props.filteredOrderData != null");
            const ordersNetPrices = this.props.orderData.map( order => {
                return (
                    parseInt(order.netPrice, 10)
                 )
             })

             const ordersGrossPrices = this.props.orderData.map( order => {
                return (
                    parseInt(order.grossPrice, 10)
                 )
             })
            
             const ordersNetPricesWD = this.props.orderData.map( order => {
                return (
                    parseInt(order.netPriceWD, 10)
                 )
             })

             const ordersGrossPricesWD = this.props.orderData.map( order => {
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
             })

        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPrice = ordersNetPrices.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPrice = ordersGrossPrices.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWD = ordersNetPricesWD.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWD = ordersGrossPricesWD.reduce(summingReducer3, 0);
          }
          else { 
            totalNetPrice = 0;
            totalGrossPrice = 0;
            totalNetPriceWD = 0;
            totalGrossPriceWD = 0;     
              } 
   
            console.log("FInal totalNetPrice: " + totalNetPrice);
            console.log("FInal totalGrossPrice: " + totalGrossPrice);
            console.log("FInal totalNetPriceWD: " + totalNetPriceWD);
            console.log("FInal totalGrossPriceWD: " + totalGrossPriceWD);


            if(this.props.orderData)
            {
       return (
           <div className="dashboardTable">
               <table className="table bp3-html-table bp3-html-table-bordered">
               <thead>                  
               <tr >
                       <th>Order ID</th>
                       <th>Oder DATE</th>
                       <th>FirstName </th>
                               <th>LastName </th>
                               <th>Country </th>
                               <th>Company </th>
                               <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>        
                       </tr>

               </thead>
               <tbody>
                   
                   {this.props.orderData.map( order => {
                       return (
                           <tr key={order.order_id}  className = "order_hovered">
                               <td onClick={(e) => this.selectedRowHandel(order)}><b>{order.order_id}</b></td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.orderDate} </td> 
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.firstName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.lastName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.country} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.companyName} </td>
                               <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPrice} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPrice} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPriceWD} </td>
                                    <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPriceWD} </td>
                                    <td><button type="button" onClick={(e) => this.handleCancelOrder(order)} className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                                    {/* <td><button type="button" onClick={(e) => this.handleCancelOrder(order.order_id)} className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td> */}
                           </tr>
                       )
                   })}
                 
                  
                 <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                   <tr>
                   <td colSpan={5} className="text-center" >
                      <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                   </td>
                   </tr>
               </tbody>
               </table>
           </div>
       ) 
      }
        else { return null;}  
    
}

    public render() {
        
        if(this.props.orderDetailData){     

        return (
            <div className="grid100">
    <Modal 
// style={{ overlay: { position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255, 255, 255, 0.75)' }}}
  isOpen={this.state.modal3IsOpen}
//   onAfterOpen={this.afterOpenModal}
  onRequestClose={this.closeModal}
  style={customStyles}
  contentLabel="Example Modal"
>
  {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
 <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
 
  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER TO CANCEL DETAILS: </div>
  <br/>

  <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitCancelOrderWithReason(info) }
          // onSubmit={ (info) => this.onSubmit1() }
        // validateOn="submit"
                    
                >   
                 <tr>
                   <td>
            
                   <div>
         
                   <label htmlFor="orderid" className="bp3-file-input"><b>Order Id: </b> {this.props.orderDetailData.order_id}</label> &nbsp;  &nbsp; 
                        {/* <Control.text
                            className="bp3-input"
                            model=".orderid"
                            defaultValue={this.props.orderDetailData.order_id} 
                        
                            // onChange={this.handleChange}
                        /> */}
                      <br/>
                      <label htmlFor="order_cancel_reason" className="bp3-file-input"><b>Reason for canceling: </b></label>  &nbsp;  &nbsp;  
                      <Control.text
                            className="bp3-input"
                            model=".order_cancel_reason" 
                            // onChange={this.handleChange}
                        /> 
                        <br/>
                    </div> 
                  
                   </td>
            
         </tr>
         <tr>                 
         <div style={{position: 'absolute', bottom: 23, right: 33}} > <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#FF0000"}} > Cancel this order  </button>
                 </div>
                        </tr>
     
        </Form>
</Modal>

             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderOrderList()}   
            </div>
        )
    }
    else {
        return (
            <div className="grid100">
 
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderOrderList()}   
            </div>
        )


    }
    }
}


const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(StartLayout)


