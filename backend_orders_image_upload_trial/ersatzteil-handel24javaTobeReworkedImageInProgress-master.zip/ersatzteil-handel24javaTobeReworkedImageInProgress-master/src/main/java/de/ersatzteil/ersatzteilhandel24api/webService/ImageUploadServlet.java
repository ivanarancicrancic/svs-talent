package de.ersatzteil.ersatzteilhandel24api.webService;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

//@WebServlet("/ersatzteilhandel24apiValid/orderArticle/uploadImage")

@WebServlet("/ersatzteilhandel24apiValid/orderArticle/uploadImage")
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
        maxFileSize=1024*1024*10,      // 10MB
        maxRequestSize=1024*1024*50)   // 50MB
public class ImageUploadServlet extends HttpServlet {

    private static final long serialVersionUID = 5619951677845873534L;

    private static final String UPLOAD_DIR = "uploads";


    static String extractPostRequestBody(HttpServletRequest request) throws IOException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            Scanner s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
        return "";
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("Entered upload do Post!!!");
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        // gets absolute path of the web application
//        String applicationPath = request.getServletContext().getRealPath("");
        // constructs path of the directory to save uploaded file
        String uploadFilePath = "./target/ersatzteilhandel24apiValid/" + UPLOAD_DIR;

        System.out.println("uploadFilePath: " + uploadFilePath);
        // creates upload folder if it does not exists
        File uploadFolder = new File(uploadFilePath);
        if (!uploadFolder.exists()) {
            uploadFolder.mkdirs();
        }

        PrintWriter writer = response.getWriter();

        // write all files in upload folder
        for (Part part : request.getParts()) {
            if (part != null && part.getSize() > 0) {
                String fileName = part.getSubmittedFileName();
                System.out.println("File name: " + fileName);
                        String contentType = part.getContentType();
                System.out.println("File name: " + fileName + ", and contentType is: " + contentType);


                // allows only JPEG files to be uploaded
                if (!contentType.equalsIgnoreCase("image/jpeg")) {
                    continue;
                }

                part.write(uploadFilePath + File.separator + fileName);

                System.out.println("FInished uploading!");

//                writer.append("File successfully uploaded to "
//                        + uploadFolder.getAbsolutePath()
//                        + File.separator
//                        + fileName
//                        + "<br>\r\n");
            }
        }

    }


//    protected void doPost(HttpServletRequest request,
//                          HttpServletResponse response) throws ServletException, IOException {
//        // gets absolute path of the web application
//        System.out.println("Entered uploadFile DO POST !!!!!!");
//                        ObjectMapper mapper = new ObjectMapper();
//        String result = extractPostRequestBody(request);
//        JsonNode jsonNode = mapper.readTree(result);
////        String appPath = request.getServletContext().getRealPath("");
//        // constructs path of the directory to save uploaded file
//        String savePath = "./src/main/resources";
//
//        // creates the save directory if it does not exists
//        File fileSaveDir = new File(savePath);
//        System.out.println("fileSaveDir!!!");
//        if (!fileSaveDir.exists()) {
//            fileSaveDir.mkdir();
//        }
//        System.out.println("request.getParts(): " + jsonNode.getNodeType());
//        for (Part part : request.getParts()) {
//            String fileName = extractFileName(part);
//            System.out.println("File name: " + fileName);
//            // refines the fileName in case it is an absolute path
//            fileName = new File(fileName).getName();
//            System.out.println("File name1 : " + fileName);
//            part.write(savePath + File.separator + fileName);
//        }
//        request.setAttribute("message", "Upload has been done successfully!");
//        getServletContext().getRequestDispatcher("/message.jsp").forward(
//                request, response);
//        System.out.println("UploadImage finished!!");
//
//    }
//    /**
//     * Extracts file name from HTTP header content-disposition
//     */
//    private String extractFileName(Part part) {
//        String contentDisp = part.getHeader("content-disposition");
//        String[] items = contentDisp.split(";");
//        for (String s : items) {
//            if (s.trim().startsWith("filename")) {
//                return s.substring(s.indexOf("=") + 2, s.length()-1);
//            }
//        }
//        return "";
//    }


}
