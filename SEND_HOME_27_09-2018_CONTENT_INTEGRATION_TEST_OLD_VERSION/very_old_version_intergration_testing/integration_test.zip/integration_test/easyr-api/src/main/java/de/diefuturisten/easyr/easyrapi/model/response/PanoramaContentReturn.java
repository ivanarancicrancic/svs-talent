package de.diefuturisten.easyr.easyrapi.model.response;

public class PanoramaContentReturn{

    long id;

    int weight;

    String name;

    public enum Type { X180, X360 }

    PanoramaContentReturn.Type type;

    String url;

    public PanoramaContentReturn(){}

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PanoramaContentReturn.Type getType() {
        return type;
    }

    public void setType(PanoramaContentReturn.Type type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }




}
