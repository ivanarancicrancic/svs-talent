package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.model.response.UnityContentReturn;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;

public class UnityContentReturnToUnityContent implements org.springframework.core.convert.converter.Converter<UnityContentReturn, UnityContent>{

    public UnityContentReturnToUnityContent(){}

    @Override
    public UnityContent convert(UnityContentReturn source) {
       UnityContent unityContent = new UnityContent();
        unityContent.setId(source.getId());
        unityContent.setWeight(source.getWeight());
        unityContent.setName(source.getName());
        unityContent.setIosUrl(source.getIosUrl());
        unityContent.setAndroidUrl(source.getAndroidUrl());
        unityContent.setPositionX(source.getPositionX());
        unityContent.setPositionY(source.getRotationY());
        unityContent.setPositionZ(source.getRotationZ());
        unityContent.setRotationX(source.getRotationX());
        unityContent.setRotationY(source.getRotationY());
        unityContent.setRotationZ(source.getRotationZ());
        unityContent.setScaleX(source.getScaleX());
        unityContent.setScaleY(source.getScaleY());
        unityContent.setScaleZ(source.getScaleZ());
        if(source.getRenderOnTrackingLost() == "true")
          unityContent.setRenderOnTrackingLost(true);
        else
            unityContent.setRenderOnTrackingLost(false);

        if(source.getExtendedTracking() == "true")
            unityContent.setExtendedTracking(true);
        else
            unityContent.setExtendedTracking(false);

        return unityContent;
    }
}
