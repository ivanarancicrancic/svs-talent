package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.vuforia.DeleteTarget;
import de.diefuturisten.easyr.easyrapi.vuforia.GetAllTargets;
import de.diefuturisten.easyr.easyrapi.vuforia.GetTarget;
import de.diefuturisten.easyr.easyrapi.vuforia.PostNewTarget;
import de.diefuturisten.easyr.easyrapi.vuforia.Summary;
import de.diefuturisten.easyr.easyrapi.vuforia.UpdateTarget;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;

@Service
@Transactional
public class VuforiaService {

    @Value("${easyr.vuforia.accessKey}")
    private String accessKey;

    @Value("${easyr.vuforia.secretKey}")
    private String secretKey;

    @Value("${easyr.vuforia.url}")
    private String url;

    private Summary summaryApi;
    private GetAllTargets getAllTargets;
    private GetTarget getTarget;
    private PostNewTarget postNewTarget;
    private UpdateTarget updateTarget;
    private DeleteTarget deleteTarget;

    public VuforiaService() {
        initApis();
    }

    public VuforiaService(String url, String accessKey, String secretKey) {
        this.url = url;
        this.accessKey = accessKey;
        this.secretKey = secretKey;

        initApis();
    }

    private void initApis() {
        summaryApi = new Summary(url, accessKey, secretKey);
        getAllTargets = new GetAllTargets(url, accessKey, secretKey);
        getTarget = new GetTarget(url, accessKey, secretKey);
        updateTarget = new UpdateTarget(url, accessKey, secretKey);
        deleteTarget = new DeleteTarget(url, accessKey, secretKey);
    }

    public String getSummary() {
        try {
            return summaryApi.getSummary();
        } catch (Exception e) {
            return null;
        }
    }

    public String getAllTargets() {
        try {
            return getAllTargets.getTargets();
        } catch (Exception e) {
            return null;
        }
    }

    public String getTarget(String targetId) {
        try {
            return getTarget.getTarget(targetId);
        } catch (Exception e) {
            return null;
        }
    }

    public String postTarget(String targetName, File file, PostNewTarget.IPostNewTargetStatusListener listener) {
        PostNewTarget postNewTarget = new PostNewTarget(url, accessKey, secretKey);
        try {
            return postNewTarget.postTarget(targetName, file, listener);
        } catch (Exception e) {
            return null;
        }
    }

    public String updateTarget(String targetId, File file) {
        try {
            return updateTarget.updateTarget(targetId, file);
        } catch (Exception e) {
            return null;
        }
    }

    public String deleteTarget(String targetId) {
        try {
            return deleteTarget.deleteTarget(targetId);
        } catch (Exception e) {
            return null;
        }
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
