package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class CampaignToCampaignCommand implements Converter<Campaign, CampaignCommand> {

    ContactInformationToContactInformationReturn contactInformationToContactInformationReturn = new ContactInformationToContactInformationReturn();
    UserToUserReturn userToUserReturn = new UserToUserReturn();
    TrackerToTrackerReturn trackerToTrackerReturn = new TrackerToTrackerReturn();

    public CampaignToCampaignCommand() {
    }

    @Override
    public CampaignCommand convert(Campaign source){
        if(source == null){
            return null;
        }

        CampaignCommand campaignCommand = new CampaignCommand();

        Long id;

        User user;

        List<Tracker> tracker = new ArrayList<>();

        List<Content> contents = new ArrayList<>();

        ContactInformation contact;

        campaignCommand.setId(source.getId());
        campaignCommand.setUser(userToUserReturn.convert(source.getUser()));
        campaignCommand.setContact(contactInformationToContactInformationReturn.convert(source.getContactInformation()));

        if (source.getTracker() != null && source.getTracker().size() > 0){
            source.getTracker()
                    .forEach( tracker1 -> campaignCommand.getTracker().add(trackerToTrackerReturn.convert(tracker1)));
        }

        return campaignCommand;
    }
}
