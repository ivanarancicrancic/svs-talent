package de.diefuturisten.easyr.easyrapi.model.request;

public class WebviewContentReturn extends ContentReturn
{    private String url;

   public WebviewContentReturn(){}

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
