package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.WebviewContentReturn;
import org.springframework.core.convert.converter.Converter;

public class WebviewContentReturnToWebviewContent implements Converter<WebviewContentReturn, WebviewContent> {

    public WebviewContentReturnToWebviewContent(){}

    @Override
    public WebviewContent convert(WebviewContentReturn source) {
        WebviewContent webviewContent = new WebviewContent();
        webviewContent.setId(source.getId());
        webviewContent.setWeight(source.getWeight());
        webviewContent.setName(source.getName());
        webviewContent.setUrl(source.getUrl());
        return webviewContent;
    }

}
