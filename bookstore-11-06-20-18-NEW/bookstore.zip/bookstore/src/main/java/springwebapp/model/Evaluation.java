package springwebapp.model;

import javax.persistence.*;
import java.util.List;

@Entity
public class Evaluation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String evaluation;

    @OneToMany
    private List<Book> book;
//
//    public Evaluation(Long id, String evaluation) {
//        this.id = id;
//        this.evaluation = evaluation;
//    }

//    public  Evaluation(){};
//
//    public Evaluation(Long id, String evaluation, List<Book> book) {
//        this.id = id;
//        this.evaluation = evaluation;
//        this.book = book;
//    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<Book> getBook() {
        return book;
    }

    public void setBook(List<Book> book) {
        this.book = book;
    }

    public String getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(String evaluation) {
        this.evaluation = evaluation;
    }
}
