import { createLogic } from 'redux-logic';
// import axios from 'axios';

import { GET_ORDER_ARTICLES_FETCH, IOrderArticleResponseModel } from './types';
import { getOrderArticlesFetch, getOrderArticlesSuccess, getOrderArticlesFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { API_ROOT } from '../../router/api-config';

export const getOrderArticlesFetchLogic = createLogic({
    type: GET_ORDER_ARTICLES_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(getOrderArticlesFetch)(action)) {
            
          console.log("getOrderArticlesFetchLogic entered, before call http://localhost:8080/OrderArticlesServlet")
          
          fetch('http://localhost:8080/OrderArticlesServlet', {
            method: 'POST',
            body: JSON.stringify({
              order_id: action.payload.order_id
            })
          }).then((response) => response.json())
            .then((responseJson) => {
                console.log("GOT RESPONSE AFTER TO JSON CONVERTING: " + responseJson);
                dispatch(getOrderArticlesSuccess(responseJson as IOrderArticleResponseModel[]));
                console.log("Success getOrderArticlesSuccess : " + responseJson);
            })
            .catch((error) => {
                dispatch(getOrderArticlesFail("fail"))
            });

    


            // console.log("YESS");
              
            // axios({
            //     method: 'get',
            //     url: API_ROOT + '/Orders'
            // }).then(response => {
            //     console.log("Before parse response: " + response.data);
            //     const result = JSON.parse(response.data) as IOrderResponseModel[];
            //     console.log("After parsing response: " + JSON.parse(response.data));
            //     dispatch(orderListSuccess(JSON.parse(response.data) as IOrderResponseModel[]));
            //     console.log("Success: " + result);
            // }).catch(error => {
            //     dispatch(orderListFail("fail"));
            // });

        } else {
            done();
        }
    }
});

export default [
    getOrderArticlesFetchLogic
];
