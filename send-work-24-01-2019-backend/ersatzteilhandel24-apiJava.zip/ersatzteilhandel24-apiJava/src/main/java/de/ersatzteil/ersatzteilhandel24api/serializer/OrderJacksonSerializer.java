package de.ersatzteil.ersatzteilhandel24api.serializer;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

import java.io.IOException;
import java.text.SimpleDateFormat;

public class OrderJacksonSerializer extends StdSerializer<Order> {

    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public OrderJacksonSerializer(Class t) {
        super(t);
    }

    @Override
    public void serialize(Order order, JsonGenerator jsonGenerator,
                          SerializerProvider serializerProvider) throws IOException {

        jsonGenerator.writeStartObject();
        jsonGenerator.writeStringField("order_id", order.getOrder_id());
        jsonGenerator.writeObjectField("dateOfBirth",
                order.getOrderDate() != null ?
                        sdf.format(order.getOrderDate()) : null);
        jsonGenerator.writeStringField("paymentMethod", order.getPaymentMethod());
        jsonGenerator.writeStringField("shippingWay", order.getShippingWay());
        jsonGenerator.writeStringField("anrede", order.getAnrede());
        jsonGenerator.writeStringField("firstName", order.getFirstName());
        jsonGenerator.writeStringField("lastName", order.getLastName());
        jsonGenerator.writeStringField("companyName", order.getCompanyName());
        jsonGenerator.writeStringField("country", order.getCountry());
        jsonGenerator.writeStringField("street", order.getStreet());
        jsonGenerator.writeStringField("houseNumber", order.getHouseNumber());
        jsonGenerator.writeStringField("city", order.getCity());
        jsonGenerator.writeStringField("postcode", order.getPostcode());
        jsonGenerator.writeStringField("phoneNumber", order.getPhoneNumber());
        jsonGenerator.writeStringField("email", order.getEmail());
        jsonGenerator.writeEndObject();
    }
}