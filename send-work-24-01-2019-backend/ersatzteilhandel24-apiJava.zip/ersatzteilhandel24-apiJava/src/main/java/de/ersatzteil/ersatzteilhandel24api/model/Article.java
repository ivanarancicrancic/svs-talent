package de.ersatzteil.ersatzteilhandel24api.model;

public class Article {
    String article_id;
    String name;
    String description;
    String netPrice;
    String grossPrice;
    String netPriceWD;
    String grossPriceWD;

    public Article(){}

    public Article(String article_id, String name, String description, String netPrice, String grossPrice, String netPriceWD, String grossPriceWD) {
        this.article_id = article_id;
        this.name = name;
        this.description = description;
        this.netPrice = netPrice;
        this.grossPrice = grossPrice;
        this.netPriceWD = netPriceWD;
        this.grossPriceWD = grossPriceWD;
    }

    public String getArticle_id() {
        return article_id;
    }

    public void setArticle_id(String article_id) {
        this.article_id = article_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNetPrice() {
        return netPrice;
    }

    public void setNetPrice(String netPrice) {
        this.netPrice = netPrice;
    }

    public String getGrossPrice() {
        return grossPrice;
    }

    public void setGrossPrice(String grossPrice) {
        this.grossPrice = grossPrice;
    }

    public String getNetPriceWD() {
        return netPriceWD;
    }

    public void setNetPriceWD(String netPriceWD) {
        this.netPriceWD = netPriceWD;
    }

    public String getGrossPriceWD() {
        return grossPriceWD;
    }

    public void setGrossPriceWD(String grossPriceWD) {
        this.grossPriceWD = grossPriceWD;
    }
}
