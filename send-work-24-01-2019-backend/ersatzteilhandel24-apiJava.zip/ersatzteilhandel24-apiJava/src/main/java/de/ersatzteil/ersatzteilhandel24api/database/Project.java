package de.ersatzteil.ersatzteilhandel24api.database;

import de.ersatzteil.ersatzteilhandel24api.model.*;

import javax.ws.rs.WebApplicationException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class Project {

    public List<Order> getOrderList(Connection connection) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders order by orderDate");
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {

                Boolean statusBoolean = rs.getBoolean(21);
                String status  = "";
                if(statusBoolean == false)
                    status = "active";
                else
                    status = "canceled";
                Date d = rs.getTimestamp(2) ;
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20),
                       status,
                        rs.getString(22)
                );

                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                throw new WebApplicationException(404);
            }
            else
            {
                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<Order> getFilteredOrders(Connection connection, Date startDate, Date endDate) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {

            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            Date currentDate =startDate;

            Calendar c = Calendar.getInstance();
            c.setTime(currentDate);

            c.add(Calendar.DATE, 2);
            Date currentDatePlus3 = c.getTime();
             startDate = currentDatePlus3;

             currentDate = endDate;
              c = Calendar.getInstance();
              c.setTime(currentDate);
              c.add(Calendar.DATE, 3);
              currentDatePlus3 = c.getTime();
              endDate = currentDatePlus3;

            ps = connection.prepareStatement("select * from orders where orderDate >= ? and orderDate <= ?");
            java.sql.Date sDate = new java.sql.Date(startDate.getTime());
            java.sql.Date eDate = new java.sql.Date(startDate.getTime());
            ps.setDate(1, new java.sql.Date(startDate.getTime()));
            ps.setDate(2, new java.sql.Date(endDate.getTime()));

            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                Boolean statusBoolean = rs.getBoolean(21);
                String status  = "";
                if(statusBoolean)
                    status = "active";
                else
                    status = "canceled";
                Date d = rs.getTimestamp(2) ;
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20),
                        status,
                        rs.getString(22)
                );

                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                return  null;
            }
            else
            {

                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public Order getOrderDetails(Connection connection, String order_id) throws Exception
    {
        Order order_item = new Order();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders where orders_id = ?");
            ps.setString(1, order_id);

            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next()) {
                Boolean statusBoolean = rs.getBoolean(21);
                String status  = "";
                if(statusBoolean)
                    status = "active";
                else
                    status = "canceled";
                Date d = rs.getTimestamp(2);
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20),
                        status,
                        rs.getString(22)
                );
                order_item = order;
            }

            if (order_item==null){
                return  null;
            }
            else
            {
                System.out.println(order_item.getEmail());
                return order_item;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<OrderArticles> getOrderArticlesList(Connection connection, String order_id) throws Exception
    {
        List<OrderArticles> order_articles_items = new ArrayList<>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orderarticle where orders_id = ?");
            ps.setString(1, order_id);
            ResultSet rs = ps.executeQuery();

            while(rs.next())
            {
                OrderArticles order_article = new OrderArticles(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)
                );

                System.out.println("OrderArticle netPrice: " + order_article.getArticleNetPrice());
                System.out.println("OrderArticle grossPrice: " + order_article.getArticleGrossPrice());
                System.out.println("OrderArticle netPriceWD: " + order_article.getArticleNetPriceWD());
                System.out.println("OrderArticle grossPriceWD: " + order_article.getArticleGrossPriceWD());
                order_articles_items.add(order_article);
            }

            if (order_articles_items==null ){
                throw new WebApplicationException(404);

            }
            else
            {
                return order_articles_items;

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void editOrder(Connection connection, Order order_item) throws Exception
    {
        PreparedStatement ps=null;
        try
        {

            ps = connection.prepareStatement(" UPDATE orders SET paymentMethod=?, shippingWay=?, anrede=?, firstName=?, lastName=?, companyName=?, country=?," +
                    " street=?, houseNumber=?, city=?, postcode=?, phoneNumber=?, email=?, netPrice=?, grossPrice=?, netPriceWD=?, grossPriceWD=?" +
                    "WHERE orders_id = ?");

            System.out.println("BEFORE SAVING INTO DATABASE");
            ps.setString(1, order_item.getPaymentMethod());
            ps.setString(2, order_item.getShippingWay());
            ps.setString(3, order_item.getAnrede());
            ps.setString(4, order_item.getFirstName());
            ps.setString(5, order_item.getLastName());
            ps.setString(6, order_item.getCompanyName());
            ps.setString(7, order_item.getCountry());
            ps.setString(8, order_item.getStreet());
            ps.setString(9, order_item.getHouseNumber());
            ps.setString(10, order_item.getCity());
            ps.setString(11, order_item.getPostcode());
            ps.setString(12, order_item.getPhoneNumber());
            ps.setString(13, order_item.getEmail());
            System.out.println("order_item.getNetPrice()): " + order_item.getNetPrice());
            ps.setString(14, order_item.getNetPrice());
            ps.setString(15, order_item.getGrossPrice());
            ps.setString(16, order_item.getNetPriceWD());
            ps.setString(17, order_item.getGrossPriceWD());
            ps.setString(18, order_item.getOrder_id());
            ps.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public void decrementQuantityOrder(Connection connection, IOrderArticleQuantityRequestModel order_article) throws Exception {
        PreparedStatement ps = null;

            try {
                ps = connection.prepareStatement(" UPDATE orderarticle SET  articleQuantity= ? WHERE orderarticle_id = ?");
                ps.setString(1, order_article.getQuantity());
                ps.setString(2, order_article.getOrArId());
                ps.executeUpdate();
            } catch (Exception e) {
                e.printStackTrace();
                throw e;
            } finally {
                ps.close();
                connection.close();
            }
    }


    public void updateNetPriceOrder(Connection connection, IOrderArticleNetPriceRequestModel order_article) throws Exception {
        PreparedStatement ps = null;

        try {
            ps = connection.prepareStatement(" UPDATE orderarticle SET  articleNetPrice= ? WHERE orderarticle_id = ?");
            ps.setString(1, order_article.getNetPrice());
            ps.setString(2, order_article.getOrArId());
            ps.executeUpdate();
            System.out.println("");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            ps.close();
            connection.close();
        }
    }

    public void updateGrossPriceOrder(Connection connection, IOrderArticleGrossPriceRequestModel order_article) throws Exception {
        PreparedStatement ps = null;

        try {
            ps = connection.prepareStatement(" UPDATE orderarticle SET  articleGrossPrice= ? WHERE orderarticle_id = ?");
            ps.setString(1, order_article.getGrossPrice());
            ps.setString(2, order_article.getOrArId());
            ps.executeUpdate();
            System.out.println("");
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            ps.close();
            connection.close();
        }
    }


    public void deleteArticleFromOrder(Connection connection, String order_article_id) throws Exception {
        PreparedStatement ps = null;

        try {
            ps = connection.prepareStatement(" delete from orderarticle WHERE orderarticle_id = ?");
            ps.setString(1, order_article_id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            ps.close();
            connection.close();
        }
    }

    public Order cancelOrder(Connection connection, String order_id, String cancelreason) throws Exception
    {
        Order order = new Order();
        PreparedStatement ps=null;
        try {
            ps = connection.prepareStatement("UPDATE orders SET canceled = true, cancelreason= ? WHERE orders_id = ?");
            ps.setString(1, cancelreason);
            ps.setString(2, order_id);
            System.out.println("order_id: " + order_id);
            ps.executeUpdate();

            return order;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


}
