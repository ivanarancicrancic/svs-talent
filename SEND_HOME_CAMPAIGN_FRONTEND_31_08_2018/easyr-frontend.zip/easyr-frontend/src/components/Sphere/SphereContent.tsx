import * as React from 'react';


export default class Sphere extends React.Component {

    public render() {
        return (
            <pre>
                <div className="panoramaBox">
                    <table className="bp3-html-table">
                        <tbody>
                            <tr>
                                <td>
                                    <form >
                                        <input type="file" name="pic" accept="image/*"/>
                                    </form>
                                </td>
                                <td> <img src="https://loremflickr.com/60/50" /> </td>
                            </tr>
                        </tbody>
                    </table>
                </div>        
            </pre>
        )
    }
}