import * as React from 'react';

export default class PanoramaContent extends React.Component {

    public render() {
        return (
            <pre>
                <div className="panoramaBox">
                    <div>
                        <span>Type</span>
                        <div className="bp3-select ">
                            <select>
                                <option value="1">180&#176; </option>
                                <option value="2">360&#176; </option>
                            </select>
                        </div>
                    </div>
                    <table className="bp3-html-table">
                        <tbody>
                            <tr>
                                <td>
                                    <form >
                                        <input type="file" name="pic" accept="image/*"/>
                                    </form>
                                </td>
                                <td> <img src="https://loremflickr.com/60/50" /> </td>
                            </tr>
                        </tbody>
                    </table>
                </div>        
            </pre>
        )
    }
}