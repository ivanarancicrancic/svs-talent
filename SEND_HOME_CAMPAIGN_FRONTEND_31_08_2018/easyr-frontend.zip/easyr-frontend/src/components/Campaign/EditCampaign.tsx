import * as React from 'react';
import TrackerImages from './TrackerImages/TrackerImages';
import CampaignContent from './CampaignContent/CampaignContent';
import CampaignInfo from './CampaignInfo/CampaignInfo';

export default class EditCampaign extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <CampaignInfo />
                <TrackerImages />
                <CampaignContent />
            </div>
        )
    }

}