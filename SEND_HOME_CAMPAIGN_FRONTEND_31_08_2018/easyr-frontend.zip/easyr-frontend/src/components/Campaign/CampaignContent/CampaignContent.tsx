import * as React from 'react';
import './CampaignContent.css';

import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedContents, getListedAudios} from '../../../redux/actions/localCampaignsActions'
import { IMovieContent, IAudioContent } from '../../../models/CampaignsModelHelper'
import { IRootState } from '../../../redux/index';
import { idCampaign } from '../../Dashboard/Campaigns';

interface ICampaignInfosState {
    entry: string,
    contents?: IMovieContent[],
    audios?: IAudioContent[],
     error?: any,
     selected? : any
 

}
interface ICampaignInfosProps {
    getAllContents: any,
    getAllAudios: any,
    editCampaignData: any,
    contents: any,
    audios: any


}

class CampaignContent extends React.Component<ICampaignInfosProps, ICampaignInfosState> {

    constructor(props: ICampaignInfosProps) {
        super(props)
        this.state = {
            entry: '',
            contents: [],
            audios: []
        }
    }


    public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
        // this.setState({campaignsData: realCampaignData.campaigns})
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
            this.editCampaign(event)
        }
    }

    public render() {
        return (
            <div className="grid100 campaignBox">
                <table className="grid100 table bp3-html-table bp3-html-table-bordered bp3-interactive">
                    <tbody >
                    {
                  this.props.contents.map((c: IMovieContent) =>
                  
                        <tr key= {c.id}>
                        <td><button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button> {c.name}
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>  )
                    }
                 
                 {
                  this.props.audios.map((a: IAudioContent) =>
                  
                        <tr key= {a.id}>
                        <td><button className="circle"> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button> {a.name}
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>  )
                    }
                 


                        <tr>
                        <td> <button className="circle"> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button> Audio
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td> 
                        <button className="circle"> <span className="bp3-icon-standard bp3-icon-media" /> </button> Movie
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>    
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td> 
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-box" /> </button> Slideshow
                            <div className="iconsRight"> 
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                                <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                            </div>
                        </td>
                        <td className="btnDelete"><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td colSpan={2}> 
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-media" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-volume-up" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-box" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }

    public componentDidMount() {

        if(idCampaign.create){
            console.log("ENTERED!!!!!");
        this.props.getAllContents(idCampaign.id);
        this.props.getAllAudios();
        }
    }

    public componentWillReceiveProps(newProps: ICampaignInfosProps) {

        if(idCampaign.create){
        this.setState({
            contents: newProps.contents,
            audios: newProps.audios
            // ...newProps.contents
        })
        console.log(this.state)
    }
    }

}

const mapStateToProps = (state: IRootState) => {
    return {
        // ...state
        contents: state.allMovieContents.contents,
        audios: state.allAudioContents.audios,
        selected: state.selectedCampaign.selectedCampaign
        // contents: state.allTrackers.realCampaigns,
        // error: state.allTrackers.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        // getAllTrackers: () => dispatch(getListedContents()),
        getAllContents: (id: string) => dispatch(getListedContents(id)),
        getAllAudios: () => dispatch(getListedAudios()),
        editCampaignData: (entry: string) => dispatch(editAndGetCampaigns(entry))
        
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(CampaignContent)




