// import { Action } from 'redux'
import { ICampaignsAction } from '../actions/campaignsActions'
import { HANDLE_GET_ALL_CAMPAIGNS, HANDLE_SET_CAMPAIGNS, HANDLE_FETCH_CAMPAIGNS_FAILED } from '../actions/actionTypes'
import { IRealCampaign } from '../../models/CampaignsModelHelper'
export interface IRealCampaignData {
    realCampaigns: IRealCampaign[],
    error: boolean

}

const INITIAL_STATE: IRealCampaignData = {
    realCampaigns: [],
    error: false
}

export function campaignsReducer(state: IRealCampaignData = INITIAL_STATE, action: ICampaignsAction): IRealCampaignData {
    switch(action.type) {
        case HANDLE_GET_ALL_CAMPAIGNS:
            return {
                ...action.payload
            };
        case HANDLE_SET_CAMPAIGNS:
        console.log("CALLLED HANDLE_SET_CAMPAIGNS");  
        return {
            ...state,
            realCampaigns: action.payload,
            error:false
          }; 
      case HANDLE_FETCH_CAMPAIGNS_FAILED:
          return {
            ...state,
            error: true
          }; 
          
        default:
            return state
    }
}


