package de.diefuturisten.easyr.easyrapi.integration;

import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class UserRepositoryTest {
    @Autowired
    UserRepository userRepository;

    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository);
    }

    @After
    public  void cleanup(){
        IntegrationTestHelper.cleanupUserData(userRepository);
    }

    @Test
    @Transactional
    public void userExists(){
        //userRepository.findByEmail("christen@app-logik.de").get();
        userRepository.findByEmail("ivica.taskovski@app-logik.de").get();
    }

    @Test(expected = NoSuchElementException.class)
    @Transactional
    public void  userNotExisting(){
        userRepository.findByEmail("no_user").get();
    }
}
