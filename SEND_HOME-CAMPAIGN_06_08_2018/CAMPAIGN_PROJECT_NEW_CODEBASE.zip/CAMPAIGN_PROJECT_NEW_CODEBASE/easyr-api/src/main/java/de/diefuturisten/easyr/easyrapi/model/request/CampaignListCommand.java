package de.diefuturisten.easyr.easyrapi.model.request;


import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

import java.util.List;

public class CampaignListCommand {

    List<Campaign> campaigns;

    public List<Campaign> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignListCommand(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignListCommand() {
    }

}
