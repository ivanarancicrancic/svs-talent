package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.model.request.AudioContentList;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignListCommand;
import de.diefuturisten.easyr.easyrapi.model.request.MovieContentList;
import de.diefuturisten.easyr.easyrapi.model.request.PanoramaContentList;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowListEntry;
import de.diefuturisten.easyr.easyrapi.model.request.SphereContentList;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import de.diefuturisten.easyr.easyrapi.service.SphereContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;

import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class CampaignController {

    @Autowired
    CampaignService campaignService;

    @Autowired
    SlideshowContentService slideShowContentService;

    @Autowired
    AudioContentService audioContentService;

    @Autowired
    MovieContentService movieContentService;

    @Autowired
    PanoramaContentService panoramaContentService;

    @Autowired
    SphereContentService sphereContentService;

    public CampaignController(CampaignService campaignService, SlideshowContentService slideShowContentService, AudioContentService audioContentService, MovieContentService movieContentService, PanoramaContentService panoramaContentService, SphereContentService sphereContentService) {
        this.campaignService = campaignService;
        this.slideShowContentService = slideShowContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
        this.panoramaContentService = panoramaContentService;
        this.sphereContentService = sphereContentService;
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_LIST)
    public CampaignListCommand getCampaigns()
    {
        System.out.println("Entered /campaigns");
       // List<CampaignCommand> campaigns = null;
        List<Campaign> campaigns = null;
        String campaign_str = null;
            campaigns = campaignService.getAllCampaigns();
              CampaignListCommand campaignList = new CampaignListCommand(campaigns);
            System.out.println("BEFORE RETURN: " + campaignList.getCampaigns());
            for(Campaign cc : campaignList.getCampaigns()){
                System.out.println("Campaign ID: " + cc.getId());
            }
            return campaignList;
    }

    @GetMapping("/campaign/{id}/slideshows")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.SLIDESHOWS_LIST)
    public SlideshowListEntry getSlideshowsByCampaign(@PathVariable String id)
    {
        System.out.println("Entered /campaign/{id}/slideshows");
        List<SlideshowContent> slideshows = null;
        List<SlideshowContent> allSlideshows = null;
        List<Content> contents = null;
            contents = campaignService.findById(new Long(id)).getContents();
            allSlideshows = slideShowContentService.findAllSlides();
            for(SlideshowContent slideshowContent: allSlideshows)
            {
                if(slideshowContent.getCampaign().getId() == new Long(id))
                {
                    slideshows.add(slideshowContent);
                }
            }
            return new SlideshowListEntry(slideshows);

    }


    @GetMapping("/campaign/{id}/audios")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.AUDOIO_LIST)
    public AudioContentList getAudiosByCampaign(@PathVariable String id) throws Exception
    {
        System.out.println("Entered /campaign/{id}/audios");
        List<AudioContent> audios = null;
        List<AudioContent> allAudios = null;
        List<Content> contents = null;
            contents = campaignService.findById(new Long(id)).getContents();
            allAudios= audioContentService.findAllAudios();
            for(AudioContent audioContent: allAudios)
            {
                if(audioContent.getCampaign().getId() == new Long(id))
                {
                   audios.add(audioContent);
                }
            }
            return new AudioContentList(audios);
    }

@GetMapping("/campaign/{id}/movies")
    @ResponseStatus(HttpStatus.OK)
@PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.MOVIES_LIST)
    public MovieContentList getMoviesByCampaign(@PathVariable String id)
    {
        System.out.println("Entered /campaign/{id}/movies");
        List<MovieContent> movies = null;
        List<MovieContent> allMovies = null;
        List<Content> contents = null;

            contents = campaignService.findById(new Long(id)).getContents();
            allMovies= movieContentService.findAllMovies();
            for(MovieContent movieContent: allMovies)
            {
                if(movieContent.getCampaign().getId() == new Long(id))
                {
                    movies.add(movieContent);
                }
            }
            return new MovieContentList(movies);
    }


    @GetMapping("/campaign/{id}/panoramas")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PANORAMA_LIST)
    public PanoramaContentList getPanoramasByCampaign(@PathVariable String id)
    {
        System.out.println("Entered /campaign/{id}/panoramas");
        List<PanoramaContent> panoramas = null;
        List<PanoramaContent> allPanoramas = null;
        List<Content> contents = null;
            contents = campaignService.findById(new Long(id)).getContents();
            allPanoramas= panoramaContentService.findAllPanoramas();
            for(PanoramaContent panoramaContent: allPanoramas)
            {
                if(panoramaContent.getCampaign().getId() == new Long(id))
                {
                    panoramas.add(panoramaContent);
                }
            }
            return new PanoramaContentList(panoramas);
    }


    @GetMapping("/campaign/{id}/spheres")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.SPHERE_LIST)
    public SphereContentList getSpheresByCampaign(@PathVariable String id)
    {
        System.out.println("Entered /campaign/{id}/sphere");
        List<SphereContent> spheres = null;
        List<SphereContent> allSpheres = null;
        List<Content> contents = null;
            contents = campaignService.findById(new Long(id)).getContents();
            allSpheres= sphereContentService.findAllSpheres();
            for(SphereContent sphereContent: allSpheres)
            {
                if(sphereContent.getCampaign().getId() == new Long(id))
                {
                    spheres.add(sphereContent);
                }
            }
            return new SphereContentList(spheres);
    }

    @GetMapping("/campaign/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_VIEW)
    public Campaign showById(@PathVariable String id){
        System.out.println("entered campaign/show/{id}");
            Campaign campaign =  campaignService.findById(new Long(id));
            return campaign;
    }

    @PostMapping("/campaign/create")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_CREATE)
    public Campaign createCampaign(@RequestBody Campaign campaign) {
       // System.out.println("BEFORE CREATING CAMPAIGN: " + campaign.getTracker());
     System.out.println("BEFORE CREATING CAMPAIGN, cmapaign user name: " + campaign.getUser());
        Campaign createdCampaign = campaignService.createCampaign(campaign);
        System.out.println("Id of campaign created:" + createdCampaign.getId());
            return createdCampaign;
    }

    @PutMapping("/campaign/update")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_EDIT)
    public Campaign saveOrUpdate(@RequestBody Campaign campaign){
        System.out.println("Before updating campaign! CAMPAIGN UPDATE CALLED WITH ID:" + campaign.getId());
        Campaign savedCampaign = campaignService.updateCampaign(campaign);
        System.out.println("Id of campaign updated:" + savedCampaign.getId());
        System.out.println("User firstName of campaign updated:" + savedCampaign.getUser().getFirstname() +  "" + savedCampaign.getUser().getLastname());
        System.out.println("Contents of campaign updated: ");
        for(Content campaignContent1 : savedCampaign.getContents())
            System.out.println("Content: " +  campaignContent1.getName());
            return campaign;
    }

    @GetMapping("campaign/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_DELETE)
    public void deleteCampaign(@PathVariable String id){
        System.out.println("Entered deleting campaign");
        Campaign campaign =  campaignService.findById(new Long(id));
        campaignService.deleteCampaign(Long.valueOf(id));
    }
}
