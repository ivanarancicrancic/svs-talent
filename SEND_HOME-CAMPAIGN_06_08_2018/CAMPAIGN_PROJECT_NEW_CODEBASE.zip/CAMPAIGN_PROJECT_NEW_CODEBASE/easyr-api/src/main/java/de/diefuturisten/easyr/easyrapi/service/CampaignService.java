package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.converter.CampaignCommandToCampaign;
import de.diefuturisten.easyr.easyrapi.converter.CampaignToCampaignCommand;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.request.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRespository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class CampaignService {

    private final CampaignRespository campaignRepository;
    private final UserRepository userRepository;

    public CampaignService(CampaignRespository campaignRepository, UserRepository userRepository) {
        this.campaignRepository = campaignRepository;
        this.userRepository = userRepository;

    }

    public Campaign createCampaign(Campaign campaign) {
        System.out.println("Creating campaign with: "  + campaign.getUser().getName());
        campaignRepository.save(campaign);
        Campaign savedCampaign = campaignRepository.findById(campaign.getId()).get();
        return savedCampaign;
    }

    public List<Campaign> getAllCampaigns() {
        return campaignRepository.findAll().stream().collect(Collectors.toList());

    }

    public Campaign updateCampaign(Campaign campaign) {
//        String status = "updating campaign";
//        System.out.println(status);
        userRepository.save(campaign.getUser());
        campaignRepository.save(campaign);
        Campaign savedCampaign = campaignRepository.findById(campaign.getId()).get();
        return savedCampaign;
    }

    public void deleteCampaign(Long id) {
//        String status = "deleting campaign";
//        System.out.println(status);
        campaignRepository.deleteById(id);

    }

    public Campaign findById(Long id) {
//        String status = "getting command campaign";
//        System.out.println(status);
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
//        if( !campaignOptional.isPresent() ){
//            throw new NotFoundException("Campaign Not Found for id:" + id.toString());
//        }
      //  CampaignCommand campaignCommand = campaignToCampaignCommand.convert(campaignOptional.get());
        return campaignOptional.get();
    }

}
