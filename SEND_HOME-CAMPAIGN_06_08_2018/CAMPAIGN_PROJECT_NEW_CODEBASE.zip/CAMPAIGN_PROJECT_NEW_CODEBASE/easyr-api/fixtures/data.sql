-- Users
INSERT INTO
  users(key_user, active, language, email, password, firstname, lastname, gender)
VALUES
  (1, true, 'de', 'christen@app-logik.de', '$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK', 'Oliver', 'Christen', true), -- password is "wuff"
  (2, false, 'en', 'ivica.taskovski@app-logik.de', '$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq', 'Ivica', 'Taskovski', true); --password is "miau"

ALTER SEQUENCE users_key_user_seq RESTART WITH 3;

-- Roles
INSERT INTO
  userroles(key_userrole, name, description)
VALUES
  (1, 'Standard', 'normal user'),
  (2, 'Admin', 'admin user');

ALTER SEQUENCE userroles_key_userrole_seq RESTART WITH 3;

-- User has Roles
INSERT INTO
  user_has_roles(fk_user, fk_userrole)
VALUES
  (1, 1),
  (1, 2),
  (2, 1);

-- Rights
INSERT INTO
  userrights(key_userright, description, name)
VALUES
  (1, 'CAMPAIGN_CREATE', 'CAMPAIGN_CREATE'),
  (2, 'CAMPAIGN_LIST', 'CAMPAIGN_LIST'),
  (3, 'CAMPAIGN_DELETE', 'CAMPAIGN_DELETE'),
  (4, 'CAMPAIGN_VIEW', 'CAMPAIGN_VIEW'),
  (5, 'CAMPAIGN_EDIT', 'CAMPAIGN_EDIT');

-- Role Has Rights
INSERT INTO
  role_has_rights(fk_userrole, fk_userright)
VALUES
  (1, 1),
  (1, 3),
  (1, 4),
  (1, 5),
  (2, 2),
  (2, 3);

--Contact Info
INSERT INTO
    contactinfos(key_contactinfo, address, address2, city, company,	email, homepage, name, number, zip)
VALUES
    (1, 'Klingel Stasse', 'Schmingel Strasse', 'Berlin', 'app-logik.de, 'ivica.taskovski@app-logik.de', 'Ivica', 'Taskovski', '+3456789012', '1234');
INSERT INTO
    campaigns(key_campaign, fk_contact, fk_user)
VALUES
    (1, 1, 1),
    (2, 1, 1);
