# Auth

## Login

Example Request:

```
curl -X POST \
  http://127.0.0.1:8080/login \
  -H 'Cache-Control: no-cache' \
  -H 'Content-Type: application/json' \
  -d '{"username": "christen@app-logik.de", "password": "wuff"}'
```