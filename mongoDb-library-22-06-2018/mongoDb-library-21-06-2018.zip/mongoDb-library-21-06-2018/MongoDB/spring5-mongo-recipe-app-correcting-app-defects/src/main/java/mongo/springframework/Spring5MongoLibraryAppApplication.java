package mongo.springframework;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring5MongoLibraryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring5MongoLibraryAppApplication.class, args);
	}
}
