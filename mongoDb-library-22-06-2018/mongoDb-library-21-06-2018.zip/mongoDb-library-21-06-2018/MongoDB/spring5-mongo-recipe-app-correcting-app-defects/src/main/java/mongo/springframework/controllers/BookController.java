package mongo.springframework.controllers;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.exceptions.NotFoundException;
import mongo.springframework.services.BookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;


@Slf4j
@Controller
public class BookController {

    private static final String BOOK_BOOKFORM_URL = "book/bookform";
    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/book/{id}/show")
    public String showById(@PathVariable String id, Model model){
        model.addAttribute("book", bookService.findCommandById(id));
        System.out.println("After model.addAttribute(book)....");
        return "book/show";
    }

    @GetMapping("book/new")
    public String newBook(Model model){
        model.addAttribute("book", new BookCommand());

        return "book/bookform";
    }

    @GetMapping("book/{id}/update")
    public String updateBook(@PathVariable String id, Model model){
        model.addAttribute("book", bookService.findCommandById(id));
        return BOOK_BOOKFORM_URL;
    }

    @PostMapping("book")
    public String saveOrUpdate(@Valid @ModelAttribute("book") BookCommand command, BindingResult bindingResult){

        if(bindingResult.hasErrors()){

            bindingResult.getAllErrors().forEach(objectError -> {
                System.out.println(objectError.toString());
            });

            return BOOK_BOOKFORM_URL;
        }

        BookCommand savedCommand = bookService.saveBookCommand(command);

        return "redirect:/book/" + savedCommand.getId() + "/show";
    }

    @GetMapping("book/{id}/delete")
    public String deleteById(@PathVariable String id){

        System.out.println("Deleting id: " + id);
        bookService.deleteById(id);
        return "redirect:/";
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NotFoundException.class)
    public ModelAndView handleNotFound(Exception exception){

        System.out.println("Handling not found!");
        System.out.println(exception.getMessage());

        ModelAndView modelAndView = new ModelAndView();

        modelAndView.setViewName("404error");
        modelAndView.addObject("exception", exception);
        return modelAndView;
    }

}
