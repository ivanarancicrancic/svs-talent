package mongo.springframework.services;

import mongo.springframework.commands.AuthorCommand;
import mongo.springframework.converters.AuthorCommandToAuthor;
import mongo.springframework.converters.AuthorToAuthorCommand;
import mongo.springframework.model.Author;
import mongo.springframework.model.Book;
import mongo.springframework.repositories.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class AuthorServiceImpl implements AuthorService{

    private final AuthorToAuthorCommand authorToAuthorCommand;
    private final AuthorCommandToAuthor authorCommandToAuthor;
    private final BookRepository bookRepository;

    public AuthorServiceImpl(AuthorToAuthorCommand authorToAuthorCommand, AuthorCommandToAuthor authorCommandToAuthor, BookRepository bookRepository) {
        this.authorToAuthorCommand = authorToAuthorCommand;
        this.authorCommandToAuthor = authorCommandToAuthor;
        this.bookRepository = bookRepository;
    }

    @Override
    public AuthorCommand findByBookIdAndAuthorId(String bookId, String authorId) {
        System.out.println("Before bookRepository.findById(bookId)");
        Optional<Book> bookOptional = bookRepository.findById(bookId);
        System.out.println("After bookRepository.findById(bookId)");

        if (!bookOptional.isPresent()){
            System.out.println("book id not found. Id: " + bookId);
        }
        Book book = bookOptional.get();
        System.out.println("After bookOptional.get()");

        Optional<AuthorCommand> authorCommandOptional = book.getAuthors().stream()
                .filter(author -> author.getId().equals(authorId))
                .map( author -> authorToAuthorCommand.convert(author)).findFirst();

        if(!authorCommandOptional.isPresent()){
            System.out.println("Author id not found: " + authorId);
        }

        AuthorCommand authorCommand = authorCommandOptional.get();
        System.out.println("After authorCommandOptional.get()");

        authorCommand.setBookId(bookId);
        System.out.println("Author id to be returned: " + authorCommandOptional.get().getId());
        return authorCommandOptional.get();
    }

    @Override
    public AuthorCommand saveAuthorCommand(AuthorCommand command) {
        System.out.println("Entered saveAuthorCommand(AuthorCommand), AuthorCommand ID: " + command.getId());
        Optional<Book> bookOptional = bookRepository.findById(command.getBookId());
        if(!bookOptional.isPresent()){
            System.out.println("Book not found for id: " + command.getBookId());
            return new AuthorCommand();
        } else {
            Book book = bookOptional.get();
            System.out.println("BookOptional id: " + book.getId());

            Optional<Author> authorOptional = book
                    .getAuthors()
                    .stream()
                    .filter(author -> author.getId().equals(command.getId()))
                    .findFirst();

            if(authorOptional.isPresent()){
                Author authorFound = authorOptional.get();
                authorFound.setFirstname(command.getFirstname());
                authorFound.setLastname(command.getLastname());
                System.out.println("AuthorOptional present! ");
            } else {
                Author author = authorCommandToAuthor.convert(command);
                book.addAuthor(author);
            }
            Book savedBook = bookRepository.save(book);

            Optional<Author> savedAuthorOptional = savedBook.getAuthors().stream()
                    .filter(bookAuthors -> bookAuthors.getId().equals(command.getId()))
                    .findFirst();

            if(!savedAuthorOptional.isPresent()){
                System.out.println("SavedAuthorOptional not present! ");
                savedAuthorOptional = savedBook.getAuthors().stream()
                        .filter(bookAuthors -> bookAuthors.getFirstname().equals(command.getFirstname()))
                        .filter(bookAuthors -> bookAuthors.getLastname().equals(command.getLastname()))
                        .findFirst();
            }

            System.out.println("AuthorOptional converted to AuthorCommand - id: " + savedAuthorOptional.get().getId());
                    AuthorCommand convertedAuthor = authorToAuthorCommand.convert(savedAuthorOptional.get());
                    convertedAuthor.setBookId(book.getId());

                    return  convertedAuthor;
        }

    }

    @Override
    public void deleteById(String bookId, String idToDelete) {

        System.out.println("Deleting author: " + bookId + ":" + idToDelete);

        Optional<Book> bookOptional = bookRepository.findById(bookId);

        if(bookOptional.isPresent()){
            Book book = bookOptional.get();
            System.out.println("found book");

            Optional<Author> authorOptional = book
                    .getAuthors()
                    .stream()
                    .filter(author -> author.getId().equals(idToDelete))
                    .findFirst();

            if(authorOptional.isPresent()){
                System.out.println("found Author");
                Author authorToDelete = authorOptional.get();
                book.getAuthors().remove(authorOptional.get());
                bookRepository.save(book);
            }
        } else {
            System.out.println("Book id not found. Id:" + bookId);
        }
    }
}
