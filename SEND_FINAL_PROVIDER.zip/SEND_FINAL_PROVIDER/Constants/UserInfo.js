// овие информации се зачувани како userInfo во localStorage
{
    "providerId": 156,
    "firstName": "Bojan",
    "typeProvider": null,
    "middleInitial": null,
    "lastName": "Janevski",
    "streetAdress": null,
    "city": null,
    "state": null,
    "zip": null,
    "phone": "070334677",
    "alternatePhone": null,
    "status": 0,
    "created": null,
    "createdBy": null,
    "modified": null,
    "modifiedBy": null,
    "deviceId": "XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX",
    "activationCode": 111111,
    "chatId": "sdhafs8fsda9fas"
}