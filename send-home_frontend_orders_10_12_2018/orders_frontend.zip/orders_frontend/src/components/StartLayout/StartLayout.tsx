import * as React from 'react';
import { connect } from 'react-redux';

import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
// import { Button } from "@blueprintjs/core";

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
}


type IProps = IPropsDispatchMap & IPropsStateMap

class StartLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: []

      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
         
    }

    public componentWillMount() {
    
        this.props.orderListFetch();        
        console.log("Date on mount: " + this.state.dateFrom);
    
    }


    public componentWillReceiveProps(nextProps: IProps) {

            this.setState({filteredOrders: nextProps.filteredOrderData});
            console.log("Filtered orders: " + this.state.filteredOrders);
            
    }


    public handleFilter(values:any){
        console.log("entered handle filter");
       
        values.preventDefault();
        // console.log("this.state.dateFrom on handleFilter: "  + this.state.dateFrom);
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
      
        // history.push(`/start`);
        // this.setState({filteredOrders: this.props.filteredOrderData});
        // this.forceUpdate();
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        console.log("State for selected dateFrom: " + this.state.dateFrom)
        
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
     this.setState({dateTo: entryDate}); 
     console.log("State for selected dateTo: " + this.state.dateTo)
     
  };

 public renderOrderList() {

        if(!this.props.orderData && !this.props.filteredOrderData) 
         {    
             console.log("this.props.orderData: " + this.props.orderData);
            console.log("this.props.orderData and this.props.filteredOrderData is null");
            return null;
         }
         else if(!this.props.orderData)
             {
                 if(this.props.filteredOrderData)
                 {
            return (
                <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>Payment Method </th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>CompanyName </th>
                                    <th>Country </th>
                                    <th>Email </th>
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id}>
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.paymentMethod} </td>
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.companyName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.email} </td>
                                    
                                </tr>
                            )
                        })}
                      
                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
            ) 
           }
             else { return null;} 
        }

        else if(!this.props.filteredOrderData)
        {
            if(this.props.orderData)
            {
       return (
           <div className="dashboardTable">
               <table className="table bp3-html-table bp3-html-table-bordered">
               <thead>                  
               <tr>
                       <th>Order ID</th>
                       <th>Oder DATE</th>
                       <th>Payment Method </th>
                       <th>FirstName </th>
                               <th>LastName </th>
                               <th>CompanyName </th>
                               <th>Country </th>
                               <th>Email </th>
                       </tr>

               </thead>
               <tbody>
                   
                   {this.props.orderData.map( order => {
                       return (
                           <tr key={order.order_id}>
                               <td><b>{order.order_id}</b></td>
                               <td>{order.orderDate} </td> 
                               <td>{order.paymentMethod} </td>
                               <td>{order.firstName} </td>
                               <td>{order.lastName} </td>
                               <td>{order.companyName} </td>
                               <td>{order.country} </td>
                               <td>{order.email} </td>
                               
                           </tr>
                       )
                   })}
                 
                   <tr>
                   <td colSpan={5} className="text-center" >
                      <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                   </td>
                   </tr>
               </tbody>
               </table>
           </div>
       ) 
      }
        else { return null;} 
   }
        
         else {
            console.log("!this.props.filteredOrderData =! NULL !!!!!!!!!!!!!!!!! AND this.props.orderData =! NULL");

             if(this.props.orderData[0].latest> this.props.filteredOrderData[0].latest)
      {
          console.log("this.props.orderData[0].latest> this.props.filteredOrderData[0].latest !!!!!!!!!!");
             return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <thead>                  
                <tr>
                        <th>Order ID</th>
                        <th>Oder DATE</th>
                        <th>Payment Method </th>
                        <th>FirstName </th>
                                <th>LastName </th>
                                <th>CompanyName </th>
                                <th>Country </th>
                                <th>Email </th>
                        </tr>

                </thead>
                <tbody>
                    
                    {this.props.orderData.map( order => {
                        return (
                            <tr key={order.order_id}>
                                <td><b>{order.order_id}</b></td>
                                <td>{order.orderDate} </td> 
                                <td>{order.paymentMethod} </td>
                                <td>{order.firstName} </td>
                                <td>{order.lastName} </td>
                                <td>{order.companyName} </td>
                                <td>{order.country} </td>
                                <td>{order.email} </td>
                                
                            </tr>
                        )
                    })}
                  
                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }
    else {

        console.log("this.props.orderData[0].latest < this.props.filteredOrderData[0].latest");
        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <thead>                  
                <tr>
                        <th>Oooooorder ID</th>
                        <th>Oder DATE</th>
                        <th>Payment Method </th>
                        <th>FirstName </th>
                                <th>LastName </th>
                                <th>CompanyName </th>
                                <th>Country </th>
                                <th>Email </th>
                        </tr>

                </thead>
                <tbody>
                    
                    {this.props.filteredOrderData.map( order => {
                        return (
                            <tr key={order.order_id}>
                                <td><b>{order.order_id}</b></td>
                                <td>{order.orderDate} </td> 
                                <td>{order.paymentMethod} </td>
                                <td>{order.firstName} </td>
                                <td>{order.lastName} </td>
                                <td>{order.companyName} </td>
                                <td>{order.country} </td>
                                <td>{order.email} </td>
                                
                            </tr>
                        )
                    })}
                  
                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }
    }
}

    public render() {
        return (
            <div className="grid100">
              
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}/> 
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker onChange={this.handleDateTo}/>
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

        </form>



        {/* <DatePicker
    
          onChange={this.handleDateFrom}
        /> &nbsp; &nbsp; &nbsp;
        <b>       End date: </b>
                <DatePicker
          onChange={this.handleDateTo}
        />
        &nbsp; &nbsp; &nbsp;

       <Button className="bp3-button" onClick={this.handleFilter }  text="Filter"/>             */}

      </div>
              <br/>
                {this.renderOrderList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch})(StartLayout)