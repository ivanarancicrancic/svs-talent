import * as React from 'react';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";

import { RouteComponentProps, Switch, Route } from 'react-router';
import { PATH_START, PATH_ORDER_DETAIL, PATH_ORDER_EDIT, PATH_FILTERED_ORDERS } from '../../router/paths';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
import StartLayout from '../../components/StartLayout/StartLayout';
import ManageOrder from '../../components/ManageOrder/ManageOrder';
import EditOrder from '../../components/EditOrder/EditOrder';
import FilteredOrders from '../../components/FilteredOrders/FilteredOrders';

library.add(faEnvelope, faKey);


type IProps = RouteComponentProps<{}>;

export default class App extends React.Component<IProps> {

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_START} exact={true} component={StartLayout} />
            <Route path={PATH_ORDER_DETAIL} exact={true} component={ManageOrder} />
            <Route path={PATH_ORDER_EDIT} exact={true} component={EditOrder} />
            <Route path={PATH_FILTERED_ORDERS} exact={true} component={FilteredOrders} />
            
         </Switch>
        </div>
        <Footer />
      </div>
    );
  }


}


