import { IRootState } from '..'

export const getDecrementedQuantity = (state: IRootState) => state.decrementedQuantity.data;
export const getDecrementedQuantityLoading = (state: IRootState) => state.decrementedQuantity.loading;
export const getDecrementedQuantityHasError = (state: IRootState) => state.decrementedQuantity.error;