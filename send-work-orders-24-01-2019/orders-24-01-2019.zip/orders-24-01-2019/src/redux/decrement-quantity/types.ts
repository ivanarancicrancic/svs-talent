// import { StringOrSymbol } from "../../../node_modules/typesafe-actions/dist/types";

export const DECREMENT_QUANTITY_FETCH = '@@user/decrement/quantity/FETCH';
export const DECREMENT_QUANTITY_SUCCESS = '@@user/decrement/quantity/SUCCESS';
export const DECREMENT_QUANTITY_FAIL = '@@user/decrement/quantity/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};


export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};


export interface IOrderArticleQuantityRequestModel {

    orArId: string;
    quantity: string;

}
