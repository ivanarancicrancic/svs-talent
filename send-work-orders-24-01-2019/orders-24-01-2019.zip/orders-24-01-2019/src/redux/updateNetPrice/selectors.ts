import { IRootState } from '..'

export const getResultUpdateNetPriceState = (state: IRootState) => state.resultUpdateNetPrice.data;
export const getResultUpdateNetPriceLoading = (state: IRootState) => state.resultUpdateNetPrice.loading;
export const getResultUpdateNetPriceHasError = (state: IRootState) => state.resultUpdateNetPrice.error;