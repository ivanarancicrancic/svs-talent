import { IRootState } from '..'

export const getSavedOrder = (state: IRootState) => state.savedOrder.data;
export const getSavedOrderLoading = (state: IRootState) => state.savedOrder.loading;
export const getSavedOrderHasError = (state: IRootState) => state.savedOrder.error;