import {
    ORDER_SAVE_FETCH,
    ORDER_SAVE_SUCCESS,
    ORDER_SAVE_FAIL,
    IOrderDetailResponseModel,
    IOrderSaveRequestModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const orderSaveFetch = createStandardAction(ORDER_SAVE_FETCH)<{orderToSave: IOrderSaveRequestModel}>();
export const orderSaveSuccess = createStandardAction(ORDER_SAVE_SUCCESS)<IOrderDetailResponseModel>();
export const orderSaveFail = createStandardAction(ORDER_SAVE_FAIL)<string>();

