import { ActionType, getType } from 'typesafe-actions';
import { IOrderDetailResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type OrderSaveActions = ActionType<typeof extActions>;

export interface IOrderSaveState {
    readonly data: IOrderDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IOrderSaveState = {
    data: null,
    loading: false,
    error: null
};
  
export function orderSaveReducer(state: IOrderSaveState = INITIAL_STATE, action: OrderSaveActions): IOrderSaveState  {
    switch (action.type) {
        case getType(extActions.orderSaveFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.orderSaveSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.orderSaveFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}