import {
    DELETE_ARTICLE_FROM_ORDER_FETCH,
    DELETE_ARTICLE_FROM_ORDER_SUCCESS,
    DELETE_ARTICLE_FROM_ORDER_FAIL,

} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IOrderDetailResponseModel } from '../delete-article/types';

export const deleteArticleFromOrderFetch = createStandardAction(DELETE_ARTICLE_FROM_ORDER_FETCH)<{orArId: string}>();
export const deleteArticleFromOrderSuccess = createStandardAction(DELETE_ARTICLE_FROM_ORDER_SUCCESS)<IOrderDetailResponseModel>();
export const deleteArticleFromOrderFail = createStandardAction(DELETE_ARTICLE_FROM_ORDER_FAIL)<string>();

