export const DELETE_ARTICLE_FROM_ORDER_FETCH = '@@user/order/article/delete/FETCH';
export const DELETE_ARTICLE_FROM_ORDER_SUCCESS = '@@user/order/article/delete/SUCCESS';
export const DELETE_ARTICLE_FROM_ORDER_FAIL = '@@user/order/article/delete/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};



export interface IOrderSaveRequestModel {
    order_id: string;
    orderDate: Date;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};