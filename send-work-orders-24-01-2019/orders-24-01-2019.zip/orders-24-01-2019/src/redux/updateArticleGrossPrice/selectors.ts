import { IRootState } from '..'

export const getResultUpdateGrossPriceState = (state: IRootState) => state.resultUpdateGrossPrice.data;
export const getResultUpdateGrossPriceLoading = (state: IRootState) => state.resultUpdateGrossPrice.loading;
export const getResultUpdateGrossPriceHasError = (state: IRootState) => state.resultUpdateGrossPrice.error;