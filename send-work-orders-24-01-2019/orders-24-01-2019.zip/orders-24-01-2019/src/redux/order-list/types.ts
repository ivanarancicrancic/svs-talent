export const ORDER_LIST_FETCH = '@@user/order/list/FETCH';
export const ORDER_LIST_SUCCESS = '@@user/order/list/SUCCESS';
export const ORDER_LIST_FAIL = '@@user/order/list/FAIL';

export const ORDER_CREATE_FETCH = '@@order/create/FETCH';
export const ORDER_CREATE_SUCCESS = '@@order/create/SUCCESS';
export const ORDER_CREATE_FAIL = '@@order/create/FAIL';

export interface IOrderResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
    status: string;
    cancelReason: string;
};