import {
    GET_ARTICLES_FETCH,
    GET_ARTICLES_SUCCESS,
    GET_ARTICLES_FAIL,
    IArticleResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const getArticlesFetch = createStandardAction(GET_ARTICLES_FETCH)();
export const getArticlesSuccess = createStandardAction(GET_ARTICLES_SUCCESS)<IArticleResponseModel[]>();
export const getArticlesFail = createStandardAction(GET_ARTICLES_FAIL)<string>();
