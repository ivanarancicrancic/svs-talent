import { IRootState } from '..'

export const getArticles = (state: IRootState) => state.articlesList.data;
export const getArticlesIsLoading = (state: IRootState) => state.articlesList.loading;
export const getArticlestHasError = (state: IRootState) => state.articlesList.error;