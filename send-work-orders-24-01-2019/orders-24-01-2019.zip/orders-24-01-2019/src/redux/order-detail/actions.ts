import {
    ORDER_DETAIL_FETCH,
    ORDER_DETAIL_SUCCESS,
    ORDER_DETAIL_FAIL,
    IOrderDetailResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const orderDetailFetch = createStandardAction(ORDER_DETAIL_FETCH)<{orderId: string}>();
export const orderDetailSuccess = createStandardAction(ORDER_DETAIL_SUCCESS)<IOrderDetailResponseModel>();
export const orderDetailFail = createStandardAction(ORDER_DETAIL_FAIL)<string>();
