import {
    CANCEL_ORDER_FETCH,
    CANCEL_ORDER_SUCCESS,
    CANCEL_ORDER_FAIL,
    IOrderDetailResponseModel,
    IOrderCancelRequestModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const cancelOrderFetch = createStandardAction(CANCEL_ORDER_FETCH)<{order_to_cancel: IOrderCancelRequestModel}>();
export const cancelOrderSuccess = createStandardAction(CANCEL_ORDER_SUCCESS)<IOrderDetailResponseModel>();
export const cancelOrderFail = createStandardAction(CANCEL_ORDER_FAIL)<string>();
