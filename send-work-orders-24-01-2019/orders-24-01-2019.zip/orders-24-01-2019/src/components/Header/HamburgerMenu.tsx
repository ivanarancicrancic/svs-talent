import * as React from 'react';
import './HamburgerMenu.css';
import {Link} from "react-router-dom";
import {PATH_ROOT} from "../../router/paths";
import { Translate } from 'react-redux-i18n';

export default class HamburgerMenu extends React.Component{

    public render() {
        return (
            <div>
              
                <nav role="navigation">
                <div className="menuToggle">
                    <input type="checkbox" />
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                        <ul className="menu">
                            <Link to={PATH_ROOT} className="bp3-navbar-heading">1 <Translate value="header.account" /></Link>
                            <div className="searchBtn"> <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span> </div>
                        </ul>
                </div>
                </nav>
            </div>
        );
    }
}


// export default connect()(HamburgerMenu)