import * as React from 'react';
import { connect } from 'react-redux';
// import { Link } from "react-router-dom";
import { history } from '../../router';
import './FilteredOrders.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { IOrderSaveRequestModel } from '../../redux/order-save/types';
import { IOrderCancelRequestModel } from '../../redux/cancelOrders/types';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
}

type IProps = IPropsDispatchMap & IPropsStateMap

class FilteredOrders extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modalIsOpen: false,
           modal2IsOpen: false,
           currentOrder: null,
           orderFirstNameToBeSaved: null,
           orderLastNameToBeSaved: null,
           orderCompanyNameToBeSaved: null,
           orderPaymentMethodToBeSaved: null,
           orderShippingWayToBeSaved: null,
           orderAnredeToBeSaved: null,
           orderCountryToBeSaved: null,
           orderStreetToBeSaved: null,
           orderHouseNumberToBeSaved: null,
           orderPostcodeToBeSaved: null,
           orderCityToBeSaved: null,
           orderPhoneNumberToBeSaved: null,
           orderEmailToBeSaved: null,
           orderNetPriceToBeSaved: null,
           orderGrossPriceToBeSaved: null,
           orderNetPriceWDToBeSaved: null,
           orderGrossPriceWDToBeSaved: null,
           orderToSave: null
        

      }
    
      constructor(props: any) {
        super(props);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.editOrder = this.editOrder.bind(this);
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleCancelOrder = this.handleCancelOrder.bind(this);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
    }

public editOrder(){
    this.setState({modalIsOpen: false}); 
    this.setState({modal2IsOpen: true}); 
}

  public handleSubmitSaveOrder(value:any) {
      
    const newValues: IOrderSaveRequestModel = {

        order_id: value.order_id,
        orderDate: new Date(),
        paymentMethod: value.paymentMethod,
        shippingWay: value.shippingWay,
        anrede: "anrede",
        firstName: value.firstName,
        lastName: value.lastName,
        companyName: value.companyName,
        country: value.country,
        street: value.street,
        houseNumber: value.houseNumber,
        city: value.city,
        postcode: value.postcode,
        phoneNumber: value.phoneNumber, 
        email: value.email, 
        latest: 1,
        netPrice: value.netPrice,
        grossPrice: value.grossPrice,
        netPriceWD:  value.netPriceWD,
        grossPriceWD: value.grossPriceWD 

    }

   this.props.orderSaveFetch({orderToSave: newValues});
   this.props.orderDetailFetch({orderId: newValues.order_id});
   this.props.orderListFetch();      

   this.setState({modalIsOpen: false}); 
   this.setState({modal2IsOpen: false});
   history.push('/start');
}

public handleCancelOrder(order:IOrderResponseModel) {
    
    const orderId = order.order_id;
    this.props.orderDetailFetch({orderId});
    this.setState({modal3IsOpen: true});
    this.setState({modalIsOpen: false}); 
    this.setState({modal2IsOpen: false});
 
 }
 
 public handleSubmitCancelOrderWithReason(value:any) {
     
    const cancelValues: IOrderCancelRequestModel = {
        order_id: value.order_id,
        cancelReason: value.order_cancel_reason
    }

    this.setState({modal3IsOpen: false});
    this.props.cancelOrderFetch({order_to_cancel: cancelValues});
    this.setState({modalIsOpen: false}); 
    this.setState({modal2IsOpen: false});
    history.push('/start');
 
 }
     
    public selectedRowHandel(order: IOrderResponseModel){
        const order_id = order.order_id;
        const orderId = order_id;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({orderId});
        history.push(`/order/${order_id}`);
        }

        public handleFilter(values:any){
            values.preventDefault();
            const startDate = this.state.dateFrom;
            const endDate = this.state.dateTo;
            this.props.filterOrderFetch({startDate, endDate});
          };
     
    
       public handleDateFrom(entryDate: any){
            this.setState({dateFrom: entryDate}); 
            this.setState({
                dateFrom: entryDate
              }, () => console.log(this.state.dateFrom));
          };
    
       public handleDateTo(entryDate: any){
        console.log("SELECTED DATE: " + entryDate);
         this.setState({
            dateTo: entryDate
          }, () => console.log(this.state.dateTo)); 
      };
    

 public renderFilteredOrderList() {

    let totalNetPriceF = 0;
    let totalGrossPriceF = 0;
    let totalNetPriceWDF = 0;
    let totalGrossPriceWDF = 0;
   

    if(this.props.filteredOrderData)
            {
            const ordersNetPricesF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPrice, 10)
                 )
             })

             const ordersGrossPricesF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.grossPrice, 10)
                 )
             })
            
             const ordersNetPricesWDF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPriceWD, 10)
                 )
             })

             const ordersGrossPricesWDF = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
             })

     
        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPriceF = ordersNetPricesF.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPriceF = ordersGrossPricesF.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWDF = ordersNetPricesWDF.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWDF = ordersGrossPricesWDF.reduce(summingReducer3, 0);
     
          }
          else {
              
            totalNetPriceF = 0;
            totalGrossPriceF = 0;
            totalNetPriceWDF = 0;
            totalGrossPriceWDF = 0;

            }      
           
            if(this.props.filteredOrderData){
                return(
                    <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>Country </th>
                                    <th>Company </th>
                                    <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)} className = "order_hovered"> 
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.companyName} </td>
                                    <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>

                                </tr>
                            )
                        })}
                      
                      
                      <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price:
                      { totalNetPriceF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price:
                      { totalGrossPriceF
                      } 

                    </td>
                    </tr>
 
                     <tr>
                    <td colSpan={5} className="text-center td" >
                       Total net price (without delivery):
                      { totalNetPriceWDF
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center td1" >
                       Total gross price (without delivery):
                      { totalGrossPriceWDF
                      } 

                    </td>
                    </tr>

                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
                )
            }
           else{
        return null;   
        }
}

    public render() {
        
        if(this.props.orderDetailData){
            if(!this.props.orderArticlesData)
            {
           return (
            <div className="grid100">
    
             <b> Filter orders by date range: </b> <br/>
             <div>
               
     <form onSubmit={ this.handleFilter }>
         <div className="bp3-input-group">
     <b>  Start date: </b> 
                             
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

        </form>

      </div>
              <br/>
                {this.renderFilteredOrderList()}   
            </div>
        )
    }
   else{
    return (
        <div className="grid100">

         <b> Filter orders by date range: </b> <br/>
         <div>
           

 <form onSubmit={ this.handleFilter }>
     <div className="bp3-input-group">
 <b>  Start date: </b> 
                         
      <DatePicker 
      onChange={this.handleDateFrom}
      value={this.state.dateFrom}
      />   
      &nbsp; &nbsp; &nbsp;
      <b> End date: </b>
      <DatePicker 
   onChange={this.handleDateTo} 
   value={this.state.dateTo} 
   />
      &nbsp; &nbsp; &nbsp;
                </div>
                  <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

    </form>

  </div>
          <br/>
            {this.renderFilteredOrderList()}   
        </div>
    )


   }

    }

    else {
        return (
            <div className="grid100">
   
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
            {this.renderFilteredOrderList()}   
            </div>
        )
    }
}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(FilteredOrders)


