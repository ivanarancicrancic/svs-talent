package de.diefuturisten.easyr.easyrapi.entity.campaign;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "trackers")
public class Tracker {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "key_tracker")
    private long id;

    @ManyToOne
    @JoinColumn(name = "fk_campaign", nullable = false)
    private Campaign campaign;

    @Column(name = "vuforia_id", nullable = false)
    private String vuforiaId;

    @Column(name = "url", nullable = false)
    private String url;

    // getter & setter
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public String getVuforiaId() {
        return vuforiaId;
    }

    public void setVuforiaId(String vuforiaId) {
        this.vuforiaId = vuforiaId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
