package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import java.util.Optional;

@Component
public interface SphereContentRepository extends JpaRepository<SphereContent, Long> {

}
