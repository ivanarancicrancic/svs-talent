package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.model.request.AudioContentList;
import de.diefuturisten.easyr.easyrapi.repository.AudioContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class AudioContentService {

    private AudioContentRepository audioContentRepository;
    private CampaignRepository campaignRepository;

    public AudioContentService(AudioContentRepository audioContentRepository, CampaignRepository campaignRepository) {
        this.audioContentRepository = audioContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public AudioContentList findAllAudios() {
        return new AudioContentList(audioContentRepository.findAll().stream().collect(Collectors.toList()));
    }

    public AudioContent findById(long audioId){
        return audioContentRepository.findById(audioId).get();
    }

    public void deleteAudioByCampaign(long id, long audioId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
         Content foundContent = optionalCampaign.get().getContents().stream().filter(content -> content.getId()==audioId).findFirst().get();
        optionalCampaign.get().getContents().remove(foundContent);
        campaignRepository.save(optionalCampaign.get());
    }

    public void saveAudioByCampaign(long id, AudioContent audioContent){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        Content foundContent = optionalCampaign.get().getContents().stream().filter(content -> content.getId()==audioContent.getId()).findFirst().get();
        optionalCampaign.get().getContents().remove(foundContent);
        optionalCampaign.get().getContents().add(audioContent);
        campaignRepository.save(optionalCampaign.get());
    }



}
