package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;

import java.util.List;

public class PanoramaContentList {
    private List<PanoramaContent> panoramaContentList;

    public PanoramaContentList(List<PanoramaContent> panoramaContentList) {
        this.panoramaContentList = panoramaContentList;
    }

    public List<PanoramaContent> getPanoramaContentList() {
        return panoramaContentList;
    }

    public void setPanoramaContentList(List<PanoramaContent> panoramaContentList) {
        this.panoramaContentList = panoramaContentList;
    }
}
