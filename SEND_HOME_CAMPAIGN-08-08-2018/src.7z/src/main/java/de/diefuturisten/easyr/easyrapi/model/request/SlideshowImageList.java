package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;

import java.util.List;

public class SlideshowImageList {

    private List<SlideshowImage> slideshowImageList;

    public SlideshowImageList(List<SlideshowImage> slideshowImageList) {
        this.slideshowImageList = slideshowImageList;
    }

    public List<SlideshowImage> getSlideshowImageList() {
        return slideshowImageList;
    }

    public void setSlideshowImageList(List<SlideshowImage> slideshowImageList) {
        this.slideshowImageList = slideshowImageList;
    }
}
