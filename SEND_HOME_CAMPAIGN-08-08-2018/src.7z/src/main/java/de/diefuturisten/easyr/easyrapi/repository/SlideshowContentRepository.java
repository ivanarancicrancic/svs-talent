package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface SlideshowContentRepository extends JpaRepository<SlideshowContent, Long> {

    Optional<SlideshowContent> findByName(String name);
}
