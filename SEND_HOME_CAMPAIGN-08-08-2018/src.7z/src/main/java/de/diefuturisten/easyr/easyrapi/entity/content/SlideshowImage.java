package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="slideshow_images")
public class SlideshowImage {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_slideshowimage")
    private long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "key_content", nullable = false)
    private SlideshowContent slideshow;

    @Column(name="weight", nullable = false)
    private int weight;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public SlideshowContent getSlideshow() {
        return slideshow;
    }

    public void setSlideshow(SlideshowContent slideshow) {
        this.slideshow = slideshow;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
