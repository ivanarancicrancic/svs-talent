package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.repository.PanoramaContentRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class PanoramaContentService {

    private PanoramaContentRepository panoramaContentRepository;

    public PanoramaContentService(PanoramaContentRepository panoramaContentRepository) {
        this.panoramaContentRepository = panoramaContentRepository;
    }

    public List<PanoramaContent> findAllPanoramas() {
        return panoramaContentRepository.findAll().stream().collect(Collectors.toList());
    }

}
