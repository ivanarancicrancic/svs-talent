package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="content_webviews")
public class WebviewContent extends Content {

    @Column(name="url", nullable = false)
    private String url;

    // getter & setter

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
