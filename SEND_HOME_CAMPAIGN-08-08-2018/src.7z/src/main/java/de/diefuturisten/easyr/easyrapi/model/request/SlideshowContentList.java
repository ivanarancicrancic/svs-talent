package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;

import java.util.List;

public class SlideshowContentList {

    private List<SlideshowContent> slideshowContentList;

    public SlideshowContentList(List<SlideshowContent> slideshowContentList) {
        this.slideshowContentList = slideshowContentList;
    }

    public List<SlideshowContent> getSlideshowContentList() {
        return slideshowContentList;
    }

    public void setSlideshowContentList(List<SlideshowContent> slideshowContentList) {
        this.slideshowContentList = slideshowContentList;
    }
}
