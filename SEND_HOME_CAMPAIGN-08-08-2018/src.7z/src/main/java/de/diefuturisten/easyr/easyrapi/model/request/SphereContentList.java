package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;

import java.util.List;

public class SphereContentList {

    private List<SphereContent> sphereContentList;

    public SphereContentList(List<SphereContent> sphereContentList) {
        this.sphereContentList = sphereContentList;
    }

    public List<SphereContent> getSphereContentList() {
        return sphereContentList;
    }

    public void setSphereContentList(List<SphereContent> sphereContentList) {
        this.sphereContentList = sphereContentList;
    }
}
