package de.diefuturisten.easyr.easyrapi.integration;

import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;

import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class ContacInformationRepositoryTest {
    @Autowired
    ContactInformationRepository contactInformationRepository;


    @Before
    public void prepare() {
        IntegrationTestHelper.prepareContactData(contactInformationRepository);
    }
    @After
    public void cleanup(){
        IntegrationTestHelper.cleanupContactData(contactInformationRepository);
    }
    @Test
    @Transactional
    public void ContactInfoExists(){
        contactInformationRepository.findByEmail("ivica.taskovski@app-logik.de").get();
    }

    @Test(expected = NoSuchElementException.class)
    @Transactional
    public void infoNotExisting(){
        contactInformationRepository.findByEmail("no_info").get();
    }
}
