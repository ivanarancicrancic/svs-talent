package de.diefuturisten.easyr.easyrapi.integration;

import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRightRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.Transactional;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import java.util.NoSuchElementException;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.NONE)
public class UserRepositoryTest {
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserRoleRepository userRoleRepository;
    @Autowired
    UserRightRepository userRightRepository;

    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
    }

    @After
    public  void cleanup(){
        IntegrationTestHelper.cleanupUserData(userRepository);
    }

    @Test
    @Transactional
    public void userExists(){
        //userRepository.findByEmail("christen@app-logik.de").get();
        assertNotNull(userRepository.findByEmail("ivica.taskovski@app-logik.de").get());
    }

    @Test(expected = NoSuchElementException.class)
    @Transactional
    public void  userNotExisting(){
        userRepository.findByEmail("no_user").get();
    }

    @Test
    @Transactional
    public void roleExists(){
        assertNotNull(userRoleRepository.findByName("Admin").get());
    }

    @Test
    @Transactional
    public void userRightsExist(){
        assertEquals( "Admin role", userRightRepository.findByName("Admin role").get().getName());
    }

    @Test
    @Transactional
    public void userRightExistsByRole(){
        assertEquals("Admin role", userRoleRepository.findByName("Admin").get().getRights().stream().findFirst().get().getName() );
    }

}
