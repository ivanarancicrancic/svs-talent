package springframework.controllers.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import springframework.api.v1.model.UserDTO;
import springframework.api.v1.model.UserListDTO;
import springframework.services.UserService;

@RestController
//@Controller
@RequestMapping(UserController.BASE_URL)
//@RequestMapping("/api/v1/users/")
public class UserController {

    public static final String BASE_URL = "/api/v1/users/";

    @Autowired
    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

   //getAllCategories without rest controller
//    @GetMapping
//    public ResponseEntity<UserListDTO> getallCatetories(){
//        return new ResponseEntity<UserListDTO>(
//                new UserListDTO(userService.getAllUsers()), HttpStatus.OK);
//    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public UserListDTO getallCatetories(){
     return new UserListDTO(userService.getAllUsers());
    }


//    @GetMapping({"{id}"})
//    public ResponseEntity<UserDTO> getUserById(@PathVariable Long id){
//        System.out.println("Entered getUserById with id: " + id);
//        return new ResponseEntity<UserDTO>(userService.getUserById(id), HttpStatus.OK);
//    }

    @GetMapping({"{id}"})
    @ResponseStatus(HttpStatus.OK)
    public UserDTO getUserById(@PathVariable Long id){
        System.out.println("Entered getUserById with id: " + id);
        return userService.getUserById(id);
    }

//
//    @PostMapping
//    public ResponseEntity<UserDTO> createNewUser(@RequestBody UserDTO userDTO){
//        return new ResponseEntity<UserDTO>(userService.createNewUser(userDTO),
//                HttpStatus.CREATED);
//    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UserDTO createNewUser(@RequestBody UserDTO userDTO){
        return userService.createNewUser(userDTO);
    }


//    @PutMapping({"/{id}"})
//    public ResponseEntity<UserDTO> updateUser(@PathVariable Long id, @RequestBody UserDTO userDTO){
//
//        System.out.println("Update user called");
//        return new ResponseEntity<UserDTO>(userService.saveUserByDTO(id, userDTO),
//                HttpStatus.OK);
//    }

    @PutMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public UserDTO updateUser(@PathVariable Long id, @RequestBody UserDTO userDTO){

        System.out.println("Update user called");
        return userService.saveUserByDTO(id, userDTO);
    }

//    @PatchMapping({"/{id}"})
//    public ResponseEntity<UserDTO> patchUser(@PathVariable Long id, @RequestBody UserDTO userDTO){
//        System.out.println("called mapping patchUser");
//        return new ResponseEntity<UserDTO>(userService.patchUser(id, userDTO),
//                HttpStatus.OK);
//    }

    @PatchMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public UserDTO patchUser(@PathVariable Long id, @RequestBody UserDTO userDTO){
        System.out.println("called mapping patchUser");
        return userService.patchUser(id, userDTO);
    }


//    @DeleteMapping({"/{id}"})
//    public ResponseEntity<Void> deleteUser(@PathVariable Long id){
//
//        System.out.println("Entered deleteUser !");
//        userService.deleteCustomerById(id);
//
//        return new ResponseEntity<Void>(HttpStatus.OK);
//    }

    @DeleteMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public void deleteUser(@PathVariable Long id){

        System.out.println("Entered deleteUser !");
        userService.deleteCustomerById(id);

    }

}
