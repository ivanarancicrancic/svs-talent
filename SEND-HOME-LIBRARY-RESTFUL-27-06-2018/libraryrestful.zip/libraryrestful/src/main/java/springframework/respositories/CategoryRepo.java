package springframework.respositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import springframework.domain.Category;

@Component
public interface CategoryRepo extends JpaRepository<Category, Long> {
    Category findByName(String name);

}
