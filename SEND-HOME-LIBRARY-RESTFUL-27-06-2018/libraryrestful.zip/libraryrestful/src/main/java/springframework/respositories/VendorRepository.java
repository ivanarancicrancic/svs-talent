package springframework.respositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import springframework.domain.Vendor;

@Component
public interface VendorRepository extends JpaRepository<Vendor, Long> {
    Vendor findByName(String name);

}