package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import springframework.api.v1.model.UserDTO;
import springframework.api.v1.model.UserListDTO;
import springframework.domain.User;

import java.util.List;

@Component
public interface UserService {
    List<UserDTO> getAllUsers();
    UserDTO getUserById(Long id);
    UserDTO patchUser(Long id, UserDTO userDTO);
    UserDTO saveUserByDTO(Long id, UserDTO userDTO);
    UserDTO saveAndReturnDTO(User user);
    UserDTO createNewUser(UserDTO userDTO);
    void deleteCustomerById(Long id);
}
