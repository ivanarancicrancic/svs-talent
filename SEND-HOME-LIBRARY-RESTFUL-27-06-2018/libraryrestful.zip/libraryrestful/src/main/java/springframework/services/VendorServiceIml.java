package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springframework.api.v1.mapper.VendorDTOToVendorMapper;
import springframework.api.v1.mapper.VendorToVendorDTOMapper;
import springframework.api.v1.model.VendorDTO;
import springframework.api.v1.model.VendorListDTO;
import springframework.controllers.v1.VendorController;
import springframework.domain.Vendor;
import springframework.respositories.VendorRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Component
public class VendorServiceIml
        implements VendorService {

    private final VendorDTOToVendorMapper vendorMapper;
    private final VendorToVendorDTOMapper vendorToVendorDTOMapper;
    private final VendorRepository vendorRepository;

    public VendorServiceIml(VendorDTOToVendorMapper vendorMapper, VendorRepository vendorRepository, VendorToVendorDTOMapper vendorToVendorDTOMapper) {
        this.vendorMapper = vendorMapper;
        this.vendorRepository = vendorRepository;
        this.vendorToVendorDTOMapper = vendorToVendorDTOMapper;
    }

    @Override
    public VendorDTO getVendorById(Long id) {
        return vendorRepository.findById(id)
                .map(vendorToVendorDTOMapper::convert)
                .map(vendorDTO -> {
                    vendorDTO.setVendorUrl(getVendorUrl(id));
                    return vendorDTO;
                })
                .orElseThrow(ResourceNotFoundException::new);
    }

    @Override
    public VendorListDTO getAllVendors() {
        List<VendorDTO> vendorDTOS = vendorRepository
                .findAll()
                .stream()
                .map(vendor -> {
                    VendorDTO vendorDTO = vendorToVendorDTOMapper.convert(vendor);
                    vendorDTO.setVendorUrl(getVendorUrl(vendor.getId()));
                    return vendorDTO;
                })
                .collect(Collectors.toList());

        return new VendorListDTO(vendorDTOS);
    }

    @Override
    public VendorDTO createNewVendor(VendorDTO vendorDTO) {
        return saveAndReturnDTO(vendorMapper.convert(vendorDTO));
    }

    @Override
    public VendorDTO saveVendorByDTO(Long id, VendorDTO vendorDTO) {

        Vendor vendorToSave = vendorMapper.convert(vendorDTO);
        vendorToSave.setId(id);

        return saveAndReturnDTO(vendorToSave);
    }

    @Override
    public VendorDTO patchVendor(Long id, VendorDTO vendorDTO) {
        return vendorRepository.findById(id)
                .map(vendor -> {
                    //todo if more properties, add more if statements

                    if(vendorDTO.getName() != null){
                        vendor.setName(vendorDTO.getName());
                    }

                    return saveAndReturnDTO(vendor);
                }).orElseThrow(ResourceNotFoundException::new);
    }

    @Override
    public void deleteVendorById(Long id) {
        vendorRepository.deleteById(id);
    }

    public String getVendorUrl(Long id) {
        return VendorController.BASE_URL + "/" + id;
    }

    public VendorDTO saveAndReturnDTO(Vendor vendor) {
        Vendor savedVendor = vendorRepository.save(vendor);

        VendorDTO returnDto = vendorToVendorDTOMapper.convert(savedVendor);

        returnDto.setVendorUrl(getVendorUrl(savedVendor.getId()));

        return returnDto;
    }




}