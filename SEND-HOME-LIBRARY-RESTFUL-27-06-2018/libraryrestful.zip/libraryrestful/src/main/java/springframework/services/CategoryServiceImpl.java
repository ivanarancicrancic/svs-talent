package springframework.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springframework.api.v1.mapper.CategoryDTOToCategoryMapper;
import springframework.api.v1.mapper.CategoryToCategoryDTOMapper;
import springframework.api.v1.model.CategoryDTO;
import springframework.domain.Category;
import springframework.respositories.CategoryRepo;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Component
public class CategoryServiceImpl  implements CategoryService {

    @Autowired
    private final CategoryToCategoryDTOMapper categoryMapper;

    @Autowired
    private final CategoryDTOToCategoryMapper categoryDTOToCategoryMapper;

    @Autowired
    private final CategoryRepo categoryRepository;


    public CategoryServiceImpl(CategoryToCategoryDTOMapper categoryMapper, CategoryRepo categoryRepository, CategoryDTOToCategoryMapper categoryDTOToCategoryMapper) {
        this.categoryMapper = categoryMapper;
        this.categoryRepository = categoryRepository;
        this.categoryDTOToCategoryMapper= categoryDTOToCategoryMapper;
    }

    @Override
    public List<CategoryDTO> getAllCategories() {

        return categoryRepository.findAll()
                .stream()
                .map(categoryMapper::convert)
                .collect(Collectors.toList());
    }

    @Override
    public CategoryDTO getCategoryByName(String name) {
        return categoryMapper.convert(categoryRepository.findByName(name));
    }

    @Override
    public List<CategoryDTO> createNewCategory(CategoryDTO categoryDTO) {

        return saveAndReturnDTO(categoryDTOToCategoryMapper.convert(categoryDTO));
    }

    public List<CategoryDTO> saveAndReturnDTO(Category category) {
        Category savedCategory = categoryRepository.save(category);

        CategoryDTO returnDto = categoryMapper.convert(savedCategory);

       return getAllCategories();
    }

    @Override
    public List<CategoryDTO> saveCategoryByDTO(Long id, CategoryDTO categoryDTO) {
        Category category = categoryDTOToCategoryMapper.convert(categoryDTO);
        category.setId(id);

        return saveAndReturnDTO(category);
    }

    @Override
    public CategoryDTO patchCategoy(Long id, CategoryDTO categoryDTO) {
        return categoryRepository.findById(id).map(category -> {

            if(categoryDTO.getName() != null){
                category.setName(categoryDTO.getName());
            }

            return categoryMapper.convert(categoryRepository.save(category));
        }).orElseThrow(RuntimeException::new);
    }


}
