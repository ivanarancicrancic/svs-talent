package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springframework.api.v1.mapper.UserDTOToUserMapper;
import springframework.api.v1.mapper.UserToUserDTOMapper;
import springframework.api.v1.model.UserDTO;
import springframework.controllers.v1.UserController;
import springframework.domain.User;
import springframework.respositories.UserRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Component
public class UserServiceImpl implements UserService {

    private final UserDTOToUserMapper userMapper;
    private final UserRepository userRepository;
    private final UserToUserDTOMapper userToUserDTOMapper;

    public UserServiceImpl(UserDTOToUserMapper userMapper, UserRepository userRepository, UserToUserDTOMapper userToUserDTOMapper) {
        this.userMapper = userMapper;
        this.userRepository = userRepository;
        this.userToUserDTOMapper = userToUserDTOMapper;
    }

    @Override
    public List<UserDTO> getAllUsers() {
        return userRepository
                .findAll()
                .stream()
                .map(user -> {
                    UserDTO userDTO = userToUserDTOMapper.convert(user);
                    userDTO.setUserUrl("/api/v1/customers/" + user.getId());
                    return userDTO;
                })
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO getUserById(Long id) {
        System.out.println("Entered service getUserById with id: " + id);
        System.out.println("Returned id from userRepo: " + userRepository.findById(id));
        return userRepository.findById(id)
                .map(userToUserDTOMapper::convert)
                //.orElseThrow(RuntimeException::new);
                .orElseThrow(ResourceNotFoundException::new);
    }

    @Override
    public UserDTO createNewUser(UserDTO userDTO) {

        return saveAndReturnDTO(userMapper.convert(userDTO));
    }

    public UserDTO saveAndReturnDTO(User user) {
        User savedUser = userRepository.save(user);

        UserDTO returnDto = userToUserDTOMapper.convert(savedUser);

        returnDto.setUserUrl("/api/v1/user/" + savedUser.getId());

        return returnDto;
    }

    @Override
    public UserDTO saveUserByDTO(Long id, UserDTO userDTO) {
        User user = userMapper.convert(userDTO);
        user.setId(id);

        return saveAndReturnDTO(user);
    }

    @Override
    public UserDTO patchUser(Long id, UserDTO userDTO) {
        return userRepository.findById(id).map(user -> {

            if(userDTO.getFirstname() != null){
                user.setFirstname(userDTO.getFirstname());
            }

            if(userDTO.getLastname() != null){
                user.setLastname(userDTO.getLastname());
            }

            return userToUserDTOMapper.convert(userRepository.save(user));
        }).orElseThrow(ResourceNotFoundException::new);
    }


    private String getCustomerUrl(Long id) {
        return UserController.BASE_URL + "/" + id;
    }

    @Override
    public void deleteCustomerById(Long id) {
        userRepository.deleteById(id);
    }

}
