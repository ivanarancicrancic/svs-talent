package springframework.api.v1.model;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class UserListDTO {

    List<UserDTO> categories;

    public List<UserDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<UserDTO> categories) {
        this.categories = categories;
    }

    public UserListDTO(List<UserDTO> categories) {
        this.categories = categories;
    }

    public UserListDTO(){}

}
