package springframework.api.v1.mapper;


import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import springframework.api.v1.model.UserDTO;
import springframework.domain.User;

@Component
public class UserToUserDTOMapper implements Converter<User, UserDTO> {

    public UserToUserDTOMapper() {
    }


    @Nullable
@Override
public UserDTO convert(User source) {
        if (source == null) {
        return null;
        }

final UserDTO user = new UserDTO();
        user.setId(source.getId());
        user.setFirstname(source.getFirstname());
        user.setLastname(source.getLastname());
        user.setUserUrl(source.getUserUrl());
        return user;
        }
}
