package springframework.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import springframework.domain.Category;
import springframework.domain.User;
import springframework.domain.Vendor;
import springframework.respositories.CategoryRepo;
import springframework.respositories.UserRepository;
import springframework.respositories.VendorRepository;

@Component
public class Bootstrap implements CommandLineRunner {
    private CategoryRepo categoryRepository;
    private UserRepository userRepository;
    private VendorRepository vendorRepository;

    public Bootstrap(CategoryRepo categoryRepository, UserRepository userRepository, VendorRepository vendorRepository) {
        this.categoryRepository = categoryRepository;
        this.userRepository= userRepository;
        this.vendorRepository = vendorRepository;
    }

    @Override
    public void run(String... args) throws Exception {
       loadCategories();
       loadUsers();
       loadVendors();

    }

    private void loadVendors() {
        Vendor vendor1 = new Vendor();
        vendor1.setName("Vendor 1");
        vendorRepository.save(vendor1);

        Vendor vendor2 = new Vendor();
        vendor2.setName("Vendor 2");
        vendorRepository.save(vendor2);

    }

    private void loadCategories() {

        Category music = new Category();
        music.setName("Jazz");

        Category rock = new Category();
        music.setName("Alternative Rock");

        Category pop = new Category();
        pop.setName("Pop");

        Category hiphop = new Category();
        hiphop.setName("Hiphop");

        Category blues = new Category();
        blues.setName("Blues");

        Category soul = new Category();
        soul.setName("Soul");

        Category opera = new Category();
        opera.setName("Opera");


        Category reggae = new Category();
        reggae.setName("Reggae");

        Category clasical = new Category();
        clasical.setName("Clasical music");


        Category techno = new Category();
        techno.setName("Techno");


        Category funk = new Category();
        funk.setName("Funk");


        Category punk = new Category();
        punk.setName("Punk");

        Category country = new Category();
        country.setName("Country music");

        categoryRepository.save(music);
        categoryRepository.save(rock);
        categoryRepository.save(pop);
        categoryRepository.save(hiphop);
        categoryRepository.save(blues);
        categoryRepository.save(soul);
        categoryRepository.save(opera);
        categoryRepository.save(reggae);
        categoryRepository.save(clasical);
        categoryRepository.save(techno);
        categoryRepository.save(funk);
        categoryRepository.save(punk);
        categoryRepository.save(pop);
        categoryRepository.save(country);

        System.out.println("Categories Loaded = " + categoryRepository.count() );
    }

    private void loadUsers() {
        User user1 = new User();
        user1.setId(1l);
        user1.setFirstname("Ivana");
        user1.setLastname("Rancic");
        userRepository.save(user1);
        User user2 = new User();
        user2.setId(2l);
        user2.setFirstname("David");
        user2.setLastname("Bowie");
        userRepository.save(user2);
        System.out.println("Users Loaded: " + userRepository.count());
    }

}
