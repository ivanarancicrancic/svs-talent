import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';
import { IOrderListState, OrderListActions, orderListReducer } from './order-list/reducer';
import { IFilteredOrderState, FilterOrderActions, filterOrderReducer } from './filterOrders/reducer';
import { IOrderDetailState, OrderDetailActions, orderDetailReducer } from './order-detail/reducer';
import { IOrderArticlesState, GetOrderArtictlesActions, getOrderArticlesReducer } from './order-articles/reducer';
import { formsReducer } from './forms';
import { IOrderSaveState, OrderSaveActions, orderSaveReducer } from './order-save/reducer';
import { orderCancelReducer, OrderCancelActions } from './cancelOrders/reducer';


export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    orderList: IOrderListState;
    filteredOrders: IFilteredOrderState;
    orderDetail: IOrderDetailState;
    savedOrder: IOrderSaveState;
    orderArticles: IOrderArticlesState;
    canceledOrder: IOrderDetailState;  
    forms: any;
}

export type RootAction = RouterAction
    | LocationChangeAction
    | OrderListActions
    | FilterOrderActions 
    | OrderDetailActions
    | GetOrderArtictlesActions
    | OrderSaveActions
    | OrderCancelActions
   

export const reducers = combineReducers<IRootState>({
    router: routerReducer,
    i18n: i18nReducer, 
    orderList: orderListReducer,
    filteredOrders: filterOrderReducer,
    orderDetail: orderDetailReducer,
    savedOrder: orderSaveReducer,
    orderArticles: getOrderArticlesReducer,
    canceledOrder: orderCancelReducer,
    forms: formsReducer
});