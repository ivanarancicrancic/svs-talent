import * as React from 'react';
import { connect } from 'react-redux';
// import { Link } from "react-router-dom";
import { history } from '../../router';
import './ManageOrderLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
// import deIcon from '../../assets/images/edit_pencil.svg';
import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
// import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import EditableLabel from 'react-editable-label';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
// import { Button } from "@blueprintjs/core";
// import Box from 'react-editable-text/Box';
// import { Form, Control } from 'react-redux-form';

import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
// import { IOrderSaveRequestModel } from '../../redux/order-save/types';
import { RouteComponentProps } from 'react-router';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

// const customStyles = {
//     content : {
//       top                   : '50%',
//       left                  : '50%',
//       right                 : 'auto',
//       bottom                : 'auto',
//       marginRight           : '-50%',
//       transform             : 'translate(-50%, -50%)',
//       backgroundColor: 'rgba(25, 191, 114, 1)',
//       width: '100%'
//     }
//   };

class StartLayout extends React.Component<IProps>{
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modalIsOpen: false,
           modal2IsOpen: false,
           currentOrder: null,
           orderFirstNameToBeSaved: null,
           orderLastNameToBeSaved: null,
           orderCompanyNameToBeSaved: null,
           orderPaymentMethodToBeSaved: null,
           orderShippingWayToBeSaved: null,
           orderAnredeToBeSaved: null,
           orderCountryToBeSaved: null,
           orderStreetToBeSaved: null,
           orderHouseNumberToBeSaved: null,
           orderPostcodeToBeSaved: null,
           orderCityToBeSaved: null,
           orderPhoneNumberToBeSaved: null,
           orderEmailToBeSaved: null,
           orderNetPriceToBeSaved: null,
           orderGrossPriceToBeSaved: null,
           orderNetPriceWDToBeSaved: null,
           orderGrossPriceWDToBeSaved: null,
           orderToSave: null
        

      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.editOrder = this.editOrder.bind(this);
       
    }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        console.log("Entered manageOrder mount!!");
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({order_id: orderId});

    }


    // public componentWillReceiveProps(nextProps: IProps) {
    //         this.setState({filteredOrders: nextProps.filteredOrderData});
    //         this.setState({currentOrder: nextProps.orderDetailData})
    //         this.props.orderListFetch();  
           
    //         // if(nextProps.orderDetailData)
    //         // {
    //         // this.props.orderDetailFetch({order_id: nextProps.orderDetailData.order_id});
    //         // }
    //         console.log("Filtered orders: " + this.state.filteredOrders);
              
    // }

      public onSubmit(values:any) {
        
        console.log("Entered onEditOrder with firstName:" + values.firstname);
        history.push(`/start`);
      }


    public selectedRowHandel(order: IOrderResponseModel){
        console.log("SELECTED ORDER: " + order.firstName + order.order_id);
        const order_id = order.order_id;
        const orderId = order_id;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({order_id});
            // this.setState({modalIsOpen: true}); 
            history.push(`/order/${order_id}`);
   
        }

 
    public handleFilter(values:any){
        console.log("entered handle filter");
        values.preventDefault();
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
         
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
        
        console.log("State for selected dateFrom: " + this.state.dateFrom) 
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
    //  this.setState({dateTo: entryDate}); 
    
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
     console.log("State for selected dateTo: " + this.state.dateTo)
 
  };


  public closeModal() {
      console.log("Modal closed!!!");
    this.setState({modalIsOpen: false});
  }

  public editOrder(orderid:any){
      
    const orderId = orderid;
    console.log("Entered editORder with id: " + orderId);
    history.push(`/order/edit/${orderId}`);      

}

 
    public render() {
        
        console.log("this.state.modalIsOpen: " + this.state.modalIsOpen);
        if(this.props.orderDetailData){
            let start =0;
            const orderid= this.props.orderDetailData.order_id;
            //  this.openModal();
            console.log("!!!!  this.props.orderDetailData = NULL");
     
            if(this.props.orderArticlesData)
            {   
        return (
            <div className="grid100">
         {/* <div  style={{ position: "absolute", left: 20, overflowY: 'scroll' }}> */}
      <form>
    
      <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
      <br/>
 
     <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.firstName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.lastName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.companyName}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        />  </div><br/>
     <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                            initialValue={this.props.orderDetailData.paymentMethod}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.email}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.orderDate}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.phoneNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.shippingWay}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.street}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.houseNumber}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div><br/>
     <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.postcode}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                            initialValue={this.props.orderDetailData.city}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div> <br/>
     <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                            initialValue={this.props.orderDetailData.country}
                            save={(value:any) => {
                                console.log(`Saving '${value}'`);
                            }}
                        /> </div>
     <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
     <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
     <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
     <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
     <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
     <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
     
        {/* <input /> */}
       <br/>


       {/* <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id}) } > Included products >> </button>
     
     */}

      

        <div className = "modalTText">
        <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
       </div>
                
      </form>
     {/* </div> */}
      <div  style={{ position: "absolute", right: 80, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
     {this.props.orderArticlesData.map( orderArticle => {
                     start++;
                // console.log(" top:150 + start * 20 : " +  150 + start * 20 );
                const pos =  150 + start * 20;
                console.log("pos: " + pos);
                     return (
                
                        <div key={orderArticle.orderarticle_id}>
                           
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 200, height: 200, position: "absolute", right: 70, top: pos }} /> </tr>
                           <tr> <div style={{position: "absolute", right: 20, top: 370 }} > <b> ARTICLE NAME:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                           <tr> <div style={{position: "absolute", right: 135, top: 390 }} > <b> ARTICLE QUANTITY:  </b> &nbsp; {orderArticle.articleQuantity} </div></tr> 
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
                                    {/* <img className="bp3-button imgs" src={deIcon} alt="logo" /> */}
                                    {/* <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product from order </button></td> */}
                           </div>          
                       
                    )
                })}
      
          <br/>
                </div>
    
)

     

   }
   else{
    return (
        <div className="grid100">
  
  <form>
 <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div>
 
  <div style={{textAlign: 'center', fontFamily: "monospace", fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
  <br/>

 <div className="editableLabels"><label> <b>First name: </b></label>  &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.firstName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label ><b> Last name: </b> </label>&nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.lastName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label > <b>Company: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.companyName}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    />  </div><br/>
 <div className="editableLabels"><label > <b>Paying method: </b> </label >&nbsp;  &nbsp;  &nbsp; <EditableLabel
                        initialValue={this.props.orderDetailData.paymentMethod}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label ><b>e-mail: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.email}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label> <b>Order date: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.orderDate}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label > <b>Phone number: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.phoneNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label> <b>Shipping way: </b> </label > &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.shippingWay}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b>Street: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.street}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"><label > <b> House number: </b> </label > &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.houseNumber}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div><br/>
 <div className="editableLabels"> <label ><b>Postcode: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.postcode}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"> <label ><b>City: </b> </label> &nbsp;  &nbsp;  &nbsp;   <EditableLabel
                        initialValue={this.props.orderDetailData.city}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div> <br/>
 <div className="editableLabels"><label > <b>Country: </b> </label> &nbsp;  &nbsp;  &nbsp;  <EditableLabel
                        initialValue={this.props.orderDetailData.country}
                        save={(value:any) => {
                            console.log(`Saving '${value}'`);
                        }}
                    /> </div>
 <div><b>Net price: </b> &nbsp; {this.props.orderDetailData.netPrice}</div>
 <div><b>Gross price: </b> &nbsp;  {this.props.orderDetailData.grossPrice}</div>
 <div><b>Difference: </b> &nbsp; {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
 <div><b>Net price(without delivery): </b>  &nbsp;   {this.props.orderDetailData.netPriceWD}</div>
 <div><b>Gross price(without delivery): </b> &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
 <div><b>Difference(without delivery):</b>  &nbsp;   {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</div>
 
    {/* <input /> */}
   <br/>


   {/* <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.allOrderArticles}> Included 1 products >> </button>
    <button className="bp3-button" style={{backgroundColor : "#4682B4"}} onClick={(e) => this.props.getOrderArticlesFetch({order_id}) } > Included products >> </button>
 
 */}

  

    <div className = "modalTText">
    <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
   </div>
            
  </form>


  
      <br/>
            </div>
)
     }
      }

    else {
        return (
            <div className="grid100">
   
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
         
            </div>
        )
    }
}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(StartLayout)


// {this.props.orderArticlesData.map( orderArticle => {
//     return (
//         <tr key={orderArticle.orderarticle_id} className = "order_hovered">
//             <td><b>{orderArticle.orderarticle_id}</b></td>
//             <td>{orderArticle.order_id} </td> 
//             <td>{orderArticle.articleName} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>

//                     {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
//                     {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
//                     {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
//                     <img className="bp3-button imgs" src={deIcon} alt="logo" />
//                     <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                     
//         </tr>
//     )
// })}

// {this.props.orderArticlesData.map( orderArticle => {
//     return (

//         <tr key={orderArticle.orderarticle_id} >
//             <td><b>{orderArticle.order_id}</b></td>
//             <td>{orderArticle.articleName} </td> 
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>
//             <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product </button></td>
                     
//         </tr>
//     )
// })}