import * as React from 'react';
import {Link } from "react-router-dom";
import {PATH_ROOT, PATH_START} from "../../router/paths";

import './Header';
import logo from '../../assets/images/logo.png';

import HamburgerMenu from './HamburgerMenu';


export default class PostAuthHeader extends React.Component {

    public render() {
        console.log("entered render in postAuthHeader")
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_ROOT} className="bp3-navbar-heading"> <img src= { logo } /> </Link>
                            </span>
                            <div className="headerBox">
                                <Link to={PATH_START} className="bp3-navbar-heading">Orders</Link>
                                <Link to={PATH_START} className="bp3-navbar-heading">Sth else</Link>
                                  
                                  
                                </div>                       
                              
                            </div>
                                <div className="hamburgerMenu">
                                    <HamburgerMenu />
                                </div>
                        </div>
                </nav>
            </div>
        )
    }

   
}
