import * as React from 'react';
import PostAuthFooter from './PostAuthFooter';
import './Footer.css';

export default class Footer extends React.Component {
    public render() {
        return <PostAuthFooter /> 
    }
}
