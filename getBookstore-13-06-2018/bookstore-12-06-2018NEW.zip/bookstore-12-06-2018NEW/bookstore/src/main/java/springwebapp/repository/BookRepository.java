package springwebapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import springwebapp.model.Book;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public interface BookRepository extends JpaRepository<Book, Long>{

    public Optional<Book> findById(Long id);
}
