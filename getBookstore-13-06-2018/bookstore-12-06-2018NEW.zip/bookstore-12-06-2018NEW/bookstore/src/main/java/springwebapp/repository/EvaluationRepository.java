package springwebapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import springwebapp.model.Evaluation;

@Component
public interface EvaluationRepository extends CrudRepository<Evaluation, Long> {


}
