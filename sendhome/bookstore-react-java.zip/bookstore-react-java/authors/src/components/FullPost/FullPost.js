import React, { Component } from 'react';

import './FullPost.css';

class FullPost extends Component {
    state = {
        loadedBook: null
    }

    componentDidUpdate(){
        if(this.props.id) {

            if((!this.state.loadedBook) || (this.state.loadedBook && this.state.loadedBook.id !== this.props.id)){
                fetch('http://localhost:9575/book/show/' + this.props.id)
                    .then(response => response.json())
                    .then(data => {
                            console.log("Selected book: " + data.title);
                            this.setState({loadedBook: data});
                        }
                    );
            }


        }
    }

    render () {
        let post = <p style={{textAlign: 'center'}}>Please select a Book!</p>;
        if(this.props.id) {
             post = <p style={{textAlign: 'center'}}>Loading...</p>;

        }

        if(this.state.loadedBook) {

            post = (
                <div className="FullPost">
                    <h1>{this.state.loadedBook.title}</h1>
                    <p>{this.state.loadedBook.description}</p>
                    <div className="Edit">
                        <button className="Delete">Delete</button>
                    </div>
                </div>

            );
        }

        return post;
    }
}

export default FullPost;