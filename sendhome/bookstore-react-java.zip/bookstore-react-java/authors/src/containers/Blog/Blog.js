import React, { Component } from 'react';

import Post from '../../components/Post/Post';
import FullPost from '../../components/FullPost/FullPost';
import NewPost from '../../components/NewPost/NewPost';
import './Blog.css';

class Blog extends Component {
    //
    // state = {
    //     posts: []
    // }

    constructor(props){
        super(props);
        console.log('[Blog.js] Entered Constructor', props)
        this.state =  {
            books: [
            ],
            selectedPostId: null
        }

    }


    componentDidMount() {
        fetch('http://localhost:9575/books')
            .then(response => response.json())
            .then(data =>
            {
              //   this.setState({books: data});
              // const books1 = this.state.books.map(book => {
              //     fetch('http://localhost:9575/book/'+  book.id + '/authors')
              //         .then(response => response.json())
              //         .then(data => {console.log("yes", data); this.setState({authors: data}); });
              //
              //     return <Post title={book.title} authors={this.state.authors}/>;
              // });
        this.setState({books: data}); }
                );


    }

    postSelectedHandler = (id) => {
       this.setState({selectedPostId: id});

    }

    render () {
        const books = this.state.books.map(book => { var b = book.authors.map(author => {var a = author.firstName + ' ' + author.lastName; console.log(author.firstName + ' ' + author.lastName); return a;}); console.log("Book authors: " + book.authors); return <Post key={book.id} title={book.title} authors={b} clicked={() => this.postSelectedHandler(book.id)}/>});

        return (
            <div>
                <section className="Posts">
                    {books}
                </section>
                <section>
                    <FullPost id={this.state.selectedPostId}/>
                </section>
                <section>
                    <NewPost />
                </section>
            </div>
        );
    }
}

export default Blog;