package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.user.*;

public interface UserRightRepository extends org.springframework.data.jpa.repository.JpaRepository<UserRight, Long> {
    java.util.Optional<UserRight> findByName(String name);
}
