package de.ersatzteil.ersatzteilhandel24api;

@org.springframework.boot.autoconfigure.SpringBootApplication
@it.ozimov.springboot.mail.configuration.EnableEmailTools
public class ersatzteilHandel24 {
	public static void main(String[] args) {
	    org.springframework.boot.SpringApplication.run(ersatzteilHandel24.class, args);
	}
}
