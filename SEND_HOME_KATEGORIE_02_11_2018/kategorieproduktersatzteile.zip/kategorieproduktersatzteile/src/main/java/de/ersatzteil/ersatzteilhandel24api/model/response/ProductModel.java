package de.ersatzteil.ersatzteilhandel24api.model.response;

import de.diefuturisten.easyr.easyrapi.entity.product.*;

public class ProductModel {

    private String type;
    private long id;
    private String name;
    private int weight;

    public ProductModel() {

    }

    public ProductModel(Product product) {
        this.id = product.getId();
        this.name = product.getName();
        this.weight = product.getWeight();

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}

