package de.ersatzteil.ersatzteilhandel24api.model.request;

public class EditCategoryModel {

    @javax.validation.constraints.NotNull
    private Long id;

    @javax.validation.constraints.NotBlank
    private String name;

    public EditCategoryModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
