package de.ersatzteil.ersatzteilhandel24api.entity.user;

@javax.persistence.Entity
@javax.persistence.Table(name="userrights")
public class UserRight {

    @javax.persistence.Id
    @javax.persistence.GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Column(name="key_userright")
    private long id;

    @javax.persistence.Column(name = "name", length = 45)
    private String name;

    @javax.persistence.Column(name = "description", length = 245)
    private String description;

    @javax.persistence.ManyToMany(mappedBy = "rights", fetch = javax.persistence.FetchType.EAGER)
    private java.util.Set<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRole> roles = new java.util.HashSet<>();

    public UserRight() {
    }

    public UserRight(String name) {
        this.setName(name);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @com.fasterxml.jackson.annotation.JsonIgnore
    public java.util.Set<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRole> getRoles() {
        return roles;
    }

    public void setRoles(java.util.Set<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRole> roles) {
        this.roles = roles;
    }
}
