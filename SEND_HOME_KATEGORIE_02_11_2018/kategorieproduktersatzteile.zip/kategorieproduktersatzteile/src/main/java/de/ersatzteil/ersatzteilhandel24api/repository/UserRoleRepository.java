package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.user.*;

public interface UserRoleRepository extends org.springframework.data.jpa.repository.JpaRepository<UserRole, Long> {
    java.util.Optional<UserRole> findByName(String name);

}
