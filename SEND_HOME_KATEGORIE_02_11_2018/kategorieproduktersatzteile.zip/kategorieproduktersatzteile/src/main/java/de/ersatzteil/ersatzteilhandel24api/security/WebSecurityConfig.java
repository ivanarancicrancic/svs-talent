package de.ersatzteil.ersatzteilhandel24api.security;

import de.diefuturisten.easyr.easyrapi.repository.*;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.*;

@org.springframework.context.annotation.Configuration
@org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
@org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter {

    private UserRepository userRepository;

    @org.springframework.context.annotation.Bean
    public org.springframework.security.crypto.password.PasswordEncoder passwordEncoder() {
        return new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
    }

    public WebSecurityConfig(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    protected void configure(org.springframework.security.config.annotation.web.builders.HttpSecurity http) throws Exception {
        http
                .cors().and().csrf().disable().authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/api/**").permitAll()
                .antMatchers("/register").permitAll()
                .antMatchers("/forgotpw").permitAll()
                .antMatchers("/resetpw").permitAll()
                .antMatchers("/captcha/**").permitAll()
                .antMatchers("/app/tracker/**").permitAll()
                .antMatchers("/actuator").permitAll()
                .antMatchers("/actuator/**").permitAll()

                // YOUR EASRY ENDPOINT-CONFIGURATION
                // .antMatchers("/api/**").permitAll()
                // .antMatchers(HttpMethod.POST, "/password-forgot").permitAll()
                // .antMatchers(HttpMethod.POST, "/password-reset").permitAll()

                .anyRequest().authenticated()
                .and()
                // authentication (once during login)
                .addFilter(getJWTAuthenticationFilter())
                //  authorization (recover user from JWT on each request)
                .addFilter(new JWTAuthorizationFilter(authenticationManager(), userRepository))
                // never create a session
                .sessionManagement().sessionCreationPolicy(org.springframework.security.config.http.SessionCreationPolicy.STATELESS);
    }

    /**
     * Creates an instance of our authentication filter, which uses our custom AuthenticationManager
     *
     * @return
     *
     * @throws Exception
     */
    protected JWTAuthenticationFilter getJWTAuthenticationFilter() throws Exception {
        JWTAuthenticationFilter authenticationFilter = new JWTAuthenticationFilter(new com.fasterxml.jackson.databind.ObjectMapper());
        authenticationFilter.setAuthenticationManager(authenticationManager());
        return authenticationFilter;
    }

    /**
     * Create our own authentication manager, which has access into the database.
     *
     * @return
     */
    protected EasyRAuthenticationManager getEasryRAuthenticationManager() {
        return new EasyRAuthenticationManager(userRepository, this.passwordEncoder());
    }

    /**
     * This method is overridden to activate the usage of our own specific implementation.
     *
     * @return
     *
     * @throws Exception
     */
    @org.springframework.context.annotation.Bean
    @Override
    public org.springframework.security.authentication.AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    /**
     * This method is overriden to return our own specific implementation.
     *
     * @return
     *
     * @throws Exception
     */
    @Override
    protected org.springframework.security.authentication.AuthenticationManager authenticationManager() throws Exception {
        return getEasryRAuthenticationManager();
    }

    @org.springframework.context.annotation.Bean
    org.springframework.web.cors.CorsConfigurationSource corsConfigurationSource() {
        final org.springframework.web.cors.UrlBasedCorsConfigurationSource source = new org.springframework.web.cors.UrlBasedCorsConfigurationSource();

        org.springframework.web.cors.CorsConfiguration corsConfig = new org.springframework.web.cors.CorsConfiguration();
        corsConfig.applyPermitDefaultValues();
        corsConfig.addAllowedMethod(org.springframework.http.HttpMethod.DELETE);
        corsConfig.addAllowedMethod(org.springframework.http.HttpMethod.PUT);
        corsConfig.addExposedHeader(HEADER_STRING);

        source.registerCorsConfiguration("/**", corsConfig);
        return source;
    }
}
