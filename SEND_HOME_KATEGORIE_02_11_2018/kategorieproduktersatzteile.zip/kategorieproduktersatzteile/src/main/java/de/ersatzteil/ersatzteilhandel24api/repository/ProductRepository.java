package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.category.*;
import de.diefuturisten.easyr.easyrapi.entity.product.*;

@org.springframework.stereotype.Component
public interface ProductRepository extends org.springframework.data.jpa.repository.JpaRepository<Product, Long> {
    java.util.Optional<Product> findFirstByCategoryOrderByWeightDesc(Category category);
    java.util.Optional<Product> findFirstByCategoryAndWeight(Category category, int weight);
}
