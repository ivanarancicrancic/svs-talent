package de.ersatzteil.ersatzteilhandel24api.entity.user;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;

@javax.persistence.Entity
@javax.persistence.Table(name="users")
public class User {

    @javax.persistence.Id
    @javax.persistence.GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Column(name="key_user")
    private long id;

    @javax.persistence.Column(name="language", length = 2, nullable = false)
    private String language;

    @javax.persistence.Column(name="active", nullable = false)
    private boolean active = false;

    @javax.persistence.Column(name="email", nullable=false, unique=true)
    private String email;

    @javax.persistence.Column(name="password", nullable = false)
    private String password;

    @javax.persistence.Column(name="gender", nullable = false)
    private boolean gender;

    @javax.persistence.Column(name="firstname", nullable = false)
    private String firstname;

    @javax.persistence.Column(name="lastname", nullable = false)
    private String lastname;

    // TODO: additional fields

    @javax.persistence.ManyToMany(fetch = javax.persistence.FetchType.EAGER)
    @javax.persistence.JoinTable(
            name = "user_has_roles",
            joinColumns = { @javax.persistence.JoinColumn(name = "fk_user") },
            inverseJoinColumns = { @javax.persistence.JoinColumn(name = "fk_userrole") }
    )
    private java.util.Set<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRole> roles = new java.util.HashSet();

    @javax.persistence.OneToMany(mappedBy="user")
    private java.util.List<Category> categories = new java.util.LinkedList<>();

    public User() {
    }

    public User(long id) {
        this.id = id;
    }


    public boolean hasRight(String name) {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(java.util.Collection::stream)
                .anyMatch(x -> x.getName().equals(name));
    }

    public java.util.List<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRight> getRights() {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(java.util.Collection::stream)
                .collect(java.util.stream.Collectors.toList());
    }

    // Getter and Setter methods

    public Long getId() {
        return id;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return email;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getName() {
        return String.format("%s %s", firstname, lastname);
    }

    public java.util.Locale getPreferedLanguage() {
        java.util.Locale locale = null;
        if(this.language == null) {
            locale = java.util.Locale.GERMAN;
        } else {
            switch(this.language) {
                case "de":
                    locale = java.util.Locale.GERMAN;
                    break;
                case "en":
                    locale = java.util.Locale.ENGLISH;
                    break;
                default:
                    locale = java.util.Locale.GERMAN;
            }
        }

        return locale;
    }

    @com.fasterxml.jackson.annotation.JsonIgnore
    public java.util.Set<de.ersatzteil.ersatzteilhandel24api.entity.user.UserRole> getRoles() {
        return roles;
    }

    public void addRole(UserRole userRole) {
        this.roles.add(userRole);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public boolean getGender() {
        return gender;
    }

    public String getEmail() {
        return email;
    }

    public java.util.List<Category> getCategories() {
        return categories;
    }

    public void setCategories(java.util.List<Category> categories) {
        this.categories = categories;
    }


    @Override
    public boolean equals(Object o) {
        if( this == o ) {
            return true;
        }
        if( o == null || getClass() != o.getClass() ) {
            return false;
        }
        User user = (User) o;
        return id == user.id;
    }

    @Override
    public int hashCode() {
        return java.util.Objects.hash(id);
    }
}