package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.product.*;

public interface CategoryImageRepository extends org.springframework.data.jpa.repository.JpaRepository<CategoryImage, Long> {
}
