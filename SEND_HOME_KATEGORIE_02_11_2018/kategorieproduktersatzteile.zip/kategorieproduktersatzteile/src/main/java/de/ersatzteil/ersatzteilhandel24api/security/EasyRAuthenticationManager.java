package de.ersatzteil.ersatzteilhandel24api.security;

import de.diefuturisten.easyr.easyrapi.entity.user.*;
import de.diefuturisten.easyr.easyrapi.repository.*;

public class EasyRAuthenticationManager implements org.springframework.security.authentication.AuthenticationManager {

    private final UserRepository userRepository;
    private final org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    public EasyRAuthenticationManager(UserRepository userRepository, org.springframework.security.crypto.password.PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public org.springframework.security.core.Authentication authenticate(org.springframework.security.core.Authentication authentication) {
        if( !authentication.getClass().isAssignableFrom(org.springframework.security.authentication.UsernamePasswordAuthenticationToken.class) || authentication.isAuthenticated() ){
            throw new org.springframework.security.authentication.AuthenticationServiceException("Got wrong type of auth token");
        }

        org.springframework.security.authentication.UsernamePasswordAuthenticationToken authToken = (org.springframework.security.authentication.UsernamePasswordAuthenticationToken) authentication;

        String username = String.valueOf(authToken.getPrincipal());
        if( username == null || username.trim().isEmpty() ){
            throw new org.springframework.security.authentication.BadCredentialsException("No valid username got provided");
        }

        User storedUser = userRepository.findByEmail(username)
                .orElseThrow(() -> new org.springframework.security.authentication.BadCredentialsException("Username not found"));

        String storedCryptedPassword = java.util.Optional.ofNullable(storedUser.getPassword())
                .orElseThrow(() -> new org.springframework.security.authentication.AccountExpiredException("No valid password found"));

        String requestedPassword = String.valueOf(authToken.getCredentials());

        if( !passwordEncoder.matches(requestedPassword, storedCryptedPassword) ){
            throw new org.springframework.security.authentication.BadCredentialsException("Provided password did not match stored password");
        }

        if( !storedUser.isActive() ){
            throw new org.springframework.security.authentication.BadCredentialsException("User was not active");
        }
        // return new token including the rights of the user, but do not store password in it
        return new org.springframework.security.authentication.UsernamePasswordAuthenticationToken(storedUser.getUsername(), null, getAuthorities(storedUser));
    }

    /*
     * This returns a list with all rights of the user, which are gathered from assigned roles.
     */
    private java.util.Collection<? extends org.springframework.security.core.GrantedAuthority> getAuthorities(User user) {
        if( user == null || user.isActive() ){
            return java.util.Collections.emptyList();
        }
        return user.getRoles()
                .stream()
                .map(userRoleAssociation -> userRoleAssociation.getRights())
                .flatMap(java.util.Collection::stream)
                .map(userRight -> new org.springframework.security.core.authority.SimpleGrantedAuthority(userRight.getName()))
                .collect(java.util.stream.Collectors.toList());
    }

}
