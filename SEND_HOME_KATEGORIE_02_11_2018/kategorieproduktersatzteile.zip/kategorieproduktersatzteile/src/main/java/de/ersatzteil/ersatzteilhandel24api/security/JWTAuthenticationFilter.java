package de.ersatzteil.ersatzteilhandel24api.security;

import de.diefuturisten.easyr.easyrapi.model.request.*;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.*;

public class JWTAuthenticationFilter extends org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter {

    private final com.fasterxml.jackson.databind.ObjectMapper mapper;
    public static final String REQUEST_ATTRIBUTE_FOR_JSON = "JWTAuthenticationFilter_AuthAttribute";

    public JWTAuthenticationFilter(com.fasterxml.jackson.databind.ObjectMapper mapper) {
        super();
        this.mapper = mapper;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainUsername(javax.servlet.http.HttpServletRequest request) {
        return java.util.Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new org.springframework.security.authentication.AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getUsername();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainPassword(javax.servlet.http.HttpServletRequest request) {
        return java.util.Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new org.springframework.security.authentication.AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getPassword();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public org.springframework.security.core.Authentication attemptAuthentication(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) {
        // as we are parsing the request-body, we have to read the request ONCE (otherwise we are trying to re-read the inputstream, which gets closed)
        request.setAttribute(REQUEST_ATTRIBUTE_FOR_JSON, getUserLoginCredientialsModel(request));
        org.springframework.security.core.Authentication attemptAuthenticationResult = super.attemptAuthentication(request, response);
        // cleanup
        request.removeAttribute(REQUEST_ATTRIBUTE_FOR_JSON);
        return attemptAuthenticationResult;
    }

    /**
     * Try to read credentials model from request, as we are expecting this in JSON format instead of url-parameters.
     *
     * @param request
     *
     * @return returns empty optional of request did not contain any parsable JSON
     */
    private UserLoginCredientialsModel getUserLoginCredientialsModel(javax.servlet.http.HttpServletRequest request) {
        try(javax.servlet.ServletInputStream inputStream = request.getInputStream()){
            return mapper.readValue(inputStream, UserLoginCredientialsModel.class);
        } catch(java.io.IOException e){ // NOSONAR
            // NO-OP
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void successfulAuthentication(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response, javax.servlet.FilterChain chain, org.springframework.security.core.Authentication auth) throws java.io.IOException, javax.servlet.ServletException {
        // When authentication was successful, store the username inside the JWT-related HTTP-header
        String username = String.valueOf(auth.getPrincipal());
        java.util.Date expirationTime = new java.util.Date(System.currentTimeMillis() + EXPIRATION_TIME);
        // tell the client our new JWT-token
        response.addHeader(HEADER_STRING, TokenHelper.createToken(username, expirationTime));
    }
}
