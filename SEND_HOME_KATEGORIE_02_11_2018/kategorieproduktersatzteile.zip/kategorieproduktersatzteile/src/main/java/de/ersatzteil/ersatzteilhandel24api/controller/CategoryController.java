package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;
import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.exceptions.*;
import de.ersatzteil.ersatzteilhandel24api.model.request.*;
import de.ersatzteil.ersatzteilhandel24api.model.response.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;

@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api")
public class CategoryController {


    private final CategoryService categoryService;
    private final AuthenticationFacade authenticationFacade;

    public CategoryController(CategoryService categoryService, AuthenticationFacade authenticationFacade) {
        this.categoryService = categoryService;
        this.authenticationFacade = authenticationFacade;
    }

    @org.springframework.web.bind.annotation.GetMapping("/categories")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_LIST)
    public java.util.stream.Stream<CategoryOverviewModel> getAllCategoriesForUser() {

        User user = authenticationFacade.getAuthenticatedUser();
        return categoryService
                .getCategoriesForUser(user)
                .stream()
                .map(CategoryOverviewModel::new);
    }

    @org.springframework.web.bind.annotation.GetMapping("/category/{id}")
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_GET)
    public CategoryDetailModel getCategory(@org.springframework.web.bind.annotation.PathVariable long id) throws ForbiddenException {

        User user = authenticationFacade.getAuthenticatedUser();

        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return new CategoryDetailModel(category);
    }

    @org.springframework.web.bind.annotation.PostMapping("/category")
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel createCategory() {
        User user = authenticationFacade.getAuthenticatedUser();
        Category createdCategory = this.categoryService.createEmptyCategory(user);
        return new CategoryDetailModel(createdCategory);
    }

    @org.springframework.web.bind.annotation.PostMapping("/category/{id}/save")
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel saveNewCategory(@org.springframework.web.bind.annotation.PathVariable long id, @javax.validation.Valid @org.springframework.web.bind.annotation.RequestBody SaveNewCategoryModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        return new CategoryDetailModel(categoryService.saveNewCategory(category, model, user));
    }

    @org.springframework.web.bind.annotation.PutMapping("/category")
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_EDIT)
    public CategoryDetailModel editCategory(@javax.validation.Valid @org.springframework.web.bind.annotation.RequestBody EditCategoryModel editCategoryModel) throws ForbiddenException {
        User user = authenticationFacade.getAuthenticatedUser();

        Category category = categoryService.getCategory(editCategoryModel.getId()).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        Category editedCategory = categoryService.editCategory(category, editCategoryModel);

        return new CategoryDetailModel(editedCategory);
    }


}
