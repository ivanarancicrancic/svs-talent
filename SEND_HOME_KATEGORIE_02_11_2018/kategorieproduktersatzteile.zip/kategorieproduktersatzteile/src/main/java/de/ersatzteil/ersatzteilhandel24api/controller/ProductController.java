package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.product.*;
import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.exceptions.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;

@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api")
public class ProductController {

    private final AuthenticationFacade authenticationFacade;
    private final ProductService productService;
    private final de.ersatzteil.ersatzteilhandel24api.service.CategoryService categoryService;

    public ProductController(AuthenticationFacade authenticationFacade, ProductService productService, CategoryService categoryService) {
        this.authenticationFacade = authenticationFacade;
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @org.springframework.web.bind.annotation.DeleteMapping("/category/product/{productId}")
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_DELETE)
    public boolean deleteProduct(@org.springframework.web.bind.annotation.PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!product.getCategory().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        productService.deleteProduct(product);
        return true;
    }

}