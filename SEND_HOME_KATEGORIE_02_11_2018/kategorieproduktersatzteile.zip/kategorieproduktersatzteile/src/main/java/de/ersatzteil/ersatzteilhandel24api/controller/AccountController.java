package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.model.request.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;

@org.springframework.web.bind.annotation.RestController
public class AccountController {

    private final UserService userService;

    public AccountController(UserService userService) {
        this.userService = userService;
       }

    @org.springframework.web.bind.annotation.RequestMapping(value = "/register", method = org.springframework.web.bind.annotation.RequestMethod.POST)
    public org.springframework.http.ResponseEntity createAccount(@org.springframework.web.bind.annotation.RequestBody CreateAccountModel model) {

            userService.create(model);
            return new org.springframework.http.ResponseEntity(org.springframework.http.HttpStatus.OK);

    }


}
