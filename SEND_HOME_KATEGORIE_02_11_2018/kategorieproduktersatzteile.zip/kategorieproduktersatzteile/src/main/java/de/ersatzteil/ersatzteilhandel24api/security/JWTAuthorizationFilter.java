package de.ersatzteil.ersatzteilhandel24api.security;

import de.diefuturisten.easyr.easyrapi.entity.user.*;
import de.diefuturisten.easyr.easyrapi.repository.*;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.*;

public class JWTAuthorizationFilter extends org.springframework.security.web.authentication.www.BasicAuthenticationFilter {

    private final UserRepository userRepository;

    public JWTAuthorizationFilter(org.springframework.security.authentication.AuthenticationManager authenticationManager, UserRepository userRepository) {
        super(authenticationManager);
        this.userRepository = userRepository;
    }

    @Override
    protected void doFilterInternal(javax.servlet.http.HttpServletRequest req, javax.servlet.http.HttpServletResponse res, javax.servlet.FilterChain chain) throws java.io.IOException, javax.servlet.ServletException {
        String header = req.getHeader(HEADER_STRING);

        if( header == null || !header.startsWith(TOKEN_PREFIX) ){
            chain.doFilter(req, res);
            return;
        }

        org.springframework.security.authentication.UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
        if( authentication == null ){
            // when not being able to get auth, just reject this here without further processing
            res.setStatus(401);
            return;
        }

        // when reaching this, everything went okay
        org.springframework.security.core.context.SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }

    private org.springframework.security.authentication.UsernamePasswordAuthenticationToken getAuthentication(javax.servlet.http.HttpServletRequest request) {
        String token = request.getHeader(HEADER_STRING);
        if( token == null ){
            return null;
        }

        String username = TokenHelper.userFromToken(token);
        if( username == null ){
            return null;
        }

        java.util.Optional<User> storedUser = userRepository.findByEmail(username);
        return storedUser
                .map(user -> new org.springframework.security.authentication.UsernamePasswordAuthenticationToken(username, null, getAuthorities(user)))
                .orElse(null);
    }

    /*
     * This returns a list with all rights of the user, which are gathered from assigned roles.
     */
    private java.util.Collection<? extends org.springframework.security.core.GrantedAuthority> getAuthorities(User user) {
        if( user == null ){
            return java.util.Collections.emptyList();
        }
        return user.getRoles()
                .stream()
                .map(role -> role.getRights())
                .flatMap(java.util.Collection::stream)
                .map(userRight -> new org.springframework.security.core.authority.SimpleGrantedAuthority(userRight.getName()))
                .collect(java.util.stream.Collectors.toList());
    }
}
