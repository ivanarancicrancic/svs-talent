package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.category.*;
import de.diefuturisten.easyr.easyrapi.entity.user.*;

public interface CategoryRepository extends org.springframework.data.jpa.repository.JpaRepository<Category, Long> {
    java.util.List<de.diefuturisten.easyr.easyrapi.entity.category.Category> findByUser(User user);
}
