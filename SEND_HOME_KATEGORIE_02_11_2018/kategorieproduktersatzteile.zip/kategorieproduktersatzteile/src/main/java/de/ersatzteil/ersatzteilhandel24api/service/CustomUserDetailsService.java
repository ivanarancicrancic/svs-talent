package de.ersatzteil.ersatzteilhandel24api.service;

import de.diefuturisten.easyr.easyrapi.entity.user.*;
import de.diefuturisten.easyr.easyrapi.repository.*;

@org.springframework.stereotype.Service
@javax.transaction.Transactional
public class CustomUserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

    private final UserRepository userRepository;

    public CustomUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public org.springframework.security.core.userdetails.UserDetails loadUserByUsername(String userName) {
        User user = userRepository.findByEmail(userName)
                .orElseThrow(() ->
                        new org.springframework.security.core.userdetails.UsernameNotFoundException(String.format("%s not found", userName))
                );
        if(!user.isActive()) {
            throw new org.springframework.security.authentication.AccountExpiredException("User not active");
        }

        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                getAuthorities(user));
    }

    public static java.util.Collection<? extends org.springframework.security.core.GrantedAuthority> getAuthorities(User user) {
        return user.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(java.util.Collection::stream)
                .map(x -> new org.springframework.security.core.authority.SimpleGrantedAuthority(x.getName()))
                .collect(java.util.stream.Collectors.toList());
    }

}
