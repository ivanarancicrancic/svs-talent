package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.model.response.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;

@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api")
public class AdminController {

    private final AdminService adminService;

    private final CategoryService campaignService;

    public AdminController(AdminService adminService, CategoryService campaignService) {
        this.adminService = adminService;
        this.campaignService = campaignService;
    }

    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @org.springframework.web.bind.annotation.RequestMapping(value = "/admin/users", method = org.springframework.web.bind.annotation.RequestMethod.GET)
    public java.util.List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(java.util.stream.Collectors.toList());
    }

    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @org.springframework.web.bind.annotation.RequestMapping(value = "/admin/categories", method = org.springframework.web.bind.annotation.RequestMethod.GET)
    public java.util.List<CategoryOverviewModel> listAllCategories() {
        return campaignService.findAllCategories().stream()
                .map(CategoryOverviewModel::new)
                .collect(java.util.stream.Collectors.toList());
    }

    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @org.springframework.web.bind.annotation.RequestMapping(value = "/admin/categories/{userId}", method = org.springframework.web.bind.annotation.RequestMethod.GET)
    public java.util.List<CategoryOverviewModel> listCategoriesForUser(@org.springframework.web.bind.annotation.PathVariable long userId) {
        User user = adminService.getUserByID(userId).orElseThrow(java.util.NoSuchElementException::new);
        return campaignService.getCategoriesForUser(user).stream()
                .map(CategoryOverviewModel::new)
                .collect(java.util.stream.Collectors.toList());
    }

}
