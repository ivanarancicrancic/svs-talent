package de.ersatzteil.ersatzteilhandel24api.repository;

import de.diefuturisten.easyr.easyrapi.entity.user.*;

public interface UserRepository extends org.springframework.data.jpa.repository.JpaRepository<User, Long>
{
    java.util.Optional<User> findByEmail(String username);
}
