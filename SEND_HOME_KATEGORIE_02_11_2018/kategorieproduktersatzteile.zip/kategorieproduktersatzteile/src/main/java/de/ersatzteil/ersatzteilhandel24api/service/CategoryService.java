package de.ersatzteil.ersatzteilhandel24api.service;

import de.diefuturisten.easyr.easyrapi.entity.category.*;
import de.diefuturisten.easyr.easyrapi.entity.user.*;
import de.diefuturisten.easyr.easyrapi.model.request.*;
import de.diefuturisten.easyr.easyrapi.repository.*;

@org.springframework.stereotype.Service
@org.springframework.transaction.annotation.Transactional
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }


    public java.util.List<Category> findAllCategories() {
        return categoryRepository.findAll().stream().collect(java.util.stream.Collectors.toList());
    }

    public java.util.List<Category> getCategoriesForUser(User user) {
        return categoryRepository.findByUser(user).stream().collect(java.util.stream.Collectors.toList());
    }

    public java.util.Optional<Category> getCategory(long id) {
        return this.categoryRepository.findById(id);
    }


    public Category createEmptyCategory(User user) {
        Category category = new Category();
        category.setUser(user);
        return this.categoryRepository.save(category);
    }

    public Category saveNewCategory(Category category, SaveNewCategoryModel model, User user) {

        this.categoryRepository.save(category);
        return category;
    }

    public Category editCategory(Category category, EditCategoryModel editCategoryModel) {
        category.setName(editCategoryModel.getName());
        return this.categoryRepository.save(category);
    }

}
