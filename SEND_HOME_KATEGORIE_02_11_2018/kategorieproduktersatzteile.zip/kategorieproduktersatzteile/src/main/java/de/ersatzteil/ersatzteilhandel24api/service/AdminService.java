package de.ersatzteil.ersatzteilhandel24api.service;

import de.diefuturisten.easyr.easyrapi.entity.user.*;

@org.springframework.stereotype.Service
public class AdminService {

    private final UserService userService;

    public AdminService(UserService userService) {
        this.userService = userService;
    }

    public java.util.List<User> getAllUsers() {
        return userService.getAllUser();
    }

    public java.util.Optional<User> getUserByID(long userId) {return userService.getUserByUserId(userId); }

}
