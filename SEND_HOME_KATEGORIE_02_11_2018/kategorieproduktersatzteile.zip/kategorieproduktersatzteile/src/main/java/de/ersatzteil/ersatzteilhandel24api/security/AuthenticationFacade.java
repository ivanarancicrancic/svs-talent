package de.ersatzteil.ersatzteilhandel24api.security;

import de.diefuturisten.easyr.easyrapi.entity.user.*;
import de.diefuturisten.easyr.easyrapi.service.*;

@org.springframework.stereotype.Component
public class AuthenticationFacade {

    private final UserService userService;

    public AuthenticationFacade(UserService userService) {
        this.userService = userService;
    }

    public User getAuthenticatedUser() {
        org.springframework.security.core.Authentication auth = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication();
        String username = (String) auth.getPrincipal();
        return userService.getUserByUsername(username);
    }

}
