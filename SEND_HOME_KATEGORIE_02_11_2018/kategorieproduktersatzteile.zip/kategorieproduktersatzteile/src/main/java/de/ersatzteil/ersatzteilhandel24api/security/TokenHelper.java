package de.ersatzteil.ersatzteilhandel24api.security;

import static de.ersatzteil.ersatzteilhandel24api.security.SecurityConstants.*;

public final class TokenHelper {

    public static String createToken(String username, java.util.Date expirationTime) {
        return TOKEN_PREFIX + io.jsonwebtoken.Jwts.builder()
                .setSubject(username)
                .setExpiration(expirationTime)
                .signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, SECRET.getBytes())
                .compact();
    }

    public static String userFromToken(String token) {
        return io.jsonwebtoken.Jwts.parser()
                .setSigningKey(SECRET.getBytes())
                .parseClaimsJws(token.replace(TOKEN_PREFIX, ""))
                .getBody()
                .getSubject();
    }

    private TokenHelper() {
        // NO-OP utility class
    }

}
