package de.ersatzteil.ersatzteilhandel24api.entity.product;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;


@javax.persistence.Entity
@javax.persistence.Inheritance(strategy = javax.persistence.InheritanceType.JOINED)
public abstract class Product {

    @javax.persistence.Id
    @javax.persistence.GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Column(name="key_product")
    private long id;

    @javax.persistence.ManyToOne(fetch = javax.persistence.FetchType.EAGER)
    @javax.persistence.JoinColumn(name="fk_category", nullable = false)
    private Category category;

    @javax.persistence.Column(name="weight", nullable = false)
    private int weight;

    @javax.persistence.Column(name="name", nullable = false)
    private String name;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
