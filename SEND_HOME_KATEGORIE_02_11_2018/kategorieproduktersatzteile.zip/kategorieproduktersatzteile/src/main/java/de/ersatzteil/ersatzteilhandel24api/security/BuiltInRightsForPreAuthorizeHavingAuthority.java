package de.ersatzteil.ersatzteilhandel24api.security;

public final class BuiltInRightsForPreAuthorizeHavingAuthority {

    private static final String HAS_AUTHORITY_PREFIX = "hasAuthority('";
    private static final String HAS_AUTHORITY_SUFFIX = "')";

    public static final String CATEGORY_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_GET + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String CONTENT_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.CONTENT_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String PACKAGE_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.PACKAGE_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String PACKAGE_LIST_FOR_USER = HAS_AUTHORITY_PREFIX + BuiltInRights.PACKAGE_LIST_FOR_USER + HAS_AUTHORITY_SUFFIX;
    public static final String PACKAGE_BUY = HAS_AUTHORITY_PREFIX + BuiltInRights.PACKAGE_BUY + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String TRACKER_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.TRACKER_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String USER_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.USER_GET + HAS_AUTHORITY_SUFFIX;

    public static final String ADMIN_RIGHT = HAS_AUTHORITY_PREFIX + BuiltInRights.ADMIN_RIGHT + HAS_AUTHORITY_SUFFIX;

    private BuiltInRightsForPreAuthorizeHavingAuthority() {
        // NO-OP utility class
    }

}
