package de.ersatzteil.ersatzteilhandel24api.model.response;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;

public class CategoryOverviewModel {

    private long id;
    private String name;
    private String trackerUrl;
    private long numberOfViews;
    private java.util.Date expirationDate;

    public CategoryOverviewModel() {
    }

    public CategoryOverviewModel(Category category) {
        this.id = category.getId();
        this.name = category.getName();

//        this.trackerUrl = category.getTracker()
//                .stream()
//                .map(Tracker::getUrl)
//                .findFirst().orElse(null);

//        this.numberOfViews = category.getTotalTrackings();

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTrackerUrl() {
        return trackerUrl;
    }

    public void setTrackerUrl(String trackerUrl) {
        this.trackerUrl = trackerUrl;
    }

    public long getNumberOfViews() {
        return numberOfViews;
    }

    public void setNumberOfViews(long numberOfViews) {
        this.numberOfViews = numberOfViews;
    }

    public java.util.Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(java.util.Date expirationDate) {
        this.expirationDate = expirationDate;
    }
}
