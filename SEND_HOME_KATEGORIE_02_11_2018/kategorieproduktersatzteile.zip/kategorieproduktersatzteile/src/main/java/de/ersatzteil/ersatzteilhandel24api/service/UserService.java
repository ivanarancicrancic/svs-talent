package de.ersatzteil.ersatzteilhandel24api.service;

import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.model.request.*;
import de.ersatzteil.ersatzteilhandel24api.repository.*;

@org.springframework.stereotype.Service
@org.springframework.transaction.annotation.Transactional
public class UserService {

    private final org.slf4j.Logger log = org.slf4j.LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private org.springframework.security.crypto.password.PasswordEncoder passwordEncoder;

    private final UserRoleRepository userRoleRepository;

    public UserService(UserRepository userRepository, org.springframework.security.crypto.password.PasswordEncoder passwordEncoder, UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

        this.userRoleRepository = userRoleRepository;
    }

    public User getUserByUsername(String username) {
        return userRepository.findByEmail(username).orElseThrow(java.util.NoSuchElementException::new);
    }


    public java.util.Optional<User> getUserByUserId(long userId) {
        return userRepository.findById(userId);
    }

    public User create(CreateAccountModel model) {
        User user = new User();

        user.setActive(true);
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());
        user.setEmail(model.getEmail());
        user.setPassword(passwordEncoder.encode(model.getPassword()));
        user.setLanguage(model.getLanguage());
        user.setGender(model.getGender());

        userRoleRepository.findByName("Standard").ifPresent(defaultRole -> {
            user.addRole(defaultRole);
        });
        userRepository.save(user);

        return user;
    }


    public java.util.List<User> getAllUser() {
        return userRepository.findAll();
    }
}
