package de.ersatzteil.ersatzteilhandel24api.exceptions;

@org.springframework.web.bind.annotation.ResponseStatus(org.springframework.http.HttpStatus.FORBIDDEN)
public class ForbiddenException extends RuntimeException {}
