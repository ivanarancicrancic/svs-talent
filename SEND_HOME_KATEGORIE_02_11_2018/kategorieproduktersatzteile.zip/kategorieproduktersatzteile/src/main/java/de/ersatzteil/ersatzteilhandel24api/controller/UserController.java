package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.model.response.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;

@org.springframework.web.bind.annotation.RestController
@org.springframework.web.bind.annotation.RequestMapping("/api")
public class UserController {

    private final AuthenticationFacade authenticationFacade;

    public UserController(AuthenticationFacade authenticationFacade) {
        this.authenticationFacade = authenticationFacade;
    }

    @org.springframework.web.bind.annotation.RequestMapping(value = "/user", method = org.springframework.web.bind.annotation.RequestMethod.GET)
    @org.springframework.security.access.prepost.PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.USER_GET)
    public UserModel createAccount() {
        return new UserModel(authenticationFacade.getAuthenticatedUser());
    }

}
