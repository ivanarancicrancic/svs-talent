package de.ersatzteil.ersatzteilhandel24api.entity.product;


@javax.persistence.Entity
@javax.persistence.Table(name="category_images")
public class CategoryImage {

    @javax.persistence.Id
    @javax.persistence.GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Column(name="key_categoryimage")
    private long id;

    @javax.persistence.Column(name="weight", nullable = false)
    private int weight;

    @javax.persistence.Column(name="url", nullable = false)
    private String url;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
