package de.ersatzteil.ersatzteilhandel24api.entity.user;

@javax.persistence.Entity
@javax.persistence.Table(name="userroles")
public class UserRole {

    @javax.persistence.Id
    @javax.persistence.GeneratedValue(strategy= javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Column(name="key_userrole")
    private long id;

    @javax.persistence.Column(name = "name", length = 45)
    private String name;

    @javax.persistence.Column(name = "description", length = 245)
    private String description;

    @javax.persistence.ManyToMany(fetch = javax.persistence.FetchType.EAGER)
    @javax.persistence.JoinTable(
            name = "role_has_rights",
            joinColumns = { @javax.persistence.JoinColumn(name = "fk_userrole") },
            inverseJoinColumns = { @javax.persistence.JoinColumn(name = "fk_userright") }
    )
    java.util.Set<UserRight> rights = new java.util.HashSet<>();

    @javax.persistence.ManyToMany(mappedBy = "roles", fetch = javax.persistence.FetchType.EAGER)
    private java.util.Set<User> users;

    public UserRole() {
    }

    public UserRole(String name) {
        this.name = name;
    }

    // setter & getter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @com.fasterxml.jackson.annotation.JsonIgnore
    public java.util.Set<UserRight> getRights() {
        return rights;
    }

    public void setRights(java.util.Set<UserRight> rights) {
        this.rights = rights;
    }

    @com.fasterxml.jackson.annotation.JsonIgnore
    public java.util.Set<User> getUsers() {
        return users;
    }

    public void setUsers(java.util.Set<User> users) {
        this.users = users;
    }

    public void addRight(UserRight ur1) {
        this.rights.add(ur1);
    }
}
