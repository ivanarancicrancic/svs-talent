package de.ersatzteil.ersatzteilhandel24api.model.response;

public class MovieContentModel {


}
