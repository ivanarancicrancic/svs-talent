package de.ersatzteil.ersatzteilhandel24api.model.request;

public class CreateCategoryModel {

    @javax.validation.constraints.NotNull
    private Long packageId;

    public CreateCategoryModel() {

    }

    public Long getPackageId() {
        return packageId;
    }

    public void setPackageId(Long packageId) {
        this.packageId = packageId;
    }
}
