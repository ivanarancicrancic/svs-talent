import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import User from '../components/User/User';
import { tryLogin } from '../redux/actions/auth'

import Form from '../components/Form/Form';
import Input from '../components/Form/Input';

export const Login = (props) => (
  <div className='login'>
    <p>
      <Link to="/">Back</Link>
    </p>
 <User/> 
 </div>

  
  )

const mapStateToProps = state => ({
  auth: state.auth
})

const mapDispatchToProps = dispatch => ({
  tryLogin: (creds) => dispatch(tryLogin(creds))
})

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Login)