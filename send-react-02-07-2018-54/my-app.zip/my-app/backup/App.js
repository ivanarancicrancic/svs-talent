import React, { Component } from 'react';
import './App.css';
import Person from './Person/Person.js';

class App extends Component {
  state = {
   persons: [
       {name: 'Ivana', age: 28},
       {name: 'Hanna', age: 25},
       {name: 'Josh', age: 29}
   ],
    //  otherState: 'Something else'
       showPersons: false
  }


//   clickHandler = (newName) => {
//  console.log('Was clicked!!!');
// //not this way: this.state.persons[0].name = 'Ivana Rancic';
// this.setState({
//     persons: [
//         {name: newName, age: 28},
//         {name: 'Hanna Montana', age: 25},
//         {name: 'Josh Stonne', age: 29}
//     ]
// })
//
// }

    deletePersonHandler = (personIndex) => {
   const persons = this.state.persons;
   persons.splice(personIndex, 1);
   this.setState({persons: persons});

    }



    nameChangedHandler = (event) => {

        this.setState({
            persons: [
                {name: 'Ivana', age: 28},
                {name: event.target.value, age: 29},
                {name: 'Josh Stonne', age: 26}
            ]
        })

    }

    togglePersonsHandler = () => {
       const doesShow = this.state.showPersons;
       this.setState({showPersons: !doesShow});

    }

  render() {
      const style = {
       backgroundColor: 'yellow',
          font: 'inherit',
          border: '1px solid blue',
          padding: '8px',
          cursor: 'pointer'
      }

      const style1 = {
          backgroundColor: 'gray'
      }

   //   <Person name = {this.state.persons[0].name} age={this.state.persons[0].age}/>
  //    <Person name={this.state.persons[1].name} age={this.state.persons[1].age}
    //  changed={this.nameChangedHandler}> Something here </Person>
    //  <Person name={this.state.persons[2].name} age={this.state.persons[2].age}/>

      let persons = null;
      if(this.state.showPersons){
          persons = (
              <div>
                  {this.state.persons.map((person, index) => {
                      return <Person name={person.name} age={person.age} click = {() => this.deletePersonHandler(index)}/>
                  })}
              </div>
          );
      }


  return(
      /*<button style={style} onClick={() => this.clickHandler('Ivana Rancic Button')}>Switch content</button>*/
      <div className="App" style={style1}>
          <h1>I'm a React App</h1>
          <p>This is really working!!</p>
          <button style={style} onClick={this.togglePersonsHandler}>Switch content</button>
          /*<Person name = {this.state.persons[1].name} age = {this.state.persons[1].age} click = {this.clickHandler.bind(this, 'Ivana Rancic Person')}> Something here </Person>*/
          {persons}
      </div>
  );
      // return React.createElement('div', {classname: 'App'}, React.createElement(h1, null, 'I\'m a React component!!!'));
  }
}

export default App;

