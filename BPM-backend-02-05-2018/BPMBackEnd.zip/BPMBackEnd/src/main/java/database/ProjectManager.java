package database;

import Models.*;

import java.sql.Connection;
import java.util.List;

public class ProjectManager {

    public LoginStatus getLoginStatus(UserLogin ul) throws Exception
    {
        LoginStatus t_items = new LoginStatus();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.getLoginStatus(connection,ul);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }
    public List<ClientType> getClientsType() throws Exception
    {
        List<ClientType> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.getClientsType(connection);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<LoanRequestsByParametar> getloanrequests() throws Exception
    {
        List<LoanRequestsByParametar> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.getloanrequests(connection);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }
    public List<LoanRequestsByParametar> getloanrequestsbyparametar(String p_type, String p_value) throws Exception
    {
        List<LoanRequestsByParametar> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.getloanrequestsbyparametar(connection, p_type, p_value);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<CreditLine> GetKreditniLini(Integer p_type) throws Exception
    {
        List<CreditLine> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetKreditniLini(connection, p_type);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<LoanType> GetLoanTypeByLoanLineID(Integer loanLineID) throws Exception
    {
        List<LoanType> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetLoanTypeByLoanLineID(connection, loanLineID);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<UsersByUsername> GetUsersByUsername(String p_username) throws Exception
    {
        List<UsersByUsername> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetUsersByUsername(connection, p_username);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<AplicantDetails> GetAplicantDetailsByEmbg(String p_embg) throws Exception
    {
        List<AplicantDetails> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetAplicantDetailsByEmbg(connection, p_embg);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<UserByGroupId> GetUsersByGrpoupID(Integer p_groupid) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<UserByGroupId> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetUsersByGrpoupID(connection, p_groupid);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<DocumentsForLoanTypeID> GetDocumentsForLoanTypeID(Integer _loanTypeID) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<DocumentsForLoanTypeID> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetDocumentsForLoanTypeID(connection, _loanTypeID);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }

    public List<WarningsByLoanID> GetWarningsByLoanID(Integer loanID) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<WarningsByLoanID> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetWarningsByLoanID(connection, loanID);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }


    public List<WarningsDetailsByWarrningID> GetWarningsDetailsByWarrningID(Integer warrningID) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<WarningsDetailsByWarrningID> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetWarningsDetailsByWarrningID(connection, warrningID);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }


        public List<LoanRequestsByParametar> GetLoanRequestsByParametar(String parametarName, String parametarValue) throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<LoanRequestsByParametar> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetLoanRequestsByParametar(connection, parametarName,parametarValue);
        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }


    public void CreateLoanRequest(LoanRequest loanRequest)  throws Exception {
        LoanRequest loanRequest1= new LoanRequest();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            project.CreateLoanRequest(connection, loanRequest);

        } catch (Exception e) {
            throw e;
        }
    }



    public void AddNewWarningByLoanID(LoanWarning loanWarning)  throws Exception {
        LoanWarning loanWarning1= new LoanWarning();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            project.AddNewWarningByLoanID(connection, loanWarning);

        } catch (Exception e) {
            throw e;
        }
    }


    public LoanRequest UpdateLoanRequestByID(int loanTypeID, LoanRequest loanRequest)  throws Exception {
        LoanRequest loanRequest1= new LoanRequest();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            loanRequest1 = project.UpdateLoanRequestByID(connection, loanTypeID, loanRequest);
            return loanRequest1;
        } catch (Exception e) {
            throw e;
        }
    }

    public List<KreditenOdborGroups> GetKreditenOdborGroups() throws Exception
    {
        // List<KreditniLinii> t_items = new ArrayList<KreditniLinii>();
        List<KreditenOdborGroups> t_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            t_items=project.GetKreditenOdborGroups(connection);

        } catch (Exception e) {
            throw e;
        }
        return t_items;
    }
}
