package org.activiti;

import org.springframework.stereotype.Component;

@Component
public class RequestService {

    public void storeRequest() {
        System.out.println("Storing request ...");
    }

}
