package Models;

public class LoginStatus {

    private Integer status;

    public LoginStatus() {
    }

    public LoginStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
