package springwebapp.model;

import javax.persistence.Entity;


public enum Difficutly {

    EASY, MODERATE, KIND_OF_HARD, HARD

}
