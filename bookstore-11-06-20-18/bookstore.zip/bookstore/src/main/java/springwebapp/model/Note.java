package springwebapp.model;

import javax.persistence.*;

@Entity
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

   // @OneToOne
    //private Book book;
    private String note;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

   // public Book getBook() {
    //    return book;
   // }

    //public void setBook(Book book) {
     //   this.book = book;
   // }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
