package springwebapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import springwebapp.model.Comment;

@Component
public interface CommentRepository  extends CrudRepository<Comment, Long> {
}
