package springwebapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import springwebapp.model.Note;

@Component
public interface NoteRepository  extends CrudRepository<Note, Long> {
}
