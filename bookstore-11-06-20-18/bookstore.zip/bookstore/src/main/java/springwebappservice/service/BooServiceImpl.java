package springwebappservice.service;

import springwebapp.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.repository.BookRepository;

import java.util.ArrayList;
import java.util.List;

@Service("bookService")
@Component
public class BooServiceImpl implements BookService {

    @Autowired
    BookRepository repository;


    @Override
    public Book createBook(Book book){ return repository.save(book); }

    @Override
    public List<Book> getAllBooks(){
        String status = "getting all books";
        System.out.println(status);
       // return status;
        Iterable<Book> iterable = repository.findAll();
        System.out.println("Taken books!");
        List<Book> list = new ArrayList<Book>();
        if(iterable != null) {
            for(Book e: iterable) {
               // System.out.println(e.toString());
                list.add(e);
            }
        }
        return list;

    }


    @Override
    public String getBook(Long id){
        String status = "getting book";
        System.out.println(status);
        return status; }

    @Override
    public String updateBook(Long id, Book book) {
        String status = "updating Book";
        System.out.println(status);
        return status;
    }

    @Override
    public String deleteBook(Long id){
        String status = "getting author";
        System.out.println(status);
        return status;
    }


    @Override
    public Book findById(Long id){
        String status = "getting book";
        System.out.println(status);
       Book book = new Book();
        book =  repository.findById(id).get();
        System.out.println("Returned book to display" + repository.findById(id).get().toString());

        return book;
    }

}
