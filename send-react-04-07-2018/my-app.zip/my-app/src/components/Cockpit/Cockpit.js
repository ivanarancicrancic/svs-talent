import React from 'react';
import Radium, { StyleRoot } from 'radium';

const cockpit = (props) => {

    const style = {
        backgroundColor: 'yellow',
        font: 'inherit',
        border: '1px solid blue',
        padding: '8px',
        cursor: 'pointer',
        ':hover' : {
            backgroundColor: 'lightgreen',
            color: 'black'
        }
    }
    style[':hover'] = {
        backgroundColor: 'lightgreen',
        color: 'black'
    }

    //      let classes = ['red', 'bold'].join(' ');
    const asignedClasses = [];
    let btnClass = '';


    if(props.showPersons){
        btnClass = 'red';
    }

    if(props.persons.length <= 2){
        asignedClasses.push('red');
    }

    if(props.persons.length <= 1){
        asignedClasses.push('bold')
    }

    return (
        <div>
        <h1>{props.appTitle}</h1>
        <p className={asignedClasses.join(' ')}>This is really working!!</p>
<button style={style} onClick={props.clicked}>Switch content</button>
        </div>
            );
};

export default Radium(cockpit);
