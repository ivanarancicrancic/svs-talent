import * as React from 'react'
import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedCampaigns} from '../redux/actions/localCampaignsActions'
import { IRealCampaign} from '../models/CampaignsModelHelper'
import { IRootState } from '../redux/index';
// import store from '../redux/store/store'

interface ICampaignsState {
    entry: string
     campaignsData?: IRealCampaign[],
     error?: any
}
interface ICampaignsProps {
    getAllCampaigns: any
    editCampaignData: any,
    campaignsData: any
}

class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        this.state = {
            entry: ''
            //  campaignsData: [],
            //  error: false
        }
    }

    public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
        // this.setState({campaignsData: realCampaignData.campaigns})
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)

            this.editCampaign(event)
        }
    }

  public render() {
        return (
            <div>
                <div>
                    <span>FORM</span>
                    <br />
                    <input 
                        type='text' 
                        placeholder='ENTRY'
                        onChange={ e => this.handleAddress(e) }
                        onKeyPress={ e => this.handleKeyPress(e) }
                    />
                    <button
                        onClick={ e => this.editCampaign(e) }
                    >
                    Submit for info
                    </button>
                </div>
               <div> CAMPAIGNS LIST:
               {
                   this.props.campaignsData.map((campaign: IRealCampaign) =>
                    <div key={campaign.id}>
                      {campaign.user.firstname} 
                      {campaign.user.lastname}
                      {campaign.user.email}
                      {/* {campaign.contact.address} */}
                    </div>
                  )
                 }
                   
                    </div>
            </div>
        )
    }


    public componentDidMount() {
        this.props.getAllCampaigns();
    }

    public componentWillReceiveProps(newProps: ICampaignsProps) {

        this.setState({
            ...newProps.campaignsData
        })
        console.log(this.state)
    }
}


const mapStateToProps = (state: IRootState) => {
    return {
        // ...state
        campaignsData: state.allCampaign.realCampaigns,
        error: state.allCampaign.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllCampaigns: () => dispatch(getListedCampaigns()),
        editCampaignData: (entry: number) => dispatch(editAndGetCampaigns(entry))
        
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)
