import * as React from 'react';
import './DashboardLayout.css';
import TrackerImages from './EditCampaign/TrackerImages';
import CampaignContent from './EditCampaign/CampaignContent';
import CampaignInfo from './EditCampaign/CampaignInfo';

export default class EditCampaign extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <CampaignInfo />
                <TrackerImages />
                <CampaignContent />
            </div>
        )
    }

}
