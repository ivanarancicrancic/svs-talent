import { ICampaign } from "../models/CampaignsModelHelper";

const baseURL = 'http://localhost:8080/api'

const defaultHeaders = {
    headers: {
        'Content-Type': 'application/json'    
    }
}

const postToBackend = (url: string, data: ICampaign, headers = defaultHeaders): Promise<any> => {
    const fullURL = baseURL + url
    return  fetch(fullURL, {
        method: 'POST',
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify(data),
    })
    .then(response => {
        console.log(response);
        return response
    })
    .catch(err => {
        console.log(err);
       return err
    });
}

const getFromBackend = (url: string, headers = defaultHeaders): Promise<any> => {
    const fullURL = baseURL + url
    return fetch(fullURL, {
        method: 'GET',
        headers: {"Content-Type": "application/json"}
    })
    .then(response => response.json())
    .then(response => {
        console.log(response);
        return response 
    })
    .catch(err => {
        console.log(err);
        return err
    });
}


export {
  //  postToBackend,
    getFromBackend, postToBackend
}
