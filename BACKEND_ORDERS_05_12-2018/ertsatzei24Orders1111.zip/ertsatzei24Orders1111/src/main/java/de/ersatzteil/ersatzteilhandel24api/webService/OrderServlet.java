package de.ersatzteil.ersatzteilhandel24api.webService;

import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;
import de.ersatzteil.ersatzteilhandel24api.client.serializer.OrderJacksonSerializer;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


@javax.servlet.annotation.WebServlet("/Orders")
public class OrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("Orders: <br/>");


        System.out.println("init");
        List<Order> order_items = null;

        try{
            ProjectManager projectManager= new ProjectManager();

            order_items = projectManager.getOrderList();
            for(Order o: order_items)
            {
//                ObjectMapper mapper = new ObjectMapper();
//                String jsonResult = mapper.writeValueAsString(o);
                SimpleModule module = new SimpleModule();
                module.addSerializer(new OrderJacksonSerializer(Order.class));
                ObjectMapper mapper = new ObjectMapper();
                String jsonResult = mapper.registerModule(module)
                        .writer(new DefaultPrettyPrinter())
                        .writeValueAsString(o);

                out.println("Order additional info: " + o.getOrderDate());
                out.println(", Order full info: " + jsonResult);
            out.println("<br/>");
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        out.println("</html></body>");


    }
}
