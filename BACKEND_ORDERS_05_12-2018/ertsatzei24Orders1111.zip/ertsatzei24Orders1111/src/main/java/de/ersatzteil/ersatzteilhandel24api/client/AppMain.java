package de.ersatzteil.ersatzteilhandel24api.client;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

public class AppMain {

    public static void main(String[] args) throws Exception {

        java.util.Date utilDate = new java.util.Date();
        java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

        Order order = new Order("4747273757895789AB-35384", sqlDate, "Credit Card", "DHL", "anrede", "Ivana", "Rancic","App-logik", "Macedonia", "some street..", "1/1-10","Skopje","1000","+38976806125","ivana.rancic@app-logik.de" );
        System.out.println("init");
        try
        {
            ProjectManager projectManager= new ProjectManager();
            System.out.println("init");
               projectManager.insertOrder(order);
               	projectManager.getOrderList();

            System.out.println("post init");
        } catch (Exception e)

        {
            System.out.println("error");
            e.printStackTrace();
        }
    }



}
