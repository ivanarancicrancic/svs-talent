package de.ersatzteil.ersatzteilhandel24api.client;

import de.ersatzteil.ersatzteilhandel24api.database.Database;
import de.ersatzteil.ersatzteilhandel24api.database.Project;
import de.ersatzteil.ersatzteilhandel24api.model.Order;

import java.sql.Connection;
import java.util.List;

public class ProjectManager {

    public List<Order> getOrderList() throws Exception {
        List<Order> order_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_items=project.getOrderList(connection);
           for(Order order: order_items)
            System.out.println(order.getEmail());

        } catch (Exception e) {
            throw e;
        }
        return order_items;
    }



    public Order insertOrder(Order order)  throws Exception {
        Order order_item= new Order();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_item=project.insertOrder(connection, order);

        } catch (Exception e) {
            throw e;
        }
        return order_item;
    }

}
