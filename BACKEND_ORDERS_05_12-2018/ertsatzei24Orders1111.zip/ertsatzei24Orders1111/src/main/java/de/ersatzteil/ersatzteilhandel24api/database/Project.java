package de.ersatzteil.ersatzteilhandel24api.database;

import de.ersatzteil.ersatzteilhandel24api.model.Order;

import javax.ws.rs.WebApplicationException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Project {

    public List<Order> getOrderList(Connection connection) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders order by orderDate");
            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next())
            {
                Date d = rs.getTimestamp(2) ;
                Order order = new Order(
                        rs.getString(1),
                          d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15)
                        );
                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                throw new WebApplicationException(404);
            }
            else
            {
                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public Order insertOrder(Connection connection, Order order) throws Exception
    {
        PreparedStatement ps=null;
        Order result=new Order();

        try
        {


            ps =connection.prepareStatement("INSERT INTO `orders` (`order_id`, `orderDate`, `paymentMethod`, `shippingWay`, `anrede`, `firstName`, `lastName`, `companyName`, `country`, `street`, `houseNumber`, `city`, `postcode`, `phoneNumber` , `email`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1,order.getOrder_id());
            ps.setObject(2,new java.sql.Timestamp(order.getOrderDate().getTime()));
            ps.setString(3,order.getPaymentMethod());
            ps.setString(4,order.getShippingWay());
            ps.setString(5,order.getAnrede());
            ps.setString(6,order.getFirstName());
            ps.setString(7,order.getLastName());
            ps.setString(8,order.getCompanyName());
            ps.setString(9,order.getCountry());
            ps.setString(10,order.getStreet());
            ps.setString(11,order.getHouseNumber());
            ps.setString(12,order.getCity());
            ps.setString(13,order.getPostcode());
            ps.setString(14,order.getPhoneNumber());
            ps.setString(15,order.getEmail());

            ResultSet rs = ps.executeQuery();
            return order;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

        finally {
            ps.close();
            connection.close();
        }
    }


}
