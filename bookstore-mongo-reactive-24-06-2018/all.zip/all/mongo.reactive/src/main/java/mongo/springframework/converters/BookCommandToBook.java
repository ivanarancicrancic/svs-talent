package mongo.springframework.converters;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.model.Book;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;


@Component
public class BookCommandToBook implements Converter<BookCommand, Book> {

    private final CategoryCommandToCategory categoryConveter;
    private final AuthorCommandToAuthor authorConverter;
    private final NotesCommandToNotes notesConverter;

    public BookCommandToBook(CategoryCommandToCategory categoryConveter, AuthorCommandToAuthor authorConverter, NotesCommandToNotes notesConverter) {
        this.categoryConveter = categoryConveter;
        this.authorConverter = authorConverter;
        this.notesConverter = notesConverter;
    }

    @Synchronized
    @Nullable
    @Override
    public Book convert(BookCommand source) {
        if (source == null) {
            return null;
        }

        final Book book = new Book();
        book.setId(source.getId());
        book.setSize(source.getSize());
        book.setEvaluation(source.getEvaluation());
        book.setDescription(source.getDescription());
        book.setDifficulty(source.getDifficulty());
        book.setUrl(source.getUrl());
        book.setNotes(notesConverter.convert(source.getNotes()));

        if (source.getCategories() != null && source.getCategories().size() > 0){
            source.getCategories()
                    .forEach( category -> book.getCategories().add(categoryConveter.convert(category)));
        }

        if (source.getAuthorCommands() != null && source.getAuthorCommands().size() > 0){
            source.getAuthorCommands()
                    .forEach(author ->  book.getAuthors().add(authorConverter.convert(author)));
        }

        return book;
    }
}
