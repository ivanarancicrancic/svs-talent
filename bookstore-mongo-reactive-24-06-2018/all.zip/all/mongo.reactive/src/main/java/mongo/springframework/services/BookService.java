package mongo.springframework.services;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.model.Book;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface BookService {

    Flux<Book> getBooks();

    Mono<Book> findById(String id);

    Mono<BookCommand> findCommandById(String id);

    Mono<BookCommand> saveBookCommand(BookCommand command);

    Mono<Void> deleteById(String idToDelete);

    public Flux<BookCommand> getBookCommands();


    // public Flux<BookCommand> getBooksReactive();

}
