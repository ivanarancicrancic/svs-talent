package mongo.springframework.converters;

import mongo.springframework.commands.AuthorCommand;
import mongo.springframework.model.Author;
import mongo.springframework.model.Book;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

@Component
public class AuthorCommandToAuthor implements Converter<AuthorCommand, Author> {

    public AuthorCommandToAuthor() {
    }

    @Nullable
    @Override
    public Author convert(AuthorCommand source) {
        if (source == null) {
            return null;
        }

        final Author author = new Author();
        author.setId(source.getId());

        if(source.getId() != null){
            Book book = new Book();
            book.setId(source.getBookId());
            book.addAuthor(author);
        }

        author.setFirstname(source.getFirstname());
        author.setLastname(source.getLastname());
        return author;
    }
}
