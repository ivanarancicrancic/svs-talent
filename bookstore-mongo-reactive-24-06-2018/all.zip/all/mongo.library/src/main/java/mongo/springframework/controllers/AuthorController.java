package mongo.springframework.controllers;

import lombok.extern.slf4j.Slf4j;
import mongo.springframework.commands.AuthorCommand;
import mongo.springframework.commands.BookCommand;
import mongo.springframework.converters.AuthorToAuthorCommand;
import mongo.springframework.model.Author;
import mongo.springframework.services.AuthorService;
import mongo.springframework.services.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Slf4j
@Controller
public class AuthorController {

    private final AuthorService authorService;
    private final BookService bookService;
    private final AuthorToAuthorCommand authorConverter;

    public AuthorController(AuthorService authorService, BookService bookService, AuthorToAuthorCommand authorConverter) {
        this.authorService = authorService;
        this.bookService = bookService;
        this.authorConverter= authorConverter;
    }

    @GetMapping("/book/{bookId}/authors")
    public String listAuthors(@PathVariable String bookId, Model model){
        System.out.println("Getting author list for book id: " + bookId);

        model.addAttribute("book", bookService.findCommandById(bookId).block());

        return "book/author/list";
    }

    @GetMapping("book/{bookId}/author/{id}/show")
    public String showBookAuthor(@PathVariable String bookId,
                                       @PathVariable String id, Model model){
        System.out.println("Entered showBookAuthor(), with bookId: " + bookId + ", and authorId: " + id);
        model.addAttribute("author", authorService.findByBookIdAndAuthorId(bookId, id).block());
        return "book/author/show";
    }

    @GetMapping("book/{bookId}/author/new")
    public String newAuthor(@PathVariable String bookId, Model model){

        BookCommand bookCommand = bookService.findCommandById(bookId).block();
        System.out.println("After bookService.findCommandById(bookId)");

        Author author = new Author();
        AuthorCommand authorCommand = authorConverter.convert(author);
        authorCommand.setBookId(bookId);
        System.out.println("After new AuthorCommand()");

        model.addAttribute("book", bookService.findById(bookId).block());
        model.addAttribute("author", authorCommand);
        return "book/author/authorform";
    }

    @GetMapping("book/{bookId}/author/{id}/update")
    public String updateBookAuthor(@PathVariable String bookId,
                                         @PathVariable String id, Model model){
        System.out.println("Book id: " + bookId);
        model.addAttribute("book", bookService.findById(bookId).block());
        model.addAttribute("author", authorService.findByBookIdAndAuthorId(bookId, id).block());
        return "book/author/authorform";
    }

    @PostMapping("book/{bookId}/author")
    public String saveOrUpdate(@PathVariable String bookId, @ModelAttribute AuthorCommand command){
        System.out.println("Before saving authorCommand - id: " + command.getId());
        AuthorCommand savedCommand = authorService.saveAuthorCommand(command).block();

        System.out.println("saved author id:" + savedCommand.getId());

        return "redirect:/book/" + bookId + "/author/" + savedCommand.getId() + "/show";
    }

    @GetMapping("book/{bookId}/author/{id}/delete")
    public String deleteAuthor(@PathVariable String bookId,
                                   @PathVariable String id){

        System.out.println("deleting author id:" + id);
        authorService.deleteById(bookId, id).block();

        return "redirect:/book/" + bookId + "/authors";
    }
}
