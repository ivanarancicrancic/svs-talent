package mongo.springframework.converters;

import lombok.Synchronized;
import mongo.springframework.commands.AuthorCommand;
import mongo.springframework.model.Author;
import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

@Component
public class AuthorToAuthorCommand implements Converter<Author, AuthorCommand> {

    public AuthorToAuthorCommand() {
    }

    @Synchronized
    @Nullable
    @Override
    public AuthorCommand convert(Author author) {
        if (author == null) {
            return null;
        }

        AuthorCommand authorCommand = new AuthorCommand();
        authorCommand.setId(author.getId());

        authorCommand.setFirstname(author.getFirstname());
        authorCommand.setLastname(author.getLastname());
        return authorCommand;
    }
}
