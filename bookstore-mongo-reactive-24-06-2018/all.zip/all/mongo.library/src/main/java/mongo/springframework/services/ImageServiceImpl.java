package mongo.springframework.services;

import lombok.extern.slf4j.Slf4j;
import mongo.springframework.model.Book;
import mongo.springframework.repositories.BookRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import reactor.core.publisher.Mono;

import java.io.IOException;

@Slf4j
@Service
public class ImageServiceImpl implements ImageService {

    private final BookRepository bookRepository;
    public ImageServiceImpl( BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    @Override
    @Transactional
    public Mono<Void> saveImageFile(String bookId, MultipartFile file) {

        try {
            Book book = bookRepository.findById(bookId).get();
            Byte[] byteObjects = new Byte[file.getBytes().length];
            int i = 0;

            for (byte b : file.getBytes()){
                byteObjects[i++] = b;
            }

            book.setImage(byteObjects);

            bookRepository.save(book);
        } catch (IOException e) {
            System.out.println("Error!");
            e.printStackTrace();
        }
        return Mono.empty();
    }
}
