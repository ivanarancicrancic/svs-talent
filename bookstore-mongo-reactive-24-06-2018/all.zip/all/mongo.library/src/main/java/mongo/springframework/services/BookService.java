package mongo.springframework.services;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.model.Book;
import reactor.core.publisher.Mono;

import java.util.Set;

public interface BookService {

    Set<Book> getBooks();

    Mono<Book> findById(String id);

    Mono<BookCommand> findCommandById(String id);

    Mono<BookCommand> saveBookCommand(BookCommand command);

    Mono<Void> deleteById(String idToDelete);

    public Set<BookCommand> getBookCommands();
}
