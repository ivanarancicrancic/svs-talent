package mongo.springframework.repositories.reactive;

import mongo.springframework.model.Book;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface BookReactiveRepository extends ReactiveMongoRepository<Book, String> {
}
