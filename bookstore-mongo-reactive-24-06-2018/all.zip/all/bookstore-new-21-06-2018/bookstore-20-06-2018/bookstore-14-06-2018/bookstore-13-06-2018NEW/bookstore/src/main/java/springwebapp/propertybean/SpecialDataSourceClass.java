package springwebapp.propertybean;

public class SpecialDataSourceClass {

    private String specialUser;
    private String specailPassword;
    private String specialUrl;

    public String getSpecialUser() {
        return specialUser;
    }

    public void setSpecialUser(String specialUser) {
        this.specialUser = specialUser;
    }

    public String getSpecailPassword() {
        return specailPassword;
    }

    public void setSpecailPassword(String specailPassword) {
        this.specailPassword = specailPassword;
    }

    public String getSpecialUrl() {
        return specialUrl;
    }

    public void setSpecialUrl(String specialUrl) {
        this.specialUrl = specialUrl;
    }
}
