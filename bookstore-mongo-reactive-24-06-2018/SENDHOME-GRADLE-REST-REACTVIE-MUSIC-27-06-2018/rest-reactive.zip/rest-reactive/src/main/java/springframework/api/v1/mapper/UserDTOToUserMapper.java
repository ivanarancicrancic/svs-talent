package springframework.api.v1.mapper;

import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import springframework.api.v1.model.CategoryDTO;
import springframework.api.v1.model.UserDTO;
import springframework.domain.Category;
import springframework.domain.User;

@Component
public class UserDTOToUserMapper implements Converter<UserDTO, User> {

    public UserDTOToUserMapper() {
    }

    @Nullable
    @Override
    public User convert(UserDTO source) {
        if (source == null) {
            return null;
        }

        final User user = new User();
        user.setId(source.getId());

        user.setFirstname(source.getFirstname());
        user.setLastname(source.getLastname());
        user.setUserUrl(source.getUserUrl());
        return user;
    }

}
