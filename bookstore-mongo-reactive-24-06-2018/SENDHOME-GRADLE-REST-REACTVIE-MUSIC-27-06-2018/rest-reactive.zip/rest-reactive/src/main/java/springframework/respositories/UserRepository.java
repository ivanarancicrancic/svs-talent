package springframework.respositories;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Component;
import springframework.domain.User;


public interface UserRepository extends ReactiveMongoRepository<User, String> {

}
