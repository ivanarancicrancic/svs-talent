package springframework.api.v1.model;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class VendorListDTO {
    List<VendorDTO> vendors;

    public List<VendorDTO> getVendors() {
        return vendors;
    }

    public void setVendors(List<VendorDTO> vendors) {
        this.vendors = vendors;
    }

    public VendorListDTO(List<VendorDTO> vendors) {
        this.vendors = vendors;
    }

    public VendorListDTO(){};
}
