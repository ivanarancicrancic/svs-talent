package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.model.UserDTO;
import springframework.api.v1.model.UserListDTO;
import springframework.domain.User;

import java.util.List;

@Component
public interface UserService {
    Flux<UserDTO> getAllUsers();
    Mono<UserDTO> getUserById(String id);
    Mono<UserDTO> patchUser(String id, UserDTO userDTO);
    Flux<UserDTO> saveUserByDTO(String id, UserDTO userDTO);
    Flux<UserDTO> saveAndReturnDTO(User user);
    Flux<UserDTO> createNewUser(UserDTO userDTO);
    Mono<Void> deleteCustomerById(String id);
}
