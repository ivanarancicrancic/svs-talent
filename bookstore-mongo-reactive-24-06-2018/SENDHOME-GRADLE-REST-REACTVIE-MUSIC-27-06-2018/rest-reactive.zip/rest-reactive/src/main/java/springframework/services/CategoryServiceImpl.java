package springframework.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.mapper.CategoryDTOToCategoryMapper;
import springframework.api.v1.mapper.CategoryToCategoryDTOMapper;
import springframework.api.v1.model.CategoryDTO;
import springframework.domain.Category;
import springframework.respositories.CategoryRepo;

@Service
@Component
public class CategoryServiceImpl  implements CategoryService {

    @Autowired
    private final CategoryToCategoryDTOMapper categoryMapper;

    @Autowired
    private final CategoryDTOToCategoryMapper categoryDTOToCategoryMapper;

    @Autowired
    private final CategoryRepo categoryRepository;


    public CategoryServiceImpl(CategoryToCategoryDTOMapper categoryMapper, CategoryRepo categoryRepository, CategoryDTOToCategoryMapper categoryDTOToCategoryMapper) {
        this.categoryMapper = categoryMapper;
        this.categoryRepository = categoryRepository;
        this.categoryDTOToCategoryMapper= categoryDTOToCategoryMapper;
    }

    //without flux
//    @Override
//    public List<CategoryDTO> getAllCategories() {
//
//        return categoryRepository.findAll()
//                .stream()
//                .map(categoryMapper::convert)
//                .collect(Collectors.toList());
//    }

    @Override
    public Flux<CategoryDTO> getAllCategories(){
        return categoryRepository
                .findAll()
                .map(categoryMapper::convert);
    }


    @Override
    public Mono<CategoryDTO> getCategoryByName(String name) {
        return categoryRepository.findByName(name)
                .map(category -> {
                    CategoryDTO categoryDTO = categoryMapper.convert(category);
                    return categoryDTO;
                });

    }

    @Override
    public Flux<CategoryDTO> createNewCategory(CategoryDTO categoryDTO) {
        return saveAndReturnDTO(categoryDTOToCategoryMapper.convert(categoryDTO));
    }


    public Flux<CategoryDTO> saveAndReturnDTO(Category category) {
        categoryRepository.save(category).block();
        return getAllCategories();
    }


    @Override
    public Flux<CategoryDTO> saveCategoryByDTO(String id, CategoryDTO categoryDTO) {
        Category category = categoryDTOToCategoryMapper.convert(categoryDTO);
        category.setId(id);
        return saveAndReturnDTO(category);
    }

    @Override
    public Mono<CategoryDTO> patchCategory(String id, CategoryDTO categoryDTO) {
        return categoryRepository.findById(id)
                .map(category -> {
                    if(categoryDTO.getName() != null){
                        category.setName(categoryDTO.getName());
                        categoryRepository.save(category).block();
                    }
                    return categoryMapper.convert(category);
                });
    }

    @Override
    public Mono<Void> deleteCategoryByID(String id) {
        categoryRepository.deleteById(id).block();
        return Mono.empty();
    }

}
