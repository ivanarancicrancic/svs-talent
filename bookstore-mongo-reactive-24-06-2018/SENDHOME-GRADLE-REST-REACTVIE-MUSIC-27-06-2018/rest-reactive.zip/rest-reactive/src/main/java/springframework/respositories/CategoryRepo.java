package springframework.respositories;


import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import springframework.domain.Category;


public interface CategoryRepo extends ReactiveMongoRepository<Category, String> {

  Mono<Category> findByName(String name);
}
