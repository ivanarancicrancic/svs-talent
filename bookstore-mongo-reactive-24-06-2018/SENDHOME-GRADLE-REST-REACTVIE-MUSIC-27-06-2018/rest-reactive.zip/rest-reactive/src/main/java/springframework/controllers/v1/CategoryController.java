package springframework.controllers.v1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import springframework.api.v1.model.CategoryListDTO;
import springframework.api.v1.model.CategoryDTO;
import springframework.services.CategoryService;

@RestController
//@Controller
@RequestMapping("/api/v1/categories/")
public class CategoryController {

    @Autowired
    private final CategoryService categoryService;

    public CategoryController(CategoryService categoryService) {
        this.categoryService = categoryService;
    }

    //without rest
//    @GetMapping
//    public ResponseEntity<CategoryListDTO> getallCatetories(){
//        return new ResponseEntity<CategoryListDTO>(
//                new CategoryListDTO(categoryService.getAllCategories()), HttpStatus.OK);
//           }



 //with rest - without webflux
//    @GetMapping
//    @ResponseStatus(HttpStatus.OK)
//    public CategoryListDTO getallCatetories(){
//        return new CategoryListDTO(categoryService.getAllCategories());
//    }

//with webflux
    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public CategoryListDTO getallCatetories(){
        return new CategoryListDTO(categoryService.getAllCategories().collectList().block());

    }



//without rest
//    @GetMapping("{name}")
//    public ResponseEntity<CategoryDTO> getCategoryByName(@PathVariable String name){
//        return new ResponseEntity<CategoryDTO>(
//                categoryService.getCategoryByName(name), HttpStatus.OK
//        );
//    }

    @GetMapping("{name}")
    @ResponseStatus(HttpStatus.OK)
    public CategoryDTO getCategoryByName(@PathVariable String name){
        return categoryService.getCategoryByName(name).block();
    }

    //without rest
//    @PostMapping
//    public ResponseEntity<CategoryListDTO> createNewCategory(@RequestBody CategoryDTO categoryDTO){
//        return new ResponseEntity<CategoryListDTO>(new CategoryListDTO(categoryService.createNewCategory(categoryDTO)),
//                HttpStatus.CREATED);
//    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CategoryListDTO createNewCategory(@RequestBody CategoryDTO categoryDTO){
        return new CategoryListDTO(categoryService.createNewCategory(categoryDTO).collectList().block());
    }

//without rest
//    @PutMapping({"/{id}"})
//    public ResponseEntity<CategoryListDTO> updateCategory(@PathVariable Long id, @RequestBody CategoryDTO categoryDTO){
//        return new ResponseEntity<CategoryListDTO>(new CategoryListDTO(categoryService.saveCategoryByDTO(id, categoryDTO)),
//                HttpStatus.OK);
//    }

    @PutMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public CategoryListDTO updateCategory(@PathVariable String id, @RequestBody CategoryDTO categoryDTO){
        return new CategoryListDTO(categoryService.saveCategoryByDTO(id, categoryDTO).collectList().block());
    }

    @DeleteMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public void deleteCategory(@PathVariable String id){

        System.out.println("Entered deleteCategory !");
        categoryService.deleteCategoryByID(id).block();

    }

}
