package springframework.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import springframework.domain.Category;
import springframework.domain.User;
import springframework.domain.Vendor;
import springframework.respositories.CategoryRepo;
import springframework.respositories.UserRepository;
import springframework.respositories.VendorRepository;

@Component
public class Bootstrap implements CommandLineRunner {
    private CategoryRepo categoryRepository;
    private UserRepository userRepository;
    private VendorRepository vendorRepository;

    public Bootstrap(CategoryRepo categoryRepository, UserRepository userRepository, VendorRepository vendorRepository) {
        this.categoryRepository = categoryRepository;
        this.userRepository= userRepository;
        this.vendorRepository = vendorRepository;
    }

    @Override
    public void run(String... args) throws Exception {

        if(categoryRepository.count().block()==0){
            System.out.println("Loading data!!!");
            loadCategories();
        }

        if(userRepository.count().block()==0){
            System.out.println("Loading data!!!");
            loadUsers();
        }

        if(vendorRepository.count().block()==0){
            System.out.println("Loading data!!!");
            loadVendors();
        }

    }

    private void loadVendors() {
        Vendor vendor1 = new Vendor();
        vendor1.setName("Vendor 1");
        vendorRepository.save(vendor1).block();

        Vendor vendor2 = new Vendor();
        vendor2.setName("Vendor 2");
        vendorRepository.save(vendor2).block();

        System.out.println("Loadded vendors: " + vendorRepository.count().block());

    }

    private void loadCategories() {

        Category music = new Category();
        music.setName("Jazz");

        Category rock = new Category();
        music.setName("Alternative Rock");

        Category pop = new Category();
        pop.setName("Pop");

        Category hiphop = new Category();
        hiphop.setName("Hiphop");

        Category blues = new Category();
        blues.setName("Blues");

        Category soul = new Category();
        soul.setName("Soul");

        Category opera = new Category();
        opera.setName("Opera");


        Category reggae = new Category();
        reggae.setName("Reggae");

        Category clasical = new Category();
        clasical.setName("Clasical music");


        Category techno = new Category();
        techno.setName("Techno");


        Category funk = new Category();
        funk.setName("Funk");


        Category punk = new Category();
        punk.setName("Punk");

        Category country = new Category();
        country.setName("Country music");

        categoryRepository.save(music).block();
        categoryRepository.save(rock).block();
        categoryRepository.save(pop).block();
        categoryRepository.save(hiphop).block();
        categoryRepository.save(blues).block();
        categoryRepository.save(soul).block();
        categoryRepository.save(opera).block();
        categoryRepository.save(reggae).block();
        categoryRepository.save(clasical).block();
        categoryRepository.save(techno).block();
        categoryRepository.save(funk).block();
        categoryRepository.save(punk).block();
        categoryRepository.save(pop).block();
        categoryRepository.save(country).block();

        System.out.println("Categories Loaded = " + categoryRepository.count().block() );
    }

    private void loadUsers() {
        User user1 = new User();
        //user1.setId(1l);
        user1.setFirstname("Ivana");
        user1.setLastname("Rancic");
        userRepository.save(user1).block();
        User user2 = new User();
        //user2.setId(2l);
        user2.setFirstname("David");
        user2.setLastname("Bowie");
        userRepository.save(user2).block();
        System.out.println("Users Loaded: " + userRepository.count().block());
    }

}
