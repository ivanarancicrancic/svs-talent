package springframework.api.v1.mapper;

import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import springframework.api.v1.model.VendorDTO;
import springframework.domain.Vendor;

@Component
public class VendorDTOToVendorMapper implements Converter<VendorDTO, Vendor> {

    public VendorDTOToVendorMapper() {
    }

    @Nullable
    @Override
    public Vendor convert(VendorDTO source) {
        if (source == null) {
            return null;
        }

        final Vendor vendor = new Vendor();
        vendor.setId(source.getId());

        vendor.setName(source.getName());

        vendor.setLastname(source.getLastname());
        return vendor;
    }

}
