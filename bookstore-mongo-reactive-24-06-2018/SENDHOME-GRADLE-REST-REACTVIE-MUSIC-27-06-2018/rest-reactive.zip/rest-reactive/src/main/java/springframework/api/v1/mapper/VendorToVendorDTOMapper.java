package springframework.api.v1.mapper;

import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import springframework.api.v1.model.VendorDTO;
import springframework.domain.Vendor;

@Component
public class VendorToVendorDTOMapper implements Converter<Vendor, VendorDTO> {

    public VendorToVendorDTOMapper() {
    }


    @Nullable
    @Override
    public VendorDTO convert(Vendor source) {
        if (source == null) {
            return null;
        }

        final VendorDTO vendorDTO = new VendorDTO();
        vendorDTO.setId(source.getId());
        vendorDTO.setName(source.getName());
        vendorDTO.setLastname(source.getLastname());
        return vendorDTO;
    }
}
