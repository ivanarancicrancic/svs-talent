package springframework.services;


import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.model.CategoryDTO;
import springframework.domain.Category;

@Component
public interface CategoryService {

    Flux<CategoryDTO> getAllCategories();

    Mono<CategoryDTO> getCategoryByName(String name);
    Mono<CategoryDTO> patchCategory(String id, CategoryDTO categoryDTO);
    Flux<CategoryDTO> saveCategoryByDTO(String id, CategoryDTO categoryDTO);
    Flux<CategoryDTO> saveAndReturnDTO(Category category);
    Flux<CategoryDTO> createNewCategory(CategoryDTO categoryDTO);
    public Mono<Void> deleteCategoryByID(String id);
}
