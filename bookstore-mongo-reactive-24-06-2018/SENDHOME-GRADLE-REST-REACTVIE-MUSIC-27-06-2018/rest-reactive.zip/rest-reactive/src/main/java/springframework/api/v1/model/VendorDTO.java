package springframework.api.v1.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component
public class VendorDTO {

    private  String id;

    private String name;

    private String lastname;

    @JsonProperty("vendor_url")
    private String vendorUrl;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVendorUrl() {
        return vendorUrl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setVendorUrl(String vendorUrl) {
        this.vendorUrl = vendorUrl;
    }

    public VendorDTO(String name, String vendorUrl) {
        this.name = name;
        this.vendorUrl = vendorUrl;
    }

    public VendorDTO(String name, String lastname, String vendorUrl) {
        this.name = name;
        this.lastname = lastname;
        this.vendorUrl = vendorUrl;
    }

    public VendorDTO(String id, String name, String lastname, String vendorUrl) {
        this.id = id;
        this.name = name;
        this.lastname = lastname;
        this.vendorUrl = vendorUrl;
    }

    public VendorDTO(){};



}