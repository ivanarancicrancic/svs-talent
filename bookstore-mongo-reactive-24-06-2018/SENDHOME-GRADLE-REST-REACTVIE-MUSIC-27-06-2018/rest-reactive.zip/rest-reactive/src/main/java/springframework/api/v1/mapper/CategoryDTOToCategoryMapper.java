package springframework.api.v1.mapper;


import org.springframework.core.convert.converter.Converter;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import springframework.api.v1.model.CategoryDTO;
import springframework.domain.Category;

@Component
public class CategoryDTOToCategoryMapper implements Converter<CategoryDTO, Category> {

    public CategoryDTOToCategoryMapper() {
    }

    @Nullable
    @Override
    public Category convert(CategoryDTO source) {
        if (source == null) {
            return null;
        }

        final Category category = new Category();
        category.setId(source.getId());

        category.setName(source.getName());
        return category;
    }
}