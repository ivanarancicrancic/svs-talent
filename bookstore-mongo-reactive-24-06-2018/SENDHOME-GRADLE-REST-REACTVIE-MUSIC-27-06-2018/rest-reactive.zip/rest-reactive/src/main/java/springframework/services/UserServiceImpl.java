package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.mapper.UserDTOToUserMapper;
import springframework.api.v1.mapper.UserToUserDTOMapper;
import springframework.api.v1.model.UserDTO;
import springframework.controllers.v1.UserController;
import springframework.domain.User;
import springframework.respositories.UserRepository;

@Service
@Component
public class UserServiceImpl implements UserService {

    private final UserDTOToUserMapper userMapper;
    private final UserRepository userRepository;
    private final UserToUserDTOMapper userToUserDTOMapper;

    public UserServiceImpl(UserDTOToUserMapper userMapper, UserRepository userRepository, UserToUserDTOMapper userToUserDTOMapper) {
        this.userMapper = userMapper;
        this.userRepository = userRepository;
        this.userToUserDTOMapper = userToUserDTOMapper;
    }

    @Override
    public Flux<UserDTO> getAllUsers() {
        return userRepository
                .findAll()
                .map(user -> {
            UserDTO userDTO = userToUserDTOMapper.convert(user);
            userDTO.setUserUrl("/api/v1/customers/" + user.getId());
            return userDTO;
        });

    }

    @Override
    public Mono<UserDTO> getUserById(String id) {
        System.out.println("Entered service getUserById with id: " + id);
        System.out.println("Returned id from userRepo: " + userRepository.findById(id).block());
        return userRepository.findById(id)
                .map(user -> {
                    UserDTO userDTO = userToUserDTOMapper.convert(user);
                    return userDTO;
                });
    }

    @Override
    public Flux<UserDTO> createNewUser(UserDTO userDTO) {
        return saveAndReturnDTO(userMapper.convert(userDTO));
    }

    public Flux<UserDTO> saveAndReturnDTO(User user) {
        userRepository.save(user).block();
        return getAllUsers();
    }

    @Override
    public Flux<UserDTO> saveUserByDTO(String id, UserDTO userDTO) {
        User user = userMapper.convert(userDTO);
        user.setId(id);
        return saveAndReturnDTO(user);
    }

    @Override
    public Mono<UserDTO> patchUser(String id, UserDTO userDTO) {
        return userRepository.findById(id).map(user -> {

            if(userDTO.getFirstname() != null){
                user.setFirstname(userDTO.getFirstname());
            }

            if(userDTO.getLastname() != null){
                user.setLastname(userDTO.getLastname());
            }

            return userToUserDTOMapper.convert(userRepository.save(user).block());
        });
    }

    private String getCustomerUrl(String id) {
        return UserController.BASE_URL + "/" + id;
    }

    @Override
    public Mono<Void> deleteCustomerById(String id) {
        userRepository.deleteById(id).block();
        return  Mono.empty();
    }

}
