package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.mapper.VendorDTOToVendorMapper;
import springframework.api.v1.mapper.VendorToVendorDTOMapper;
import springframework.api.v1.model.VendorDTO;
import springframework.api.v1.model.VendorListDTO;
import springframework.controllers.v1.VendorController;
import springframework.domain.Vendor;
import springframework.respositories.VendorRepository;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Component
public class VendorServiceIml
        implements VendorService {

    private final VendorDTOToVendorMapper vendorMapper;
    private final VendorToVendorDTOMapper vendorToVendorDTOMapper;
    private final VendorRepository vendorRepository;

    public VendorServiceIml(VendorDTOToVendorMapper vendorMapper, VendorRepository vendorRepository, VendorToVendorDTOMapper vendorToVendorDTOMapper) {
        this.vendorMapper = vendorMapper;
        this.vendorRepository = vendorRepository;
        this.vendorToVendorDTOMapper = vendorToVendorDTOMapper;
    }

    @Override
    public Mono<VendorDTO> getVendorById(String id) {
        return vendorRepository.findById(id)
                .map(vendorToVendorDTOMapper::convert)
                .map(vendorDTO -> {
                    vendorDTO.setVendorUrl(getVendorUrl(id));
                    return vendorDTO;
                });
    }

    @Override
    public Flux<VendorDTO> getAllVendors() {

            return vendorRepository
                .findAll()
                .map(vendor -> {
                    VendorDTO vendorDTO = vendorToVendorDTOMapper.convert(vendor);
                    vendorDTO.setVendorUrl(getVendorUrl(vendor.getId()));
                    return vendorDTO;
                });


    }

    @Override
    public Flux<VendorDTO> createNewVendor(VendorDTO vendorDTO) {
        return saveAndReturnDTO(vendorMapper.convert(vendorDTO));
    }

    @Override
    public Flux<VendorDTO> saveVendorByDTO(String id, VendorDTO vendorDTO) {

        Vendor vendorToSave = vendorMapper.convert(vendorDTO);
        vendorToSave.setId(id);
        return saveAndReturnDTO(vendorToSave);
    }

    @Override
    public Mono<VendorDTO> patchVendor(String id, VendorDTO vendorDTO) {

        return vendorRepository.findById(id)
                .map(vendor -> {
                    if(vendorDTO.getName() != null){
                        vendor.setName(vendorDTO.getName());
                        vendorRepository.save(vendor).block();
                    }
                    return vendorToVendorDTOMapper.convert(vendor);
                });
    }

    @Override
    public Mono<Void> deleteVendorById(String id) {
        vendorRepository.deleteById(id).block();
        return  Mono.empty();
    }

    public String getVendorUrl(String id) {
        return VendorController.BASE_URL + "/" + id;
    }

    public Flux<VendorDTO> saveAndReturnDTO(Vendor vendor) {
        vendorRepository.save(vendor).block();
        return getAllVendors();
    }




}