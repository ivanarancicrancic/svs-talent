package springframework.services;

import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import springframework.api.v1.model.VendorDTO;
import springframework.api.v1.model.VendorListDTO;
import springframework.domain.Vendor;

@Component
public interface VendorService {

    Mono<VendorDTO> getVendorById(String id);

    Flux<VendorDTO> getAllVendors();

    Flux<VendorDTO> createNewVendor(VendorDTO vendorDTO);

    Flux<VendorDTO> saveVendorByDTO(String id, VendorDTO vendorDTO);

    Mono<VendorDTO> patchVendor(String id, VendorDTO vendorDTO);

    Mono<Void> deleteVendorById(String id);

    String getVendorUrl(String id);

    Flux<VendorDTO> saveAndReturnDTO(Vendor vendor);

}
