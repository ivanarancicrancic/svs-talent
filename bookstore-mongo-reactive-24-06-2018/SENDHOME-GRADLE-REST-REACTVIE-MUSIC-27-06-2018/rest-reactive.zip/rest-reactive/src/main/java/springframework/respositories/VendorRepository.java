package springframework.respositories;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import org.springframework.stereotype.Component;
import springframework.domain.Vendor;


public interface VendorRepository extends ReactiveMongoRepository<Vendor, String> {

}