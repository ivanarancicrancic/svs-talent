package springframework.controllers.v1;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import springframework.api.v1.model.UserListDTO;
import springframework.api.v1.model.VendorDTO;
import springframework.api.v1.model.VendorListDTO;
import springframework.services.VendorServiceIml;

@RestController
@RequestMapping(VendorController.BASE_URL)
public class VendorController {

    public static final String BASE_URL = "/api/v1/vendors";

    private final VendorServiceIml vendorService;

    public VendorController(VendorServiceIml vendorService) {
        this.vendorService = vendorService;
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public VendorListDTO getVendorList(){
        return new VendorListDTO(vendorService.getAllVendors().collectList().block());
    }

    @GetMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public VendorDTO getVendorById(@PathVariable String id){
        return vendorService.getVendorById(id).block();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public VendorListDTO createNewVendor(@RequestBody VendorDTO vendorDTO){
        return new VendorListDTO(vendorService.createNewVendor(vendorDTO).collectList().block());
    }

    @PutMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public VendorListDTO updateVendor(@PathVariable String id, @RequestBody VendorDTO vendorDTO){
        return new VendorListDTO(vendorService.saveVendorByDTO(id, vendorDTO).collectList().block());
    }

    @PatchMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public VendorDTO patchVendor(@PathVariable String id, @RequestBody VendorDTO vendorDTO){
        return vendorService.patchVendor(id, vendorDTO).block();
    }

    @DeleteMapping({"/{id}"})
    @ResponseStatus(HttpStatus.OK)
    public void deleteVendor(@PathVariable String id){
        vendorService.deleteVendorById(id).block();
    }
}