package de.ersatzteil.ersatzteilhandel24api.serializer;

public class Deserializer {
}
