package de.ersatzteil.ersatzteilhandel24api.database;

import com.mysql.cj.util.StringUtils;
import de.ersatzteil.ersatzteilhandel24api.model.Order;
import de.ersatzteil.ersatzteilhandel24api.model.OrderArticles;

import javax.ws.rs.WebApplicationException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Project {

    public Integer NVL(Integer a){
        if (a==null)
        {
            return 0;
        }
        else
        {
            return a;
        }
    }


    public List<Order> getOrderList(Connection connection) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders order by orderDate");
            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next())
            {
                Date d = rs.getTimestamp(2) ;
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20)
                        );

                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                throw new WebApplicationException(404);
            }
            else
            {
                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<Order> getFilteredOrders(Connection connection, Date startDate, Date endDate) throws Exception
    {
        List<Order> order_items = new ArrayList<Order>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders where orderDate > ? and orderDate < ?");
            java.sql.Date sDate = new java.sql.Date(startDate.getTime());
            java.sql.Date eDate = new java.sql.Date(startDate.getTime());
            ps.setDate(1, new java.sql.Date(startDate.getTime()));
            ps.setDate(2, new java.sql.Date(endDate.getTime()));

            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next())
            {
                Date d = rs.getTimestamp(2) ;
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20));


                order_items.add(order);
            }

            if (order_items==null || order_items.isEmpty()){
                return  null;
            }
            else
            {
                for(Order o: order_items)
                System.out.println("ORDERR: " + o.getCompanyName());
                return order_items;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public Order getOrderDetails(Connection connection, String order_id) throws Exception
    {
       Order order_item = new Order();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orders where orders_id = ?");
            ps.setString(1, order_id);

            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next()) {
                Date d = rs.getTimestamp(2);
                Order order = new Order(
                        rs.getString(1),
                        d,
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14),
                        rs.getString(15),
                        rs.getInt(16),
                        rs.getString(17),
                        rs.getString(18),
                        rs.getString(19),
                        rs.getString(20));
                order_item = order;
            }

            if (order_item==null){
                return  null;
            }
            else
            {
                System.out.println(order_item.getEmail());
                return order_item;
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<OrderArticles> getOrderArticlesList(Connection connection, String order_id) throws Exception
    {
        List<OrderArticles> order_articles_items = new ArrayList<>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from orderarticle where orders_id = ?");
            ps.setString(1, order_id);
            System.out.println("order_id: " + order_id);
            ResultSet rs = ps.executeQuery();

            System.out.println(rs);
            while(rs.next())
            {
                OrderArticles order_article = new OrderArticles(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                       );

                order_articles_items.add(order_article);
            }

            if (order_articles_items==null || order_articles_items.isEmpty()){
                throw new WebApplicationException(404);
            }
            else
            {
                System.out.println("Article DESCRIPTION: " + order_articles_items.get(0).getArticleDescription());
                return order_articles_items;

            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void editOrder(Connection connection, Order order_item) throws Exception
    {
        PreparedStatement ps=null;
        try
        {

            ps = connection.prepareStatement(" UPDATE orders SET paymentMethod=?, shippingWay=?, anrede=?, firstName=?, lastName=?, companyName=?, country=?," +
                    " street=?, houseNumber=?, city=?, postcode=?, phoneNumber=?, email=?, netPrice=?, grossPrice=?, netPriceWD=?, grossPriceWD=?" +
                    "WHERE orders_id = ?");

//            java.sql.Date convDate = new java.sql.Date(order_item.getOrderDate().getTime());
//            ps.setDate(2, convDate);
            ps.setString(1, order_item.getPaymentMethod());
            ps.setString(2, order_item.getShippingWay());
            ps.setString(3, order_item.getAnrede());
            ps.setString(4, order_item.getFirstName());
            ps.setString(5, order_item.getLastName());
            ps.setString(6, order_item.getCompanyName());
            ps.setString(7, order_item.getCountry());
            ps.setString(8, order_item.getStreet());
            ps.setString(9, order_item.getHouseNumber());
            ps.setString(10, order_item.getCity());
            ps.setString(11, order_item.getPostcode());
            ps.setString(12, order_item.getPhoneNumber());
            ps.setString(13, order_item.getEmail());
//            ps.setInt(14, order_item.getLatest());
            ps.setString(14, order_item.getNetPrice());
            ps.setString(15, order_item.getGrossPrice());
            ps.setString(16, order_item.getNetPriceWD());
            ps.setString(17, order_item.getGrossPriceWD());
            ps.setString(18, order_item.getOrder_id());
            ps.executeUpdate();
//            System.out.println(rs);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public Order cancelOrder(Connection connection, String order_id) throws Exception
    {
        Order order = new Order();
        PreparedStatement ps=null;
        try {
            ps = connection.prepareStatement("delete from orders where orders_id = ?");
            ps.setString(1, order_id);
            System.out.println("order_id: " + order_id);
            ps.executeUpdate();

            return order;
           }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

}
