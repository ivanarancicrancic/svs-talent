package de.ersatzteil.ersatzteilhandel24api.client;

import com.mysql.cj.x.protobuf.MysqlxCrud;
import de.ersatzteil.ersatzteilhandel24api.database.Database;
import de.ersatzteil.ersatzteilhandel24api.database.Project;
import de.ersatzteil.ersatzteilhandel24api.model.Order;
import de.ersatzteil.ersatzteilhandel24api.model.OrderArticles;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ProjectManager {

    public List<Order> getOrderList() throws Exception {
        List<Order> order_items = new ArrayList<>();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_items=project.getOrderList(connection);

            if(order_items == null){
                Order o = new Order();
                o.setLatest(0);
                order_items.add(o);
            }


            for(Order order: order_items)
            System.out.println(order.getEmail());

        } catch (Exception e) {
            throw e;
        }
        return order_items;
    }


    public List<Order> getFilteredOrders(Date startDate, Date endDate) throws Exception {
        System.out.println("!!!!!!!!!!!!!!!! getFilteredOrders with Startdate: "  + startDate);
        List<Order> order_items = new ArrayList<>();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_items=project.getFilteredOrders(connection, startDate, endDate);

                if(order_items == null){
                    Order o = new Order();
//                    o.setLatest(0);
                    System.out.println("latest: " + o.getLatest());
                    order_items = new ArrayList<>();
                    order_items.add(o);
                }


            for(Order order: order_items)
                System.out.println(order.getEmail());

        } catch (Exception e) {
            throw e;
        }
        return order_items;
    }


    public Order getOrderDetails(String order_id) throws Exception {
        Order order_item = new Order();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_item = project.getOrderDetails(connection, order_id);

            if(order_item == null){
                Order o = new Order();
//                    o.setLatest(0);
             }

        } catch (Exception e) {
            throw e;
        }
        return order_item;
    }


    public List<OrderArticles> getOrderArticlesList(String order_id) throws Exception{

        List<OrderArticles> order_articles_items = new ArrayList<>();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_articles_items=project.getOrderArticlesList(connection, order_id);

            if(order_articles_items == null){
                OrderArticles o = new OrderArticles();
                order_articles_items.add(o);
            }


            for(OrderArticles orderArticle: order_articles_items)
                System.out.println(orderArticle.getArticleDescription());

        } catch (Exception e) {
            throw e;
        }
        return order_articles_items;


     }


    public void editOrder(Order order_item) throws Exception{

        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            project.editOrder(connection, order_item);

        } catch (Exception e) {
            throw e;
        }

    }

    public Order cancelOrder(String order_id) throws Exception{

        Order order = new Order();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
           order = project.cancelOrder(connection, order_id);
           return order;
        } catch (Exception e) {
            throw e;
        }

    }


}
