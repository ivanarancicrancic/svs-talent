import * as React from 'react';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import { IRootState } from '../../redux';
import { productListFetch } from '../../redux/product-list/actions';
import { IProductResponseModel } from '../../redux/product-list/types';
import { getProductList } from '../../redux/product-list/selectors';
import { productCreateFetch } from '../../redux/product/actions';
// import { history } from '../../router';
import { RouteComponentProps } from 'react-router';

interface IPropsDispatchMap {
    productListFetch: typeof productListFetch;
    productCreateFetch: typeof productCreateFetch;
}
interface IPropsStateMap {
    productsData: IProductResponseModel[] | null;
    productCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{id: number}>

class Products extends React.Component<IProps> {

    public componentWillMount() {
        const id = this.props.match.params.id;
        this.props.productListFetch({id});
      }

    // public componentWillReceiveProps(nextProps: IProps) {

    //     const productCreated = this.props.productCreating === true && nextProps.productCreating === false;
    //     if(productCreated) {
    //         history.push(`/category/${nextProps.lastCreatedId}`);
    //     }
    // }
    

    public render():any {


        if(this.props.productsData == null) {
            return null;
        }

        return (

<div className="dashboardTable">
<table className="table bp3-html-table bp3-html-table-bordered">
<tbody>
    <tr>
    {this.props.productsData.map( product => {
        return (
            <tr key={product.id}>
                <td><b>{product.name} Product</b></td>
                <td>{product.numberOfViews} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </td>
                <td><Link to={`/product/${product.id}`} className="fontello icon-edit"/> </td>
            </tr>
        )
    })}
  </tr>
    <tr>
    <td colSpan={5} className="text-center" >
        {!this.props.productCreating && <a onClick={ () => {this.props.productCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
    </td>
    </tr>
</tbody>
</table>
</div>


        )

    }

}

const mapStateToProps = (state: IRootState) => ({
    productsData: getProductList(state),
    productCreating: state.product.createLoading,
    lastCreatedId: state.product.lastCreatedId,
});

export default connect(mapStateToProps, {productListFetch, productCreateFetch})(Products)