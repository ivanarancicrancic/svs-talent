import { createLogic } from 'redux-logic';
import axios from 'axios';

import { MANUFACTURER_DETAIL_FETCH, IManufacturerDetailResponseModel, MANUFACTURER_CREATE_FETCH, MANUFACTURER_SAVE_FETCH, MANUFACTURER_EDIT_FETCH} from './types';
import { manufacturerDetailFetch, manufacturerDetailSuccess, manufacturerDetailFail, manufacturerCreateSuccess, manufacturerCreateFail, manufacturerCreateFetch, manufacturerSaveFetch, manufacturerSaveSuccess, manufacturerSaveFail, manufacturerEditFetch} from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const manufacturerDetailFetchLogic = createLogic({
    type: MANUFACTURER_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(manufacturerDetailFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/category/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IManufacturerDetailResponseModel
                dispatch(manufacturerDetailSuccess(result));
            }).catch(error => {
                dispatch(manufacturerDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const manufacturerCreateFetchLogic = createLogic({
    type: MANUFACTURER_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(manufacturerCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as IManufacturerDetailResponseModel
                dispatch(manufacturerCreateSuccess(result));
            }).catch(error => {
                dispatch(manufacturerCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const manufacturerSaveFetchLogic = createLogic({
    type: MANUFACTURER_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(manufacturerSaveFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.manufacturerId}/save`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { packageId: action.payload.packageId }
            }).then(response => {
                const result = response.data as IManufacturerDetailResponseModel
                dispatch(manufacturerSaveSuccess(result));
            }).catch(error => {
                dispatch(manufacturerSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const manufacturerEditFetchLogic = createLogic({
    type: MANUFACTURER_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(manufacturerEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload
            }).then(response => {
                const result = response.data as IManufacturerDetailResponseModel
                dispatch(manufacturerSaveSuccess(result));
            }).catch(error => {
                dispatch(manufacturerSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    manufacturerDetailFetchLogic,
    manufacturerCreateFetchLogic,
    manufacturerSaveFetchLogic,
    manufacturerEditFetchLogic
];
