import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

export type RegistrationActions = ActionType<typeof actions>;

export interface IRegistrationState {
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IRegistrationState = {
    loading: false,
    error: null
};
  
export function registerReducer(state: IRegistrationState = INITIAL_STATE, action: RegistrationActions): IRegistrationState  {
    switch (action.type) {
        case getType(actions.registerFetch):
            return {...state, loading: true, error: null};
        case getType(actions.registerSuccess):
            return {...state, loading: false, error: null};
        case getType(actions.registerFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }
}