import { MESSAGE_ADD, MESSAGE_REMOVE, IMessage } from './types';

import { createStandardAction } from 'typesafe-actions';

export const messageAdd = createStandardAction(MESSAGE_ADD)<IMessage>();
export const messageRemove = createStandardAction(MESSAGE_REMOVE)<{messageId: number}>();