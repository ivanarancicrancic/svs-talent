import {
    MANUFACTURER_LIST_FETCH,
    MANUFACTURER_LIST_SUCCESS,
    MANUFACTURER_LIST_FAIL,
    IManufacturerResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const manufacturerListFetch = createStandardAction(MANUFACTURER_LIST_FETCH)();
export const manufacturerListSuccess = createStandardAction(MANUFACTURER_LIST_SUCCESS)<IManufacturerResponseModel[]>();
export const manufacturerListFail = createStandardAction(MANUFACTURER_LIST_FAIL)<string>();
