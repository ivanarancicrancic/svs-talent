import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IJWToken } from './types';

export type AuthActions = ActionType<typeof actions>;

export interface IAuthState {
    readonly token: IJWToken | null;
    readonly loggingIn: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IAuthState = {
    error: null,
    loggingIn: false,
    token: null,
};
  
export function authReducer(state: IAuthState = INITIAL_STATE, action: AuthActions): IAuthState  {
    switch (action.type) {
        case getType(actions.loginUserSuccess):
            return {...state, token: action.payload};
        case getType(actions.loginUserFail):
            return {...state, error: action.payload};
        case getType(actions.loginLogout):
            return {...state, token: null}
        default:
            return state;
    }
}