import {
    CATEGORY_DETAIL_FETCH,
    CATEGORY_DETAIL_SUCCESS,
    CATEGORY_DETAIL_FAIL,
    
    CATEGORY_CREATE_FETCH,
    CATEGORY_CREATE_SUCCESS,
    CATEGORY_CREATE_FAIL,

    CATEGORY_SAVE_FETCH,
    CATEGORY_SAVE_SUCCESS,
    CATEGORY_SAVE_FAIL,

    CATEGORY_EDIT_FETCH,
    CATEGORY_EDIT_SUCCESS,
    CATEGORY_EDIT_FAIL,


    PRODUCT_DELETE_FETCH,
    PRODUCT_DELETE_SUCCESS,
    PRODUCT_DELETE_FAIL,

    PRODUCT_CREATE_FETCH,
    PRODUCT_CREATE_SUCCESS,
    PRODUCT_CREATE_FAIL,

    PRODUCT_EDIT_FETCH,
    PRODUCT_EDIT_SUCCESS,
    PRODUCT_EDIT_FAIL,

    ICategoryDetailResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IProductRequestModel, IProductResponseModel, PRODUCT_RENAME_FETCH, PRODUCT_RENAME_SUCCESS, PRODUCT_RENAME_FAIL } from './types';

export const categoryDetailFetch = createStandardAction(CATEGORY_DETAIL_FETCH)<{id: number}>();
export const categoryDetailSuccess = createStandardAction(CATEGORY_DETAIL_SUCCESS)<ICategoryDetailResponseModel>();
export const categoryDetailFail = createStandardAction(CATEGORY_DETAIL_FAIL)<string>();

export const categoryCreateFetch = createStandardAction(CATEGORY_CREATE_FETCH)();
export const categoryCreateSuccess = createStandardAction(CATEGORY_CREATE_SUCCESS)<ICategoryDetailResponseModel>();
export const categoryCreateFail = createStandardAction(CATEGORY_CREATE_FAIL)<string>();

export const categorySaveFetch = createStandardAction(CATEGORY_SAVE_FETCH)<{categoryId: number, packageId: number}>();
export const categorySaveSuccess = createStandardAction(CATEGORY_SAVE_SUCCESS)<ICategoryDetailResponseModel>();
export const categorySaveFail = createStandardAction(CATEGORY_SAVE_FAIL)<string>();

export const categoryEditFetch = createStandardAction(CATEGORY_EDIT_FETCH)<{id: number, name: string}>();
export const categoryEditSuccess = createStandardAction(CATEGORY_EDIT_SUCCESS)<ICategoryDetailResponseModel>();
export const categoryEditFail = createStandardAction(CATEGORY_EDIT_FAIL)<string>();

export const productDeleteFetch = createStandardAction(PRODUCT_DELETE_FETCH)<{productId: number}>();
export const productDeleteSuccess = createStandardAction(PRODUCT_DELETE_SUCCESS)<{productId: number}>();
export const productDeleteFail = createStandardAction(PRODUCT_DELETE_FAIL)<string>();

export const productCreateFetch = createStandardAction(PRODUCT_CREATE_FETCH)<{categoryId: number, data: IProductRequestModel}>();
export const productCreateSuccess = createStandardAction(PRODUCT_CREATE_SUCCESS)<IProductResponseModel>();
export const productCreateFail = createStandardAction(PRODUCT_CREATE_FAIL)<string>();

export const productEditFetch = createStandardAction(PRODUCT_EDIT_FETCH)<{data: IProductRequestModel}>();
export const productEditSuccess = createStandardAction(PRODUCT_EDIT_SUCCESS)<IProductResponseModel>();
export const productEditFail = createStandardAction(PRODUCT_EDIT_FAIL)<string>();

export const productRenameFetch = createStandardAction(PRODUCT_RENAME_FETCH)<{productId: number, name: string}>();
export const productRenameSuccess = createStandardAction(PRODUCT_RENAME_SUCCESS)<IProductResponseModel>();
export const productRenameFail = createStandardAction(PRODUCT_RENAME_FAIL)<string>();