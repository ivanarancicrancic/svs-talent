# Used Library Versions

* react-router-redux@next is used due to incompatibility with older version
* redux-logic typescript definitions coming soon? (https://github.com/jeffbski/redux-logic/pull/112)