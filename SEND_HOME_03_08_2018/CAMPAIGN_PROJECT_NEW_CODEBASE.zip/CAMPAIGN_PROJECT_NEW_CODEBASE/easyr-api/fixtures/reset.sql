DELETE FROM user_has_roles;
DELETE FROM role_has_rights;
DELETE FROM userrights;
DELETE FROM userroles;
DELETE FROM reset_password_tokens;
DELETE FROM campaigns;
DELETE FROM users;
DELETE FROM contactinfos;
