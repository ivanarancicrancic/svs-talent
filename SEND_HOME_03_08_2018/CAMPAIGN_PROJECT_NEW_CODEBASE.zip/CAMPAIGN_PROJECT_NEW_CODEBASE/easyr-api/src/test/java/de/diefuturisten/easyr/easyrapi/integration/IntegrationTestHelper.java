package de.diefuturisten.easyr.easyrapi.integration;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;

import java.util.Optional;

public class IntegrationTestHelper {
        private static  User user;
        private static ContactInformation contactInfo;
    public static void prepareUserData(UserRepository userRepository){
        UserRight userRight = new UserRight("Admin role");
        UserRole userRole = new UserRole("Admin");
        User user = new User();
        user.setFirstname("Ivica");
        user.setLastname("Taskovski");
        user.setEmail("ivica.taskovski@app-logik.de");
        user.setGender(true);
        user.setActive(false);
        //user.setId(new Long(1));
        //user.addRole();
        user.setPassword("$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq");
        user.setLanguage("EN");

        userRepository.save(user);
    }
    public static void prepareContactData(ContactInformationRepository contactInformationRepository){
        ContactInformation contactInfo = new ContactInformation();
        contactInfo.setCity("Berlin");
        contactInfo.setCompany("some-company");
        contactInfo.setEmail("ivica.taskovski@app-logik.de");
        contactInfo.setHomepage("companyInBerlin.de");
        contactInfo.setAddress("Klingeln Strasse");
        contactInfo.setAddress2("Blingeln Strasse");
        contactInfo.setNumber("+3456789012");
        contactInfo.setZip("1234");

        contactInformationRepository.save(contactInfo);

    }

    public static void prepareCampaignData(CampaignRepository campaignRepository, Optional<User> userOptional, Optional<ContactInformation> contactInformationOptional){

        Campaign campaign = new Campaign();
        campaign.setContactInformation(contactInformationOptional.get());
        campaign.setUser(userOptional.get());
        //campaign.setId(new Long(1));

        campaignRepository.save(campaign);
    }

    public static void cleanupUserData(UserRepository userRepository){
        userRepository.deleteAll();
        userRepository.flush();
    }

    public static void cleanupContactData(ContactInformationRepository contactInformationRepository){
        contactInformationRepository.deleteAll();
        contactInformationRepository.flush();
    }

    public static void cleanupCampaign(CampaignRepository campaignRepository){
        campaignRepository.deleteAll();
        campaignRepository.flush();
    }
}
