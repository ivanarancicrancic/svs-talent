package de.diefuturisten.easyr.easyrapi.entity.user;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;
import javax.persistence.*;

@Entity
@Table(name="users")
public class User {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="key_user")
    private long id;

    @Column(name="language", length = 2, nullable = false)
    private String language;

    @Column(name="active", nullable = false)
    private boolean active = false;

    @Column(name="email", nullable=false, unique=true)
    private String email;

    @Column(name="password", nullable = false)
    private String password;

    @Column(name="gender", nullable = false)
    private boolean gender;

    @Column(name="firstname", nullable = false)
    private String firstname;

    @Column(name="lastname", nullable = false)
    private String lastname;

    // TODO: additional fields

    @OneToMany(mappedBy="user")
    private List<ResetPasswordToken> resetPasswordTokens = new LinkedList<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "user_has_roles",
            joinColumns = { @JoinColumn(name = "fk_user") },
            inverseJoinColumns = { @JoinColumn(name = "fk_userrole") }
    )
    private Set<UserRole> roles = new HashSet();

    @OneToMany(mappedBy="user")
    private List<Campaign> campaigns = new LinkedList<>();

    public User() {
    }

    public User(long id) {
        this.id = id;
    }


    public boolean hasRight(String name) {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(Collection::stream)
                .anyMatch(x -> x.getName().equals(name));
    }

    public List<UserRight> getRights() {
        return this.getRoles().stream()
                .map(x -> x.getRights())
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
    }

    // Getter and Setter methods

    public Long getId() {
        return id;
    }

    public String getPassword() {
        return this.password;
    }

    public String getUsername() {
        return email;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getName() {
        return String.format("%s %s", firstname, lastname);
    }

    public Locale getPreferedLanguage() {
        Locale locale = null;
        if(this.language == null) {
            locale = Locale.GERMAN;
        } else {
            switch(this.language) {
                case "de":
                    locale = Locale.GERMAN;
                    break;
                case "en":
                    locale = Locale.ENGLISH;
                    break;
                default:
                    locale = Locale.GERMAN;
            }
        }

        return locale;
    }

    public Set<UserRole> getRoles() {
        return roles;
    }

    public List<ResetPasswordToken> getResetPasswordTokens() {
        return resetPasswordTokens;
    }

    public void addRole(UserRole userRole) {
        this.roles.add(userRole);
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(Boolean gender) {
        this.gender = gender;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public boolean getGender() {
        return gender;
    }
}