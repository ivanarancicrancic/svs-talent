package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.ArrayList;
import java.util.List;

public class CampaignCommand {

    private Long id;

    private User user;

    private List<Tracker> tracker = new ArrayList<>();

    private List<Content> contents = new ArrayList<>();

    private ContactInformation contact;

    public CampaignCommand(){};

    public CampaignCommand(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Tracker> getTracker() {
        return tracker;
    }

    public void setTracker(List<Tracker> tracker) {
        this.tracker = tracker;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    public ContactInformation getContact() {
        return contact;
    }

    public void setContact(ContactInformation contact) {
        this.contact = contact;
    }
}
