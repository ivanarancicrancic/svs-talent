package de.diefuturisten.easyr.easyrapi.security;

public final class BuiltInRights {

    public static final String CAMPAIGN_CREATE = "CAMPAIGN_CREATE";
    public static final String CAMPAIGN_DELETE = "CAMPAIGN_DELETE";
    public static final String CAMPAIGN_LIST = "CAMPAIGN_LIST";

    private BuiltInRights() {
        // NO-OP utility class
    }

}
