import React from 'react';

import MenuButton from './MenuButton';

interface RoleResult {
  id: string;
  userrole: string;
  description: string;
}

interface RoleListProps {
}

interface RoleListState {
  roles: Array<RoleResult>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Role extends React.Component<RoleListProps, RoleListState> {
	constructor(props: RoleListProps) {
    super(props);

    this.state = {
      roles: [],
      isLoading: false,
	  value: "",
	  value1: "",
	  value2: "",
	  value3: "",
	  value4: "",
	  value5: ""
    };
  
  this.handleChangeGetRoleById_roleID = this.handleChangeGetRoleById_roleID.bind(this);
  this.handleSubmit = this.handleSubmit.bind(this);
  this.handleChangeAddRoleToUser_userID = this.handleChangeAddRoleToUser_userID.bind(this);
    this.handleSubmit1 = this.handleSubmit1.bind(this);
  this.handleChangeAddRoleToUser_roleID = this.handleChangeAddRoleToUser_roleID.bind(this);
    this.handleSubmit2 = this.handleSubmit2.bind(this);
	this.handleChangeGetRolesForUser_userID = this.handleChangeGetRolesForUser_userID.bind(this);
	this.handleSubmit3 = this.handleSubmit3.bind(this);
	this.handleChangeRemoveRoleFromUser_userID = this.handleChangeRemoveRoleFromUser_userID.bind(this);
    this.handleChangeRemoveRoleFromUser_roleID = this.handleChangeRemoveRoleFromUser_roleID.bind(this);
	this.handleSubmit4 = this.handleSubmit4.bind(this);
	}
  
  handleChangeGetRoleById_roleID(event) {
    this.setState({value: event.target.value});
	
  }

  handleSubmit(event) {
    event.preventDefault();
    fetch('http://localhost:8080/getAllRoles')
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_roleID(event) {
    this.setState({value2: event.target.value});
  }

  handleSubmit1(event) {
    alert('User id entered: ' + this.state.value);
    event.preventDefault();
    fetch('http://localhost:8080/getRolesByID/role_id=' + this.state.value)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeAddRoleToUser_userID(event) {
	 this.setState({value1: event.target.value});
  }

  handleSubmit2(event) {
    alert('user_id: ' + this.state.value1 + ', role_id: ' + this.state.value2);
    event.preventDefault();
    fetch('http://localhost:8080/addRoleToUser/user_id=' + this.state.value1 + '&role_id=' + this.state.value2)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }

  handleChangeGetRolesForUser_userID(event){
	  this.setState({value3: event.target.value});
  }
  
   handleSubmit3(event) {
    alert('Entered user_id: ' + this.state.value3);
    event.preventDefault();
    fetch('http://localhost:8080/getRolesForUser/user_id=' + this.state.value3)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  handleChangeRemoveRoleFromUser_userID(event){
	  this.setState({value4: event.target.value});
  }
  
  handleChangeRemoveRoleFromUser_roleID(event){
	  this.setState({value5: event.target.value});
  }
  
  handleSubmit4(event) {
    alert('user_id: ' + this.state.value4 + ', role_id: ' + this.state.value5);
    event.preventDefault();
       fetch('http://localhost:8080/removeRoleFromUser/user_id=' + this.state.value4 + '&role_id=' + this.state.value5)
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
  
  
  componentDidMount() {
    this.setState({isLoading: true});
    fetch('http://localhost:8080/getAllRoles')
      .then(response => response.json())
      .then(data => this.setState({roles: data, isLoading: false}));
  }
	
	
  render() {
	   const {roles, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="notificationsFrame">
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">Autorization</span>
          </div>
          <div className="content">           
		   <div className="line"></div>  
		
	  <div>
        <h2>List of roles that exist: </h2><br/>
        {roles.map((role: RoleResult) =>
            <div className="item">
 		       <div key={role.id}>
                <p><b>Role ID: </b> {role.id}, <b> Role name: </b> {role.userrole},  <b> Description: </b> {role.description} </p> <br/><br/><br/>
               </div>
            </div>
        )}
     <b> This is also the result that is returned on loading on the page: </b> <br/>
		<form onSubmit={this.handleSubmit}>
  <input type="submit" value="getAllRoles" />
</form>
<br/><br/>
<b> Enter existing role_id to be searched:</b> <br/>
		<form onSubmit={this.handleSubmit1}>
  <label>
    Role_id: 
    <input type="text" name="name1" id="textBox" value={this.state.value} onChange={this.handleChangeGetRoleById_roleID} />
  </label>
  <input type="submit" value="getRoleById" />
</form>
<br/><br/>

<b> Enter existing user_id to be serached roles that corresponds to it:</b> <br/>
	<form onSubmit={this.handleSubmit3}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value3} onChange={this.handleChangeGetRolesForUser_userID} />
  </label>
			
  <input type="submit" value="getRolesForUser" />
</form>
<br/><br/>
<b> Enter existing role_id to be added to existing user_id:</b> <br/>
		<form onSubmit={this.handleSubmit2}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value1} onChange={this.handleChangeAddRoleToUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value2} onChange={this.handleChangeAddRoleToUser_roleID} />
	</label>	
  <input type="submit" value="addRoleToUser" />
</form>
<br/><br/>
<b> Enter existing role_id to be removed to existing user_id:</b> <br/>
		<form onSubmit={this.handleSubmit4}>
		  <label>
    User_id:
    <input type="text" name="name" id="textBox" value={this.state.value4} onChange={this.handleChangeRemoveRoleFromUser_userID} />
  </label>
		
  <label>
    Role_id:  
    <input type="text" name="name" id="textBox" value={this.state.value5} onChange={this.handleChangeRemoveRoleFromUser_roleID} />
	</label>	
  <input type="submit" value="removeRoleFromUser" />
</form>
	
      </div>  
	  </div>
	  </div>
	  </div>
    )
  }
}

export default Role