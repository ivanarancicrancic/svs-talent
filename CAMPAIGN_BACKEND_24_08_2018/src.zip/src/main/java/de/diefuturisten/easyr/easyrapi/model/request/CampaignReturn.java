package de.diefuturisten.easyr.easyrapi.model.request;

public class CampaignReturn {

    private Long id;

    public CampaignReturn(){};

    public CampaignReturn(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
