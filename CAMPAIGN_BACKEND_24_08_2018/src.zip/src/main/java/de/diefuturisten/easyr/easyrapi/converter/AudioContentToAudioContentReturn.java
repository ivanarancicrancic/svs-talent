package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.model.request.AudioContentReturn;
import org.springframework.core.convert.converter.Converter;

public class AudioContentToAudioContentReturn implements Converter<AudioContent, AudioContentReturn> {

    public AudioContentToAudioContentReturn(){}

    @Override
    public AudioContentReturn convert(AudioContent source) {
        AudioContentReturn audioContentReturn = new AudioContentReturn();
        System.out.println("Audio source ID: " + source.getId());
        audioContentReturn.setId(source.getId());
        System.out.println("Audio source wight: " + source.getWeight());
        audioContentReturn.setWeight(source.getWeight());
        System.out.println("Audio source name: " + source.getName());
        audioContentReturn.setName(source.getName());
        System.out.println("Audio source url: " + source.getUrl());
        audioContentReturn.setUrl(source.getUrl());

        System.out.println("Audio source trackLost: " + source.isRenderOnTrackingLost());
        if(source.isRenderOnTrackingLost() == true)
            audioContentReturn.setRenderOnTrackingLost("true");
        else
            audioContentReturn.setRenderOnTrackingLost("false");

        return audioContentReturn;
    }
}
