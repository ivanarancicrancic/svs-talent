package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SlideshowImageRepository extends JpaRepository<SlideshowImage, Long> {
}
