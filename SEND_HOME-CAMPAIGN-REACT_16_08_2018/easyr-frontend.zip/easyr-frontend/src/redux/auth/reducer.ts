import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import * as dashboard_actions from './dashboard_actions';

export type AuthActions = ActionType<typeof actions>;

export interface IAuthState {
    readonly token: string | null;
    readonly loggingIn: boolean;
    readonly error: string | null;
    campaigns: ICampaign[];
    loading: false
};
  
const INITIAL_STATE: IAuthState = {
    error: null,
    loggingIn: false,
    token: null,
    campaigns: [],
    loading: false
};

// const getCampaignsFail = ( state, action ) => {
//     return updateObject( state, { loading: false } );
// };

// const getCampaignsFetch = ( state, action ) => {
//     return updateObject( state, { loading: true } );
// };

// const getCampaignsSuccess = ( state, action ) => {
//     return updateObject( state, {
//         orders: action.orders,
//         loading: false
//     } );
// };

  
export interface ICampaign{
    id: string;
}

export function authReducer(state: IAuthState = INITIAL_STATE, action: AuthActions): IAuthState  {
    switch (action.type) {
        case getType(actions.loginUserFetch):
            return state;
        case getType(actions.loginUserSuccess):
            return {...state, token: "123faketoken"};
        case getType(actions.loginUserFail):
            return state;
        case getType(actions.loginLogout):
            return {...state, token: null};     
        case getType(actions.getCampaignsFetch): 
            return state;
        case getType(dashboard_actions.getAllCampaignsSuccess): 
            return state;
         case getType(dashboard_actions.getAllCampaignsFail): 
            return state;
        default:
            return state;
    }

};


export const reducer = ( state: IAuthState = INITIAL_STATE, action: AuthActions ) => {
    switch ( action.type ) {
        case getType(dashboard_actions.getAllCampaignsSuccess): 
            return state;
         case getType(dashboard_actions.getAllCampaignsFail): 
            return state;
        default:
            return state;
    }
};

export default {
    reducer
}

