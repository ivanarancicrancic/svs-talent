export const LOGIN_USER_FETCH = '@@login/FETCH';
export const LOGIN_USER_SUCCESS = '@@login/SUCCESS';
export const LOGIN_USER_FAIL = '@@login/FAIL';
export const LOGIN_LOGOUT = '@@login/LOGOUT';
export const  GET_CAMPAIGNS_SUCCESS = '@@campaigns/SUCCESS';
export const  GET_CAMPAIGNS_FETCH = '@@campaigns/FETCH';
export const  GET_CAMPAIGNS_FAIL = '@@campaigns/FAIL';