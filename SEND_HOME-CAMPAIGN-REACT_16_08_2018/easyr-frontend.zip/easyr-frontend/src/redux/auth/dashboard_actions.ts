import {
     GET_CAMPAIGNS_FETCH,
    GET_CAMPAIGNS_FAIL, 
    GET_CAMPAIGNS_SUCCESS 
} from './types';

import { createStandardAction } from 'typesafe-actions';
// import { ILoginFormData } from '../forms';

  const initialState = {
    campaigns: [],
    loading: false,
    purchased: false
};


 interface ICampaign {
    id: string;
  }

 export const getAllCampaignsFetch = createStandardAction(GET_CAMPAIGNS_FETCH)<void>();
export const getCampaignsSuccess = createStandardAction(GET_CAMPAIGNS_SUCCESS)<{id: string}>();
export const getCampaignsFail = createStandardAction(GET_CAMPAIGNS_FAIL)<void>();

export const getAllCampaignsSuccess = ( campaigns : ICampaign[]) => {
    return {
        type: GET_CAMPAIGNS_SUCCESS,
        campaigns: campaigns
    };
};

export const getAllCampaignsFail = ( error:Error ) => {
    return {
        type: GET_CAMPAIGNS_FAIL,
        error: error
    };
};


export const getCampaignsFetch = () => {
    return (dispatch: any) => {
        dispatch(getCampaignsFetch());
        fetch('http://localhost:8080/api/testCampaigns', {
            method: 'GET',
            headers: {"Content-Type": "application/json"},
        })
        .then(response => response.json())        
        .then( res => {
            const fetchedCampaigns = [];
            for ( let key in res.data ) {
                fetchedCampaigns.push( {
                    ...res.data[key],
                    id: key
                } );
            }
            dispatch(getAllCampaignsSuccess(fetchedCampaigns));
        } )
        .catch(err => {
            console.log(err);
            dispatch(getAllCampaignsFail(err));
        });
    }     
};

export default {
    getCampaignsFetch
}



