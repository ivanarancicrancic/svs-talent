import {
    LOGIN_USER_FETCH,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,  
    LOGIN_LOGOUT,
     GET_CAMPAIGNS_FETCH,
    // GET_CAMPAIGNS_FAIL, 
    // GET_CAMPAIGNS_SUCCESS 
} from './types';

import { createStandardAction } from 'typesafe-actions';
// import { ILoginFormData } from '../forms';


export const loginUserFetch = createStandardAction(LOGIN_USER_FETCH)<{username: string, password: string}>();
export const loginUserSuccess = createStandardAction(LOGIN_USER_SUCCESS)<void>();
export const loginUserFail = createStandardAction(LOGIN_USER_FAIL)<void>();
export const loginLogout = createStandardAction(LOGIN_LOGOUT)<void>();
 export const getCampaignsFetch = createStandardAction(GET_CAMPAIGNS_FETCH)<void>();
// export const getCampaignsSuccess = createStandardAction(GET_CAMPAIGNS_SUCCESS)<void>();
// export const getCampaignsFail = createStandardAction(GET_CAMPAIGNS_FAIL)<void>();




export const loginUser = (username:string, password:string) => {
    console.log("User Data: ", username, password);
    return (dispatch: any) => {
        dispatch(loginUserFetch({username, password}));
        fetch('http://localhost:8080/login', {
            method: 'POST',
            // headers: {
            //     'Accept': 'application/json',
            //     'Content-Type': 'application/json',
            // },
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                username,
                password
            }),
        })
        .then(response => {
            console.log(response);
            dispatch(loginUserSuccess());
        })
        .catch(err => {
            console.log(err);
            dispatch(loginUserFail());
        });
    }        
};

export default {
    loginUser
}
