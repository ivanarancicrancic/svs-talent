import * as React from 'react';

export default class PostAuthHeader extends React.Component {

    public render() {
        return (
            <div className="header">
                Post-auth Header
            </div>
        )
    }

}