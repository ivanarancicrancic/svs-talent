import * as React from 'react';
// import { IRootState } from '../../redux';
import { connect } from 'react-redux';

// import { loginUser } from '../../redux/auth/actions';
// import { RouteComponentProps } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import dashboard_actions from '../../redux/auth/dashboard_actions';

// import { PATH_ROOT } from '../../router/paths';

// import {getCampaigns} from '../../redux/auth/actions'


interface ICampaign {
    id: string;
  }


// import { Dispatch } from 'redux';

// interface IPropsDispatchMap {
//     getCampaignsFetch: typeof getCampaignsFetch;
// }

// interface IPropsStateMap {
//     auth: IAuthState,  
// }

// interface ICampaign {
//     id: string;
//   }


//   interface IStateDashboard {
//     camaigns: ICampaign[];
//     isLoading: boolean;
//     token: string;
//   }

//type IProps = IPropsStateMap & RouteComponentProps<{}>

 class DashboardContainer extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
        this.state = {
            token: ""
        }
    }

    public componentWillMount() {
        console.log(this.props);
    }

    public componentDidMount () {
        this.props.onFetchCampaigns();
        // fetch('http://localhost:8080/api/testCampaigns', {
        //     method: 'GET',
        //     headers: {"Content-Type": "application/json"}
        // })
        // .then(response => response.json())
        // .then(response => {
        //     console.log(response);
        //     this.setState({ camaigns: response, token: "", isLoading: false})

        // })
        // .catch(err => {
        //     console.log(err);
        // });
    }


    public render() {

        // const { camaigns} = this.state;
       // let camaigns = <Spinner />;
         



        return (
            <div>
            {/* <Translate value="test" /><br />
            Token: <input type="text" value={this.state.token} onChange={ (e) => this.setState({token: e.target.value}) } />
            <ReactS3Uploader
                signingUrl="/s3/sign/"
                signingUrlMethod="POST"
                accept="image/*"
                s3path="/"
                // preprocess={ () => {console.log("preprocess")} }
                // onSignedUrl={ () => {console.log("onSignedUrl")} }
                // onProgress={ () => {console.log("onProgress")} }
                // onError={ () => {console.log("onError")} }
                // onFinish={ () => {console.log("onFinish")} }
                signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.state.token }}
                // signingUrlQueryParams={{ additional: query-params }}
                signingUrlWithCredentials={false}      // in case when need to pass authentication credentials via CORS
                uploadRequestHeaders={{}}  // this is the default
                // contentDisposition="auto"
                // scrubFilename={(filename: string) => filename.replace(/[^\w\d_\-.]+/ig, '')}
                server="http://127.0.0.1:8080"
                // inputRef={cmp => this.uploadInput = cmp}
                autoUpload={true}
                /> */}
                 <h2>Campaign List</h2>
                 if ( !this.props.loading ) 
        {this.props.campaigns.map((campaign: ICampaign) =>
          <div key={campaign.id}>
            {campaign.id}<br/>
          </div>
        )}
            </div>
        )
    }
}


const mapDispatchToProps = (dispatch: any) => {
    return {
        onFetchCampaigns: () => dispatch(dashboard_actions.getCampaignsFetch())
    };
};

const mapStateToProps = (state: IAuthState) => ({
    campaigns: state.campaigns,
    loading: state.loading,
  //  auth: state.auth
});

// export default connect(mapStateToProps, {})(DashboardContainer)
export default connect(mapStateToProps, mapDispatchToProps)(DashboardContainer)