export const PATH_ROOT = '/';

export const PATH_LOGIN = '/login';
export const PATH_FORGOT_PASSWORD_REQUEST = '/login/forgot-password';
export const PATH_FORGOT_PASSWORD_RESET = '/login/reset-password/:username/:token?';
export const PATH_REGISTER = '/login/register';
export const PATH_PRIVACY = '/login/privacy';
export const PATH_TERMS = '/login/terms';
export const PATH_IMPRINT = '/login/imprint';
export const PATH_FAQ = '/login/faq';
export const PATH_DESCRIPTION = '/login/description';
export const PATH_REFERENCES = '/login/references';
export const PATH_DASHBOARD = '/dashboard';