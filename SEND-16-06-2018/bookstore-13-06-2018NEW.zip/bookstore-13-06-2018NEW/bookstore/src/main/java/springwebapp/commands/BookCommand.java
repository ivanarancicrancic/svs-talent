package springwebapp.commands;

import springwebapp.model.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BookCommand {

    private Long id;
    private String title;

    private Byte[] image;

    private EvalutationCommand evaluation;
    private Set<CommentCommand> comments = new HashSet<>();

    public String description;
    private String size;
    private String url;
    private String note;

    private PublisherCommand publisher;

    private Difficutly difficutly;

    public List<CategoryCommand> categories = new ArrayList<>();

    private String stringCategories;

    private Set<AuthorCommand> authors = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Byte[] getImage() {
        return image;
    }

    public void setImage(Byte[] image) {
        this.image = image;
    }

    public EvalutationCommand getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(EvalutationCommand evaluation) {
        this.evaluation = evaluation;
    }

    public Set<CommentCommand> getComments() {
        return comments;
    }

    public void setComments(Set<CommentCommand> comments) {
        this.comments = comments;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public PublisherCommand getPublisher() {
        return publisher;
    }

    public void setPublisher(PublisherCommand publisher) {
        this.publisher = publisher;
    }

    public Difficutly getDifficutly() {
        return difficutly;
    }

    public void setDifficutly(Difficutly difficutly) {
        this.difficutly = difficutly;
    }

    public List<CategoryCommand> getCategories() {
        return this.categories;
    }

    public void setCategories(List<CategoryCommand> categories) {
        this.categories = categories;
    }

    public String getStringCategories() {
        return stringCategories;
    }

    public void setStringCategories(String stringCategories) {
        this.stringCategories = stringCategories;
    }

    public Set<AuthorCommand> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<AuthorCommand> authors) {
        this.authors = authors;
    }
}
