package springwebapp.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import springwebapp.commands.AuthorCommand;
import springwebapp.commands.BookCommand;
import springwebapp.model.Difficutly;
import springwebappservice.service.AuthorService;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

/**
 * Created by jt on 5/18/17.
 */
@Controller
@Order(1)
public class AuthorController {
    private AuthorService authorService;

    @Autowired
    private BookService bookService;

    @Autowired
    TableAttributeService tableAttributeService;

    public AuthorController(AuthorService authorService, BookService bookService, TableAttributeService tableAttributeService) {
        this.authorService = authorService;
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
    }

    @RequestMapping("/authors")
    public String getAuthors(Model model){


        model.addAttribute("authors", authorService.getAllAuthors());

        return "authors";
    }


    @GetMapping
    @RequestMapping("/book/{bookId}/authors")
    public String listAuthors(@PathVariable String bookId, Model model){

        model.addAttribute("book", bookService.findById(Long.valueOf(bookId)));
        return "book/author/list";
    }

    @GetMapping
    @RequestMapping("/book/{bookId}/author/{authorId}/show")
    public String viewAuthor(@PathVariable String bookId, @PathVariable String authorId, Model model){
 System.out.println("Book id: " + bookId);
       System.out.println("AuthorId: " + authorId);
        model.addAttribute("author", authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId)));
        return "book/author/show";
    }

    @GetMapping
    @RequestMapping("/book/{bookId}/author/{authorId}/delete")
    public String removeAuthor(@PathVariable String bookId, @PathVariable String authorId, Model model){
        authorService.deleteAuthorFromBook(Long.valueOf(bookId), Long.valueOf(authorId));
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "redirect:/book/" + bookId + "/authors";
    }

    @GetMapping
    @RequestMapping("/book/{bookId}/author/{authorId}/update")
    public String openEditAuthor(@PathVariable String bookId, @PathVariable String authorId, Model model){
        AuthorCommand authorCommand = authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId));
        authorCommand.setBookId(Long.valueOf(bookId));
        System.out.println("Book id:" + authorCommand.getBookId());
        model.addAttribute("author", authorCommand);
        return "book/author/editauthor";
    }

    @PostMapping("authoredit")
    public String saveOrUpdate(@ModelAttribute AuthorCommand authorCommand, Model model){
        System.out.println("Before updating author! Author UPDATE CALLED WITH ID:" + authorCommand.getId() + "AND BOOK ID: " + authorCommand.getBookId());
        AuthorCommand savedAuthorCommand = authorService.updateAuthor(authorCommand);
        System.out.println("Id of author updated:" + savedAuthorCommand.getId());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "redirect:/book/" + authorCommand.getBookId() + "/authors";

    }

    @PostMapping("createAuthor")
    public String createAuthor(@ModelAttribute AuthorCommand authorCommand, Model model){
        System.out.println("BEFORE CREATING AUTHOR");
        AuthorCommand createAuthorCommand = authorService.addAuthorToBook(authorCommand.getBookId(), authorCommand);
        System.out.println("Id of author created:" + createAuthorCommand.getId() + "for book with id:" + authorCommand.getBookId());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("authors", authorService.getAllAuthors());
        return "redirect:/book/" + authorCommand.getBookId() + "/authors";

    }

    @RequestMapping("/book/{bookId}/author/create")
    public String openCreateAuthor(@PathVariable String bookId, Model model){
        AuthorCommand authorCommand = new AuthorCommand();
        authorCommand.setBookId(Long.valueOf(bookId));
        System.out.println("Book id set: " + authorCommand.getBookId());
        model.addAttribute("author", authorCommand) ;
        return "book/author/createAuthor";
    }


}
