import { combineForms } from 'react-redux-form';

export interface ILoginFormData {
    username: string;
    password: string;
}

const loginForm: ILoginFormData = {
    username: '',
    password: ''
};

export const formsReducer = combineForms({
    login: loginForm,
}, 'forms');