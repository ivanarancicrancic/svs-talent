import { applyMiddleware } from 'redux';
import { routerMiddleware } from 'react-router-redux';
import { createStore, compose } from 'redux';
import { syncTranslationWithStore, loadTranslations, setLocale } from 'react-redux-i18n';

import thunk from 'redux-thunk';
import { createLogicMiddleware } from 'redux-logic';

import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

import { translations } from '../translation';
import { reducers } from '.';
import { history } from '../router';

import authLogics from './auth/logics';

const persistConfig = {
    key: 'root',
    storage,
    whitelist: []
};

const persistedReducer = persistReducer(persistConfig, reducers);

const composeEnhancers = (
    process.env.NODE_ENV === 'development' && window && (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
  ) || compose;

const logicMiddleware = createLogicMiddleware([...authLogics], {});

const enhancer = composeEnhancers(
    applyMiddleware(routerMiddleware(history), thunk, logicMiddleware)
);

export const store = createStore(persistedReducer, {}, enhancer);
export const persistor = persistStore(store);

syncTranslationWithStore(store);
store.dispatch(loadTranslations(translations));
store.dispatch(setLocale('de'));