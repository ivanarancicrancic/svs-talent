import * as React from 'react'
import { connect } from 'react-redux'
import { editAndGetCampaigns, realCampaignData } from '../redux/actions/localCampaignsActions'
import { IRealCampaign} from '../models/CampaignsModelHelper'


interface ICampaignsState {
    entry: string
     campaignsData: IRealCampaign[]
}
interface ICampaignsProps {
    editCampaignData: any
}

class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        this.state = {
            entry: '',
             campaignsData: []
        }
    }

    public editCampaign(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
        this.setState({campaignsData: realCampaignData.campaigns})
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)

            this.editCampaign(event)
        }
    }

  public render() {
        return (
            <div>
                <div>
                    <span>FORM</span>
                    <br />
                    <input 
                        type='text' 
                        placeholder='ENTRY'
                        onChange={ e => this.handleAddress(e) }
                        onKeyPress={ e => this.handleKeyPress(e) }
                    />
                    <button
                        onClick={ e => this.editCampaign(e) }
                    >
                    Submit for info
                    </button>
                </div>
               <div> CAMPAIGNS LIST:
               {
                   realCampaignData.campaigns.map((campaign: IRealCampaign) =>
                    <div key={campaign.id}>
                      {campaign.id} 
                    </div>
                  )
                 }
                   
                    </div>
            </div>
        )
    }

    public componentWillReceiveProps(newProps: ICampaignsProps) {
        console.log(this.state)
    }
}


const mapStateToProps = (state: ICampaignsState) => {
    return {
        ...state
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        editCampaignData: (entry: number) => dispatch(editAndGetCampaigns(entry)),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)
