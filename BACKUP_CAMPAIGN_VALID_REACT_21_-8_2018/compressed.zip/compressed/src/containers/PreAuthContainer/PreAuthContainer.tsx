import * as React from 'react';
import { Switch, Route } from 'react-router';
import {
    PATH_LOGIN,
    PATH_FORGOT_PASSWORD_REQUEST,
    PATH_FORGOT_PASSWORD_RESET,
    PATH_REGISTER,
    PATH_PRIVACY, PATH_TERMS, PATH_IMPRINT, PATH_FAQ, PATH_DESCRIPTION, PATH_REFERENCES
} from '../../router/paths';
import LoginContainer from './LoginContainer';
import ForgotPasswordContainer from './ForgotPasswordContainer';
import ResetPasswordContainer from './ResetPasswordContainer';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';
import RegisterContainer from './RegisterContainer';
import PrivacyPolicy from "../../components/Terms/PrivacyPolicy";
import TermsAndConditions from "../../components/Terms/TermsAndConditions";
import Imprint from "../../components/Terms/Imprint";
import Faq from "../../components/Support/Faq";
import Description from "../../components/HomePage/Description";
import References from "../../components/HomePage/References";

export default class PreAuthContainer extends React.Component {

    public render() {
        return (
            <div className="appContainer">
                <Header />
                <div className="appContentContainer">
                    <Switch>
                        <Route path={PATH_LOGIN} exact={true} component={LoginContainer} />
                        <Route path={PATH_FORGOT_PASSWORD_REQUEST} exact={true} component={ForgotPasswordContainer} />
                        <Route path={PATH_FORGOT_PASSWORD_RESET} exact={true} component={ResetPasswordContainer} />
                        <Route path={PATH_REGISTER} exact={true} component={RegisterContainer} />
                        <Route path={PATH_PRIVACY} exact={true} component={PrivacyPolicy} />
                        <Route path={PATH_TERMS} exact={true} component={TermsAndConditions} />
                        <Route path={PATH_IMPRINT} exact={true} component={Imprint} />
                        <Route path={PATH_FAQ} exact={true} component={Faq} />
                        <Route path={PATH_DESCRIPTION} exact={true} component={Description} />
                        <Route path={PATH_REFERENCES} exact={true} component={References} />
                    </Switch>
                </div>
                <Footer />
            </div>
        )
    }

}