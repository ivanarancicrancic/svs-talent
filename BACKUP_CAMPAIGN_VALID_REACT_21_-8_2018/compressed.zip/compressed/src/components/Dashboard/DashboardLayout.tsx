import * as React from 'react';
import './DashboardLayout.css';
import {Link} from "react-router-dom";
import { PATH_CAMPAIGN_EDIT } from '../../router/paths';

export default class DashboardLayout extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <div className="grid50">
                    <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
                        <thead>
                            <tr>
                            <th>Campaign<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th>Image</th>
                            <th>Technologies<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            <th colSpan={2}>Date<button className="bp3-button bp3-icon-swap-vertical bp3-minimal"/></th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                            <td>Campaign Name 01</td>
                            <td><img src="https://loremflickr.com/60/50" /></td>
                            <td>5.5888</td>
                            <td>5.08.2018</td>
                            <td><Link to={PATH_CAMPAIGN_EDIT} className="bp3-button bp3-icon-edit bp3-minimal" /></td>
                            </tr>
                            <tr>
                            <td>Campaign Name 02</td>
                            <td><img src="https://loremflickr.com/60/50" /></td>
                            <td>2.2999</td>
                            <td>05.08.2018</td>
                            <td><Link to={PATH_CAMPAIGN_EDIT} className="bp3-button bp3-icon-edit bp3-minimal" /></td>
                            </tr>
                            <tr>
                            <td colSpan={5} className="text-center" >
                                <a className="bp3-button bp3-icon-add bp3-minimal"/>
                            </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div className="grid45">
                    <table className="table campaignTable bp3-html-table bp3-html-table-bordered">
                        <thead>
                            <tr>
                            <th colSpan={3}>Bought campaign package</th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                            <td>Bought: 5</td>
                            <td>Used: 3</td>
                            <td>Unused: 2</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
               
            </div>
        )
    }

}
