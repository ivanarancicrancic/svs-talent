package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;

public class PanoramaContentModel extends ContentModel {

    private String panoramaType;
    private String url;


    public PanoramaContentModel(PanoramaContent content) {
        super(content, "panorama");

//        this.panoramaType = content.getType().toString();
        this.url = content.getUrl();
    }

    public String getPanoramaType() {
        return panoramaType;
    }

    public void setPanoramaType(String panoramaType) {
        this.panoramaType = panoramaType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
