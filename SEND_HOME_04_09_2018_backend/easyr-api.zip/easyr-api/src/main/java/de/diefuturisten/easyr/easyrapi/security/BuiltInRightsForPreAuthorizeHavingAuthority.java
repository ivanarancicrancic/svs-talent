package de.diefuturisten.easyr.easyrapi.security;

public final class BuiltInRightsForPreAuthorizeHavingAuthority {

    private static final String HAS_AUTHORITY_PREFIX = "hasAuthority('";
    private static final String HAS_AUTHORITY_SUFFIX = "')";

    public static final String CAMPAIGN_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.CAMPAIGN_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String CAMPAIGN_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.CAMPAIGN_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String CAMPAIGN_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.CAMPAIGN_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String CAMPAIGN_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.CAMPAIGN_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String CAMPAIGN_VIEW = HAS_AUTHORITY_PREFIX + BuiltInRights.CAMPAIGN_VIEW + HAS_AUTHORITY_SUFFIX;
    public static final String PANORAMA_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.PANORAMA_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String MOVIES_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.MOVIES_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String AUDIO_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.AUDIO_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String SLIDESHOWS_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.SLIDESHOWS_LIST + HAS_AUTHORITY_SUFFIX;

    private BuiltInRightsForPreAuthorizeHavingAuthority() {
        // NO-OP utility class
    }

}
