package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotBlank;

public class CreateContentModel {

    @NotBlank
    private String name;

    private String type;
    private long id;
    private int weight;

    public CreateContentModel() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
