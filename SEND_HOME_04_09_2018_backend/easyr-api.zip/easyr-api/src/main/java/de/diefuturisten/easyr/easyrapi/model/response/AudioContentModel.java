package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;

public class AudioContentModel extends ContentModel {

    private String url;
    private boolean renderOnTrackingLost;

    public AudioContentModel(AudioContent content) {
        super(content, "audio");
        this.url = content.getUrl();
        this.renderOnTrackingLost = content.isRenderOnTrackingLost();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }
}
