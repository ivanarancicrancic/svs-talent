package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.beans.factory.annotation.Autowired;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import javax.validation.Valid;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowImageRepository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowContentRepository;

@Service
@Transactional
public class SlideshowImageService {

    @Autowired
    private SlideshowContentRepository slideshowContentRepository;

    @Autowired
    private SlideshowImageRepository slideshowImageRepository;

    public SlideshowImageService(SlideshowImageRepository slideshowImageRepository, SlideshowContentRepository slideshowContentRepository) {
        this.slideshowImageRepository = slideshowImageRepository;
        this.slideshowContentRepository = slideshowContentRepository;
    }

    public SlideshowImage create(long slideshowContentID, @Valid CreateSlideshowImageModel model) {
        SlideshowImage content = new SlideshowImage();
        SlideshowContent slideshowContent =  slideshowContentRepository.findById(slideshowContentID).get();
        content.setSlideshow(slideshowContent);
        content.setUrl(model.getUrl());
        content.setWeight(model.getWeight());
        return slideshowImageRepository.save(content);
    }

    public SlideshowImage edit(SlideshowImage content, @Valid CreateSlideshowImageModel model) {
        content.setUrl(model.getUrl());
        content.setWeight(model.getWeight());
        return slideshowImageRepository.save(content);
    }


}
