package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
@Transactional
public class TrackerService {

    private TrackerRepository trackerRepository;

    private VuforiaService vuforiaService;

    public TrackerService(TrackerRepository trackerRepository,
                          VuforiaService vuforiaService) {
        this.trackerRepository = trackerRepository;
        this.vuforiaService = vuforiaService;
    }

    public CompletableFuture<Tracker> createTrackerForCampaign(Campaign campaign, File trackerFile) {

        CompletableFuture<Tracker> result = new CompletableFuture<>();

        final Tracker tracker = new Tracker();
        tracker.setCampaign(campaign);

        String vuforiaId = vuforiaService.postTarget(UUID.randomUUID().toString(), trackerFile, tid -> {
            trackerRepository.save(tracker);
            result.complete(tracker);
        });

        tracker.setVuforiaId(vuforiaId);
        tracker.setUrl("TODO"); // TODO: get public url for uploaded file

        return result;
    }

    // TODO: complete this with Vuforia API
    public Tracker editTracker(Tracker tracker, File trackerFile) {
        tracker.setUrl( tracker.getUrl().concat("O") ); // just "testing"
        return trackerRepository.save(tracker);
    }

    public Optional<Tracker> getTrackerByVuforiaId(String vuforiaId) {
        return trackerRepository.findByVuforiaId(vuforiaId);
    }

    public Optional<Tracker> getTrackerById(long trackerId) {
        return trackerRepository.findById(trackerId);
    }

    // TODO: complete this with Vuforia API
    public void deleteTracker(Tracker tracker) {
        trackerRepository.delete(tracker);
    }
}
