package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;

@Service
@Transactional
public class PanoramaContentService {
    // TODO: rewrite service



    @Autowired
    private ContentRepository contentRepository;

    public PanoramaContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public PanoramaContent create(Campaign campaign, @Valid CreatePanoramaContentModel model) {
        PanoramaContent content = new PanoramaContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setUrl(model.getUrl());


        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public PanoramaContent edit(PanoramaContent content, @Valid EditPanoramaContentModel model) {

        content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setWeight(model.getWeight());

        return contentRepository.save(content);
    }


}
