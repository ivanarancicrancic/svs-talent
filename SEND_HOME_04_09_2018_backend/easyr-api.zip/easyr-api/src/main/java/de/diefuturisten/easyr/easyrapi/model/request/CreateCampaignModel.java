package de.diefuturisten.easyr.easyrapi.model.request;


import javax.validation.constraints.NotNull;

public class CreateCampaignModel {

    @NotNull
    private RuntimeType runtimeType;

    public CreateCampaignModel() {

    }

    enum RuntimeType {
        SMALL, MEDIUM, LARGE
    }

    public RuntimeType getRuntimeType() {
        return runtimeType;
    }

    public void setRuntimeType(RuntimeType runtimeType) {
        this.runtimeType = runtimeType;
    }
}
