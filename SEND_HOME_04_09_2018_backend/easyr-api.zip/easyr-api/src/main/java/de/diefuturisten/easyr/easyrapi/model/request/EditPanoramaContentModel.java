package de.diefuturisten.easyr.easyrapi.model.request;

public class EditPanoramaContentModel extends EditCotnentModel{
    private String panoramaType;
    private String url;

    public EditPanoramaContentModel(){}

    public String getPanoramaType() {
        return panoramaType;
    }

    public void setPanoramaType(String panoramaType) {
        this.panoramaType = panoramaType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
