package de.diefuturisten.easyr.easyrapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;

public interface SlideshowContentRepository extends JpaRepository<SlideshowContent, Long> {
}
