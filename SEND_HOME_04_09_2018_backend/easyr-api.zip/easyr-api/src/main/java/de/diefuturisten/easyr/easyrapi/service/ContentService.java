package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;

@Service
@Transactional
public class ContentService {

    @Autowired
    private ContentRepository contentRepository;

    @Autowired
    private WebviewContentService webviewContentService;

    @Autowired
    private AudioContentService audioContentService;

    @Autowired
    private MovieContentService movieContentService;

    @Autowired
    private PanoramaContentService panoramaContentService;

    @Autowired
    private UnityContentService unityContentService;

    @Autowired
    private SlideshowContentService slideshowContentService;

    @Autowired
    private SlideshowImageService slideshowImageService;


    public ContentService(
            ContentRepository contentRepository,
            WebviewContentService webviewContentService,
            AudioContentService audioContentService, MovieContentService movieContentService, PanoramaContentService panoramaContentService, UnityContentService unityContentService, SlideshowContentService slideshowContentService) {
        this.contentRepository = contentRepository;
        this.webviewContentService = webviewContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
        this.panoramaContentService = panoramaContentService;
        this.unityContentService = unityContentService;
        this.slideshowContentService = slideshowContentService;
    }

    public <T extends Content> Optional<T> getById(long id) {
        return (Optional<T>) this.contentRepository.findById(id);
    }

    public void deleteContent(Content content) {
        this.contentRepository.delete(content);
    }

    /* Webview */
    public WebviewContent createWebviewContent(Campaign campaign, CreateWebviewContentModel model) {
        WebviewContent content = webviewContentService.create(campaign, model);
        return content;
    }

    public WebviewContent editWebviewContent(WebviewContent content, CreateWebviewContentModel model) {
        WebviewContent editedContent = webviewContentService.edit(content, model);
        return editedContent;
    }

    /* Audio */
    public AudioContent createAudioContent(Campaign campaign, @Valid CreateAudioContentModel model) {
        AudioContent content = audioContentService.create(campaign, model);
        return content;
    }

    public AudioContent editAudioContent(AudioContent content, @Valid CreateAudioContentModel model) {
        AudioContent editedContent = audioContentService.edit(content, model);
        return editedContent;
    }


    /* Movie */
    public MovieContent createMovieContent(Campaign campaign, @Valid CreateMovieContentModel model) {
        MovieContent content = movieContentService.create(campaign, model);
        return content;
    }

    public MovieContent editMovieContent(MovieContent content, @Valid EditMovieContentModel model) {
        MovieContent editedContent = movieContentService.edit(content, model);
        return editedContent;
    }


    /* Panorama */
    public PanoramaContent createPanoramaContent(Campaign campaign, @Valid CreatePanoramaContentModel model) {
        PanoramaContent content = panoramaContentService.create(campaign, model);
        return content;
    }

    public PanoramaContent editPanoramaContent(PanoramaContent content, @Valid EditPanoramaContentModel model) {
        PanoramaContent editedContent = panoramaContentService.edit(content, model);
        return editedContent;
    }


    /* Unity */
    public UnityContent createUnityContent(Campaign campaign, @Valid CreateUnityContentModel model) {
        UnityContent content = unityContentService.create(campaign, model);
        return content;
    }

    public UnityContent editUnityContent(UnityContent content, @Valid EditUnityContentModel model) {
        UnityContent editedContent = unityContentService.edit(content, model);
        return editedContent;
    }

    /* Slideshow */
    public SlideshowContent createSlideshowContent(Campaign campaign, @Valid CreateSlideshowContentModel model) {
        SlideshowContent content = slideshowContentService.create(campaign, model);
        return content;
    }

    public SlideshowContent editSlideshowContent(SlideshowContent content, @Valid EditSlideshowContentModel model) {
        SlideshowContent editedContent = slideshowContentService.edit(content, model);
        return editedContent;
    }

    public boolean moveUp(Content content) {
        int currentWeight = content.getWeight();

        if(currentWeight == 1) {
            return false;
        }

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() - 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    public boolean moveDown(Content content) {
        int currentWeight = content.getWeight();

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() + 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        } else {
            return false;
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    /*
    private PanoramaContentService panoramaContentService;
    private SlideshowContentService slideshowContentService;
    private WebviewContentService webviewContentService;
    private UnityContentService unityContentService;
    private AudioContentService audioContentService;
    private MovieContentService movieContentService;

    public ContentService(
            PanoramaContentService panoramaContentService,
            SlideshowContentService slideshowContentService,
            WebviewContentService webviewContentService,
            UnityContentService unityContentService,
            AudioContentService audioContentService,
            MovieContentService movieContentService
    ) {
        this.panoramaContentService = panoramaContentService;
        this.slideshowContentService = slideshowContentService;
        this.webviewContentService = webviewContentService;
        this.unityContentService = unityContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
    }

    public List<PanoramaContent> getPanoramaContentByCampaign(Campaign campaign) {
        return panoramaContentService.findPanoramaByCampagin(campaign);
    }

    public List<SlideshowContent> getSlideshowContentByCampaign(Campaign campaign) {
        return slideshowContentService.findByCampagin(campaign);
    }

    public List<WebviewContent> getWebviewContentByCampaign(Campaign campaign) {
        return webviewContentService.findByCampagin(campaign);
    }

    public List<UnityContent> getUnityContentByCampaign(Campaign campaign) {
        return unityContentService.findByCampagin(campaign);
    }

    public List<AudioContent> getAudioContentByCampaign(Campaign campaign) {
        return audioContentService.findByCampagin(campaign);
    }

    public List<MovieContent> getMovieContentByCampaign(Campaign campaign) {
        return movieContentService.findByCampagin(campaign);
    }
    */

}
