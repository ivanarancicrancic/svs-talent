package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;

@Service
@Transactional
public class MovieContentService {
    // TODO: rewrite service

    @Autowired
    private ContentRepository contentRepository;

    public MovieContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public MovieContent create(Campaign campaign, @Valid CreateMovieContentModel model) {
        MovieContent content = new MovieContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getRotationZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getPositionZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public MovieContent edit(MovieContent content, @Valid EditMovieContentModel model) {
        content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getRotationZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getPositionZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        return contentRepository.save(content);
    }

}
