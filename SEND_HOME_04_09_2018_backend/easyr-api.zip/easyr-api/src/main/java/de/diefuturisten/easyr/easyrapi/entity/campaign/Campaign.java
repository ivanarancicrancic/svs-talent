package de.diefuturisten.easyr.easyrapi.entity.campaign;

import com.fasterxml.jackson.annotation.JsonIgnore;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="campaigns")
public class Campaign {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_campaign")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="name", nullable = false)
    private String name;

    @Column(name="description", nullable = false)
    private String description;

    @OneToMany(mappedBy="campaign")
    private List<Tracker> tracker = new java.util.ArrayList<>();

    @OneToMany(mappedBy="campaign")
    private List<Content> contents = new java.util.ArrayList<>();

    @ManyToOne()
    @JoinColumn(name="fk_contact", nullable = true)
    private ContactInformation contact;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonIgnore
    public List<Tracker> getTracker() {
        return tracker;
    }

    public void setTracker(List<Tracker> tracker) {
        this.tracker = tracker;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    @JsonIgnore
    public ContactInformation getContactInformation() {
        return contact;
    }

    public void setContactInformation(ContactInformation contactInformation) {
        this.contact = contactInformation;
    }
}
