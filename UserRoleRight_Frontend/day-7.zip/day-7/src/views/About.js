import React from 'react';

export const About = (props) => (
  <div className='about'>
    <h1>About us</h1>
  </div>
)

export default About