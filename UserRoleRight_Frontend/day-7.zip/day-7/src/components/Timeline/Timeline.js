import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Switch,
} from 'react-router-dom';

import Navbar from '../Nav/Navbar';
import Home from '../../views/Home';
import Login from '../../views/Login';
import About from '../../views/About';
import MenuButton from './MenuButton';

interface Beer {
  id: string;
  right_name: string;
  description: string;
}

interface RightsListProps {
}

interface RightListState {
  rights: Array<Beer>;
  isLoading: boolean;
}

// Don't do it like this. This is for example only
class Timeline extends React.Component<RightsListProps, RightListState> {
	constructor(props: RightsListProps) {
    super(props);

    this.state = {
      rights: [],
      isLoading: false
    };
  }

  componentDidMount() {
    this.setState({isLoading: true});

    fetch('http://localhost:8080/getAllRights')
      .then(response => response.json())
      .then(data => this.setState({rights: data, isLoading: false}));
  }
	
	
  render() {
	   const {rights, isLoading} = this.state;
	   if (isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="notificationsFrame">
        <div className="panel">
          <div className="header">
            
            <MenuButton />

            <span className="title">Autorization</span>
          </div>
          <div className="content">           
		   <div className="line"></div>  
	  <div>
        <h2>Right List</h2><br/>
        {rights.map((right: Beer) =>
            <div className="item">
               <div className="avatar">
                  <img alt='doug' src="http://www.croop.cl/UI/twitter/images/doug.jpg" />
               </div>
 		       <div key={right.id}>
                <p><b> Name: </b> {right.right_name},  <b> Description: </b> {right.description} </p> <br/><br/><br/>
               </div>
            </div>
        )}
		<form>
  <label>
    Name:
    <input type="text" name="name" />
  </label>
  <input type="submit" value="Submit" />
</form>
		
		
      </div>  
	  </div>
	  </div>
	  </div>
    )
  }
}

export default Timeline
