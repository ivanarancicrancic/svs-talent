package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserModelForAdmin;
import de.diefuturisten.easyr.easyrapi.service.AdminService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;

import javax.validation.Valid;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.model.response.CouponModel;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class AdminController {

    private final AdminService adminService;

    private final CampaignService campaignService;

    private final CampaignRuntimeService campaignRuntimeService;

    public AdminController(AdminService adminService, CampaignService campaignService, CampaignRuntimeService campaignRuntimeService) {
        this.adminService = adminService;
        this.campaignService = campaignService;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/users", method = RequestMethod.GET)
    public List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/campaigns", method = RequestMethod.GET)
    public List<CampaignOverviewModel> listAllCampaigns() {
        return campaignService.findAllCampaigns().stream()
                .map(CampaignOverviewModel::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/campaigns/{userId}", method = RequestMethod.GET)
    public List<CampaignOverviewModel> listCampaignsForUser(@PathVariable long userId) {
        User user = adminService.getUserByID(userId).orElseThrow(NoSuchElementException::new);
        return campaignService.getCampaignsForUser(user).stream()
                .map(CampaignOverviewModel::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/coupon", method = RequestMethod.POST)
    public CouponModel createCouponForGivenUserAndPackage(@Valid @RequestBody CreateCouponAdminModel model) {
        Coupon coupon = campaignRuntimeService.createCoupon(model);
        return new CouponModel(coupon);
    }
}
