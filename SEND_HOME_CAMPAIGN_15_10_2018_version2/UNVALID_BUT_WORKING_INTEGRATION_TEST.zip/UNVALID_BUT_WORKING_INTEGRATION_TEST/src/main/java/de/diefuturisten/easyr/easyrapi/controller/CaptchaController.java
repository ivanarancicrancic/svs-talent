package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.model.response.CaptchaModel;
import de.diefuturisten.easyr.easyrapi.service.CaptchaService;

import java.util.Optional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CaptchaController {

    private final CaptchaService captchaService;

    public CaptchaController(CaptchaService captchaService) {
        this.captchaService = captchaService;
    }

    @RequestMapping(value = {"/captcha", "/captcha/{lastId}"}, method = RequestMethod.POST)
    public CaptchaModel createCaptcha(@PathVariable() Optional<String> lastId) {
        // cleanup already existing captcha when getting request to create a new for provided ID
        lastId.ifPresent(s -> captchaService.deleteCaptcha(s));
        return captchaService.generateCaptcha();
    }

}
