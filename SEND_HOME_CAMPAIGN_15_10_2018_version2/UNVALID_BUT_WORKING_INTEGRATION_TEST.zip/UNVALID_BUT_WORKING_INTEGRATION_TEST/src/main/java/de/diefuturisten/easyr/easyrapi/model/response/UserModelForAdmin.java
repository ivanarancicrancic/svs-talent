package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.user.User;

public class UserModelForAdmin {

    private long id;
    private String name;
    private long numberOfCampaigns;

    public UserModelForAdmin(User user) {
        this.id = user.getId();
        this.name = user.getName();
        this.numberOfCampaigns = user.getCampaigns().size();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getNumberOfCampaigns() {
        return numberOfCampaigns;
    }

    public void setNumberOfCampaigns(long numberOfCampaigns) {
        this.numberOfCampaigns = numberOfCampaigns;
    }
}
