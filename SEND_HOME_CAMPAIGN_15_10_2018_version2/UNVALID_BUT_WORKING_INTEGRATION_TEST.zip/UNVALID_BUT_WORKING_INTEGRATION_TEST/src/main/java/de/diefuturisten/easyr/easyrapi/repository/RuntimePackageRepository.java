package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import org.springframework.data.jpa.repository.JpaRepository;


public interface RuntimePackageRepository extends JpaRepository<RuntimePackage, Long> {
}
