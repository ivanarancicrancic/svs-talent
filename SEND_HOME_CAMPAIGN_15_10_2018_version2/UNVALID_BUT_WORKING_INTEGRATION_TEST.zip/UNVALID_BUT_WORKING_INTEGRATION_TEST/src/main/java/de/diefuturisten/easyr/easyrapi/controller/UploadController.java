package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.SignedUploadURLResponse;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.S3Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("api/")

public class UploadController {

    private final Logger log = LoggerFactory.getLogger(this.getClass());
    private final S3Service s3Service;
    private final AuthenticationFacade authenticationFacade;

    public UploadController(S3Service s3Service, AuthenticationFacade authenticationFacade) {
        this.s3Service = s3Service;
        this.authenticationFacade = authenticationFacade;
    }

    @RequestMapping(value = "s3/sign/", method = RequestMethod.POST)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public SignedUploadURLResponse getSignedUploadURL(@RequestParam("objectName") String objectName, @RequestParam("contentType") String contentType, @RequestParam("path") String path) {
        log.info(String.format("objectName: %s, contentType: %s path: %s", objectName, contentType, path));
        User user = authenticationFacade.getAuthenticatedUser();
        // TODO handle NULL
        return new SignedUploadURLResponse(s3Service.signUploadRequest(user, objectName).toString());
    }

}
