package de.diefuturisten.easyr.easyrapi.vuforia;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.DateUtils;
import org.apache.http.message.BasicHeader;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;


//See the Vuforia Web Services Developer API Specification - https://developer.vuforia.com/resources/dev-guide/updating-target-cloud-database

public class UpdateTarget {

	private String url;
	private String accessKey;
	private String secretKey;

	public UpdateTarget(String url, String accessKey, String secretKey) {
		this.url = url;
		this.accessKey = accessKey;
		this.secretKey = secretKey;
	}

	public boolean updateTarget(String targetId, File file) throws URISyntaxException, IOException, JSONException {
		HttpPut putRequest = new HttpPut();
		HttpClient client = new DefaultHttpClient();
		putRequest.setURI(new URI(url + "/targets/" + targetId));
		JSONObject requestBody = new JSONObject();
		
		setRequestBody(requestBody, file);
		putRequest.setEntity(new StringEntity(requestBody.toString()));
		setHeaders(putRequest); // Must be done after setting the body
		
		HttpResponse response = client.execute(putRequest);
		// String responseStr = EntityUtils.toString(response.getEntity());
		UpdateTargetResult result = new ObjectMapper().readValue(response.getEntity().getContent(), UpdateTargetResult.class);
		// {"result_code":"Success","transaction_id":"5cef297c1de8468d9b45dce48d8fe6a0"}
        return result.isSuccess();
	}
	
	private void setRequestBody(JSONObject requestBody, File file) throws IOException, JSONException {
		byte[] image = FileUtils.readFileToByteArray(file);
		requestBody.put("image", Base64.encodeBase64String(image));
	}
	
	private void setHeaders(HttpUriRequest request) {
		SignatureBuilder sb = new SignatureBuilder();
		request.setHeader(new BasicHeader("Date", DateUtils.formatDate(new Date()).replaceFirst("[+]00:00$", "")));
		request.setHeader(new BasicHeader("Content-Type", "application/json"));
		request.setHeader("Authorization", "VWS " + accessKey + ":" + sb.tmsSignature(request, secretKey));
	}

	static class UpdateTargetResult {

		public String result_code;
		public String transaction_id;

		public UpdateTargetResult() {

		}

		public boolean isSuccess() {
			return result_code.equals("Success");
		}
	}

}
