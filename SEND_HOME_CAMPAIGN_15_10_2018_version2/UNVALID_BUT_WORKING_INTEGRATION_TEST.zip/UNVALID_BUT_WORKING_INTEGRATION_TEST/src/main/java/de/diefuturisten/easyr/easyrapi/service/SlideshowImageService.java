package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowImageRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class SlideshowImageService {

    private final SlideshowContentRepository slideshowContentRepository;

    private final SlideshowImageRepository slideshowImageRepository;

    public SlideshowImageService(SlideshowImageRepository slideshowImageRepository, SlideshowContentRepository slideshowContentRepository) {
        this.slideshowImageRepository = slideshowImageRepository;
        this.slideshowContentRepository = slideshowContentRepository;
    }

    public Optional<SlideshowImage> getById(long id) {
        return this.slideshowImageRepository.findById(id);
    }

    public SlideshowImage create(long slideshowContentID, @Valid CreateSlideshowImageModel model) {
        SlideshowImage image = new SlideshowImage();
        SlideshowContent slideshowContent =  slideshowContentRepository.findById(slideshowContentID).get();
        image.setSlideshow(slideshowContent);
        image.setUrl(model.getUrl());

        Optional<SlideshowImage> contentWithHeighestWeight = slideshowImageRepository.findFirstBySlideshowOrderByWeightDesc(slideshowContent);
        if (contentWithHeighestWeight.isPresent()) {
            image.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            image.setWeight(1);
        }

        return slideshowImageRepository.save(image);
    }

    public SlideshowImage delete(long imageID) {
        SlideshowImage imageToBeDeleted = slideshowImageRepository.findById(imageID).get();
         slideshowImageRepository.delete(imageToBeDeleted);
       return imageToBeDeleted;
    }

    public void delete(SlideshowImage image) {
        slideshowImageRepository.delete(image);
    }

    public void delete(List<SlideshowImage> images) {
        slideshowImageRepository.deleteAll(images);
    }

    public SlideshowImage edit(SlideshowImage image, @Valid CreateSlideshowImageModel model) {
        image.setUrl(model.getUrl());
        image.setWeight(model.getWeight());
        return slideshowImageRepository.save(image);
    }

    public boolean moveUp(SlideshowImage image) {
        int currentWeight = image.getWeight();

        if(currentWeight == 1) {
            return false;
        }

         SlideshowContent slideshowContent = image.getSlideshow();

        int desiredWeight = image.getWeight() - 1;
        Optional<SlideshowImage> contentAtDesiredWeightOpt = slideshowImageRepository.findFirstBySlideshowAndWeight(slideshowContent, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            SlideshowImage contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            slideshowImageRepository.save(contentAtDesiredWeight);
        }

        image.setWeight(desiredWeight);
        slideshowImageRepository.save(image);

        return true;
    }

    public boolean moveDown(SlideshowImage image) {
        int currentWeight = image.getWeight();

        SlideshowContent slideshowContent = image.getSlideshow();

        int desiredWeight = image.getWeight() + 1;
        Optional<SlideshowImage> contentAtDesiredWeightOpt = slideshowImageRepository.findFirstBySlideshowAndWeight(slideshowContent, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            SlideshowImage contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            slideshowImageRepository.save(contentAtDesiredWeight);
        } else {
            return false;
        }

        image.setWeight(desiredWeight);
        slideshowImageRepository.save(image);

        return true;
    }


}
