package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;

public class MoreInfoContentModel extends ContentModel {

    private String url;

    public MoreInfoContentModel() {}

    public MoreInfoContentModel(MoreInfoContent content) {
        super(content, "moreinfo");

        this.url = content.getUrl();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
