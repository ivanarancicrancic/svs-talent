package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.exceptions.InvalidTrackerImageException;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Optional;
import java.util.UUID;

@Service
@Transactional
public class TrackerService {

    private final TrackerRepository trackerRepository;
    private final VuforiaService vuforiaService;
    private final S3Service s3Service;

    public TrackerService(TrackerRepository trackerRepository,
                          VuforiaService vuforiaService,
                          S3Service s3Service) {
        this.trackerRepository = trackerRepository;
        this.vuforiaService = vuforiaService;
        this.s3Service = s3Service;
    }

    public Tracker createTrackerForCampaign(Campaign campaign, File trackerFile) {

        final Tracker tracker = new Tracker();
        tracker.setCampaign(campaign);

        String targetName = UUID.randomUUID().toString();

        try {
            String targetId = vuforiaService.postTarget(targetName, trackerFile, null);
            tracker.setVuforiaId(targetId);
            String url = s3Service.uploadTracker(targetId, trackerFile);
            tracker.setUrl(url);
            trackerRepository.save(tracker);
        } catch (InvalidTrackerImageException e) {
            throw new RuntimeException();
        }

        return tracker;
    }

    public Tracker editTracker(Tracker tracker, File trackerFile) {
        boolean result = vuforiaService.updateTarget(tracker.getVuforiaId(), trackerFile);
        if(result) {
            String url = s3Service.uploadTracker(tracker.getVuforiaId(), trackerFile);
            tracker.setUrl(url);
            return trackerRepository.save(tracker);
        } else {
            return null;
        }
    }

    public Optional<Tracker> getTrackerByVuforiaId(String vuforiaId) {
        return trackerRepository.findByVuforiaId(vuforiaId);
    }

    public Optional<Tracker> getTrackerById(long trackerId) {
        return trackerRepository.findById(trackerId);
    }

    public boolean deleteTracker(Tracker tracker) {
        boolean result = vuforiaService.deleteTarget(tracker.getVuforiaId());
        if(result) {
            s3Service.deleteTracker(tracker.getVuforiaId());
            trackerRepository.delete(tracker);
            return true;
        } else {
            return false;
        }
    }

    public Tracker incrementTrackings(Tracker tracker) {
        tracker.setTrackings(tracker.getTrackings() + 1);
        return trackerRepository.save(tracker);
    }
}
