package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CampaignDetailModel {

    private long id;
    private String name;
    private String description;
    private List<TrackerModel> tracker;
    private List<ContentModel> contents;
    private boolean temporary;

    private Long activePackageId;

    public CampaignDetailModel() {
    }

    private ContentModel contentToModel(Content content) {
        if(content instanceof WebviewContent) {
            return new WebviewContentModel((WebviewContent) content);
        } else if(content instanceof SlideshowContent) {
            return new SlideshowContentModel((SlideshowContent) content);
        } else if(content instanceof PanoramaContent) {
            return new PanoramaContentModel((PanoramaContent) content);
        } else if(content instanceof AudioContent) {
            return new AudioContentModel((AudioContent) content);
        } else if(content instanceof MovieContent) {
            return new MovieContentModel((MovieContent) content);
        } else if(content instanceof UnityContent) {
            return new UnityContentModel((UnityContent) content);
        } else if(content instanceof MoreInfoContent) {
            return new MoreInfoContentModel((MoreInfoContent) content);
        } else {
            return new ContentModel(content, null);
        }

    }

    public CampaignDetailModel(Campaign campaign) {
        this.id = campaign.getId();
        this.name = campaign.getName();
        this.description = campaign.getDescription();

        this.tracker = campaign
                .getTracker()
                .stream()
                .map(TrackerModel::new)
                .collect(Collectors.toList());

        List<Content> campaignContents = campaign.getContents();
        campaignContents.sort(Comparator.comparingInt(Content::getWeight));
        this.contents = campaignContents
                .stream()
                .map(this::contentToModel)
                .collect(Collectors.toList());

        this.temporary = campaign.isTemporary();

        if(campaign.getRuntimes().size() > 0) {
            this.activePackageId = campaign.getRuntimes().get(campaign.getRuntimes().size() - 1).getPackageBuy().getRuntimePackage().getId();
        } else {
            this.activePackageId = null;
        }

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<TrackerModel> getTracker() {
        return tracker;
    }

    public void setTracker(List<TrackerModel> tracker) {
        this.tracker = tracker;
    }

    public List<ContentModel> getContents() {
        return contents;
    }

    public void setContents(List<ContentModel> contents) {
        this.contents = contents;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    public Long getActivePackageId() {
        return activePackageId;
    }

    public void setActivePackageId(Long activePackageId) {
        this.activePackageId = activePackageId;
    }
}
