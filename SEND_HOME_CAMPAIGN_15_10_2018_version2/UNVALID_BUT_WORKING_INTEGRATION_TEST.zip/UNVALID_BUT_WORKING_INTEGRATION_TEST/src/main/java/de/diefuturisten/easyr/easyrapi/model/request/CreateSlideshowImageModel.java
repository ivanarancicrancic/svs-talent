package de.diefuturisten.easyr.easyrapi.model.request;

public class CreateSlideshowImageModel extends CreateContentModel {

    private int weight;
    private String url;

    public CreateSlideshowImageModel(){}


    @Override
    public int getWeight() {
        return weight;
    }

    @Override
    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
