package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import javax.validation.Valid;
import java.util.Optional;

@Service
@Transactional
public class AudioContentService {

    private final ContentRepository contentRepository;

    public AudioContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public AudioContent create(Campaign campaign, @Valid CreateAudioContentModel model) {
        AudioContent content = new AudioContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setRenderOnTrackingLost(model.getRenderOnTrackingLost());

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);

    }

    public AudioContent edit(AudioContent content, @Valid CreateAudioContentModel model) {
        // content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setRenderOnTrackingLost(model.getRenderOnTrackingLost());
        return contentRepository.save(content);
    }
}
