package de.diefuturisten.easyr.easyrapi.unittest;

import org.springframework.test.web.servlet.MockMvc;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.controller.RuntimePackagesController;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import org.junit.Test;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.RequestBuilder;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import java.util.List;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesModel;
import de.diefuturisten.easyr.easyrapi.model.request.BuyPackageRequestModel;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import  org.springframework.test.web.servlet.MvcResult;
import de.diefuturisten.easyr.easyrapi.exceptions.CouponNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoMoneyException;
import de.diefuturisten.easyr.easyrapi.exceptions.RuntimePackageNotFoundException;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesCountModel;
import org.springframework.mock.web.MockHttpServletResponse;
import org.junit.Assert;
import org.springframework.http.HttpStatus;
import java.math.BigDecimal;

public class RuntimePackageControllerTest {
    private MockMvc mockMvc;
    private RuntimePackagesController runtimePackageController;
    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;
    private ObjectMapper mapper;
    private RuntimePackage runtimePackage;
    private RuntimePackage runtimePackage1;
    private RuntimePackage runtimePackage2;
    private User user;
    private BigDecimal bigDecimal;
    private PackageBuy packageBuy;

    @Before
    public void setUp(){
        authenticationFacade = mock(AuthenticationFacade.class);
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        runtimePackage = mock(RuntimePackage.class);
        runtimePackage1 = mock(RuntimePackage.class);
        runtimePackage2 = mock(RuntimePackage.class);
        user = mock(User.class);
        packageBuy = mock(PackageBuy.class);
        bigDecimal = mock(java.math.BigDecimal.class);
        runtimePackageController =new RuntimePackagesController(authenticationFacade, campaignRuntimeService);
        mockMvc = MockMvcBuilders.standaloneSetup(runtimePackageController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void getAllRuntimePackages() throws Exception {
        List<RuntimePackage> runtimePackages = new ArrayList<>();
        runtimePackages.add(runtimePackage);
        runtimePackages.add(runtimePackage1);
        runtimePackages.add(runtimePackage2);

        Mockito.when(campaignRuntimeService.getAllPackages()).thenReturn(runtimePackages);
        Mockito.when(runtimePackage.getPrice()).thenReturn(bigDecimal);
        Mockito.when(runtimePackage1.getPrice()).thenReturn(bigDecimal);
        Mockito.when(runtimePackage2.getPrice()).thenReturn(bigDecimal);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/packages").accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        Assert.assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void getUserPackages() throws Exception {
        UserPackagesCountModel userPackagesCountModel = new UserPackagesCountModel();
        userPackagesCountModel.setId(1L);
        userPackagesCountModel.setCount(2L);
        userPackagesCountModel.setName("User package name");
        UserPackagesCountModel userPackagesCountModel2 = new UserPackagesCountModel();
        userPackagesCountModel2.setId(1L);
        userPackagesCountModel2.setCount(2L);
        userPackagesCountModel2.setName("User package name");
        List<UserPackagesCountModel> countModelList = new java.util.ArrayList<>();
        countModelList.add(userPackagesCountModel);
        countModelList.add(userPackagesCountModel2);

        UserPackagesModel userPackagesModel = new UserPackagesModel();
        userPackagesModel.setUsed(countModelList);
        userPackagesModel.setAvailable(countModelList);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignRuntimeService.getPackagesForUser(Mockito.any(User.class))).thenReturn(userPackagesModel);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/packages/own").accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        Assert.assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void buyPackage() throws Exception, RuntimePackageNotFoundException, CouponNotFoundException, NoMoneyException {
        BuyPackageRequestModel buyPackageRequestModel = new BuyPackageRequestModel();
        buyPackageRequestModel.setCouponId(1L);
        buyPackageRequestModel.setPackageId(1L);
        buyPackageRequestModel.setCouponCode("538934053890FFF");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignRuntimeService.buyPackage(Mockito.any(User.class), Mockito.any(BuyPackageRequestModel.class))).thenReturn(packageBuy);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                    .post("/api/package/buy")
                    .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                            .writeValueAsString(buyPackageRequestModel))
                    .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        Assert.assertEquals(HttpStatus.OK.value(), response.getStatus());
        }
}
