package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.service.WebviewContentService;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import de.diefuturisten.easyr.easyrapi.service.UnityContentService;
import de.diefuturisten.easyr.easyrapi.service.MoreinfoContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import de.diefuturisten.easyr.easyrapi.service.ContentService;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMoreinfoContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditContentNameModel;

public class ContentServiceTest {
    private Campaign campaign;
    private ContentRepository contentRepository;
    private WebviewContentService webviewContentService;
    private AudioContentService audioContentService;
    private MovieContentService movieContentService;
    private PanoramaContentService panoramaContentService;
    private UnityContentService unityContentService;
    private MoreinfoContentService moreinfoContentService;
    private SlideshowContentService slideshowContentService;
    private SlideshowImageService slideshowImageService;
    private ContentService contentService;
    private Content content;
    private WebviewContent webviewContent;
    private AudioContent audioContent;
    private MovieContent movieContent;
    private PanoramaContent mockPanorama;
    private UnityContent mockUnity;
    private SlideshowContent mockSlideshowContent;
    private SlideshowImage mockSlideshowImage;
    private MoreInfoContent moreInfoContent;

    @Before
    public void setUp() {
        campaign = mock(Campaign.class);
        contentRepository = mock(ContentRepository.class);
        webviewContentService = mock(WebviewContentService.class);
        audioContentService = mock(AudioContentService.class);
        movieContentService = mock(MovieContentService.class);
        panoramaContentService = mock(PanoramaContentService.class);
        unityContentService = mock(UnityContentService.class);
        moreinfoContentService = mock(MoreinfoContentService.class);
        slideshowContentService = mock(SlideshowContentService.class);
        slideshowImageService = mock(SlideshowImageService.class);
        content = mock(Content.class);
        webviewContent = mock(WebviewContent.class);
        audioContent = mock(AudioContent.class);
        movieContent = mock(MovieContent.class);
        mockPanorama = mock(PanoramaContent.class);
        mockUnity = mock(UnityContent.class);
        mockSlideshowContent = mock(SlideshowContent.class);
        mockSlideshowImage = mock(SlideshowImage.class);
        moreInfoContent = mock(MoreInfoContent.class);
        contentService = new ContentService(contentRepository, webviewContentService, audioContentService, movieContentService, panoramaContentService, unityContentService, moreinfoContentService, slideshowContentService, slideshowImageService);
    }

    @Test
    public void getById(){
        Mockito.when(contentRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(content));
        contentService.getById(1L);
        assertNotNull(contentService.getById(1L));
    }

    @Test
    public void deleteContent(){
        doNothing().when(contentRepository).delete(Mockito.any(Content.class));
        assertTrue(contentService.deleteContent(content));
    }

    @Test
    public void createWebviewContent(){
        CreateWebviewContentModel model = new CreateWebviewContentModel();
        model.setId(1L);
        model.setUrl("http://www.example.com/");
        model.setName("Webview Name");
        model.setType("NORMAL");
        model.setWeight(1);

        Mockito.when(webviewContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);
        assertNotNull(contentService.createWebviewContent(campaign, model));
    }

    @Test
    public void editWebviewContent(){
        CreateWebviewContentModel model = new CreateWebviewContentModel();
        model.setId(1L);
        model.setUrl("http://www.example.com/");
        model.setName("Webview Name");
        model.setType("NORMAL");
        model.setWeight(1);

        Mockito.when(webviewContentService.edit(Mockito.any(WebviewContent.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);
        assertNotNull(contentService.editWebviewContent(webviewContent, model));
    }

    @Test
    public void createAudioContent(){
        CreateAudioContentModel model = new CreateAudioContentModel();
        model.setId(1L);
        model.setUrl("http://www.example.com/");
        model.setName("Audio Name");
        model.setType("NORMAL");
        model.setWeight(1);
        model.setRenderOnTrackingLost(true);

        Mockito.when(audioContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);
        assertNotNull(contentService.createAudioContent(campaign, model));
    }

    @Test
    public void editAudioContent(){
        CreateAudioContentModel model = new CreateAudioContentModel();
        model.setId(1L);
        model.setUrl("http://www.example.com/");
        model.setName("Audio Name");
        model.setType("NORMAL");
        model.setWeight(1);
        model.setRenderOnTrackingLost(true);

        Mockito.when(audioContentService.edit(Mockito.any(AudioContent.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);
        assertNotNull(contentService.editAudioContent(audioContent, model));
    }

    @Test
    public void createMovieContent(){
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("http://www.example.com/");
        createMovieContentModel.setName("Movie Name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("NORMAL");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);

        Mockito.when(movieContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateMovieContentModel.class))).thenReturn(movieContent);
        assertNotNull(contentService.createMovieContent(campaign, createMovieContentModel));
    }

    @Test
    public void editMovieContent(){
        EditMovieContentModel editMovieContentModel = new EditMovieContentModel();
        editMovieContentModel.setUrl("blahsth");
        editMovieContentModel.setName("newMovie name");
        editMovieContentModel.setWeight(1);
        editMovieContentModel.setRenderOnTrackingLost(true);
        editMovieContentModel.setType("type");

        Mockito.when(movieContentService.edit(Mockito.any(MovieContent.class), Mockito.any(EditMovieContentModel.class))).thenReturn(movieContent);
        assertNotNull(contentService.editMovieContent(movieContent, editMovieContentModel));
    }

    @Test
    public void createPanoramaContent(){
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("http://www.example.com/");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(panoramaContentService.create(Mockito.any(Campaign.class), Mockito.any(CreatePanoramaContentModel.class))).thenReturn(mockPanorama);
        assertNotNull(contentService.createPanoramaContent(campaign, createPanoramaContentModel));
    }

    @Test
    public void editPanoramaContent(){
        EditPanoramaContentModel editPanoramaContentModel = new EditPanoramaContentModel();
        editPanoramaContentModel.setUrl("http://www.example.com/");
        editPanoramaContentModel.setName("newMovie name");
        editPanoramaContentModel.setWeight(1);
        editPanoramaContentModel.setType("type");
        editPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(panoramaContentService.edit(Mockito.any(PanoramaContent.class), Mockito.any(EditPanoramaContentModel.class))).thenReturn(mockPanorama);
        assertNotNull(contentService.editPanoramaContent(mockPanorama, editPanoramaContentModel));
    }

    @Test
    public void createUnityContent(){
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("webview name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("type");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(unityContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateUnityContentModel.class))).thenReturn(mockUnity);
        assertNotNull(contentService.createUnityContent(campaign, createUnityContentModel));
    }

    @Test
    public void editUnityContent(){
        EditUnityContentModel editUnityContentModel = new EditUnityContentModel();
        editUnityContentModel.setName("newMovie name");
        editUnityContentModel.setWeight(1);
        editUnityContentModel.setType("type");
        editUnityContentModel.setRenderOnTrackingLost(true);
        editUnityContentModel.setExtendedTracking(false);
        editUnityContentModel.setScaleX(1);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleZ(2);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setRotationX(1);
        editUnityContentModel.setRotationY(2);
        editUnityContentModel.setRotationZ(2);
        editUnityContentModel.setPositionX(2);
        editUnityContentModel.setPositionY(3);
        editUnityContentModel.setPositionZ(3);
        editUnityContentModel.setAndroidUrl("sthUrl android");
        editUnityContentModel.setIosUrl("sthUrl ios");

        Mockito.when(unityContentService.edit(Mockito.any(UnityContent.class), Mockito.any(EditUnityContentModel.class))).thenReturn(mockUnity);
        assertNotNull(contentService.editUnityContent(mockUnity, editUnityContentModel));
    }

    @Test
    public void createMoreinfoContent(){
        CreateMoreinfoContentModel createMoreinfoContent = new CreateMoreinfoContentModel();
        createMoreinfoContent.setName("webview name");
        createMoreinfoContent.setWeight(1);
        createMoreinfoContent.setType("NORMAL");
        createMoreinfoContent.setId(1L);
        createMoreinfoContent.setUrl("http://www.example.com/");

        Mockito.when(moreinfoContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateMoreinfoContentModel.class))).thenReturn(moreInfoContent);
        assertNotNull(contentService.createMoreinfoContent(campaign, createMoreinfoContent));
    }

    @Test
    public void editMoreinfoContent(){
        CreateMoreinfoContentModel createMoreinfoContent = new CreateMoreinfoContentModel();
        createMoreinfoContent.setName("webview name");
        createMoreinfoContent.setWeight(1);
        createMoreinfoContent.setType("NORMAL");
        createMoreinfoContent.setId(1L);
        createMoreinfoContent.setUrl("http://www.example.com/");

        Mockito.when(moreinfoContentService.edit(Mockito.any(MoreInfoContent.class), Mockito.any(CreateMoreinfoContentModel.class))).thenReturn(moreInfoContent);
        assertNotNull(contentService.editMoreinfoContent(moreInfoContent, createMoreinfoContent));
    }

     @Test
     public void createSlideshowContent(){
         CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
         createSlideshowContentModel.setName("webview name");
         createSlideshowContentModel.setWeight(1);
         createSlideshowContentModel.setType("type");
         createSlideshowContentModel.setId(1L);
         createSlideshowContentModel.setExtendedTracking(true);
         createSlideshowContentModel.setPositionX(1);
         createSlideshowContentModel.setPositionY(2);
         createSlideshowContentModel.setPositionZ(3);
         createSlideshowContentModel.setRotationX(1);
         createSlideshowContentModel.setRotationY(2);
         createSlideshowContentModel.setRotationZ(3);
         createSlideshowContentModel.setScaleX(1);
         createSlideshowContentModel.setScaleY(2);
         createSlideshowContentModel.setScaleZ(3);
         createSlideshowContentModel.setRenderOnTrackingLost(true);

         Mockito.when(slideshowContentService.create(Mockito.any(Campaign.class), Mockito.any(CreateSlideshowContentModel.class))).thenReturn(mockSlideshowContent);
         assertNotNull(contentService.createSlideshowContent(campaign, createSlideshowContentModel));
}

    @Test
    public void editSlideshowContent(){
        EditSlideshowContentModel editSlideshowContentModel = new EditSlideshowContentModel();
        editSlideshowContentModel.setName("newSlideshow name");
        editSlideshowContentModel.setWeight(1);
        editSlideshowContentModel.setType("SPHERE");
        editSlideshowContentModel.setRenderOnTrackingLost(true);
        editSlideshowContentModel.setExtendedTracking(false);
        editSlideshowContentModel.setScaleX(1);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleZ(2);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setRotationX(1);
        editSlideshowContentModel.setRotationY(2);
        editSlideshowContentModel.setRotationZ(2);
        editSlideshowContentModel.setPositionX(2);
        editSlideshowContentModel.setPositionY(3);
        editSlideshowContentModel.setPositionZ(3);

       Mockito.when(slideshowContentService.edit(Mockito.any(de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent.class), Mockito.any(EditSlideshowContentModel.class))).thenReturn(mockSlideshowContent);
       assertNotNull(contentService.editSlideshowContent(mockSlideshowContent, editSlideshowContentModel));
}

   @Test
   public void createSlideshowImage(){
      CreateSlideshowImageModel createSlideshowImageModel = new CreateSlideshowImageModel();
      createSlideshowImageModel.setName("image name");
      createSlideshowImageModel.setWeight(1);
      createSlideshowImageModel.setType("type");
      createSlideshowImageModel.setUrl("sthUrl");

      Mockito.when(slideshowImageService.create(Mockito.anyLong(), Mockito.any(CreateSlideshowImageModel.class))).thenReturn(mockSlideshowImage);
      assertNotNull(contentService.createSlideshowImage(1L, createSlideshowImageModel));
}

    @Test
    public void deleteSlideshowImage(){
        Mockito.when(slideshowImageService.delete(Mockito.anyLong())).thenReturn(mockSlideshowImage);
        assertNotNull(contentService.deleteSlideshowImage(1L));
    }

    @Test
    public void moveUp_currentWeightIs1(){
        Mockito.when(content.getWeight()).thenReturn(1);
        Mockito.when(content.getCampaign()).thenReturn(campaign);
        Mockito.when(contentRepository.findFirstByCampaignAndWeight(Mockito.any(Campaign.class), Mockito.anyInt())).thenReturn(Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertFalse(contentService.moveUp(content));
    }

    @Test
    public void moveUp_contentAtDesiredWeightIsPresent(){
        Mockito.when(content.getWeight()).thenReturn(2);
        Mockito.when(content.getCampaign()).thenReturn(campaign);
        Mockito.when(contentRepository.findFirstByCampaignAndWeight(Mockito.any(Campaign.class), Mockito.anyInt())).thenReturn(Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertTrue(contentService.moveUp(content));
    }

    @Test
    public void moveUp_contentAtDesiredWeightIsNotPresent(){
        Mockito.when(content.getWeight()).thenReturn(2);
        Mockito.when(content.getCampaign()).thenReturn(campaign);
        Mockito.when(contentRepository.findFirstByCampaignAndWeight(Mockito.any(Campaign.class), Mockito.anyInt())).thenReturn(Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertTrue(contentService.moveUp(content));
    }

    @Test
    public void moveDown_contentAtDesiredWeightIsPresent(){
        Mockito.when(content.getCampaign()).thenReturn(campaign);
        Mockito.when(contentRepository.findFirstByCampaignAndWeight(Mockito.any(Campaign.class), Mockito.anyInt())).thenReturn(Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertTrue(contentService.moveDown(content));
    }

    @Test
    public void moveDown_contentAtDesiredWeightNotPresent(){
        Mockito.when(contentRepository.findFirstByCampaignAndWeight(Mockito.any(Campaign.class), Mockito.anyInt())).thenReturn(Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertFalse(contentService.moveDown(content));
    }

    @Test
    public void rename(){
        EditContentNameModel editContentNameModel = new EditContentNameModel();
        editContentNameModel.setName("Neu name");
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(content);
        assertNotNull(contentService.rename(content, editContentNameModel));
    }
}
