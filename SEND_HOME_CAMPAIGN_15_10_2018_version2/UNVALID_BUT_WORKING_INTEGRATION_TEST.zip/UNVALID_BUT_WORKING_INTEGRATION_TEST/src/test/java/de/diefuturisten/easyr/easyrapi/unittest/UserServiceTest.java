package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.model.response.CaptchaResponseModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordModel;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import de.diefuturisten.easyr.easyrapi.repository.ResetPasswordTokenRepository;
import de.diefuturisten.easyr.easyrapi.service.MailingService;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import java.util.Optional;
import java.util.NoSuchElementException;
import de.diefuturisten.easyr.easyrapi.entity.user.ResetPasswordToken;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;

public class UserServiceTest {
    private User user;
    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private ResetPasswordTokenRepository resetPasswordTokenRepository;
    private MailingService mailingService;
    private UserRoleRepository userRoleRepository;
    private RuntimePackageRepository runtimePackageRepository;
    private UserService userService;
    private de.diefuturisten.easyr.easyrapi.entity.user.UserRole userRole;
    private de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage runtimePackage;
    private ResetPasswordToken resetPasswordToken;

    @Before
    public void setUp() {
        user = mock(User.class);
        userRole = mock(UserRole.class);
        userRepository = mock(UserRepository.class);
        passwordEncoder = mock(PasswordEncoder.class);
        resetPasswordTokenRepository = mock(ResetPasswordTokenRepository.class);
        mailingService = mock(MailingService.class);
        userRoleRepository = mock(UserRoleRepository.class);
        runtimePackageRepository = mock(RuntimePackageRepository.class);
        resetPasswordToken = mock(ResetPasswordToken.class);
        runtimePackage = mock(RuntimePackage.class);
        userService = new UserService(userRepository, passwordEncoder, resetPasswordTokenRepository, mailingService, userRoleRepository, runtimePackageRepository);
     }

    @Test
    public void getUserByUsername(){
        Mockito.when(userRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.of(user));
        assertNotNull(userService.getUserByUsername("name"));
    }

    @Test(expected = NoSuchElementException.class)
    public void getUserByUsername_NoSuchElement() throws NoSuchElementException{
        Mockito.when(userRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.empty());
        userService.getUserByUsername("name");
     }

    @Test
    public void getUserByUserId(){
        Mockito.when(userRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(user));
        assertNotNull(userService.getUserByUserId(1L));
    }

    @Test
    public void create() throws CannotSendEmailException{
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1L");
        captchaResponseModel.setAnswer("someAnswer");

        CreateAccountModel model = new CreateAccountModel();
        model.setFirstName("FirstName");
        model.setLastName("LastName");
        model.setPassword("password");
        model.setLanguage("english");
        model.setGender(true);
        model.setEmail("somemail");
        model.setCaptcha(captchaResponseModel);

        Mockito.when(userRoleRepository.findByName(Mockito.anyString())).thenReturn(Optional.of(userRole));
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage));
        Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(user);
        doNothing().when(mailingService).sendNewUserWelcome(Mockito.any(User.class));

        assertNotNull( userService.create(model));
    }

    @Test
    public void forgotPassword() throws CannotSendEmailException{
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1L");
        captchaResponseModel.setAnswer("someAnswer");

        ForgotPasswordModel forgotPasswordModel = new ForgotPasswordModel();
        forgotPasswordModel.setEmail("someMail");
        forgotPasswordModel.setCaptcha(captchaResponseModel);

        Mockito.when(userRoleRepository.findByName(Mockito.anyString())).thenReturn(Optional.of(userRole));
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage));
        Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(user);
        doNothing().when(mailingService).sendPasswordResetToken(Mockito.any(User.class), Mockito.anyString());

        userService.forgotPassword(forgotPasswordModel);
    }

    @Test
    public void deleteOldToken(){
        Mockito.when(resetPasswordTokenRepository.findByUser(Mockito.any(User.class))).thenReturn(Optional.of(resetPasswordToken));
        doNothing().when(resetPasswordTokenRepository).delete(Mockito.any(ResetPasswordToken.class));
        userService.deleteOldToken(user);
    }

    @Test
    public void createAndSaveNewToken(){
        Mockito.when(resetPasswordTokenRepository.save(Mockito.any(ResetPasswordToken.class))).thenReturn(resetPasswordToken);
        assertNotNull(userService.createAndSaveNewToken(user));
    }
}
