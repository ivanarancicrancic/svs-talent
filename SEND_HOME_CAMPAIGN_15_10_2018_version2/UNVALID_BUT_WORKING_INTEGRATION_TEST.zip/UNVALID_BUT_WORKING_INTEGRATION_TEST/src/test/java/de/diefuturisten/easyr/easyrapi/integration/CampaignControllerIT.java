package de.diefuturisten.easyr.easyrapi.integration;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.Test;
import org.junit.Before;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRightRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.model.request.SaveNewCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class CampaignControllerIT {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ContactInformationRepository contactInformationRepository;

    @org.springframework.beans.factory.annotation.Autowired
    private de.diefuturisten.easyr.easyrapi.repository.TrackerRepository trackerRepository;

    @org.springframework.beans.factory.annotation.Autowired
    private de.diefuturisten.easyr.easyrapi.repository.ContentRepository contentRepository;

    @org.springframework.beans.factory.annotation.Autowired
    private de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository runtimeRepository;

    @Autowired
    private CampaignRepository campaignRepository;

    @Autowired
    private de.diefuturisten.easyr.easyrapi.repository.ResetPasswordTokenRepository resetPasswordTokenRepository;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserRightRepository userRightRepository;

    @Autowired
    private de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository packageBuyRepository;

    @Autowired
    private de.diefuturisten.easyr.easyrapi.repository.CouponRepository couponRepository;

    @Autowired
    private de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository runtimePackageRepository;

    private Campaign campaign;
    private ObjectMapper mapper;
    private String token;

    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
//        IntegrationTestHelper.prepareTrackerData(trackerRepository);
//        IntegrationTestHelper.prepareContentData(contentRepository);
        IntegrationTestHelper.prepareContactData(contactInformationRepository);

        IntegrationTestHelper.prepareCampaignData(campaignRepository,  userRepository, contactInformationRepository, contentRepository);
//        IntegrationTestHelper.prepareRuntimeData(runtimeRepository, packageBuyRepository, userRepository, couponRepository, runtimePackageRepository);

        this.campaign = campaignRepository.findAll().stream().findFirst().get();
        campaign.setContents(null);
        mapper = new ObjectMapper();
        token = IntegrationTestHelper.createLoginToken(userRepository.findByEmail("easyr@app-logik.de").get());
    }

    @Test
    @Transactional
    public void getAllCampaignsForUser() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaigns").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isForbidden());
    }

    @Test
    @Transactional
    public void getCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/" + campaign.getId()).header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isForbidden());
    }

    @Test
    @Transactional
    public void createCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaign").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

//    @Test
//    @Transactional
//    public void saveNewCampaign() throws Exception{
//        RuntimePackage runtimePackage = new RuntimePackage();
//        runtimePackage.setPrice(new java.math.BigDecimal(1.5354));
//        runtimePackage.setLengthInDays(2);
//        runtimePackage.setName("Package name");
//        runtimePackage = runtimePackageRepository.save(runtimePackage);
//        SaveNewCampaignModel saveNewCampaignModel = new SaveNewCampaignModel();
//        saveNewCampaignModel.setPackageId(runtimePackage.getId());
//        assertNotNull(token);
//        MockHttpServletRequestBuilder requestBuilder = post("/api/campaign/" + campaign.getId() + "/save").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL).writeValueAsString(saveNewCampaignModel));
//        this.mvc.perform(requestBuilder).andExpect(status().isOk());
//    }

//    @Test
//    @Transactional
//    public void editCampaign() throws Exception{
//        EditCampaignModel editCampaignModel =  new EditCampaignModel();
//        editCampaignModel.setId(campaign.getId());
//        editCampaignModel.setName("new name");
//        assertNotNull(token);
//        MockHttpServletRequestBuilder requestBuilder = put("/api/campaign").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL).writeValueAsString(editCampaignModel));
//        this.mvc.perform(requestBuilder).andExpect(status().isOk());
//    }


}
