package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.service.FileStorageService;
import java.io.File;
import de.diefuturisten.easyr.easyrapi.exceptions.ProbablyNotAnImageException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import org.springframework.mock.web.MockMultipartFile;

public class FileStorageServiceTest {
    private FileStorageService fileStorageService;

    @Before
    public void setUp() {
        fileStorageService = new FileStorageService();
    }

    @Test
    public void GetFileExtension_lastIndexInvalid(){
        assertEquals(FileStorageService.GetFileExtension("name"), "");
    }

    @Test
    public void GetFileExtension_lastIndexValid(){
        assertEquals(FileStorageService.GetFileExtension("name"), "");
    }

    @Test
    public void compressFile() throws IOException, ProbablyNotAnImageException{
        File file1 = new File("src/test/resources/Rotating_earth.gif");
        File file2 = new File("src/test/resources/Rotating_earth1.gif");
        Files.copy(file1.toPath(), file2.toPath(), StandardCopyOption.REPLACE_EXISTING);
        assertNotNull(fileStorageService.compressFile(file2,1));
    }

    @Test
    public void storeTemporaryTrackerFile() throws IOException, ProbablyNotAnImageException {
        File file1 = new File("src/test/resources/Rotating_earth.gif");
        File file2 = new File("src/test/resources/Rotating_earth1.gif");
        Files.copy(file1.toPath(), file2.toPath(), StandardCopyOption.REPLACE_EXISTING);
        byte[] bytes = Files.readAllBytes(file2.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file2", "Rotating_earth.gif", "image/jpg", bytes);
        assertNotNull(fileStorageService.storeTemporaryTrackerFile(multipartFile));
    }
}
