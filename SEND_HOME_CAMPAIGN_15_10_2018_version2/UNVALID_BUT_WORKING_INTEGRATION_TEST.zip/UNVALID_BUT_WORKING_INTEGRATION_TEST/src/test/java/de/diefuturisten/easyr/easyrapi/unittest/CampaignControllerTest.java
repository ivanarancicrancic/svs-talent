package de.diefuturisten.easyr.easyrapi.unittest;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;
import de.diefuturisten.easyr.easyrapi.controller.CampaignController;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.model.request.SaveNewCampaignModel;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;

public class CampaignControllerTest {
    private MockMvc mockMvc;
    private CampaignController campaignController;
    private CampaignService campaignService;
    private AuthenticationFacade authenticationFacade;
    private ObjectMapper mapper;
    private Campaign mockCampaign;
    private Campaign mockCampaign1;
    private Campaign mockCampaign2;
    private User mockUser;
    private User mockUser1;
    private RuntimePackage runtimePackage;

    @Before
    public void setUp(){
        campaignService = mock(CampaignService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        mockCampaign = mock(Campaign.class);
        mockCampaign1 = mock(Campaign.class);
        mockCampaign2 = mock(Campaign.class);
        mockUser = mock(User.class);
        mockUser1 = mock(User.class);
        runtimePackage = mock(RuntimePackage.class);
        campaignController = new CampaignController(campaignService, authenticationFacade);

        CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
        campaignDetailModel.setName("CAMPAIGN LALA");
        campaignDetailModel.setDescription("This is campaign about...");

        mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void getDetailsForCampaign() throws Exception {

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    }

    @Test
    public void getDetailsForCampaignNoCampaign() throws Exception {

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void getDetailsForCampaignUserNotEqual() throws Exception {

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void getAllCampaignsForUser() throws Exception {
        List<Campaign> campaignList = new java.util.ArrayList<>();
        campaignList.add(mockCampaign);
        campaignList.add(mockCampaign1);
        campaignList.add(mockCampaign2);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaignsForUser(Mockito.any(User.class))).thenReturn(campaignList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaigns").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }


    @Test
    public void createCampaign() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.createEmptyCampaign(Mockito.any(User.class))).thenReturn(mockCampaign);

        // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaign() throws NoRuntimePackageAvailableException, Exception {
        SaveNewCampaignModel saveNewCampaignModel = new SaveNewCampaignModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(SaveNewCampaignModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

        // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaignNoCampaign() throws NoRuntimePackageAvailableException, Exception {
        SaveNewCampaignModel saveNewCampaignModel = new SaveNewCampaignModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(SaveNewCampaignModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

         // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaignUserNotEqual() throws NoRuntimePackageAvailableException, Exception {
        SaveNewCampaignModel saveNewCampaignModel = new SaveNewCampaignModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(SaveNewCampaignModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }


    @Test()
    public void editCampaign() throws Exception {
        EditCampaignModel campaignEdit = new EditCampaignModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(EditCampaignModel.class))).thenReturn(mockCampaign);

         RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editCampaignNoCampaignAvailable() throws Exception {
        EditCampaignModel campaignEdit = new EditCampaignModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(EditCampaignModel.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editCampaignUserNotEqual() throws Exception {
        EditCampaignModel campaignEdit = new EditCampaignModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(EditCampaignModel.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }
}
