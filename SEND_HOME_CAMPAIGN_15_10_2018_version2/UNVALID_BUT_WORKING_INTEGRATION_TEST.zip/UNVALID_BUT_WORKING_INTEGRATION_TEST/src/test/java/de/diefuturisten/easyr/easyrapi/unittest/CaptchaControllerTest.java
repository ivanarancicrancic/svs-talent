package de.diefuturisten.easyr.easyrapi.unittest;

import org.springframework.test.web.servlet.MockMvc;
import  org.junit.Before;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import de.diefuturisten.easyr.easyrapi.controller.CaptchaController;
import de.diefuturisten.easyr.easyrapi.service.CaptchaService;
import de.diefuturisten.easyr.easyrapi.model.response.CaptchaModel;
import static org.mockito.Mockito.mock;

public class CaptchaControllerTest {

    private MockMvc mockMvc;
    private CaptchaService captchaService;
    private CaptchaController captchaController;

    @Before
    public void setUp(){
        captchaService = mock(CaptchaService.class);
        captchaController =new CaptchaController(captchaService);
        mockMvc = MockMvcBuilders.standaloneSetup(captchaController).build();
    }

    @Test
    public void createCaptcha() throws Exception {
        CaptchaModel captchaModel = new CaptchaModel();
        captchaModel.setData("some test data hasjhfsks");
        captchaModel.setId("1L");

        Mockito.when(captchaService.generateCaptcha()).thenReturn(captchaModel);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/captcha")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }

    @Test
    public void recreateCaptcha() throws Exception {
        CaptchaModel captchaModel = new CaptchaModel();
        captchaModel.setData("some test data hasjhfsks");
        captchaModel.setId("1L");

        Mockito.when(captchaService.generateCaptcha()).thenReturn(captchaModel);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/captcha/" + 1)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }


}
