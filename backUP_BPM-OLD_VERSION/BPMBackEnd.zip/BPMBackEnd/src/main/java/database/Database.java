package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.*;
public class Database {
    public Connection Get_Connection() throws Exception
    {
        try
        {
            Class.forName("org.postgresql.Driver");
            String connectionURL = "jdbc:postgresql://192.168.1.110:5432/LoanOrganization?characterEncoding=utf8";  // "jdbc:mysql://localhost:3306/workingbrain";
            Connection connection = null;
            //Class.forName("org.postgresql.Driver");
            connection = DriverManager.getConnection(connectionURL, "sa", "Interway1102");
            return connection;
        }
        catch (SQLException e)
        {
            throw e;
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}
