package Models;

public class LoanRequest {
<<<<<<< HEAD

    int loantypeid;
    String embg;
   String requestdate;
   int amount;

   public  LoanRequest(){}

    public LoanRequest(int loantypeid, String embg, String requestdate, int amount) {
        this.loantypeid = loantypeid;
        this.embg = embg;
        this.requestdate = requestdate;
        this.amount = amount;
    }

    public int getLoantypeid() {
        return loantypeid;
    }

    public void setLoantypeid(int loantypeid) {
        this.loantypeid = loantypeid;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
=======
    private Integer loanrequestid;
    private String firstname;
    private String lastname;
    private String requestdate;
    private String embg;
    private String loantypeshortname;

    public LoanRequest() {
    }

    public LoanRequest(Integer loanrequestid, String firstname, String lastname, String requestdate, String embg, String loantypeshortname) {
        this.loanrequestid = loanrequestid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.requestdate = requestdate;
        this.embg = embg;
        this.loantypeshortname = loantypeshortname;
    }

    public Integer getLoanrequestid() {
        return loanrequestid;
    }

    public void setLoanrequestid(Integer loanrequestid) {
        this.loanrequestid = loanrequestid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
>>>>>>> 8aa09c36a029df97fd9d995808097528b4752c8e
    }

    public String getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(String requestdate) {
        this.requestdate = requestdate;
    }

<<<<<<< HEAD
    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
=======
    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getLoantypeshortname() {
        return loantypeshortname;
    }

    public void setLoantypeshortname(String loantypeshortname) {
        this.loantypeshortname = loantypeshortname;
>>>>>>> 8aa09c36a029df97fd9d995808097528b4752c8e
    }
}
