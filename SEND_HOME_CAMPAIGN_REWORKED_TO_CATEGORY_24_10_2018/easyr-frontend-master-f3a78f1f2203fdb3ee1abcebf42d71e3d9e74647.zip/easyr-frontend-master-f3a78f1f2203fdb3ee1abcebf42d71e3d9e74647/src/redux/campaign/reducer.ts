import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { ICampaignDetailResponseModel } from './types';

export type CampaignDetailActions = ActionType<typeof actions>;

export interface ICampaignDetailState {
    readonly data: ICampaignDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;

    readonly createLoading: boolean;
    readonly trackerLoading: boolean;
    readonly contentLoading: boolean;

    readonly lastCreatedId: number | null;

    readonly saveLoading: boolean;
    readonly saveError: any | null;
};
  
const INITIAL_STATE: ICampaignDetailState = {
    data: null,
    loading: false,
    error: null,

    createLoading: false,
    trackerLoading: false,
    contentLoading: false,

    lastCreatedId: null,

    saveLoading: false,
    saveError: null
};
  
export function campaignDetailReducer(state: ICampaignDetailState = INITIAL_STATE, action: CampaignDetailActions): ICampaignDetailState  {
    switch (action.type) {

        // detail
        case getType(actions.userCampaignDetailFetch):
            return {...state, loading: true, error: null};
        case getType(actions.userCampaignDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.userCampaignDetailFail):
            return {...state, loading: false, error: action.payload};

        // create
        case getType(actions.campaignCreateFetch):
            return {...state, createLoading: true, error: null};
        case getType(actions.campaignCreateSuccess):
            return {...state, createLoading: false, error: null, lastCreatedId: action.payload.id};
        case getType(actions.campaignCreateFail):
            return {...state, createLoading: false, error: action.payload};

        // save
        case getType(actions.campaignSaveFetch):
            return {...state, saveLoading: true, saveError: null};
        case getType(actions.campaignSaveSuccess):
            return {...state, saveLoading: false, saveError: null, data: action.payload};
        case getType(actions.campaignSaveFail):
            return {...state, saveLoading: false, saveError: action.payload};

        // tracker upload
        case getType(actions.trackerUploadFetch):
            return {...state, trackerLoading: true};

        case getType(actions.trackerUploadSuccess):
            if(state.data == null) {
                return state;
            }

            return {
                ...state,
                trackerLoading: false,
                data: {
                    ...state.data,
                    tracker: [
                        ...state.data.tracker,
                        action.payload
                    ]
                }
            }
        case getType(actions.trackerUploadFail):
            return {...state, trackerLoading: false};

        // tracker delete
        case getType(actions.trackerDeleteFetch):
            return {...state, trackerLoading: true};

        case getType(actions.trackerDeleteSuccess):
            if(state.data == null) {
                return state;
            }

            const trackersAfterDelete = state.data.tracker.filter(x => x.id !== action.payload.trackerId);

            return {
                ...state,
                trackerLoading: false,
                data: {
                    ...state.data,
                    tracker: trackersAfterDelete
                }
            }
        
        case getType(actions.trackerDeleteFail):
            return {...state, trackerLoading: false};

        // content delete
        case getType(actions.contentDeleteFetch):
            return {...state, contentLoading: true};

        case getType(actions.contentDeleteSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false}
            }

            const contentsAfterDelete = state.data.contents.filter(x => x.id !== action.payload.contentId);

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: contentsAfterDelete
                }
            }
        
        case getType(actions.contentDeleteFail):
            return {...state, contentLoading: false};

        // content create
        case getType(actions.contentVideoCreateFetch):
        case getType(actions.contentPanoramaCreateFetch):
        case getType(actions.contentWebviewCreateFetch):
        case getType(actions.contentAudioCreateFetch):
        case getType(actions.contentUnityCreateFetch):
        case getType(actions.contentSlideshowCreateFetch):
        case getType(actions.contentMoreinfoCreateFetch):
            return {...state, contentLoading: true};

        case getType(actions.contentVideoCreateSuccess):
        case getType(actions.contentPanoramaCreateSuccess):
        case getType(actions.contentWebviewCreateSuccess):
        case getType(actions.contentAudioCreateSuccess):
        case getType(actions.contentUnityCreateSuccess):
        case getType(actions.contentSlideshowCreateSuccess):
        case getType(actions.contentMoreinfoCreateSuccess):

            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: [
                        ...state.data.contents,
                        action.payload
                    ]
                }
            };

        case getType(actions.contentVideoCreateFail):
        case getType(actions.contentPanoramaCreateFail):
        case getType(actions.contentWebviewCreateFail):
        case getType(actions.contentAudioCreateFail):
        case getType(actions.contentUnityCreateFail):
        case getType(actions.contentSlideshowCreateFail):
        case getType(actions.contentMoreinfoCreateFail):
            return {...state, contentLoading: false};


        // content edit
        case getType(actions.contentVideoEditFetch):
        case getType(actions.contentPanoramaEditFetch):
        case getType(actions.contentWebviewEditFetch):
        case getType(actions.contentAudioEditFetch):
        case getType(actions.contentUnityEditFetch):
        case getType(actions.contentSlideshowEditFetch):
        case getType(actions.contentMoreinfoEditFetch):
            return {...state, contentLoading: true};

        case getType(actions.contentVideoEditSuccess):
        case getType(actions.contentPanoramaEditSuccess):
        case getType(actions.contentWebviewEditSuccess):
        case getType(actions.contentAudioEditSuccess):
        case getType(actions.contentUnityEditSuccess):
        case getType(actions.contentSlideshowEditSuccess):
        case getType(actions.contentSlideshowImageUpSuccess):
        case getType(actions.contentSlideshowImageDownSuccess):
        case getType(actions.contentMoreinfoEditSuccess):
        case getType(actions.contentRenameSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            const elementToUpdate = action.payload;
            const idxOfIdToUpdate = state.data.contents.findIndex( x => x.id === elementToUpdate.id );

            if(idxOfIdToUpdate === -1) {
                return state;
            }

            const updatedVideoContents = [...state.data.contents];
            updatedVideoContents[idxOfIdToUpdate] = action.payload;

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: updatedVideoContents
                }
            };

        case getType(actions.contentVideoEditFail):
        case getType(actions.contentPanoramaEditFail):
        case getType(actions.contentWebviewEditFail):
        case getType(actions.contentAudioEditFail):
        case getType(actions.contentUnityEditFail):
        case getType(actions.contentSlideshowEditFail):
        case getType(actions.contentMoreinfoEditFail):
            return {...state, contentLoading: false};

        default:
            return state;
    }
}