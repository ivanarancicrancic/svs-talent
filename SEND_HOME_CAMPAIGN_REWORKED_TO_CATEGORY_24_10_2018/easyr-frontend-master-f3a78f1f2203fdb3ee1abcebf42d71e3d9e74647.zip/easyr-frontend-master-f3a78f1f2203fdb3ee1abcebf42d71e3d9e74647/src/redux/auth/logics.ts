import { createLogic } from 'redux-logic';

import { LOGIN_USER_FETCH, IJWTokenContent } from './types';
import { loginUserFetch, loginUserSuccess, loginUserFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';

import * as jwt_decode from 'jwt-decode';

import { messageAdd, messageRemove } from '../messages/actions';

import { createErrorMessage } from '../messages/types';

function extractJWT(headers: Headers): string | null {
    const authStr: string | null = headers.get('Authorization');
    if (!!authStr) {
        const authStrParts: string[] = authStr.split(' ');
        if (authStrParts.length === 2) {
            return authStrParts[1];
        }
    }
    return null;
}

export const fetchLoginUserLogic = createLogic({
    type: LOGIN_USER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(loginUserFetch)(action)) {
            fetch(API_ROOT + '/login', {
                method: 'POST',
                headers: {"Content-Type": "application/json"},
                body: JSON.stringify({
                    username: action.payload.username,
                    password: action.payload.password
                }),
            })
            .then(response => {
                // if response 
                if (response.status === 403) {
                    dispatch(loginUserFail('Wrong credentials'));
                    const message = createErrorMessage("Login fehlgeschlagen", "Das angegebene Passwort stimmt nicht mit der E-Mail-Adresse überein", () => { dispatch(messageRemove({messageId: message.id})) })
                    dispatch(messageAdd(message));
                    return;
                }

                if (response.status !== 200) {
                    dispatch(loginUserFail('unknown error'));
                    const message = createErrorMessage("Login fehlgeschlagen", "Ein unbekannter Fehler ist aufgetreten. Bitte versuchen Sie es erneut.", () => { dispatch(messageRemove({messageId: message.id})) })
                    dispatch(messageAdd(message));
                    return;
                }

                const jwt = extractJWT(response.headers);
                if (jwt !== null) {
                    const tokenContent = jwt_decode<IJWTokenContent>(jwt);
                    dispatch(loginUserSuccess({ token: jwt, content: tokenContent }));
                } else {
                    dispatch(loginUserFail('Wrong credentials or server problem'));
                }
            })
            .catch(error => {
                dispatch(loginUserFail('Connection problem'));
            }).then(() => {
                done();
            });
        } else {
            done();
        }
    }
});

export default [
    fetchLoginUserLogic
];
