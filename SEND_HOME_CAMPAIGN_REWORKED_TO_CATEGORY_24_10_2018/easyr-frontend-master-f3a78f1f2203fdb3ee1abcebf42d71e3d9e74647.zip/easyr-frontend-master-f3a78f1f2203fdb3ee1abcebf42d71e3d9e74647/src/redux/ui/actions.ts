import { UI_SHOW_CREATE_CAMPAIGN, UI_HIDE_CREATE_CAMPAIGN } from './types';

import { createStandardAction } from 'typesafe-actions';

export const uiShowCreateCampaign = createStandardAction(UI_SHOW_CREATE_CAMPAIGN)();
export const uiHideCreateCampaign = createStandardAction(UI_HIDE_CREATE_CAMPAIGN)();