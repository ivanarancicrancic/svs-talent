import * as React from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';

import './StartLayout.css';
import { IRootState } from '../../redux';
import { categoryListFetch } from '../../redux/user-campaign-list/actions';
import { ICategoryResponseModel } from '../../redux/user-campaign-list/types';
import { getCategoryList } from '../../redux/user-campaign-list/selectors';
import { IPackagesResponseModel } from '../../redux/user-package-list/types';
import { getUserPackageList } from '../../redux/user-package-list/selectors';
import { userPackageListFetch } from '../../redux/user-package-list/actions';
import { campaignCreateFetch } from '../../redux/campaign/actions';

import { history } from '../../router';

interface IPropsDispatchMap {
    categoryListFetch: typeof categoryListFetch;
    userPackageListFetch: typeof userPackageListFetch;
    campaignCreateFetch: typeof campaignCreateFetch;
}
interface IPropsStateMap {
    categoryData: ICategoryResponseModel[] | null;
    packageData: IPackagesResponseModel | null;
    campaignCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.categoryListFetch();
        this.props.userPackageListFetch();
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const campaignCreated = this.props.campaignCreating === true && nextProps.campaignCreating === false;
        if(campaignCreated) {
            history.push(`/campaign/${nextProps.lastCreatedId}`);
        }
    }


    public renderPackageList() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <tbody>
                    <tr>
                    {this.props.categoryData.map( category => {
                        return (
                            <tr key={category.id}>
                                <td><b>{category.name} Category Kochtechnik</b></td>
                                <td>{category.numberOfViews} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </td>
                                <td><Link to={`/campaign/${category.id}`} className="fontello icon-edit"/> </td>
                            </tr>
                        )
                    })}
                  </tr>
                    <tr>
                    <td colSpan={5} className="text-center" >
                        {!this.props.campaignCreating && <a onClick={ () => {this.props.campaignCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
              
                {this.renderPackageList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    categoryData: getCategoryList(state),
    packageData: getUserPackageList(state),

    campaignCreating: state.campaign.createLoading,
    lastCreatedId: state.campaign.lastCreatedId,
});

export default connect(mapStateToProps, {categoryListFetch, campaignCreateFetch, userPackageListFetch})(DashboardLayout)