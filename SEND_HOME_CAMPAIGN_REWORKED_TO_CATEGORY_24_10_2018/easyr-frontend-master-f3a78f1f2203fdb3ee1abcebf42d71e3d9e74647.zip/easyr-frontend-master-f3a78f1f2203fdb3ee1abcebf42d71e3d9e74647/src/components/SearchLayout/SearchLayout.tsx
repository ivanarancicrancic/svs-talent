import * as React from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';

import './SearchLayout.css';
import { IRootState } from '../../redux';
import { categoryListFetch } from '../../redux/user-campaign-list/actions';
import { ICategoryResponseModel } from '../../redux/user-campaign-list/types';
import { getCategoryList } from '../../redux/user-campaign-list/selectors';
import { IPackagesResponseModel } from '../../redux/user-package-list/types';
import { getUserPackageList } from '../../redux/user-package-list/selectors';
import { userPackageListFetch } from '../../redux/user-package-list/actions';
import { campaignCreateFetch } from '../../redux/campaign/actions';

import { history } from '../../router';

interface IPropsDispatchMap {
    categoryListFetch: typeof categoryListFetch;
    userPackageListFetch: typeof userPackageListFetch;
    campaignCreateFetch: typeof campaignCreateFetch;
}
interface IPropsStateMap {
    categoryData: ICategoryResponseModel[] | null;
    packageData: IPackagesResponseModel | null;
    campaignCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.categoryListFetch();
        this.props.userPackageListFetch();
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const campaignCreated = this.props.campaignCreating === true && nextProps.campaignCreating === false;
        if(campaignCreated) {
            history.push(`/campaign/${nextProps.lastCreatedId}`);
        }
    }

    public renderCampaignList() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable" style={{backgroundColor:"#D3D3D3"}} >
              <h1 style={{textAlign:"center"}}> Ersatzteile für Gastronomie-Technik </h1>
                  <tr>Willkommen! Bei uns können Sie aus einem der größten Sortimente Europas Ihr passendes Ersatzteil auswählen. Für fast jeden Hersteller gastronomischer Geräte haben wir beinahe alles im Angebot. Nutzen Sie unsere komfortablen Suchfunktionen oder wenden sich direkt an uns - Ihr Ersatzteil-Handel24.com Team</tr>
                   
                <table className="table" style={{backgroundColor:"#D3D3D3"}}>
                    <thead>
                        <tr/>
                    </thead>
                    <tbody>
                
                    <tr>
                     <td><button style={{backgroundColor:"#DF4444"}}> Warengruppen SchnellSuche></button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Ertzatsteil suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Bilder Suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}>Explosionzeichnungen </button></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        );
    }

    public renderPackageList() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table">
                <tbody>
                    <tr>
                    {this.props.categoryData.map( category => {
                        return (
                            <td key={category.id}>
                                <tr><b>{category.name} Category Kochtechnik</b></tr>
                                <tr>{category.numberOfViews} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </tr>
                                <tr><Link to={`/campaign/${category.id}`} className="fontello icon-edit"/> </tr>
                            </td>
                        )
                    })}
                  </tr>
                    <tr>
                    <td colSpan={5} className="text-center" >
                        {!this.props.campaignCreating && <a onClick={ () => {this.props.campaignCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
                {this.renderCampaignList()}
                {this.renderPackageList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    campaignData: getCategoryList(state),
    packageData: getUserPackageList(state),

    campaignCreating: state.campaign.createLoading,
    lastCreatedId: state.campaign.lastCreatedId,
});

export default connect(mapStateToProps, {categoryListFetch, campaignCreateFetch, userPackageListFetch})(DashboardLayout)