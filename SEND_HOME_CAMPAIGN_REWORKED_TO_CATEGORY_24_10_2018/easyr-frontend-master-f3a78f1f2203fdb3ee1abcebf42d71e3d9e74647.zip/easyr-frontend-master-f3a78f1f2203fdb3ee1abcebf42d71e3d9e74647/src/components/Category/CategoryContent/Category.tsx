import * as React from 'react';
import './Category.css';

import Products from '../../Products/Products';

export default class CampaignContent extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            files: [],
          };
    }
    
    public render() {

        
        return (
            <div className="grid100 campaignBox">
                <table className="grid100 table bp3-html-table bp3-html-table-bordered">
                    <tbody >
                     
                        
                        <tr>
                            <td> 
                                <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button> Product     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Products />
                            </td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        )
    }
}
