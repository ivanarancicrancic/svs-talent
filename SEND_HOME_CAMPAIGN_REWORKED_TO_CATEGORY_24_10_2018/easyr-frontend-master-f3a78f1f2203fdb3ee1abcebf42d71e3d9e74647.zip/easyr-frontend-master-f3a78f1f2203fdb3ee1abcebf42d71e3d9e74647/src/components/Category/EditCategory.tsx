import * as React from 'react';
import CategoryContent from './CategoryContent/Category';
import CategoryInfo from './CategoryInfo/CategoryInfo';

export default class EditCampaign extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <CategoryInfo />
                <CategoryContent />
            </div>
        )
    }

}