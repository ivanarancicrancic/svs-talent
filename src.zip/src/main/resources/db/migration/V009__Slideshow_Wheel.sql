ALTER TABLE content_slideshows ADD COLUMN type varchar(255);
UPDATE content_slideshows SET type = 'NORMAL';
ALTER TABLE content_slideshows ALTER COLUMN type SET NOT NULL;