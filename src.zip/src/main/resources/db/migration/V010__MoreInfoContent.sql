create table if not exists content_moreinfos
(
	url varchar(255),
	key_content bigint not null
		constraint content_moreinfo_pkey
			primary key
		constraint fkptsym4g23swkxxzxrtqkj1ant
			references content
);