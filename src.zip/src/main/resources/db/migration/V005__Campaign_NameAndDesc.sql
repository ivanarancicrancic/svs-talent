ALTER TABLE campaigns ADD name varchar(255) not null;
ALTER TABLE campaigns ADD description varchar(255) not null;