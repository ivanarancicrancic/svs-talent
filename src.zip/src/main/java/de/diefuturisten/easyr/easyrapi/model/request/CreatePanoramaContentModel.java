package de.diefuturisten.easyr.easyrapi.model.request;

public class CreatePanoramaContentModel extends CreateContentModel {

    private String subType;
    private String url;

    public CreatePanoramaContentModel(){}

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
