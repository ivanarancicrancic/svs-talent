package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;

public class PanoramaContentModel extends ContentModel {

    private String subType;
    private String url;


    public PanoramaContentModel(PanoramaContent content) {
        super(content, "panorama");

        this.subType = content.getType().toString();
        this.url = content.getUrl();
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
