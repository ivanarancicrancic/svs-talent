package de.diefuturisten.easyr.easyrapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;

public interface SlideshowImageRepository extends JpaRepository<SlideshowImage, Long> {
    Optional<SlideshowImage> findFirstBySlideshowOrderByWeightDesc(SlideshowContent slideshowContent);
    Optional<SlideshowImage> findFirstBySlideshowAndWeight(SlideshowContent slideshowContent, int weight);

}
