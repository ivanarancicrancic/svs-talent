package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.exceptions.ProbablyNotAnImageException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Iterator;

@Service
public class FileStorageService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public static String GetFileExtension(String name) {
        int lastIndexOf = name.lastIndexOf(".");
        if (lastIndexOf == -1) {
            return "";
        }
        return name.substring(lastIndexOf);
    }

    public File compressFile(File file, int interation) throws IOException, ProbablyNotAnImageException {
        log.info(String.format("Will compress: %s , iteration: %d", file.getName(), interation));

        BufferedImage image = ImageIO.read(file);
        if(image == null) {
            throw new ProbablyNotAnImageException();
        }

        File compressedTempFile = File.createTempFile("tmp-", ".jpg");
        OutputStream os = new FileOutputStream(compressedTempFile);

        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
        ImageWriter writer = writers.next();

        ImageOutputStream ios = ImageIO.createImageOutputStream(os);
        writer.setOutput(ios);

        ImageWriteParam param = writer.getDefaultWriteParam();

        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality( (10 - interation) / 10);  // Change the quality value you prefer

        IIOImage newImage = new IIOImage(image, null, null);
        writer.write(null, newImage, param);

        file.delete();

        return compressedTempFile;
    }

    public File storeTemporaryTrackerFile(MultipartFile file) throws ProbablyNotAnImageException {

        String extension = GetFileExtension(file.getOriginalFilename());

        try {
            File tempFile = File.createTempFile("tmp-", extension);
            Files.copy(file.getInputStream(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);

            int iteration = 0;
            do {
                tempFile = compressFile(tempFile, iteration++);
            } while(tempFile.length() > 2097152 && iteration < 10);

            return tempFile;

        } catch (IOException e) {
            return null;
        }
    }

}
