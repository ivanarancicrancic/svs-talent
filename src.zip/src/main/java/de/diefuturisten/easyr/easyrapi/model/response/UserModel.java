package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.List;
import java.util.stream.Collectors;

public class UserModel {

    private long id;
    private String name;
    private List<String> rights;

    public UserModel(User user) {
        this.id = user.getId();
        this.name = user.getName();
        this.rights = user.getRights().stream().map(x -> x.getName()).collect(Collectors.toList());
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getRights() {
        return rights;
    }

    public void setRights(List<String> rights) {
        this.rights = rights;
    }
}
