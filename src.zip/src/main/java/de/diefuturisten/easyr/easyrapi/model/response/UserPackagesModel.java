package de.diefuturisten.easyr.easyrapi.model.response;

import java.util.ArrayList;
import java.util.List;

public class UserPackagesModel {

    private List<UserPackagesCountModel> available = new ArrayList<>();
    private List<UserPackagesCountModel> used = new ArrayList<>();

    public UserPackagesModel() {
    }

    public UserPackagesModel(List<UserPackagesCountModel> available, List<UserPackagesCountModel> used) {
        this.available = available;
        this.used = used;
    }

    public List<UserPackagesCountModel> getAvailable() {
        return available;
    }

    public void setAvailable(List<UserPackagesCountModel> available) {
        this.available = available;
    }

    public List<UserPackagesCountModel> getUsed() {
        return used;
    }

    public void setUsed(List<UserPackagesCountModel> used) {
        this.used = used;
    }
}
