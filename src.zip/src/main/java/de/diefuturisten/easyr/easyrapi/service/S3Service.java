package de.diefuturisten.easyr.easyrapi.service;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import de.diefuturisten.easyr.easyrapi.entity.content.Upload;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.repository.UploadRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.net.URL;
import java.util.Date;
import java.util.UUID;

@Service
public class S3Service {

    private AmazonS3 s3client;

    private UploadRepository uploadRepository;

    @Value("${jsa.s3.region}")
    private String s3Region;

    @Value("${jsa.s3.bucket}")
    private String bucketName;

    public S3Service(AmazonS3 s3client, UploadRepository uploadRepository) {
        this.s3client = s3client;
        this.uploadRepository = uploadRepository;
    }

    public URL signUploadRequest(User user, String objectName) {

        // Set the pre-signed URL to expire after one hour.
        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 1000 * 60 * 60;
        expiration.setTime(expTimeMillis);

        String extension = FileStorageService.GetFileExtension(objectName);

        String uploadFileName = UUID.randomUUID().toString() + extension;

        // Generate the pre-signed URL.
        GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, uploadFileName)
                .withMethod(HttpMethod.PUT)
                .withExpiration(expiration);
        URL url = s3client.generatePresignedUrl(generatePresignedUrlRequest);

        // save generated url to database
        Upload upload = new Upload();
        upload.setUrl(url.toString().split("\\?")[0]);
        upload.setUser(user);
        upload.setCreatedAt(new Date());
        uploadRepository.save(upload);

        return url;
    }

    private String getTrackerUploadPath(String vuforiaId) {
        return new File("tracker", vuforiaId).toString();
    }

    public String uploadTracker(String vuforiaId, File file) {
        PutObjectRequest request = new PutObjectRequest(bucketName, getTrackerUploadPath(vuforiaId), file);
        s3client.putObject(request);
        String result = String.format("https://s3.%s.amazonaws.com/%s/tracker/%s", s3Region, bucketName, vuforiaId);
        return result;
    }

    public void deleteTracker(String vuforiaId) {
        DeleteObjectRequest request = new DeleteObjectRequest(bucketName, getTrackerUploadPath(vuforiaId));
        s3client.deleteObject(request);
    }

}
