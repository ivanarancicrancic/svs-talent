package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public interface ContentRepository extends JpaRepository<Content, Long> {
    Optional<Content> findFirstByCampaignOrderByWeightDesc(Campaign campaign);
    Optional<Content> findFirstByCampaignAndWeight(Campaign campaign, int weight);
}
