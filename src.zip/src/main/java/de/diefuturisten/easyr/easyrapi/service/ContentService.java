package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMoreinfoContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditContentNameModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.validation.Valid;
import java.util.Optional;

@Service
@Transactional
public class ContentService {

    private final ContentRepository contentRepository;
    private final WebviewContentService webviewContentService;
    private final AudioContentService audioContentService;
    private final MovieContentService movieContentService;
    private final PanoramaContentService panoramaContentService;
    private final UnityContentService unityContentService;
    private final MoreinfoContentService moreinfoContentService;
    private final SlideshowContentService slideshowContentService;
    private final SlideshowImageService slideshowImageService;

    public ContentService(
            ContentRepository contentRepository,
            WebviewContentService webviewContentService,
            AudioContentService audioContentService, MovieContentService movieContentService, PanoramaContentService panoramaContentService, UnityContentService unityContentService, MoreinfoContentService moreinfoContentService, SlideshowContentService slideshowContentService, SlideshowImageService slideshowImageService) {
        this.contentRepository = contentRepository;
        this.webviewContentService = webviewContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
        this.panoramaContentService = panoramaContentService;
        this.unityContentService = unityContentService;
        this.moreinfoContentService = moreinfoContentService;
        this.slideshowContentService = slideshowContentService;
        this.slideshowImageService = slideshowImageService;
    }

    public Optional<Content> getById(long id) {
        return this.contentRepository.findById(id);
    }

    public boolean deleteContent(Content content) {
        this.contentRepository.delete(content);
        return true;
    }

    /* Webview */
    public WebviewContent createWebviewContent(Campaign campaign, CreateWebviewContentModel model) {
        WebviewContent content = webviewContentService.create(campaign, model);
        return content;
    }

    public WebviewContent editWebviewContent(WebviewContent content, CreateWebviewContentModel model) {
        WebviewContent editedContent = webviewContentService.edit(content, model);
        return editedContent;
    }

    /* Audio */
    public AudioContent createAudioContent(Campaign campaign, @Valid CreateAudioContentModel model) {
        AudioContent content = audioContentService.create(campaign, model);
        return content;
    }

    public AudioContent editAudioContent(AudioContent content, @Valid CreateAudioContentModel model) {
        AudioContent editedContent = audioContentService.edit(content, model);
        return editedContent;
    }

    /* Movie */
    public MovieContent createMovieContent(Campaign campaign, @Valid CreateMovieContentModel model) {
        MovieContent content = movieContentService.create(campaign, model);
        return content;
    }

    public MovieContent editMovieContent(MovieContent content, @Valid EditMovieContentModel model) {
        MovieContent editedContent = movieContentService.edit(content, model);
        return editedContent;
    }


    /* Panorama */
    public PanoramaContent createPanoramaContent(Campaign campaign, @Valid CreatePanoramaContentModel model) {
        PanoramaContent content = panoramaContentService.create(campaign, model);
        return content;
    }

    public PanoramaContent editPanoramaContent(PanoramaContent content, @Valid EditPanoramaContentModel model) {
        PanoramaContent editedContent = panoramaContentService.edit(content, model);
        return editedContent;
    }


    /* Unity */
    public UnityContent createUnityContent(Campaign campaign, @Valid CreateUnityContentModel model) {
        UnityContent content = unityContentService.create(campaign, model);
        return content;
    }

    public UnityContent editUnityContent(UnityContent content, @Valid EditUnityContentModel model) {
        UnityContent editedContent = unityContentService.edit(content, model);
        return editedContent;
    }

    /* MoreInfo */
    public MoreInfoContent createMoreinfoContent(Campaign campaign, CreateMoreinfoContentModel model) {
        MoreInfoContent content = moreinfoContentService.create(campaign, model);
        return content;
    }

    public MoreInfoContent editMoreinfoContent(MoreInfoContent content, CreateMoreinfoContentModel model) {
        MoreInfoContent editedContent = moreinfoContentService.edit(content, model);
        return editedContent;
    }

    /* Slideshow */
    public SlideshowContent createSlideshowContent(Campaign campaign, @Valid CreateSlideshowContentModel model) {
        SlideshowContent content = slideshowContentService.create(campaign, model);
        return content;
    }

    public SlideshowContent editSlideshowContent(SlideshowContent content, @Valid EditSlideshowContentModel model) {
        SlideshowContent editedContent = slideshowContentService.edit(content, model);
        return editedContent;
    }

    /* SlideshowImage */
    public SlideshowImage createSlideshowImage(long slideshowID, @Valid CreateSlideshowImageModel model) {
        SlideshowImage content = slideshowImageService.create(slideshowID, model);
        return content;
    }

    public SlideshowImage deleteSlideshowImage(long imageID) {
        SlideshowImage content = slideshowImageService.delete(imageID);
        return content;
    }

    public boolean moveUp(Content content) {
        int currentWeight = content.getWeight();

        if( currentWeight == 1 ){
            return false;
        }

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() - 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if( contentAtDesiredWeightOpt.isPresent() ){
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    public boolean moveDown(Content content) {

        int currentWeight = content.getWeight();

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() + 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if( contentAtDesiredWeightOpt.isPresent() ){
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        } else {
            return false;
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    public Content rename(Content content, EditContentNameModel model) {
        content.setName(model.getName());
        return contentRepository.save(content);
    }

}
