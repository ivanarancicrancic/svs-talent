package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.CouponNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoMoneyException;
import de.diefuturisten.easyr.easyrapi.exceptions.RuntimePackageNotFoundException;
import de.diefuturisten.easyr.easyrapi.model.request.BuyPackageRequestModel;
import de.diefuturisten.easyr.easyrapi.model.response.RuntimePackageModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.stream.Stream;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class RuntimePackagesController {

    private final AuthenticationFacade authenticationFacade;
    private final CampaignRuntimeService campaignRuntimeService;

    public RuntimePackagesController(AuthenticationFacade authenticationFacade, CampaignRuntimeService campaignRuntimeService) {
        this.authenticationFacade = authenticationFacade;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    @GetMapping("/packages")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PACKAGE_LIST)
    public Stream<RuntimePackageModel> getAllCampaignsForUser() {
        return campaignRuntimeService.getAllPackages().stream()
                .map(RuntimePackageModel::new);
    }

    @GetMapping("/packages/own")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PACKAGE_LIST_FOR_USER)
    public UserPackagesModel getUserPackages() {
        User user = authenticationFacade.getAuthenticatedUser();
        return campaignRuntimeService.getPackagesForUser(user);
    }

    @PostMapping("/package/buy")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PACKAGE_BUY)
    public ResponseEntity buyPackage(@RequestBody BuyPackageRequestModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        try{
            campaignRuntimeService.buyPackage(user, model);
        } catch(CouponNotFoundException | NoMoneyException | RuntimePackageNotFoundException e){
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity(HttpStatus.OK);
    }

}
