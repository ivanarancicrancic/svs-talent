package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class CreateAudioContentModel extends CreateContentModel {

    @NotBlank
    private String url;

    @NotNull
    private Boolean renderOnTrackingLost;

    public CreateAudioContentModel() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Boolean getRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(Boolean renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }
}
