package de.diefuturisten.easyr.easyrapi.integration;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import java.util.Date;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRightRepository;
import  de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import  de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

public class IntegrationTestHelper {
    private static User user;
    private static ContactInformation contactInfo;

    public static String createLoginToken(User user){
        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
        String token = Jwts.builder().
                setSubject(user.getUsername()).
                setExpiration(expirationTime).
                signWith(SignatureAlgorithm.HS512, SECRET.getBytes()).
                compact();
        return TOKEN_PREFIX + token;
    }

    public static void prepareUserData(UserRepository userRepository, UserRoleRepository userRoleRepository, UserRightRepository userRightRepository){
        UserRight userRight = new UserRight("Admin role");
        UserRight userRight1 = new UserRight("CAMPAIGN_CREATE");
        UserRight updateUserRight = new UserRight("CAMPAIGN_EDIT");
        UserRight viewCampaignRight = new UserRight("CAMPAIGN_VIEW");

        userRightRepository.save(userRight);
        userRightRepository.save(userRight1);
        userRightRepository.save(updateUserRight);
        userRightRepository.save(viewCampaignRight);

        UserRole userRole1 = new UserRole("User");
        userRole1.addRight(userRight);
        userRole1.addRight(userRight1);
        userRole1.addRight(updateUserRight);
        userRole1.addRight(viewCampaignRight);
        userRoleRepository.save(userRole1);

        UserRole userRole = new UserRole("Admin");
        userRole.addRight(userRight);
        userRoleRepository.save(userRole);

        User user = new User();
        user.setFirstname("Easy");
        user.setLastname("R");
        user.setEmail("easyr@app-logik.de");
        user.setGender(true);
        user.setActive(false);
        user.addRole(userRole);
        user.addRole(userRole1);
        user.setPassword("$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq");
        user.setLanguage("EN");
        userRepository.save(user);
    }

    public static void prepareContactData(ContactInformationRepository contactInformationRepository){
        ContactInformation contactInfo = new ContactInformation();
        contactInfo.setCity("Munich");
        contactInfo.setCompany("some-company");
        contactInfo.setEmail("easyr@app-logik.de");
        contactInfo.setHomepage("appLogik.de");
        contactInfo.setAddress("Munich Strasse");
        contactInfo.setAddress2("Haupt Strasse");
        contactInfo.setNumber("+3456885332");
        contactInfo.setZip("1234");
        contactInformationRepository.save(contactInfo);
    }

    public static void prepareTrackerData(de.diefuturisten.easyr.easyrapi.repository.TrackerRepository trackerRepository){
        de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker tracker = new de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker();
        tracker.setVuforiaId("583978956FF");
        tracker.setUrl("http://example.com/");
        tracker.setCampaign(null);
        tracker.setTrackings(0);
        trackerRepository.save(tracker);
    }

    public static void prepareContentData(de.diefuturisten.easyr.easyrapi.repository.ContentRepository contentRepository){
        de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent panoramaContent = new de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent();
        panoramaContent.setUrl("http://example.com/");
        panoramaContent.setName("name");
        panoramaContent.setWeight(1);
        panoramaContent.setType(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);
        panoramaContent.setCampaign(null);
        contentRepository.save(panoramaContent);
    }

    public static void prepareRuntimeData(de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository runtimeRepository, de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository packageBuyRepository, de.diefuturisten.easyr.easyrapi.repository.UserRepository userRepository, de.diefuturisten.easyr.easyrapi.repository.CouponRepository couponRepository, de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository runtimePackageRepository){

        de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage runtimePackage = new de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage();
        runtimePackage.setBuys(null);
        runtimePackage.setName("RuntimeName");
        runtimePackage.setLengthInDays(2);
        runtimePackage.setPrice(new java.math.BigDecimal(2354.555));
        runtimePackage = runtimePackageRepository.save(runtimePackage);

        de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon coupon = new de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon();
        coupon.setUser(userRepository.findByEmail("easy.r@app-logik.de").get());
        coupon.setValidTo(new java.util.Date());
        coupon.setValidFrom(new java.util.Date());
        coupon.setCode("53749478DFF");
        coupon.setPackageBuy(null);
        coupon.setRuntimePackage(runtimePackage);
        coupon.setValidUnlimited(false);
        coupon.setDiscountPercentage(new Double(8.9));
        couponRepository.save(coupon);

        de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy packageBuy = new de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy();
        packageBuy.setUsedOnRuntime(null);
        packageBuy.setUser(userRepository.findByEmail("easy.r@app-logik.de").get());
        packageBuy.setRuntimePackage(runtimePackage);
        packageBuy.setBoughtAt(new java.util.Date());
        packageBuy.setUsedCoupon(coupon);
        packageBuyRepository.save(packageBuy);

        de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime runtime = new de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime();
        runtime.setBegin(new java.util.Date());
        runtime.setEnd(new java.util.Date());
        runtime.setCampaign(null);
        runtime.setPackageBuy(packageBuy);
        runtimeRepository.save(runtime);
    }

    public static void prepareCampaignData(CampaignRepository campaignRepository, UserRepository userRepository, ContactInformationRepository contactInformationRepository, de.diefuturisten.easyr.easyrapi.repository.ContentRepository contentRepository){
        Campaign campaign = new Campaign();
        campaign.setContactInformation(contactInformationRepository.findByEmail("easyr@app-logik.de").get());
        campaign.setUser(userRepository.findByEmail("easyr@app-logik.de").get());
        campaign.setContents(contentRepository.findAll());
        campaign.setContact(contactInformationRepository.findByEmail("easyr@app-logik.de").get());
        campaign.setName("CampaignName");
        campaign.setRuntimes(null);
        campaign.setDescription("Some description...");
        campaign.setTemporary(true);
        campaign.setTracker(null);
        campaignRepository.save(campaign);

    }

}
