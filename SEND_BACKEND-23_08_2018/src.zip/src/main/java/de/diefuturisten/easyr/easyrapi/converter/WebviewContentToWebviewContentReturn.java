package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.WebviewContentReturn;
import org.springframework.core.convert.converter.Converter;

public class WebviewContentToWebviewContentReturn implements Converter<WebviewContent, WebviewContentReturn> {

    public WebviewContentToWebviewContentReturn(){}

    @Override
    public WebviewContentReturn convert(WebviewContent source) {
        WebviewContentReturn webviewContentReturn = new WebviewContentReturn();
        webviewContentReturn.setId(source.getId());
        webviewContentReturn.setWeight(source.getWeight());
        webviewContentReturn.setName(source.getName());
        webviewContentReturn.setUrl(source.getUrl());
        return webviewContentReturn;
    }

}
