import {
    DECREMENT_QUANTITY_FETCH,
    DECREMENT_QUANTITY_SUCCESS,
    DECREMENT_QUANTITY_FAIL, 
    IOrderArticleResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const decrementQuantityFetch = createStandardAction(DECREMENT_QUANTITY_FETCH)<{orderArticle:IOrderArticleResponseModel}>();
export const decrementQuantitySuccess = createStandardAction(DECREMENT_QUANTITY_SUCCESS)<IOrderArticleResponseModel>();
export const decrementQuantityFail = createStandardAction(DECREMENT_QUANTITY_FAIL)<string>();

