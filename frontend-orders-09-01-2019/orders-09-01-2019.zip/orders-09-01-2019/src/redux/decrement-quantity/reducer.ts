import { ActionType, getType } from 'typesafe-actions';
import { IOrderArticleResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type DecrementQuantityActions = ActionType<typeof extActions>;

export interface IDecrementQuantityState {
    readonly data: IOrderArticleResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IDecrementQuantityState = {
    data: null,
    loading: false,
    error: null
};
  
export function decrementQuantityReducer(state: IDecrementQuantityState = INITIAL_STATE, action: DecrementQuantityActions): IDecrementQuantityState  {
    switch (action.type) {
        case getType(extActions.decrementQuantityFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.decrementQuantitySuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.decrementQuantityFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}