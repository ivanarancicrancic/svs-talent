import { IRootState } from '..'

export const getOrderArticles = (state: IRootState) => state.orderArticles.data;
export const getOrderArticlesLoading = (state: IRootState) => state.orderArticles.loading;
export const getOrderArticlesHasError = (state: IRootState) => state.orderArticles.error;