import { createLogic } from 'redux-logic';
// import axios from 'axios';

import { CANCEL_ORDER_FETCH, IOrderDetailResponseModel } from './types';
import { cancelOrderFetch, cancelOrderSuccess, cancelOrderFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { API_ROOT } from '../../router/api-config';

export const cancelOrderFetchLogic = createLogic({
    type: CANCEL_ORDER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(cancelOrderFetch)(action)) {
            
            fetch('http://localhost:8080/OrderCancel', {
                method: 'POST',
                body: JSON.stringify({
                  order_to_cancel: action.payload.order_to_cancel,
                })
              })
            .then(response => response.json())
            .then(data => {
            // dispatch(orderDetailSuccess(data as IOrderDetailResponseModel));
            const result = data as IOrderDetailResponseModel;
            console.log("ORDER SEARCH SUCCESS!");
            dispatch(cancelOrderSuccess(result));
             console.log(result);

            // console.log("Success: " + data);

            // Catch any errors we hit and update the app
              })
            .catch(error =>  dispatch(cancelOrderFail("fail")));
        



            // console.log("YESS");
              
            // axios({
            //     method: 'get',
            //     url: API_ROOT + '/Orders'
            // }).then(response => {
            //     console.log("Before parse response: " + response.data);
            //     const result = JSON.parse(response.data) as IOrderResponseModel[];
            //     console.log("After parsing response: " + JSON.parse(response.data));
            //     dispatch(orderListSuccess(JSON.parse(response.data) as IOrderResponseModel[]));
            //     console.log("Success: " + result);
            // }).catch(error => {
            //     dispatch(orderListFail("fail"));
            // });

        } else {
            done();
        }
    }
});

export default [
    cancelOrderFetchLogic
];
