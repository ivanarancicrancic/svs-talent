import * as React from 'react';
import { connect } from 'react-redux';
// import { Link } from "react-router-dom";
import { history } from '../../router';
import './EditOrder.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getDecrementedQuantity } from '../../redux/decrement-quantity/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
// import deIcon from '../../assets/images/edit_pencil.svg';
import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
// import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { decrementQuantityFetch } from '../../redux/decrement-quantity/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
// import EditableLabel from 'react-editable-label';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
// import { Button } from "@blueprintjs/core";
// import Box from 'react-editable-text/Box';
import { Form, Control } from 'react-redux-form';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { IOrderSaveRequestModel } from '../../redux/order-save/types';
import { RouteComponentProps } from 'react-router';
import { getSavedOrder } from '../../redux/order-save/selectors';
// import { IDecrementOrderArticlesQuantityRequestModel } from '../../redux/decrement-quantity-articles/types';


interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
    decrementQuantityFetch: typeof decrementQuantityFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    decrementQuantityData: IOrderArticleResponseModel | null;
    
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

// const customStyles = {
//     content : {
//       top                   : '50%',
//       left                  : '50%',
//       right                 : 'auto',
//       bottom                : 'auto',
//       marginRight           : '-50%',
//       transform             : 'translate(-50%, -50%)',
//       backgroundColor: 'rgba(25, 191, 114, 1)',
//       width: '100%'
//     }
//   };

class EditOrder extends React.Component<IProps>{
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modalIsOpen: false,
           modal2IsOpen: false,
           currentOrder: null,
           orderFirstNameToBeSaved: null,
           orderLastNameToBeSaved: null,
           orderCompanyNameToBeSaved: null,
           orderPaymentMethodToBeSaved: null,
           orderShippingWayToBeSaved: null,
           orderAnredeToBeSaved: null,
           orderCountryToBeSaved: null,
           orderStreetToBeSaved: null,
           orderHouseNumberToBeSaved: null,
           orderPostcodeToBeSaved: null,
           orderCityToBeSaved: null,
           orderPhoneNumberToBeSaved: null,
           orderEmailToBeSaved: null,
           orderNetPriceToBeSaved: null,
           orderGrossPriceToBeSaved: null,
           orderNetPriceWDToBeSaved: null,
           orderGrossPriceWDToBeSaved: null,
           orderToSave: null,
           decremented: 0
        

      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.closeModal = this.closeModal.bind(this);
        // this.editOrder = this.editOrder.bind(this);
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleDeleteProductFromOrder = this.handleDeleteProductFromOrder.bind(this);
        this.handleDecrementQuantity = this.handleDecrementQuantity.bind(this);
        
       
    }

    public componentWillMount() {
        console.log("ENTERED MOUNT EDIT ORDER!!!!!!!!!!!!!!!!!!!!!!!!");
        const orderId = this.props.match.params.orderId;
        this.props.orderDetailFetch({orderId});
        if(this.props.orderDetailData){
            console.log("Entered editOrder with id:" + this.props.orderDetailData.order_id);
          
        }
        else {
            console.log("this.props.orderDetailData == NULL !!!");
        }
       this.props.getOrderArticlesFetch({order_id: orderId});
               
    }


    public componentWillReceiveProps(nextProps: IProps) {
            
        this.props.orderListFetch(); 

            if(this.props.orderDetailData)
            {
                this.props.orderDetailFetch({orderId: this.props.orderDetailData.order_id});
                this.props.orderListFetch(); 
                // if(this.props.orderSavedData){
                //     // history.push(`/order/${this.props.orderDetailData.order_id}`);
                //     history.push(`/start`); 
                // }          
          
                if(this.props.decrementQuantityData){
                    console.log("Entered this.props.decrementQuantityData => qunatity should be incremented");
                    this.props.getOrderArticlesFetch({order_id:  this.props.orderDetailData.order_id});
                 }
            }

            if(this.props.orderSavedData){
                if(nextProps.orderSavedData !== this.props.orderSavedData && nextProps.orderSavedData !== null)
              {
                this.props.orderListFetch(); 
                // history.push(`/order/${this.props.orderDetailData.order_id}`);
                history.push(`/start`); 
              }
            }

          
             
    }

      public onSubmit(values:any) {
        
        console.log("Entered onEditOrder with firstName:" + values.firstname);
        history.push(`/start`);
      }


    public selectedRowHandel(order: IOrderResponseModel){
        console.log("SELECTED ORDER: " + order.firstName + order.order_id);
        const order_id = order.order_id;
        const orderId = order_id;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({order_id});
        

            // this.setState({modalIsOpen: true}); 
            history.push(`/order/${order_id}`);
   
        }

 
    public handleFilter(values:any){
        console.log("entered handle filter");
        values.preventDefault();
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
         
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
        
        console.log("State for selected dateFrom: " + this.state.dateFrom) 
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
    //  this.setState({dateTo: entryDate}); 
    
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
     console.log("State for selected dateTo: " + this.state.dateTo)
 
  };

  public handleDeleteProductFromOrder(orderToSaveId: any, orderarticleId:any){
      console.log("ENTERED handleDeleteProductFromOrder!!!");
     console.log("Decrementing quantity of orderArticle: " + orderarticleId + ", on order: " + orderToSaveId);
        

  }

  public closeModal() {
      console.log("Modal closed!!!");
    this.setState({modalIsOpen: false});
  }

public handleDecrementQuantity(orderArticle: IOrderArticleResponseModel){
console.log("Succeded!!! ENTERED with orderid: afte see " + ", and orderArticle: " + orderArticle.orArId);
// const orderarticle_id = orderArticle.orderarticle_id;

// const orderId = order_id;
// const orderarticleId = orderarticle_id;

    // const orderarticle_id = orderArticle.orderarticle_id;
    // const orderarticleId = orderarticle_id;
    // const orderArticleId = orderArticle.orderArticle_id;
   
    // this.props.decrementQuantityFetch({orderarticleId});

    // const orArId = orderArticle.orArId;
    this.props.decrementQuantityFetch({orderArticle});

}

public handleSubmitSaveOrder(value:any) {
    console.log("Entered handleSubmitSaveOrder!!!");
    console.log("orderFirstNameToBeSaved: " + value.firstName);
    console.log("orderLastNameToBeSaved: " + value.lastName);
    // console.log("ORDER_TO_BE_SAVED ID: " + value.order_id);
  
    if(this.props.orderDetailData){
    
    const newValues: IOrderSaveRequestModel = {

        order_id: this.props.orderDetailData.order_id,
        orderDate: new Date(),
        paymentMethod: value.paymentMethod,
        shippingWay: value.shippingWay,
        anrede: "anrede",
        firstName: value.firstName,
        lastName: value.lastName,
        companyName: value.companyName,
        country: value.country,
        street: value.street,
        houseNumber: value.houseNumber,
        city: value.city,
        postcode: value.postcode,
        phoneNumber: value.phoneNumber, 
        email: value.email, 
        latest: 1,
        netPrice: value.netPrice,
        grossPrice: value.grossPrice,
        netPriceWD:  value.netPriceWD,
        grossPriceWD: value.grossPriceWD 

    }

    this.props.orderSaveFetch({orderToSave: newValues});
   this.props.orderDetailFetch({orderId: newValues.order_id});
   this.props.orderListFetch();      

   this.setState({modalIsOpen: false}); 
   this.setState({modal2IsOpen: false});
//    history.push('/start');
    }
    else {
        console.log("Order not loaded");
    }
}

 
    public render() {
        let start =0;
        let quantity = 0;
        const numbers:any = [];
        // let orderToSaveid = '';
        if(this.props.orderDetailData){
            // const order_id= this.props.orderDetailData.order_id;
            // orderToSaveid = this.props.orderDetailData.order_id;
            //  this.openModal();
            console.log("!!!!  this.props.orderDetailData ! = NULL");
            if(this.props.orderArticlesData)
            {   
        return (
            <div className="grid100">
         {/* <div  style={{ position: "absolute", left: 20, overflowY: 'scroll' }}> */}
         <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitSaveOrder(info) }
          // onSubmit={ (info) => this.onSubmit1() }
        // validateOn="submit"
                    
                >   
                 <tr>
                   <td>
               
                      <div>
                      <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                      {/* <Control.text
                            className="bp3-input"
                            model=".order_id"
                            defaultValue= {this.props.orderDetailData.order_id} 
                            // onChange={this.handleChange}
                        /> */}
                       
 
                        <br/>

                        <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
                        <Control.text
                            className="bp3-input"
                            model=".firstName"
                            defaultValue={this.props.orderDetailData.firstName} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button> */}

                        <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".lastName"
                            defaultValue={this.props.orderDetailData.lastName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".companyName"
                            defaultValue={this.props.orderDetailData.companyName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".paymentMethod"
                            defaultValue={this.props.orderDetailData.paymentMethod} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                          <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".shippingWay"
                            defaultValue={this.props.orderDetailData.shippingWay} 
                            // onChange={this.handleChange}
                        />
                     <br/>


                                             <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".email"
                            defaultValue={this.props.orderDetailData.email} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".phoneNumber"
                            defaultValue={this.props.orderDetailData.phoneNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                            <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".street"
                            defaultValue={this.props.orderDetailData.street} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    
                    <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".houseNumber"
                            defaultValue={this.props.orderDetailData.houseNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".postcode"
                            defaultValue={this.props.orderDetailData.postcode} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".city"
                            defaultValue={this.props.orderDetailData.city} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".country"
                            defaultValue={this.props.orderDetailData.country} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPrice"
                            defaultValue={this.props.orderDetailData.netPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>


 <label htmlFor="grossPrice" className="bp3-file-input"><b>Gross price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPrice"
                            defaultValue={this.props.orderDetailData.grossPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPriceWD"
                            defaultValue={this.props.orderDetailData.netPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     

 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderDetailData.grossPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     {/* <label hidden={true} htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderSavedData} 
                            // onChange={this.handleChange}
                        />
                     <br/> */}

                         {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Save order >> </button>  */}
                    </div> 
                  
                   </td>
            

         </tr>
         <tr>
       
                     <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4", position: "absolute", right: 30, top: 650 }} > Save changes  </button>   
                        {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button> */}
                 
                        </tr>
     
        


     {/* </div> */}
      <div  style={{ position: "absolute", right: 80, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
     {this.props.orderArticlesData.map( orderArticle => {
                     start++;
                     quantity = parseInt(orderArticle.articleQuantity,10);
                // console.log(" top:150 + start * 20 : " +  150 + start * 20 );
                const pos =  150 + start * 20;
                // const orderarticleId = orderArticle.order_id;
               
              
                // let listItems = numbers.map((number) =>
                //   <li>{number}</li>
                // );
                 
                numbers.push(parseInt(orderArticle.articleQuantity,10));

                console.log("pos: " + pos);
                console.log("orderArticle listed ID: " + orderArticle.orArId);
                     return (
                
                        <div key={orderArticle.orArId}>
                           
                           <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 200, height: 200, position: "absolute", right: 70, top: pos }} /> </tr>
                           <tr> <div style={{position: "absolute", right: 20, top: 370 }} > <b> ARTICLE NAME:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
                           <tr> <div style={{position: "absolute", right: 135, top: 390 }} > <b> ARTICLE QUANTITY:  </b> &nbsp; {orderArticle.articleQuantity} </div></tr>
                           <tr> <div style={{position: "absolute", right: 245, top: 410 }} > <b> ARTICLE QUANTITY 2:  </b> &nbsp; {quantity} </div></tr> 
                           {/* <tr> <div style={{position: "absolute", right: 185, top: 420 }} ><button type="button" onClick={(e) => this.handleDeletePr(orderarticleId)} className="bp3-button" style={{backgroundColor : "red"}} > DECREMENT QUANTITY </button></div></tr> */}
                          
                           {/* <tr style={{position: "absolute", right: 175, top: 420 }} ><button type="button" onClick={(e) => this.handleDecrementQuantity(orderArticle)} className="bp3-button" style={{backgroundColor : "red"}} > DECREMENT QUANTITY  </button></tr> */}
                           <tr style={{position: "absolute", right: 175, top: 420 }} ><button type="button" onClick={(e) => numbers[start] = quantity + 1} className="bp3-button" style={{backgroundColor : "red"}} > DECREMENT QUANTITY  </button></tr>
                        

                           <tr><div style={{position: "absolute", right: 75, top: 420 }} ><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product from order </button></div></tr>
                                    {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
                                    {/* <img className="bp3-button imgs" src={deIcon} alt="logo" /> */}
                           
                           </div>          
                       
                    )
                })}
      </Form>
          <br/>
                </div>
    
)

     

   }           

            else{
        return (
            <div className="grid100">
      <Form 
      model="forms.info"
      method="post"
                   
     onSubmit={ (info) => this.handleSubmitSaveOrder(info) }
          // onSubmit={ (info) => this.onSubmit1() }
        // validateOn="submit"
                    
                >   
                 <tr>
                   <td>
               
                      <div>
                      <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                      {/* <Control.text
                            className="bp3-input"
                            model=".order_id"
                            defaultValue= {this.props.orderDetailData.order_id} 
                            // onChange={this.handleChange}
                        /> */}
                       
 
                        <br/>

                        <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
                        <Control.text
                            className="bp3-input"
                            model=".firstName"
                            defaultValue={this.props.orderDetailData.firstName} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button> */}

                        <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".lastName"
                            defaultValue={this.props.orderDetailData.lastName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".companyName"
                            defaultValue={this.props.orderDetailData.companyName} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".paymentMethod"
                            defaultValue={this.props.orderDetailData.paymentMethod} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                          <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".shippingWay"
                            defaultValue={this.props.orderDetailData.shippingWay} 
                            // onChange={this.handleChange}
                        />
                     <br/>


                                             <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".email"
                            defaultValue={this.props.orderDetailData.email} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".phoneNumber"
                            defaultValue={this.props.orderDetailData.phoneNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                            <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".street"
                            defaultValue={this.props.orderDetailData.street} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    
                    <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".houseNumber"
                            defaultValue={this.props.orderDetailData.houseNumber} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".postcode"
                            defaultValue={this.props.orderDetailData.postcode} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
                        <Control.text
                            className="bp3-input"
                            model=".city"
                            defaultValue={this.props.orderDetailData.city} 
                            // onChange={this.handleChange}
                        />
                     <br/>

                    <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".country"
                            defaultValue={this.props.orderDetailData.country} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPrice"
                            defaultValue={this.props.orderDetailData.netPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>


 <label htmlFor="grossPrice" className="bp3-file-input"><b>Gross price: </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPrice"
                            defaultValue={this.props.orderDetailData.grossPrice} 
                            // onChange={this.handleChange}
                        />
                     <br/>

 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".netPriceWD"
                            defaultValue={this.props.orderDetailData.netPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     

 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderDetailData.grossPriceWD} 
                            // onChange={this.handleChange}
                        />
                     <br/>
                     {/* <label hidden={true} htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                        <Control.text
                            className="bp3-input"
                            model=".grossPriceWD"
                            defaultValue={this.props.orderSavedData} 
                            // onChange={this.handleChange}
                        />
                     <br/> */}

                         {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Save order >> </button>  */}
                    </div> 
                  
                   </td>
            

         </tr>
         <tr>
       
                     <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4", position: "absolute", right: 30, top: 690 }} > Save changes  </button>   
                        {/* <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Save order  </button> */}
                 
                        </tr>
     
        </Form>



      
          <br/>
                </div>
    )
            }

   

    }

    else {
        return (
            <div className="grid100">
   
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>
                </form> 
              </div>
              <br/>
         
            </div>
        )
    }
}
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state),
    orderSavedData: getSavedOrder(state),
    decrementQuantityData: getDecrementedQuantity(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch, decrementQuantityFetch})(EditOrder)


// {this.props.orderArticlesData.map( orderArticle => {
//     return (
//         <tr key={orderArticle.orderarticle_id} className = "order_hovered">
//             <td><b>{orderArticle.orderarticle_id}</b></td>
//             <td>{orderArticle.order_id} </td> 
//             <td>{orderArticle.articleName} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>

//                     {/* <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td> */}
//                     {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
//                     {/* <td><Link to={`/order/cancel/${order.order_id}`}>cancel</Link></td> */}
//                     <img className="bp3-button imgs" src={deIcon} alt="logo" />
//                     <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > cancel </button></td>
                     
//         </tr>
//     )
// })}

// {this.props.orderArticlesData.map( orderArticle => {
//     return (

//         <tr key={orderArticle.orderarticle_id} >
//             <td><b>{orderArticle.order_id}</b></td>
//             <td>{orderArticle.articleName} </td> 
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articleDescription} </td>
//             <td>{orderArticle.articlePromotion} </td>
//             <td><button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "red"}} > delete product </button></td>
                     
//         </tr>
//     )
// })}