export const PATH_ROOT = '/';

export const PATH_PRIVACY = '/login/privacy';
export const PATH_TERMS = '/login/terms';
export const PATH_IMPRINT = '/login/imprint';
export const PATH_FAQ = '/login/faq';
export const PATH_DESCRIPTION = '/login/description';
export const PATH_REFERENCES = '/login/references';
export const PATH_LANDING = '/landing';
export const PATH_ABOUT_US = '/about-us';
export const PATH_PRODUCTS = '/products';
export const PATH_ADMINISTRATION = '/administration';
export const PATH_START = '/start';
export const PATH_SEARCH = '/search';
export const PATH_ORDER_DETAIL = '/order/:orderId';
export const PATH_ORDER_EDIT = '/order/edit/:orderId';
export const PATH_FILTERED_ORDERS = '/orders/filtered';  





