package de.ersatzteil.ersatzteilhandel24api.webService;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.mysql.cj.xdevapi.JsonParser;
import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;
import de.ersatzteil.ersatzteilhandel24api.model.IOrderArticleQuantityRequestModel;
import de.ersatzteil.ersatzteilhandel24api.model.Order;
import de.ersatzteil.ersatzteilhandel24api.model.OrderArticles;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Locale;
import java.util.Scanner;

@WebServlet("/DecrementOrderArticlesQuantity")
public class DecrementArticlesQuantityServlet extends HttpServlet {

    static String extractPostRequestBody(HttpServletRequest request) throws IOException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            Scanner s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
        return "";
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        System.out.println("ENTERED DecrementOrderArticlesQuantityServlet doPost");

        ObjectMapper mapper = new ObjectMapper();
        String result = extractPostRequestBody(request);
        JsonNode jsonNode = mapper.readTree(result);
        System.out.println("jsonNode: " + jsonNode);

        JsonParser jp = new JsonParser();

        String orderToSaveString = jsonNode.get("newQuantityValue").toString();
        System.out.println("newQuantityValue: " + orderToSaveString);


        JsonNode orderJsonNode = jsonNode.get("newQuantityValue");
        System.out.println("orderJsonNode: " + orderJsonNode);
        IOrderArticleQuantityRequestModel newQuantityValue = new IOrderArticleQuantityRequestModel();

        if (newQuantityValue != null) {
            System.out.println("newQuantityValue not null!!! ");

            String orArId = (orderJsonNode.get("orArId").asText());
            System.out.println("ORDER ARTICLE ENTRY ID: " + orArId);
            newQuantityValue.setOrArId(orArId);

            System.out.println("NEW ORDER ARTICLE QUANTITIY: " + orderJsonNode.get("quantity"));
            String quantity = orderJsonNode.get("quantity").asText();
//            newQuantityValue.setQuantity(orderJsonNode.get("quantity").asText());

//        String[] ary = orderJsonNode.get("quantity").asText().split(",");
//            newQuantityValue.setQuantity(Arrays.asList(ary));

            newQuantityValue.setQuantity(quantity);
        }

        try{
            ProjectManager projectManager= new ProjectManager();
            projectManager.decrementQuantityOrder(newQuantityValue);

            response.setContentType("application/json");
            mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
            DateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
            mapper.setDateFormat(fmt);
            OrderArticles order_to_decrement = new OrderArticles();
            System.out.println("decremented qunatity on entry-orderArticle with ID: " + order_to_decrement.getOrArId());
            mapper.writeValue(response.getOutputStream(), order_to_decrement);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
