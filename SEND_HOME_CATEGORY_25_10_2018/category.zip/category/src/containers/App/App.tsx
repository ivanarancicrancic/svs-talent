import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";

import { RouteComponentProps, Switch, Route } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_LOGIN, PATH_DASHBOARD, PATH_CAMPAIGN_EDIT, PATH_CREATE_CAMPAIGN, PATH_CAMPAIGN_DETAIL, PATH_START, PATH_SEARCH, PATH_INQUIRY } from '../../router/paths';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
import EditCategory from '../../components/Category/EditCategory';
import ProductGroupsLayout from '../../components/ProductGroupsLayout/ProductGroupsLayout';
import StartLayout from '../../components/StartLayout/StartLayout';
import SearchLayout from '../../components/SearchLayout/SearchLayout';
import SearchProductPart from '../../components/Search/SearchProductPartBasic/SearchProductPartBasic';
import ManageCampaign from '../../components/ManageCampaign/ManageCampaign';
import Inquiry from '../../components/InquiryLayout/InquiryLayout';

library.add(faEnvelope, faKey);

interface IPropsStateMap {
  auth: IAuthState
}

type IProps = RouteComponentProps<{}> & IPropsStateMap;

class App extends React.Component<IProps> {

  public componentWillReceiveProps(nextProps: IProps) {
    if(this.props.auth.token != null && nextProps.auth.token == null) {
      this.props.history.replace(PATH_LOGIN);
    }
  }

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_DASHBOARD} exact={true} component={ProductGroupsLayout} />
            <Route path={PATH_SEARCH} exact={true} component={SearchLayout} />
            <Route path={PATH_START} exact={true} component={StartLayout} />
            <Route path={PATH_CAMPAIGN_EDIT} exact={true} component={EditCategory} />
            <Route path={PATH_CREATE_CAMPAIGN} exact={true} component={SearchProductPart} />
            <Route path={PATH_CAMPAIGN_DETAIL} exact={true} component={ManageCampaign} />
            <Route path={PATH_INQUIRY} exact={true} component={Inquiry} />
          </Switch>
        </div>
        <Footer />
      </div>
    );
  }


}
const mapStateToProps = (state: IRootState) => ({
  auth: state.auth
});

export default connect(mapStateToProps)(App);