import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';

export default class CreateInfo extends React.Component {
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }
    
      public onSubmit(values:any) {
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        console.log(values)
      }

    public render() {
        return (
            <div className="createInfo">

          <table>
              <tr>
                  <td>
                <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validateOn="submit"
                    
                >
               
                    <div>
                        <label><b>Suche über Warengruppen. </b>
                        <br/>Nichts gefunden? <br/> Nutzen Sie die Möglichkeit per Warengruppe zu suchen...</label>
                        <br/>
                        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#B22222"}} > Schnellsuche </button>
                    </div>
                 
                    </Form>
                  </td>

                   <td> 
                    <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validateOn="submit"
                    
                >
                    <div >
                        <label><b>Bilder-Suche für einige </b> <br/> Warengruppen</label><br/>
                        Vergleichen Sie Ihr gesuchtes Ersatzteil über Bilder. Wenn Sie die genaue Bezeichnung Ihres Ersatzteils nicht kennen, nutzen Sie diese Suche!
                        <br/> 
                        <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4"}} > Image Search >> </button>               
                    </div>
                    </Form>
                    </td>
                    
                    <td>
                    <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validateOn="submit"
                    
                >
                
                       <div >
                        <label><b>Explosionszeichnungen </b></label><br/>
                        - Vendingmaschinen
                        <br/> 
                        - Kaffeemaschinen <br/>
                        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Explosionszeichnungen >> </button>               
                    </div>
                     </Form>
                   </td>
                   </tr>

                 <tr>
                   <td>
                <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validators={{
                        name: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                    
                >
                      <div>
                        <label htmlFor="name" className="bp3-file-input"><b>Suche nach Artikelnummer</b></label>
                        <br/>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'Please enter a article number!',
                            }}
                            show="touched"
                            className="errors"
                        /> <br/>
                         <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Suchen >> </button> 
                    </div> 
                   </Form>
                   </td>
               
                     <td>
                 <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validators={{
                        name1: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                    
                >
                     <br/>
                    <div className="bp3-input-group">
                        <label htmlFor="package" className="bp3-file-input"><b>Suche nach Herstellernummer</b></label>
                        <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".package" 
                            >
                                 <option defaultValue="Basic">Herstellen wahlen </option>
                                <option value="Advanced">A.D. </option>
                                <option value="Premium">A.R.C </option>
                                <option value="Premium">A.B </option>
                                <option value="Premium">ABAT </option>
                                <option value="Premium">ABB </option>
                            </Control.select>
                        </div>
                        <Control.text
                            className="bp3-input"
                            model=".name1"
                        />
                        <Errors
                            model=".name1"
                            messages={{
                                required: 'Please enter sth in input field',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                    </div>
                    <label>
                        <Control.checkbox model=".check" /> Hersteller unbekannt
                    </label>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}> Suchen >> </button>
                  </Form>
              </td>
              <td>
                  <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validators={{
                        name2: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                    
                >
                    <div className="bp3-input-group">
                        <label htmlFor="package" className="bp3-file-input"><b>Spezial-Suche</b></label>
                        - Kühlgeräte Dichtungen <br/>
                        - Wasserarmaturen, Brausen <br/>
                        - Sanitär und Zubehör
                       <br/>
                       <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".package" 
                            >
                                <option defaultValue="Basic">Gewerbekalte wahlen </option>
                                <option value="Advanced">Schockfroste </option>
                                <option value="Premium">A.R.C </option>
                                <option value="Premium">A.B </option>
                                <option value="Premium">ABAT </option>
                                <option value="Premium">ABB </option>
                            </Control.select>
                        </div>

                       <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".package" 
                            >
                                <option defaultValue="Basic">Dichtung </option>
                            </Control.select>
                        </div>

                        <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".package" 
                            >
                                <option defaultValue="Basic">Gewerbekalte wahlen </option>
                                <option value="Advanced">Schockfroste </option>
                                <option value="Premium">A.R.C </option>
                                <option value="Premium">A.B </option>
                                <option value="Premium">ABAT </option>
                                <option value="Premium">ABB </option>
                            </Control.select>
                        </div>
                        <br/>
                        <Control.text
                            className="bp3-input"
                            model=".name2"
                        />
                        <Errors
                            model=".name2"
                            messages={{
                                required: 'Please enter sth in text input field!',
                            }}
                            show="touched"
                            className="errors"
                        /> <br/>
                    </div>
                    <label>
                        <Control.checkbox model=".check" /> ohne Hersteller
                    </label>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>


                </Form>
                </td>
         </tr>
         <tr>
         <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validators={{
                        name3: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                    
                >
                  <b>    Suche nach Modell </b><br/>
- Hersteller Angabe zusaetzlich moeglich
                 <Control.text
                            className="bp3-input"
                            model=".name3"
                        />
                        <Errors
                            model=".name3"
                            messages={{
                                required: 'Please enter a Model name',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        
                        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Search >> </button>
   
   
       </Form>
         </tr>
         </table>
            </div>
        )
       
    }

}