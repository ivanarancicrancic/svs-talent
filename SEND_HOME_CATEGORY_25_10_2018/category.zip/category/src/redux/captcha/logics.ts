import { createLogic } from 'redux-logic';
import axios from 'axios';

import { CAPTCHA_FETCH, ICaptchaResponseModel } from './types';
import { captchaFetch, captchaSuccess, captchaFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';

export const captchaFetchLogic = createLogic({
    type: CAPTCHA_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(captchaFetch)(action)) {
            
            axios({
                method: 'post',
                url: API_ROOT + '/captcha',
            }).then(response => {
                const result = response.data as ICaptchaResponseModel
                dispatch(captchaSuccess(result));
            }).catch(error => {
                dispatch(captchaFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    captchaFetchLogic
];
