import { createLogic } from 'redux-logic';
import axios from 'axios';

import { CATEGORY_DETAIL_FETCH, ICategoryDetailResponseModel, TRACKER_UPLOAD_FETCH, ITrackerResponseModel, TRACKER_DELETE_FETCH, CATEGORY_CREATE_FETCH, CATEGORY_SAVE_FETCH, CATEGORY_EDIT_FETCH, CONTENT_VIDEO_CREATE_FETCH, IVideoContentResponseModel, CONTENT_DELETE_FETCH, CONTENT_VIDEO_EDIT_FETCH, CONTENT_PANORAMA_CREATE_FETCH, IPanoramaContentResponseModel, CONTENT_PANORAMA_EDIT_FETCH, CONTENT_WEBVIEW_CREATE_FETCH, CONTENT_WEBVIEW_EDIT_FETCH, IWebviewContentResponseModel, CONTENT_AUDIO_CREATE_FETCH, IAudioContentResponseModel, CONTENT_AUDIO_EDIT_FETCH, CONTENT_UNITY_CREATE_FETCH, IUnityContentResponseModel, CONTENT_UNITY_EDIT_FETCH, CONTENT_SLIDESHOW_CREATE_FETCH, ISlideshowContentResponseModel, CONTENT_SLIDESHOW_EDIT_FETCH, CONTENT_SLIDESHOW_IMAGEUP_FETCH, CONTENT_SLIDESHOW_IMAGEDOWN_FETCH, CONTENT_RENAME_FETCH, IContentResponseModel, CONTENT_MOREINFO_CREATE_FETCH, IMoreinfoContentResponseModel, CONTENT_MOREINFO_EDIT_FETCH } from './types';
import { categoryDetailFetch, categoryDetailSuccess, categoryDetailFail, trackerUploadFetch, trackerUploadSuccess, trackerUploadFail, trackerDeleteFetch, trackerDeleteSuccess, trackerDeleteFail, categoryCreateSuccess, categoryCreateFail, categoryCreateFetch, categorySaveFetch, categorySaveSuccess, categorySaveFail, categoryEditFetch, contentVideoCreateFetch, contentVideoCreateSuccess, contentVideoCreateFail, contentDeleteFetch, contentDeleteSuccess, contentDeleteFail, contentVideoEditFetch, contentVideoEditSuccess, contentVideoEditFail, contentPanoramaCreateFetch, contentPanoramaCreateSuccess, contentPanoramaCreateFail, contentPanoramaEditFetch, contentPanoramaEditFail, contentPanoramaEditSuccess, contentWebviewCreateFetch, contentWebviewEditFetch, contentWebviewCreateSuccess, contentWebviewCreateFail, contentWebviewEditSuccess, contentWebviewEditFail, contentAudioCreateFetch, contentAudioCreateSuccess, contentAudioCreateFail, contentAudioEditFetch, contentAudioEditSuccess, contentAudioEditFail, contentUnityCreateFetch, contentUnityCreateSuccess, contentUnityCreateFail, contentUnityEditFetch, contentUnityEditSuccess, contentUnityEditFail, contentSlideshowCreateFetch, contentSlideshowCreateSuccess, contentSlideshowCreateFail, contentSlideshowEditFetch, contentSlideshowEditSuccess, contentSlideshowEditFail, contentSlideshowImageUpFetch, contentSlideshowImageUpSuccess, contentSlideshowImageDownFetch, contentSlideshowImageDownSuccess, contentSlideshowImageDownFail, contentRenameFetch, contentRenameSuccess, contentRenameFail, contentMoreinfoCreateFetch, contentMoreinfoCreateSuccess, contentMoreinfoCreateFail, contentMoreinfoEditFetch, contentMoreinfoEditSuccess, contentMoreinfoEditFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const categoryDetailFetchLogic = createLogic({
    type: CATEGORY_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryDetailFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/campaign/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categoryDetailSuccess(result));
            }).catch(error => {
                dispatch(categoryDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categoryCreateFetchLogic = createLogic({
    type: CATEGORY_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categoryCreateSuccess(result));
            }).catch(error => {
                dispatch(categoryCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categorySaveFetchLogic = createLogic({
    type: CATEGORY_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categorySaveFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/save`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { packageId: action.payload.packageId }
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categorySaveSuccess(result));
            }).catch(error => {
                dispatch(categorySaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categoryEditFetchLogic = createLogic({
    type: CATEGORY_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categorySaveSuccess(result));
            }).catch(error => {
                dispatch(categorySaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const trackerUploadFetchLogic = createLogic({
    type: TRACKER_UPLOAD_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(trackerUploadFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/tracker`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as ITrackerResponseModel
                dispatch(trackerUploadSuccess(result));
            }).catch(error => {
                dispatch(trackerUploadFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const trackerDeleteFetchLogic = createLogic({
    type: TRACKER_DELETE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(trackerDeleteFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'delete',
                url: API_ROOT + `/api/campaign/tracker/${action.payload.trackerId}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                dispatch(trackerDeleteSuccess({trackerId: action.payload.trackerId}));
            }).catch(error => {
                dispatch(trackerDeleteFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentDeleteFetchLogic = createLogic({
    type: CONTENT_DELETE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentDeleteFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'delete',
                url: API_ROOT + `/api/campaign/content/${action.payload.contentId}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                dispatch(contentDeleteSuccess({contentId: action.payload.contentId}));
            }).catch(error => {
                dispatch(contentDeleteFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentVideoCreateLogic = createLogic({
    type: CONTENT_VIDEO_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentVideoCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/movie`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IVideoContentResponseModel
                dispatch(contentVideoCreateSuccess(result));
            }).catch(error => {
                dispatch(contentVideoCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentVideoEditLogic = createLogic({
    type: CONTENT_VIDEO_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentVideoEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/movie/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IVideoContentResponseModel
                dispatch(contentVideoEditSuccess(result));
            }).catch(error => {
                dispatch(contentVideoEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentPanoramaCreateLogic = createLogic({
    type: CONTENT_PANORAMA_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentPanoramaCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/panorama`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IPanoramaContentResponseModel
                dispatch(contentPanoramaCreateSuccess(result));
            }).catch(error => {
                dispatch(contentPanoramaCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentPanoramaEditLogic = createLogic({
    type: CONTENT_PANORAMA_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentPanoramaEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/panorama/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IPanoramaContentResponseModel
                dispatch(contentPanoramaEditSuccess(result));
            }).catch(error => {
                dispatch(contentPanoramaEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

// WEBVIEW
export const contentWebviewCreateLogic = createLogic({
    type: CONTENT_WEBVIEW_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentWebviewCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/webview`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IWebviewContentResponseModel
                dispatch(contentWebviewCreateSuccess(result));
            }).catch(error => {
                dispatch(contentWebviewCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentWebviewEditLogic = createLogic({
    type: CONTENT_WEBVIEW_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentWebviewEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/webview/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IWebviewContentResponseModel
                dispatch(contentWebviewEditSuccess(result));
            }).catch(error => {
                dispatch(contentWebviewEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

// MOREINFO
export const contentMoreinfoCreateLogic = createLogic({
    type: CONTENT_MOREINFO_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentMoreinfoCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/moreinfo`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IMoreinfoContentResponseModel
                dispatch(contentMoreinfoCreateSuccess(result));
            }).catch(error => {
                dispatch(contentMoreinfoCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentMoreinfoEditLogic = createLogic({
    type: CONTENT_MOREINFO_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentMoreinfoEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/moreinfo/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IMoreinfoContentResponseModel
                dispatch(contentMoreinfoEditSuccess(result));
            }).catch(error => {
                dispatch(contentMoreinfoEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentAudioCreateLogic = createLogic({
    type: CONTENT_AUDIO_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentAudioCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/audio`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IAudioContentResponseModel
                dispatch(contentAudioCreateSuccess(result));
            }).catch(error => {
                dispatch(contentAudioCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentAudioEditLogic = createLogic({
    type: CONTENT_AUDIO_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentAudioEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/audio/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IAudioContentResponseModel
                dispatch(contentAudioEditSuccess(result));
            }).catch(error => {
                dispatch(contentAudioEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

// UNITY
export const contentUnityCreateLogic = createLogic({
    type: CONTENT_UNITY_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentUnityCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/unity`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IUnityContentResponseModel;
                dispatch(contentUnityCreateSuccess(result));
            }).catch(error => {
                dispatch(contentUnityCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentUnityEditLogic = createLogic({
    type: CONTENT_UNITY_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentUnityEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/unity/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IUnityContentResponseModel
                dispatch(contentUnityEditSuccess(result));
            }).catch(error => {
                dispatch(contentUnityEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

// SLIDESHOW
export const contentSlideshowCreateLogic = createLogic({
    type: CONTENT_SLIDESHOW_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentSlideshowCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/campaign/${action.payload.campaignId}/slideshow`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as ISlideshowContentResponseModel;
                dispatch(contentSlideshowCreateSuccess(result));
            }).catch(error => {
                dispatch(contentSlideshowCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentSlideshowEditLogic = createLogic({
    type: CONTENT_SLIDESHOW_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentSlideshowEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/slideshow/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as ISlideshowContentResponseModel;
                dispatch(contentSlideshowEditSuccess(result));
            }).catch(error => {
                dispatch(contentSlideshowEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentSlideshowImageUpLogic = createLogic({
    type: CONTENT_SLIDESHOW_IMAGEUP_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentSlideshowImageUpFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/slideshow/image/${action.payload.imageId}/up`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as ISlideshowContentResponseModel;
                dispatch(contentSlideshowImageUpSuccess(result));
            }).catch(error => {
                dispatch(contentSlideshowEditFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentSlideshowImageDownLogic = createLogic({
    type: CONTENT_SLIDESHOW_IMAGEDOWN_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentSlideshowImageDownFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/slideshow/image/${action.payload.imageId}/down`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as ISlideshowContentResponseModel;
                dispatch(contentSlideshowImageDownSuccess(result));
            }).catch(error => {
                dispatch(contentSlideshowImageDownFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const contentRenameLogic = createLogic({
    type: CONTENT_RENAME_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(contentRenameFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/campaign/content/${action.payload.contentId}/name`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { name: action.payload.name }
            }).then(response => {
                const result = response.data as IContentResponseModel;
                dispatch(contentRenameSuccess(result));
            }).catch(error => {
                dispatch(contentRenameFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    categoryDetailFetchLogic,
    categoryCreateFetchLogic,
    categorySaveFetchLogic,
    categoryEditFetchLogic,

    trackerUploadFetchLogic,
    trackerDeleteFetchLogic,

    contentDeleteFetchLogic,
    
    contentVideoCreateLogic,
    contentVideoEditLogic,

    contentPanoramaCreateLogic,
    contentPanoramaEditLogic,

    contentWebviewCreateLogic,
    contentWebviewEditLogic,

    contentMoreinfoCreateLogic,
    contentMoreinfoEditLogic,

    contentAudioCreateLogic,
    contentAudioEditLogic,

    contentUnityCreateLogic,
    contentUnityEditLogic,

    contentSlideshowCreateLogic,
    contentSlideshowEditLogic,
    contentSlideshowImageUpLogic,
    contentSlideshowImageDownLogic,

    contentRenameLogic
];
