export const CATEGORY_LIST_FETCH = '@@user/category/list/FETCH';
export const CATEGORY_LIST_SUCCESS = '@@user/category/list/SUCCESS';
export const CATEGORY_LIST_FAIL = '@@user/category/list/FAIL';

export const CATEGORY_CREATE_FETCH = '@@category/create/FETCH';
export const CATEGORY_CREATE_SUCCESS = '@@category/create/SUCCESS';
export const CATEGORY_CREATE_FAIL = '@@category/create/FAIL';

export interface ICategoryResponseModel {
    id: number;
    name: string;
    trackerUrl: string | null;
    numberOfViews: number;
    expirationDate: string | null;
};