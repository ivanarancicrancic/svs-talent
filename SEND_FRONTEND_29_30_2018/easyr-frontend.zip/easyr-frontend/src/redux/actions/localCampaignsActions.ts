import { HANDLE_SET_SELECTED_CAMPAIGN, HANDLE_SET_AUDIOS, HANDLE_FETCH_AUDIOS_FAILED, HANDLE_SET_CAMPAIGNS, HANDLE_FETCH_CAMPAIGNS_FAILED, HANDLE_FETCH_CONTENTS_FAILED, HANDLE_FETCH_TRACKERS_FAILED, HANDLE_SET_CONTENTS, HANDLE_SET_TRACKERS} from './actionTypes'
import { getFromBackend } from '../../api/api'
import { IRealCampaign, IMovieContent, ITracker, IAudioContent} from '../../models/CampaignsModelHelper';

import { idCampaign } from '../../components/Dashboard/Campaigns';

interface ICampaignAction<Action> {
    type: string
    payload?: any
}

interface ITrackerAction {
    type: string
    payload?: any
}

interface IContentsAction {
    type: string
    payload?: any
}

interface IAudiosAction {
    type: string
    payload?: any
}

interface IRealCampaignData {
    "campaigns": IRealCampaign[] 
}

const realCampaignData:IRealCampaignData = {
    "campaigns": []
}

const setCampaigns = (campaigns: IRealCampaign[]) => {
    return {
      type: HANDLE_SET_CAMPAIGNS,
      payload: campaigns
    }

}


const setSelectedCampaign = (campaignID: string) => {
    return {
      type: HANDLE_SET_SELECTED_CAMPAIGN,
      payload: campaignID
    }

}


const setContents = (contents: IMovieContent[]) => {
    return {
      type: HANDLE_SET_CONTENTS,
      payload: contents
    }
}

const setAudios = (audios: IAudioContent[]) => {
    return {
      type: HANDLE_SET_AUDIOS,
      payload: audios
    }
}

const setTrackers = (tracker: ITracker[]) => {
    return {
      type: HANDLE_SET_TRACKERS,
      payload: tracker
    }
}


/* tslint:disable:no-string-literal */
const updateSelectedCampaign = (id: string) => {
   console.log("ENTERED update Selected!!");
    return (dispatch :any, getState:any) => {  
        
        dispatch(setSelectedCampaign(id)); 
    }
}

const getListedCampaigns = () => {
    const url: string = '/campaigns'
   console.log("ENTERED getListedCampaigns!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:IRealCampaign[]) => {
              
                 dispatch(setCampaigns(response)); 
            }).catch((error:any) => {
                  dispatch(campaignDataFaied(error))
            })
    }
}

const getListedContents = (id: string) => {
    const url: string = '/campaign/'+id+'/movies'
   console.log("ENTERED getListedContents!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:IMovieContent[]) => {
              
                 dispatch(setContents(response)); 
            }).catch((error:any) => {
                  dispatch(contentsDataFaied(error))
            })
    }
}

const getListedAudios = () => {
    const url: string = '/campaign/1/audios'
   console.log("ENTERED getListedAudios!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:IAudioContent[]) => {
              
                 dispatch(setAudios(response)); 
            }).catch((error:any) => {
                  dispatch(audiosDataFaied(error))
            })
    }
}



const getListedTrackers = (idCampa: string) => {
    const url: string = '/campaign/' + idCampa + '/trackers'
   console.log("ENTERED getListedTrackers!!");
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:ITracker[]) => {
              
                 dispatch(setTrackers(response)); 
            }).catch((error:any) => {
                  dispatch(trackersDataFaied(error))
            })
    }
}
/* tslint:enable:no-string-literal */


// const getEditedCampaigns = (repResponseData: any, dispatch: any) => {
//     const url: string = '/testCampaigns'

//     return getFromBackend(url).then(response => {
//         dispatch(addressDataSuccess(response.data))
//     }).catch(error => {
//           dispatch(campaignDataFaied(error))
//     })
// }


/* tslint:disable:no-string-literal */
const editAndGetCampaigns = (name: string) => {
    // const url: string = '/campaign/update'
    // const data = {
    //     'id': name
    // }
    // return (dispatch :any, getState:any) => {  
    //         return postToBackend(url, data).then( (response:IRealCampaign) => {
    //             const repData = {
    //                 edited_campaign: response              
    //             }
    //              getEditedCampaigns(repData, dispatch) 
    //         }).catch((error:any) => {
    //               dispatch(campaignDataFaied(error))
    //         })
    // }

        const url: string = '/campaign/ ' + idCampaign.id + '/tracker/' + name + '/delete'
        console.log("URL: " + url);
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:ITracker) => {
            
                getListedTrackers(idCampaign.id) 
            }).catch((error:any) => {
                  dispatch(campaignDataFaied(error))
            })
    }

}
/* tslint:enable:no-string-literal */

// const addressDataSuccess = (addressData: any) => {
//     return {
//         type: HANDLE_GET_ALL_CAMPAIGNS,
//         payload: addressData
//     }
// }

const campaignDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_CAMPAIGNS_FAILED,
        payload: error
    }
}

const trackersDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_TRACKERS_FAILED,
        payload: error
    }
}


const contentsDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_CONTENTS_FAILED,
        payload: error
    }
}

const audiosDataFaied = (error: any) => {
    return {
        type: HANDLE_FETCH_AUDIOS_FAILED,
        payload: error
    }
}

export {
    editAndGetCampaigns, updateSelectedCampaign, ICampaignAction, realCampaignData, getListedCampaigns, IAudiosAction, getListedContents, getListedTrackers, getListedAudios, ITrackerAction, IContentsAction
}