  import { getFromBackend } from '../../api/api'

const getCampaigns = () => {
    const teamURL = '/campaigns'
     return getFromBackend(teamURL)
}

const getRealCampaigns = () => {
    const teamURL = '/campaigns'
     return getFromBackend(teamURL)
}

export {
     getCampaigns,
     getRealCampaigns
}
