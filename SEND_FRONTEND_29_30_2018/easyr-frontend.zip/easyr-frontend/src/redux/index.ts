import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';
import { IAuthState, AuthActions, authReducer } from './auth/reducer';
import { campaignsReducer, IRealCampaignData } from './store/CampaignsReducer'
import { ICampaignsAction } from './actions/campaignsActions'
import { formsReducer } from './forms';
import { trackerReducer, ITrackersData } from './store/TrackerReducer';
import { ITrackerAction, IContentsAction, IAudiosAction } from './actions/localCampaignsActions';
import { contentsReducer, IMovieContentsData } from './store/ContentsReducer';
import { audiosReducer, IAudioContentsData } from './store/AudiosReducer';
import { ISelectionCampaignData, selectionReducer } from './store/SelectionReducer';


export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    auth: IAuthState;
    forms: any;
    allCampaign: IRealCampaignData,
    allTrackers: ITrackersData,
    allMovieContents: IMovieContentsData,
    allAudioContents: IAudioContentsData,
    selectedCampaign: ISelectionCampaignData
}

export type RootAction = RouterAction
    | LocationChangeAction
    | AuthActions | ICampaignsAction | ITrackerAction | IContentsAction | IAudiosAction;

export const reducers = combineReducers<IRootState>({
    i18n: i18nReducer,
    router: routerReducer,
    auth: authReducer,
    forms: formsReducer,
    allCampaign: campaignsReducer,
    allTrackers: trackerReducer,
    allMovieContents: contentsReducer,
    allAudioContents: audiosReducer,
    selectedCampaign: selectionReducer
});