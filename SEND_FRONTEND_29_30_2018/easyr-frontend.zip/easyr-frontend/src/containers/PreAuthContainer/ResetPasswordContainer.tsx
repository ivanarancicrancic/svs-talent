import * as React from 'react';

export default class ResetPasswordContainer extends React.Component {

    public render() {
        return (
            <span>ResetPasswordContainer</span>
        )
    }

}