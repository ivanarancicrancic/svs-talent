import * as React from 'react';

export default class ForgotPasswordContainer extends React.Component {

    public render() {
        return (
            <span>ForgotPasswordContainer</span>
        )
    }

}