import * as React from 'react';
import {Control, actions as formActions, Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import {Icon} from '@blueprintjs/core';

import './LoginForm.css';
import {Link} from "react-router-dom";
import {PATH_FORGOT_PASSWORD_REQUEST, PATH_REGISTER} from "../../../router/paths";
import {maxLength50} from "../validator";
import { connect } from 'react-redux';
import { IRootState } from '../../../redux';

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
    formActions: typeof formActions;
}

class LoginForm extends React.Component<IProps> {

    private formDispatch?: any;

    public componentWillUnmount(){
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.login'));
        }
    }

    public render() {
        return (
            <div>
                <Form
                    model="forms.login"
                    onSubmit={(values) => this.props.onSubmit(values)}
                    getDispatch={(dispatch: any) => this.formDispatch = dispatch}
                >
                    <div>
                        <div className="userIcon">
                            <Icon icon="user" iconSize={60}/>
                        </div>
                        <Control
                            model=".username"
                            validators={{
                                required: (val) => val && val.length,
                                maxLength50
                            }}
                            component={"input"}

                            controlProps={{
                                className: "bp3-input inputButton",
                                placeholder: "Benutzername"
                            }}
                        />
                    </div>

                    <div>
                        <Control
                            model=".password"
                            validators={{
                                required: (val) => val && val.length,
                                /* minLength5, */
                                maxLength50
                            }}
                            component={"input"}
                            controlProps={{
                                className: "bp3-input inputButton",
                                type: "password",
                                placeholder: "Passwort"
                            }}
                        />
                        <div className="forgotPass">
                            <Link to={PATH_FORGOT_PASSWORD_REQUEST}> Forgot your password? </Link>
                        </div>
                    </div>

                    <div className="loginBtn">
                        <button className="logIn bp3-button bp3-minimal">
                            Log in
                        </button>
                    </div>

                </Form>

                <div className="signUp">
                    <p> Don't have an account? </p>
                    <Link to={PATH_REGISTER} role="button" className="bp3-button bp3-minimal"> Sign up </Link>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
    form: state.forms.forms.login
});

const actions = {
    formActions
};

export default connect(mapStateToProps, actions)(LoginForm);