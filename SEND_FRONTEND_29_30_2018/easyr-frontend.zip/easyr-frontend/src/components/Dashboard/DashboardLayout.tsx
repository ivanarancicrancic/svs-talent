import * as React from 'react';
import './DashboardLayout.css';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import Campaigns from './Campaigns'

const SampleCampaigns = () => {
    return (
        <Campaigns />
    )
}

class DashboardContainer extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.state = {
            token: ""
        }
    }

    public render() {
        return (
            <div className="grid100">            
                 { SampleCampaigns() }
                <div className="grid45">
                    <table className="table campaignTable bp3-html-table bp3-html-table-bordered">
                        <thead>
                            <tr>
                            <th colSpan={3}>Bought campaign package</th>
                            </tr>
                        </thead>
                        <tbody >
                            <tr>
                            <td>Bought: 5</td>
                            <td>Used: 3</td>
                            <td>Unused: 2</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, {})(DashboardContainer)