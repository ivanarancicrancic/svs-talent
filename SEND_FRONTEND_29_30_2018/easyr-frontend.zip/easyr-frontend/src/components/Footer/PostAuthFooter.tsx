import * as React from 'react';
import {NavLink} from "react-router-dom";
import {PATH_FAQ, PATH_IMPRINT, PATH_PRIVACY, PATH_ROOT, PATH_TERMS} from "../../router/paths";

export default class PostAuthFooter extends React.Component {

    public render() {
        return (
            <div className="postFooter footer">
                <nav className="bp3-navbar">
                    <div className="footerNav">
                        <div className="bp3-navbar-group bp3-align-left">
                            <div className="bp3-navbar-heading">&copy; Copyright 2018</div>
                            <NavLink to={PATH_FAQ} className="bp3-navbar-heading"> FAQ </NavLink>
                        </div>
                        <div className="bp3-navbar-group bp3-align-right">
                            <NavLink to={PATH_ROOT} className="bp3-navbar-heading">CONTACT US</NavLink>
                            <NavLink to={PATH_IMPRINT} className="bp3-navbar-heading">IMPRINT</NavLink>
                            <NavLink to={PATH_PRIVACY} className="bp3-navbar-heading">PRIVACY POLICY</NavLink>
                            <NavLink to={PATH_TERMS} className="bp3-navbar-heading">TERMS & CONDITIONS</NavLink>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

}