import * as React from 'react';
import {NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD} from "../../router/paths";

import './Header';

export default class PostAuthHeader extends React.Component {

    public render() {
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group bp3-align-left">
                            <NavLink to={PATH_ROOT} className="bp3-navbar-heading"> LOGO </NavLink>
                            <div className="leftBox">
                                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Create Campaign </NavLink>
                                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Buy Campaign </NavLink>
                            </div>
                        </div>
                        <div className="bp3-navbar-group bp3-align-right">
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Analytics </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Push </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Konto </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> Dashboard </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> <button className="bp3-button bp3-icon-cog bp3-minimal"/> </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading"> <button className="bp3-button bp3-icon-search bp3-minimal"/> </NavLink>
                            <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">First LastName <button className="bp3-button bp3-icon-person bp3-minimal"/> </NavLink>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }
}