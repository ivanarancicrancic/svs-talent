import * as React from 'react';
import './CampaignInfo.css';

export default class CampaignInfo extends React.Component {

    public render() {
        return (
            <div className="infoBox">
                <h2> Campaign Information </h2>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tellus mi, rhoncus non eros eu, varius tristique lorem. 
                    Ut imperdiet est fringilla porttitor tristique. </p>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tellus mi, rhoncus non eros eu, varius tristique lorem. 
                    Ut imperdiet est fringilla porttitor tristique. </p>
                <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec tellus mi, rhoncus non eros eu, varius tristique lorem. 
                    Ut imperdiet est fringilla porttitor tristique. </p>
            </div>
        )
    }

}