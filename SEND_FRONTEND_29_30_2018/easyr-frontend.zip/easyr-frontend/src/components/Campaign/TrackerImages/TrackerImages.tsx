import * as React from 'react';
import './TrackerImages.css';

import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedTrackers} from '../../../redux/actions/localCampaignsActions'
import { ITracker } from '../../../models/CampaignsModelHelper'
import { IRootState } from '../../../redux/index';
import { idCampaign } from '../../Dashboard/Campaigns';

interface ICampaignInfosState {
    entry: string,
    tracker?: ITracker[],
     error?: any,
     deleted? : string,
     selected? : boolean,
     selectedUrl? : string

}
interface ICampaignInfosProps {
    getAllTrackers: any,
    editCampaignData: any,
    tracker: any
}

type IProps = ICampaignInfosProps

class TrackerImages extends React.Component<IProps, ICampaignInfosState> {
    constructor(props: IProps) {
        super(props)
        this.state = {
            entry: '',
            deleted: 'false',
            selected: false,
            selectedUrl: ''
        }
    }

    public deleteTracker(id:string) {
        this.setState({deleted: 'true'});
        this.props.editCampaignData(id);
        console.log(" STATE FOR DELETE" + this.state);
        
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
        }
    }

    public postSelectedHandler = (id:string) => {
        console.log("Selected tracker! With id: " + id);
         this.setState({selected: true});
         this.setState({selectedUrl: id})
         
    }
  /* tslint:enable:no-string-literal */
    
    public render() {
        return (
            <div className="trackerBox">
            
                <div className="trackerLeft">
                    <div>
                    {
                  this.props.tracker.map((t: ITracker) =>
                  
                  <div key= {t.id}  onClick={() => this.postSelectedHandler(t.url)}>
                    <img src= {t.url} className="trackerImg" />
                    <button className="bp3-button bp3-minimal" onClick={() => this.deleteTracker(t.id) }> <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                  </div>
                  )
                    }
                </div>
                    <div>
                    <button className="bp3-button bp3-minimal" ><span className="bp3-icon-standard bp3-icon-add" /> </button>
                    </div>
                </div>
                <div className="trackerRight">
                 
                <div> <img className="trackerMainImg" src= {this.state.selectedUrl} /> </div>
                 
                   <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                </div>
            </div>
        )
    }

    public componentDidMount() {
        if(idCampaign.create){
        this.props.getAllTrackers(idCampaign.id);
    }
}

   public componentDidUpdate(){

        this.props.getAllTrackers(idCampaign.id);
   }

    public componentWillReceiveProps(newProps: ICampaignInfosProps) {
       
        if(idCampaign.create){
            this.props.getAllTrackers(idCampaign.id);}
        }
}

const mapStateToProps = (state: IRootState) => {
    return {
        tracker: state.allTrackers.trackers,
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllTrackers: (idCam: string) => dispatch(getListedTrackers(idCam)),
        editCampaignData: (entry: string) => dispatch(editAndGetCampaigns(entry))
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TrackerImages)


