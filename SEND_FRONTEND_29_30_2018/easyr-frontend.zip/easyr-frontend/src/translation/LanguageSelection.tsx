import * as React from 'react';
import { setLocale } from 'react-redux-i18n';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { IRootState } from '../redux';
import './LanguageSelection.css';


export interface ILanguageSelectionProps {
    setLocale: (locale: string) => Dispatch;
}

class LanguageSelection extends React.Component<ILanguageSelectionProps, any>{

    constructor(props: any) {
        super(props);
    }

    public onClickGerman() {
        this.props.setLocale('de');
    }

    public onClickEnglish() {
        this.props.setLocale('en');
    }

    public render() {
        return (
            <div className="langSelection">
                <button onClick={() => { this.onClickGerman(); }}>
                    <div>
                        <span> DE </span>
                    </div>
                </button>
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <span> EN </span>
                    </div>
                </button>
            </div>
        );
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, { setLocale })(LanguageSelection)