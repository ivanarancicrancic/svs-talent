package com.nebiz.authorizationUsers.service;

import com.nebiz.authorizationUsers.model.*;
import com.nebiz.authorizationUsers.repository.RoleRepository;
import com.nebiz.authorizationUsers.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("userService")
@Component
public class UserServiceImpl implements UserService{

    @Autowired
    UserRepository user_repository;

    @Autowired
    RoleRepository role_repository;

//    @Autowired
//    RoleRepository role_repository;

    public List<UserReturn> getAllUsers(){
        //String result="";
//     user_repository.findAll();
//        for(User user : user_repository.findAll()) {
//                result = result + user.toString() + "*";
//        }
//        System.out.println(result);
//        List<User> users = new ArrayList<User>();
//        users =  user_repository.findAll();
//           String result = "";
//        for(User user : user_repository.findAll()) {
//                result = result + user.toString() + "*";
//        }
//        return result;
        List<User> users = new ArrayList<User>();
        users =  user_repository.findAll();
        List<UserReturn> returnUsers = new ArrayList<UserReturn>();
        for(User user : users) {

            UserReturn userReturn = new UserReturn(user.getId(), user.getCountry_code(), user.getUsername(), user.getEmail(),
                    user.isGender(), user.getFirstName(), user.getLastName(), user.getMDBID(), user.getDeactivated(), user.getKey_user_createuser(),
                    user.getCreate_datetime(), user.getKey_user_updateuser(), user.getUpdate_datetime());
            returnUsers.add(userReturn);
            // result = result + role.toString() + "*";
        }
        return returnUsers;


    }

    public UserReturn getUserByID(int id){

        User user = user_repository.findById(id);
        UserReturn userReturn = new UserReturn(user.getId(), user.getCountry_code(), user.getUsername(), user.getEmail(),
                user.isGender(), user.getFirstName(), user.getLastName(), user.getMDBID(), user.getDeactivated(), user.getKey_user_createuser(),
                user.getCreate_datetime(), user.getKey_user_updateuser(), user.getUpdate_datetime());
        return userReturn;

    }

    public void createUser(UserReturn user){

        User user1 = new User(user.getCountry_code(), user.getUsername(), user.getEmail(),
                user.getGender(), user.getFirst_name(), user.getLast_name(), user.getMdbid(), user.getDeactivated(), user.getKey_user_createuser(),
                user.getCreate_datetime(), user.getKey_user_updateuser(), user.getUpdate_datetime());
        user_repository.save(user1);
        }

    public void addRoleToUser(int role_id, int user_id){
        List<User> users = new ArrayList<User>();
        users =  user_repository.findAll();
        for(User user : users){
            if(user.getId() == user_id)
            {
                Role role = role_repository.getOne(role_id);
                List<Role> user_roles = user.getRoles();
                user_roles.add(role);
                user.setRoles(user_roles);
                user_repository.save(user);
            }
        }
    }

    public void removeRoleFromUser(int role_id, int user_id){
        List<User> users = new ArrayList<User>();
        users =  user_repository.findAll();
        for(User user : users){
            if(user.getId() == user_id)
            {
                Role role = role_repository.getOne(role_id);
                List<Role> user_roles = user.getRoles();
                user_roles.remove(role);
                user.setRoles(user_roles);
                user_repository.save(user);
            }
        }
    }


}
