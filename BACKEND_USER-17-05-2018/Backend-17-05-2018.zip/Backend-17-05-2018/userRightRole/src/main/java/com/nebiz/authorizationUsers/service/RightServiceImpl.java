package com.nebiz.authorizationUsers.service;

import com.nebiz.authorizationUsers.model.Rights;
import com.nebiz.authorizationUsers.model.RightsReturn;
import com.nebiz.authorizationUsers.model.Role;
import com.nebiz.authorizationUsers.repository.RightRepository;
import com.nebiz.authorizationUsers.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("rightService")
@Component
public class RightServiceImpl implements RightService {

    @Autowired
    RightRepository right_repository;

    @Autowired
    RoleRepository role_repository;

    public List<RightsReturn> getAllRights(){
        List<Rights> roles = new ArrayList<Rights>();

        //  List<User> users = new ArrayList<User>();
        roles =  right_repository.findAll();

      //  String result = "";
        List<RightsReturn> rights_return = new ArrayList<RightsReturn>();
        for(Rights right : right_repository.findAll()) {
            RightsReturn right_return = new RightsReturn(right.getId(), right.getRight_name(), right.getDescription());
            rights_return.add(right_return);
        }

        return rights_return;

    }

    public List<RightsReturn> getRightsForRole(int id){
        List<RightsReturn> rights_return = new ArrayList<RightsReturn>();
        System.out.println("Required role id: " + id);
        System.out.println("Listed Role ids: ");

        for(Role role : role_repository.findAll()) {
            System.out.println("Role id: " + role.getId());

            if(role.getId() == id)
           {
               System.out.println("Entered if!!! ==id");
               for (Rights right: role.getRights())
               {
                   RightsReturn right_return = new RightsReturn(right.getId(), right.getRight_name(), right.getDescription());
                   System.out.println("Adding Right to return: "  + right_return.getRight_name());
                   rights_return.add(right_return);
               }
               break;
           }
        }

        System.out.println("Returned rights: ");
        for (RightsReturn right23: rights_return){
            System.out.println(right23.getRight_name());

        }

        return rights_return;
    }

    public List<RightsReturn> getRightByID(int id){
        List<RightsReturn> list = new ArrayList<RightsReturn>();
         Rights right = right_repository.findById(id);
         RightsReturn rightsReturn = new RightsReturn(right.getId(), right.getRight_name(), right.getDescription());
         list.add(rightsReturn);
         return list;
    }

    public void createRight(RightsReturn rightsReturn){
        Rights right = new Rights(rightsReturn.getRight_name(), rightsReturn.getDescription());
        right_repository.save(right);
    }



}
