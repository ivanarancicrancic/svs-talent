package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class CampaignService {

    private final CampaignRepository campaignRepository;
    private final CampaignRuntimeService campaignRuntimeService;

    public CampaignService(CampaignRepository campaignRepository, CampaignRuntimeService campaignRuntimeService) {
        this.campaignRepository = campaignRepository;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    public List<Campaign> getCampaignsForUser(User user) {
        return campaignRepository.findByUser(user).collect(Collectors.toList());
    }

    public Optional<Campaign> getCampaign(long id) {
        return this.campaignRepository.findById(id);
    }


    public Campaign createCampaignForUser(CreateCampaignModel createCampaignModel, User user) throws NoRuntimePackageAvailableException {
        PackageBuy availablePackage = campaignRuntimeService.userHasPackageAvailable(user, createCampaignModel.getPackageId());

        if(availablePackage == null) {
            throw new NoRuntimePackageAvailableException();
        }

        Campaign campaign = new Campaign();
        campaign.setUser(user);
        campaign.setName("Campaign Name");
        campaign.setDescription("Campaign Description");
        campaign = this.campaignRepository.save(campaign);

        campaignRuntimeService.createRuntime(campaign, availablePackage);

        return campaign;
    }

    public Campaign editCampaign(Campaign campaign, EditCampaignModel editCampaignModel) {
        campaign.setName(editCampaignModel.getName());
        campaign.setDescription(editCampaignModel.getDescription());
        return this.campaignRepository.save(campaign);
    }

}
