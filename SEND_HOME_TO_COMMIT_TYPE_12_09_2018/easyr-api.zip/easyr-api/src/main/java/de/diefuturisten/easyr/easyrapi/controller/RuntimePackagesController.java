package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.CouponNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoMoneyException;
import de.diefuturisten.easyr.easyrapi.exceptions.RuntimePackageNotFoundException;
import de.diefuturisten.easyr.easyrapi.model.request.BuyPackageRequestModel;
import de.diefuturisten.easyr.easyrapi.model.response.RuntimePackageModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api")
public class RuntimePackagesController {

    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;

    public RuntimePackagesController(AuthenticationFacade authenticationFacade, CampaignRuntimeService campaignRuntimeService) {
        this.authenticationFacade = authenticationFacade;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    @GetMapping("/packages")
    @ResponseStatus(HttpStatus.OK)
    public Stream<RuntimePackageModel> getAllCampaignsForUser() {
        return campaignRuntimeService.getAllPackages().stream()
                .map(RuntimePackageModel::new);
    }

    @GetMapping("/packages/own")
    @ResponseStatus(HttpStatus.OK)
    public UserPackagesModel getUserPackages() {
        User user = authenticationFacade.getAuthenticatedUser();
        return campaignRuntimeService.getPackagesForUser(user);
    }

    @PostMapping("/package/buy")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity buyPackage(@Valid @RequestBody BuyPackageRequestModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        try {
            PackageBuy boughtPackage = campaignRuntimeService.buyPackage(user, model);
        } catch (CouponNotFoundException e) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        } catch (NoMoneyException e) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        } catch (RuntimePackageNotFoundException e) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

        return new ResponseEntity(HttpStatus.OK);
    }

}
