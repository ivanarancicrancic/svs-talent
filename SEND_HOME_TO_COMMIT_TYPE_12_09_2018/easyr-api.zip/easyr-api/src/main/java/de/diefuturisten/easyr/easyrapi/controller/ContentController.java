package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.model.response.AudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.response.WebviewContentModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.ContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.model.response.MovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.response.PanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.response.UnityContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.response.SlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.response.SlideshowImageModel;

import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;

@RestController
@RequestMapping("/api")
public class ContentController {

    @Autowired
    private AuthenticationFacade authenticationFacade;

    @Autowired
    private final ContentService contentService;

    @Autowired
    private final CampaignService campaignService;

    @Autowired
    private final SlideshowImageService slideshowImageService;


    public ContentController(AuthenticationFacade authenticationFacade, ContentService contentService, CampaignService campaignService, SlideshowImageService slideshowImageService) {
        this.authenticationFacade = authenticationFacade;
        this.contentService = contentService;
        this.campaignService = campaignService;
        this.slideshowImageService = slideshowImageService;
    }

    @DeleteMapping("/campaign/content/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteContent(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        contentService.deleteContent(content);
    }

    @PutMapping("/campaign/content/{contentId}/up")
    @ResponseStatus(HttpStatus.OK)
    public boolean moveContentUp(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return contentService.moveUp(content);
    }

    @PutMapping("/campaign/content/{contentId}/down")
    @ResponseStatus(HttpStatus.OK)
    public boolean moveContentDown(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return contentService.moveDown(content);
    }

    @PostMapping("/campaign/{campaignId}/webview")
    @ResponseStatus(HttpStatus.OK)
    public WebviewContentModel createWebviewContent(@PathVariable long campaignId, @Valid @RequestBody CreateWebviewContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        WebviewContent webviewContent = contentService.createWebviewContent(campaign, model);
        return new WebviewContentModel(webviewContent);
    }

    @PutMapping("/campaign/webview/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public WebviewContentModel editWebviewContent(@PathVariable long contentId, @Valid @RequestBody CreateWebviewContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        WebviewContent content = contentService.<WebviewContent>getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        WebviewContent webviewContent = contentService.editWebviewContent(content, model);
        return new WebviewContentModel(webviewContent);
    }

    @PostMapping("/campaign/{campaignId}/audio")
    @ResponseStatus(HttpStatus.OK)
    public AudioContentModel createAudioContent(@PathVariable long campaignId, @Valid @RequestBody CreateAudioContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        AudioContent content = contentService.createAudioContent(campaign, model);
        return new AudioContentModel(content);
    }

    @PutMapping("/campaign/audio/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public AudioContentModel editAudioContent(@PathVariable long contentId, @Valid @RequestBody CreateAudioContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        AudioContent content = contentService.<AudioContent>getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        AudioContent editedContent = contentService.editAudioContent(content, model);
        return new AudioContentModel(editedContent);
    }

    @PostMapping("/campaign/{campaignId}/movie")
    @ResponseStatus(HttpStatus.OK)
    public MovieContentModel createMovieContent(@PathVariable long campaignId, @RequestBody CreateMovieContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        MovieContent content = contentService.createMovieContent(campaign, model);
        return new MovieContentModel(content);
    }


    @PostMapping("/campaign/{campaignId}/panorama")
    @ResponseStatus(HttpStatus.OK)
    public PanoramaContentModel createPanoramaContent(@PathVariable long campaignId, @RequestBody CreatePanoramaContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        PanoramaContent content = contentService.createPanoramaContent(campaign, model);
        return new PanoramaContentModel(content);
    }

    @PostMapping("/campaign/{campaignId}/unityContent")
    @ResponseStatus(HttpStatus.OK)
    public UnityContentModel createUnityContent(@PathVariable long campaignId, @RequestBody CreateUnityContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        UnityContent content = contentService.createUnityContent(campaign, model);
        return new UnityContentModel(content);
    }


    @PostMapping("/campaign/{campaignId}/slideshowContent")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowContentModel createSlideshowContent(@PathVariable long campaignId, @RequestBody CreateSlideshowContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        SlideshowContent content = contentService.createSlideshowContent(campaign, model);
        return new SlideshowContentModel(content);
    }


    @PostMapping("/slideshow/{slideshowId}")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowImageModel createImageToSlideshowContent(@PathVariable long slideshowId, @RequestBody CreateSlideshowImageModel model) {

        SlideshowImage image = contentService.createSlideshowImage(slideshowId, model);

        return new SlideshowImageModel(image);
    }

    @DeleteMapping("/slideshowimage/{imageId}")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowImageModel deleteImageFromSlideshowContent(@PathVariable long imageId) {

        SlideshowImage image = contentService.deleteSlideshowImage(imageId);

        return new SlideshowImageModel(image);
    }


    @PutMapping("/campaign/movie/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public MovieContentModel editMovieContent(@PathVariable long contentId, @Valid @RequestBody EditMovieContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        MovieContent content = contentService.<MovieContent>getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        MovieContent editedContent = contentService.editMovieContent(content, model);
        return new MovieContentModel(editedContent);
    }


    @PutMapping("/campaign/panorama/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public PanoramaContentModel editPanoramaContent(@PathVariable long contentId, @Valid @RequestBody EditPanoramaContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        PanoramaContent content = contentService.<PanoramaContent>getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        PanoramaContent editedContent = contentService.editPanoramaContent(content, model);
        return new PanoramaContentModel(editedContent);
    }



    @PutMapping("/campaign/unity/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public UnityContentModel editUnityContent(@PathVariable long contentId, @Valid @RequestBody EditUnityContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        UnityContent content = contentService.<UnityContent>getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        UnityContent editedContent = contentService.editUnityContent(content, model);
        return new UnityContentModel(editedContent);
    }



    @PutMapping("/campaign/slideshow/{contentId}")
    @ResponseStatus(HttpStatus.OK)
    public SlideshowContentModel editSlideshowContent(@PathVariable long contentId, @Valid @RequestBody EditSlideshowContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        SlideshowContent content = contentService.<SlideshowContent>getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        SlideshowContent editedContent = contentService.editSlideshowContent(content, model);
        return new SlideshowContentModel(editedContent);
    }

    @PutMapping("/slideshow/image/{imageId}/up")
    @ResponseStatus(HttpStatus.OK)
    public boolean moveImageUp(@PathVariable long imageId) {
        User user = authenticationFacade.getAuthenticatedUser();
        SlideshowImage image = slideshowImageService.getById(imageId).orElseThrow(ForbiddenException::new);

        return slideshowImageService.moveUp(image);
    }

    @PutMapping("/slideshow/image/{imageId}/down")
    @ResponseStatus(HttpStatus.OK)
    public boolean moveImageDown(@PathVariable long imageId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(imageId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return contentService.moveDown(content);
    }

}