package de.diefuturisten.easyr.easyrapi.unittest;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import de.diefuturisten.easyr.easyrapi.controller.AccountController;
import de.diefuturisten.easyr.easyrapi.service.CaptchaService;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.model.response.CaptchaResponseModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordResetModel;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;

public class AccountControllerTest {
    private MockMvc mockMvc;
    private CaptchaService captchaService;
    private UserService userService;
    private AccountController accountController;
    private User user;
    private ObjectMapper mapper;

    @Before
    public void setUp(){
        captchaService = mock(CaptchaService.class);
        userService = mock(UserService.class);
        user = mock(User.class);
        accountController =new AccountController(userService, captchaService);
        mockMvc = MockMvcBuilders.standaloneSetup(accountController).build();
        mapper= new ObjectMapper();
    }


    @Test
    public void createAccount_Approved() throws Exception {
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1");
        captchaResponseModel.setAnswer("sth as answer");

        CreateAccountModel createAccountModel = new CreateAccountModel();
        createAccountModel.setFirstName("Anna");
        createAccountModel.setLastName("Jonson");
        createAccountModel.setEmail("ana.jonson@app-logik.de");
        createAccountModel.setCaptcha(captchaResponseModel);
        createAccountModel.setGender(true);
        createAccountModel.setLanguage("de");
        createAccountModel.setPassword("probepassword123");

        Mockito.when(captchaService.verifyCaptcha(Mockito.any(CaptchaResponseModel.class))).thenReturn(true);
        Mockito.when(userService.create(Mockito.any(CreateAccountModel.class))).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/register")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAccountModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }


    @Test
    public void createAccount_notApprroved() throws Exception {
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1");
        captchaResponseModel.setAnswer("sth as answer");

        CreateAccountModel createAccountModel = new CreateAccountModel();
        createAccountModel.setFirstName("Anna");
        createAccountModel.setLastName("Jonson");
        createAccountModel.setEmail("ana.jonson@app-logik.de");
        createAccountModel.setCaptcha(captchaResponseModel);
        createAccountModel.setGender(true);
        createAccountModel.setLanguage("de");
        createAccountModel.setPassword("probepassword123");

        Mockito.when(captchaService.verifyCaptcha(Mockito.any(CaptchaResponseModel.class))).thenReturn(false);
        Mockito.when(userService.create(Mockito.any(CreateAccountModel.class))).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/register")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAccountModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void forgotPassword() throws Exception {
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1");
        captchaResponseModel.setAnswer("sth as answer");

        ForgotPasswordModel forgotPasswordModel = new ForgotPasswordModel();
        forgotPasswordModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordModel.setCaptcha(captchaResponseModel);

        Mockito.when(captchaService.verifyCaptcha(Mockito.any(CaptchaResponseModel.class))).thenReturn(true);
        doNothing().when(userService).forgotPassword(Mockito.any(ForgotPasswordModel.class));

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/forgotpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());//
    }

    @Test
    public void forgotPassword_NotApproved()  throws Exception {
        CaptchaResponseModel captchaResponseModel = new CaptchaResponseModel();
        captchaResponseModel.setId("1");
        captchaResponseModel.setAnswer("sth as answer");

        ForgotPasswordModel forgotPasswordModel = new ForgotPasswordModel();
        forgotPasswordModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordModel.setCaptcha(captchaResponseModel);

        Mockito.when(captchaService.verifyCaptcha(Mockito.any(CaptchaResponseModel.class))).thenReturn(false);
        doNothing().when(userService).forgotPassword(Mockito.any(ForgotPasswordModel.class));

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/forgotpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());//
    }


    @Test
    public void resetPasswordRequest()  throws Exception {
        ForgotPasswordResetModel forgotPasswordResetModel = new ForgotPasswordResetModel();
        forgotPasswordResetModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordResetModel.setNewPassword("newPassword123");
        forgotPasswordResetModel.setToken("573897593FFS4");

        Mockito.when(userService.getUserByUsername(Mockito.anyString())).thenReturn(user);
        Mockito.when(userService.resetPassword(Mockito.any(User.class), Mockito.anyString(), Mockito.anyString())).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resetpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordResetModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());//
    }

    @Test
    public void resetPasswordRequest_CheckFalse()  throws Exception {
        ForgotPasswordResetModel forgotPasswordResetModel = new ForgotPasswordResetModel();
        forgotPasswordResetModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordResetModel.setNewPassword("newPassword123");
        forgotPasswordResetModel.setToken("573897593FFS4");

        Mockito.when(userService.getUserByUsername(Mockito.anyString())).thenReturn(user);
        Mockito.when(userService.resetPassword(Mockito.any(User.class), Mockito.anyString(), Mockito.anyString())).thenReturn(false);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resetpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordResetModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());//
    }

    @Test
    public void resetPasswordRequest_NoSuchElement()  throws Exception {
        ForgotPasswordResetModel forgotPasswordResetModel = new ForgotPasswordResetModel();
        forgotPasswordResetModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordResetModel.setNewPassword("newPassword123");
        forgotPasswordResetModel.setToken("573897593FFS4");

        Mockito.when(userService.getUserByUsername(Mockito.anyString())).thenReturn(null);
        Mockito.when(userService.resetPassword(Mockito.any(User.class), Mockito.anyString(), Mockito.anyString())).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resetpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordResetModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());//
    }


    @Test
    public void resetPasswordRequest_CannotSendException() throws Exception {
        ForgotPasswordResetModel forgotPasswordResetModel = new ForgotPasswordResetModel();
        forgotPasswordResetModel.setEmail("ana.jonson@app-logik.de");
        forgotPasswordResetModel.setNewPassword("newPassword123");
        forgotPasswordResetModel.setToken("573897593FFS4");

        Mockito.when(userService.getUserByUsername(Mockito.anyString())).thenReturn(user);
        doThrow(new CannotSendEmailException()).when(userService).resetPassword(Mockito.any(User.class), Mockito.anyString(), Mockito.anyString());

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/resetpw")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(forgotPasswordResetModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());//
    }
}
