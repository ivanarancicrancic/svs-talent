package de.diefuturisten.easyr.easyrapi;

import com.google.common.util.concurrent.SettableFuture;
import de.diefuturisten.easyr.easyrapi.exceptions.InvalidTrackerImageException;
import de.diefuturisten.easyr.easyrapi.service.VuforiaService;
import de.diefuturisten.easyr.easyrapi.vuforia.IPostNewTargetStatusListener;
import de.diefuturisten.easyr.easyrapi.vuforia.IPostNewTargetStatusListenerImpl;
import de.diefuturisten.easyr.easyrapi.vuforia.PostNewTarget;
import org.junit.Before;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import java.io.File;
import java.io.IOException;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * TODO this need to be tuned a bit, as we are having async processing steps
 */
public class VuforiaServiceTest {

    private VuforiaService vuforiaService;

    @Before
    public void setup() {
        vuforiaService = new VuforiaService(
                "https://vws.vuforia.com",
                "87b38ef0226d1aceb23ffe3da79760e620f1948b",
                "132d7389c8cc29ca2a5fb31bee76719ed7e3f7a3"
        );
    }

    @Test
    public void summary_test() {
        assertThat(vuforiaService.getSummary()).isNotNull();
    }

    @Test
    public void getalltargets_test() {
        assertThat(vuforiaService.getAllTargets()).isNotNull();
    }

    @Test
    public void gettarget_test() {
        assertThat(vuforiaService.getTarget("75bd88b428784333a0a1015dd7a4eeb8")).isNotNull();
    }

    @Test
    public void posttarget_test() throws IOException, InvalidTrackerImageException {
        Resource resource = new ClassPathResource("images/test_tracker.jpg");
        File file = resource.getFile();

        String targetId = vuforiaService.postTarget(UUID.randomUUID().toString(), file, null);
        assertThat(targetId).isNotNull();
    }

    private Future<String> postFuture(File file) throws InvalidTrackerImageException {
        final SettableFuture<String> future = SettableFuture.create();
        String targetId = vuforiaService.postTarget(UUID.randomUUID().toString(), file, new IPostNewTargetStatusListener() {
            @Override
            public void onStatusSuccess(String targetId) {
                future.set(targetId);
            }
        });
        return future;
    }

    @Test
    public void updatetarget_test() throws IOException, InterruptedException, ExecutionException, TimeoutException, InvalidTrackerImageException {
        Resource resource = new ClassPathResource("images/test_tracker.jpg");
        File file = resource.getFile();

        String targetId = postFuture(file).get(2, TimeUnit.MINUTES);

        Resource resource_update = new ClassPathResource("images/test_tracker2.jpg");
        File file_update = resource_update.getFile();

        assertThat(
                vuforiaService.updateTarget(targetId, file_update)
        ).isNotNull();
    }

    @Test
    public void deletetarget_test() throws IOException, InterruptedException, ExecutionException, TimeoutException, InvalidTrackerImageException {
        Resource resource = new ClassPathResource("images/test_tracker.jpg");
        File file = resource.getFile();

        String targetId = postFuture(file).get(2, TimeUnit.MINUTES);

        assertThat(
                vuforiaService.deleteTarget(targetId)
        ).isNotNull();
    }

}
