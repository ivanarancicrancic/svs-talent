package de.diefuturisten.easyr.easyrapi.unittest;

import de.diefuturisten.easyr.easyrapi.controller.AdminController;
import org.springframework.test.web.servlet.MockMvc;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.service.AdminService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.Test;
import java.util.List;
import java.util.ArrayList;
import org.mockito.Mockito;
import static org.junit.Assert.assertEquals;
import org.springframework.test.web.servlet.RequestBuilder;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import java.util.Optional;

public class AdminControllerTest {
    private MockMvc mockMvc;
    private User user;
    private User user1;
    private Campaign campaign;
    private Campaign campaign1;
    private AdminService adminService;
    private CampaignService campaignService;
    private CampaignRuntimeService campaignRuntimeService;
    private AdminController adminController;
    private ObjectMapper mapper;
    private RuntimePackage runtimePackage;
    private Coupon coupon;

    @Before
    public void setUp(){
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        campaignService = mock(CampaignService.class);
        adminService = mock(AdminService.class);
        user = mock(User.class);
        user1 = mock(User.class);
        campaign = mock(Campaign.class);
        campaign1 = mock(Campaign.class);
        coupon = mock(Coupon.class);
        runtimePackage = mock(RuntimePackage.class);
        adminController =new AdminController(adminService, campaignService, campaignRuntimeService);
        mockMvc = MockMvcBuilders.standaloneSetup(adminController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void listUsers() throws Exception{
        List<User> userList = new ArrayList<>();
        userList.add(user);
        userList.add(user1);

        Mockito.when(adminService.getAllUsers()).thenReturn(userList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/api/admin/users")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void listAllCampaigns() throws Exception{
        List<Campaign> campaignList = new java.util.ArrayList<>();
        campaignList.add(campaign);
        campaignList.add(campaign1);

        Mockito.when(campaignService.findAllCampaigns()).thenReturn(campaignList);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/api/admin/campaigns")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
        }

    @Test
    public void listCampaignsForUser() throws Exception {
        List<Campaign> campaignList = new ArrayList<>();
        campaignList.add(campaign);
        campaignList.add(campaign1);

        Mockito.when(adminService.getUserByID(Mockito.anyLong())).thenReturn(java.util.Optional.of(user));
        Mockito.when(campaignService.getCampaignsForUser(user)).thenReturn(campaignList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/api/admin/campaigns/" + 1)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test(expected = Exception.class)
    public void listCampaignsForUser_NoUser() throws Exception {
        List<Campaign> campaignList = new ArrayList<>();
        campaignList.add(campaign);
        campaignList.add(campaign1);

        Mockito.when(adminService.getUserByID(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(campaignService.getCampaignsForUser(user)).thenReturn(campaignList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/api/admin/campaigns/" + 1)
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), response.getStatus());
    }

    @Test
    public void createCouponForGivenUserAndPackage() throws Exception {
        CreateCouponAdminModel createCouponAdminModel = new CreateCouponAdminModel();
        createCouponAdminModel.setUserId(1L);
        createCouponAdminModel.setPackageId(2L);
        createCouponAdminModel.setPercentage(20.8);

        Mockito.when(campaignRuntimeService.createCoupon(Mockito.any(CreateCouponAdminModel.class))).thenReturn(coupon);

        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/admin/coupon")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createCouponAdminModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }
}
