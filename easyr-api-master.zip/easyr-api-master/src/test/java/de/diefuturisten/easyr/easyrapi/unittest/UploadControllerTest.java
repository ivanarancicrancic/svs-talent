package de.diefuturisten.easyr.easyrapi.unittest;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import de.diefuturisten.easyr.easyrapi.service.S3Service;
import de.diefuturisten.easyr.easyrapi.controller.UploadController;
import de.diefuturisten.easyr.easyrapi.model.request.SignedUploadURLResponse;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import java.net.URL;

public class UploadControllerTest {
    private MockMvc mockMvc;
    private S3Service s3Service;
    private UploadController uploadController;
    private AuthenticationFacade authenticationFacade;

    @Before
    public void setUp(){
        s3Service = mock(S3Service.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        uploadController =new UploadController(s3Service, authenticationFacade);
        mockMvc = MockMvcBuilders.standaloneSetup(uploadController).build();
    }

    @Test
    public void getSignedUploadURL() throws Exception {
        URL url = new URL("http://example.com");

        Mockito.when(s3Service.signUploadRequest(Mockito.any(), Mockito.any())).thenReturn(url);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/s3/sign/").param("objectName", "movie").param("contentType", "SPHERE").param("path", "http://example.com")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }
}
