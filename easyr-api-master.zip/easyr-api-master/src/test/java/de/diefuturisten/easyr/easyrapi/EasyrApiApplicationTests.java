package de.diefuturisten.easyr.easyrapi;

import org.junit.Test;

public class EasyrApiApplicationTests {

    @Test
    public void nothing() {
    }

}
