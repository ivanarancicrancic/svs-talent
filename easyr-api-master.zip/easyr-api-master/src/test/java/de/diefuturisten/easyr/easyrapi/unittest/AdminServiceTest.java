package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.service.AdminService;

public class AdminServiceTest {
    private User user;
    private User user1;
    private UserService userService;
    private AdminService adminService;

    @Before
    public void setUp() {
        user = mock(User.class);
        user1 = mock(User.class);
        userService = mock(UserService.class);
        adminService = new de.diefuturisten.easyr.easyrapi.service.AdminService(userService);
    }

    @Test
    public void getAllUsers(){
        java.util.List<de.diefuturisten.easyr.easyrapi.entity.user.User> userList = new java.util.ArrayList<>();
        userList.add(user);
        userList.add(user1);
        Mockito.when(userService.getAllUser()).thenReturn(userList);
        assertNotNull(adminService.getAllUsers());
    }

    @Test
    public void getUserByID(){
        Mockito.when(userService.getUserByUserId(Mockito.anyLong())).thenReturn(Optional.of(user));
        assertNotNull(adminService.getUserByID(1L));
    }
}
