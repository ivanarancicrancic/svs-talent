package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.service.UnityContentService;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;

public class UnityContentServiceTest {
    private Content content;
    private Campaign campaign;
    private ContentRepository contentRepository;
    private UnityContentService unityContentService;
    private UnityContent unityContent;

    @Before
    public void setUp() {
        campaign = mock(Campaign.class);
        contentRepository = mock(ContentRepository.class);
        content = mock(Content.class);
        unityContent = mock(UnityContent.class);
        unityContentService = new UnityContentService(contentRepository);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("unit name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("NORMAL");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(de.diefuturisten.easyr.easyrapi.entity.content.UnityContent.class))).thenReturn(unityContent);
        assertNotNull(unityContentService.create(campaign, createUnityContentModel));
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("unit name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("NORMAL");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(UnityContent.class))).thenReturn(unityContent);
        assertNotNull(unityContentService.create(campaign, createUnityContentModel));
    }

    @Test
    public void edit() {
        EditUnityContentModel editUnityContentModel = new EditUnityContentModel();
        editUnityContentModel.setName("unit name");
        editUnityContentModel.setWeight(1);
        editUnityContentModel.setType("NORMAL");
        editUnityContentModel.setRenderOnTrackingLost(true);
        editUnityContentModel.setExtendedTracking(false);
        editUnityContentModel.setScaleX(1);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleZ(2);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setRotationX(1);
        editUnityContentModel.setRotationY(2);
        editUnityContentModel.setRotationZ(2);
        editUnityContentModel.setPositionX(2);
        editUnityContentModel.setPositionY(3);
        editUnityContentModel.setPositionZ(3);
        editUnityContentModel.setAndroidUrl("sthUrl android");
        editUnityContentModel.setIosUrl("sthUrl ios");

        Mockito.when(contentRepository.save(Mockito.any(UnityContent.class))).thenReturn(unityContent);
        assertNotNull(unityContentService.edit(unityContent, editUnityContentModel));
    }

}
