package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.service.MoreinfoContentService;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMoreinfoContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;

public class MoreinfoContentServiceTest {

    private ContentRepository contentRepository;
    private Campaign campaign;
    private Content content;
    private MoreinfoContentService moreinfoContentService;
    private MoreInfoContent moreInfoContent;

    @Before
    public void setUp() {
        contentRepository = mock(ContentRepository.class);
        campaign = mock(Campaign.class);
        content = mock(Content.class);
        moreInfoContent = mock(de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent.class);
        moreinfoContentService = new MoreinfoContentService(contentRepository);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreateMoreinfoContentModel contentModel = new CreateMoreinfoContentModel();
        contentModel.setId(1L);
        contentModel.setWeight(1);
        contentModel.setName("name");
        contentModel.setType("NORMAL");
        contentModel.setUrl("url");

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(MoreInfoContent.class))).thenReturn(moreInfoContent);

        moreinfoContentService.create(campaign, contentModel);
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreateMoreinfoContentModel contentModel = new CreateMoreinfoContentModel();
        contentModel.setId(1L);
        contentModel.setWeight(1);
        contentModel.setName("name");
        contentModel.setType("NORMAL");
        contentModel.setUrl("url");

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(MoreInfoContent.class))).thenReturn(moreInfoContent);

        moreinfoContentService.create(campaign, contentModel);
    }

    @Test
    public void edit(){
        CreateMoreinfoContentModel contentModel = new CreateMoreinfoContentModel();
        contentModel.setId(1L);
        contentModel.setWeight(1);
        contentModel.setName("name");
        contentModel.setType("NORMAL");
        contentModel.setUrl("url");

        Mockito.when(contentRepository.save(Mockito.any(MoreInfoContent.class))).thenReturn(moreInfoContent);

        moreinfoContentService.edit(moreInfoContent, contentModel);
    }

}
