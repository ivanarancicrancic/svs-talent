package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;

public class PanoramaContentServiceTest {
    private ContentRepository contentRepository;
    private Campaign campaign;
    private Content content;
    private PanoramaContentService panoramaContentService;
    private PanoramaContent panoramaContent;

    @Before
    public void setUp() {
        contentRepository = mock(ContentRepository.class);
        campaign = mock(Campaign.class);
        content = mock(Content.class);
        panoramaContent = mock(PanoramaContent.class);
        panoramaContentService = new PanoramaContentService(contentRepository);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("blahsth");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        org.mockito.Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(Optional.of(content));
        org.mockito.Mockito.when(contentRepository.save(org.mockito.Mockito.any(PanoramaContent.class))).thenReturn(panoramaContent);

        assertNotNull(panoramaContentService.create(campaign, createPanoramaContentModel));
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("blahsth");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        org.mockito.Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(Optional.empty());
        org.mockito.Mockito.when(contentRepository.save(Mockito.any(PanoramaContent.class))).thenReturn(panoramaContent);

        assertNotNull(panoramaContentService.create(campaign, createPanoramaContentModel));
    }
    @Test
    public void edit(){
        EditPanoramaContentModel editPanoramaContentModel = new EditPanoramaContentModel();
        editPanoramaContentModel.setUrl("blahsth");
        editPanoramaContentModel.setName("newMovie name");
        editPanoramaContentModel.setWeight(1);
        editPanoramaContentModel.setType("type");
        editPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(contentRepository.save(Mockito.any(PanoramaContent.class))).thenReturn(panoramaContent);
        assertNotNull(panoramaContentService.edit(panoramaContent, editPanoramaContentModel));

    }

}
