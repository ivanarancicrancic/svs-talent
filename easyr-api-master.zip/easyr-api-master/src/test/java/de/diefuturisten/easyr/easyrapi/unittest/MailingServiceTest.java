package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import it.ozimov.springboot.mail.service.EmailService;
import de.diefuturisten.easyr.easyrapi.service.MessageByLocaleService;
import de.diefuturisten.easyr.easyrapi.service.MailingService;
import it.ozimov.springboot.mail.model.Email;
import java.util.Locale;
import java.util.Map;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import javax.mail.internet.MimeMessage;

public class MailingServiceTest {

    private User user;
    private EmailService emailService;
    private MessageByLocaleService messageLocalService;
    private MailingService mailingService;
    private MimeMessage mimeMessage;
    private String frontendUrl = "http://example.com/";

    @Before
    public void setUp() {
        user = mock(User.class);
        emailService = mock(EmailService.class);
        messageLocalService = mock(MessageByLocaleService.class);
        mimeMessage = mock(MimeMessage.class);
        mailingService = new MailingService(emailService, messageLocalService);
    }

    @Test
    public void sendTemplateEmail()throws CannotSendEmailException{

            Mockito.when(emailService.send(Mockito.any(Email.class), Mockito.any(String.class), Mockito.any(Map.class))).thenReturn(mimeMessage);
            Map<String, Object> model = new java.util.HashMap<>();
            model.put("visibleName", user.getName());
            model.put("username", user.getEmail());
            model.put("loginurl", String.format("%s/", frontendUrl));
            mailingService.sendTemplateEmail("template", "name", "ivana.rancic@app-logik.de", "subjectExample", model);
    }

    @Test
    public void sendPasswordResetToken() throws CannotSendEmailException {

            Mockito.when(messageLocalService.getMessage(Mockito.anyString(), Mockito.any(Locale.class))).thenReturn("subjectExample");
            Mockito.when(emailService.send(Mockito.any(Email.class), Mockito.any(String.class), Mockito.any(Map.class))).thenReturn(mimeMessage);
            Locale locale = Locale.GERMAN;
            Mockito.when(user.getPreferedLanguage()).thenReturn(locale);
            Map<String, Object> map = new java.util.HashMap<>();
            map.put("attachment1", new Object());
            mailingService.sendPasswordResetToken(user, "7935787FBB93338GGB");
    }

    @Test
    public void sendNewPassword() throws CannotSendEmailException{

            Mockito.when(messageLocalService.getMessage(Mockito.anyString(), Mockito.any(Locale.class))).thenReturn("subjectExample");
            Mockito.when(emailService.send(Mockito.any(Email.class), Mockito.any(String.class), Mockito.any(Map.class))).thenReturn(mimeMessage);
            Locale locale = Locale.GERMAN;
            Mockito.when(user.getPreferedLanguage()).thenReturn(locale);
            mailingService.sendNewPassword(user);
    }

    @Test
    public void sendNewUserWelcome() throws CannotSendEmailException {

            Mockito.when(messageLocalService.getMessage(Mockito.anyString(), Mockito.any(Locale.class))).thenReturn("subjectExample");
            Mockito.when(emailService.send(Mockito.any(Email.class), Mockito.any(String.class), Mockito.any(Map.class))).thenReturn(mimeMessage);
            Locale locale = Locale.GERMAN;
            Mockito.when(user.getPreferedLanguage()).thenReturn(locale);
            mailingService.sendNewPassword(user);
    }
}
