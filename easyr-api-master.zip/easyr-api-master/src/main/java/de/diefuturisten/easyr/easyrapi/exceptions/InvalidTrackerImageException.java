package de.diefuturisten.easyr.easyrapi.exceptions;

public class InvalidTrackerImageException extends Throwable {
}
