package de.diefuturisten.easyr.easyrapi.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MobileTrackerResponse {

    private String targetID;
    private long campaignID;
    private long clientID;

    private String phone = "under construction";
    private String email = "under construction";
    private String web = "under construction";
    private String name = "under construction";
    private String street = "under construction";
    private String number = "under construction";
    private String address2 = "under construction";
    private String zip = "under construction";
    private String city = "under construction";
    private String company = "under construction";

    private boolean photo = false;

    private long smoothCamFramesPosition = 3;
    private long smoothCamFramesRotation = 4;

    private List<PanoramaResponse> panoramas = new ArrayList<>();
    private List<SlideshowResponse> slideshows = new ArrayList<>();
    private List<SlideshowResponse> wheels = new ArrayList<>();
    private List<WebviewResponse> webviews = new ArrayList<>();
    private List<UnityResponse> unityElements = new ArrayList<>();
    private List<AudioResponse> audios = new ArrayList<>();
    private List<MovieResponse> movies = new ArrayList<>();

    public MobileTrackerResponse() {

    }

    public MobileTrackerResponse(Tracker tracker) {
        Campaign campaign = tracker.getCampaign();

        this.setTargetID(tracker.getVuforiaId());
        this.setCampaignID(campaign.getId());
        this.setClientID(campaign.getUser().getId());

        campaign.getContents()
                .stream()
                .filter(x -> x instanceof MoreInfoContent)
                .findFirst().ifPresent( moreInfo -> {
                    String url = ((MoreInfoContent)moreInfo).getUrl();
                    if(url != null && url.length() > 0) {
                        this.web = url;
                    } else {
                        this.web = null;
                    }
                });

        this.setPanoramas(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof PanoramaContent)
                        .map( x -> new PanoramaResponse((PanoramaContent) x) )
                        .collect(Collectors.toList())
        );

        this.setSlideshows(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof SlideshowContent)
                        .filter(x -> ((SlideshowContent) x).getType().equals(SlideshowContent.Type.NORMAL))
                        .map( x -> new SlideshowResponse((SlideshowContent) x) )
                        .collect(Collectors.toList())
        );

        this.setWheels(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof SlideshowContent)
                        .filter(x -> ((SlideshowContent) x).getType().equals(SlideshowContent.Type.WHEEL))
                        .map( x -> new SlideshowResponse((SlideshowContent) x) )
                        .collect(Collectors.toList())
        );

        this.setWebviews(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof WebviewContent)
                        .map( x -> new WebviewResponse((WebviewContent) x) )
                        .collect(Collectors.toList())
        );

        this.setUnityElements(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof UnityContent)
                        .map( x -> new UnityResponse((UnityContent) x) )
                        .collect(Collectors.toList())
        );


        this.setAudios(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof AudioContent)
                        .map( x -> new AudioResponse((AudioContent) x) )
                        .collect(Collectors.toList())
        );

        this.setMovies(
                campaign.getContents()
                        .stream()
                        .filter(x -> x instanceof MovieContent)
                        .map( x -> new MovieResponse((MovieContent) x) )
                        .collect(Collectors.toList())
        );
    }

    public String getTargetID() {
        return targetID;
    }

    public void setTargetID(String targetID) {
        this.targetID = targetID;
    }

    public long getCampaignID() {
        return campaignID;
    }

    public void setCampaignID(long campaignID) {
        this.campaignID = campaignID;
    }

    public long getClientID() {
        return clientID;
    }

    public void setClientID(long clientID) {
        this.clientID = clientID;
    }

    public List<PanoramaResponse> getPanoramas() {
        return panoramas;
    }

    public void setPanoramas(List<PanoramaResponse> panoramas) {
        this.panoramas = panoramas;
    }

    public List<SlideshowResponse> getSlideshows() {
        return slideshows;
    }

    public void setSlideshows(List<SlideshowResponse> slideshows) {
        this.slideshows = slideshows;
    }

    public List<WebviewResponse> getWebviews() {
        return webviews;
    }

    public void setWebviews(List<WebviewResponse> webviews) {
        this.webviews = webviews;
    }

    public List<UnityResponse> getUnityElements() {
        return unityElements;
    }

    public void setUnityElements(List<UnityResponse> unityElements) {
        this.unityElements = unityElements;
    }

    public List<AudioResponse> getAudios() {
        return audios;
    }

    public void setAudios(List<AudioResponse> audios) {
        this.audios = audios;
    }

    public List<MovieResponse> getMovies() {
        return movies;
    }

    public void setMovies(List<MovieResponse> movies) {
        this.movies = movies;
    }

    public List<SlideshowResponse> getWheels() {
        return wheels;
    }

    public void setWheels(List<SlideshowResponse> wheels) {
        this.wheels = wheels;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public boolean isPhoto() {
        return photo;
    }

    public void setPhoto(boolean photo) {
        this.photo = photo;
    }

    public long getSmoothCamFramesPosition() {
        return smoothCamFramesPosition;
    }

    public void setSmoothCamFramesPosition(long smoothCamFramesPosition) {
        this.smoothCamFramesPosition = smoothCamFramesPosition;
    }

    public long getSmoothCamFramesRotation() {
        return smoothCamFramesRotation;
    }

    public void setSmoothCamFramesRotation(long smoothCamFramesRotation) {
        this.smoothCamFramesRotation = smoothCamFramesRotation;
    }

    public static class ContentResponse {

        private long contentID;
        private int weight;
        private String name;

        public ContentResponse(Content content) {
            this.contentID = content.getId();
            this.weight = content.getWeight();
            this.name = content.getName();
        }

        public long getContentID() {
            return contentID;
        }

        public void setContentID(long contentID) {
            this.contentID = contentID;
        }

        public int getWeight() {
            return weight;
        }

        public void setWeight(int weight) {
            this.weight = weight;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class PanoramaResponse extends ContentResponse {

        private String type;
        private String path;
        private boolean renderOnTrackingLost = true;
        private boolean extendedTracking = false;

        public PanoramaResponse(PanoramaContent panoramaContent) {
            super(panoramaContent);

            switch(panoramaContent.getType()) {
                case X180:
                    this.type = "180";
                    // this.setName("180° Panorama");
                    break;
                case X360:
                    this.type = "360";
                    // this.setName("360° Panorama");
                    break;
                case SPHERE:
                    this.type = "sphere";
                    // this.setName("Sphere Panorama");
                    break;
            }

            this.path = panoramaContent.getUrl();
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }
    }

    public static class SlideshowResponse extends ContentResponse {
        private float[] position = new float[3];
        private float[] rotation = new float[3];
        private float[] scale = new float[3];

        private boolean extendedTracking = false;
        private boolean renderOnTrackingLost = true;

        private List<SlideshowImageResponse> images;

        public SlideshowResponse(SlideshowContent slideshowContent) {
            super(slideshowContent);

            this.position[0] = slideshowContent.getPositionX();
            this.position[1] = slideshowContent.getPositionY();
            this.position[2] = slideshowContent.getPositionZ();

            this.rotation[0] = slideshowContent.getRotationX();
            this.rotation[1] = slideshowContent.getRotationY();
            this.rotation[2] = slideshowContent.getRotationZ();

            this.scale[0] = slideshowContent.getScaleX();
            this.scale[1] = slideshowContent.getScaleY();
            this.scale[2] = slideshowContent.getScaleZ();

            //this.extendedTracking = slideshowContent.isExtendedTracking();
            //this.renderOnTrackingLost = slideshowContent.isRenderOnTrackingLost();

            this.images = slideshowContent.getImages().stream().map(SlideshowImageResponse::new).collect(Collectors.toList());

            /*
            if(slideshowContent.getType().equals(SlideshowContent.Type.WHEEL)) {
                this.setName("Wheel");
            } else {
                this.setName("Slideshow");
            }
            */
        }

        public float[] getPosition() {
            return position;
        }

        public void setPosition(float[] position) {
            this.position = position;
        }

        public float[] getRotation() {
            return rotation;
        }

        public void setRotation(float[] rotation) {
            this.rotation = rotation;
        }

        public float[] getScale() {
            return scale;
        }

        public void setScale(float[] scale) {
            this.scale = scale;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public List<SlideshowImageResponse> getImages() {
            return images;
        }

        public void setImages(List<SlideshowImageResponse> images) {
            this.images = images;
        }
    }

    public static class SlideshowImageResponse {

        private long contentID;
        private String path;
        private float weight;
        private String name = null;

        public SlideshowImageResponse(SlideshowImage slideshowImage) {
            this.contentID = slideshowImage.getId();
            this.path = slideshowImage.getUrl();
            this.weight = slideshowImage.getWeight();
        }

        public long getContentID() {
            return contentID;
        }

        public void setContentID(long contentID) {
            this.contentID = contentID;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public float getWeight() {
            return weight;
        }

        public void setWeight(float weight) {
            this.weight = weight;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static class WebviewResponse extends ContentResponse {

        private String url;

        private boolean renderOnTrackingLost = true;
        private boolean extendedTracking = false;

        public WebviewResponse(WebviewContent webviewContent) {
            super(webviewContent);

            this.url = webviewContent.getUrl();

            // this.setName("Webview");
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }
    }

    public static class UnityResponse extends ContentResponse {

        @JsonProperty("android_path")
        private String androidPath;
        @JsonProperty("ios_path")
        private String iosPath;

        private float[] position = new float[3];
        private float[] rotation = new float[3];
        private float[] scale = new float[3];

        private boolean extendedTracking = true;
        private boolean renderOnTrackingLost = true;

        public UnityResponse(UnityContent unityContent) {
            super(unityContent);

            this.position[0] = unityContent.getPositionX();
            this.position[1] = unityContent.getPositionY();
            this.position[2] = unityContent.getPositionZ();

            this.rotation[0] = unityContent.getRotationX();
            this.rotation[1] = unityContent.getRotationY();
            this.rotation[2] = unityContent.getRotationZ();

            this.scale[0] = unityContent.getScaleX();
            this.scale[1] = unityContent.getScaleY();
            this.scale[2] = unityContent.getScaleZ();

            // this.extendedTracking = unityContent.isExtendedTracking();
            // this.renderOnTrackingLost = unityContent.isRenderOnTrackingLost();

            androidPath = unityContent.getAndroidUrl();
            iosPath = unityContent.getIosUrl();
        }

        public float[] getPosition() {
            return position;
        }

        public void setPosition(float[] position) {
            this.position = position;
        }

        public float[] getRotation() {
            return rotation;
        }

        public void setRotation(float[] rotation) {
            this.rotation = rotation;
        }

        public float[] getScale() {
            return scale;
        }

        public void setScale(float[] scale) {
            this.scale = scale;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public String getAndroidPath() {
            return androidPath;
        }

        public void setAndroidPath(String androidPath) {
            this.androidPath = androidPath;
        }

        public String getIosPath() {
            return iosPath;
        }

        public void setIosPath(String iosPath) {
            this.iosPath = iosPath;
        }
    }

    public static class AudioResponse extends ContentResponse  {

        private String path;
        private boolean renderOnTrackingLost = true;
        private boolean extendedTracking = false;

        public AudioResponse(AudioContent audioContent) {
            super(audioContent);

            this.path = audioContent.getUrl();
            // this.renderOnTrackingLost = audioContent.isRenderOnTrackingLost();

            // this.setName("Audio Sample");
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }
    }

    public static class MovieResponse extends ContentResponse {

        private float[] position = new float[3];
        private float[] rotation = new float[3];
        private float[] scale = new float[3];

        private boolean extendedTracking = false;
        private boolean renderOnTrackingLost = true;

        private String path;
        private boolean download = true;
        private boolean seekbar;

        private boolean greenscreen;
        private boolean sphere;

        public MovieResponse(MovieContent movieContent) {
            super(movieContent);

            this.position[0] = movieContent.getPositionX();
            this.position[1] = movieContent.getPositionY();
            this.position[2] = movieContent.getPositionZ();

            this.rotation[0] = movieContent.getRotationX();
            this.rotation[1] = movieContent.getRotationY();
            this.rotation[2] = movieContent.getRotationZ();

            this.scale[0] = movieContent.getScaleX();
            this.scale[1] = movieContent.getScaleY();
            this.scale[2] = movieContent.getScaleZ();

            // this.extendedTracking = movieContent.isExtendedTracking();
            // this.renderOnTrackingLost = movieContent.isRenderOnTrackingLost();

            this.path = movieContent.getUrl();
            // this.download = movieContent.isDownload();
            this.seekbar = movieContent.isSeekbar();

            this.greenscreen = movieContent.getType().equals(MovieContent.Type.GREENSCREEN);
            this.sphere = movieContent.getType().equals(MovieContent.Type.SPHERE);

            /*
            if(greenscreen) {
                this.setName("Greenscreen");
            } else if(sphere) {
                this.setName("360°");
            } else {
                this.setName("Normal Video");
            }
            */
        }

        public float[] getPosition() {
            return position;
        }

        public void setPosition(float[] position) {
            this.position = position;
        }

        public float[] getRotation() {
            return rotation;
        }

        public void setRotation(float[] rotation) {
            this.rotation = rotation;
        }

        public float[] getScale() {
            return scale;
        }

        public void setScale(float[] scale) {
            this.scale = scale;
        }

        public boolean isExtendedTracking() {
            return extendedTracking;
        }

        public void setExtendedTracking(boolean extendedTracking) {
            this.extendedTracking = extendedTracking;
        }

        public boolean isRenderOnTrackingLost() {
            return renderOnTrackingLost;
        }

        public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
            this.renderOnTrackingLost = renderOnTrackingLost;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public boolean isDownload() {
            return download;
        }

        public void setDownload(boolean download) {
            this.download = download;
        }

        public boolean isSeekbar() {
            return seekbar;
        }

        public void setSeekbar(boolean seekbar) {
            this.seekbar = seekbar;
        }

        public boolean isGreenscreen() {
            return greenscreen;
        }

        public void setGreenscreen(boolean greenscreen) {
            this.greenscreen = greenscreen;
        }

        public boolean isSphere() {
            return sphere;
        }

        public void setSphere(boolean sphere) {
            this.sphere = sphere;
        }
    }

}
