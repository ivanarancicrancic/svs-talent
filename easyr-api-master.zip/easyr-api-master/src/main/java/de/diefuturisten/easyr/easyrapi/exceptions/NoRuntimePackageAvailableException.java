package de.diefuturisten.easyr.easyrapi.exceptions;

public class NoRuntimePackageAvailableException extends Throwable {
}
