package de.diefuturisten.easyr.easyrapi.vuforia;

import de.diefuturisten.easyr.easyrapi.exceptions.InvalidTrackerImageException;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.DateUtils;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;


// See the Vuforia Web Services Developer API Specification - https://developer.vuforia.com/resources/dev-guide/adding-target-cloud-database-api

public class PostNewTarget implements TargetStatusListener {

    private String url;
	private String accessKey;
	private String secretKey;

	private TargetStatusPoller targetStatusPoller;
	private final float pollingIntervalMinutes = 0.25f;

	private IPostNewTargetStatusListener postNewTargetStatusListener;

    public PostNewTarget(String url, String accessKey, String secretKey) {
        this.url = url;
        this.accessKey = accessKey;
        this.secretKey = secretKey;
    }

    public String postTarget(String targetName, File file, IPostNewTargetStatusListener listener) throws URISyntaxException, ClientProtocolException, IOException, JSONException, InvalidTrackerImageException {
		System.out.println("Entered PostNewTarget.postTarget(...)!");
    	HttpPost postRequest = new HttpPost();
		System.out.println("new HttpPost() executed!");
    	HttpClient client = new DefaultHttpClient();
		System.out.println("new DefaultHttpClient() executed!!");
		postRequest.setURI(new URI(url + "/targets"));
		System.out.println("postRequest.setURI(new URI(url + \"/targets\")) executed! with URI: " + new URI(url + "/targets").toString());
		JSONObject requestBody = new JSONObject();
		System.out.println("new JSONObject() executed!");

		System.out.println("Before calling setRequestBody with requestBody: " + requestBody + ", targetName: " + targetName + ", file: " + file);
		requestBody = setRequestBody(requestBody, targetName, file);
		System.out.println("setRequestBody(requestBody, targetName, file) executed!!! with requestBody: " + requestBody.toString());
		postRequest.setEntity(new StringEntity(requestBody.toString()));
		System.out.println("postRequest.setEntity(new StringEntity(requestBody.toString())) executed!");
		setHeaders(postRequest); // Must be done after setting the body
		System.out.println("setHeaders(postRequest) executed");

		HttpResponse response = client.execute(postRequest);
		System.out.println("client.execute(postRequest) executed! with response: " + response.toString());

		String responseBody = EntityUtils.toString(response.getEntity());
		System.out.println("EntityUtils.toString(response.getEntity()) executed!!");

		JSONObject jobj = new JSONObject(responseBody);
		System.out.println("new JSONObject(responseBody) executed! with jObj: " + jobj.toString());
		
		String uniqueTargetId = jobj.has("result_code") ? jobj.getString("transaction_id") : null;
		System.out.println("uniqueTargetId is: " + uniqueTargetId);

		if(uniqueTargetId == null) {
			System.out.println("Throwing InvalidTrackerImageException");
			throw new InvalidTrackerImageException();
		}

		listener = new IPostNewTargetStatusListenerImpl();
		System.out.println("new IPostNewTargetStatusListenerImpl() executed!");

		// poll status if listener is given
		if(listener != null) {
			this.postNewTargetStatusListener = listener;
			if (uniqueTargetId != null && !uniqueTargetId.isEmpty()) {
				targetStatusPoller = new TargetStatusPoller(pollingIntervalMinutes, uniqueTargetId, accessKey, secretKey, this );
				targetStatusPoller.startPolling();
				System.out.println("targetStatusPoller.startPolling() executed!");

			}
		}

		System.out.println("uniqueTargetId: " + uniqueTargetId);
		return uniqueTargetId;
	}
	
	private JSONObject setRequestBody(JSONObject requestBody, String targetName, File file) throws IOException, JSONException {
		System.out.println("Entered setRequestBody... with file: " + file.toString());
		byte[] image = FileUtils.readFileToByteArray(file);
		System.out.println("Image loaded: " + image);
		requestBody.put("name", targetName); // Mandatory
		System.out.println("requestBody.put(\"name\", targetName) executed!");
		requestBody.put("width", 10.0); // Mandatory
		System.out.println("requestBody.put(\"width\", 10.0) executed!");
		requestBody.put("image", Base64.encodeBase64String(image)); // Mandatory
		System.out.println("requestBody.put(\"image\", Base64.encodeBase64String(image)) executed!");
		requestBody.put("active_flag", 1); // Optional
		System.out.println("requestBody.put(\"active_flag\", 1) executed!");
		// requestBody.put("application_metadata", Base64.encodeBase64String("Vuforia test metadata".getBytes())); // Optional
		return requestBody;
	}
	
	private void setHeaders(HttpUriRequest request) {
        SignatureBuilder sb = new SignatureBuilder();
        request.setHeader(new BasicHeader("Date", DateUtils.formatDate(new Date()).replaceFirst("[+]00:00$", "")));
        request.setHeader(new BasicHeader("Content-Type", "application/json"));
        request.setHeader("Authorization", "VWS " + accessKey + ":" + sb.tmsSignature(request, secretKey));
    }


	// Called with each update of the target status received by the TargetStatusPoller
	@Override
	public void OnTargetStatusUpdate(TargetState target_state) {
		if (target_state.hasState) {
			
			String status = target_state.getStatus();
			
			
			if (target_state.getActiveFlag() && status.equalsIgnoreCase("success")) {
				
				targetStatusPoller.stopPolling();
				

				if(postNewTargetStatusListener != null) {
					postNewTargetStatusListener.onStatusSuccess(target_state.getTargetId());
				}
			}
		}
	}

//	public interface IPostNewTargetStatusListener {
//    	void onStatusSuccess(String targetId);
//	}
//
//	public class IPostNewTargetStatusListenerImpl implements  IPostNewTargetStatusListener {
//
//    	public IPostNewTargetStatusListenerImpl(){}
//
//		@Override
//    	public void onStatusSuccess(String targetId){
//			System.out.println(targetId);
//
//		}
//	}


}
