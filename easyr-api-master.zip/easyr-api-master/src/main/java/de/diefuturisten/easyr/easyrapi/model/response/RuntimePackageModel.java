package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;

public class RuntimePackageModel {

    private long id;
    private String name;
    private String price;
    private String length;

    public RuntimePackageModel() {

    }

    public RuntimePackageModel(RuntimePackage runtimePackage) {
        this.id = runtimePackage.getId();
        this.name = runtimePackage.getName();
        this.price = runtimePackage.getPrice().toString();
        this.length = String.valueOf(runtimePackage.getLengthInDays());
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getLength() {
        return length;
    }

    public void setLength(String length) {
        this.length = length;
    }
}
