package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.model.response.MobileTrackerResponse;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("app/")
public class MobileApiController {

    private final TrackerService trackerService;

    public MobileApiController(TrackerService trackerService) {
        this.trackerService = trackerService;
    }

    @RequestMapping(value = "/tracker/{vuforiaId}/", method = RequestMethod.GET)
    public ResponseEntity getTracker(@PathVariable String vuforiaId) {

        Optional<Tracker> trackerOpt = trackerService.getTrackerByVuforiaId(vuforiaId);

        if( trackerOpt.isPresent() ){
            Tracker tracker = trackerOpt.get();
            trackerService.incrementTrackings(tracker);
            MobileTrackerResponse mobileTrackerResponse = new MobileTrackerResponse(tracker);
            return ResponseEntity.ok(mobileTrackerResponse);
        } else {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }

    }

}
