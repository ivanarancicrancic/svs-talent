package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;

import java.util.Date;

public class CouponModel {

    private long id;
    private String code;
    private boolean validUnlimited;
    private Date validFrom;
    private Date validTo;
    private long packageId;
    private String packageName;
    private double discountPercentage;

    public CouponModel(Coupon coupon) {
        this.id = coupon.getId();
        this.code = coupon.getCode();
        this.validUnlimited = coupon.isValidUnlimited();
        this.discountPercentage = coupon.getDiscountPercentage();
        this.packageId = coupon.getRuntimePackage().getId();
        this.packageName = coupon.getRuntimePackage().getName();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public boolean isValidUnlimited() {
        return validUnlimited;
    }

    public void setValidUnlimited(boolean validUnlimited) {
        this.validUnlimited = validUnlimited;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public long getPackageId() {
        return packageId;
    }

    public void setPackageId(long packageId) {
        this.packageId = packageId;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }
}
