package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.Upload;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UploadRepository extends JpaRepository<Upload, Long> {
}
