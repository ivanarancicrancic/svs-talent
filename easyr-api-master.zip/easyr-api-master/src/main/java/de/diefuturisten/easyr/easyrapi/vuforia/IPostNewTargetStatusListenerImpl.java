package de.diefuturisten.easyr.easyrapi.vuforia;

import com.google.common.util.concurrent.SettableFuture;

public class IPostNewTargetStatusListenerImpl implements  IPostNewTargetStatusListener {

    public IPostNewTargetStatusListenerImpl(){}

    @Override
    public void onStatusSuccess(String targetId){
        final SettableFuture<String> future = SettableFuture.create();
        future.set(targetId);
        System.out.println(targetId);

    }
}