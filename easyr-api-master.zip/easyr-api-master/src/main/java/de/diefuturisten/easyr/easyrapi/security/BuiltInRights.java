package de.diefuturisten.easyr.easyrapi.security;

public final class BuiltInRights {

    public static final String CAMPAIGN_CREATE = "CAMPAIGN_CREATE";
    public static final String CAMPAIGN_LIST = "CAMPAIGN_LIST";
    public static final String CAMPAIGN_EDIT = "CAMPAIGN_EDIT";
    public static final String CAMPAIGN_GET = "CAMPAIGN_GET";
    public static final String CONTENT_CREATE = "CONTENT_CREATE";
    public static final String CONTENT_EDIT = "CONTENT_EDIT";
    public static final String CONTENT_DELETE = "CONTENT_DELETE";
    public static final String IMAGE_DELETE = "IMAGE_DELETE";
    public static final String IMAGE_CREATE = "IMAGE_CREATE";
    public static final String PACKAGE_LIST = "PACKAGE_LIST";
    public static final String PACKAGE_LIST_FOR_USER = "PACKAGE_LIST_FOR_USER";
    public static final String PACKAGE_BUY = "PACKAGE_BUY";
    public static final String TRACKER_CREATE = "TRACKER_CREATE";
    public static final String TRACKER_EDIT = "TRACKER_EDIT";
    public static final String TRACKER_DELETE = "TRACKER_DELETE";
    public static final String USER_GET = "USER_GET";
    public static final String ADMIN_RIGHT = "ADMIN_RIGHT";

    private BuiltInRights() {
        // NO-OP utility class
    }

}
