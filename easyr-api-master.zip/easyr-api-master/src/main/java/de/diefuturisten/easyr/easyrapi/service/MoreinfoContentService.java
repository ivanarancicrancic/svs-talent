package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMoreinfoContentModel;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Service
@Transactional
public class MoreinfoContentService {

    private final ContentRepository contentRepository;

    public MoreinfoContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public MoreInfoContent create(Campaign campaign, CreateMoreinfoContentModel contentModel) {
        MoreInfoContent content = new MoreInfoContent();
        content.setCampaign(campaign);
        content.setName(contentModel.getName());
        content.setUrl(contentModel.getUrl());

        Optional<Content> contentWithHighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHighestWeight.isPresent()) {
            content.setWeight(contentWithHighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public MoreInfoContent edit(MoreInfoContent content, CreateMoreinfoContentModel contentModel) {
        // content.setName(webviewContentModel.getName());
        content.setUrl(contentModel.getUrl());
        return contentRepository.save(content);
    }
}
