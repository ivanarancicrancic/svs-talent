package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type;

@Service
@Transactional
public class MovieContentService {

    private final ContentRepository contentRepository;

    public MovieContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public MovieContent create(Campaign campaign, @Valid CreateMovieContentModel model) {
        MovieContent content = new MovieContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        content.setType(Type.valueOf(model.getSubType()));

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public MovieContent edit(MovieContent content, @Valid EditMovieContentModel model) {
        // content.setName(model.getName());
        content.setUrl(model.getUrl());
        content.setPositionX(model.getPositionX());
        content.setPositionY(model.getPositionY());
        content.setPositionZ(model.getPositionZ());
        content.setRotationX(model.getRotationX());
        content.setRotationY(model.getRotationY());
        content.setRotationZ(model.getRotationZ());
        content.setScaleX(model.getScaleX());
        content.setScaleY(model.getScaleY());
        content.setScaleZ(model.getScaleZ());
        content.setRenderOnTrackingLost(model.isRenderOnTrackingLost());
        content.setExtendedTracking(model.isExtendedTracking());

        return contentRepository.save(content);
    }

}
