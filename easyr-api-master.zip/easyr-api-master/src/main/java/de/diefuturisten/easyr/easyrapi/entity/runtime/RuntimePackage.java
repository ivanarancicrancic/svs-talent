package de.diefuturisten.easyr.easyrapi.entity.runtime;

import java.math.BigDecimal;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="runtime_packages")
public class RuntimePackage {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_runtimepackage")
    private long id;

    @Column(name="name", nullable = false)
    private String name;

    @Column(name="length", nullable = false)
    private int lengthInDays;

    @Column(name="price", nullable = false)
    private BigDecimal price;

    @OneToMany(mappedBy = "runtimePackage", cascade = CascadeType.ALL)
    private Set<PackageBuy> buys;

    public RuntimePackage() {

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLengthInDays() {
        return lengthInDays;
    }

    public void setLengthInDays(int lengthInDays) {
        this.lengthInDays = lengthInDays;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Set<PackageBuy> getBuys() {
        return buys;
    }

    public void setBuys(Set<PackageBuy> buys) {
        this.buys = buys;
    }
}
