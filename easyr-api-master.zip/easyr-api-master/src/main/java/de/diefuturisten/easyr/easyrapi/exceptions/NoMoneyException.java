package de.diefuturisten.easyr.easyrapi.exceptions;

public class NoMoneyException extends Throwable {
}
