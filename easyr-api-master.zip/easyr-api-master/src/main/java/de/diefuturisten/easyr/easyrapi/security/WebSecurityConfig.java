package de.diefuturisten.easyr.easyrapi.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.HEADER_STRING;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    private UserRepository userRepository;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    public WebSecurityConfig(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .cors().and().csrf().disable().authorizeRequests()
                .antMatchers("/").permitAll()
                .antMatchers("/api/**").permitAll()
                .antMatchers("/register").permitAll()
                .antMatchers("/forgotpw").permitAll()
                .antMatchers("/resetpw").permitAll()
                .antMatchers("/captcha/**").permitAll()
                .antMatchers("/app/tracker/**").permitAll()
                .antMatchers("/actuator").permitAll()
                .antMatchers("/actuator/**").permitAll()

                // YOUR EASRY ENDPOINT-CONFIGURATION
                // .antMatchers("/api/**").permitAll()
                // .antMatchers(HttpMethod.POST, "/password-forgot").permitAll()
                // .antMatchers(HttpMethod.POST, "/password-reset").permitAll()
                
                .anyRequest().authenticated()
                .and()
                // authentication (once during login)
                .addFilter(getJWTAuthenticationFilter())
                //  authorization (recover user from JWT on each request)
                .addFilter(new JWTAuthorizationFilter(authenticationManager(), userRepository))
                // never create a session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
    }

    /**
     * Creates an instance of our authentication filter, which uses our custom AuthenticationManager
     *
     * @return
     *
     * @throws Exception
     */
    protected JWTAuthenticationFilter getJWTAuthenticationFilter() throws Exception {
        JWTAuthenticationFilter authenticationFilter = new JWTAuthenticationFilter(new ObjectMapper());
        authenticationFilter.setAuthenticationManager(authenticationManager());
        return authenticationFilter;
    }

    /**
     * Create our own authentication manager, which has access into the database.
     *
     * @return
     */
    protected EasyRAuthenticationManager getEasryRAuthenticationManager() {
        return new EasyRAuthenticationManager(userRepository, this.passwordEncoder());
    }

    /**
     * This method is overridden to activate the usage of our own specific implementation.
     *
     * @return
     *
     * @throws Exception
     */
    @Bean
    @Override
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return super.authenticationManagerBean();
    }

    /**
     * This method is overriden to return our own specific implementation.
     *
     * @return
     *
     * @throws Exception
     */
    @Override
    protected AuthenticationManager authenticationManager() throws Exception {
        return getEasryRAuthenticationManager();
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();

        CorsConfiguration corsConfig = new CorsConfiguration();
        corsConfig.applyPermitDefaultValues();
        corsConfig.addAllowedMethod(HttpMethod.DELETE);
        corsConfig.addAllowedMethod(HttpMethod.PUT);
        corsConfig.addExposedHeader(HEADER_STRING);

        source.registerCorsConfiguration("/**", corsConfig);
        return source;
    }
}
