package de.diefuturisten.easyr.easyrapi.model.response;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class CaptchaResponseModel {

    @NotBlank
    private String id;

    @NotNull
    private String answer;

    public CaptchaResponseModel() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
