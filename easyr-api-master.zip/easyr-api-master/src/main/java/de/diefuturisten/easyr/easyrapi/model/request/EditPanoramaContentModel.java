package de.diefuturisten.easyr.easyrapi.model.request;

public class EditPanoramaContentModel extends EditCotnentModel{
    private String subType;
    private String url;

    public EditPanoramaContentModel(){}

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
