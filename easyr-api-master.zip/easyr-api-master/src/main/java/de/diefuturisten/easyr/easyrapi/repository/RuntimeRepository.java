package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import org.springframework.data.jpa.repository.JpaRepository;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;

public interface RuntimeRepository extends JpaRepository<Runtime, Long> {

    Runtime findByPackageBuy(PackageBuy packageBuy);

}
