package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRightRepository extends JpaRepository<UserRight, Long> {
    Optional<UserRight> findByName(String name);
}
