package de.diefuturisten.easyr.easyrapi.vuforia;

public interface IPostNewTargetStatusListener {
    void onStatusSuccess(String targetId);
}