package de.diefuturisten.easyr.easyrapi.entity.campaign;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Table
@Entity(name = "contactinfos")
public class ContactInformation {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_contactinfo")
    private long id;

    @OneToMany(mappedBy = "contact")
    private List<Campaign> campaigns = new ArrayList<>();

    @Column(name="name")
    private String name;

    @Column(name="company")
    private String company;

    @Column(name="homepage")
    private String homepage;

    @Column(name="email")
    private String email;

    @Column(name="address")
    private String address;

    @Column(name="address2")
    private String address2;

    @Column(name="number")
    private String number;

    @Column(name="zip")
    private String zip;

    @Column(name="city")
    private String city;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @JsonIgnore
    public List<Campaign> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getHomepage() {
        return homepage;
    }

    public void setHomepage(String homepage) {
        this.homepage = homepage;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
