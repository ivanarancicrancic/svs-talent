package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.user.User;

public class AccountModel {

    private long id;
    private String firstname, lastname, email, telNumber, paymentFirstName, paymentLastName;
    private String paymentCompany, paymentStreet, paymentPostcode, paymentState, paymentCity, paymentCountry;
    private boolean paymentTitle;
    private boolean gender;

    public AccountModel(User user) {
        this.id = user.getId();

        this.gender = user.getGender();
        this.firstname = user.getFirstname();
        this.lastname = user.getLastname();
        this.email = user.getEmail();
        this.telNumber = user.getTelNumber();
        this.paymentTitle = user.getPaymentTitle();
        this.paymentFirstName = user.getPaymentFirstname();
        this.paymentLastName = user.getPaymentLastname();
        this.paymentCompany = user.getPaymentCompany();
        this.paymentStreet =  user.getPaymentStreet();
        this.paymentPostcode =  user.getPaymentPostcode();
        this.paymentCity = user.getPaymentCity();
        this.paymentState =  user.getPaymentState();
        this.paymentCountry =  user.getPaymentCountry();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public boolean isGender() {
        return gender;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelNumber() {
        return telNumber;
    }

    public void setTelNumber(String telNumber) {
        this.telNumber = telNumber;
    }

    public String getPaymentFirstName() {
        return paymentFirstName;
    }

    public void setPaymentFirstName(String paymentFirstName) {
        this.paymentFirstName = paymentFirstName;
    }

    public String getPaymentLastName() {
        return paymentLastName;
    }

    public void setPaymentLastName(String paymentLastName) {
        this.paymentLastName = paymentLastName;
    }

    public boolean isPaymentTitle() {
        return paymentTitle;
    }

    public void setPaymentTitle(boolean paymentTitle) {
        this.paymentTitle = paymentTitle;
    }

    public String getPaymentCompany() {
        return paymentCompany;
    }

    public void setPaymentCompany(String paymentCompany) {
        this.paymentCompany = paymentCompany;
    }

    public String getPaymentStreet() {
        return paymentStreet;
    }

    public void setPaymentStreet(String paymentStreet) {
        this.paymentStreet = paymentStreet;
    }

    public String getPaymentPostcode() {
        return paymentPostcode;
    }

    public void setPaymentPostcode(String paymentPostcode) {
        this.paymentPostcode = paymentPostcode;
    }

    public String getPaymentCity() {
        return paymentCity;
    }

    public void setPaymentCity(String paymentCity) {
        this.paymentCity = paymentCity;
    }

    public String getPaymentState() {
        return paymentState;
    }

    public void setPaymentState(String paymentState) {
        this.paymentState = paymentState;
    }

    public String getPaymentCountry() {
        return paymentCountry;
    }

    public void setPaymentCountry(String paymentCountry) {
        this.paymentCountry = paymentCountry;
    }
}