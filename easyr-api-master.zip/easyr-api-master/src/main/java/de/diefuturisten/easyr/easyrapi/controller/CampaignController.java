package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.SaveNewCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import org.springframework.security.access.prepost.PreAuthorize;
import javax.validation.Valid;
import java.util.stream.Stream;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class CampaignController {

    private final CampaignService campaignService;
    private final AuthenticationFacade authenticationFacade;

    public CampaignController(CampaignService campaignService, AuthenticationFacade authenticationFacade) {
        this.campaignService = campaignService;
        this.authenticationFacade = authenticationFacade;
    }

    @GetMapping("/campaigns")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_LIST)
    public Stream<CampaignOverviewModel> getAllCampaignsForUser() {
        User user = authenticationFacade.getAuthenticatedUser();

        return campaignService
                .getCampaignsForUser(user)
                .stream()
                .map(CampaignOverviewModel::new);
    }

    @GetMapping("/campaign/{id}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_GET)
    public CampaignDetailModel getCampaign(@PathVariable long id) throws ForbiddenException {

        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(id).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        // TODO: include contact information?
        return new CampaignDetailModel(campaign);
    }

    @PostMapping("/campaign")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_CREATE)
    public CampaignDetailModel createCampaign() {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign createdCampaign = this.campaignService.createEmptyCampaign(user);
        return new CampaignDetailModel(createdCampaign);
    }

    @PostMapping("/campaign/{id}/save")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_CREATE)
    public CampaignDetailModel saveNewCampaign(@PathVariable long id, @Valid @RequestBody SaveNewCampaignModel model) throws NoRuntimePackageAvailableException {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(id).orElseThrow(ForbiddenException::new);
        System.out.println("Campaign: " + campaign.getName());

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        return new CampaignDetailModel(campaignService.saveNewCampaign(campaign, model, user));
    }

    @PutMapping("/campaign")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_EDIT)
    public CampaignDetailModel editCampaign(@Valid @RequestBody EditCampaignModel editCampaignModel) throws ForbiddenException {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(editCampaignModel.getId()).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        Campaign editedCampaign = campaignService.editCampaign(campaign, editCampaignModel);

        return new CampaignDetailModel(editedCampaign);
    }


}
