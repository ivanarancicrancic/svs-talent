package de.diefuturisten.easyr.easyrapi.entity.campaign;

import com.fasterxml.jackson.annotation.JsonIgnore;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="campaigns")
public class Campaign {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_campaign")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="campaign")
    private List<Tracker> tracker = new java.util.ArrayList<>();

    @OneToMany(mappedBy="campaign")
    private List<Content> contents = new java.util.ArrayList<>();

    @OneToMany(mappedBy="campaign")
    private List<Runtime> runtimes = new java.util.ArrayList<>();

    @ManyToOne()
    @JoinColumn(name="fk_contact")
    private ContactInformation contact;

    @Column(name="temporary", nullable = false)
    private boolean temporary = true;

    // getter & setter

    public Campaign(){}

    public Campaign(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getTotalTrackings() {
        return tracker.stream().mapToLong(Tracker::getTrackings).sum();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonIgnore
    public List<Tracker> getTracker() {
        return tracker;
    }

    public void setTracker(List<Tracker> tracker) {
        this.tracker = tracker;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    @JsonIgnore
    public ContactInformation getContactInformation() {
        return contact;
    }

    public void setContactInformation(ContactInformation contactInformation) {
        this.contact = contactInformation;
    }

    public List<Runtime> getRuntimes() {
        return runtimes;
    }

    public void setRuntimes(List<Runtime> runtimes) {
        this.runtimes = runtimes;
    }

    public ContactInformation getContact() {
        return contact;
    }

    public void setContact(ContactInformation contact) {
        this.contact = contact;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }
}
