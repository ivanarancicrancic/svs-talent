create table runtime_packages
(
	key_runtimepackage bigserial not null
		constraint runtime_packages_pkey
			primary key,
	length integer not null,
	name varchar(255) not null,
	price numeric(19,2) not null
);

create table coupons
(
	key_coupon bigserial not null
		constraint coupons_pkey
			primary key,
	code varchar(255),
	discount double precision not null,
	start timestamp,
	ende timestamp,
	valid_unlimited boolean not null,
	fk_package bigint not null
		constraint fkesbd1t587i46qjm6ggtywu5hg
			references runtime_packages,
	fk_user bigint
		constraint fkrw85mfxdceq3wbabxjw3yncar
			references users
);

create table package_buys
(
	key_user_bought_package bigserial not null
		constraint package_buys_pkey
			primary key,
	bought_at timestamp not null,
	key_package bigint
		constraint fkt104xs9r6ejp4kvn0cclvkk43
			references runtime_packages,
	fk_coupon bigint
		constraint fk1wfeuqn92qywwx7c1o45bv1vt
			references coupons,
	key_user bigint
		constraint fk626r1btdfateertlil0mwd5o5
			references users
);

create table runtimes
(
	key_runtime bigserial not null
		constraint runtimes_pkey
			primary key,
	start timestamp not null,
	ende timestamp not null,
	fk_campaign bigint not null
		constraint fkj8pg6xellr2e536lpspr0x6b0
			references campaigns
);

ALTER TABLE package_buys ADD COLUMN fk_runtime bigint constraint fk6y9jjg4mp2gt5pxts691ec5kr references runtimes;
ALTER TABLE runtimes ADD COLUMN fk_packagebuy bigint constraint fkaiu953jabgtqwuot3nj0atnyo references package_buys;