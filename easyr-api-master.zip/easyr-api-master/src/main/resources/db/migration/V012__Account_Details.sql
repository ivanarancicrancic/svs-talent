ALTER TABLE users ADD COLUMN telnumber varchar(50);
UPDATE users SET telnumber = '+49 1234 555 678';
ALTER TABLE users ALTER COLUMN telnumber SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_title boolean;
UPDATE users SET payment_title = users.gender;
ALTER TABLE users ALTER COLUMN payment_title SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_firstname varchar(255);
UPDATE users SET payment_firstname = users.firstname;
ALTER TABLE users ALTER COLUMN payment_firstname SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_lastname varchar(255);
UPDATE users SET payment_lastname = users.lastname;
ALTER TABLE users ALTER COLUMN payment_lastname SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_company varchar(255);
UPDATE users SET payment_company = 'Test Company';
ALTER TABLE users ALTER COLUMN payment_company SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_street varchar(255);
UPDATE users SET payment_street = '123 Fake Street';
ALTER TABLE users ALTER COLUMN payment_street SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_postcode varchar(255);
UPDATE users SET payment_postcode = '31337';
ALTER TABLE users ALTER COLUMN payment_postcode SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_city varchar(255);
UPDATE users SET payment_city = 'Faketon';
ALTER TABLE users ALTER COLUMN payment_city SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_country varchar(255);
UPDATE users SET payment_country = 'de';
ALTER TABLE users ALTER COLUMN payment_country SET NOT NULL;

ALTER TABLE users ADD COLUMN payment_state varchar(255);
UPDATE users SET payment_state = 'nw';
ALTER TABLE users ALTER COLUMN payment_state SET NOT NULL;