package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;
import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.exceptions.*;
import de.ersatzteil.ersatzteilhandel24api.model.request.*;
import de.ersatzteil.ersatzteilhandel24api.model.response.*;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
public class CategoryController {


    private final CategoryService categoryService;
    private final AuthenticationFacade authenticationFacade;

    public CategoryController(CategoryService categoryService, AuthenticationFacade authenticationFacade) {
        this.categoryService = categoryService;
        this.authenticationFacade = authenticationFacade;
    }

    @GetMapping("/categories")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_LIST)
    public java.util.stream.Stream<CategoryOverviewModel> getAllCategoriesForUser() {

        System.out.println("ENTERED getCategories!");
        User user = authenticationFacade.getAuthenticatedUser();
        return categoryService
                .getCategoriesForUser(user)
                .stream()
                .map(CategoryOverviewModel::new);
    }

    @GetMapping("/category/{id}/manufacturers")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_LIST)
    public java.util.stream.Stream<de.ersatzteil.ersatzteilhandel24api.model.response.ManufacturerModel> getExampleAllManufacturesForCategory(@PathVariable long id) {


        System.out.println("PRINT SELECTED CATEGORY ID: " + id);
        User user = authenticationFacade.getAuthenticatedUser();


        return categoryService
                .getManufacturersForCategory(id)
                .stream()
                .map(de.ersatzteil.ersatzteilhandel24api.model.response.ManufacturerModel::new);
    }


    @GetMapping("/category/{cid}/manufacturer/{id}/products")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_LIST)
    public java.util.stream.Stream<de.ersatzteil.ersatzteilhandel24api.model.response.ProductModel> getExampleAllProductsForManufacturer(@PathVariable long id, @PathVariable long cid) {

        System.out.println("PRINT SELECTED MANUFACTURER ID: " + id);
        System.out.println("PRINT SELECTED CATEGORY ID: " + cid);
        User user = authenticationFacade.getAuthenticatedUser();
        return categoryService
                .getProductsForManufactorer(id, cid)
                .stream()
                .map(de.ersatzteil.ersatzteilhandel24api.model.response.ProductModel::new);
    }

    @GetMapping("/category/{id}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_GET)
    public CategoryDetailModel getCategory(@PathVariable long id) throws ForbiddenException {

        User user = authenticationFacade.getAuthenticatedUser();
        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        return new CategoryDetailModel(category);
    }

    @PostMapping("/category")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel createCategory() {
        User user = authenticationFacade.getAuthenticatedUser();
        Category createdCategory = this.categoryService.createEmptyCategory(user);
        return new CategoryDetailModel(createdCategory);
    }

    @PostMapping("/category/{id}/save")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel saveNewCategory(@PathVariable long id, @Valid @RequestBody SaveNewCategoryModel model) {

        User user = authenticationFacade.getAuthenticatedUser();
        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        return new CategoryDetailModel(categoryService.saveNewCategory(category, model, user));
    }

    @PutMapping("/category")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_EDIT)
    public CategoryDetailModel editCategory(@Valid @RequestBody EditCategoryModel editCategoryModel) throws ForbiddenException {

        User user = authenticationFacade.getAuthenticatedUser();
        Category category = categoryService.getCategory(editCategoryModel.getId()).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        Category editedCategory = categoryService.editCategory(category, editCategoryModel);
        return new CategoryDetailModel(editedCategory);
    }
}
