package de.ersatzteil.ersatzteilhandel24api.service;

import de.ersatzteil.ersatzteilhandel24api.entity.category.Category;
import de.ersatzteil.ersatzteilhandel24api.entity.user.User;
import de.ersatzteil.ersatzteilhandel24api.model.request.EditCategoryModel;
import de.ersatzteil.ersatzteilhandel24api.model.request.SaveNewCategoryModel;
import de.ersatzteil.ersatzteilhandel24api.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import de.ersatzteil.ersatzteilhandel24api.repository.ProductRepository;
import de.ersatzteil.ersatzteilhandel24api.entity.product.Product;
import de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer;
import de.ersatzteil.ersatzteilhandel24api.repository.ManufacturerRepository;

@Service
@Transactional
public class CategoryService {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final ManufacturerRepository manufacturerRepository;

    public CategoryService(CategoryRepository categoryRepository, ProductRepository productRepository, ManufacturerRepository manufacturerRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
        this.manufacturerRepository = manufacturerRepository;
    }


    public List<Category> findAllCategories() {
        return categoryRepository.findAll().stream().collect(Collectors.toList());
    }

    public List<Category> getCategoriesForUser(User user) {
        return categoryRepository.findByUser(user).stream().collect(Collectors.toList());
    }

    public List<Manufacturer> getManufacturersForCategory(long id) {
        Category category = categoryRepository.findById(id).get();
        return category.getManufacturers().stream().collect(Collectors.toList());
//        return manufacturerRepository.findAll().stream().collect(Collectors.toList());
    }

    public List<Product> getProductsForManufactorer(long id, long categoryId) {
        Manufacturer manufacturer = manufacturerRepository.findById(id).get();

        return manufacturer.getProducts().stream().filter(product -> Long.toString(product.getCategory().getId()).equals(Long.toString(categoryId))).collect(Collectors.toList());
//        return productRepository.findAll().stream().collect(Collectors.toList());
    }

    public Optional<Category> getCategory(long id) {
        return this.categoryRepository.findById(id);
    }


    public Category createEmptyCategory(User user) {
        Category category = new Category();
        category.setUser(user);
        return this.categoryRepository.save(category);
    }

    public Category saveNewCategory(Category category, SaveNewCategoryModel model, User user) {

        this.categoryRepository.save(category);
        return category;
    }

    public Category editCategory(Category category, EditCategoryModel editCategoryModel) {
        category.setName(editCategoryModel.getName());
        return this.categoryRepository.save(category);
    }
}
