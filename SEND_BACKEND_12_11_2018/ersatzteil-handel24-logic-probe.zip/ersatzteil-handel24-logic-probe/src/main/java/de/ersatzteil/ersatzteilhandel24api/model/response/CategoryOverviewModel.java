package de.ersatzteil.ersatzteilhandel24api.model.response;

import de.ersatzteil.ersatzteilhandel24api.entity.category.*;

public class CategoryOverviewModel {

    private long id;
    private String name;
    private String trackerUrl;
    private long numberOfViews;
    private java.util.Date expirationDate;

    public CategoryOverviewModel() {
    }

    public CategoryOverviewModel(Category category) {
        this.id = category.getId();
        this.name = category.getName();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
