package de.ersatzteil.ersatzteilhandel24api.repository;

import de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerRepository extends JpaRepository<Manufacturer, Long> {
}
