package de.ersatzteil.ersatzteilhandel24api.model.request;

public class CreateCategoryModel {

    public CreateCategoryModel() {
    }
}
