package de.ersatzteil.ersatzteilhandel24api.model.response;

import de.ersatzteil.ersatzteilhandel24api.entity.user.*;

public class UserModelForAdmin {

    private long id;
    private String name;
    private long numberOfCategories;

    public UserModelForAdmin(User user) {
        this.id = user.getId();
        this.name = user.getName();
        this.numberOfCategories = user.getCategories().size();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getNumberOfCategories() {
        return numberOfCategories;
    }

    public void setNumberOfCategories(long numberOfCategories) {
        this.numberOfCategories = numberOfCategories;
    }
}
