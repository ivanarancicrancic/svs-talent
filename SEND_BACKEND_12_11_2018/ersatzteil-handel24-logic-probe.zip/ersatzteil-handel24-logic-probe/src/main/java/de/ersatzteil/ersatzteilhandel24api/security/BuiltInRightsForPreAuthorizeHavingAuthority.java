package de.ersatzteil.ersatzteilhandel24api.security;

public final class BuiltInRightsForPreAuthorizeHavingAuthority {

    private static final String HAS_AUTHORITY_PREFIX = "hasAuthority('";
    private static final String HAS_AUTHORITY_SUFFIX = "')";

    public static final String CATEGORY_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_LIST = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_LIST + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String CATEGORY_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.CATEGORY_GET + HAS_AUTHORITY_SUFFIX;
    public static final String PRODUCT_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.PRODUCT_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String PRODUCT_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.PRODUCT_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String PRODUCT_EDIT = HAS_AUTHORITY_PREFIX + BuiltInRights.PRODUCT_EDIT + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_CREATE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_CREATE + HAS_AUTHORITY_SUFFIX;
    public static final String IMAGE_DELETE = HAS_AUTHORITY_PREFIX + BuiltInRights.IMAGE_DELETE + HAS_AUTHORITY_SUFFIX;
    public static final String USER_GET = HAS_AUTHORITY_PREFIX + BuiltInRights.USER_GET + HAS_AUTHORITY_SUFFIX;
    public static final String ADMIN_RIGHT = HAS_AUTHORITY_PREFIX + BuiltInRights.ADMIN_RIGHT + HAS_AUTHORITY_SUFFIX;

    private BuiltInRightsForPreAuthorizeHavingAuthority() {
    }

}
