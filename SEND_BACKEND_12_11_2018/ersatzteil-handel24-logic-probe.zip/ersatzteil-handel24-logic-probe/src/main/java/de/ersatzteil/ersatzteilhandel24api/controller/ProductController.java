package de.ersatzteil.ersatzteilhandel24api.controller;

import de.ersatzteil.ersatzteilhandel24api.entity.product.*;
import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import de.ersatzteil.ersatzteilhandel24api.exceptions.*;
import de.ersatzteil.ersatzteilhandel24api.model.response.ProductModel;
import de.ersatzteil.ersatzteilhandel24api.security.*;
import de.ersatzteil.ersatzteilhandel24api.service.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ProductController {

    private final AuthenticationFacade authenticationFacade;
    private final ProductService productService;
    private final CategoryService categoryService;

    public ProductController(AuthenticationFacade authenticationFacade, ProductService productService, CategoryService categoryService) {
        this.authenticationFacade = authenticationFacade;
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @DeleteMapping("/category/product/{productId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.PRODUCT_DELETE)
    public boolean deleteProduct(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);

//        if(!product.getCategory().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }

        productService.deleteProduct(product);
        return true;
    }

    @GetMapping("/product/{name}")
    public ProductModel getProductByArticleNumber(@PathVariable long name) {
        System.out.println("ENTERED getPRoductByArticleNumber!");
        Product product = productService.getById(name).orElseThrow(ForbiddenException::new);
        ProductModel productModel = new ProductModel(product);
        System.out.println(productModel.getName());

//        if(!product.getCategory().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }

       return productModel;
    }



}