package de.ersatzteil.ersatzteilhandel24api.model.response;

public class ManufacturerModel {
    private long mid;
    private String name;
    private String description;

    public ManufacturerModel() {
    }

    public ManufacturerModel(de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer product) {
        this.mid = product.getId();
        this.name = product.getName();
        this.description = product.getDescription();

    }

    public long getId() {
        return mid;
    }

    public void setId(long id) {
        this.mid = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
