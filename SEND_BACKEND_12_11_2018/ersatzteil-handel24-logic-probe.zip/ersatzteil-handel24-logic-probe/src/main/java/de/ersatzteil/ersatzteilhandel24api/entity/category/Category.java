package de.ersatzteil.ersatzteilhandel24api.entity.category;

import de.ersatzteil.ersatzteilhandel24api.entity.user.*;
import java.util.Set;
import javax.persistence.*;
import de.ersatzteil.ersatzteilhandel24api.entity.manufacturer.Manufacturer;
import java.util.HashSet;
import javax.persistence.FetchType;
import de.ersatzteil.ersatzteilhandel24api.entity.product.Product;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name="categories")
public class Category {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_category")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="category")
    private List<Product> products = new ArrayList<>();

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "category_has_manufacturers",
            joinColumns = { @JoinColumn(name = "fk_categories") },
            inverseJoinColumns = { @JoinColumn(name = "fk_manufacturer") }
    )
    private Set<Manufacturer> manufacturers = new HashSet<>();

    // getter & setter
    public Category(){}

    public Category(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Manufacturer> getManufacturers() {
        return manufacturers;
    }

    public void setManufacturers(Set<Manufacturer> manufacturers) {
        this.manufacturers = manufacturers;
    }

    public java.util.List<de.ersatzteil.ersatzteilhandel24api.entity.product.Product> getProducts() {
        return products;
    }

    public void setProducts(java.util.List<de.ersatzteil.ersatzteilhandel24api.entity.product.Product> products) {
        this.products = products;
    }
}
