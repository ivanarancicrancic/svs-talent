-- Users
INSERT INTO
  users(key_user, active, language, email, password, firstname, lastname, gender)
VALUES
  (1, true, 'de', 'christen@app-logik.de', '$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK', 'Oliver', 'Christen', true); -- password is "wuff"

ALTER SEQUENCE users_key_user_seq RESTART WITH 2;

-- Roles
INSERT INTO
  userroles(key_userrole, name, description)
VALUES
  (1, 'Standard', 'normal user'),
  (2, 'Admin', 'admin user');

ALTER SEQUENCE userroles_key_userrole_seq RESTART WITH 3;

-- User has Roles
INSERT INTO
  user_has_roles(fk_user, fk_userrole)
VALUES
  (1, 1),
  (1, 2);

-- Rights
INSERT INTO
  userrights(key_userright, description, name)
VALUES
  (1, 'dummy standard rule', 'dummy standard role'),
  (2, 'dummy admin role', 'dummy admin role'),
  (3, 'dummy role', 'dummy role');

-- Role Has Rights
INSERT INTO
  role_has_rights(fk_userrole, fk_userright)
VALUES
  (1, 1),
  (1, 3),
  (2, 2),
  (2, 3);