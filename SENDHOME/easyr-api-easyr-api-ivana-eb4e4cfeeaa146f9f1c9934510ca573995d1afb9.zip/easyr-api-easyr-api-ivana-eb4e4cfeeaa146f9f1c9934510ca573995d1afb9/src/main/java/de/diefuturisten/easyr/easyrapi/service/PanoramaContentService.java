package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.repository.PanoramaContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class PanoramaContentService {
    @Autowired
    private PanoramaContentRepository panoramaContentRepository;

    public PanoramaContentService(PanoramaContentRepository panoramaContentRepository) {
        this.panoramaContentRepository = panoramaContentRepository;
    }

    public List<PanoramaContent> findAllPanoramas(){
        return panoramaContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public PanoramaContent findById(Long id){
        Optional<PanoramaContent> optionalContent = panoramaContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public PanoramaContent findByName(String name){
        return panoramaContentRepository.findByName(name).get();
    }

    public PanoramaContent savePanoramaContent(PanoramaContent panoramaContent){
        panoramaContentRepository.save(panoramaContent);
        return panoramaContent;
    }

    public void deletePanoramaContent(PanoramaContent panoramaContent){
        panoramaContentRepository.delete(panoramaContent);
    }

    public void deletePanoramaContentById(Long id){
        panoramaContentRepository.deleteById(id);
    }

    public PanoramaContent createPanorama(PanoramaContent panoramaContent){
        panoramaContentRepository.save(panoramaContent);
        PanoramaContent savedPanorama = panoramaContentRepository.findById(panoramaContent.getId()).get();
        return savedPanorama;
    }

    public void deleteMovie(Long id){
        String status = "deleting panorama";
        System.out.println(status);
        panoramaContentRepository.deleteById(id);

    }



}
