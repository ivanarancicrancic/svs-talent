package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.repository.MovieContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class MovieContentService {

    @Autowired
    private MovieContentRepository movieContentRepository;

    public MovieContentService(MovieContentRepository movieContentRepository) {
        this.movieContentRepository = movieContentRepository;
    }

    public List<MovieContent> findAllMovies(){
        return movieContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public MovieContent findById(Long id){
        Optional<MovieContent> optionalContent =movieContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public MovieContent findByName(String name){
        return movieContentRepository.findByName(name).get();
    }

    public MovieContent saveMovieContent(MovieContent movieContent){
        movieContentRepository.save(movieContent);
        return movieContent;
    }

    public void deleteMovieContent(MovieContent movieContent){
        movieContentRepository.delete(movieContent);
    }

    public void deleteMovieContentById(Long id){
        movieContentRepository.deleteById(id);
    }

    public MovieContent createAudio(MovieContent movieContent){
        movieContentRepository.save(movieContent);
        MovieContent savedMovie = movieContentRepository.findById(movieContent.getId()).get();
        return savedMovie;
    }

    public void deleteMovie(Long id){
        String status = "deleting movie";
        System.out.println(status);
        movieContentRepository.deleteById(id);

    }



}
