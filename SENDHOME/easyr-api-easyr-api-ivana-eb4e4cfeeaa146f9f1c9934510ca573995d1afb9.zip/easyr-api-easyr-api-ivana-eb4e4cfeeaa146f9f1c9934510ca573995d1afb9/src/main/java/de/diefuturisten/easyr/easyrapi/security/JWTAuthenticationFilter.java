package de.diefuturisten.easyr.easyrapi.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.model.request.UserLoginCredientialsModel;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.EXPIRATION_TIME;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.HEADER_STRING;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {


    private final ObjectMapper mapper;
    public static final String REQUEST_ATTRIBUTE_FOR_JSON = "JWTAuthenticationFilter_AuthAttribute";
   // private final AuthenticationManager authenticationManager;

//    public JWTAuthenticationFilter(ObjectMapper mapper, AuthenticationManager authenticationManager) {
//        this.mapper = mapper;
//        this.authenticationManager = authenticationManager;
//    }
//
//    public JWTAuthenticationFilter(AuthenticationManager authenticationManager) {
//        this.authenticationManager = authenticationManager;
//    }


    public JWTAuthenticationFilter(ObjectMapper mapper) {
        super();
        this.mapper = mapper;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainUsername(HttpServletRequest request) {
        return Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getUsername();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainPassword(HttpServletRequest request) {
        return Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getPassword();
    }

    /**
     * {@inheritDoc}
     */

//    @Override
//    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
//        try {
//            UserLoginCredientialsModel creds = new ObjectMapper()
//                    .readValue(request.getInputStream(), UserLoginCredientialsModel.class);
//
//            return authenticationManager.authenticate(
//                    new UsernamePasswordAuthenticationToken(
//                            creds.getUsername(),
//                            creds.getPassword(),
//                            new ArrayList<>())
//            );
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//    }

    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        // as we are parsing the request-body, we have to read the request ONCE (otherwise we are trying to re-read the inputstream, which gets closed)
        request.setAttribute(REQUEST_ATTRIBUTE_FOR_JSON, getUserLoginCredientialsModel(request));
        Authentication attemptAuthenticationResult = super.attemptAuthentication(request, response);
        // cleanup
        request.removeAttribute(REQUEST_ATTRIBUTE_FOR_JSON);
        return attemptAuthenticationResult;
    }


    private UserLoginCredientialsModel getUserLoginCredientialsModel(HttpServletRequest request) {
        try(ServletInputStream inputStream = request.getInputStream()){
            return mapper.readValue(inputStream, UserLoginCredientialsModel.class);
        } catch(IOException e){ // NOSONAR
            // NO-OP
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication auth) throws IOException, ServletException {
        // When authentication was successful, store the username inside the JWT-related HTTP-header
        String username = String.valueOf(auth.getPrincipal());
        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
        // tell the client our new JWT-token
        response.addHeader(HEADER_STRING, TokenHelper.createToken(username, expirationTime));
    }



//    @Override
//    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication auth) throws IOException, ServletException {
//        String username = ((User) auth.getPrincipal()).getUsername();
//        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
//        response.addHeader(HEADER_STRING, TokenHelper.createToken(username, expirationTime));
//    }
}
