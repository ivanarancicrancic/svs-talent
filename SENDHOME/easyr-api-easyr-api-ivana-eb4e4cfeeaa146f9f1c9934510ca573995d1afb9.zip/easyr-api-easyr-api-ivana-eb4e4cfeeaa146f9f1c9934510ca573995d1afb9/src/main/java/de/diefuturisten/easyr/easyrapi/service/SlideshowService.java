package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowEntry;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRespository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Component
@Transactional
public class SlideshowService {

    @Autowired
    private final SlideshowRepository slideshowRepository;

    @Autowired
    private final CampaignRespository campaignRespository;

    public SlideshowService(SlideshowRepository slideshowRepository, CampaignRespository campaignRespository) {
        this.slideshowRepository = slideshowRepository;
        this.campaignRespository = campaignRespository;
    }

    public List<SlideshowContent> getAllSlideshows(){
        String status = "getting all slideshow";
        System.out.println(status);
        Iterable<SlideshowContent> iterable = slideshowRepository.findAll();
        System.out.println("Taken slideshows!");
        List<SlideshowContent> list = new ArrayList<>();
        if(iterable != null) {
            for(SlideshowContent e: iterable) {
                list.add(e);
            }
        }
        return list;
    }

    public SlideshowContent findByCampaignIdAndSlideshowId(long campaignId, long slideshowId)
    {
             Optional<SlideshowContent> slideshowContentOptional =  slideshowRepository.findById(slideshowId);
        if (!slideshowContentOptional.isPresent()) {
            // throw new NotFoundException("Slideshow Not Found for id:" + id.toString());
        }
        return slideshowContentOptional.get();

//      {
//        Optional<SlideshowContent> slideshowContentOptional =  slideshowRepository.findById(slideshowId);
//
//        Optional<Campaign> campaignOptional = campaignRespository.findById(campaignId);
//        if (!campaignOptional.isPresent()){
//            System.out.println("campaign id not found. Id: " + campaignId);
//        }
//        Campaign campaign = campaignOptional.get();
//
//        Optional<SlideshowEntry> slideshowEntryOptional = campaign.getContents().stream()
//                .filter(content -> content.getId().equals(slideshowId))
//                .map( content -> authorToAuthorCommand.convert(author)).findFirst();
//
//        if(!authorCommandOptional.isPresent()){
//            System.out.println("Author id not found: " + authorId);
//        }
//
//        return authorCommandOptional.get();
//        //AuthorCommand authorCommand = authorToAuthorCommand.convert(authorOptional.get());
//        //return authorCommand;
//    }
//

    }

}
