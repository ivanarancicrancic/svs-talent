package de.diefuturisten.easyr.easyrapi.security;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.HEADER_STRING;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.TOKEN_PREFIX;

@Component
@Service
@Transactional
public class JWTAuthorizationFilter extends BasicAuthenticationFilter {

    //private UserDetailsService userDetailsService;
    private final UserRepository userRepository;

//    public JWTAuthorizationFilter(AuthenticationManager authenticationManager, @Qualifier("customUserDetailsService") UserDetailsService userDetailsService) {
//        super(authenticationManager);
//        this.userDetailsService = userDetailsService;
//    }
public JWTAuthorizationFilter(AuthenticationManager authenticationManager, UserRepository userRepository) {
    super(authenticationManager);
    this.userRepository = userRepository;
}



//    @Override
//    protected void doFilterInternal(HttpServletRequest req,
//                                    HttpServletResponse res,
//                                    FilterChain chain) throws IOException, ServletException {
//        String header = req.getHeader(HEADER_STRING);
//
//        if (header == null || !header.startsWith(TOKEN_PREFIX)) {
//            chain.doFilter(req, res);
//            return;
//        }
//
//        try {
//            UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
//            SecurityContextHolder.getContext().setAuthentication(authentication);
//            chain.doFilter(req, res);
//        } catch(IOException | ServletException ex) {
//            res.setStatus(401);
//        }
//    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader(HEADER_STRING);

        if( header == null || !header.startsWith(TOKEN_PREFIX) ){
            chain.doFilter(req, res);
            return;
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(req);
        if( authentication == null ){
            // when not being able to get auth, just reject this here without further processing
            res.setStatus(401);
            return;
        }

        // when reaching this, everything went okay
        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }


//    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
//        String token = request.getHeader(HEADER_STRING);
//        if (token != null) {
//            String username = TokenHelper.userFromToken(token);
//            if (username != null) {
//                try {
//                    UserDetails user = userDetailsService.loadUserByUsername(username);
//                    return new UsernamePasswordAuthenticationToken(username, null, user.getAuthorities());
//                } catch(NoSuchElementException ex) {
//                    // NO-OP
//                }
//            }
//        }
//        return null;
//    }

    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request) {
        String token = request.getHeader(HEADER_STRING);
        if( token == null ){
            return null;
        }

        String username = TokenHelper.userFromToken(token);
        if( username == null ){
            return null;
        }

        Optional<User> storedUser = userRepository.findByEmail(username);
        return storedUser
                .map(user -> new UsernamePasswordAuthenticationToken(username, null, getAuthorities(user)))
                .orElse(null);
    }

    private Collection<? extends GrantedAuthority> getAuthorities(User user) {
        if( user == null || !user.isActive() ){
            return Collections.emptyList();
        }
        return user.getRoles()
                .stream()
                .map(userRoleAssociation -> userRoleAssociation.getRights())
                .flatMap(Collection::stream)
                .map(userRight -> new SimpleGrantedAuthority(userRight.getName()))
                .collect(Collectors.toList());
    }


}
