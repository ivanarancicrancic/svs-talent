package de.diefuturisten.easyr.easyrapi.security;

public class BuiltInRights {

    public static final String CAMPAIGN_CREATE = "dummy admin role";
    public static final String CAMPAIGN_DELETE = "dummy rule";
    public static final String CAMPAIGN_LIST = "dummy standard rule";

    private BuiltInRights() {
        // NO-OP utility class
    }

}
