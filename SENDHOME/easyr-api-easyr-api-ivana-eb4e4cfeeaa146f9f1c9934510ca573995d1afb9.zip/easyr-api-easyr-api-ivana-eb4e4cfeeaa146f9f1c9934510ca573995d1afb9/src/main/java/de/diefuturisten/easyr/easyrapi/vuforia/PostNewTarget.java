package de.diefuturisten.easyr.easyrapi.vuforia;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Date;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.cookie.DateUtils;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;


// See the Vuforia Web Services Developer API Specification - https://developer.vuforia.com/resources/dev-guide/adding-target-cloud-database-api

public class PostNewTarget implements TargetStatusListener {

    private String url;
	private String accessKey;
	private String secretKey;

	private TargetStatusPoller targetStatusPoller;
	private final float pollingIntervalMinutes = 0.25f;

	private IPostNewTargetStatusListener postNewTargetStatusListener;

    public PostNewTarget(String url, String accessKey, String secretKey) {
        this.url = url;
        this.accessKey = accessKey;
        this.secretKey = secretKey;
    }

    public String postTarget(String targetName, File file, IPostNewTargetStatusListener listener) throws URISyntaxException, ClientProtocolException, IOException, JSONException {
		HttpPost postRequest = new HttpPost();
		HttpClient client = new DefaultHttpClient();
		postRequest.setURI(new URI(url + "/targets"));
		JSONObject requestBody = new JSONObject();
		
		setRequestBody(requestBody, targetName, file);
		postRequest.setEntity(new StringEntity(requestBody.toString()));
		setHeaders(postRequest); // Must be done after setting the body
		
		HttpResponse response = client.execute(postRequest);
		String responseBody = EntityUtils.toString(response.getEntity());
		System.out.println(responseBody);
		
		JSONObject jobj = new JSONObject(responseBody);
		
		String uniqueTargetId = jobj.has("target_id") ? jobj.getString("target_id") : "";
		System.out.println("\nCreated target with id: " + uniqueTargetId);

		// poll status if listener is given
		if(listener != null) {
			this.postNewTargetStatusListener = listener;
			if (uniqueTargetId != null && !uniqueTargetId.isEmpty()) {
				targetStatusPoller = new TargetStatusPoller(pollingIntervalMinutes, uniqueTargetId, accessKey, secretKey, this );
				targetStatusPoller.startPolling();
			}
		}
		
		return uniqueTargetId;
	}
	
	private void setRequestBody(JSONObject requestBody, String targetName, File file) throws IOException, JSONException {
		byte[] image = FileUtils.readFileToByteArray(file);
		requestBody.put("name", targetName); // Mandatory
		requestBody.put("width", 320.0); // Mandatory
		requestBody.put("image", Base64.encodeBase64String(image)); // Mandatory
		requestBody.put("active_flag", 1); // Optional
		// requestBody.put("application_metadata", Base64.encodeBase64String("Vuforia test metadata".getBytes())); // Optional
	}
	
	private void setHeaders(HttpUriRequest request) {
        SignatureBuilder sb = new SignatureBuilder();
        request.setHeader(new BasicHeader("Date", DateUtils.formatDate(new Date()).replaceFirst("[+]00:00$", "")));
        request.setHeader(new BasicHeader("Content-Type", "application/json"));
        request.setHeader("Authorization", "VWS " + accessKey + ":" + sb.tmsSignature(request, secretKey));
    }


	// Called with each update of the target status received by the TargetStatusPoller
	@Override
	public void OnTargetStatusUpdate(TargetState target_state) {
		if (target_state.hasState) {
			
			String status = target_state.getStatus();
			
			System.out.println("Target status is: " + (status != null ? status : "unknown"));
			
			if (target_state.getActiveFlag() && status.equalsIgnoreCase("success")) {
				
				targetStatusPoller.stopPolling();
				
				System.out.println("Target is now in 'success' status");

				if(postNewTargetStatusListener != null) {
					postNewTargetStatusListener.onStatusSuccess(target_state.getTargetId());
				}
			}
		}
	}

	public interface IPostNewTargetStatusListener {
		void onStatusSuccess(String targetId);
	}

}
