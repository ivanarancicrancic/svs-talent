package springwebapp.repository;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import springwebapp.model.TableAtrtributes;

@Component
@Repository
public interface TableAttributeRepository {
    public TableAtrtributes getEnglishTableAttributes();

    public TableAtrtributes getSpanishTableAttributes();

    public TableAtrtributes getGermanTableAttributes();

}
