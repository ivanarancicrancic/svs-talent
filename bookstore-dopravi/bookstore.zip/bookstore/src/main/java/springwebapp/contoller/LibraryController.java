package springwebapp.contoller;



import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1")
public class LibraryController {
//    @Autowired
//    BookService service;
//
//    @Autowired
//    AuthorService service1;
//
//    @RequestMapping(value = "/books", method = RequestMethod.GET)
//    public List<Book> getBooks(){
//        return service.getAllBooks();
//    }
//
//    @RequestMapping(value = "/lib_accounts", method = RequestMethod.GET)
//    public List<Author> getUsers(){
//        return service1.getAllLibAccounts();
//    }
//
//
//    @RequestMapping(value = "/books", method = RequestMethod.POST)
//    @ResponseBody
//    public Book createBook(@RequestParam(value="book_title") String title, @RequestParam(value="book_description") String description){
//        Book book = new Book(title, description);
//        System.out.println("Creating new book!");
//        return service.createBook(book);
//    }
//
//    @RequestMapping(value = "/lib_accounts", method = RequestMethod.POST)
//    @ResponseBody
//    public Author createUser(@RequestParam(value="first_name") String first_name, @RequestParam(value="surname") String surname){
//        Author libraryuser = new Author(first_name, surname);
//        System.out.println("Creating new Library_user!");
//        return service1.createUser(libraryuser);
//    }
//
//    @RequestMapping(value = "/books/{id}", method = RequestMethod.PUT)
//    public @ResponseBody Book update(@PathVariable Long id, @RequestBody Book book){
//        return service.updateBook(id, book);
//    }
//
//    @RequestMapping(value = "/lib_accounts/{id}", method = RequestMethod.PUT)
//    public @ResponseBody
//    Author update(@PathVariable Long id, @RequestBody Author libraryuser){
//        return service1.updateUser(id, libraryuser);
//    }
//
//    @RequestMapping(value = "/books/{id}", method = RequestMethod.DELETE)
//    public Book delete(@PathVariable Long id){
//        return service.deleteBook(id);
//
//    }
//
//
//    @RequestMapping(value = "/lib_accounts/{id}", method = RequestMethod.DELETE)
//    public Author deleteUser(@PathVariable Long id){
//        return service1.deleteUser(id);
//    }
}