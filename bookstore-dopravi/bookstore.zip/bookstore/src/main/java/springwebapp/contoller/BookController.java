package springwebapp.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

/**
 * Created by jt on 5/18/17.
 */
@Controller
public class BookController {

    @Autowired
    BookService bookService;

    @Autowired
    TableAttributeService tableAttributeService;

    public BookController(BookService bookService, TableAttributeService tableAttributeService) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
    }

    @RequestMapping("/books")
    public String getBooks(Model model)
    {
        model.addAttribute("greeting", tableAttributeService.sayGreeting());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }
}
