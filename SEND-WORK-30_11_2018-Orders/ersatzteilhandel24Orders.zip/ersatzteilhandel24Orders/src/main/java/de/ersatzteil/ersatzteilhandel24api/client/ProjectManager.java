package de.ersatzteil.ersatzteilhandel24api.client;

import java.sql.Connection;
import java.util.List;

import de.ersatzteil.ersatzteilhandel24api.database.Database;
import de.ersatzteil.ersatzteilhandel24api.database.Project;

import de.ersatzteil.ersatzteilhandel24api.model.Order;

public class ProjectManager {

    public List<Order> getOrderList() throws Exception {
        List<Order> order_items = null;
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_items=project.getOrderList(connection);
           for(Order order: order_items)
            System.out.println(order.getAdditionalInnfo());

        } catch (Exception e) {
            throw e;
        }
        return order_items;
    }


    public Order insertOrder(Order order)  throws Exception {
        Order order_item= new Order();
        try {
            Database database= new Database();
            Connection connection = database.Get_Connection();
            Project project= new Project();
            order_item=project.insertOrder(connection, order);

        } catch (Exception e) {
            throw e;
        }
        return order_item;
    }


//
//    public boolean UpdateSavedTreatment(List<TreatmentItem> t_items, int p_savedtreatmentid, String security_token) throws Exception
//    {
//        boolean flag;
//        try{
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            flag=project.UpdateSavedTreatment(connection, t_items, p_savedtreatmentid, security_token);
//        }
//
//        catch (Exception e) {
//            throw e;
//        }
//        return flag;
//    }
//
//
//
//    public boolean AddContactPatient(Integer providerid, String telephoneNumber, String firstName,
//                                     String lastName, String ChatId, String RoomId, String security_token) throws Exception {
//        boolean flag;
//        try {
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            flag=project.AddContactPatient(connection, providerid, telephoneNumber, firstName, lastName, ChatId, RoomId, security_token);
//
//        } catch (Exception e) {
//            throw e;
//        }
//        return flag;
//    }
//
//
//
//    public Patients getPatientData(int patientId, String security_token) throws Exception {
//        Patients t_items = null;
//        try {
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            t_items=project.getPatientsData(connection,patientId, security_token);
//
//        } catch (Exception e) {
//            throw e;
//        }
//        return t_items;
//    }
//
//    public SavedTemplate DeleteSavedTemplate(@PathParam("savedtreatmentdetail")int savedtreatmentdetail,@PathParam("savedtreatmenttemplateid")int savedtreatmenttemplateid, String security_token)throws Exception
//    {
//        SavedTemplate t_items= new SavedTemplate();
//        try {
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            t_items=project.DeleteSavedTemplate(connection, savedtreatmentdetail,savedtreatmenttemplateid, security_token);
//
//        } catch (Exception e) {
//            throw e;
//        }
//        return t_items;
//    }
//
//
//
//    public boolean EndTreatment(int ActiveTreatmentId, String security_token) throws Exception
//    {
//        boolean flag;
//        try{
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            flag=project.EndTreatment(connection, ActiveTreatmentId, security_token);
//        }
//        catch (Exception e) {
//            throw e;
//        }
//
//        return flag;
//    }
//
//
//    public boolean deleteProviderPatient( int ProviderDetail, int PatientDetail, String security_token) throws Exception
//    {
//        boolean flag;
//        try{
//            Database database= new Database();
//            Connection connection = database.Get_Connection();
//            Project project= new Project();
//            flag=project.deleteProviderPatient(connection, ProviderDetail, PatientDetail, security_token);
//        }
//        catch (Exception e) {
//            throw e;
//        }
//
//        return flag;
//    }
//

}
