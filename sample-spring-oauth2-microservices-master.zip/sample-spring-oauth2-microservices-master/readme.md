## Microservices security with Oauth2

Detailed description can be found here: [Microservices security with Oauth2](https://piotrminkowski.wordpress.com/2017/02/22/microservices-security-with-oauth2/) 


