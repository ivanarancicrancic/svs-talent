package de.diefuturisten.easyr.easyrapi.model.request;

public class AudioContentReturn extends ContentReturn {

    String url;

    String renderOnTrackingLost;

    public AudioContentReturn(){}

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(String renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }
}
