package de.diefuturisten.easyr.easyrapi.model.request;

public class MovieContentReturn extends ContentReturn{

    enum Type { NORMAL, GREENSCREEN, SPHERE }

    Type type;

    String url;

    String download;

    String seekbar;

    float positionX = 0.0f;

    float positionY = 0.0f;

    float positionZ = 0.0f;

    float rotationX = 0.0f;

    float rotationY = 0.0f;

    float rotationZ = 0.0f;

    float scaleX = 0.0f;

    float scaleY = 0.0f;

    float scaleZ = 0.0f;

    String renderOnTrackingLost;

    String extendedTracking;

    public MovieContentReturn(){}

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getDownload() {
        return download;
    }

    public void setDownload(String download) {
        this.download = download;
    }

    public String getSeekbar() {
        return seekbar;
    }

    public void setSeekbar(String seekbar) {
        this.seekbar = seekbar;
    }

    public float getPositionX() {
        return positionX;
    }

    public void setPositionX(float positionX) {
        this.positionX = positionX;
    }

    public float getPositionY() {
        return positionY;
    }

    public void setPositionY(float positionY) {
        this.positionY = positionY;
    }

    public float getPositionZ() {
        return positionZ;
    }

    public void setPositionZ(float positionZ) {
        this.positionZ = positionZ;
    }

    public float getRotationX() {
        return rotationX;
    }

    public void setRotationX(float rotationX) {
        this.rotationX = rotationX;
    }

    public float getRotationY() {
        return rotationY;
    }

    public void setRotationY(float rotationY) {
        this.rotationY = rotationY;
    }

    public float getRotationZ() {
        return rotationZ;
    }

    public void setRotationZ(float rotationZ) {
        this.rotationZ = rotationZ;
    }

    public float getScaleX() {
        return scaleX;
    }

    public void setScaleX(float scaleX) {
        this.scaleX = scaleX;
    }

    public float getScaleY() {
        return scaleY;
    }

    public void setScaleY(float scaleY) {
        this.scaleY = scaleY;
    }

    public float getScaleZ() {
        return scaleZ;
    }

    public void setScaleZ(float scaleZ) {
        this.scaleZ = scaleZ;
    }

    public String getRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(String renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }

    public String getExtendedTracking() {
        return extendedTracking;
    }

    public void setExtendedTracking(String extendedTracking) {
        this.extendedTracking = extendedTracking;
    }
}
