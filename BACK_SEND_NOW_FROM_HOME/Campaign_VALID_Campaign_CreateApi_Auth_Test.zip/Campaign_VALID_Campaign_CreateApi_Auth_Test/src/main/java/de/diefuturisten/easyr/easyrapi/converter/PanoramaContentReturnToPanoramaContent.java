package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.model.request.PanoramaContentReturn;
import org.springframework.core.convert.converter.Converter;

public class PanoramaContentReturnToPanoramaContent implements Converter<PanoramaContentReturn, PanoramaContent> {

    public PanoramaContentReturnToPanoramaContent(){}

    @Override
    public PanoramaContent convert(PanoramaContentReturn source) {

          PanoramaContent panoramaContent = new PanoramaContent();

          panoramaContent.setId(source.getId());

          panoramaContent.setWeight(source.getWeight());

          panoramaContent.setName(source.getName());
          panoramaContent.setType(null);
          panoramaContent.setUrl(source.getUrl());
       return panoramaContent;
    }

    }
