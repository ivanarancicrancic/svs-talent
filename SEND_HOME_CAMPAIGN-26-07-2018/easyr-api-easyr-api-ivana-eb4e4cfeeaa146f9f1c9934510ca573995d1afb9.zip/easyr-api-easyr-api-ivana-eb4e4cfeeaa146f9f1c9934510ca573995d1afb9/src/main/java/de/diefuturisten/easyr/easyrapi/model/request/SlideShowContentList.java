package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;

import java.util.List;

public class SlideShowContentList {

    private List<SlideshowContent> slideshowContentList;

    public SlideShowContentList(List<SlideshowContent> slideshowContentList) {
        this.slideshowContentList = slideshowContentList;
    }

    public List<SlideshowContent> getSlideshowContentList() {
        return slideshowContentList;
    }

    public void setSlideshowContentList(List<SlideshowContent> slideshowContentList) {
        this.slideshowContentList = slideshowContentList;
    }
}
