package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.repository.SphereContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Component
@Transactional
public class SphereContentService {

    @Autowired
    private SphereContentRepository sphereContentRepository;

    public SphereContentService(SphereContentRepository sphereContentRepository) {
        this.sphereContentRepository = sphereContentRepository;
    }

    public List<SphereContent> findAllSpheres(){
        return sphereContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public SphereContent findById(Long id){
        Optional<SphereContent> optionalContent =sphereContentRepository.findById(id);
        if(optionalContent.isPresent()) {
            return optionalContent.get();
        }
        return null;
    }

    public SphereContent findByName(String name){
        return sphereContentRepository.findByName(name).get();
    }

    public SphereContent saveSphereContent(SphereContent sphereContent){
        sphereContentRepository.save(sphereContent);
        return sphereContent;
    }

    public void deleteSphereContent(SphereContent sphereContent){
        sphereContentRepository.delete(sphereContent);
    }

    public void deleteSphereContentBySphereId(Long id){
        sphereContentRepository.deleteById(id);
    }

    public SphereContent createSphere(SphereContent sphereContent){
        sphereContentRepository.save(sphereContent);
        SphereContent savedSphere = sphereContentRepository.findById(sphereContent.getId()).get();
        return savedSphere;
    }

    public void deleteSphere(Long id){
        String status = "deleting sphere";
        System.out.println(status);
        sphereContentRepository.deleteById(id);

    }

}


