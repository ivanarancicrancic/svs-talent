# easy|R Backend API

## Requirements

* Java 1.8
* Maven
* PostgreSQL 9.6

## Database Setup

> createuser -P easyrdb

> createdb easyrdb

> psql easyrdb

> grant all privileges on database easyrdb to easyrdb;

## Spring Boot Configuration

Use either environment variables or _application.properties_ file to configure database, logging, email, etc.

### Environment variables

> export SPRING_DATASOURCE_URL="jdbc:postgresql://localhost:5432/easyrdb"

> export SPRING_DATASOURCE_USERNAME="easyrdb"

> export SPRING_DATASOURCE_PASSWORD="easyrdb"

### Properties

[External Config](https://docs.spring.io/spring-boot/docs/current/reference/html/boot-features-external-config.html)

Database:

> spring.datasource.platform=postgres

> spring.datasource.url=jdbc:postgresql://localhost:5432/easyrdb

> spring.datasource.username=easyrdb

> spring.datasource.password=easyrdb

> spring.datasource.driverClassName=org.postgresql.Driver

Logging:

> logging.file=/var/log/easyr-api/application.log

Frontend URL:

> easyr.frontend.url=http://localhost:3000

E-Mail:

> easyr.email.enable=true

> easyr.email.from.mail=easyr@app-logik.de

> easyr.email.from.name=easy|R

> spring.mail.host=

> spring.mail.port=

> spring.mail.username=

> spring.mail.password=

> spring.mail.properties.mail.smtp.auth=

> spring.mail.properties.mail.smtp.starttls.enable=

> spring.mail.properties.mail.smtp.starttls.required=

## Run

Using Maven:

> ./mvnw clean spring-boot:run

From Fatjar:

> ./mvnw clean install

> cd target

> java -jar easyr-api-0.0.1-SNAPSHOT.jar