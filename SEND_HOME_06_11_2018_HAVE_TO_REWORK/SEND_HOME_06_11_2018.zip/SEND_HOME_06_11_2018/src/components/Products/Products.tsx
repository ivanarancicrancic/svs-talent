import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';
import { productListFetch } from '../../redux/product-list/actions';
import { IProductResponseModel } from '../../redux/product-list/types';
import { getProductList } from '../../redux/product-list/selectors';
import { productCreateFetch } from '../../redux/product-list/actions';


import ProductContent from './ProductContent';

export interface ICollapseExampleState {
    isOpen?: boolean;
};


interface IPropsDispatchMap {
    productListFetch: typeof productListFetch;
    productCreateFetch: typeof productCreateFetch;
}
interface IPropsStateMap {
    productsData: IProductResponseModel[] | null;
    productCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


class Products extends React.Component<IProps, ICollapseExampleState> {

    public state = {
        isOpen: false,
    };

    public componentWillMount() {
        this.props.productListFetch();
      }

    public componentWillReceiveProps(nextProps: IProps) {

        // const productCreated = this.props.productCreating === true && nextProps.productCreating === false;
        // if(productCreated) {
        //     history.push(`/product/${nextProps.lastCreatedId}`);
        // }
    }
    

    public render():any {


        if(this.props.productsData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table">
                <tbody>
                    <tr>
                    {this.props.productsData.map( product => {
                        return (
                            <div className="slideshow">
                            <ProductContent />
                        </div>
                        )
                    })}
                  </tr>
                </tbody>
                </table>
            </div>
        )

    }


    private handleClick = () => {
        this.setState({ isOpen: !this.state.isOpen });
    }

}

const mapStateToProps = (state: IRootState) => ({
    productsData: getProductList(state),
    productCreating: state.product.createLoading,
    lastCreatedId: state.product.lastCreatedId,
});

export default connect(mapStateToProps, {productListFetch, productCreateFetch})(Products)