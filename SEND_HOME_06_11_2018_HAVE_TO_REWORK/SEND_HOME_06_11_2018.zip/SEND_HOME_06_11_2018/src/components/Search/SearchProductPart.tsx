import * as React from 'react';
import SearchProductPartBasic from './SearchProductPartBasic/SearchProductPartBasic';

export default class SearchProductPart extends React.Component {

    public render() {
        return (
            <div className="createCategory">
                <SearchProductPartBasic />
            </div>
        )
    }

}