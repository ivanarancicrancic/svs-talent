import { createLogic } from 'redux-logic';
import axios from 'axios';

import { CATEGORY_DETAIL_FETCH, IProductDetailResponseModel, CATEGORY_CREATE_FETCH, CATEGORY_SAVE_FETCH, CATEGORY_EDIT_FETCH, PRODUCTPART_CREATE_FETCH, IProductResponseModel, PRODUCT_DELETE_FETCH, PRODUCT_EDIT_FETCH,  PRODUCT_RENAME_FETCH} from './types';
import { productDetailFetch, productDetailSuccess, productDetailFail, productCreateSuccess, productCreateFail, productCreateFetch, productSaveFetch, productSaveSuccess, productSaveFail, productEditFetch, productPartCreateFetch, productPartCreateSuccess, productPartCreateFail, productPartDeleteFetch, productPartDeleteSuccess, productPartDeleteFail, productPartEditFetch, productPartEditSuccess, productPartEditFail, productPartRenameFetch, productPartRenameSuccess, productPartRenameFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const categoryDetailFetchLogic = createLogic({
    type: CATEGORY_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productDetailFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/category/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productDetailSuccess(result));
            }).catch(error => {
                dispatch(productDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productCreateFetchLogic = createLogic({
    type: PRODUCT_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productCreateSuccess(result));
            }).catch(error => {
                dispatch(productCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productSaveFetchLogic = createLogic({
    type: PRODUCT_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productSaveFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.productId}/save`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { packageId: action.payload.packageId }
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productSaveSuccess(result));
            }).catch(error => {
                dispatch(productSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const prodictEditFetchLogic = createLogic({
    type: PRODICT_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productSaveSuccess(result));
            }).catch(error => {
                dispatch(productSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productPartDeleteFetchLogic = createLogic({
    type: PRODUCTPART_DELETE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartDeleteFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'delete',
                url: API_ROOT + `/api/category/product/${action.payload.productId}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                dispatch(productPartDeleteSuccess({productId: action.payload.productId}));
            }).catch(error => {
                dispatch(productPartDeleteFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productPartCreateLogic = createLogic({
    type: PRODUCTPART_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.categoryId}/product`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productPartCreateSuccess(result));
            }).catch(error => {
                dispatch(productPartCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productEditLogic = createLogic({
    type: PRODUCT_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productEditSuccess(result));
            }).catch(error => {
                dispatch(productEditFail("fail"));
            });

        } else {
            done();
        }
    }
});


export const productRenameLogic = createLogic({
    type: PRODUCT_RENAME_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartRenameFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.productId}/name`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { name: action.payload.name }
            }).then(response => {
                const result = response.data as IProductPartResponseModel;
                dispatch(productPartRenameSuccess(result));
            }).catch(error => {
                dispatch(productPartRenameFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    productDetailFetchLogic,
    productCreateFetchLogic,
    productSaveFetchLogic,
    productEditFetchLogic,
    productPartDeleteFetchLogic,
    productPartCreateLogic,
    productPartEditLogic,
    productPartRenameLogic
];
