export const CATEGORY_DETAIL_FETCH = '@@user/category/detail/FETCH';
export const CATEGORY_DETAIL_SUCCESS = '@@user/category/detail/SUCCESS';
export const CATEGORY_DETAIL_FAIL = '@@user/category/detail/FAIL';

export const CATEGORY_CREATE_FETCH = '@@category/create/FETCH';
export const CATEGORY_CREATE_SUCCESS = '@@category/create/SUCCESS';
export const CATEGORY_CREATE_FAIL = '@@category/create/FAIL';

export const CATEGORY_SAVE_FETCH = '@@category/save/FETCH';
export const CATEGORY_SAVE_SUCCESS = '@@category/save/SUCCESS';
export const CATEGORY_SAVE_FAIL = '@@category/save/FAIL';

export const CATEGORY_EDIT_FETCH = '@@category/edit/FETCH';
export const CATEGORY_EDIT_SUCCESS = '@@category/edit/SUCCESS';
export const CATEGORY_EDIT_FAIL = '@@category/edit/FAIL';

export const PRODUCT_UPLOAD_FETCH = '@@category/product/upload/FETCH';
export const PRODUCT_UPLOAD_SUCCESS = '@@category/product/upload/SUCCESS';
export const PRODUCT_UPLOAD_FAIL = '@@category/product/upload/FAIL';

export const PRODUCT_DELETE_FETCH = '@@category/product/delete/FETCH';
export const PRODUCT_DELETE_SUCCESS = '@@category/product/delete/SUCCESS';
export const PRODUCT_DELETE_FAIL = '@@category/product/delete/FAIL';

export const PRODUCTPART_DELETE_FETCH = '@@category/productPart/delete/FETCH';
export const PRODUCTPART_DELETE_SUCCESS = '@@category/productPart/delete/SUCCESS';
export const PRODUCTPART_DELETE_FAIL = '@@category/productPart/delete/FAIL';

export const PRODUCTPART_CREATE_FETCH = '@@category/productPart/create/FETCH';
export const PRODUCTPART_CREATE_SUCCESS = '@@category/productPart/create/SUCCESS';
export const PRODUCTPART_CREATE_FAIL = '@@category/productPart/create/FAIL';

export const PRODUCTPART_EDIT_FETCH = '@@category/productPart/edit/FETCH';
export const PRODUCTPART_EDIT_SUCCESS = '@@category/productPart/edit/SUCCESS';
export const PRODUCTPART_EDIT_FAIL = '@@category/productPart/edit/FAIL';

export const PRODUCTPART_RENAME_FETCH = '@@category/product/renamePart/FETCH';
export const PRODUCTPART_RENAME_SUCCESS = '@@category/productPart/rename/SUCCESS';
export const PRODUCTPART_RENAME_FAIL = '@@category/productPart/rename/FAIL';

// PRODUCT_PART
export interface IProductPartResponseModel {
    id: number;
    url: string;
}

// PRODUCT
type ProductType =  'KITCHEN';

export interface IProduct1ResponseModel {
    id: number;
    type: ProductType;
    name: string;
    weight: number;
}

// PRODUCT TYPES
export type ProductSubtype = 'KITCHEN' | 'HOUSE';

interface IProductFields {
    subType: ProductSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IProductResponseModel extends IProduct1ResponseModel, IProductFields {}

export interface IProductRequestModel extends IProductFields {
    id?: number;
    name: string;
}


// CATEGORY
export interface IProductDetailResponseModel {
    id: number;
    name: string;
    description: string;
    productPart: IProductPartResponseModel[];
    products: IProductResponseModel[]
    temporary: boolean;
    activePackageId: number | null
};