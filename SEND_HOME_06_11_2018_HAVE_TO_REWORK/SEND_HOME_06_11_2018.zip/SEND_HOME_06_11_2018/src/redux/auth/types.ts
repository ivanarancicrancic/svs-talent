export const LOGIN_USER_FETCH = '@@login/FETCH';
export const LOGIN_USER_SUCCESS = '@@login/SUCCESS';
export const LOGIN_USER_FAIL = '@@login/FAIL';
export const LOGIN_LOGOUT = '@@login/LOGOUT';

export interface IJWTokenContent {
    exp: number;
    sub: string;
};
  
export interface IJWToken {
    token: string;
    content: IJWTokenContent;
};