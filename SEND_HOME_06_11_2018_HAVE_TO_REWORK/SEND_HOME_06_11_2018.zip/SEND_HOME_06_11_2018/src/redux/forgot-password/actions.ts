import {
    FORGOT_PASSWORD_FETCH, FORGOT_PASSWORD_SUCCESS, FORGOT_PASSWORD_FAIL,
    RESET_PASSWORD_FETCH, RESET_PASSWORD_SUCCESS, RESET_PASSWORD_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IForgotPasswordFormData, IResetPasswordFormData } from '../forms';

export const forgotPasswordFetch = createStandardAction(FORGOT_PASSWORD_FETCH)<IForgotPasswordFormData>();
export const forgotPasswordSuccess = createStandardAction(FORGOT_PASSWORD_SUCCESS)();
export const forgotPasswordFail = createStandardAction(FORGOT_PASSWORD_FAIL)<string>();

export const resetPasswordFetch = createStandardAction(RESET_PASSWORD_FETCH)<IResetPasswordFormData>();
export const resetPasswordSuccess = createStandardAction(RESET_PASSWORD_SUCCESS)();
export const resetPasswordFail = createStandardAction(RESET_PASSWORD_FAIL)<string>();