import * as React from 'react';

import { connect } from 'react-redux';
import {IRegisterFormData} from "../../redux/forms";
import {IRootState} from "../../redux";
import RegisterForm from "../../components/Forms/Register/RegisterForm";
import './RegisterContainer.css';
import { registerFetch } from '../../redux/register/actions';
import { RouteComponentProps } from 'react-router';
import { getRegisterIsLoading, getRegisterHasError } from '../../redux/register/selectors';
import { PATH_REGISTER_COMPLETE } from '../../router/paths';

interface IPropsDispatchMap {
    registerFetch: typeof registerFetch;
}

interface IPropsStateMap {
    registerIsLoading: boolean;
    registerHasError: string | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{}>;

class RegisterContainer extends React.Component<IProps> {

    public componentWillReceiveProps(nextProps: IProps) {
        const loadingFinished = (this.props.registerIsLoading === true && nextProps.registerIsLoading === false);
        const withoutErrors = nextProps.registerHasError == null;
        if(loadingFinished && withoutErrors) {
            this.props.history.replace(PATH_REGISTER_COMPLETE);
        }
    }

    public render() {
        return (
            <div className="grid80">
                <div>
                    <RegisterForm onSubmit={this.onSubmitRegisterForm} />
                </div>
            </div>
        )
    }

    private onSubmitRegisterForm = (values: IRegisterFormData) => {
        this.props.registerFetch(values);
    }

}

const mapStateToProps = (state: IRootState) => ({
    registerIsLoading: getRegisterIsLoading(state),
    registerHasError: getRegisterHasError(state)
});

export default connect(mapStateToProps, {registerFetch})(RegisterContainer)