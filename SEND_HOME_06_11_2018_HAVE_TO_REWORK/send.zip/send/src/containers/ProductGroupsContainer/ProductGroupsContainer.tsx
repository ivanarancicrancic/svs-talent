import * as React from 'react';
import Products from '../../components/ProductGroupsLayout/ProductGroupsLayout';


export default class ProductGroupsContainer extends React.Component {

    public render():any {
        return (
            <div>
                <Products />
            </div>
        )
    }
}