import * as React from 'react';
import './HamburgerMenu.css';
import {Link, NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD} from "../../router/paths";
import { userSelfInfoFetch } from '../../redux/user-self-info/actions';
import { getUserSelfInfo } from '../../redux/user-self-info/selectors';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { IUserResponseModel } from '../../redux/user-self-info/types';
import { categoryCreateFetch } from '../../redux/category/actions';

import { history } from '../../router';
import { IJWToken } from '../../redux/auth/types';
import { Translate } from 'react-redux-i18n';

interface IPropsDispatchMap {
    userSelfInfoFetch: typeof userSelfInfoFetch;
    categoryCreateFetch: typeof categoryCreateFetch;
}

interface IPropsStateMap {
    userInfo: IUserResponseModel | null;
    categoryCreating: boolean;
    lastCreatedId: number | null;
    token: IJWToken | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class HamburgerMenu extends React.Component<IProps> {

    public componentWillMount() {
        if(this.props.token != null) {
            this.props.userSelfInfoFetch();
        }
    }

    public renderUser() {

        if(this.props.userInfo == null) {
            return;
        }

        return <span className="userInfo"> 
                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">{this.props.userInfo.name} 
                    <i  className="fontello icon-user" />
                </NavLink></span>;
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const categoryCreated = this.props.categoryCreating === true && nextProps.categoryCreating === false;
        if(categoryCreated) {
            history.push(`/category/${nextProps.lastCreatedId}`);
        }
    }

    public render() {
        return (
            <div>
              
                <nav role="navigation">
                <div className="menuToggle">
                    <input type="checkbox" />
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                        <ul className="menu">
                            {this.props.token && this.renderUser()}
                            <Link to={PATH_ROOT} className="bp3-navbar-heading">1 >> <Translate value="header.account" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">2 >> <Translate value="header.buy-category" /></Link>
                            {this.props.categoryCreating && <a className="bp3-navbar-heading" onClick={(e) => { e.preventDefault(); }}> Loading ... </a> || <a className="bp3-navbar-heading" onClick={(e) => { e.preventDefault(); if(this.props.token != null) { this.props.categoryCreateFetch() } }}> <span> 3 >> </span><Translate value="header.create-category" /></a>}
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">4 >> <Translate value="header.administration" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">5 >> <Translate value="header.statistics" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">6 <Translate value="header.push" /></Link>
                            <div className="searchBtn"> <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span> </div>
                        </ul>
                </div>
                </nav>
            </div>
        );
    }
}

const mapStateToProps = (state: IRootState) => ({
    userInfo: getUserSelfInfo(state),
    categoryCreating: state.category.createLoading,
    lastCreatedId: state.category.lastCreatedId,
    token: state.auth.token
});

export default connect(mapStateToProps, {userSelfInfoFetch, categoryCreateFetch})(HamburgerMenu)