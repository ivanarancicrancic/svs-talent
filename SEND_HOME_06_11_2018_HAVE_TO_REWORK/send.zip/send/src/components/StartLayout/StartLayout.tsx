import * as React from 'react';
import { Link } from "react-router-dom";
import { connect } from 'react-redux';

import './StartLayout.css';
import { IRootState } from '../../redux';
import { categoryListFetch } from '../../redux/category-list/actions';
import { ICategoryResponseModel } from '../../redux/category-list/types';
import { getCategoryList } from '../../redux/category-list/selectors';
import { categoryCreateFetch } from '../../redux/category/actions';
import { PATH_CATEGORY_DETAIL, PATH_CATEGORY_EDIT } from '../../router/paths'; 

import { history } from '../../router';

interface IPropsDispatchMap {
    categoryListFetch: typeof categoryListFetch;

    categoryCreateFetch: typeof categoryCreateFetch;
}
interface IPropsStateMap {
    categoryData: ICategoryResponseModel[] | null;
    categoryCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.categoryListFetch();
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const categoryCreated = this.props.categoryCreating === true && nextProps.categoryCreating === false;
        if(categoryCreated) {
            history.push(`/category/${nextProps.lastCreatedId}`);
        }
    }


    public renderCategoryList() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <tbody>
                    <tr>
                    {this.props.categoryData.map( category => {
                        return (
                            <tr key={category.id}>
                                <Link to={PATH_CATEGORY_EDIT}><td><b>{category.name} Kategorieeee</b>   </td> </Link>
                                <td>{category.numberOfViews} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </td>
                                <td><Link to={PATH_CATEGORY_EDIT} className="fontello icon-edit"/> </td>
                            </tr>
                        )
                    })}
                  </tr>
                    <tr>
                    <td colSpan={5} className="text-center" >
                        {!this.props.categoryCreating && <a onClick={ () => {this.props.categoryCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
              
                {this.renderCategoryList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    categoryData: getCategoryList(state),

    categoryCreating: state.category.createLoading,
    lastCreatedId: state.category.lastCreatedId,
});

export default connect(mapStateToProps, {categoryListFetch, categoryCreateFetch})(DashboardLayout)