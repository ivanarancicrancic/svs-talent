import { IRootState } from '..'

export const getProductList = (state: IRootState) => state.productList.data;
export const getProductListIsLoading = (state: IRootState) => state.productList.loading;
export const getProductListHasError = (state: IRootState) => state.productList.error;