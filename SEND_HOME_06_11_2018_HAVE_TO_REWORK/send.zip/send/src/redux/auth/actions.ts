import {
    LOGIN_USER_FETCH,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,  
    LOGIN_LOGOUT,  
    IJWToken
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const loginUserFetch = createStandardAction(LOGIN_USER_FETCH)<{username: string, password: string}>();
export const loginUserSuccess = createStandardAction(LOGIN_USER_SUCCESS)<IJWToken>();
export const loginUserFail = createStandardAction(LOGIN_USER_FAIL)<string>();
export const loginLogout = createStandardAction(LOGIN_LOGOUT)<void>();
