import { IRootState } from '..'

export const getCategoryList = (state: IRootState) => state.categoryList.data;
export const getCategoryListIsLoading = (state: IRootState) => state.categoryList.loading;
export const getCategoryListHasError = (state: IRootState) => state.categoryList.error;