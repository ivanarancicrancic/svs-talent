export const REGISTER_FETCH = '@@register/FETCH';
export const REGISTER_SUCCESS = '@@register/SUCCESS';
export const REGISTER_FAIL = '@@register/FAIL';