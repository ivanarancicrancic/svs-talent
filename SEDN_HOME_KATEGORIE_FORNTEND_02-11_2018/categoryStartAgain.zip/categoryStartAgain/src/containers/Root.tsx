import * as React from 'react';

import { Provider } from 'react-redux';
import { ConnectedRouter } from 'react-router-redux';
import { PersistGate } from 'redux-persist/integration/react';

import { history } from '../router';
import { store, persistor } from '../redux/store';

import App from './App/App'

import PrivateRoute from '../router/PrivateRoute';

import { Switch, Route } from 'react-router';
import PreAuthContainer from './PreAuthContainer/PreAuthContainer';

import { PATH_ROOT, PATH_LOGIN, PATH_REGISTER, PATH_REGISTER_COMPLETE, PATH_FORGOT_PASSWORD_REQUEST, PATH_FORGOT_PASSWORD_RESET} from '../router/paths';

class Root extends React.Component {
    public render() {
      return (
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <ConnectedRouter history={history}>
            <Switch>
          
              <Route path={PATH_LOGIN} component={PreAuthContainer} />
              <Route path={PATH_REGISTER} component={PreAuthContainer} />
              <Route path={PATH_REGISTER_COMPLETE} component={PreAuthContainer} />
              <Route path={PATH_FORGOT_PASSWORD_REQUEST} component={PreAuthContainer} />
              <Route path={PATH_FORGOT_PASSWORD_RESET} component={PreAuthContainer} />
              <PrivateRoute path={PATH_ROOT} component={App} />
            </Switch>
          </ConnectedRouter>
        </PersistGate>
      </Provider>
      )
    }
}

export default Root;