import * as React from 'react';
import { Position, Tooltip } from "@blueprintjs/core";

export default class ProductContent extends React.Component {

    public render() {
        return (
            <pre>
                <div>
                    <table className="table bp3-html-table">
                        <tbody>
                            <tr>
                                <td>
                                    <form>
                                        <input type="file" name="video" accept=".mp3,audio/*" />
                                    </form>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <form>
                                        <input type="file" name="video" accept=".mp3,audio/*" />
                                    </form>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div className="checkboxes">
                        <label className="bp3-control bp3-checkbox .modifier">
                            <input type="checkbox"  />
                            <span className="bp3-control-indicator"/>
                            Checkbox
                            <Tooltip content="Some info here!" position={Position.TOP}>
                                <span className="bp3-icon-standard bp3-icon-info-sign" />
                            </Tooltip>
                        </label>
                    </div>
                </div>        
            </pre>
        )
    }
}