import * as React from 'react';
import { connect } from 'react-redux';
import {Control, Errors, Form, actions as formActions} from 'react-redux-form';
import {IRegisterFormData} from '../../../redux/forms';

import { maxLength100, maxLength200, maxLength5, maxLength50, minLength3, minLength5, isEmail } from '../validator';
import { IRootState } from '../../../redux';
import { captchaFetch } from '../../../redux/captcha/actions';

import './Register.css';
import { ICaptchaResponseModel } from '../../../redux/captcha/types';
import { Button } from '@blueprintjs/core';

interface IPropsDispatchMap {
    captchaFetch: typeof captchaFetch;
}
interface IPropsStateMap {
    captcha: ICaptchaResponseModel | null;
    captchaIsLoading: boolean;
    registerIsLoading: boolean;
}

interface IOwnProps {
    onSubmit: (values: IRegisterFormData) => void;
}

type IProps = IOwnProps & IPropsDispatchMap & IPropsStateMap;

class RegisterForm extends React.Component<IProps> {

    private formDispatch: any;

    public componentWillMount() {
        this.props.captchaFetch();
    }

    public componentWillUnmount() {
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.register'));
        }
    }

    public onBeforeSubmit(event: any) {
        console.log(event);
    }

    public renderCaptcha() {

        if(this.props.captchaIsLoading) {
            return (<p>Loading Captcha</p>)
        } else if(this.props.captcha != null) {
            return (
                <React.Fragment>
                    <img style={{width: 200, height: 50}} src={`data:image/png;base64,${this.props.captcha.data}`} />
                    <div className="bp3-input-group">
                        <Control
                            model=".captcha"
                            validators={{
                                required: (val) => val && val.length,
                                minLength5,
                                maxLength5,
                            }}
                            component={"input"}
                            controlProps={{
                                className: "bp3-input inputButton",
                                placeholder: "Captcha",
                            }}
                        />
                        <Errors className="arrow_box"
                            model=".captcha"
                            show="touched"
                            messages={{
                                required: 'This field is required. ',
                                minLength5: 'Five characters expected',
                                maxLength5: 'Five characters expected'
                            }}
                        />
                    </div>
                </React.Fragment>
            )
        } else {
            return (<p>Error Loading Captcha</p>)
        }
    }

    public render() {
        return (
            <div className="container">
                <Form
                    model="forms.register"
                    validators={{
                        '': {
                          passwordsMatch: (vals) => vals.password === vals.confirmPassword,
                        },
                      }}
                    validateOn="change"
                    onUpdate={ (form) => {console.log("onUpdate", form);} }
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                <div className="registerBox">
                    <div className="kontoBox">
                        <div className="bottomSeparator">
                            <p>Kontoinformationen</p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16" >
                                <Control.select
                                    model=".title"
                                    className="selectButton inputButton">
                                    <option value="male">Herr</option>
                                    <option value="female">Frau</option>
                                </Control.select>
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".firstName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "Vorname",
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".firstName"
                                    show="touched"
                                    messages={{
                                        required:'This field is required. ',
                                        maxLength50: 'First name is too long'
                                    }}
                                />
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".lastName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "Nachname",
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".lastName"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required. ',
                                        maxLength50: 'Last name is too long'
                                    }}
                                />
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".email"
                                type="email"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength5,
                                    maxLength200,
                                    isEmail
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "E-mail",
                                }}

                            />
                            <Errors className="arrow_box"
                                model=".email"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    isEmail: 'Invalid email address'
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".password"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength5,
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Passwort",
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".password"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    minLength5: 'Please use at least 5 characters',
                                    maxLength50: 'Password is too long',
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".confirmPassword"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "Passwort bestätigen",
                                }}
                            />
                            <Errors className="arrow_box"
                                model="forms.register"
                                show="touched"
                                messages={{
                                    passwordsMatch: 'Passwords do not match.'
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".phoneNumber"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Telefonnumer",
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".phoneNumber"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    minLength5: 'Please use at least 5 characters',
                                    maxLength50: 'Phone number is too long'
                                }}
                            />
                        </div>
                    </div>

                    <div className="kontoBox">
                        <div className="bottomSeparator">
                            <p>Zahlungsinformationen</p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16" >
                            <Control.select
                                    model=".paymentTitle"
                                    className="selectButton inputButton">
                                    <option value="male">Herr</option>
                                    <option value="female">Frau</option>
                                </Control.select>
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".paymentFirstName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "Vorname",
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".paymentFirstName"
                                    show="touched"
                                    messages={{
                                        required:'This field is required. ',
                                        maxLength50: 'First name is too long'
                                    }}
                                />
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".paymentLastName"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "Nachame",
                                    }}
                                />
                                <Errors className="arrow_box"
                                    model=".paymentLastName"
                                    show="touched"
                                    messages={{
                                        required:'This field is required. ',
                                        maxLength50: 'First name is too long'
                                    }}
                                />
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".companyName"
                                validators={{
                                    required: (val) => val && val.length,
                                    minLength3,
                                    maxLength100
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "Firmenname",
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".companyName"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    minLength3: 'Please use at least 3 characters',
                                    maxLength50: 'Company name is too long'
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".streetAddress"
                                validators={{
                                    required: (val) => val && val.length,
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Straße und Hausnummer",
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".streetAddress"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    minLength5: 'Please use at least 5 characters',
                                    maxLength50: 'Street Address is too long'
                                }}
                            />
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16">
                                <Control
                                    model=".zipCode"
                                    validators={{
                                        required: (val) => val && val.length,
                                        minLength5,
                                        maxLength5
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        placeholder: "PLZ",
                                    }}
                                />
                                <Errors className="arrow_box zipCode"
                                    model=".zipCode"
                                    show="touched"
                                    messages={{
                                        required: 'This field is required. ',
                                    }}
                                />
                            </div>
                            <div className="grid84">
                                <Control
                                    model=".city"
                                    validators={{
                                        required: (val) => val && val.length,
                                        maxLength50
                                    }}
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        placeholder: "Ort",
                                    }}
                                />
                                <Errors className="arrow_box bp3-icon-standard bp3-icon-error"
                                    model=".city"
                                    show="touched"
                                    messages={{
                                        required: ' This field is required. ',
                                        minLength5: 'Please use at least 5 characters',
                                        maxLength50: 'City is too long'
                                    }} 
                                />
                            </div>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control.select
                                    model=".country"
                                    className="selectButton inputButton">
                                    <option value="Germany">Deutschland</option>
                                </Control.select>
                            </div>
                            <div className="grid50">
                                <Control.select
                                    model=".state"
                                    className="selectButton inputButton">
                                    <option value="Herr">Bundesland</option>
                                </Control.select>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">
                    <div className="kontoBox">
                        <div className="captcha container">
                            <div className="grid50">
                                {this.props.captcha != null && <img style={{width: 200, height: 50}} src={`data:image/png;base64,${this.props.captcha.data}`} />}
                            </div>
                            <div className="grid50">
                                <div className="bp3-input-group">
                                    <Control
                                        model=".captcha"
                                        validators={{
                                            required: (val) => val && val.length,
                                            minLength5,
                                            maxLength5,
                                        }}
                                        component={"input"}
                                        controlProps={{
                                            className: "bp3-input inputButton secondBg",
                                            placeholder: "Captcha",
                                        }}
                                    />
                                    <Errors className="arrow_box"
                                        model=".captcha"
                                        show="touched"
                                        messages={{
                                            required: 'This field is required. ',
                                            minLength5: 'Five characters expected',
                                            maxLength5: 'Five characters expected'
                                        }}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="kontoBox">
                        <div className="submit container">
                            <div className="grid50">
                            <label className="bp3-control bp3-checkbox bp3-align-right">
                                <input type="checkbox" />
                                <span className="bp3-control-indicator"/>
                                Ich akzeptiere die AGB und die Datenschutzerklärungen.
                            </label>
                            </div>
                            <div className="grid50">
                            <Button type="submit" className="logIn bp3-button bp3-minimal" loading={this.props.registerIsLoading}>Registrieren</Button>
                            </div>
                        </div>
                    </div>
                </div>
                </Form>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        this.formDispatch = dispatch;
    }

}

const mapStateToProps = (state: IRootState) => ({
    captcha: state.captcha.data,
    captchaIsLoading: state.captcha.loading,
    registerIsLoading: state.register.loading
});

export default connect(mapStateToProps, {captchaFetch})(RegisterForm)