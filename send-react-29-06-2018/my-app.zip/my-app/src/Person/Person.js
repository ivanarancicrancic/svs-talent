const  person = () => {
    return <p>I'm awesome!!!</p>

}

export default person;