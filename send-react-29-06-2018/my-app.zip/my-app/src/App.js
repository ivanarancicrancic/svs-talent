import React, { Component } from 'react';
import './App.css';

class App extends Component {
  render() {
  return(
      <div className="App">
          <h1>I'm a React App</h1>
          <p>This is really working!!</p>
      </div>
  );
      // return React.createElement('div', {classname: 'App'}, React.createElement(h1, null, 'I\'m a React component!!!'));
  }
}

export default App;
