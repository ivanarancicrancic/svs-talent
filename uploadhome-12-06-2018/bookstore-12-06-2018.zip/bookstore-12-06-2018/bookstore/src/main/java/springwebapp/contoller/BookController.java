package springwebapp.contoller;

import springwebapp.commands.BookCommand;
import springwebapp.commands.CategoryCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebapp.model.Category;
import springwebapp.repository.CategoryRepository;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

import java.util.List;

/**
 * Created by jt on 5/18/17.
 */
@Controller
public class BookController {

    @Autowired
    BookService bookService;


    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    TableAttributeService tableAttributeService;

    public BookController(BookService bookService, TableAttributeService tableAttributeService, CategoryRepository categoryRepository) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.categoryRepository = categoryRepository;
    }

    @RequestMapping("/books")
    public String getBooks(Model model)
    {
        System.out.println("Entered /books");
        List<BookCommand> books = bookService.getAllBooks();
        if(books==null) {System.out.println("EMPTY BOOKLIST");}
        for(BookCommand b:books){
            System.out.println("Check books");
            if(b.getCategories()==null){System.out.println("Empty categories");}
            for(CategoryCommand c: b.getCategories())
            System.out.println("Book category:" + c.getDescription());
        }



        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }



    @RequestMapping("/findByDescription")
    public String getCategoryByDescription(Model model)
    {
        System.out.println("Entered /findByDescription");
        Category cagetory = categoryRepository.findByDescription("Drama");

        System.out.println("Category id is: " + cagetory.getId() + ", for description: " + cagetory.getDescription());


        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }

    @RequestMapping("/book/show/{id}")
    public String showById(@PathVariable String id, Model model){

        System.out.println("entered book/show/{id}");
        model.addAttribute("book", bookService.findById(new Long(id)));

        return "book/show";
    }


    @RequestMapping("book/create")
    public String createBook(Model model){
        model.addAttribute("book", new BookCommand());
        return "book/bookform";
    }


    @PostMapping("recipe")
    public String saveOrUpdate(@ModelAttribute BookCommand bookCommand){
        BookCommand savedBookCommand = bookService.createBook(bookCommand);

        return "redirect:/book/show/" + savedBookCommand.getId();
    }

}
