package springwebapp.model;

import org.springframework.stereotype.Component;

import javax.persistence.*;

@Entity
@Component
public class Comment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "book")
    private Book book;

    private String comment;

//    public Comment(){}
//
//    public Comment(Book book, String comment) {
//        this.book = book;
//        this.comment = comment;
//    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Book getBook() {
        return book;
    }

    public void setBook(Book book) {
        this.book = book;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
