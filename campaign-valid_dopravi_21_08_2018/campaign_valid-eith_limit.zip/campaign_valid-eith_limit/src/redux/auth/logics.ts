import { createLogic } from 'redux-logic';

import { LOGIN_USER_FETCH } from './types';
import { loginUserFetch, loginUserSuccess, loginUserFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const fetchLoginUserLogic = createLogic({
    type: LOGIN_USER_FETCH,
    latest: true,
  
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(loginUserFetch)(action)) {
            if(action.payload.username === "app" && action.payload.password === "logik") {
                dispatch(loginUserSuccess());
            } else {
                dispatch(loginUserFail());
            }
        }
    }
  });

export default [
    fetchLoginUserLogic
];