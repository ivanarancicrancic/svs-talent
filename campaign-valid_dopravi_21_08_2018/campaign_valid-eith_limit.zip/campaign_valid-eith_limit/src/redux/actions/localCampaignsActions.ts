import { HANDLE_GET_ALL_CAMPAIGNS} from './actionTypes'
import { getFromBackend, postToBackend } from '../../api/api'
import { IRealCampaign} from '../../models/CampaignsModelHelper';

interface ICampaignAction<Action> {
    type: string
    payload?: any
}

interface IRealCampaignData {
    "campaigns": IRealCampaign[] 
}

const realCampaignData:IRealCampaignData = {
    "campaigns": []
}

const getEditedCampaigns = (repResponseData: any, dispatch: any) => {
    const url: string = '/testCampaigns'

    return getFromBackend(url).then(response => {
        dispatch(addressDataSuccess(response.data))
    }).catch(error => {
          dispatch(addressDataFaied(error))
    })
}

/* tslint:disable:no-string-literal */
const editAndGetCampaigns = (name: number) => {
    const url: string = '/campaign/update'
    const data = {
        'id': name
    }
    return (dispatch :any, getState:any) => {  
            return postToBackend(url, data).then( (response:IRealCampaign) => {
                const repData = {
                    edited_campaign: response              
                }
                 getEditedCampaigns(repData, dispatch) 
            }).catch((error:any) => {
                  dispatch(addressDataFaied(error))
            })
    }
}
/* tslint:enable:no-string-literal */

const addressDataSuccess = (addressData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: addressData
    }
}

const addressDataFaied = (error: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: error
    }
}

export {
    editAndGetCampaigns, ICampaignAction, realCampaignData
}