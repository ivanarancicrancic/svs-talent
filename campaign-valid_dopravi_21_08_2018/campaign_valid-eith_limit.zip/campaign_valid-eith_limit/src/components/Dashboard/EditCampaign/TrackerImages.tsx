import * as React from 'react';
import './TrackerImages.css';

export default class TrackerImages extends React.Component {

    public render() {
        return (
            <div className="trackerBox">
                <div className="trackerLeft">
                    <div>
                        <div>
                            <img src="https://dummyimage.com/100x80/141014/fafafa.jpg" />
                            <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                        </div>
                        <div>
                            <img src="https://dummyimage.com/100x80/141014/fafafa.jpg" />
                            <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                        </div>
                        <div>
                            <img src="https://dummyimage.com/100x80/141014/fafafa.jpg" />
                            <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                        </div>
                    </div>
                    <div>
                    <button className="bp3-button bp3-minimal" ><span className="bp3-icon-standard bp3-icon-add" /> </button>
                    </div>
                </div>
                <div className="trackerRight">
                    <div> <img src="https://dummyimage.com/240x200/141014/fafafa.jpg" /> </div>
                    <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                </div>
            </div>
        )
    }

}
