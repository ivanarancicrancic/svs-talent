import * as React from 'react';

export default class Description extends React.Component {

    public render() {
        return (
            <h2>Description</h2>
        )
    }

}