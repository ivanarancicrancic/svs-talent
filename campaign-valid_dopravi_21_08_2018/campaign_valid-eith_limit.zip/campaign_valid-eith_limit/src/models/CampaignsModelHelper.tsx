 import { getRealCampaigns } from '../redux/actions/initialActions';

interface ICampaign {
    id: number
}

const campaignData = {
    "campaigns":[]
}

interface IUser {
    id: string,
    language: string,
    active: string,
    email: string,
    password: string,
    gender: string,
    firstname: string,
    lastname: string
}

interface IContent {
    id: string,
    weight: number,
    name: string
}


interface ITracker {
    id: string,
    vuforiaId: string,
    url: string
}

interface IContactInformation {
    id: string,
    name: string,
    company: string,
    homepage: string,
    email: string,
    address: string,
    address2: string,
    number: string,
    zip: string,
    city: string
}

interface IRealCampaign {
    id: string,
    user: IUser,
    tracker: ITracker[],
    contents: IContent[],
    contact: IContactInformation;
   
}

interface IRealCampaignData {
    "campaigns":IRealCampaign[],

}

const realCampaignData:IRealCampaignData = {
    "campaigns":[]
}

/* tslint:disable:no-string-literal */
getRealCampaigns().then( (response : IRealCampaign[]) => {
    const campaigns = response
    console.log(campaigns)
    realCampaignData['campaigns'] = campaigns
})

const getAllCampaigns = () => { getRealCampaigns().then( (response : IRealCampaign[]) => {
    const campaigns = response
    console.log(campaigns)
    realCampaignData['campaigns'] = campaigns
})
}

/* tslint:enable:no-string-literal */

export {
    campaignData,
    ICampaign,
    IRealCampaign,
    realCampaignData,
    getAllCampaigns
}
