import * as React from 'react';
// import Campaigns from '../../components/Campaigns'

//     class DashboardContainer extends React.Component<any, any> {
//         constructor(props: any) {
//             super(props)
//             this.props = props
//         }
    
//        public render() {
    
//             return (
//                 <div>
//                     {
//                     <Campaigns />
//                      }
                      
//                 </div>
//             )
//         }
//     }
    
//     export default DashboardContainer

/////////////////////
import LocalCampaigns from '../../components/LocalCampaigns'


const SampleCampaigns = () => {
        return (
            <LocalCampaigns />
        )

}

const dashboardDisplay = () => {
    
    return (
        <div>
         {SampleCampaigns()}
                   </div>
    )
}

class DashboardContainer extends React.Component<any, any> {
    constructor(props: any) {
        super(props)
        this.props = props
    }

  public render() {

        return (
            <div> {
                 dashboardDisplay()
                    }
            </div>
        )
    }

}

export default DashboardContainer
    
