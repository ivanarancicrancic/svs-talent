// import { getTeam } from '../redux/actions/initialActions'
 import { getRealCampaigns } from '../redux/actions/initialActions';
// import { addTodo4 } from '../redux/actions/initialActions';


// interface TeamMemberLink {
//     name: string,
//     url: string,
//     position: number
// }

interface ICampaign {
    id: number
}

const campaignData = {
    "campaigns":[],
    // "returnStr": {}
}

interface IUser {
    id: string,
    language: string,
    active: string,
    email : string,
    password: string,
    gender: string,
    firstname: string,
    lastname: string
}

// interface ITracker {
//     id: string,
//     vuforiaId: string,
//     url: string
// }

interface IContent {
    id: string,
    weight: number,
    name: string
}

interface IContactInformation {
    id: string,
    name: string,
    company: string,
    homepage: string,
    email: string,
    address: string,
    address2: string,
    number: string,
    zip: string,
    city: string
}

interface IRealCampaign {
    id: string,
    user: IUser,
    // trackers: ITracker[],
    contents: IContent[],
    contact: IContactInformation;
}


const realCampaignData = {
    "campaigns":[]
}

/* tslint:disable:no-string-literal */
// getCampaigns().then( (response : any) => {
//     const campaigns = response
//     console.log(campaigns)
//     campaignData['campaigns'] = campaigns
// })


getRealCampaigns().then( (response : any) => {
    const campaigns = response
    console.log(campaigns)
    realCampaignData['campaigns'] = campaigns
})




// campaignData.returnStr = addTodo4("THIS IS RETURN")
/* tslint:enable:no-string-literal */



export {
    campaignData,
    ICampaign,
    IRealCampaign,
    realCampaignData
}
