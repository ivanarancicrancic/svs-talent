import * as React from 'react'
import { connect } from 'react-redux'
// import * as style from 'ts-style' //ts-style is correct one
// import { bindActionCreators } from 'redux'
import { getAddressData, realCampaignData } from '../redux/actions/localCampaignsActions'
// import store from '../../../redux/store/store'
// import { Office, Official, Division, Election } from '../../types/voteSmartTypes'
// import { displayElectionsAndOfficialsByDivision } from './displayElectionsAndOfficialsByDivision'
import { ICampaign} from '../models/teamModel'


interface IVoteSmartState {
    entry: string
    userAddressData?: any
}
interface IVoteSmartProps {
    fetchAddressData: any
    userAddressData: any
}

class LocalCampaigns extends React.Component<IVoteSmartProps, IVoteSmartState> {
    constructor(props: IVoteSmartProps) {
        super(props)
        this.state = {
            entry: ''
        }
    }

    public lookupAddress(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.fetchAddressData()
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry = event.target.value
        if (entry !== 'hello') {
            this.setState({
                entry: 'entry' 
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)

            this.lookupAddress(event)
        }
    }

  public render() {
        return (
            <div>
                <div>
                    <span>FORM</span>
                    <br />
                    <input 
                        type='text' 
                        placeholder='ENTRY'
                        onChange={ e => this.handleAddress(e) }
                        onKeyPress={ e => this.handleKeyPress(e) }
                    />
                    <button
                        onClick={ e => this.lookupAddress(e) }
                    >
                    Submit for info
                    </button>
                </div>
               <div> CAMPAIGNS LIST:
               {
                    //  campaignData.campaigns.map((campaign: ICampaign) =>
                    //           <div key={campaign.id}>
                    //             {campaign.id}<br/>
                    //           </div>
                    //         )
                   realCampaignData.campaigns.map((campaign: ICampaign) =>
                   
                    <div key={campaign.id}>
                      {campaign.id} 
                      {/* {campaign.user.firstname} */}
                      {/* {campaign.user.lastname} */}
                      {/* {campaign.contact.address}<br/> */}
                    </div>
                  )

                 
                 }
                   
                    </div>
            </div>
        )
    }

    public componentDidMount() {
        console.log(JSON.stringify(realCampaignData.campaigns))
         this.props.fetchAddressData()
            
         }
     

    public componentWillReceiveProps(newProps: IVoteSmartProps) {
        this.setState({
            ...newProps.userAddressData
        })
        console.log(this.state)
    }
}


const mapStateToProps = (state: IVoteSmartState) => {
    return {
        ...state
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        fetchAddressData: () => dispatch(getAddressData()),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(LocalCampaigns)
