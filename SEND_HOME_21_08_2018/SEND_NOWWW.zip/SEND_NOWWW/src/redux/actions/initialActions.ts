// import { Action } from 'redux'
// import store from '../store/store'
// import { imageData } from '../../models/imageData'
  import { getFromBackend } from '../../api/api'
// import { HANDLE_PARALLAX_DATA } from '../actions/actionTypes'

// import { ICampaign} from '../../models/teamModel'

// const getProjects = () => {
//     const projects = '/projects/get_all'
//     return getFromBackend(projects)
// }

// interface IAddTodoAction {
//     type: string,
//     text: string
// };


const getCampaigns = () => {
    const teamURL = '/testCampaigns'
     return getFromBackend(teamURL)
    // return fetch('http://localhost:8080/api/testCampaigns', {
    //     method: 'GET',
    //     headers: {"Content-Type": "application/json"}
    // })
    // .then(response => response.json())
    // .then(response => {
    //     console.log(response);
    //     return response 
    // })
    // .catch(err => {
    //     console.log(err);
    //     return err
    // });

}

const getRealCampaigns = () => {
    const teamURL = '/testCampaigns'
     return getFromBackend(teamURL)

}

//  const addTodo4 = (text: string): IAddTodoAction => {
//     return {
//         type: "THIS IS ",
//         text: "text"
//     }
// }

// const getParallaxImages = () => {
//     const parallaxImagesURL = '/images/get_all_parallax'
//     return getFromBackend(parallaxImagesURL)
// }

export {
    // getParallaxImages, 
     getCampaigns,
     getRealCampaigns
    // addTodo4,
   // IAddTodoAction
    // getProjects
}
