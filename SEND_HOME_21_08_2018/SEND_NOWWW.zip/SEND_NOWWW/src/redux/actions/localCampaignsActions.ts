
// import { Action } from 'redux'
import { HANDLE_GET_ALL_CAMPAIGNS} from './actionTypes'
// import store from '../store/store'
import { getFromBackend } from '../../api/api'
import { ICampaign } from '../../models/teamModel';
// import projectConfig from '../../../project.config'

interface ILocalVoteMattersAction<Action> {
    type: string
    payload?: any
}


const realCampaignData = {
    "campaigns":[]
}



/* tslint:disable:no-string-literal */
const getAddressData = () => {
    const url: string = '/testCampaigns'
    return (dispatch :any, getState:any) => {  
            return getFromBackend(url).then( (response:ICampaign[]) => {
                const repData = {
                    campaigns: response              
                }
                realCampaignData['campaigns'] = response
                dispatch(addressDataSuccess(repData))
            }).catch((error:any) => {
                  dispatch(addressDataFaied(error))
            })
    }
}
/* tslint:enable:no-string-literal */
const addressDataSuccess = (addressData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: addressData
    }
}
const addressDataFaied = (error: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: error
    }
}

export {
    getAddressData, ILocalVoteMattersAction, realCampaignData
}