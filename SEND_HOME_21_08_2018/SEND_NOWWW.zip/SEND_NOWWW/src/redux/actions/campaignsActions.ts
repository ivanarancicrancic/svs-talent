// import { Dispatch } from 'redux'
import { HANDLE_GET_ALL_CAMPAIGNS } from './actionTypes'
// import store from '../store/store'
import { getFromBackend } from '../../api/api'
// import projectConfig from '../../../project.config'



interface ICampaignsAction<Action> {
    type: string
    payload?: any
}
// const getAllCampaigns = (repResponseData: any, dispatch: any) => {
//     const url: string = '/campaigns'

//     return getFromBackend(url).then(function (response) {
//         const getAllCampaignsResponse = {
//             ...repResponseData,
//             ...response.data
//         }

//         dispatch(addressDataSuccess(getAllCampaignsResponse))
//     }).catch(function (error) {
//           dispatch(addressDataFaied(error))
//     })
// }
const getAllCampaigns = () => {
    const url: string = '/testCampaigns'
    return (dispatch: any, getState:any) => {

       return getFromBackend(url).then( (response : any) => {
            const campaigns = response
             dispatch(getCampaignsDataSuccess(campaigns))
                // getElectionWithaddress(repData, address, dispatch) 

            })
            // .catch(function (error) {
            //       dispatch(getCampaignsDataFaied(error))
            // })
        .catch(error => {
                dispatch(getCampaignsDataFaied(error))
        });

            
        }
    }

const getCampaignsDataSuccess = (campaignsData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: campaignsData
    }
}
const getCampaignsDataFaied = (error: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: error
    }
}

export {
    getAllCampaigns, ICampaignsAction
}
