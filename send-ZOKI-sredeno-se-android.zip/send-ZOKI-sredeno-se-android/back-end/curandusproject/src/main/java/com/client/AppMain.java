package com.client;

import java.io.File;
import java.sql.Timestamp;

import com.database.Project;
import com.model.Patients;
import com.notnoop.apns.APNS;
import com.notnoop.apns.ApnsService;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class AppMain {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		Project project= new Project();
		String pateka_send="";
		
		//pateka_send="\"http:"+"/"+"/"+"104.245.33.167"+":"+"8080"+"/"+"curandusImages"+"/"+"Certificates.p12"+"\"";
		 
		File file = new File(".");
		for(String fileNames : file.list()) System.out.println(fileNames);
		
		ApnsService service =
			     APNS.newService()
			     //.withCert("Certificates.p12", "Interway1102")
			     .withCert("CertificatesPushProvider.p12", "Interway1102")
			     .withSandboxDestination()
			     .build();
		 
		//String json = "{\"brand\":\"Jeep\", \"doors\": 3}";
		
		String payload="{\"aps\":"
								+ "{\"alert\":"
											+ "{\"body\":\"Can't be simpler than this!\","
											+ "\"from\":\"p_from\","
											+ "\"_id\":\"p__id\","
											+ "\"namenovo\":\"p_namenovo\","
											+ "\"fromchatid\":\"p_fromchatid\","
											+ "\"title\":\"Ime Provider\""
											+ "},"
											+"\"sound\":\"default\","
											+"\"vibrate\":\"true\""
											+ "},"		
									+ "\"message\":\"p_message\"}";
		
		//String payload={"aps":{"alert":{"body":"Can't be simpler than this!","title":"Ime Provider"}}};
		//String payload = APNS.newPayload().alertBody("Probna notifikacija").alertTitle("Ime Provider").build();
		System.out.println(payload);	
		
		String token = "b8a1d17cb379a6366c8082b12adf90a47e905dde8c088bc485e509332c29d3f2";
		service.push(token, payload);		
		
//		boki		
//		  string AccountSid = "AC09897ed28e3ca84c002dc7597151d9b3";
//          string AuthToken = "244af8201cd17bbf3000dcabd8e2b01b";
//          +13478092620
          
	//	Twilio.init("AC5dc88a4ccce105c4e7a0335d3d95b6d8", "eeb9e4447f5ec91bdd60cf479b780633");
		
        //  American Account 	// Twilio.init("AC5dc88a4ccce105c4e7a0335d3d95b6d8", "eeb9e4447f5ec91bdd60cf479b780633");
		//Vanja ("+16692260877"),
        //Twilio.init("AC389ed5b9f9f774b7383cbf88af065f46", "0559b9f3af2fa00c93cd25285deb036b");
		
//	    Message message = Message.creator(new PhoneNumber("+16692260877"),
//	        new PhoneNumber("+12242316531"), 
//	        "Test za sms poraka preku twilio?").create();
		
		
	    
       // Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        //System.out.println(timestamp.toString().replace(":", "").replace("-", "").replace(".", "").replace(" ", ""));
        
		int randomNumber = (int) Math.floor(Math.random() * 1000000);
	    System.out.println("Vlezeeee i ova e random numberrrr: "+randomNumber);

	  //  System.out.println(message);	
	    
//          American Account 	// Twilio.init("AC5dc88a4ccce105c4e7a0335d3d95b6d8", "eeb9e4447f5ec91bdd60cf479b780633");
//		Vanja ("+16692260877"),
        //Twilio.init("AC3cdf4cf57d4c7d9b1e99fe5b5317af5c", "fb8e434eff426f4807559adfe04b9542");
		
	//    Message message = Message.creator(new PhoneNumber("+16692260877"),
	  //      new PhoneNumber("+15043157825"), 
	    //    "Test za sms poraka preku twilio?").create();	   
//	    Patients pp=new Patients();
//	    Patients pp1=new Patients();
//	    pp.setPhone("071111111");
//	    
//	    System.out.println("phone app"+pp.getPhone());
//	    ProjectManager projectManager= new ProjectManager();
//	    pp1=projectManager.InsertPatient(pp);
	    
	    
//	    System.out.println("ID "+pp1.getPatientId());	

	}

}
