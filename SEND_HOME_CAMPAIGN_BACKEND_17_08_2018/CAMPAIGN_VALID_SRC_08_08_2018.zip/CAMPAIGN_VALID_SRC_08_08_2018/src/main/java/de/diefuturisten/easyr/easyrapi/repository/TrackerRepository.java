package de.diefuturisten.easyr.easyrapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;

public interface TrackerRepository extends JpaRepository<Tracker, Long> {

    Optional<Tracker> findByUrl(String url);
}
