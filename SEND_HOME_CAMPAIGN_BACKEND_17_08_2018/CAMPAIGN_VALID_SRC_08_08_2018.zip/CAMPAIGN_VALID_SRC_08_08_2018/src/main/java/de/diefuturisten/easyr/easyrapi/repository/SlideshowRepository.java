package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import java.util.Optional;

@Component
public interface SlideshowRepository extends JpaRepository<SlideshowContent, Long>
{
    public Optional<SlideshowContent> findById(Long id);
    public void deleteById(Long id);
}
