package mongo.springframework.bootstrap;

import mongo.springframework.repositories.BookRepository;
import mongo.springframework.repositories.CategoryRepository;
import lombok.extern.slf4j.Slf4j;
import mongo.springframework.model.*;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Slf4j
@Component
public class BookBootstrap implements ApplicationListener<ContextRefreshedEvent> {

    private final CategoryRepository categoryRepository;
    private final BookRepository bookRepository;

    public BookBootstrap(CategoryRepository categoryRepository, BookRepository bookRepository) {
        this.categoryRepository = categoryRepository;
        this.bookRepository = bookRepository;
    }

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent event) {
        loadCategories();
        bookRepository.saveAll(getBooks());
        System.out.println("Loading Data");
    }

    private void loadCategories(){
        Category cat1 = new Category();
        cat1.setDescription("Education");
        categoryRepository.save(cat1);

        Category cat2 = new Category();
        cat2.setDescription("Travel");
        categoryRepository.save(cat2);

        Category cat3 = new Category();
        cat3.setDescription("Health");
        categoryRepository.save(cat3);

        Category cat4 = new Category();
        cat4.setDescription("Medical");
        categoryRepository.save(cat4);
    }



    private List<Book> getBooks() {

        List<Book> books = new ArrayList<>(2);

        //get Categories
        Optional<Category> educationCategoryOptional = categoryRepository.findByDescription("Education");

        if(!educationCategoryOptional.isPresent()){
            throw new RuntimeException("Required Category Not Found");
        }

        Optional<Category> travelCategoryOptional = categoryRepository.findByDescription("Travel");

        if(!travelCategoryOptional.isPresent()){
            throw new RuntimeException("Required Category Not Found");
        }

        Category educationCategory = educationCategoryOptional.get();
        Category travelCategory = travelCategoryOptional.get();

        Book book = new Book();
        book.setDescription("Java Spring Enterprise - Perfect knowledge to get");
        book.setSize(500);
        book.setEvaluation(10);
        book.setDifficulty(Difficulty.HARD);
        Notes bookNotes = new Notes();
        bookNotes.setNotes("This is book about....");

        book.setNotes(bookNotes);

        book.addAuthor(new Author("Ivana Rancic", "Rancic"));
        book.addAuthor(new Author("Pol", "Mark"));

        book.getCategories().add(educationCategory);
        book.getCategories().add(travelCategory);

        book.setUrl("http://www.");

        //add to return list
        books.add(book);

        Book book2 = new Book();
        book2.setDescription("LOTR - Adventure Book");
        book2.setSize(658);
        book2.setEvaluation(10);
        book2.setDifficulty(Difficulty.MODERATE);

        Notes bookNotes2 = new Notes();
        bookNotes2.setNotes("This is adventure legendary book about adventure travel and fantasy enthusiasts...");

        book2.setNotes(bookNotes2);

        book2.addAuthor(new Author("Tom","Great"));

        book2.getCategories().add(travelCategory);

       book2.setUrl("http://www.books.LOTR/");

        books.add(book2);
        return books;
    }
}
