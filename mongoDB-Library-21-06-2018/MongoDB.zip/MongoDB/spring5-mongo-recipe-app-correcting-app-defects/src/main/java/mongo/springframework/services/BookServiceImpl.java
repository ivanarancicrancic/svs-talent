package mongo.springframework.services;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.converters.BookCommandToBook;
import mongo.springframework.converters.BookToBookCommand;
import mongo.springframework.model.Book;
import mongo.springframework.exceptions.NotFoundException;
import mongo.springframework.repositories.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

@Slf4j
@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final BookToBookCommand bookToBookCommand;
    private final BookCommandToBook bookCommandToBook;

    public BookServiceImpl(BookRepository bookRepository, BookToBookCommand bookToBookCommand, BookCommandToBook bookCommandToBook) {
        this.bookRepository = bookRepository;
        this.bookToBookCommand = bookToBookCommand;
        this.bookCommandToBook = bookCommandToBook;
    }

    @Override
    public Set<Book> getBooks() {
        System.out.println("Entered service getBooks()!");

        Set<Book> bookSet = new HashSet<>();
        bookRepository.findAll().iterator().forEachRemaining(bookSet::add);
        return bookSet;
    }

    @Override
    public Book findById(String id) {

        Optional<Book> bookOptional = bookRepository.findById(id);

        if (!bookOptional.isPresent()) {
            throw new NotFoundException("Book Not Found. ID value: " + id );
        }

        return bookOptional.get();
    }

    @Override
    @Transactional
    public BookCommand findCommandById(String id) {
        return bookToBookCommand.convert(findById(id));
    }

    @Override
    @Transactional
    public BookCommand saveBookCommand(BookCommand command) {
        Book detachedBook = bookCommandToBook.convert(command);
        Book savedBook = bookRepository.save(detachedBook);
        System.out.println("Saved RecipeId:" + savedBook.getId());
        return bookToBookCommand.convert(savedBook);
    }

    @Override
    public void deleteById(String idToDelete) {
        bookRepository.deleteById(idToDelete);
    }
}
