package mongo.springframework.services;

import mongo.springframework.commands.BookCommand;
import mongo.springframework.model.Book;

import java.util.Set;

public interface BookService {

    Set<Book> getBooks();

    Book findById(String id);

    BookCommand findCommandById(String id);

    BookCommand saveBookCommand(BookCommand command);

    void deleteById(String idToDelete);
}
