package mongo.springframework.services;

import mongo.springframework.commands.AuthorCommand;

public interface AuthorService {

    AuthorCommand findByBookIdAndAuthorId(String bookId, String authorId);

    AuthorCommand saveAuthorCommand(AuthorCommand command);

    void deleteById(String bookId, String idToDelete);
}
