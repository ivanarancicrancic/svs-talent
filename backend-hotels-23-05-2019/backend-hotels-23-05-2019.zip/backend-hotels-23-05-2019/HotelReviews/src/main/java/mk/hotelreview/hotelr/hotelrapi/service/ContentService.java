package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowImage;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateSlideshowImageModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditContentNameModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditSlideshowContentModel;
import mk.hotelreview.hotelr.hotelrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.validation.Valid;
import java.util.Optional;

@Service
@Transactional
public class ContentService {

    private final ContentRepository contentRepository;
    private final SlideshowContentService slideshowContentService;
    private final SlideshowImageService slideshowImageService;

    public ContentService(ContentRepository contentRepository, SlideshowContentService slideshowContentService, SlideshowImageService slideshowImageService) {
        this.contentRepository = contentRepository;
        this.slideshowContentService = slideshowContentService;
        this.slideshowImageService = slideshowImageService;
    }

//    public Optional<Content> getById(long id) {
//        return this.contentRepository.findById(id);
//    }
//
//    public boolean deleteContent(Content content) {
//        this.contentRepository.delete(content);
//        return true;
//    }
//
//
//    /* Slideshow */
//    public SlideshowContent createSlideshowContent(Hotel hotel, @Valid CreateSlideshowContentModel model) {
//        SlideshowContent content = slideshowContentService.create(hotel, model);
//        return content;
//    }
//
//    public SlideshowContent editSlideshowContent(SlideshowContent content, @Valid EditSlideshowContentModel model) {
//        SlideshowContent editedContent = slideshowContentService.edit(content, model);
//        return editedContent;
//    }

    /* SlideshowImage */
    public SlideshowImage createSlideshowImage(long slideshowID, @Valid CreateSlideshowImageModel model) {
        SlideshowImage content = slideshowImageService.create(slideshowID, model);
        return content;
    }

    public SlideshowImage deleteSlideshowImage(long imageID) {
        SlideshowImage content = slideshowImageService.delete(imageID);
        return content;
    }


//    public Content rename(Content content, EditContentNameModel model) {
//        content.setName(model.getName());
//        return contentRepository.save(content);
//    }

}
