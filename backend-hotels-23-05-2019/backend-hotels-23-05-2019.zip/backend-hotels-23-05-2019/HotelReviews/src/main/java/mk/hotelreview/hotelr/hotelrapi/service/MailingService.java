package mk.hotelreview.hotelr.hotelrapi.service;

import com.google.common.collect.Lists;
import it.ozimov.springboot.mail.model.Email;
import it.ozimov.springboot.mail.model.defaultimpl.DefaultEmail;
import it.ozimov.springboot.mail.service.EmailService;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.mail.internet.InternetAddress;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

@Service
public class MailingService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private final EmailService emailService;
    private final MessageByLocaleService messageLocalService;

    @Value("${hotelr.email.enable:false}")
    private boolean emailEnabled;

    @Value("${hotelr.email.from.mail}")
    private String fromEmail;

    @Value("${hotelr.email.from.name}")
    private String fromName;

    @Value("${hotelr.frontend.url}")
    private String frontendUrl;

    public MailingService(EmailService emailService, MessageByLocaleService messageLocalService) {
        this.emailService = emailService;
        this.messageLocalService = messageLocalService;
    }

    public void sendTemplateEmail(String template, String receipientName, String receipientMail, String subject, Map<String, Object> model) throws CannotSendEmailException {
        try{
            final Email email = DefaultEmail.builder()
                    .from(new InternetAddress(fromEmail, fromName))
                    .to(Lists.newArrayList(new InternetAddress(receipientMail, receipientName)))
                    .subject(subject)
                    .body("")
                    .encoding("UTF-8").build();

            if( !emailEnabled ){
                log.warn("Sending email disabled by hotelr.email.enable setting");
                return;
            }

            emailService.send(email, template, model);
        } catch(UnsupportedEncodingException e){
            log.error("Could not Send E-Mail due to UnsupportedEncodingException", e);
            throw new CannotSendEmailException();
        } catch(CannotSendEmailException e){
            log.error("Could not Send E-Mail due to CannotSendEmailException", e);
            throw new CannotSendEmailException();
        }
    }

    public void sendPasswordResetToken(User user, String token) throws CannotSendEmailException {
        Map<String, Object> model = new HashMap<>();
        model.put("token", token);
        model.put("url", String.format("%s/forgot-password/%s/%s", frontendUrl, user.getUsername(), token));

        String subject = messageLocalService.getMessage("email.subject.passwordreset", user.getPreferedLanguage());

        sendTemplateEmail(
                String.format("password_reset.%s.ftl", user.getPreferedLanguage().getLanguage()),
                user.getName(),
                user.getEmail(),
                subject,
                model
        );

    }


    public void sendNewPassword(User user) throws CannotSendEmailException {
        Map<String, Object> model = new HashMap<>();
        model.put("url", String.format("%s/", frontendUrl));

        String subject = messageLocalService.getMessage("email.subject.passwordnew", user.getPreferedLanguage());

        sendTemplateEmail(
                String.format("password_new.%s.ftl", user.getPreferedLanguage().getLanguage()),
                user.getName(),
                user.getEmail(),
                subject,
                model
        );

    }

    public void sendNewUserWelcome(User user) throws CannotSendEmailException {
        Map<String, Object> model = new HashMap<>();
        model.put("visibleName", user.getName());
        model.put("username", user.getEmail());
        model.put("loginurl", String.format("%s/", frontendUrl));

        String subject = messageLocalService.getMessage("email.subject.usernew", user.getPreferedLanguage());

        sendTemplateEmail(
                String.format("user_new.%s.ftl", user.getPreferedLanguage().getLanguage()),
                user.getName(),
                user.getEmail(),
                subject,
                model
        );

    }

}
