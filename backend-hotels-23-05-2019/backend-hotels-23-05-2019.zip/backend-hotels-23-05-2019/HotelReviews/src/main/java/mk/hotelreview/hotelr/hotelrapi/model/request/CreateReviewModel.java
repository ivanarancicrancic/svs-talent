package mk.hotelreview.hotelr.hotelrapi.model.request;

import javax.validation.constraints.NotNull;

public class CreateReviewModel {

    @NotNull
    private Long userId;

    @NotNull
    private Long hotelId;

    private String comment;

    public CreateReviewModel() {
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getHotelId() {
        return hotelId;
    }

    public void setHotelId(Long hotelId) {
        this.hotelId = hotelId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
