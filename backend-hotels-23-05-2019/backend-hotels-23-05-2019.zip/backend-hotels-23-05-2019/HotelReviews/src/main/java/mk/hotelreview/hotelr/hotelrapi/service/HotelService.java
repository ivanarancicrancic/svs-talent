package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditHotelModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.SaveNewHotelModel;
import mk.hotelreview.hotelr.hotelrapi.repository.HotelRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class HotelService {

    private final HotelRepository hotelRepository;
    private final HotelReviewService hotelReviewService;

    public HotelService(HotelRepository hotelRepository, HotelReviewService hotelReviewService) {
        this.hotelRepository = hotelRepository;
        this.hotelReviewService = hotelReviewService;
    }

    public List<Hotel> findAllHotels() {
        return hotelRepository.findAll().stream().collect(Collectors.toList());
    }

    public List<HotelReview> getAllFavoriteHotelsForUser(User user) {
        return user.getHotelReviews();
    }

    public Optional<Hotel> getHotel(long id) {
        return this.hotelRepository.findById(id);
    }

    public Hotel createEmptyHotel(String name) {
        Hotel hotel = new Hotel();
        hotel.setName(name);
        return this.hotelRepository.save(hotel);
    }

    public Hotel saveNewHotel(Hotel hotel, SaveNewHotelModel model, User user) throws Exception {
        hotel.setTemporary(false);
        this.hotelRepository.save(hotel);
        return hotel;
    }


    public Hotel editHotel(Hotel hotel, EditHotelModel editHotelModel) {
        hotel.setName(editHotelModel.getName());
        hotel.setDescription(editHotelModel.getDiscription());
        return this.hotelRepository.save(hotel);
    }

}
