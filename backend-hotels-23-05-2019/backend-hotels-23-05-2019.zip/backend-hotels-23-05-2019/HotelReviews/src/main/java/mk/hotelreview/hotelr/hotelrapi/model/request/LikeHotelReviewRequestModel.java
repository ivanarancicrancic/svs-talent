package mk.hotelreview.hotelr.hotelrapi.model.request;

import javax.validation.constraints.NotNull;

public class LikeHotelReviewRequestModel {

    @NotNull
    private Long hotelReviewId;
    private Long userId;

    public LikeHotelReviewRequestModel() {
    }

    public LikeHotelReviewRequestModel(@NotNull Long hotelReviewId, Long userId) {
        this.hotelReviewId = hotelReviewId;
        this.userId = userId;
    }

    public Long getHotelReviewId() {
        return hotelReviewId;
    }

    public void setHotelReviewId(Long hotelReviewId) {
        this.hotelReviewId = hotelReviewId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
