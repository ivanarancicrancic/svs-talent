package mk.hotelreview.hotelr.hotelrapi.model.response;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Tracker;

public class HotelOverviewModel {

    private long id;
    private String name;
    private String description;
    private String trackerUrl;


    public HotelOverviewModel() {
    }

    public HotelOverviewModel(Hotel hotel) {
        this.id = hotel.getId();
        this.name = hotel.getName();
        this.description = hotel.getDescription();

        this.trackerUrl = hotel.getTracker()
                .stream()
                .map(Tracker::getUrl)
                .findFirst().orElse(null);

         }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTrackerUrl() {
        return trackerUrl;
    }

    public void setTrackerUrl(String trackerUrl) {
        this.trackerUrl = trackerUrl;
    }


}
