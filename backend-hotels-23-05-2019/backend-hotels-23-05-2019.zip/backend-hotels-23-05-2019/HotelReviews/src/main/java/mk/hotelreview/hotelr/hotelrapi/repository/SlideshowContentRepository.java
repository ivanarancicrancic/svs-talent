package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.content.SlideshowContent;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SlideshowContentRepository extends JpaRepository<SlideshowContent, Long> {

}
