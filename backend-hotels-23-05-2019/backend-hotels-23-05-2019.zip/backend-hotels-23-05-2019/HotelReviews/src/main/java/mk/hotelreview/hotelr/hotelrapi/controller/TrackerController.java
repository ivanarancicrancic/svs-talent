package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Tracker;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ForbiddenException;
import mk.hotelreview.hotelr.hotelrapi.exceptions.MyFileNotFoundException;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ProbablyNotAnImageException;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ValidationException;
import mk.hotelreview.hotelr.hotelrapi.model.response.TrackerModel;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.FileStorageService;
import mk.hotelreview.hotelr.hotelrapi.service.HotelService;
import mk.hotelreview.hotelr.hotelrapi.service.TrackerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@RestController
@RequestMapping("/api")
public class TrackerController {

    private final TrackerService trackerService;
    private final HotelService hotelService;
    private final FileStorageService fileStorageService;

    public TrackerController(TrackerService trackerService, HotelService hotelService, FileStorageService fileStorageService) {
        this.trackerService = trackerService;
        this.hotelService = hotelService;
        this.fileStorageService = fileStorageService;
    }

    @PostMapping("/hotel/{hotelId}/tracker")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_CREATE)
    public ResponseEntity createTracker(@PathVariable long hotelId, @RequestParam("file") MultipartFile multipartFile) throws IOException, ProbablyNotAnImageException {
        System.out.println("1 before calling fileStorageService.storeTemporaryTrackerFile(multipartFile)");
        Hotel hotel = hotelService.getHotel(hotelId).orElseThrow(ForbiddenException::new);
        System.out.println("before calling fileStorageService.storeTemporaryTrackerFile(multipartFile)");
        // save as temporary file
        System.out.println("MultFile: " + multipartFile.toString());
        File convertedFile = fileStorageService.storeTemporaryTrackerFile(multipartFile);

        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        // upload magic
        System.out.println("Before calling trackerService.createTrackerForHotel with convertedFile: " + convertedFile.toString());
        Tracker tracker = trackerService.createTrackerForHotel(hotel, convertedFile);
        System.out.println("trackerService.createTrackerForHotel(hotel, convertedFile) executed!!! With tracker: " + tracker.toString());
//        return new TrackerModel(tracker);
        return ResponseEntity.ok(new TrackerModel(tracker));
    }

    @PostMapping("/hotel/tracker/{trackerId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_EDIT)
    public ResponseEntity updateTracker(@PathVariable long trackerId, @RequestParam("file") MultipartFile multipartFile) throws ProbablyNotAnImageException {
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        // allow only files with PNG or JPG extension
        String extension = FileStorageService.GetFileExtension(multipartFile.getOriginalFilename());
        if( !(extension.equals(".png") || extension.equals(".jpg")) ) {
            throw new ValidationException();
        }
          // 2MB limit
        if(multipartFile.getSize() > 2097152) {
            throw new ValidationException();
        }

        // save as temporary file
        File convertedFile = fileStorageService.storeTemporaryTrackerFile(multipartFile);
        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        Tracker editedTracker = trackerService.editTracker(tracker, convertedFile);

        if(editedTracker != null) {
            return ResponseEntity.ok(new TrackerModel(tracker));
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/hotel/tracker/{trackerId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_DELETE)
    public ResponseEntity deleteTracker(@PathVariable long trackerId) {
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        boolean res = trackerService.deleteTracker(tracker);
        if(res) {
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }




}
