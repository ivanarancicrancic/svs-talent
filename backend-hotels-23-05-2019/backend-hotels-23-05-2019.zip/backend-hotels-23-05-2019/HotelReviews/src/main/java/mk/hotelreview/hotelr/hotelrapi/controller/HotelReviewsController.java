package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.LikeHotelReviewRequestModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelReviewModel;
import mk.hotelreview.hotelr.hotelrapi.repository.HotelRepository;
import mk.hotelreview.hotelr.hotelrapi.security.AuthenticationFacade;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.HotelReviewService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api")
public class HotelReviewsController {

    private final AuthenticationFacade authenticationFacade;
    private final HotelReviewService hotelReviewService;
    private final HotelRepository hotelRepository;

    public HotelReviewsController(AuthenticationFacade authenticationFacade, HotelReviewService hotelReviewService, HotelRepository hotelRepository) {
        this.authenticationFacade = authenticationFacade;
        this.hotelReviewService = hotelReviewService;
        this.hotelRepository = hotelRepository;
    }

    @GetMapping("/reviews")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.REVIEWS_LIST)
    public Stream<HotelReviewModel> getAllReviewsForHotel() {
        return hotelReviewService.getAllHotelReviews().stream()
                .map(HotelReviewModel::new);
    }

    @GetMapping("/reviews/{hotelId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.REVIEWS_LIST_FOR_HOTEL)
    public List<HotelReview> getHotelReviews(@PathVariable long hotelId) {
        Hotel hotel = hotelRepository.findById(hotelId).get();
        return hotel.getReviews();
    }

    @PostMapping("/review/like")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.REVIEW_LIKE)
    public ResponseEntity likeHotelReview(@RequestBody LikeHotelReviewRequestModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        hotelReviewService.likeHotelReview(user, model);
        return new ResponseEntity(HttpStatus.OK);
    }

}
