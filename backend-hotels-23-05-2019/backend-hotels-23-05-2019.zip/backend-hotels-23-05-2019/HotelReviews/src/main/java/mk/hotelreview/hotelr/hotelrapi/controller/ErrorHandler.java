package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.exceptions.InvalidCaptchaException;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ValidationResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@Controller
public class ErrorHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(InvalidCaptchaException.class)
    public final ResponseEntity<ValidationResponse> handleInvalidCaptchaException(InvalidCaptchaException ex, WebRequest request) {
        ValidationResponse validationResponse = new ValidationResponse().addError("captcha", "wrong_code");
        return new ResponseEntity<>(validationResponse, HttpStatus.BAD_REQUEST);
    }

}