-- Users
INSERT INTO
  users(key_user, active, language, email, password, firstname, lastname, gender, city, country)
VALUES
  (1, true, 'de', 'christen@app-logik.de', '$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK', 'Oliver', 'Christen', true, 'Skopje', 'Macedonia'), -- password is "wuff"
  (2, true, 'en', 'ivana.rancic.r@gmail.com', '$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq', 'Ivana', 'Rancic', true, 'Belgrade', 'Serbia'); --password is "miau"

ALTER SEQUENCE users_key_user_seq RESTART WITH 3;

-- Roles
INSERT INTO
  userroles(key_userrole, name, description)
VALUES
  (1, 'Standard', 'normal user'),
  (2, 'Admin', 'admin user');

ALTER SEQUENCE userroles_key_userrole_seq RESTART WITH 3;

-- User has Roles
INSERT INTO
  user_has_roles(fk_user, fk_userrole)
VALUES
  (1, 1),
  (1, 2);

-- Rights
INSERT INTO
  userrights(key_userright, description, name)
VALUES
  (4, 'HOTEL_LIST', 'HOTEL_LIST'),
  (5, 'HOTEL_DELETE', 'HOTEL_DELETE'),
  (6, 'HOTEL_EDIT', 'HOTEL_EDIT'),
  (7, 'HOTEL_CREATE', 'HOTEL_CREATE'),
  (8, 'HOTEL_VIEW', 'HOTEL_VIEW'),
  (13, 'SLIDESHOWS_LIST', 'SLIDESHOWS_LIST'),
  (14, 'ADMIN_RIGHT', 'ADMIN_RIGHT'),
  (15, 'USER_GET', 'USER_GET'),
  (16, 'REVIEWS_LIST', 'REVIEWS_LIST'),
  (17, 'REVIEWS_LIST_FOR_HOTEL', 'REVIEWS_LIST_FOR_HOTEL'),
  (18, 'REVIEW_LIKE', 'REVIEW_LIKE'),
  (19, 'HOTEL_GET', 'HOTEL_GET'),
  (22, 'TRACKER_CREATE', 'TRACKER_CREATE'),
  (23, 'TRACKER_EDIT', 'TRACKER_EDIT'),
  (24, 'TRACKER_DELETE', 'TRACKER_DELETE'),
  (25, 'CONTENT_CREATE', 'CONTENT_CREATE'),
  (26, 'CONTENT_EDIT', 'CONTENT_EDIT'),
  (27, 'CONTENT_DELETE', 'CONTENT_DELETE');

-- Role Has Rights
INSERT INTO
  role_has_rights(fk_userrole, fk_userright)
VALUES
  (1, 4),
  (1, 5),
  (1, 6),
  (1, 7),
  (1, 8),
  (1, 10),
  (1, 11),
  (1, 12),
  (1, 13),
  (1, 14), -- admin right
  (1, 15),
  (1, 16),
  (1, 17),
  (1, 18),
  (1, 19),
  (1, 20),
  (1, 21),
  (1, 22),
  (1, 23),
  (1, 24),
  (1, 25),
  (1, 26),
  (1, 27);


-- Hotels
INSERT INTO
    hotels(key_hotel, name, description, temporary)
VALUES
    (1, 'Via Abruzzi', 'This is wonderfull hotel placed near Milan city.', true);


-- HotelReview
INSERT INTO
    hotelreviews(key_hotelreviews, fk_user, fk_hotel, comment, likesNumber, code)
VALUES
 (1, 1, 1, 'What a wonderful place for rest', 3, '644SA63453675');


