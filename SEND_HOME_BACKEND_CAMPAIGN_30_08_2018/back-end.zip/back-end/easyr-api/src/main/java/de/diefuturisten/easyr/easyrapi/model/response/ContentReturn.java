package de.diefuturisten.easyr.easyrapi.model.response;

public class ContentReturn {
    private long id;

    private int weight;

    private String name;

    public ContentReturn(){}

    public ContentReturn(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
