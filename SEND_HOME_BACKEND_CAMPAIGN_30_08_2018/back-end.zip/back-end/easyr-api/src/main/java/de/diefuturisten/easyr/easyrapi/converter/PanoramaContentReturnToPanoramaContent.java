package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class PanoramaContentReturnToPanoramaContent implements org.springframework.core.convert.converter.Converter<PanoramaContentReturn, de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent> {

    public PanoramaContentReturnToPanoramaContent(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent convert(PanoramaContentReturn source) {

          de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent panoramaContent = new de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent();

          panoramaContent.setId(source.getId());

          panoramaContent.setWeight(source.getWeight());

          panoramaContent.setName(source.getName());
          panoramaContent.setType(null);
          panoramaContent.setUrl(source.getUrl());
       return panoramaContent;
    }

    }
