package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class ContactInformationReturnToContactInformation implements org.springframework.core.convert.converter.Converter<ContactInformationReturn, de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation> {

    public ContactInformationReturnToContactInformation(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation convert(ContactInformationReturn source) {
        if(source == null){
            return null;
        }
        de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation contactInformation = new de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation();
        java.util.List<de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign> campaigns = new java.util.ArrayList<>();

        contactInformation.setId(source.getId());
        contactInformation.setCampaigns(campaigns);
        contactInformation.setName(source.getName());
        contactInformation.setCompany(source.getCompany());
        contactInformation.setHomepage(source.getHomepage());
        contactInformation.setEmail(source.getEmail());
        contactInformation.setAddress(source.getAddress());
        contactInformation.setAddress2(source.getAddress2());
        contactInformation.setName(source.getNumber());
        contactInformation.setZip(source.getZip());
        contactInformation.setCity(source.getCity());

        return contactInformation;
    }

}
