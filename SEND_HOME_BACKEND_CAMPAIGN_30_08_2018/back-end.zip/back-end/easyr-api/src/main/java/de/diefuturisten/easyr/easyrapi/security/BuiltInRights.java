package de.diefuturisten.easyr.easyrapi.security;

public final class BuiltInRights {

    public static final String CAMPAIGN_CREATE = "CAMPAIGN_CREATE";
    public static final String CAMPAIGN_DELETE = "CAMPAIGN_DELETE";
    public static final String CAMPAIGN_LIST = "CAMPAIGN_LIST";
    public static final String CAMPAIGN_EDIT = "CAMPAIGN_EDIT";
    public static final String CAMPAIGN_VIEW = "CAMPAIGN_VIEW";
    public static final String PANORAMA_LIST = "PANORAMA_LIST";
    public static final String MOVIES_LIST = "MOVIES_LIST";
    public static final String AUDIO_LIST = "AUDIO_LIST";
    public static final String SLIDESHOWS_LIST = "SLIDESHOWS_LIST";


    private BuiltInRights() {
        // NO-OP utility class
    }

}
