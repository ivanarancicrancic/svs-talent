package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.UnityContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class UnityContentService {
    private UnityContentRepository unityContentRepository;
    private CampaignRepository campaignRepository;

    public UnityContentService(UnityContentRepository unityContentRepository, CampaignRepository campaignRepository) {
        this.unityContentRepository = unityContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public List<UnityContent> fetchAllUnities(){
        return unityContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public UnityContent findUnityById(long unityId){
        return unityContentRepository.findById(unityId).get();
    }

    public UnityContent modifyUnityContent(long id, UnityContent unityContent, long unityId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(unityContentRepository.findById(unityId).get());
        optionalCampaign.get().getContents().add(unityContent);
        campaignRepository.save(optionalCampaign.get());
        return unityContent;
    }

    public UnityContent createUnityConten(long id, UnityContent unityContent){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().add(unityContent);
        campaignRepository.save(optionalCampaign.get());
        unityContentRepository.save(unityContent);
        return unityContent;
    }

    public void deleteUnityContent(long id, long unityId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(unityContentRepository.findById(unityId).get());
        campaignRepository.save(optionalCampaign.get());
    }


    public List<UnityContent> findByCampagin(Campaign campaign) {
        return unityContentRepository.findByCampaign(campaign);
    }
}
