package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class UnityContentToUnityContentReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.content.UnityContent, UnityContentReturn>{

    public UnityContentToUnityContentReturn(){}

    @Override
    public UnityContentReturn convert(de.diefuturisten.easyr.easyrapi.entity.content.UnityContent source) {
        UnityContentReturn unityContentReturn = new UnityContentReturn();
        unityContentReturn.setId(source.getId());
        unityContentReturn.setWeight(source.getWeight());
        unityContentReturn.setName(source.getName());
        unityContentReturn.setIosUrl(source.getIosUrl());
        unityContentReturn.setAndroidUrl(source.getAndroidUrl());
        unityContentReturn.setPositionX(source.getPositionX());
        unityContentReturn.setPositionY(source.getRotationY());
        unityContentReturn.setPositionZ(source.getRotationZ());
        unityContentReturn.setRotationX(source.getRotationX());
        unityContentReturn.setRotationY(source.getRotationY());
        unityContentReturn.setRotationZ(source.getRotationZ());
        unityContentReturn.setScaleX(source.getScaleX());
        unityContentReturn.setScaleY(source.getScaleY());
        unityContentReturn.setScaleZ(source.getScaleZ());
        if(source.isRenderOnTrackingLost() == true)
            unityContentReturn.setRenderOnTrackingLost("true");
        else
            unityContentReturn.setRenderOnTrackingLost("false");

        if(source.isExtendedTracking() == true)
            unityContentReturn.setExtendedTracking("true");
        else
            unityContentReturn.setExtendedTracking("false");

        return unityContentReturn;
    }

}
