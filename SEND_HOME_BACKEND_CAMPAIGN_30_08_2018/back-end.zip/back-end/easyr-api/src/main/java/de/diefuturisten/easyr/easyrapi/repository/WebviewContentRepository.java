package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface WebviewContentRepository extends JpaRepository<WebviewContent, Long> {

    Optional<WebviewContent> findByName(String name);
    List<WebviewContent> findByCampaign(Campaign campaign);

}
