package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class ContentService {

    private PanoramaContentService panoramaContentService;
    private SlideshowContentService slideshowContentService;
    private WebviewContentService webviewContentService;
    private UnityContentService unityContentService;
    private AudioContentService audioContentService;
    private MovieContentService movieContentService;

    public ContentService(
            PanoramaContentService panoramaContentService,
            SlideshowContentService slideshowContentService,
            WebviewContentService webviewContentService,
            UnityContentService unityContentService,
            AudioContentService audioContentService,
            MovieContentService movieContentService
    ) {
        this.panoramaContentService = panoramaContentService;
        this.slideshowContentService = slideshowContentService;
        this.webviewContentService = webviewContentService;
        this.unityContentService = unityContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
    }

    public List<PanoramaContent> getPanoramaContentByCampaign(Campaign campaign) {
        return panoramaContentService.findPanoramaByCampagin(campaign);
    }

    public List<SlideshowContent> getSlideshowContentByCampaign(Campaign campaign) {
        return slideshowContentService.findByCampagin(campaign);
    }

    public List<WebviewContent> getWebviewContentByCampaign(Campaign campaign) {
        return webviewContentService.findByCampagin(campaign);
    }

    public List<UnityContent> getUnityContentByCampaign(Campaign campaign) {
        return unityContentService.findByCampagin(campaign);
    }

    public List<AudioContent> getAudioContentByCampaign(Campaign campaign) {
        return audioContentService.findByCampagin(campaign);
    }

    public List<MovieContent> getMovieContentByCampaign(Campaign campaign) {
        return movieContentService.findByCampagin(campaign);
    }

}
