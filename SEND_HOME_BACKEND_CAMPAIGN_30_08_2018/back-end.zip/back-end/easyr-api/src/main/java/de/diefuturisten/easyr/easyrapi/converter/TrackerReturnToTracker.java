package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class TrackerReturnToTracker implements org.springframework.core.convert.converter.Converter<TrackerReturn, de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> {

    public TrackerReturnToTracker(){}

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker convert(TrackerReturn source) {
        de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker tracker = new de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker();
        tracker.setId(source.getId());
        tracker.setUrl(source.getUrl());
        tracker.setVuforiaId(source.getVuforiaId());
        return tracker;
    }


}
