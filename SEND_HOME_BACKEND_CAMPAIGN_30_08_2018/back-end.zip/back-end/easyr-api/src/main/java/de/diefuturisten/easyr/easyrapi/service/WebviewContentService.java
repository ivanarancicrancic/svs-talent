package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.WebviewContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class WebviewContentService {

    private CampaignRepository campaignRepository;
    private WebviewContentRepository webviewContentRepository;

    public WebviewContentService(CampaignRepository campaignRepository, WebviewContentRepository webviewContentRepository) {
        this.campaignRepository = campaignRepository;
        this.webviewContentRepository = webviewContentRepository;
    }

    public WebviewContent createWebviewByCampaign(long id, WebviewContent webviewContent){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().add(webviewContent);
        campaignRepository.save(optionalCampaign.get());
        webviewContentRepository.save(webviewContent);
        return webviewContent;
    }

    public WebviewContent updateWebviewByCampaign(long id, WebviewContent webviewContent, long webviewId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(webviewContentRepository.findById(webviewId).get());
        optionalCampaign.get().getContents().add(webviewContent);
        campaignRepository.save(optionalCampaign.get());
        return  webviewContent;
    }
    public WebviewContent findWebviewById(long webviewId){
        return webviewContentRepository.findById(webviewId).get();
    }

    public void deleteWebviewByCampaign(long id, long webviewId){
        Optional<Campaign> optionalCampaign = campaignRepository.findById(id);
        optionalCampaign.get().getContents().remove(webviewContentRepository.findById(webviewId).get());
        campaignRepository.save(optionalCampaign.get());
    }

    public List<WebviewContent> findByCampagin(Campaign campaign) {
        return webviewContentRepository.findByCampaign(campaign);
    }

}
