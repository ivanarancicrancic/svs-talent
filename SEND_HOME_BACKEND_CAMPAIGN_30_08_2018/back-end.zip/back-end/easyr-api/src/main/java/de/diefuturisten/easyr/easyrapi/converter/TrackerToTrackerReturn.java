package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

public class TrackerToTrackerReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker, TrackerReturn> {

    public TrackerToTrackerReturn(){}

    @Override
    public TrackerReturn convert(de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker source) {
        TrackerReturn trackerReturn = new TrackerReturn();
        trackerReturn.setId(source.getId());
        trackerReturn.setUrl(source.getUrl());
        trackerReturn.setVuforiaId(source.getVuforiaId());
        return trackerReturn;
    }


}
