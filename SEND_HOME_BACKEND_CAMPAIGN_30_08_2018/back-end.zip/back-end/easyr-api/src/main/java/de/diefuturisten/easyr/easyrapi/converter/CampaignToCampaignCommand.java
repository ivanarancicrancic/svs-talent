package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;


@org.springframework.stereotype.Component
public class CampaignToCampaignCommand implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign, CampaignCommand> {

    ContactInformationToContactInformationReturn contactInformationToContactInformationReturn = new ContactInformationToContactInformationReturn();
    UserToUserReturn userToUserReturn = new UserToUserReturn();
    TrackerToTrackerReturn trackerToTrackerReturn = new TrackerToTrackerReturn();

    public CampaignToCampaignCommand() {
    }

    @Override
    public CampaignCommand convert(de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign source){
        if(source == null){
            return null;
        }

        CampaignCommand campaignCommand = new CampaignCommand();

        Long id;

        de.diefuturisten.easyr.easyrapi.entity.user.User user;

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> tracker = new java.util.ArrayList<>();

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.content.Content> contents = new java.util.ArrayList<>();

        de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation contact;

        campaignCommand.setId(source.getId());
        campaignCommand.setUser(userToUserReturn.convert(source.getUser()));
        campaignCommand.setContact(contactInformationToContactInformationReturn.convert(source.getContactInformation()));

        if (source.getTracker() != null && source.getTracker().size() > 0){
            source.getTracker()
                    .forEach( tracker1 -> campaignCommand.getTracker().add(trackerToTrackerReturn.convert(tracker1)));
        }

        return campaignCommand;
    }
}
