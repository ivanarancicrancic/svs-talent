package de.diefuturisten.easyr.easyrapi.converter;


import de.diefuturisten.easyr.easyrapi.model.response.*;

public class UserToUserReturn implements org.springframework.core.convert.converter.Converter<de.diefuturisten.easyr.easyrapi.entity.user.User, UserReturn> {

    public UserToUserReturn(){}

    @Override
    public UserReturn convert(de.diefuturisten.easyr.easyrapi.entity.user.User source) {
        UserReturn userReturn = new UserReturn();

        userReturn.setId(source.getId());
        userReturn.setLanguage(source.getLanguage());
        userReturn.setActive(source.isActive());
        userReturn.setEmail(source.getEmail());
        userReturn.setPassword(source.getPassword());
        userReturn.setGender(source.isGender());
        userReturn.setFirstname(source.getFirstname());
        userReturn.setLastname(source.getLastname());
        return userReturn;
    }


}
