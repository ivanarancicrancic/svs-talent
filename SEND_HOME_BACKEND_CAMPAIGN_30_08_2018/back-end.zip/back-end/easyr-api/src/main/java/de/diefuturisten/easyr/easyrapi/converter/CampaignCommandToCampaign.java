package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.model.response.*;

@org.springframework.stereotype.Component
public class CampaignCommandToCampaign implements org.springframework.core.convert.converter.Converter<CampaignCommand, de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign> {

    ContactInformationReturnToContactInformation contactInformationReturnToContactInformation = new ContactInformationReturnToContactInformation();
    UserReturnToUser userReturnToUser = new UserReturnToUser();
    TrackerReturnToTracker trackerReturnToTracker = new TrackerReturnToTracker();

    public CampaignCommandToCampaign() {
    }

    @Override
    public de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign convert(CampaignCommand source){

        if(source == null){
            return null;
        }

        de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign campaign = new de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign();

        Long id;

        de.diefuturisten.easyr.easyrapi.entity.user.User user;

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> tracker = new java.util.ArrayList<>();

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.content.Content> contents = new java.util.ArrayList<>();

        de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation contact;

        campaign.setId(source.getId());
        campaign.setUser(userReturnToUser.convert(source.getUser()));
        campaign.setContactInformation(contactInformationReturnToContactInformation.convert(source.getContact()));

        if (source.getTracker() != null && source.getTracker().size() > 0){
            source.getTracker()
                    .forEach( tracker1 -> campaign.getTracker().add(trackerReturnToTracker.convert(tracker1)));
        }

        campaign.setTracker(null);
        campaign.setContactInformation(null);

        return campaign;
    }

}



