ALTER TABLE campaigns ALTER COLUMN name DROP NOT NULL;
ALTER TABLE campaigns ALTER COLUMN description DROP NOT NULL;

ALTER TABLE campaigns ADD COLUMN temporary boolean;
UPDATE campaigns SET temporary = false;
ALTER TABLE campaigns ALTER COLUMN temporary SET NOT NULL;