ALTER TABLE trackers ADD COLUMN trackings BIGINT;
UPDATE trackers SET trackings = 0;
ALTER TABLE trackers ALTER COLUMN trackings SET NOT NULL;