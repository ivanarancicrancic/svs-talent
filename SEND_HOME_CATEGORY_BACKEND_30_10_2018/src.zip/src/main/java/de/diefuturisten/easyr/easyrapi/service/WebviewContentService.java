package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@Transactional
public class WebviewContentService {

    private final ContentRepository contentRepository;

    public WebviewContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public WebviewContent create(Campaign campaign, CreateWebviewContentModel webviewContentModel) {
        WebviewContent content = new WebviewContent();
        content.setCampaign(campaign);
        content.setName(webviewContentModel.getName());
        content.setUrl(webviewContentModel.getUrl());

        Optional<Content> contentWithHighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHighestWeight.isPresent()) {
            content.setWeight(contentWithHighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public WebviewContent edit(WebviewContent content, CreateWebviewContentModel webviewContentModel) {
        // content.setName(webviewContentModel.getName());
        content.setUrl(webviewContentModel.getUrl());
        return contentRepository.save(content);
    }
}
