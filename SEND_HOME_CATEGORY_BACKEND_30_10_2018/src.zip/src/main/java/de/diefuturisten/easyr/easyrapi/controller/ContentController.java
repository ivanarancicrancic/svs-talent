package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MoreInfoContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.model.response.MovieContentModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.ContentService;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ContentController {

    private final AuthenticationFacade authenticationFacade;
    private final ContentService contentService;
    private final de.diefuturisten.easyr.easyrapi.service.CategoryService campaignService;
    private final SlideshowImageService slideshowImageService;

    public ContentController(AuthenticationFacade authenticationFacade, ContentService contentService, de.diefuturisten.easyr.easyrapi.service.CategoryService campaignService, SlideshowImageService slideshowImageService) {
        this.authenticationFacade = authenticationFacade;
        this.contentService = contentService;
        this.campaignService = campaignService;
        this.slideshowImageService = slideshowImageService;
    }

    @DeleteMapping("/campaign/content/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_DELETE)
    public boolean deleteContent(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        contentService.deleteContent(content);
        return true;
    }

    @PutMapping("/campaign/content/{contentId}/up")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public boolean moveContentUp(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return contentService.moveUp(content);
    }

    @PutMapping("/campaign/content/{contentId}/down")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public boolean moveContentDown(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return contentService.moveDown(content);
    }

    @PostMapping("/campaign/{campaignId}/webview")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public WebviewContentModel createWebviewContent(@PathVariable long campaignId, @Valid @RequestBody CreateWebviewContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        WebviewContent webviewContent = contentService.createWebviewContent(campaign, model);
        return new WebviewContentModel(webviewContent);
    }

    @PutMapping("/campaign/webview/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public WebviewContentModel editWebviewContent(@PathVariable long contentId, @Valid @RequestBody CreateWebviewContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        WebviewContent content = (WebviewContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        WebviewContent webviewContent = contentService.editWebviewContent(content, model);
        return new WebviewContentModel(webviewContent);
    }

    @PostMapping("/campaign/{campaignId}/audio")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public AudioContentModel createAudioContent(@PathVariable long campaignId, @Valid @RequestBody CreateAudioContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        AudioContent content = contentService.createAudioContent(campaign, model);
        return new AudioContentModel(content);
    }

    @PutMapping("/campaign/audio/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public AudioContentModel editAudioContent(@PathVariable long contentId, @Valid @RequestBody CreateAudioContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();
        AudioContent content = (AudioContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        AudioContent editedContent = contentService.editAudioContent(content, model);
        return new AudioContentModel(editedContent);
    }

    @PostMapping("/campaign/{campaignId}/movie")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public MovieContentModel createMovieContent(@PathVariable long campaignId, @RequestBody CreateMovieContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        MovieContent content = contentService.createMovieContent(campaign, model);
        return new MovieContentModel(content);
    }


    @PostMapping("/campaign/{campaignId}/panorama")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public PanoramaContentModel createPanoramaContent(@PathVariable long campaignId, @RequestBody CreatePanoramaContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        PanoramaContent content = contentService.createPanoramaContent(campaign, model);
        return new PanoramaContentModel(content);
    }

    @PostMapping("/campaign/{campaignId}/unity")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public UnityContentModel createUnityContent(@PathVariable long campaignId, @RequestBody CreateUnityContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        UnityContent content = contentService.createUnityContent(campaign, model);
        return new UnityContentModel(content);
    }

    @PostMapping("/campaign/{campaignId}/moreinfo")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public MoreInfoContentModel createMoreinfoContent(@PathVariable long campaignId, @RequestBody CreateMoreinfoContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        MoreInfoContent content = contentService.createMoreinfoContent(campaign, model);
        return new MoreInfoContentModel(content);
    }

    @PostMapping("/campaign/{campaignId}/slideshow")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
    public SlideshowContentModel createSlideshowContent(@PathVariable long campaignId, @RequestBody CreateSlideshowContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        SlideshowContent content = contentService.createSlideshowContent(campaign, model);
        return new SlideshowContentModel(content);
    }


    @PostMapping("/slideshow/{slideshowId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_CREATE)
    public SlideshowImageModel createImageToSlideshowContent(@PathVariable long slideshowId, @RequestBody CreateSlideshowImageModel model) {

        SlideshowImage image = contentService.createSlideshowImage(slideshowId, model);

        return new SlideshowImageModel(image);
    }

    @DeleteMapping("/slideshowimage/{imageId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_DELETE)
    public SlideshowImageModel deleteImageFromSlideshowContent(@PathVariable long imageId) {

        SlideshowImage image = contentService.deleteSlideshowImage(imageId);

        return new SlideshowImageModel(image);
    }


    @PutMapping("/campaign/movie/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public MovieContentModel editMovieContent(@PathVariable long contentId, @Valid @RequestBody EditMovieContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        MovieContent content = (MovieContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        MovieContent editedContent = contentService.editMovieContent(content, model);
        return new MovieContentModel(editedContent);
    }


    @PutMapping("/campaign/panorama/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public PanoramaContentModel editPanoramaContent(@PathVariable long contentId, @Valid @RequestBody EditPanoramaContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        PanoramaContent content = (PanoramaContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        PanoramaContent editedContent = contentService.editPanoramaContent(content, model);
        return new PanoramaContentModel(editedContent);
    }



    @PutMapping("/campaign/unity/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public UnityContentModel editUnityContent(@PathVariable long contentId, @Valid @RequestBody EditUnityContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        UnityContent content = (UnityContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        UnityContent editedContent = contentService.editUnityContent(content, model);
        return new UnityContentModel(editedContent);
    }

    @PutMapping("/campaign/moreinfo/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public MoreInfoContentModel editMoreinfoContent(@PathVariable long contentId, @Valid @RequestBody CreateMoreinfoContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        MoreInfoContent content = (MoreInfoContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        MoreInfoContent editedContent = contentService.editMoreinfoContent(content, model);
        return new MoreInfoContentModel(editedContent);
    }

    @PutMapping("/campaign/slideshow/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public SlideshowContentModel editSlideshowContent(@PathVariable long contentId, @Valid @RequestBody EditSlideshowContentModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        SlideshowContent content = (SlideshowContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }
        SlideshowContent editedContent = contentService.editSlideshowContent(content, model);
        return new SlideshowContentModel(editedContent);
    }

    @PutMapping("/slideshow/image/{imageId}/up")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public SlideshowContentModel moveImageUp(@PathVariable long imageId) {
        User user = authenticationFacade.getAuthenticatedUser();

        SlideshowImage image = slideshowImageService.getById(imageId).orElseThrow(ForbiddenException::new);

        if(!image.getSlideshow().getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        slideshowImageService.moveUp(image);

        return new SlideshowContentModel(image.getSlideshow());
    }

    @PutMapping("/slideshow/image/{imageId}/down")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public SlideshowContentModel moveImageDown(@PathVariable long imageId) {
        User user = authenticationFacade.getAuthenticatedUser();
        SlideshowImage image = slideshowImageService.getById(imageId).orElseThrow(ForbiddenException::new);

        if(!image.getSlideshow().getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        slideshowImageService.moveDown(image);

        return new SlideshowContentModel(image.getSlideshow());
    }

    @PutMapping("/campaign/content/{contentId}/name")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
    public Object renameContent(@PathVariable long contentId, @RequestBody de.diefuturisten.easyr.easyrapi.model.request.EditProductNameModel model) {
        User user = authenticationFacade.getAuthenticatedUser();

        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!content.getCampaign().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        Content renamedContent = contentService.rename(content, model);

        if(renamedContent instanceof AudioContent) {
            return new AudioContentModel((AudioContent) renamedContent);
        } else if(renamedContent instanceof MovieContent) {
            return new MovieContentModel((MovieContent) renamedContent);
        } else if(renamedContent instanceof PanoramaContent) {
            return new PanoramaContentModel((PanoramaContent) renamedContent);
        } else if(renamedContent instanceof SlideshowContent) {
            return new SlideshowContentModel((SlideshowContent) renamedContent);
        } else if(renamedContent instanceof UnityContent) {
            return new UnityContentModel((UnityContent) renamedContent);
        } else if(renamedContent instanceof WebviewContent) {
            return new WebviewContentModel((WebviewContent) renamedContent);
        } else if(renamedContent instanceof MoreInfoContent) {
            return new MoreInfoContentModel((MoreInfoContent) renamedContent);
        } else {
            return null;
        }
    }

}