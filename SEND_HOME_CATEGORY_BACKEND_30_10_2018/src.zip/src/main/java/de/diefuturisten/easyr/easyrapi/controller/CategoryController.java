package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.CategoryService;
import org.springframework.security.access.prepost.PreAuthorize;
import javax.validation.Valid;
import java.util.stream.Stream;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Category;

@RestController
@RequestMapping("/api")
public class CategoryController {


    private final CategoryService categoryService;
    private final AuthenticationFacade authenticationFacade;

    public CategoryController(CategoryService categoryService, AuthenticationFacade authenticationFacade) {
        this.categoryService = categoryService;
        this.authenticationFacade = authenticationFacade;
    }

    @GetMapping("/categories")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_LIST)
    public Stream<CategoryOverviewModel> getAllCategoriesForUser() {

        User user = authenticationFacade.getAuthenticatedUser();
        return categoryService
                .getCategoriesForUser(user)
                .stream()
                .map(CategoryOverviewModel::new);
    }

    @GetMapping("/category/{id}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_GET)
    public CategoryDetailModel getCategory(@PathVariable long id) throws ForbiddenException {

        User user = authenticationFacade.getAuthenticatedUser();

        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        return new CategoryDetailModel(category);
    }

    @PostMapping("/category")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel createCategory() {
        User user = authenticationFacade.getAuthenticatedUser();
        Category createdCategory = this.categoryService.createEmptyCategory(user);
        return new CategoryDetailModel(createdCategory);
    }

    @PostMapping("/category/{id}/save")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_CREATE)
    public CategoryDetailModel saveNewCategory(@PathVariable long id, @Valid @RequestBody SaveNewCategoryModel model) throws NoRuntimePackageAvailableException {
        User user = authenticationFacade.getAuthenticatedUser();
        Category category = categoryService.getCategory(id).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }
        return new CategoryDetailModel(categoryService.saveNewCategory(category, model, user));
    }

    @PutMapping("/category")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CATEGORY_EDIT)
    public CategoryDetailModel editCategory(@Valid @RequestBody EditCategoryModel editCategoryModel) throws ForbiddenException {
        User user = authenticationFacade.getAuthenticatedUser();

        Category category = categoryService.getCategory(editCategoryModel.getId()).orElseThrow(ForbiddenException::new);

        if(!category.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        Category editedCategory = categoryService.editCategory(category, editCategoryModel);

        return new CategoryDetailModel(editedCategory);
    }


}
