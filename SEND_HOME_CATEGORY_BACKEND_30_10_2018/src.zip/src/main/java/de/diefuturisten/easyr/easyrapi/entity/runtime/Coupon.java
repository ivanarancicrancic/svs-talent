package de.diefuturisten.easyr.easyrapi.entity.runtime;

import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="coupons")
public class Coupon {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_coupon")
    private long id;

    @ManyToOne()
    @JoinColumn(name = "fk_user")
    private User user;

    @ManyToOne()
    @JoinColumn(name = "fk_package", nullable = false)
    private RuntimePackage runtimePackage;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start")
    private Date validFrom;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ende")
    private Date validTo;

    @Column(name = "valid_unlimited", nullable = false)
    private boolean validUnlimited;

    @Column(name = "discount", nullable = false)
    private double discountPercentage;

    @Column(name = "code")
    private String code;

    @OneToOne(mappedBy="usedCoupon")
    private PackageBuy packageBuy;

    public Coupon() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public RuntimePackage getRuntimePackage() {
        return runtimePackage;
    }

    public void setRuntimePackage(RuntimePackage runtimePackage) {
        this.runtimePackage = runtimePackage;
    }

    public Date getValidFrom() {
        return validFrom;
    }

    public void setValidFrom(Date validFrom) {
        this.validFrom = validFrom;
    }

    public Date getValidTo() {
        return validTo;
    }

    public void setValidTo(Date validTo) {
        this.validTo = validTo;
    }

    public boolean isValidUnlimited() {
        return validUnlimited;
    }

    public void setValidUnlimited(boolean validUnlimited) {
        this.validUnlimited = validUnlimited;
    }

    public double getDiscountPercentage() {
        return discountPercentage;
    }

    public void setDiscountPercentage(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public PackageBuy getPackageBuy() {
        return packageBuy;
    }

    public void setPackageBuy(PackageBuy packageBuy) {
        this.packageBuy = packageBuy;
    }
}
