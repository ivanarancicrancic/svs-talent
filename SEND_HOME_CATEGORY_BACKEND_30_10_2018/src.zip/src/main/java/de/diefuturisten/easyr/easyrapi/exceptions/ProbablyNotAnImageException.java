package de.diefuturisten.easyr.easyrapi.exceptions;

public class ProbablyNotAnImageException extends Throwable {
}
