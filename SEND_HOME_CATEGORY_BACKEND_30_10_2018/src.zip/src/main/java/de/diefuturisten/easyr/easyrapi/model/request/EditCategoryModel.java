package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class EditCategoryModel {

    @NotNull
    private Long id;

    @NotBlank
    private String name;

    public EditCategoryModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
