package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import javax.validation.Valid;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type;

@Service
@Transactional
public class PanoramaContentService {

    private final ContentRepository contentRepository;

    public PanoramaContentService(ContentRepository contentRepository) {
        this.contentRepository = contentRepository;
    }

    public PanoramaContent create(Campaign campaign, @Valid CreatePanoramaContentModel model) {
        PanoramaContent content = new PanoramaContent();
        content.setCampaign(campaign);
        content.setName(model.getName());
        content.setUrl(model.getUrl());

        content.setType(Type.valueOf(model.getSubType()));

        Optional<Content> contentWithHeighestWeight = contentRepository.findFirstByCampaignOrderByWeightDesc(campaign);
        if (contentWithHeighestWeight.isPresent()) {
            content.setWeight(contentWithHeighestWeight.get().getWeight() + 1);
        } else {
            content.setWeight(1);
        }

        return contentRepository.save(content);
    }

    public PanoramaContent edit(PanoramaContent content, @Valid EditPanoramaContentModel model) {
        // content.setName(model.getName());
        content.setUrl(model.getUrl());

        content.setType(Type.valueOf(model.getSubType()));

        return contentRepository.save(content);
    }


}
