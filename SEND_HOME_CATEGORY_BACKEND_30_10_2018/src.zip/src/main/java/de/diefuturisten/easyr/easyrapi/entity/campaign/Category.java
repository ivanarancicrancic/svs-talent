package de.diefuturisten.easyr.easyrapi.entity.campaign;

import com.fasterxml.jackson.annotation.JsonIgnore;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="categories")
public class Category {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_campaign")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="campaign")
    private List<CategoryImage> images = new java.util.ArrayList<>();

    @OneToMany(mappedBy="campaign")
    private List<Product> products = new java.util.ArrayList<>();

    // getter & setter
    public Category(){}

    public Category(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getTotalImages() {
        return images.stream().mapToLong(CategoryImage::getCategoryImages).sum();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonIgnore
    public List<CategoryImages> getCategoryImages() {
        return images;
    }

    public void setCategoryImages(List<CategoryImages> images) {
        this.images = images;
    }

    public List<Content> getProducts() {
        return products;
    }

    public void setProducts(List<CategoryImages> products) {
        this.products = products;
    }

}
