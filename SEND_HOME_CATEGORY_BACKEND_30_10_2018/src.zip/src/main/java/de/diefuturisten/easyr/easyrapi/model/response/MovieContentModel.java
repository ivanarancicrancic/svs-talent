package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;

public class MovieContentModel extends ContentModel {

    private String url;

    private float positionX;
    private float positionY;
    private float positionZ;

    private float rotationX;
    private float rotationY;
    private float rotationZ;

    private float scaleX;
    private float scaleY;
    private float scaleZ;

    private boolean renderOnTrackingLost;
    private boolean extendedTracking;

    private String subType;

    public MovieContentModel(MovieContent content) {
        super(content, "movie");
        this.url = content.getUrl();

        this.positionX = content.getPositionX();
        this.positionY = content.getPositionY();
        this.positionZ = content.getPositionZ();

        this.rotationX = content.getRotationX();
        this.rotationY = content.getRotationY();
        this.rotationZ = content.getRotationZ();

        this.scaleX = content.getScaleX();
        this.scaleY = content.getScaleY();
        this.scaleZ = content.getScaleZ();

        this.extendedTracking = content.isExtendedTracking();
        this.renderOnTrackingLost = content.isRenderOnTrackingLost();

        this.subType = content.getType().toString();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public float getPositionX() {
        return positionX;
    }

    public void setPositionX(float positionX) {
        this.positionX = positionX;
    }

    public float getPositionY() {
        return positionY;
    }

    public void setPositionY(float positionY) {
        this.positionY = positionY;
    }

    public float getPositionZ() {
        return positionZ;
    }

    public void setPositionZ(float positionZ) {
        this.positionZ = positionZ;
    }

    public float getRotationX() {
        return rotationX;
    }

    public void setRotationX(float rotationX) {
        this.rotationX = rotationX;
    }

    public float getRotationY() {
        return rotationY;
    }

    public void setRotationY(float rotationY) {
        this.rotationY = rotationY;
    }

    public float getRotationZ() {
        return rotationZ;
    }

    public void setRotationZ(float rotationZ) {
        this.rotationZ = rotationZ;
    }

    public float getScaleX() {
        return scaleX;
    }

    public void setScaleX(float scaleX) {
        this.scaleX = scaleX;
    }

    public float getScaleY() {
        return scaleY;
    }

    public void setScaleY(float scaleY) {
        this.scaleY = scaleY;
    }

    public float getScaleZ() {
        return scaleZ;
    }

    public void setScaleZ(float scaleZ) {
        this.scaleZ = scaleZ;
    }

    public boolean isRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }

    public boolean isExtendedTracking() {
        return extendedTracking;
    }

    public void setExtendedTracking(boolean extendedTracking) {
        this.extendedTracking = extendedTracking;
    }

    public String getSubType() {
        return subType;
    }

    public void setSubType(String subType) {
        this.subType = subType;
    }
}
