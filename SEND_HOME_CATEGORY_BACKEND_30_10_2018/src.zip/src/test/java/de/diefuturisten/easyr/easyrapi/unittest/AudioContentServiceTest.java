package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;

public class AudioContentServiceTest {
    private ContentRepository contentRepository;
    private AudioContentService audioContentService;
    private AudioContent audioContent;
    private Campaign campaign;

    @Before
    public void setUp() {
        contentRepository = mock(ContentRepository.class);
        audioContent = mock(AudioContent.class);
        campaign = mock(Campaign.class);
        audioContentService = new AudioContentService(contentRepository);
    }

    @Test
    public void create_contentWithHeighestWeightPresent(){
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setName("audioContentName");
        createAudioContentModel.setType("SPHERE");
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setUrl("someurl");
        createAudioContentModel.setWeight(3);
        Content content = audioContent;
        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(audioContent);

        assertNotNull(audioContentService.create(campaign, createAudioContentModel));
    }

    @Test
    public void create_contentWithHeighestWeightNotPresent(){
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setName("audioContentName");
        createAudioContentModel.setType("SPHERE");
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setUrl("someurl");
        createAudioContentModel.setWeight(3);
        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(Content.class))).thenReturn(audioContent);

        assertNotNull(audioContentService.create(campaign, createAudioContentModel));
    }

    @Test
    public void edit(){
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setName("audioContentName");
        createAudioContentModel.setType("SPHERE");
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setUrl("someurl");
        createAudioContentModel.setWeight(3);
        Content content = audioContent;
        Mockito.when(contentRepository.save(content)).thenReturn(content);

        assertNotNull(audioContentService.edit(audioContent, createAudioContentModel));
    }
}
