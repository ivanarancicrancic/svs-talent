package de.diefuturisten.easyr.easyrapi.unittest;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;

public class CampaignControllerUnit {
    private MockMvc mockMvc;
    private de.diefuturisten.easyr.easyrapi.controller.CategoryController campaignController;
    private de.diefuturisten.easyr.easyrapi.service.CategoryService campaignService;
    private AuthenticationFacade authenticationFacade;
    private ObjectMapper mapper;
    private Campaign mockCampaign;
    private Campaign mockCampaign1;
    private Campaign mockCampaign2;
    private User mockUser;
    private User mockUser1;
    private RuntimePackage runtimePackage;

    @Before
    public void setUp(){
        campaignService = mock(de.diefuturisten.easyr.easyrapi.service.CategoryService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        mockCampaign = mock(Campaign.class);
        mockCampaign1 = mock(Campaign.class);
        mockCampaign2 = mock(Campaign.class);
        mockUser = mock(User.class);
        mockUser1 = mock(User.class);
        runtimePackage = mock(RuntimePackage.class);
        campaignController = new de.diefuturisten.easyr.easyrapi.controller.CategoryController(campaignService, authenticationFacade);

        CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
        campaignDetailModel.setName("CAMPAIGN LALA");
        campaignDetailModel.setDescription("This is campaign about...");

        mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
        mapper= new ObjectMapper();
    }

//    @Test
//    public void getDetailsForCampaign() throws Exception {
//
//        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
//        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
//        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
//
//        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
//                "/api/campaign/" + 1).accept(
//                MediaType.APPLICATION_JSON);
//
//        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//    }

    @Test
    public void getDetailsForCampaignNoCampaign() throws Exception {

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void getDetailsForCampaignUserNotEqual() throws Exception {

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void getAllCampaignsForUser() throws Exception {
        List<Campaign> campaignList = new java.util.ArrayList<>();
        campaignList.add(mockCampaign);
        campaignList.add(mockCampaign1);
        campaignList.add(mockCampaign2);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaignsForUser(Mockito.any(User.class))).thenReturn(campaignList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaigns").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }


    @Test
    public void createCampaign() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.createEmptyCampaign(Mockito.any(User.class))).thenReturn(mockCampaign);

        // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaign() throws NoRuntimePackageAvailableException, Exception {
        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel saveNewCampaignModel = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

        // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaignNoCampaign() throws NoRuntimePackageAvailableException, Exception {
        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel saveNewCampaignModel = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

         // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void saveNewCampaignUserNotEqual() throws NoRuntimePackageAvailableException, Exception {
        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel saveNewCampaignModel = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(campaignService.saveNewCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/save")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(saveNewCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }


    @Test()
    public void editCampaign() throws Exception {
        de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel campaignEdit = new de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel.class))).thenReturn(mockCampaign);

         RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editCampaignNoCampaignAvailable() throws Exception {
        de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel campaignEdit = new de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editCampaignUserNotEqual() throws Exception {
        de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel campaignEdit = new de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel.class))).thenReturn(mockCampaign);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }
}
