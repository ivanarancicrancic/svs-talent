package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import java.util.List;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository;

public class CampaignServiceTest {
    private User user;
    private de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository;
    private CampaignRuntimeService campaignRuntimeService;
    private de.diefuturisten.easyr.easyrapi.service.CategoryService campaignService;
    private Campaign campaign;
    private Campaign campaign1;
    private PackageBuy packageBuy;
    private RuntimePackage runtimePackage1;
    private RuntimePackage runtimePackage2;
    private Runtime runtime;
    private RuntimeRepository runtimeRepository;

    @Before
    public void setUp() {
        user = mock(User.class);
        campaignRepository = mock(de.diefuturisten.easyr.easyrapi.repository.CategoryRepository.class);
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        campaign = mock(Campaign.class);
        campaign1 = mock(Campaign.class);
        packageBuy = mock(PackageBuy.class);
        runtimePackage1 = mock(RuntimePackage.class);
        runtimePackage2 = mock(RuntimePackage.class);
        runtime = mock(Runtime.class);
        runtimeRepository = mock(RuntimeRepository.class);
        campaignService = new de.diefuturisten.easyr.easyrapi.service.CategoryService(campaignRepository, campaignRuntimeService);
      }

    @Test
    public void findAllCampaigns(){
        List<Campaign> campaignList = new ArrayList<>();
        campaignList.add(campaign);
        campaignList.add(campaign1);

        Mockito.when(campaignRepository.findAll()).thenReturn(campaignList);

        assertNotNull(campaignService.findAllCampaigns());
    }

    @Test
    public void getCampaignsForUser(){
        List<Campaign> campaignList = new ArrayList<>();
        campaignList.add(campaign);
        campaignList.add(campaign1);

        Mockito.when(campaignRepository.findByUser(Mockito.any(User.class))).thenReturn(campaignList);

        assertNotNull(campaignService.getCampaignsForUser(user));
    }

    @Test
    public void getCampaign(){

        Mockito.when(campaignRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(campaign));

        assertNotNull(campaignService.getCampaign(1L));
    }

    @Test
    public void createEmptyCampaign(){

        Mockito.when(campaignRepository.save(Mockito.any(Campaign.class))).thenReturn(campaign);

        assertNotNull(campaignService.createEmptyCampaign(user));
    }

    @Test
    public void saveNewCampaign() throws NoRuntimePackageAvailableException{

        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel model = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        model.setPackageId(1L);

        List<RuntimePackage> runtimePackageList = new ArrayList<>();
        runtimePackageList.add(runtimePackage1);
        runtimePackageList.add(runtimePackage2);

        Mockito.when(campaignRuntimeService.userHasPackageAvailable(Mockito.any(User.class), Mockito.anyLong())).thenReturn(packageBuy);
        Mockito.when(campaignRepository.save(Mockito.any(Campaign.class))).thenReturn(campaign);
        Mockito.when(packageBuy.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(runtimeRepository.save(Mockito.any(Runtime.class))).thenReturn(runtime);

        assertNotNull(campaignService.saveNewCampaign(campaign, model, user));

        }

    @Test(expected = NoRuntimePackageAvailableException.class)
    public void saveNewCampaign_AvailablePackageBuyNull() throws NoRuntimePackageAvailableException{

        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel model = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        model.setPackageId(1L);

        List<RuntimePackage> runtimePackageList = new java.util.ArrayList<>();
        runtimePackageList.add(runtimePackage1);
        runtimePackageList.add(runtimePackage2);

        Mockito.when(campaignRuntimeService.userHasPackageAvailable(Mockito.any(User.class), Mockito.anyLong())).thenReturn(null);
        Mockito.when(campaignRepository.save(Mockito.any(Campaign.class))).thenReturn(campaign);
        Mockito.when(packageBuy.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(runtimeRepository.save(Mockito.any(Runtime.class))).thenReturn(runtime);

        campaignService.saveNewCampaign(campaign, model, user);

        campaignService.createEmptyCampaign(user);
          }

    @Test
    public void editCampaign() throws NoRuntimePackageAvailableException{
        de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel editCampaignModel = new de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel();
        editCampaignModel.setId(1L);
        editCampaignModel.setName("Neue Campaigne Name");

        Mockito.when(campaignRepository.save(Mockito.any(Campaign.class))).thenReturn(campaign);

        assertNotNull(campaignService.editCampaign(campaign, editCampaignModel));

    }

}
