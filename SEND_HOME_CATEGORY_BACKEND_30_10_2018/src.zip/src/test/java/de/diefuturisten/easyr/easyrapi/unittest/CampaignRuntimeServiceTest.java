package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.service.AdminService;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository;
import de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository;
import de.diefuturisten.easyr.easyrapi.repository.CouponRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import java.util.List;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.exceptions.CouponNotFoundException;
import java.util.NoSuchElementException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoMoneyException;
import de.diefuturisten.easyr.easyrapi.exceptions.RuntimePackageNotFoundException;

public class CampaignRuntimeServiceTest {
    private User user;
    private User user1;
    private AdminService adminService;
    private RuntimePackageRepository runtimePackageRepository;
    private CouponRepository couponRepository;
    private PackageBuyRepository packageBuyRepository;
    private RuntimeRepository runtimeRepository;
    private CampaignRuntimeService campaignRuntimeService;
    private RuntimePackage runtimePackage1;
    private RuntimePackage runtimePackage2;
    private Coupon coupon;
    private PackageBuy packageBuy;
    private Runtime runtime;

    @Before
    public void setUp() {
        user = mock(User.class);
        user1 = mock(User.class);
        adminService = mock(AdminService.class);
        runtimePackageRepository = mock(RuntimePackageRepository.class);
        couponRepository = mock(CouponRepository.class);
        packageBuyRepository = mock(PackageBuyRepository.class);
        runtimeRepository = mock(RuntimeRepository.class);
        runtimePackage1 = mock(RuntimePackage.class);
        runtimePackage2 = mock(RuntimePackage.class);
        packageBuy = mock(PackageBuy.class);
        coupon = mock(Coupon.class);
        runtime = mock(Runtime.class);
        campaignRuntimeService = new CampaignRuntimeService(runtimePackageRepository, couponRepository, packageBuyRepository, runtimeRepository, adminService);
    }

    @Test
    public void getAllPackages(){
        List<RuntimePackage> runtimePackageList = new ArrayList<>();
        runtimePackageList.add(runtimePackage1);
        runtimePackageList.add(runtimePackage2);
        Mockito.when(runtimePackageRepository.findAll()).thenReturn(runtimePackageList);
        assertNotNull(campaignRuntimeService.getAllPackages());
    }

    @Test
    public void checkCoupon_hasCoupon() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        assertNotNull(campaignRuntimeService.checkCoupon(user, runtimePackage1, model));
       }

    @Test(expected = CouponNotFoundException.class)
    public void checkCoupon_NoCouponFoundById() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.checkCoupon(user, runtimePackage1, model);
    }

    @Test(expected = CouponNotFoundException.class)
    public void checkCoupon_NoCouponFoundByCode() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.empty());
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.checkCoupon(user, runtimePackage1, model);
    }

    @Test(expected = CouponNotFoundException.class)
    public void checkCoupon_couponUserNotEqual() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user1);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.checkCoupon(user, runtimePackage1, model);
    }

    @Test(expected = CouponNotFoundException.class)
    public void checkCoupon_runtimePackageNotEqual() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage2);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.checkCoupon(user, runtimePackage1, model);
    }

    @Test(expected = CouponNotFoundException.class)
    public void checkCoupon_packageBuyNull() throws CouponNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(null);

        campaignRuntimeService.checkCoupon(user, runtimePackage1, model);
    }

    @Test
    public void createCoupon() throws NoSuchElementException{
        CreateCouponAdminModel model = new CreateCouponAdminModel();
        model.setUserId(1L);
        model.setPercentage(new Double(12.202));
        model.setPackageId(1L);

        Mockito.when(adminService.getUserByID(Mockito.anyLong())).thenReturn(Optional.of(user));
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(couponRepository.save(Mockito.any(Coupon.class))).thenReturn(coupon);

        campaignRuntimeService.createCoupon(model);
    }

    @Test(expected = NoSuchElementException.class)
    public void createCoupon_noSuchUser() throws NoSuchElementException{
        CreateCouponAdminModel model = new CreateCouponAdminModel();
        model.setUserId(1L);
        model.setPercentage(new Double(12.202));
        model.setPackageId(1L);

        Mockito.when(adminService.getUserByID(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(couponRepository.save(Mockito.any(Coupon.class))).thenReturn(coupon);

        campaignRuntimeService.createCoupon(model);
    }

    @Test(expected = NoSuchElementException.class)
    public void createCoupon_noSuchRuntimePackage() throws NoSuchElementException{
        CreateCouponAdminModel model = new CreateCouponAdminModel();
        model.setUserId(1L);
        model.setPercentage(new Double(12.202));
        model.setPackageId(1L);

        Mockito.when(adminService.getUserByID(Mockito.anyLong())).thenReturn(Optional.of(user));
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(couponRepository.save(Mockito.any(Coupon.class))).thenReturn(coupon);

        campaignRuntimeService.createCoupon(model);
     }

    @Test
    public void buyPackage() throws NoSuchElementException, CouponNotFoundException, NoMoneyException, RuntimePackageNotFoundException {
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(coupon.getDiscountPercentage()).thenReturn(new Double(100));
        Mockito.when(packageBuyRepository.save(Mockito.any(PackageBuy.class))).thenReturn(packageBuy);
        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        assertNotNull(campaignRuntimeService.buyPackage(user, model));
    }

    @Test(expected = RuntimePackageNotFoundException.class)
    public void buyPackage_NoRuntimePackageFound() throws NoSuchElementException, CouponNotFoundException, NoMoneyException, RuntimePackageNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(coupon.getDiscountPercentage()).thenReturn(new Double(100));
        Mockito.when(packageBuyRepository.save(Mockito.any(PackageBuy.class))).thenReturn(packageBuy);
        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.buyPackage(user, model);
    }

    @Test(expected = NoMoneyException.class)
    public void buyPackage_NoCoupon() throws NoSuchElementException, CouponNotFoundException, NoMoneyException, RuntimePackageNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setPackageId(1L);

        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(coupon.getDiscountPercentage()).thenReturn(new Double(100));
        Mockito.when(packageBuyRepository.save(Mockito.any(PackageBuy.class))).thenReturn(packageBuy);
        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.buyPackage(user, model);
    }

    @Test(expected = NoMoneyException.class)
    public void buyPackage_discountPercentageNotValid() throws NoSuchElementException, CouponNotFoundException, NoMoneyException, RuntimePackageNotFoundException{
        BuyPackageRequestModel model = new BuyPackageRequestModel();
        model.setCouponCode("389538989BB647");
        model.setPackageId(1L);
        model.setCouponId(1L);

        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(coupon.getDiscountPercentage()).thenReturn(new Double(90.535));
        Mockito.when(packageBuyRepository.save(Mockito.any(PackageBuy.class))).thenReturn(packageBuy);
        Mockito.when(couponRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(coupon));
        Mockito.when(couponRepository.findFirstByCode(Mockito.anyString())).thenReturn(Optional.of(coupon));
        Mockito.when(coupon.getUser()).thenReturn(user);
        Mockito.when(coupon.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(coupon.getPackageBuy()).thenReturn(packageBuy);

        campaignRuntimeService.buyPackage(user, model);
    }

    @Test
    public void userHasPackageAvailable() throws NullPointerException{
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(packageBuyRepository.findFirstByUserAndRuntimePackageAndUsedOnRuntimeIsNull(Mockito.any(User.class), Mockito.any(RuntimePackage.class))).thenReturn(Optional.of(packageBuy));
        assertNotNull(campaignRuntimeService.userHasPackageAvailable(user, 1L));
    }

    @Test
    public void userHasPackageAvailable_runtimePackageNull(){
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(packageBuyRepository.findFirstByUserAndRuntimePackageAndUsedOnRuntimeIsNull(Mockito.any(User.class), Mockito.any(RuntimePackage.class))).thenReturn(Optional.of(packageBuy));
        assertNull(campaignRuntimeService.userHasPackageAvailable(user, 1L));
    }

    @Test
    public void userHasPackageAvailable_noValidPackageBuyFound(){
        Mockito.when(runtimePackageRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(runtimePackage1));
        Mockito.when(packageBuyRepository.findFirstByUserAndRuntimePackageAndUsedOnRuntimeIsNull(Mockito.any(User.class), Mockito.any(RuntimePackage.class))).thenReturn(Optional.empty());
        assertNull(campaignRuntimeService.userHasPackageAvailable(user, 1L));
    }

    @Test
    public void getPackagesForUser(){
        List<RuntimePackage> runtimePackageList = new ArrayList<>();
        runtimePackageList.add(runtimePackage1);
        runtimePackageList.add(runtimePackage2);

        Mockito.when(packageBuyRepository.countAvailable(Mockito.any(User.class), Mockito.any(RuntimePackage.class))).thenReturn(1L);
        Mockito.when(packageBuyRepository.countUsed(Mockito.any(User.class), Mockito.any(RuntimePackage.class))).thenReturn(1L);
        Mockito.when(runtimePackageRepository.findAll()).thenReturn(runtimePackageList);

        assertNotNull(campaignRuntimeService.getPackagesForUser(user));
    }

    @Test
    public void createRuntime(){
        List<RuntimePackage> runtimePackageList = new ArrayList<>();
        runtimePackageList.add(runtimePackage1);
        runtimePackageList.add(runtimePackage2);

        Mockito.when(packageBuy.getRuntimePackage()).thenReturn(runtimePackage1);
        Mockito.when(runtimeRepository.save(runtime)).thenReturn(runtime);

        assertNotNull(campaignRuntimeService.getPackagesForUser(user));
    }
}
