package de.diefuturisten.easyr.easyrapi.unittest;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.controller.MobileApiController;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

public class MobileApiControllerTest {
    private MockMvc mockMvc;
    private TrackerService trackerService;
    private MobileApiController mobileApiController;
    private User user;
    private Campaign mockCampaign;
    private Tracker mockTracker;

    @Before
    public void setUp() throws Exception {
        trackerService = mock(TrackerService.class);
        user = mock(User.class);
        mockCampaign = mock(Campaign.class);
        mockTracker = mock(Tracker.class);
        mobileApiController =new MobileApiController(trackerService);
        mockMvc = MockMvcBuilders.standaloneSetup(mobileApiController).build();
    }

    @Test
    public void getTracker() throws Exception {
        Mockito.when(trackerService.getTrackerByVuforiaId(Mockito.anyString())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/app/tracker/" + 1 + "/").accept(
                        MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }
}
