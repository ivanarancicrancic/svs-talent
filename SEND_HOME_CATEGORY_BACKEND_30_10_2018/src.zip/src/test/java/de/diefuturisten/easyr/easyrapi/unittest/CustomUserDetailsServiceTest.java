package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import static org.mockito.Mockito.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import java.util.Optional;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.service.CustomUserDetailsService;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import java.util.Set;
import org.springframework.security.authentication.AccountExpiredException;
import java.util.HashSet;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

public class CustomUserDetailsServiceTest {
    private User user;
    private UserRepository userRepository;
    private CustomUserDetailsService customUserDetailsService;
    private UserRole userRole;
    private UserRole userRole1;
    private UserRole userRole2;

    @Before
    public void setUp() {
        user = mock(User.class);
        userRepository = mock(UserRepository.class);
        userRole = mock(UserRole.class);
        userRole1 = mock(UserRole.class);
        userRole2 = mock(UserRole.class);
        customUserDetailsService = new CustomUserDetailsService(userRepository);
    }

    @Test
    public void loadUserByUsername_UserIsActive(){
        Set<UserRole> userRoleList = new HashSet<>();
        userRoleList.add(userRole);
        userRoleList.add(userRole1);
        userRoleList.add(userRole2);

        Mockito.when(userRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.of(user));
        Mockito.when(user.isActive()).thenReturn(true);
        Mockito.when(user.getUsername()).thenReturn("name");
        Mockito.when(user.getPassword()).thenReturn("password");
        Mockito.when(user.getRoles()).thenReturn(userRoleList);

        assertNotNull(customUserDetailsService.loadUserByUsername("name"));
    }

    @Test(expected = UsernameNotFoundException.class)
    public void loadUserByUsername_UsernameNotFound(){
        Mockito.when(userRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.empty());
        Mockito.when(user.isActive()).thenReturn(true);

        assertNotNull(customUserDetailsService.loadUserByUsername("name"));
    }

    @Test(expected = AccountExpiredException.class)
    public void loadUserByUsername_UserNotActive(){
        Mockito.when(userRepository.findByEmail(Mockito.anyString())).thenReturn(Optional.of(user));
        Mockito.when(user.isActive()).thenReturn(false);

        assertNotNull(customUserDetailsService.loadUserByUsername("name"));
    }

    @Test
    public void getAuthorities(){
        Set<UserRole> userRoleList = new HashSet<>();
        userRoleList.add(userRole);
        userRoleList.add(userRole1);
        userRoleList.add(userRole2);

        Mockito.when(user.getRoles()).thenReturn(userRoleList);

        assertNotNull(CustomUserDetailsService.getAuthorities(user));
    }
}
