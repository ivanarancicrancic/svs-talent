package de.diefuturisten.easyr.easyrapi.integration;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.junit.Test;
import org.junit.Before;
import org.springframework.boot.test.context.SpringBootTest;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRightRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository;
import de.diefuturisten.easyr.easyrapi.repository.ResetPasswordTokenRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository;
import de.diefuturisten.easyr.easyrapi.repository.CouponRepository;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class CampaignControllerIT {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ContactInformationRepository contactInformationRepository;

    @Autowired
    private TrackerRepository trackerRepository;

    @Autowired
    private ContentRepository contentRepository;

    @Autowired
    private RuntimeRepository runtimeRepository;

    @Autowired
    private de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository;

    @Autowired
    private ResetPasswordTokenRepository resetPasswordTokenRepository;

    @Autowired
    private UserRoleRepository userRoleRepository;

    @Autowired
    private UserRightRepository userRightRepository;

    @Autowired
    private PackageBuyRepository packageBuyRepository;

    @Autowired
    private CouponRepository couponRepository;

    @Autowired
    private RuntimePackageRepository runtimePackageRepository;

    private Campaign campaign;
    private RuntimePackage runtimePackage;
    private ObjectMapper mapper;
    private String token;

    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
        IntegrationTestHelper.prepareCampaignData(campaignRepository,  userRepository, contactInformationRepository, contentRepository, trackerRepository, runtimeRepository);
        IntegrationTestHelper.prepareTrackerData(trackerRepository, campaignRepository, userRepository);
        IntegrationTestHelper.prepareContentData(contentRepository, campaignRepository, userRepository);
        IntegrationTestHelper.prepareContactData(contactInformationRepository, campaignRepository, userRepository);
        IntegrationTestHelper.prepareRuntimeData(runtimeRepository, packageBuyRepository, userRepository, couponRepository, runtimePackageRepository, campaignRepository);
        this.campaign = campaignRepository.findAll().stream().findFirst().get();
        this.runtimePackage = runtimePackageRepository.findAll().stream().findFirst().get();
        mapper = new ObjectMapper();
        token = IntegrationTestHelper.createLoginToken(userRepository.findByEmail("easyr@app-logik.de").get());
    }

    @Test
    @Transactional
    public void getAllCampaignsForUser() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaigns").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void getCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = get("/api/campaign/" + campaign.getId()).header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void createCampaign() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaign").header("Content-Type","application/json").header("Authorization", token);
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }


    @Test
    @Transactional
    public void saveNewCampaign() throws Exception{
        de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel saveNewCampaignModel = new de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel();
        saveNewCampaignModel.setPackageId(runtimePackage.getId());
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = post("/api/campaign/" + campaign.getId() + "/save").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL).writeValueAsString(saveNewCampaignModel));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
  }

    @Test
    @Transactional
    public void editCampaign() throws Exception{
        de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel editCampaignModel =  new de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel();
        editCampaignModel.setId(campaign.getId());
        editCampaignModel.setName("Name");
        assertNotNull(token);
        MockHttpServletRequestBuilder requestBuilder = put("/api/campaign").header("Content-Type","application/json").header("Authorization", token).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL).writeValueAsString(editCampaignModel));
        this.mvc.perform(requestBuilder).andExpect(status().isOk());
    }

}
