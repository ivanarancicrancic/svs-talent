package de.diefuturisten.easyr.easyrapi.unittest;

import org.springframework.test.web.servlet.MockMvc;
import  org.junit.Before;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import de.diefuturisten.easyr.easyrapi.controller.UserController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;

public class UserControllerTest {
    private MockMvc mockMvc;
    private AuthenticationFacade authenticationFacade;
    private User user;
    private UserController userController;

    @Before
    public void setUp() throws Exception {
        authenticationFacade = mock(AuthenticationFacade.class);
        user = mock(User.class);
        userController =new UserController(authenticationFacade);
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    @Test
    public void createAccount() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .get("/api/user")
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

}
