package de.diefuturisten.easyr.easyrapi.integration;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.*;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRightRepository;
import  de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository;
import de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository;
import de.diefuturisten.easyr.easyrapi.repository.CouponRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;

public class IntegrationTestHelper {
    private static User user;
    private static ContactInformation contactInfo;

    public static String createLoginToken(User user){
        java.util.Date expirationTime = new java.util.Date(System.currentTimeMillis() + EXPIRATION_TIME);
        String token = io.jsonwebtoken.Jwts.builder().
                setSubject(user.getUsername()).
                setExpiration(expirationTime).
                signWith(io.jsonwebtoken.SignatureAlgorithm.HS512, SECRET.getBytes()).
                compact();
        return TOKEN_PREFIX + token;
    }

    public static void prepareUserData(UserRepository userRepository, UserRoleRepository userRoleRepository, UserRightRepository userRightRepository){
        UserRight userRight = new UserRight("Admin role");
        UserRight userRight1 = new UserRight("CAMPAIGN_CREATE");
        UserRight updateUserRight = new UserRight("CAMPAIGN_LIST");
        UserRight viewCampaignRight = new UserRight("CAMPAIGN_GET");
        UserRight editCampaignRight = new UserRight("CAMPAIGN_EDIT");

        userRightRepository.save(userRight);
        userRightRepository.save(userRight1);
        userRightRepository.save(updateUserRight);
        userRightRepository.save(viewCampaignRight);
        userRightRepository.save(editCampaignRight);

        UserRole userRole1 = new UserRole("User");
        userRole1.addRight(userRight);
        userRole1.addRight(userRight1);
        userRole1.addRight(updateUserRight);
        userRole1.addRight(viewCampaignRight);
        userRole1.addRight(editCampaignRight);
        userRoleRepository.save(userRole1);

        UserRole userRole = new UserRole("Admin");
        userRole.addRight(userRight);
        userRoleRepository.save(userRole);

        User user = new User();
        user.setFirstname("Easy");
        user.setLastname("R");
        user.setEmail("easyr@app-logik.de");
        user.setGender(true);
        user.setActive(false);
        user.addRole(userRole);
        user.addRole(userRole1);
        user.setPassword("$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq");
        user.setLanguage("EN");
        userRepository.save(user);
    }

    public static void prepareContactData(ContactInformationRepository contactInformationRepository, de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository, UserRepository userRepository){
        System.out.println("ENTERED PREPARE CONTACT-INFO: ");
        ContactInformation contactInfo = new ContactInformation();
        contactInfo.setCity("Munich");
        contactInfo.setCompany("some-company");
        contactInfo.setEmail("easyr@app-logik.de");
        contactInfo.setHomepage("appLogik.de");
        contactInfo.setAddress("Munich Strasse");
        contactInfo.setAddress2("Haupt Strasse");
        contactInfo.setNumber("+3456885332");
        contactInfo.setZip("1234");
        contactInfo.setName("contact");

        Campaign campaign = campaignRepository.findByUser(userRepository.findByEmail("easyr@app-logik.de").get()).get(0);
        java.util.List<Campaign> campaignList = new java.util.ArrayList<>();
        campaignList.add(campaign);
        contactInfo.setCampaigns(campaignList);
        contactInfo = contactInformationRepository.save(contactInfo);

        campaign.setContact(contactInfo);
        campaignRepository.save(campaign);
    }

    public static void prepareTrackerData(TrackerRepository trackerRepository, de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository, UserRepository userRepository){
        Tracker tracker = new Tracker();
        tracker.setVuforiaId("583978956FF");
        tracker.setUrl("http://example.com/");
        tracker.setCampaign(null);
        tracker.setTrackings(0);

        Campaign campaign = campaignRepository.findByUser(userRepository.findByEmail("easyr@app-logik.de").get()).get(0);
        tracker.setCampaign(campaign);
        tracker = trackerRepository.save(tracker);

        java.util.List<Tracker> trackerList = new java.util.ArrayList<>();
        trackerList.add(tracker);
        campaign.setTracker(trackerList);
        campaignRepository.save(campaign);
    }

    public static void prepareContentData(ContentRepository contentRepository, de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository, UserRepository userRepository){
        PanoramaContent panoramaContent = new PanoramaContent();
        panoramaContent.setUrl("http://example.com/");
        panoramaContent.setName("name");
        panoramaContent.setWeight(1);
        panoramaContent.setType(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);

        Campaign campaign = campaignRepository.findByUser(userRepository.findByEmail("easyr@app-logik.de").get()).get(0);
        panoramaContent.setCampaign(campaign);
        contentRepository.save(panoramaContent);

        java.util.List<Content> contentList = new java.util.ArrayList<>();
        contentList.add(panoramaContent);
        campaign.setContents(contentList);
        campaignRepository.save(campaign);
    }

    public static void prepareRuntimeData(RuntimeRepository runtimeRepository, PackageBuyRepository packageBuyRepository, UserRepository userRepository, CouponRepository couponRepository, RuntimePackageRepository runtimePackageRepository, de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository){

        RuntimePackage runtimePackage = new RuntimePackage();
        runtimePackage.setBuys(null);
        runtimePackage.setName("RuntimeName");
        runtimePackage.setLengthInDays(2);
        runtimePackage.setPrice(new java.math.BigDecimal(2354.555));
        runtimePackage = runtimePackageRepository.save(runtimePackage);

        Coupon coupon = new Coupon();
        coupon.setUser(null);
        coupon.setValidTo(new java.util.Date());
        coupon.setValidFrom(new java.util.Date());
        coupon.setCode("53749478DFF");
        coupon.setPackageBuy(null);
        coupon.setRuntimePackage(runtimePackage);
        coupon.setValidUnlimited(false);
        coupon.setDiscountPercentage(new Double(8.9));
        couponRepository.save(coupon);

        PackageBuy packageBuy = new PackageBuy();
        packageBuy.setUsedOnRuntime(null);
        packageBuy.setUser(userRepository.findByEmail("easyr@app-logik.de").get());
        packageBuy.setRuntimePackage(runtimePackage);
        packageBuy.setBoughtAt(new java.util.Date());
        packageBuy.setUsedCoupon(coupon);
        packageBuy = packageBuyRepository.save(packageBuy);

        Runtime runtime = new Runtime();
        runtime.setBegin(new java.util.Date());
        runtime.setEnd(new java.util.Date());
        java.util.List<Campaign> campaignList = campaignRepository.findByUser(userRepository.findByEmail("easyr@app-logik.de").get());
        runtime.setCampaign(campaignList.get(0));
        runtime.setPackageBuy(packageBuy);
        runtime = runtimeRepository.save(runtime);

//        packageBuy.setUsedOnRuntime(runtime);
        packageBuyRepository.save(packageBuy);

        java.util.List<Runtime> runtimeList = new java.util.ArrayList<>();
        runtimeList.add(runtime);
        campaignList.get(0).setRuntimes(runtimeList);
       Campaign campaign = campaignRepository.save(campaignList.get(0));
        java.util.List<Content> campaignContents = campaign.getContents();
        campaignContents.sort(java.util.Comparator.comparingInt(Content::getWeight));
        campaignRepository.save(campaign);
    }

    public static void prepareCampaignData(de.diefuturisten.easyr.easyrapi.repository.CategoryRepository campaignRepository, UserRepository userRepository, ContactInformationRepository contactInformationRepository, ContentRepository contentRepository, TrackerRepository trackerRepository, RuntimeRepository runtimeRepository){
        Campaign campaign = new Campaign();
        campaign.setUser(userRepository.findByEmail("easyr@app-logik.de").get());
        campaign.setContents(contentRepository.findAll());
        campaign.setName("CampaignName");
        java.util.List<de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime> runtimeList = runtimeRepository.findAll();
        campaign.setRuntimes(runtimeList);
        campaign.setDescription("Some description...");
        campaign.setTemporary(true);
        java.util.List<Tracker> trackerList = trackerRepository.findAll();
        campaign.setTracker(trackerList);
        campaignRepository.save(campaign);
    }

}
