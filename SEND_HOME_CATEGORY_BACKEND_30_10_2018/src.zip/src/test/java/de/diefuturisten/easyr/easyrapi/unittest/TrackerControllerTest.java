package de.diefuturisten.easyr.easyrapi.unittest;

import org.springframework.test.web.servlet.MockMvc;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.FileStorageService;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.controller.TrackerController;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.junit.Test;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ProbablyNotAnImageException;
import org.mockito.Mockito;
import org.springframework.web.multipart.MultipartFile;
import java.util.Optional;
import org.springframework.mock.web.MockMultipartFile;
import java.io.File;
import java.util.concurrent.CompletableFuture;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.RequestBuilder;
import java.nio.file.Files;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.mock.web.MockHttpServletResponse;
import static org.junit.Assert.assertEquals;
import org.springframework.http.HttpStatus;

public class TrackerControllerTest {
    private MockMvc mockMvc;
    private TrackerController trackerController;
    private TrackerService trackerService;
    private AuthenticationFacade authenticationFacade;
    private de.diefuturisten.easyr.easyrapi.service.CategoryService campaignService;
    private FileStorageService fileStorageService;
    private Campaign mockCampaign;
    private Tracker mockTracker;
    private User mockUser;
    private User mockUser1;
    private File mockFile;
    private MockMultipartFile mockMultipartFile;

    @Before
    public void setUp(){
        trackerService = mock(TrackerService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        campaignService = mock(de.diefuturisten.easyr.easyrapi.service.CategoryService.class);
        mockTracker = mock(Tracker.class);
        mockCampaign = mock(Campaign.class);
        mockUser = mock(User.class);
        mockUser1 = mock(User.class);
        mockFile = mock(File.class);
        mockMultipartFile = mock(MockMultipartFile.class);
        fileStorageService = mock(FileStorageService.class);
        trackerController =new TrackerController(authenticationFacade, trackerService, campaignService, fileStorageService);
        mockMvc = MockMvcBuilders.standaloneSetup(trackerController).build();
    }

    @Test
    public void createTracker() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);

        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(mockFile);
        Mockito.when(trackerService.createTrackerForCampaign(Mockito.any(Campaign.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/1/tracker")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createTracker_NoCampaign() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);

        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(mockFile);
        Mockito.when(trackerService.createTrackerForCampaign(Mockito.any(Campaign.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/1/tracker")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic"));

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/1/tracker")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createTracker_UserNotEqual() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);

        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(mockFile);
        Mockito.when(trackerService.createTrackerForCampaign(Mockito.any(Campaign.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/1/tracker")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createTracker_ConvertedFileNull() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);

        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(null);
        Mockito.when(trackerService.createTrackerForCampaign(Mockito.any(Campaign.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/1/tracker")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.NOT_FOUND.value(), response.getStatus());
    }

    @Test
    public void updateTracker() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile mockMultipartFile1 = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(mockTracker);


        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(mockMultipartFile1)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void updateTracker_NoTracker() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile1 = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(multipartFile1)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void updateTracker_UserNotEqual() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(mockTracker);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void updateTracker_SizeNotValid() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/msg-1-fc-40.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "msg-1-fc-40.jpg", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }


    @Test
    public void updateTracker_NoValidExtension() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/Rotating_earth.gif");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile multipartFile = new MockMultipartFile("file", "Rotating_earth.gif", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(mockTracker);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(multipartFile)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void updateTracker_EditedTrackerNull() throws Exception, ProbablyNotAnImageException {
        File file = new File("src/test/resources/boat.jpg");
        byte[] bytes = Files.readAllBytes(file.toPath());
        MockMultipartFile mockMultipartFile1 = new MockMultipartFile("file", "boat.jpg", "image/jpg", bytes);
        CompletableFuture<Tracker> compatibleTracker = CompletableFuture.completedFuture(mockTracker);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(fileStorageService.storeTemporaryTrackerFile(Mockito.any(MultipartFile.class))).thenReturn(file);
        Mockito.when(trackerService.editTracker(Mockito.any(Tracker.class), Mockito.any(File.class))).thenReturn(null);

        MvcResult result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/api/campaign/tracker/1")
                .file(mockMultipartFile1)
                .param("name", "FileUploadTest.txt")
                .param("uploadedBy", "Ivana Rancic")).andReturn();

        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }

    @Test
    public void deleteTracker() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(trackerService.deleteTracker(Mockito.any(Tracker.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/tracker/" + 1).accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void deleteTracker_NoTracker() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(trackerService.deleteTracker(Mockito.any(Tracker.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/tracker/" + 1).accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void deleteTracker_UserNotEqual() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser1);
        Mockito.when(trackerService.deleteTracker(Mockito.any(Tracker.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/tracker/" + 1).accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void deleteTracker_resFalse() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(mockUser);
        Mockito.when(trackerService.getTrackerById(Mockito.anyLong())).thenReturn(Optional.of(mockTracker));
        Mockito.when(mockTracker.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(mockUser);
        Mockito.when(trackerService.deleteTracker(Mockito.any(Tracker.class))).thenReturn(false);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/tracker/" + 1).accept(
                MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.BAD_REQUEST.value(), response.getStatus());
    }
}
