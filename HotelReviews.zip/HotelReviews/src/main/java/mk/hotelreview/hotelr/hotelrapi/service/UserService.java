package mk.hotelreview.hotelr.hotelrapi.service;

import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import mk.hotelreview.hotelr.hotelrapi.entity.user.ResetPasswordToken;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.CreateAccountModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditAccountModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.ForgotPasswordModel;
import mk.hotelreview.hotelr.hotelrapi.repository.HotelRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.ResetPasswordTokenRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRoleRepository;
import mk.hotelreview.hotelr.hotelrapi.security.SecurityConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private ResetPasswordTokenRepository resetPasswordTokenRepository;
    private MailingService mailingService;
    private final UserRoleRepository userRoleRepository;
    private final HotelRepository hotelRepository;


    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, ResetPasswordTokenRepository resetPasswordTokenRepository, MailingService mailingService, UserRoleRepository userRoleRepository, HotelRepository hotelRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.resetPasswordTokenRepository = resetPasswordTokenRepository;
        this.mailingService = mailingService;
        this.userRoleRepository = userRoleRepository;
        this.hotelRepository = hotelRepository;
    }

    public User getUserByUsername(String username) {
        System.out.println("Username to search: " + username);
        return userRepository.findByEmail(username).orElseThrow(NoSuchElementException::new);
    }


    public Optional<User> getUserByUserId(long userId) {
        return userRepository.findById(userId);
    }

    public User create(CreateAccountModel model) {
        User user = new User();

        user.setActive(true);
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());
        user.setEmail(model.getEmail());
        user.setPassword(passwordEncoder.encode(model.getPassword()));
        user.setLanguage(model.getLanguage());
        user.setGender(model.getGender());
        user.setCity(model.getCity());
        user.setCountry(model.getCountry());

        userRoleRepository.findByName("Standard").ifPresent(defaultRole -> {
            user.addRole(defaultRole);
        });

        userRepository.save(user);

        try {
            mailingService.sendNewUserWelcome(user);
        } catch (CannotSendEmailException e) {
            log.error(String.format("Welcome E-Mail could not be send for user:", user.getEmail()));
        }

        return user;
    }

    public User edit(User user, EditAccountModel model) {

        user.setGender(model.getGender());
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());

        if(model.getPassword().length() > 0) {
            user.setPassword(passwordEncoder.encode(model.getPassword()));
        }

        user.setCity(model.getCity());
        user.setCountry(model.getCountry());

        userRepository.save(user);
        return user;
    }

    public void forgotPassword(ForgotPasswordModel model) throws CannotSendEmailException {
        try {
            User user = getUserByUsername(model.getEmail());
            deleteOldToken(user);
            ResetPasswordToken token = createAndSaveNewToken(user);
            mailingService.sendPasswordResetToken(user, token.getToken());
        } catch(NoSuchElementException e) {
            return;
        }

    }

    public void deleteOldToken(User user) {
        resetPasswordTokenRepository.findByUser(user).ifPresent(token -> resetPasswordTokenRepository.delete(token));
    }

    public ResetPasswordToken createAndSaveNewToken(User user) {
        String tokenValue = UUID.randomUUID().toString().replace("-", "").substring(0, SecurityConstants.PASSWORD_RESET_TOKEN_LENGTH).toUpperCase();

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, SecurityConstants.PASSWORD_RESET_TOKEN_EXPIRE_DAYS);

        ResetPasswordToken token = new ResetPasswordToken(user, cal.getTime(), tokenValue);
        resetPasswordTokenRepository.save(token);

        log.info(String.format("Created ResetPasswordToken for user %s: %s", user.getEmail(), token.getToken()));

        return token;
    }


    public boolean resetPassword(User user, String tokenValue, String userDefinedPassword) throws CannotSendEmailException {
        Optional<ResetPasswordToken> savedToken = resetPasswordTokenRepository.findByUserAndToken(user, tokenValue);
        if( !savedToken.isPresent() ){
            return false;
        }

        // check validity
        boolean valid = new Date().before(savedToken.get().getExpires());

        // delete token
        deleteOldToken(user);

        // set new password
        user.setPassword(passwordEncoder.encode(userDefinedPassword));

        // send email to user
        mailingService.sendNewPassword(user);

        return valid;
    }

    public List<User> getAllUser() {
        return userRepository.findAll();
    }
}
