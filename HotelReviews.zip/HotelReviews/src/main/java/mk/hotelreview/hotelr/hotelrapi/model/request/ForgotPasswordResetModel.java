package mk.hotelreview.hotelr.hotelrapi.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ForgotPasswordResetModel {

    @NotBlank
    private String email;

    @NotNull
    private String token;

    @NotBlank
    private String newPassword;

    public ForgotPasswordResetModel() {
    }

    public ForgotPasswordResetModel(String username, String token, String newPassword) {
        this.email = username;
        this.token = token;
        this.newPassword = newPassword;
    }

    public String getEmail() {
        return email;
    }

    public String getToken() {
        return token;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
