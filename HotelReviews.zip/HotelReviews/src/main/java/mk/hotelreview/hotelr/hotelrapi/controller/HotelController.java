package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.exceptions.ForbiddenException;
import mk.hotelreview.hotelr.hotelrapi.model.request.EditHotelModel;
import mk.hotelreview.hotelr.hotelrapi.model.request.SaveNewHotelModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelDetailModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelOverviewModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.HotelReviewModel;
import mk.hotelreview.hotelr.hotelrapi.security.AuthenticationFacade;
import mk.hotelreview.hotelr.hotelrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import mk.hotelreview.hotelr.hotelrapi.service.HotelService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api1")
public class HotelController {

    private final HotelService hotelService;
    private final AuthenticationFacade authenticationFacade;

    public HotelController(HotelService hotelService, AuthenticationFacade authenticationFacade) {
        this.hotelService = hotelService;
        this.authenticationFacade = authenticationFacade;
    }

    @GetMapping("/favoriteHotels")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.HOTEL_LIST)
    public Stream<HotelReviewModel> getAllFavoriteHotelsForUser() {
        User user = authenticationFacade.getAuthenticatedUser();

        return user.getHotelReviewsLiked()
                .stream()
                .map(HotelReviewModel::new);
    }


//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.HOTEL_GET)
    @RequestMapping(value = "/hotel/{hotelId}", method = RequestMethod.GET)
//    @RequestMapping(value = "/hotel", method = RequestMethod.GET)
    public HotelDetailModel getHotel(@PathVariable String hotelId) throws ForbiddenException {
//        public HotelDetailModel getHotel() throws ForbiddenException {
            System.out.println("Entered getHotel()with hotelId: " + hotelId);
//        Hotel hotel = hotelService.getHotel(Long.parseLong(hotelId)).orElseThrow(ForbiddenException::new);
        Hotel hotel = hotelService.getHotel(Long.parseLong(hotelId)).orElseThrow(ForbiddenException::new);
        return new HotelDetailModel(hotel);
    }

    @PostMapping("/hotel")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.HOTEL_CREATE)
    public HotelDetailModel createHotel() {
        User user = authenticationFacade.getAuthenticatedUser();
        Hotel createdHotel = this.hotelService.createEmptyHotel("Via Abruzzi");
        return new HotelDetailModel(createdHotel);
    }

    @PostMapping("/hotel/{id}/save")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.HOTEL_CREATE)
    public HotelDetailModel saveNewHotel(@PathVariable long id, @Valid @RequestBody SaveNewHotelModel model) throws Exception{
        User user = authenticationFacade.getAuthenticatedUser();
        Hotel hotel = hotelService.getHotel(id).orElseThrow(ForbiddenException::new);
        System.out.println("Hotel: " + hotel.getName() + ", hotel description: " + hotel.getDescription());
        return new HotelDetailModel(hotelService.saveNewHotel(hotel, model, user));
    }

    @PutMapping("/hotel")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.HOTEL_EDIT)
    public HotelDetailModel editHotel(@Valid @RequestBody EditHotelModel editHotelModel) throws ForbiddenException {
        Hotel hotel = hotelService.getHotel(editHotelModel.getId()).orElseThrow(ForbiddenException::new);
        Hotel editedHotel = hotelService.editHotel(hotel, editHotelModel);
        return new HotelDetailModel(editedHotel);
    }


}
