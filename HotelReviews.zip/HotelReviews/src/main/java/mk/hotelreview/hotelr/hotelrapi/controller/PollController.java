package mk.hotelreview.hotelr.hotelrapi.controller;


import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.request.VoteRequest;
import mk.hotelreview.hotelr.hotelrapi.model.response.PollResponse;
import mk.hotelreview.hotelr.hotelrapi.security.AuthenticationFacade;
import mk.hotelreview.hotelr.hotelrapi.service.PollService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Stream;

/**
 * Created by rajeevkumarsingh on 20/11/17.
 */

@RestController
@RequestMapping("/this/polls")
public class PollController {


    @Autowired
    private PollService pollService;

   @Autowired
   private final AuthenticationFacade authenticationFacade;

   private static final Logger logger = LoggerFactory.getLogger(PollController.class);

    public PollController(PollService pollService, AuthenticationFacade authenticationFacade) {

        this.pollService = pollService;
        this.authenticationFacade = authenticationFacade;

    }

    @GetMapping
    public Stream<PollResponse> getPolls() {

        System.out.println("getAllPolls called!");
        return pollService.getAllPolls().stream().map(PollResponse:: new);

    }

    @PostMapping("/{pollId}/votes/{choiceId}")
//    @PreAuthorize("hasRole('normal user')")
    public PollResponse castVote(@PathVariable Long pollId, @PathVariable Long choiceId,
                                  @RequestBody VoteRequest voteData) {


        System.out.println("castVote api called with voteRequest - choice ID: " + choiceId + ",pollId: " + pollId);
        User user = authenticationFacade.getAuthenticatedUser();
        System.out.println("USERRRR: " + user.toString());
        return pollService.castVoteAndGetUpdatedPoll(pollId, choiceId, user);
    }



}
