package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Feed;
import mk.hotelreview.hotelr.hotelrapi.repository.FeedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedService {


    @Autowired
    private FeedRepository feedRepository;

    public FeedService(FeedRepository feedRepository) {

        this.feedRepository = feedRepository;

    }

    public Feed saveFeed(Feed feed) {

        return feedRepository.save(feed);
    }


}
