package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Choice;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.ChoiceVoteCount;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Poll;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Vote;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.ModelMapper;
import mk.hotelreview.hotelr.hotelrapi.model.request.VoteRequest;
import mk.hotelreview.hotelr.hotelrapi.model.response.PollResponse;
import mk.hotelreview.hotelr.hotelrapi.repository.PollRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.VoteRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;


@Service
public class PollService {

    @Autowired
    private PollRepository pollRepository;

    @Autowired
    private VoteRepository voteRepository;

    @Autowired
    private UserRepository userRepository;


    private static final Logger logger = LoggerFactory.getLogger(PollService.class);

    public PollService(PollRepository pollRepository, VoteRepository voteRepository, UserRepository userRepository) {

    this.pollRepository =pollRepository;
    this.voteRepository =voteRepository;
    this.userRepository = userRepository;
        }

    public List<Poll> getAllPolls() {


        System.out.println("BEGINNNN");
        // Retrieve Polls
        List<Poll> polls = new ArrayList<>();
             polls = pollRepository.findAll().stream().collect(Collectors.toList());
        System.out.println("POLLS: " + polls);
        return polls;


        ///////////////////////////////

    }


    public Poll getPollByTitle(String title) {
        Poll poll = pollRepository.findByTitle(title);

        // Retrieve Vote Counts of every choice belonging to the current poll
//        List<ChoiceVoteCount> votes = voteRepository.countByPollIdGroupByChoiceId(pollId);
//
//        Map<Long, Long> choiceVotesMap = votes.stream()
//                .collect(Collectors.toMap(ChoiceVoteCount::getChoiceId, ChoiceVoteCount::getVoteCount));
//
//        // Retrieve poll creator details
//        User creator = userRepository.findById(poll.getCreatedBy())
//                .orElseThrow(() -> new ResourceNotFoundException("User", "id", poll.getCreatedBy()));
//
//        // Retrieve vote done by logged in user
//        Vote userVote = null;
//        if(currentUser != null) {
//            userVote = voteRepository.findByUserIdAndPollId(currentUser.getId(), pollId);
//        }

        return poll;
    }

    public PollResponse castVoteAndGetUpdatedPoll(Long pollId, Long choiceId, User user) {
        System.out.println("entered service castVoteAndGetUpdatedPoll");
//        Poll poll = pollRepository.findById(pollId).get();
        Poll poll = pollRepository.findById(new Long(1)).get();
        System.out.println("Pollllll: " + poll.toString());

//        if(poll.getExpirationDateTime().isBefore(Instant.now())) {
//            throw new BadRequestException("Sorry! This Poll has already expired");
//        }

//        User user = userRepository.getOne(currentUser.getId());

        System.out.println("CHOICESSS: " + poll.getChoices() + "Choice ID: " + choiceId);
        Choice selectedChoice = poll.getChoices().stream()
                .filter(choice -> choice.getId().equals(choiceId))
                .findFirst().get();

        System.out.println("SECLECTED CHOICE: " + selectedChoice.toString());
//                .orElseThrow(() -> new ResourceNotFoundException("Choice", "id", voteRequest.getChoiceId()));

        Vote vote = new Vote();
        vote.setPoll(poll);
        vote.setUser(user);
        vote.setChoice(selectedChoice);


        try {
            vote = voteRepository.save(vote);
        } catch (DataIntegrityViolationException ex) {
            System.out.println("Sorry! You have already cast your vote in this poll");
        }

        System.out.println("vote should be saveeeeeeeddd!!!!!");
        //-- Vote Saved, Return the updated Poll Response now --

        // Retrieve Vote Counts of every choice belonging to the current poll
        List<ChoiceVoteCount> votes = voteRepository.countByPollIdGroupByChoiceId(pollId);
        System.out.println("Here are the votes for the choices: " + votes.toString());

        Map<Long, Long> choiceVotesMap = votes.stream()
                .collect(Collectors.toMap(ChoiceVoteCount::getChoiceId, ChoiceVoteCount::getVoteCount));

        // Retrieve poll creator details
//        User creator = userRepository.findById(poll.getCreatedBy()).get();
//                .orElseThrow(() -> new ResourceNotFoundException("User", "id", poll.getCreatedBy()));

        return ModelMapper.mapPollToPollResponse(poll, choiceVotesMap, user, vote.getChoice().getId());
    }





}
