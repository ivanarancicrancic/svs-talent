package mk.hotelreview.hotelr.hotelrapi.entity.content;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;

import javax.persistence.*;

@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public abstract class Content {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_content")
    private long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="fk_hotel", nullable = false)
    private Hotel hotel;

    @Column(name="weight", nullable = false)
    private int weight;

    @Column(name="name", nullable = false)
    private String name;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}