package mk.hotelreview.hotelr.hotelrapi.vuforia;

public interface TargetStatusListener {

	public void OnTargetStatusUpdate(TargetState targetState);
}
