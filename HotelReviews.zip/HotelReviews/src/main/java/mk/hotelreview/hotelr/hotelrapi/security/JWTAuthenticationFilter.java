package mk.hotelreview.hotelr.hotelrapi.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import mk.hotelreview.hotelr.hotelrapi.model.request.UserLoginCredientialsModel;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.Principal;
import java.util.Date;
import java.util.Optional;

import static mk.hotelreview.hotelr.hotelrapi.security.SecurityConstants.EXPIRATION_TIME;
import static mk.hotelreview.hotelr.hotelrapi.security.SecurityConstants.HEADER_STRING;


public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private final ObjectMapper mapper;
    public static final String REQUEST_ATTRIBUTE_FOR_JSON = "JWTAuthenticationFilter_AuthAttribute";

    public JWTAuthenticationFilter(ObjectMapper mapper) {
        super();
        this.mapper = mapper;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainUsername(HttpServletRequest request) {
        System.out.println("OBTAIN USERNAME: "+  Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getUsername());
        return Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getUsername();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected String obtainPassword(HttpServletRequest request) {
        System.out.println("Passworddddd: " + Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getPassword());
        return Optional.ofNullable(request.getAttribute(REQUEST_ATTRIBUTE_FOR_JSON))
                .map(model -> (UserLoginCredientialsModel) model)
                .orElseThrow(() -> new AuthenticationServiceException("Could not authenticate user, as request did not contain proper JSON format."))
                .getPassword();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        // as we are parsing the request-body, we have to read the request ONCE (otherwise we are trying to re-read the inputstream, which gets closed)
        request.setAttribute(REQUEST_ATTRIBUTE_FOR_JSON, getUserLoginCredientialsModel(request));
        Authentication attemptAuthenticationResult = super.attemptAuthentication(request, response);
        // cleanup
        request.removeAttribute(REQUEST_ATTRIBUTE_FOR_JSON);
        return attemptAuthenticationResult;
    }

    /**
     * Try to read credentials model from request, as we are expecting this in JSON format instead of url-parameters.
     *
     * @param request
     *
     * @return returns empty optional of request did not contain any parsable JSON
     */
    private UserLoginCredientialsModel getUserLoginCredientialsModel(HttpServletRequest request) {
        try(ServletInputStream inputStream = request.getInputStream()){
//            System.out.println("mapper.readValue(inputStream, UserLoginCredientialsModel.class): " + mapper.readValue(inputStream, UserLoginCredientialsModel.class).getPassword());
            return mapper.readValue(inputStream, UserLoginCredientialsModel.class);
        } catch(IOException e){ // NOSONAR
            // NO-OP
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication auth) throws IOException, ServletException {
        // When authentication was successful, store the username inside the JWT-related HTTP-header
        String username = String.valueOf(auth.getPrincipal());
        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
        // tell the client our new JWT-token
        System.out.println("UserName success: " + username);
        response.addHeader(HEADER_STRING, TokenHelper.createToken(username, expirationTime));
    }
}
