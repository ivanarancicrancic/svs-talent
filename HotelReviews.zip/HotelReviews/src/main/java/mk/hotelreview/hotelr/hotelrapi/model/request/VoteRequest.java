package mk.hotelreview.hotelr.hotelrapi.model.request;
import javax.validation.constraints.NotNull;

public class VoteRequest {
    @NotNull
    private Long choiceId;

    private Long pollId;


     public VoteRequest(){}


    public VoteRequest(@NotNull Long choiceId, Long pollId) {
        this.choiceId = choiceId;
        this.pollId = pollId;
    }

    public Long getChoiceId() {
        return choiceId;
    }

    public void setChoiceId(Long choiceId) {
        this.choiceId = choiceId;
    }


    public Long getPollId() {
        return pollId;
    }

    public void setPollId(Long pollId) {
        this.pollId = pollId;
    }
}

