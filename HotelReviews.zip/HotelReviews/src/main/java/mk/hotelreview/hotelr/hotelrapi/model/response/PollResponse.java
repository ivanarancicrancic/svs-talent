package mk.hotelreview.hotelr.hotelrapi.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Choice;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.ChoiceVoteCount;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Poll;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


public class PollResponse {
    private Long id;
//    private String question;
//    private Instant creationDateTime;
//    private Instant expirationDateTime;
//    private Boolean isExpired;

    private String title;

    private String description;

    private String link;

    private String author;

    private String authorName;

    private String guid;

    private String url;

    private String summary;

    private String createdDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Long selectedChoice;

    private boolean expired;

    private Long totalVotes;

    private List<ChoiceResponse> choices;




//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getQuestion() {
//        return question;
//    }
//
//    public void setQuestion(String question) {
//        this.question = question;
//    }
//
//

//
//
//    public Instant getCreationDateTime() {
//        return creationDateTime;
//    }
//
//    public void setCreationDateTime(Instant creationDateTime) {
//        this.creationDateTime = creationDateTime;
//    }
//
//    public Instant getExpirationDateTime() {
//        return expirationDateTime;
//    }
//
//    public void setExpirationDateTime(Instant expirationDateTime) {
//        this.expirationDateTime = expirationDateTime;
//    }
//
//    public Boolean getExpired() {
//        return isExpired;
//    }
//
//    public void setExpired(Boolean expired) {
//        isExpired = expired;
//    }
//


    public PollResponse(Poll poll){

        this.id = poll.getId();
        this.title = poll.getTitle();
        this.description = poll.getDescription();
        this.link = poll.getLink();
        this.authorName = poll.getAuthor();
        System.out.println("Author @@@: " + poll.getAuthor());
//        User user = userRepository.findByEmail(poll.getAuthor()).get();
        this.author = "Oliver" + " " + "Christen";
        this.url = poll.getUrl();
        this.summary = poll.getSummary();
        this.createdDate = poll.getCreatedDate();
        this.selectedChoice =  new Long(2);

        this.expired = false;
        this.totalVotes = new Long(10);

//        ChoiceResponse choiceResponse1 = new ChoiceResponse();
//        choiceResponse1.setId(1);
//        choiceResponse1.setText("I like this info");
//        choiceResponse1.setVoteCount(new Long(10));
//
//        ChoiceResponse choiceResponse2 = new ChoiceResponse();
//        choiceResponse2.setId(2);
//        choiceResponse2.setText("I don't like this info");
//        choiceResponse2.setVoteCount(new Long(1));
//
        List<ChoiceResponse> listChoices = new ArrayList<>();
//        listChoices.add(choiceResponse1);
//        listChoices.add(choiceResponse2);
//        this.choices = listChoices;
        for(Choice c: poll.getChoices()){
            ChoiceResponse choiceResponse = new ChoiceResponse();
            choiceResponse.setId(c.getId());
            choiceResponse.setVoteCount(new Long(5));
            choiceResponse.setText(c.getText());
            System.out.println("Choiseeee: " + choiceResponse.toString());
            listChoices.add(choiceResponse);
        }

        this.choices = listChoices;

    }



    public PollResponse(){}
    public PollResponse(Long id, String title, String description, String link, String author, String guid, String url, String summary) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.link = link;
        this.author = author;
        this.guid = guid;
        this.url = url;
        this.summary = summary;

    }

    public Long isSelectedChoice() {
        return selectedChoice;
    }

    public void setSelectedChoice(Long selectedChoice) {
        this.selectedChoice = selectedChoice;
    }

    public boolean isExpired() {
        return expired;
    }

    public void setExpired(boolean expired) {
        this.expired = expired;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGuid() {
        return guid;
    }

    public void setGuid(String guid) {
        this.guid = guid;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public Long getSelectedChoice() {
        return selectedChoice;
    }

    public Long getTotalVotes() {
        return totalVotes;
    }

    public void setTotalVotes(Long totalVotes) {
        this.totalVotes = totalVotes;
    }

    public List<ChoiceResponse> getChoices() {
        return choices;
    }

    public void setChoices(List<ChoiceResponse> choices) {
        this.choices = choices;
    }
}
