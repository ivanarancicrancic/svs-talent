package mk.hotelreview.hotelr.hotelrapi.exceptions;

public class HotelReviewNotFoundException extends Throwable {
}
