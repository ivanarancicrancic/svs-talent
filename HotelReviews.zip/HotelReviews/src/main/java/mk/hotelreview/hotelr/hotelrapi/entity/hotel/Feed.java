package mk.hotelreview.hotelr.hotelrapi.entity.hotel;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "feeds")
public class Feed {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name="title", nullable = false)
    public String title;

    @Column(name="link", nullable = false)
    public String link;

    @Column(name="description", nullable = false, length = 70000)
    public String description;

    @Column(name="language", nullable = false)
    public String language;

    @Column(name="copyright", nullable = false)
    public String copyright;

    @Column(name="pub_date", nullable = false)
    public String pubDate;

    @OneToMany(mappedBy = "feed")
    public List<FeedMessage> messages = new ArrayList<>();

    public Feed(){}

    public Feed(String title, String link, String description, String language,
                String copyright, String pubDate) {
        this.title = title;
        this.link = link;
        this.description = description;
        this.language = language;
        this.copyright = copyright;
        this.pubDate = pubDate;
    }

    public List<FeedMessage> getMessages() {
        return messages;
    }


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setMessages(List<FeedMessage> messages) {
        this.messages = messages;
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public String getDescription() {
        return description;
    }

    public String getLanguage() {
        return language;
    }

    public String getCopyright() {
        return copyright;
    }

    public String getPubDate() {
        return pubDate;
    }

    @Override
    public String toString() {
        return "Feed [copyright=" + copyright + ", description=" + description
                + ", language=" + language + ", link=" + link + ", pubDate="
                + pubDate + ", title=" + title + "]";
    }

}
