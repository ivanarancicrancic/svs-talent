package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.exceptions.InvalidTrackerImageException;
import mk.hotelreview.hotelr.hotelrapi.vuforia.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;

@Service
@Transactional
public class VuforiaService {

    @Value("8874364895745498660e620f1948b")
    private String accessKey;

    @Value("5774574594758976567389032534b")
    private String secretKey;

    @Value("${hotelr.vuforia.url}")
    private String url;

    private Summary summaryApi;
    private GetAllTargets getAllTargets;
    private GetTarget getTarget;

    public VuforiaService() {
        initApis();
    }

    public VuforiaService(String url, String accessKey, String secretKey) {
        this.url = url;
        this.accessKey = accessKey;
        this.secretKey = secretKey;

        initApis();
    }

    private void initApis() {
        summaryApi = new Summary(url, accessKey, secretKey);
        getAllTargets = new GetAllTargets(url, accessKey, secretKey);
        getTarget = new GetTarget(url, accessKey, secretKey);
    }

    public String getSummary() {
        try {
            return summaryApi.getSummary();
        } catch (Exception e) {
            return null;
        }
    }

    public String getAllTargets() {
        try {
            return getAllTargets.getTargets();
        } catch (Exception e) {
            return null;
        }
    }

    public String getTarget(String targetId) {
        try {
            return getTarget.getTarget(targetId);
        } catch (Exception e) {
            return null;
        }
    }

    public String postTarget(String targetName, File file, IPostNewTargetStatusListener listener) throws InvalidTrackerImageException {
        PostNewTarget postNewTarget = new PostNewTarget(url, accessKey, secretKey);
        System.out.println("postNewTarget: " + postNewTarget);
        try {
            System.out.println("Target name: " + targetName);
            System.out.println("File: " + file.toString());
            listener = new IPostNewTargetStatusListenerImpl();
            System.out.println("listener:" + listener);
            System.out.println("postNewTarget.postTarget(targetName, file, listener) returned: " + postNewTarget.postTarget(targetName, file, listener));
            return postNewTarget.postTarget(targetName, file, listener);
        }catch (Exception e) {
            System.out.println("Exception here!");
            return null;
        }
    }

    public boolean updateTarget(String targetId, File file) {
        UpdateTarget updateTarget = new UpdateTarget(url, accessKey, secretKey);
        try {
            return updateTarget.updateTarget(targetId, file);
        } catch (Exception e) {
            return false;
        }
    }

    public boolean deleteTarget(String targetId) {
        DeleteTarget deleteTarget = new DeleteTarget(url, accessKey, secretKey);
        try {
            return deleteTarget.deleteTarget(targetId);
        } catch (Exception e) {
            return false;
        }
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
