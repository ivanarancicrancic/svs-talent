package mk.hotelreview.hotelr.hotelrapi.model.request;

import javax.validation.constraints.NotNull;

public class SaveNewHotelModel {

    @NotNull
    private String additionalInfo;

    public SaveNewHotelModel() {
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }

    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }
}
