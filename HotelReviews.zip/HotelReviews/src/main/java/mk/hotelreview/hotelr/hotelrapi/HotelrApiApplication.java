package mk.hotelreview.hotelr.hotelrapi;


import it.ozimov.springboot.mail.configuration.EnableEmailTools;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.ArrayList;
import java.util.Collections;

@SpringBootApplication
@EnableEmailTools
@EnableScheduling
public class HotelrApiApplication {
	public static void main(String[] args) {

		try {
			ArrayList<Integer> list = new ArrayList<Integer>();


			list.add(2);
			list.add(3);
			list.add(5);
			list.add(7);

			Integer max1 = Collections.max(list);

			list.remove(Integer.valueOf(max1));

			Integer max2 = Collections.max(list);

			Integer sum = max1 + max2;
			System.out.println("Max sum is: " + sum);
		}catch (Exception e){
			System.out.println("N");
		}

		SpringApplication.run(HotelrApiApplication.class, args);
	}
}
