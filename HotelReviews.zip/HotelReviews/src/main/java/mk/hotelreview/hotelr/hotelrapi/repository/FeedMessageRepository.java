package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.FeedMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FeedMessageRepository extends JpaRepository<FeedMessage, Long> {

    FeedMessage findByTitle(String title);

}
