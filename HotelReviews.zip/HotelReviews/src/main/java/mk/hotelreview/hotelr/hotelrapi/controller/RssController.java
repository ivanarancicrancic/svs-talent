package mk.hotelreview.hotelr.hotelrapi.controller;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Choice;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Feed;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.FeedMessage;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Poll;
import mk.hotelreview.hotelr.hotelrapi.entity.user.User;
import mk.hotelreview.hotelr.hotelrapi.model.response.AccountModel;
import mk.hotelreview.hotelr.hotelrapi.repository.ChoiceRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.PollRepository;
import mk.hotelreview.hotelr.hotelrapi.repository.UserRepository;
import mk.hotelreview.hotelr.hotelrapi.security.AuthenticationFacade;
import mk.hotelreview.hotelr.hotelrapi.service.FeedMessageService;
import mk.hotelreview.hotelr.hotelrapi.service.FeedService;
import mk.hotelreview.hotelr.hotelrapi.service.PollService;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.XMLEvent;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


@RestController
public class RssController {

	static final String TITLE = "title";
	static final String DESCRIPTION = "description";
	static final String CHANNEL = "channel";
	static final String LANGUAGE = "language";
	static final String COPYRIGHT = "copyright";
	static final String LINK = "link";
	static final String AUTHOR = "author";
	static final String ITEM = "item";
	static final String PUB_DATE = "pubDate";
	static final String GUID = "guid";
	static final String URL = "url";
	static final String ENCLOSURE = "enclosure";
	static final String CREATEDDATE = "createdDate";

	URL url = null;

	@Autowired
	private FeedMessageService feedMessageService;

	@Autowired
	private FeedService feedService;

	@Autowired
	private PollRepository pollRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PollService pollService;


	@Autowired
	private ChoiceRepository choiceRepository;


	public RssController(FeedMessageService feedMessageService, FeedService feedService, PollRepository pollRepository, UserRepository userRepository, PollService pollService, ChoiceRepository choiceRepository){

		this.feedMessageService = feedMessageService;
		this.feedService = feedService;
		this.pollRepository = pollRepository;
		this.userRepository = userRepository;
		this.pollService = pollService;
		this.choiceRepository = choiceRepository;

		try {
			this.url =  new URL("http://feeds.nos.nl/nosjournaal?format=xml");
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}

	}

	@GetMapping("/rssfeed")
	@Scheduled(fixedRate=3000)
	public Feed getFeedInRss() {

//		List<SampleContent> items = new ArrayList<SampleContent>();
//
//		SampleContent content  = new SampleContent();
//		content.setTitle("Spring MVC Tutorial 1");
//		content.setUrl("http://www.mkyong.com/spring-mvc/tutorial-1");
//		content.setSummary("Tutorial 1 summary ...");
//		content.setCreatedDate(new Date());
//		items.add(content);
//
//		SampleContent content2  = new SampleContent();
//		content2.setTitle("Spring MVC Tutorial 2");
//		content2.setUrl("http://www.mkyong.com/spring-mvc/tutorial-2");
//		content2.setSummary("Tutorial 2 summary ...");
//		content2.setCreatedDate(new Date());
//		items.add(content2);
//
////		ModelAndView mav = new ModelAndView();
////		mav.setViewName("rssViewer");
////		mav.addObject("feedContent", items);
//		System.out.println(items);
//           for(SampleContent s : items){
//
//			   System.out.println("Content with \n" +
//					   " Title: " + s.getTitle() +
//					   "\n Url: " + s.getUrl() +
//					   "\n Summary: " + s.getSummary() +
//					   "\n createdDate: " + s.getCreatedDate());


		Feed feed = null;
		try {
			boolean isFeedHeader = true;
			// Set header values intial to the empty string
			String description = "";
			String title = "";
			String link = "";
			String language = "";
			String copyright = "";
			String author = "";
			String pubdate = "";
			String guid = "";
			String url = "";
			String summary = "";
			String createdDate = "";
			String imageUrl = "";
			String imageName = "";
			String imageSavedUrl = "";

			// First create a new XMLInputFactory
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();

			inputFactory.setProperty(inputFactory.IS_COALESCING, new Boolean(true));

			// Setup a new eventReader
			InputStream in = read();
			XMLEventReader eventReader = inputFactory.createXMLEventReader(in);
			// read the XML document
			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					String localPart = event.asStartElement().getName()
							.getLocalPart();
					switch (localPart) {
						case ITEM:
							if (isFeedHeader) {
								isFeedHeader = false;
								feed = new Feed(title, link, description, language,
										copyright, pubdate);
							}
							event = eventReader.nextEvent();
							break;
						case TITLE:
							title = getCharacterData(event, eventReader);
							break;
						case DESCRIPTION:
							event = eventReader.nextEvent();
							if (event.getClass().getName().equals("com.ctc.wstx.evt.CompactStartElement")) {
								description = event.asStartElement().asCharacters().getData();
								System.out.println("D1: " + description);
							} else {
								description = event.asCharacters().getData();
								System.out.println("D2: " + description);
							}

							 summary = description;
//							String all = "<img src=\"http://www.01net.com/images/article/mea/150.100.790233.jpg\""; // shortened it
							String all = description;
							String s = "<img src=\"";
							int ix = all.indexOf(s)+s.length();
							System.out.println("INDEX OF S IS: " + ix);
							if(all.indexOf("\"", ix+1)!= -1){
								System.out.println("END INDEX IS: " + all.indexOf("\"", ix+1));
								imageUrl = all.substring(ix, all.indexOf("\"", ix+1));
								try {
									URL imageUrlURL = new URL(imageUrl);
									imageName = FilenameUtils.getName(imageUrlURL.getPath()); // -> file.xml
									System.out.println("ImageName: " + imageName);
									System.out.println("ImageURL: " + imageUrl);
									imageSavedUrl = downloadFile(imageUrl, imageName);
									System.out.println("ImageSavedURL: " + imageSavedUrl);
								}catch (Exception e){
									System.out.println("exception url");
								}
							}
//							description = getCharacterData(event, eventReader);
							break;
						case LINK:
							link = getCharacterData(event, eventReader);
							break;
						case GUID:
							guid = getCharacterData(event, eventReader);
							break;
						case LANGUAGE:
							language = getCharacterData(event, eventReader);
							break;
						case AUTHOR:
							author = getCharacterData(event, eventReader);
							break;
						case PUB_DATE:
							pubdate = getCharacterData(event, eventReader);
							createdDate = pubdate;
							break;
						case COPYRIGHT:
							copyright = getCharacterData(event, eventReader);
							break;

						case URL:
							url = getCharacterData(event, eventReader);
							break;

						case ENCLOSURE:
							Iterator<Attribute> attrs = event.asStartElement().getAttributes();
							summary = "";
							while (attrs.hasNext()) {
								Attribute attr = attrs.next();
								if (attr.getName().toString().equals(URL)) {
									summary = attr.getValue();
									try {
										URL imageUrl1 = new URL(summary);
										imageName = FilenameUtils.getName(imageUrl1.getPath()); // -> file.jpg
										System.out.println("ImageName: " + imageName);
										downloadFile(summary, imageName);
									}catch (Exception e){
										System.out.println("exception url");
									}
								}
							}
							break;

						case CREATEDDATE:
							createdDate = getCharacterData(event, eventReader);
							break;




					}
				} else if (event.isEndElement()) {
					if (event.asEndElement().getName().getLocalPart() == (ITEM)) {

						if(feedMessageService.getFeedMessage(title) != null){
							FeedMessage feedMessage = feedMessageService.getFeedMessage(title);
							User foundUser = userRepository.findByFirstname("Oliver").get();
							feedMessage.setAuthor(foundUser.getEmail());
							feedMessage.setDescription(description);
							feedMessage.setSummary(summary);
							feedMessage.setGuid(guid);
							feedMessage.setLink(link);
							feedMessage.setTitle(title);
							feedMessage.setUrl(url);
							feedMessage.setImageSavedUrl(imageSavedUrl);
							feedMessage.setCreatedDate(createdDate);

							feedMessageService.saveFeedMessage(feedMessage);

							feed.getMessages().add(feedMessage);
						}
                       else {
							FeedMessage message = new FeedMessage();

//						AccountModel accountModel = new AccountModel(authenticationFacade.getAuthenticatedUser());
//           if(accountModel == null)
							User foundUser = userRepository.findByFirstname("Oliver").get();

							System.out.println("account model == null: " + foundUser.getEmail());
							message.setAuthor(foundUser.getEmail());
							message.setDescription(description);
							message.setSummary(summary);
							message.setGuid(guid);
							message.setLink(link);
							message.setTitle(title);
							message.setUrl(url);
							message.setImageSavedUrl(imageSavedUrl);
							message.setCreatedDate(createdDate);


							feedMessageService.saveFeedMessage(message);
							feed.getMessages().add(message);
						}
//						final String url = enclosure.getUrl();
//						if (url != null) {
//							enclosureElement.setAttribute("url", url);
//						}


						event = eventReader.nextEvent();
						continue;
					}
				}
			}

			feedService.saveFeed(feed);
			System.out.println("Feed saved!");

			if(pollService.getPollByTitle(title) != null) {
				System.out.println("Editing poll ");
				Poll poll = pollService.getPollByTitle(title);
				User foundUser = userRepository.findByFirstname("Oliver").get();
				System.out.println("USER FOUND!!! : " + foundUser.getEmail());
				poll.setAuthor(foundUser.getEmail());
				poll.setDescription(description);
				poll.setSummary(summary);
				poll.setGuid(guid);
				poll.setLink(link);
				poll.setTitle(title);
				poll.setUrl(url);
				poll.setImageSavedUrl(imageSavedUrl);
				poll.setCreatedDate(createdDate);

				List<Choice> choices = new ArrayList<>();



	            poll = pollRepository.save(poll);

//				Choice choice1 = new Choice();
//				choice1.setText("Choice1");
//                choice1.setPoll(poll);
//
//				System.out.println("Before choice 1 saving");
//				choiceRepository.save(choice1);
//				System.out.println("choice 1 saved!");
//				choices.add(choice1);
//
//
//				Choice choice2 = new Choice();
//				choice2.setText("Choice 2");
//				choice2.setPoll(poll);
//				choiceRepository.save(choice2);
//				choices.add(choice2);
//
//
//				poll.setChoices(choices);
//				pollRepository.save(poll);
			}
			else {

				System.out.println("Choice else");
				Poll poll = new Poll();
				User foundUser = userRepository.findByFirstname("Oliver").get();
//				poll.setId(new Long(feed.getId()));
				poll.setAuthor(foundUser.getEmail());
				poll.setDescription(description);
				poll.setSummary(summary);
				poll.setGuid(guid);
				poll.setLink(link);
				poll.setTitle(title);
				poll.setUrl(url);
				poll.setImageSavedUrl(imageSavedUrl);
				poll.setCreatedDate(createdDate);

//				List<Choice> choices = new ArrayList<>();
//
//
//				Choice choice1 = new Choice();
//				choice1.setText("Choice1");
//
//				System.out.println("Before choice 1 saving");
//				choiceRepository.save(choice1);
//				System.out.println("choice 1 saved!");
//				choices.add(choice1);
//
//				Choice choice2 = new Choice();
//				choice2.setText("Choice 2");
//				choiceRepository.save(choice2);
//				choices.add(choice2);
//				poll.setChoices(choices);


//				User user1 = userRepository.findByEmail("christen@app-logik.de");
//				User user1 = userRepository.findByEmail("christ@app-logik.de")
//						.orElseThrow(() -> new BadCredentialsException("User EMAIL NOT found"));
//				if(user1 == null){
//					System.out.println("USER IS NULL");
//				}
//				poll.setCreatedBy(user1.getId());

				//        poll.setQuestion(pollRequest.getQuestion());

//				List<Choice> choices = new ArrayList<>();
//
//
//				Choice choice1 = new Choice();
//				choice1.setText("Choice1");
//
//				System.out.println("Before choice 1 saving");
//             choiceRepository.save(choice1);
//				System.out.println("choice 1 saved!");
//				choices.add(choice1);
//
//			Choice choice2 = new Choice();
//			choice2.setText("Choice 2");
//			choiceRepository.save(choice2);
//			 choices.add(choice2);
//			 poll.setChoices(choices);
//				System.out.println("CHOICES: " + poll.getChoices());

				Instant now = Instant.now();
//				poll.setCreatedAt(now);
				poll.setCreatedDate(now.toString());
				poll.setAuthor(author);
				Instant expirationDateTime = now.plus(Duration.ofDays(1)
						.plus(Duration.ofHours(3)));

				poll.setExpirationDateTime(expirationDateTime);

				System.out.println("Before saving choices");



				System.out.println("Choices should be now saved");
				pollRepository.save(poll);
				System.out.println("Poll now should be saved");


				List<Choice> choices = new ArrayList<>();



				poll = pollRepository.save(poll);


				Choice choice1 = new Choice();
				choice1.setText("Choice1");
				choice1.setPoll(poll);

				System.out.println("Before choice 1 saving");
				choiceRepository.save(choice1);
				System.out.println("choice 1 saved!");
				choices.add(choice1);


				Choice choice2 = new Choice();
				choice2.setText("Choice 2");
				choice2.setPoll(poll);
				choiceRepository.save(choice2);
				choices.add(choice2);


				poll.setChoices(choices);
				pollRepository.save(poll);




//				choice1.setPoll(poll);
//				choice2.setPoll(poll);
//			choiceRepository.save(choice1);
//			choiceRepository.save(choice2);

			}
//			choice1.setPoll(poll);
//			choice2.setPoll(poll);


		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}

		System.out.println("Feeds");

		for(FeedMessage message : feed.getMessages()){
			System.out.println("Title: " + message.getTitle());
			System.out.println("Author: " + message.getAuthor());
			System.out.println("Description: " + message.getDescription());
			System.out.println("Link: " + message.getLink());
			System.out.println("URL: " + message.getUrl());
			System.out.println("Enclosure: " + message.getSummary());
			System.out.println("CreatedDate: " + message.getCreatedDate());
		}

		return feed;



//		   }
//		return mav;

	}

	private String getCharacterData(XMLEvent event, XMLEventReader eventReader)
			throws XMLStreamException {
		String result = "";
		event = eventReader.nextEvent();
		if (event instanceof Characters) {
			result = event.asCharacters().getData();
		}
		return result;
	}




	private InputStream read() {
		try {
			return url.openStream();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	public String downloadFile(String uRl, String imageName) {

		try {
			URL url = new URL(uRl);
			InputStream in = new BufferedInputStream(url.openStream());
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[1024];
			int n = 0;
			while (-1 != (n = in.read(buf))) {
				out.write(buf, 0, n);
			}
			out.close();
			in.close();
			byte[] response = out.toByteArray();


			FileOutputStream fos = new FileOutputStream(imageName);
			fos.write(response);
			fos.close();
			return imageName;
		}
		catch (Exception e) {

			System.out.println("Exception!!");
			return null;
		}
	}


	
}