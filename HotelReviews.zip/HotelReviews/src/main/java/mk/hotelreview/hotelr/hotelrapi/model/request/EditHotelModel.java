package mk.hotelreview.hotelr.hotelrapi.model.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class EditHotelModel {

    @NotNull
    private Long id;

    @NotBlank
    private String name;

    @NotBlank
    private String discription;

    public EditHotelModel() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }
}
