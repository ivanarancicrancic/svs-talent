package mk.hotelreview.hotelr.hotelrapi.entity.hotel;

import com.fasterxml.jackson.annotation.JsonIgnore;
import mk.hotelreview.hotelr.hotelrapi.entity.content.Content;
import mk.hotelreview.hotelr.hotelrapi.entity.review.HotelReview;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="hotels")
public class Hotel {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_hotel")
    private long id;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

    @OneToMany(mappedBy="hotel")
    private List<Tracker> tracker = new java.util.ArrayList<>();

    @OneToMany(mappedBy="hotel")
    private List<Content> contents = new ArrayList<>();

    @OneToMany(mappedBy="hotel")
    private List<HotelReview> reviews = new ArrayList<>();

//    @ManyToOne()
//    @JoinColumn(name="fk_contact")
//    private ContactInformation contact;

    @Column(name="temporary", nullable = false)
    private boolean temporary = true;

//    private List<User> favorite_to_users;

    // getter & setter

    public Hotel(){}

    public Hotel(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getTotalTrackings() {
        return tracker.stream().mapToLong(Tracker::getTrackings).sum();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @JsonIgnore
    public List<Tracker> getTracker() {
        return tracker;
    }

    public void setTracker(List<Tracker> tracker) {
        this.tracker = tracker;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

//    @JsonIgnore
//    public ContactInformation getContactInformation() {
//        return contact;
//    }

//    public void setContactInformation(ContactInformation contactInformation) {
//        this.contact = contactInformation;
//    }

    public List<HotelReview> getReviews() {
        return reviews;
    }

    public void setReviews(List<HotelReview> reviews) {
        this.reviews = reviews;
    }

//    public ContactInformation getContact() {
//        return contact;
//    }
//
//    public void setContact(ContactInformation contact) {
//        this.contact = contact;
//    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

//    public List<User> getFavorite_to_users() {
//        return favorite_to_users;
//    }
//
//    public void setFavorite_to_users(List<User> favorite_to_users) {
//        this.favorite_to_users = favorite_to_users;
//    }
}
