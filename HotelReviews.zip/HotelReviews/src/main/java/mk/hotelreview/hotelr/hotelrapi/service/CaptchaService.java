package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.model.response.CaptchaModel;
import mk.hotelreview.hotelr.hotelrapi.model.response.CaptchaResponseModel;
import nl.captcha.Captcha;
import nl.captcha.backgrounds.SquigglesBackgroundProducer;
import nl.captcha.gimpy.RippleGimpyRenderer;
import nl.captcha.noise.CurvedLineNoiseProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.imageio.ImageIO;
import javax.transaction.Transactional;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.*;

@Service
@Transactional
public class CaptchaService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private static final int CAPTCHA_WIDTH = 200;
    private static final int CAPTCHA_HEIGHT = 50;

    private final Map<String, GeneratedCaptcha> captchaStore = Collections.synchronizedMap(new HashMap<>());

    public CaptchaService() {
    }

    public CaptchaModel generateCaptcha() {

        Captcha captcha = new Captcha.Builder(CAPTCHA_WIDTH, CAPTCHA_HEIGHT)
                .addText()
                .addNoise(new CurvedLineNoiseProducer())
                .addBackground(new SquigglesBackgroundProducer())
                .gimp(new RippleGimpyRenderer())
                .addBorder()
                .build();

        BufferedImage buf = captcha.getImage();
        ByteArrayOutputStream bao = new ByteArrayOutputStream();

        String b64Image = null;

        try {
            ImageIO.write(buf, "png", bao);
            bao.flush();
            byte[] imageBytes = bao.toByteArray();
            bao.close();
            b64Image = new String(Base64.getEncoder().encode(imageBytes), "UTF-8");
        } catch (Exception e) {
            return null;
        }

        String captchaId = UUID.randomUUID().toString();
        GeneratedCaptcha generatedCaptcha = new GeneratedCaptcha(captchaId, captcha.getAnswer());
        captchaStore.put(captchaId, generatedCaptcha);

        log.info(String.format("Created captcha with id %s and answer %s", generatedCaptcha.getId(), generatedCaptcha.getAnswer()));

        return new CaptchaModel(captchaId, b64Image);
    }

    public boolean verifyCaptcha(CaptchaResponseModel captchaResponse) {

        if(captchaResponse.getAnswer().equals("magicmike")) { // TODO: remove magic captcha
            return true;
        }

        GeneratedCaptcha generatedCaptcha = captchaStore.get(captchaResponse.getId());
        if(generatedCaptcha == null) {
            return false;
        } else {
            deleteCaptcha(captchaResponse.getId());
            return generatedCaptcha.getAnswer().equals(captchaResponse.getAnswer());
        }
    }

    public void deleteCaptcha(String lastId) {
        captchaStore.remove(lastId);
    }

    public static class GeneratedCaptcha {

        private String id;
        private String answer;
        private Date created;

        public GeneratedCaptcha(String id, String answer) {
            this.id = id;
            this.answer = answer;
            this.created = new Date();
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }

        public Date getCreated() {
            return created;
        }

        public void setCreated(Date created) {
            this.created = created;
        }
    }

}
