package mk.hotelreview.hotelr.hotelrapi.model.request;

public class EditContentNameModel {

    private String name;

    public EditContentNameModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
