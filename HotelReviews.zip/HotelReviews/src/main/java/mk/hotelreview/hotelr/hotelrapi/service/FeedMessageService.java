package mk.hotelreview.hotelr.hotelrapi.service;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.FeedMessage;
import mk.hotelreview.hotelr.hotelrapi.repository.FeedMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedMessageService {

    @Autowired
    private FeedMessageRepository feedMessageRepository;

    public FeedMessageService(FeedMessageRepository feedMessageRepository) {

        this.feedMessageRepository = feedMessageRepository;
    }

    public FeedMessage saveFeedMessage(FeedMessage feedMessage) {

        return feedMessageRepository.save(feedMessage);
    }


   public FeedMessage getFeedMessage(String title){

        return feedMessageRepository.findByTitle(title);

   }

}


