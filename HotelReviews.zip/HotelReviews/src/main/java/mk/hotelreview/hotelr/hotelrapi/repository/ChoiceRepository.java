package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Choice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChoiceRepository extends JpaRepository<Choice, Long> {
}
