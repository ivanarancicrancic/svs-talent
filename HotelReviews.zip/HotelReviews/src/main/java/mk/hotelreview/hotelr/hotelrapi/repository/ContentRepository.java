package mk.hotelreview.hotelr.hotelrapi.repository;

import mk.hotelreview.hotelr.hotelrapi.entity.content.Content;
import mk.hotelreview.hotelr.hotelrapi.entity.hotel.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import java.util.Optional;

@Component
public interface ContentRepository extends JpaRepository<Content, Long> {
    Optional<Content> findFirstByHotelOrderByWeightDesc(Hotel hotel);
    Optional<Content> findFirstByHotelAndWeight(Hotel hotel, int weight);
}
