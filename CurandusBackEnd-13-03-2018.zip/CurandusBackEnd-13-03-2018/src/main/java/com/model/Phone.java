package com.model;

public class Phone {
	
	private String phone;
	private String userType;
	
	public Phone(){}
	
	public Phone(String phone, String userType){ this.phone=phone; this.userType=userType;}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	

}
