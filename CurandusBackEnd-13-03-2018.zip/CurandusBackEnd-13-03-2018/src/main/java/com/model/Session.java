package com.model;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

public class Session {
  	    private int appID;
	    private String auth_key;
	    private String user;
	    private String password;
	   // private String oldToken;
	    	
		public Session(){}
	
	    public Session(int appID, String auth_key, String user, String password, String oldToken){
	    	this.appID=appID;
	    	this.auth_key=auth_key;
	    	this.user=user;
	    	this.password=password;
	    //	this.oldToken = oldToken;
	    }

//	    public String getOldToken() {
//				return oldToken;
//			}
//
//			public void setOldToken(String oldToken) {
//				this.oldToken = oldToken;
//			}
//	    
		public int getAppID() {
			return appID;
		}

		public void setAppID(int appID) {
			this.appID = appID;
		}

		public String getAuth_key() {
			return auth_key;
		}

		public void setAuth_key(String auth_key) {
			this.auth_key = auth_key;
		}

		public String getUser() {
			return user;
		}

		public void setUser(String user) {
			this.user = user;
		}

		public String getPassword() {
			return password;
		}

		public void setPassword(String password) {
			this.password = password;
		}
	    
}
