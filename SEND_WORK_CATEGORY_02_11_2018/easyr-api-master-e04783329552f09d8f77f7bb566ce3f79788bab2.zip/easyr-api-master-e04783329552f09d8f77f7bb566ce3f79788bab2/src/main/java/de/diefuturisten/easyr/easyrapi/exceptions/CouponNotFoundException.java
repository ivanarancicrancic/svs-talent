package de.diefuturisten.easyr.easyrapi.exceptions;

public class CouponNotFoundException extends Throwable {
}
