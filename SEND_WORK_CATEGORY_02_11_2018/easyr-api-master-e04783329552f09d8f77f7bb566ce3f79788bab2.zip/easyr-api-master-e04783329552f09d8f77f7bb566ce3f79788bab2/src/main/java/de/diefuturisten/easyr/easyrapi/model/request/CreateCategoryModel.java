package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotNull;

public class CreateCategoryModel {

    @NotNull
    private Long packageId;

    public CreateCategoryModel() {

    }

    public Long getPackageId() {
        return packageId;
    }

    public void setPackageId(Long packageId) {
        this.packageId = packageId;
    }
}
