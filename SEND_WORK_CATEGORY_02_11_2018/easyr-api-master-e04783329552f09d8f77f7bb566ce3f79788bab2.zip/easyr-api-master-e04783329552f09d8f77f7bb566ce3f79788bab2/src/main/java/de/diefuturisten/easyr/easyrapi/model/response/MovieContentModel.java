package de.diefuturisten.easyr.easyrapi.model.response;

public class MovieContentModel {


}
