package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.Product;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.ProductService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class ProductController {

    private final AuthenticationFacade authenticationFacade;
    private final ProductService productService;
    private final de.diefuturisten.easyr.easyrapi.service.CategoryService categoryService;
    private final SlideshowImageService slideshowImageService;

    public ProductController(AuthenticationFacade authenticationFacade, ProductService productService, de.diefuturisten.easyr.easyrapi.service.CategoryService categoryService, SlideshowImageService slideshowImageService) {
        this.authenticationFacade = authenticationFacade;
        this.productService = productService;
        this.categoryService = categoryService;
        this.slideshowImageService = slideshowImageService;
    }

    @DeleteMapping("/campaign/content/{contentId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_DELETE)
    public boolean deleteProduct(@PathVariable long contentId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);

        if(!product.getCategory().getUser().equals(user)) {
            throw new ForbiddenException();
        }

        productService.deleteProduct(product);
        return true;
    }

//    @PutMapping("/campaign/content/{contentId}/up")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public boolean moveContentUp(@PathVariable long contentId) {
//        User user = authenticationFacade.getAuthenticatedUser();
//        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);
//
//        if(!product.getCategory().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        return productService.moveUp(product);
//    }
//
//    @PutMapping("/campaign/content/{contentId}/down")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public boolean moveContentDown(@PathVariable long contentId) {
//        User user = authenticationFacade.getAuthenticatedUser();
//        Product product = productService.getById(contentId).orElseThrow(ForbiddenException::new);
//
//        if(!product.getCategory().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        return productService.moveDown(product);
//    }


//
//    @PostMapping("/campaign/{campaignId}/movie")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
//    public MovieContentModel createMovieContent(@PathVariable long campaignId, @RequestBody CreateMovieContentModel model) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        Category category = categoryService.getCategory(campaignId).orElseThrow(ForbiddenException::new);
//
//        if(!category.getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        MovieContent product = productService.createMovieContent(category, model);
//        return new MovieContentModel(product);
//    }
//
//
//    @PostMapping("/campaign/{campaignId}/slideshow")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_CREATE)
//    public SlideshowContentModel createSlideshowContent(@PathVariable long campaignId, @RequestBody CreateSlideshowContentModel model) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);
//        if(!campaign.getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        SlideshowContent content = contentService.createSlideshowContent(campaign, model);
//        return new SlideshowContentModel(content);
//    }
//
//
//    @PostMapping("/slideshow/{slideshowId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_CREATE)
//    public SlideshowImageModel createImageToSlideshowContent(@PathVariable long slideshowId, @RequestBody CreateSlideshowImageModel model) {
//
//        SlideshowImage image = contentService.createSlideshowImage(slideshowId, model);
//
//        return new SlideshowImageModel(image);
//    }
//
//    @DeleteMapping("/slideshowimage/{imageId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.IMAGE_DELETE)
//    public SlideshowImageModel deleteImageFromSlideshowContent(@PathVariable long imageId) {
//
//        SlideshowImage image = contentService.deleteSlideshowImage(imageId);
//
//        return new SlideshowImageModel(image);
//    }
//
//
//    @PutMapping("/campaign/movie/{contentId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public MovieContentModel editMovieContent(@PathVariable long contentId, @Valid @RequestBody EditMovieContentModel model) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        MovieContent content = (MovieContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
//        if(!content.getCampaign().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//        MovieContent editedContent = contentService.editMovieContent(content, model);
//        return new MovieContentModel(editedContent);
//    }
//
//
//
//    @PutMapping("/campaign/slideshow/{contentId}")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public SlideshowContentModel editSlideshowContent(@PathVariable long contentId, @Valid @RequestBody EditSlideshowContentModel model) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        SlideshowContent content = (SlideshowContent) contentService.getById(contentId).orElseThrow(ForbiddenException::new);
//        if(!content.getCampaign().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//        SlideshowContent editedContent = contentService.editSlideshowContent(content, model);
//        return new SlideshowContentModel(editedContent);
//    }
//
//    @PutMapping("/slideshow/image/{imageId}/up")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public SlideshowContentModel moveImageUp(@PathVariable long imageId) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        SlideshowImage image = slideshowImageService.getById(imageId).orElseThrow(ForbiddenException::new);
//
//        if(!image.getSlideshow().getCampaign().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        slideshowImageService.moveUp(image);
//
//        return new SlideshowContentModel(image.getSlideshow());
//    }
//
//    @PutMapping("/slideshow/image/{imageId}/down")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public SlideshowContentModel moveImageDown(@PathVariable long imageId) {
//        User user = authenticationFacade.getAuthenticatedUser();
//        SlideshowImage image = slideshowImageService.getById(imageId).orElseThrow(ForbiddenException::new);
//
//        if(!image.getSlideshow().getCampaign().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        slideshowImageService.moveDown(image);
//
//        return new SlideshowContentModel(image.getSlideshow());
//    }
//
//    @PutMapping("/campaign/content/{contentId}/name")
//    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CONTENT_EDIT)
//    public Object renameContent(@PathVariable long contentId, @RequestBody de.diefuturisten.easyr.easyrapi.model.request.EditProductNameModel model) {
//        User user = authenticationFacade.getAuthenticatedUser();
//
//        Content content = contentService.getById(contentId).orElseThrow(ForbiddenException::new);
//
//        if(!content.getCampaign().getUser().equals(user)) {
//            throw new ForbiddenException();
//        }
//
//        Content renamedContent = contentService.rename(content, model);
//
//        if(renamedContent instanceof AudioContent) {
//            return new AudioContentModel((AudioContent) renamedContent);
//        } else if(renamedContent instanceof MovieContent) {
//            return new MovieContentModel((MovieContent) renamedContent);
//        } else if(renamedContent instanceof PanoramaContent) {
//            return new PanoramaContentModel((PanoramaContent) renamedContent);
//        } else if(renamedContent instanceof SlideshowContent) {
//            return new SlideshowContentModel((SlideshowContent) renamedContent);
//        } else if(renamedContent instanceof UnityContent) {
//            return new UnityContentModel((UnityContent) renamedContent);
//        } else if(renamedContent instanceof WebviewContent) {
//            return new WebviewContentModel((WebviewContent) renamedContent);
//        } else if(renamedContent instanceof MoreInfoContent) {
//            return new MoreInfoContentModel((MoreInfoContent) renamedContent);
//        } else {
//            return null;
//        }
//    }

}