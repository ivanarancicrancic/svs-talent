package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.CategoryImage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SlideshowImageRepository extends JpaRepository<CategoryImage, Long> {
//    Optional<CategoryImage> findFirstBySlideshowOrderByWeightDesc(SlideshowContent slideshowContent);
//    Optional<CategoryImage> findFirstBySlideshowAndWeight(SlideshowContent slideshowContent, int weight);

}
