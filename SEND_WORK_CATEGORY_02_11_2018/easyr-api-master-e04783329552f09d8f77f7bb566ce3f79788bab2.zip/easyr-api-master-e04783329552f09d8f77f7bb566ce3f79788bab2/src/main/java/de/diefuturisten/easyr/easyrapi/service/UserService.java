package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.user.ResetPasswordToken;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordModel;
import de.diefuturisten.easyr.easyrapi.repository.ResetPasswordTokenRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.security.SecurityConstants;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;
    private ResetPasswordTokenRepository resetPasswordTokenRepository;
    private MailingService mailingService;
    private final UserRoleRepository userRoleRepository;
    private final RuntimePackageRepository runtimePackageRepository;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, ResetPasswordTokenRepository resetPasswordTokenRepository, MailingService mailingService, UserRoleRepository userRoleRepository, RuntimePackageRepository runtimePackageRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.resetPasswordTokenRepository = resetPasswordTokenRepository;
        this.mailingService = mailingService;
        this.userRoleRepository = userRoleRepository;
        this.runtimePackageRepository = runtimePackageRepository;
    }

    public User getUserByUsername(String username) {
        return userRepository.findByEmail(username).orElseThrow(NoSuchElementException::new);
    }


    public Optional<User> getUserByUserId(long userId) {
        return userRepository.findById(userId);
    }

    public User create(CreateAccountModel model) {
        User user = new User();

        user.setActive(true);
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());
        user.setEmail(model.getEmail());
        user.setPassword(passwordEncoder.encode(model.getPassword()));
        user.setLanguage(model.getLanguage());
        user.setGender(model.getGender());

        userRoleRepository.findByName("Standard").ifPresent(defaultRole -> {
            user.addRole(defaultRole);
        });

        // TODO: remove free packages!
        ArrayList<PackageBuy> boughtPackages = new ArrayList<>();
        for(int i = 0 ; i < 99 ; ++i) {
            PackageBuy packageBuy = new PackageBuy();
            packageBuy.setUser(user);
            packageBuy.setBoughtAt(new Date());
            packageBuy.setUsedCoupon(null);
            long pid = ((new Random().nextInt() & Integer.MAX_VALUE) % 3) + 1;
            packageBuy.setRuntimePackage(runtimePackageRepository.findById(pid).get());
            boughtPackages.add(packageBuy);
        }
        user.setBoughtPackages(boughtPackages);

        userRepository.save(user);


        try {
            mailingService.sendNewUserWelcome(user);
        } catch (CannotSendEmailException e) {
            log.error(String.format("Welcome E-Mail could not be send for user:", user.getEmail()));
        }

        return user;
    }

    public void forgotPassword(ForgotPasswordModel model) throws CannotSendEmailException {
        try {
            User user = getUserByUsername(model.getEmail());
            deleteOldToken(user);
            ResetPasswordToken token = createAndSaveNewToken(user);
            mailingService.sendPasswordResetToken(user, token.getToken());
        } catch(NoSuchElementException e) {
            return;
        }

    }

    public void deleteOldToken(User user) {
        resetPasswordTokenRepository.findByUser(user).ifPresent(token -> resetPasswordTokenRepository.delete(token)); // NOSONAR
    }

    public ResetPasswordToken createAndSaveNewToken(User user) {
        String tokenValue = UUID.randomUUID().toString().replace("-", "").substring(0, SecurityConstants.PASSWORD_RESET_TOKEN_LENGTH).toUpperCase();

        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DATE, SecurityConstants.PASSWORD_RESET_TOKEN_EXPIRE_DAYS);

        ResetPasswordToken token = new ResetPasswordToken(user, cal.getTime(), tokenValue);
        resetPasswordTokenRepository.save(token);

        log.info(String.format("Created ResetPasswordToken for user %s: %s", user.getEmail(), token.getToken()));

        return token;
    }


    public boolean resetPassword(User user, String tokenValue, String userDefinedPassword) throws CannotSendEmailException {
        Optional<ResetPasswordToken> savedToken = resetPasswordTokenRepository.findByUserAndToken(user, tokenValue);
        if( !savedToken.isPresent() ){
            return false;
        }

        // check validity
        boolean valid = new Date().before(savedToken.get().getExpires());

        // delete token
        deleteOldToken(user);

        // set new password
        user.setPassword(passwordEncoder.encode(userDefinedPassword));

        // send email to user
        mailingService.sendNewPassword(user);

        return valid;
    }

    public List<User> getAllUser() {
        return userRepository.findAll();
    }
}
