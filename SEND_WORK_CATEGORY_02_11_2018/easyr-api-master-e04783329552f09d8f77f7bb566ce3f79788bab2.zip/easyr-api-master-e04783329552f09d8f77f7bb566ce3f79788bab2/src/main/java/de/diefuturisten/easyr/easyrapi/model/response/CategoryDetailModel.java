package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.category.Category;
import de.diefuturisten.easyr.easyrapi.entity.content.Product;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CategoryDetailModel {

    private long id;
    private String name;
    private String description;
    private List<TrackerModel> tracker;
    private List<ProductModel> products;
    private boolean temporary;

    private Long activePackageId;

    public CategoryDetailModel() {
    }

    private ProductModel productToModel(Product product) {
            return new ProductModel(product);
    }

    public CategoryDetailModel(Category category) {
        this.id = category.getId();
        this.name = category.getName();
        this.description = category.getDescription();

//        this.tracker = category
//                .getTracker()
//                .stream()
//                .map(TrackerModel::new)
//                .collect(Collectors.toList());

//        List<Product> categoryProducts = category.getProducts();
//        categoryProducts.sort(Comparator.comparingInt(Product::getWeight));
//        this.products = categoryProducts
//                .stream()
//                .map(this::productToModel)
//                .collect(Collectors.toList());

//        this.temporary = category.isTemporary();

//        if(category.getRuntimes().size() > 0) {
//            this.activePackageId = category.getRuntimes().get(category.getRuntimes().size() - 1).getPackageBuy().getRuntimePackage().getId();
//        } else {
//            this.activePackageId = null;
//        }

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<TrackerModel> getTracker() {
        return tracker;
    }

    public void setTracker(List<TrackerModel> tracker) {
        this.tracker = tracker;
    }

    public List<ProductModel> getProducts() {
        return products;
    }

    public void setProducts(List<ProductModel> products) {
        this.products = products;
    }

    public boolean isTemporary() {
        return temporary;
    }

    public void setTemporary(boolean temporary) {
        this.temporary = temporary;
    }

    public Long getActivePackageId() {
        return activePackageId;
    }

    public void setActivePackageId(Long activePackageId) {
        this.activePackageId = activePackageId;
    }
}
