package de.diefuturisten.easyr.easyrapi.entity.runtime;

import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="package_buys")
public class PackageBuy {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_user_bought_package")
    private long id;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "key_user")
    private User user;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "key_package")
    private RuntimePackage runtimePackage;

    @OneToOne()
    @JoinColumn(name = "fk_runtime")
    private Runtime usedOnRuntime;

    @OneToOne()
    @JoinColumn(name = "fk_coupon")
    private Coupon usedCoupon;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "bought_at", nullable = false)
    private Date boughtAt;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public RuntimePackage getRuntimePackage() {
        return runtimePackage;
    }

    public void setRuntimePackage(RuntimePackage runtimePackage) {
        this.runtimePackage = runtimePackage;
    }

    public Coupon getUsedCoupon() {
        return usedCoupon;
    }

    public void setUsedCoupon(Coupon usedCoupon) {
        this.usedCoupon = usedCoupon;
    }

    public Date getBoughtAt() {
        return boughtAt;
    }

    public void setBoughtAt(Date boughtAt) {
        this.boughtAt = boughtAt;
    }

    public Runtime getUsedOnRuntime() {
        return usedOnRuntime;
    }

    public void setUsedOnRuntime(Runtime usedOnRuntime) {
        this.usedOnRuntime = usedOnRuntime;
    }
}
