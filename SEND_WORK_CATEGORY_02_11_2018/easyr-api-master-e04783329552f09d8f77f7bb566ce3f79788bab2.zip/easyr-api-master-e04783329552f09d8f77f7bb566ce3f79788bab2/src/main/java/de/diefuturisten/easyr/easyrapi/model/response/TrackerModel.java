package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.category.Tracker;

public class TrackerModel {

    private long id;
    private String url;

    public TrackerModel() {
    }

    public TrackerModel(Tracker tracker) {
        this.id = tracker.getId();
        this.url = tracker.getUrl();
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
