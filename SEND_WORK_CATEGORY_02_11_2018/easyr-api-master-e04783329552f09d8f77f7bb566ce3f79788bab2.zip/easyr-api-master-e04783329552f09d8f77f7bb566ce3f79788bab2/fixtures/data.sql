-- Users
INSERT INTO
  users(key_user, active, language, email, password, firstname, lastname, gender)
VALUES
  (1, true, 'de', 'christen@app-logik.de', '$2a$10$.Y9Xo0BqUoTwEqAzqv5NaefdJbpYOpIgTOvuAllvrraKNb14ywbTK', 'Oliver', 'Christen', true), -- password is "wuff"
  (2, true, 'en', 'ivana.rancic@app-logik.de', '$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq', 'Ivana', 'Rancic', true); --password is "miau"

ALTER SEQUENCE users_key_user_seq RESTART WITH 3;

-- Roles
INSERT INTO
  userroles(key_userrole, name, description)
VALUES
  (1, 'Standard', 'normal user'),
  (2, 'Admin', 'admin user');

ALTER SEQUENCE userroles_key_userrole_seq RESTART WITH 3;

-- User has Roles
INSERT INTO
  user_has_roles(fk_user, fk_userrole)
VALUES
  (1, 1),
  (1, 2);

-- Rights
INSERT INTO
  userrights(key_userright, description, name)
VALUES
  (4, 'CAMPAIGN_LIST', 'CAMPAIGN_LIST'),
  (5, 'CAMPAIGN_DELETE', 'CAMPAIGN_DELETE'),
  (6, 'CAMPAIGN_EDIT', 'CAMPAIGN_EDIT'),
  (7, 'CAMPAIGN_CREATE', 'CAMPAIGN_CREATE'),
  (8, 'CAMPAIGN_VIEW', 'CAMPAIGN_VIEW'),
  (10, 'PANORAMA_LIST', 'PANORAMA_LIST'),
  (11, 'MOVIES_LIST', 'MOVIES_LIST'),
  (12, 'AUDIO_LIST', 'AUDIO_LIST'),
  (13, 'SLIDESHOWS_LIST', 'SLIDESHOWS_LIST'),
  (14, 'ADMIN_RIGHT', 'ADMIN_RIGHT'),
  (15, 'USER_GET', 'USER_GET'),
  (16, 'PACKAGE_LIST', 'PACKAGE_LIST'),
  (17, 'PACKAGE_LIST_FOR_USER', 'PACKAGE_LIST_FOR_USER'),
  (18, 'PACKAGE_BUY', 'PACKAGE_BUY'),
  (19, 'CAMPAIGN_GET', 'CAMPAIGN_GET'),
  (20, 'CAMPAIGN_CREATE', 'CAMPAIGN_CREATE'),
  (21, 'CAMPAIGN_EDIT', 'CAMPAIGN_EDIT'),
  (22, 'TRACKER_CREATE', 'TRACKER_CREATE'),
  (23, 'TRACKER_EDIT', 'TRACKER_EDIT'),
  (24, 'TRACKER_DELETE', 'TRACKER_DELETE'),
  (25, 'CONTENT_CREATE', 'CONTENT_CREATE'),
  (26, 'CONTENT_EDIT', 'CONTENT_EDIT'),
  (27, 'CONTENT_DELETE', 'CONTENT_DELETE');
  (28, 'CATEGORY_LIST', 'CATEGORY_LIST'),
    (29, 'CATEGORY_DELETE', 'CATEGORY_DELETE'),
    (30, 'CATEGORY_EDIT', 'CATEGORY_EDIT'),
    (31, 'CATEGORY_CREATE', 'CATEGORY_CREATE'),
    (32, 'CATEGORY_VIEW', 'CATEGORY_VIEW'),


-- Role Has Rights
INSERT INTO
  role_has_rights(fk_userrole, fk_userright)
VALUES
  (1, 4),
  (1, 5),
  (1, 6),
  (1, 7),
  (1, 8),
  (1, 10),
  (1, 11),
  (1, 12),
  (1, 13),
  (1, 14), -- admin right
  (1, 15),
  (1, 16),
  (1, 17),
  (1, 18),
  (1, 19),
  (1, 20),
  (1, 21),
  (1, 22),
  (1, 23),
  (1, 24),
  (1, 25),
  (1, 26),
  (1, 27);

-- Packages
INSERT INTO
    runtime_packages(key_runtimepackage, name, length, price)
VALUES
  (1, 'Kurz', 30, 9.99),
  (2, 'Mittel', 90, 19.99),
  (3, 'Standard', 120, 29.99);

ALTER SEQUENCE runtime_packages_key_runtimepackage_seq RESTART WITH 4;

-- Coupons
INSERT INTO
    coupons(key_coupon, fk_package, fk_user, valid_unlimited, start, ende, code, discount)
VALUES
    (1, 1, 1, true, null, null, null, 100);

ALTER SEQUENCE coupons_key_coupon_seq RESTART WITH 2;

-- Bought Packages
INSERT INTO
    package_buys(key_user_bought_package, key_package, key_user, bought_at, fk_coupon)
VALUES
 (1, 1, 1, current_timestamp, 1);

ALTER SEQUENCE package_buys_key_user_bought_package_seq RESTART WITH 2;

-- Campaign
-- INSERT INTO
--     campaigns(key_campaign, fk_contact, fk_user, name, description, temporary)
-- VALUES
--     (1, null, 1, 'First campaign', 'This is my first campaign', false),
--     (2, null, 1, 'Second campaign', 'This is my second campaign', false);

-- ALTER SEQUENCE campaigns_key_campaign_seq RESTART WITH 3;

-- Runtime
-- INSERT INTO
--   runtimes(key_runtime, fk_campaign, fk_packagebuy, start, ende)
-- VALUES
--   (1, 1, 1, to_date('05.09.2018', 'DD.MM.YYYY'), to_date('04.10.2018', 'DD.MM.YYYY'));

-- ALTER SEQUENCE runtimes_key_runtime_seq RESTART WITH 2;

-- Tracker
-- INSERT INTO
--   trackers(key_tracker, fk_campaign, vuforia_id, url)
-- VALUES
--   (1, 1, '96f0cbfad4aa452a9cc6a854b16a6eda', 'https://via.placeholder.com/350x150');

-- ALTER SEQUENCE trackers_key_tracker_seq RESTART WITH 2;

-- Content
-- INSERT INTO
--   content(key_content, fk_campaign, weight, name)
-- VALUES
--   (1, 1, 1, 'My little Panorama'),
--   (2, 1, 2, 'My second Panorama'),
--   (3, 1, 3, 'My little Slideshow'),
--   (4, 1, 4, 'My second Slideshow'),
--   (5, 1, 5, 'My little Webview'),
--   (6, 1, 6, 'My second Webview'),
--   (7, 1, 7, 'My little Unity 3D Content'),
--   (8, 1, 8, 'My second Unity 3D Content'),
--   (9, 1, 9, 'My little Audio'),
--   (10, 1, 10, 'My little Movie');

-- ALTER SEQUENCE content_key_content_seq RESTART WITH 11;

-- Panoramas
-- INSERT INTO
--   content_panoramas(key_content, type, url)
-- VALUES
--   (1, 'X360', 'https://via.placeholder.com/1920x1080'),
--   (2, 'X180', 'https://via.placeholder.com/1280x720');

-- Slideshows
-- INSERT INTO
--   content_slideshows(key_content, extended_tracking, render_on_tracking_lost, position_x, position_y, position_z, rotation_x, rotation_y, rotation_z, scale_x, scale_y, scale_z)
-- VALUES
--   (3, false, false, 0, 0, 0, 0, 0, 0, 0, 0, 0),
--   (4, true, true, 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- Slideshow Images
-- INSERT INTO
--   slideshow_images(key_slideshowimage, key_content, weight, url)
-- VALUES
--   (1, 3, 1, 'http://www.example.org/slideshow1_image1.png'),
--   (2, 3, 2, 'http://www.example.org/slideshow1_image2.png'),
--   (3, 3, 3, 'http://www.example.org/slideshow1_image3.png'),

--   (4, 4, 3, 'http://www.example.org/slideshow2_image3.png'),
--   (5, 4, 2, 'http://www.example.org/slideshow2_image2.png'),
--   (6, 4, 1, 'http://www.example.org/slideshow2_image1.png');

-- Webviews
-- INSERT INTO
--   content_webviews(key_content, url)
-- VALUES
--   (5, 'http://www.google.de'),
--   (6, 'http://www.bing.de');

-- Unity Content
-- INSERT INTO
--   content_3dmodels(key_content, android_url, ios_url, extended_tracking, render_on_tracking_lost, position_x, position_y, position_z, rotation_x, rotation_y, rotation_z, scale_x, scale_y, scale_z)
-- VALUES
--   (7, 'http://www.example.org/android_dummy.zip', 'http://www.example.org/ios_dummy.zip', true, false, 0, 0, 0, 0, 0, 0, 0, 0, 0),
--   (8, 'http://www.example.org/android_dummy2.zip', 'http://www.example.org/ios_dummy2.zip', false, true, 0, 0, 0, 0, 0, 0, 0, 1, 0);

-- Audio Content
-- INSERT INTO
--   content_audios(key_content, url, render_on_tracking_lost)
-- VALUES
--   (9, 'http://www.example.org/audio.mp3', false);

-- Movie Content
-- INSERT INTO
--   content_movies(key_content, type, url, download, seekbar, extended_tracking, render_on_tracking_lost, position_x, position_y, position_z, rotation_x, rotation_y, rotation_z, scale_x, scale_y, scale_z)
-- VALUES
--   (10, 'NORMAL', 'http://www.example.org/movie.mp4', true, false, false, true, 0, 0, 0, 0, 0, 0, 0, 0, 0);