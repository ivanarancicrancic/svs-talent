package de.diefuturisten.easyr.easyrapi.unittest.controller;

import de.diefuturisten.easyr.easyrapi.controller.CampaignController;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import static org.hamcrest.Matchers.comparesEqualTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRight;

import static org.mockito.Mockito.mock;


public class CampaignControllerTest {

    private CampaignController campaignController;
    private CampaignService campaignService;
    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;
    UserRepository userRepository, UserRoleRepository userRoleRepository, UserRightRepository userRightRepository
    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        campaignService = mock(CampaignService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        campaignController =new CampaignController(campaignService, authenticationFacade, campaignRuntimeService);
//        this.campaign = campaignService.findAllCampaigns().stream().findFirst().get();

        UserRight userRight = new de.diefuturisten.easyr.easyrapi.entity.user.UserRight("Admin role");
        UserRight listRight = new UserRight("CAMPAIGN_LIST");

        userRightRepository.save(userRight);
        userRightRepository.save(listRight);
        UserRole userRole = new UserRole("Admin");
        userRole.addRight(userRight);
        userRoleRepository.save(userRole);

        UserRole userRole1 = new UserRole("User role");
        userRole1.addRight(listRight);
        userRoleRepository.save(userRole1);

        User user = new User();
        user.setFirstname("Ivica");
        user.setLastname("Taskovski");
        user.setEmail("ivica.taskovski@app-logik.de");
        user.setGender(true);
        user.setActive(false);
        //user.setId(new Long(1));
        user.addRole(userRole);
        user.addRole(userRole1);
        user.setPassword("$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq");
        user.setLanguage("EN");

        userRepository.save(user);

        ContactInformation contactInfo = new ContactInformation();
        contactInfo.setCity("Berlin");
        contactInfo.setCompany("some-company");
        contactInfo.setEmail("ivica.taskovski@app-logik.de");
        contactInfo.setHomepage("companyInBerlin.de");
        contactInfo.setAddress("Klingeln Strasse");
        contactInfo.setAddress2("Blingeln Strasse");
        contactInfo.setNumber("+3456789012");
        contactInfo.setZip("1234");

        contactInformationRepository.save(contactInfo);
        Campaign campaign = new Campaign();
        campaign.setContactInformation(contactInformationOptional.get());
        campaign.setUser(userOptional.get());
        //campaign.setId(new Long(1));


        campaignRepository.save(campaign);

        mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
        mapper= new ObjectMapper();



    }

    @Test
    public void getAllCampaignsForUser() throws Exception {
        mockMvc.perform(get("/api/campaigns/")
                .contentType("application/json")).
                andExpect(status().isOk());
    }


    @Test
    public void getCampaign() throws Exception {
        mockMvc.perform(get("/api/campaign/")
                .contentType("application/json")).
                andExpect(status().isOk());
    }

//    @Test
//    public void test_default() throws Exception {
//        SlideshowContent slideshowContent = new SlideshowContent();
//        slideshowContent.setName("ErsteSlideShow");
//        //slideshowContent.setWeight(12);
//        System.out.println(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
//                .writeValueAsString(slideshowContent));
//        mockMvc.perform((post(SlideshowContentController.BASE_URL).
//                contentType("application/json")).
//                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
//                        .writeValueAsString(slideshowContent))).
//                andExpect(status().isCreated()).
//                andExpect(jsonPath("$.weight",comparesEqualTo(0)));
//    }


}
