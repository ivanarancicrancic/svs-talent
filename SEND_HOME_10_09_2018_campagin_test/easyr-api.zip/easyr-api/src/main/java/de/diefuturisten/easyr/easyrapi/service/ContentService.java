package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.Valid;
import java.util.Optional;

@Service
@Transactional
public class ContentService {

    @Autowired
    private ContentRepository contentRepository;

    @Autowired
    private WebviewContentService webviewContentService;

    @Autowired
    private AudioContentService audioContentService;

    public ContentService(
            ContentRepository contentRepository,
            WebviewContentService webviewContentService,
            AudioContentService audioContentService) {
        this.contentRepository = contentRepository;
        this.webviewContentService = webviewContentService;
        this.audioContentService = audioContentService;
    }

    public <T extends Content> Optional<T> getById(long id) {
        return (Optional<T>) this.contentRepository.findById(id);
    }

    public void deleteContent(Content content) {
        this.contentRepository.delete(content);
    }

    /* Webview */
    public WebviewContent createWebviewContent(Campaign campaign, CreateWebviewContentModel model) {
        WebviewContent content = webviewContentService.create(campaign, model);
        return content;
    }

    public WebviewContent editWebviewContent(WebviewContent content, CreateWebviewContentModel model) {
        WebviewContent editedContent = webviewContentService.edit(content, model);
        return editedContent;
    }

    /* Audio */
    public AudioContent createAudioContent(Campaign campaign, @Valid CreateAudioContentModel model) {
        AudioContent content = audioContentService.create(campaign, model);
        return content;
    }

    public AudioContent editAudioContent(AudioContent content, @Valid CreateAudioContentModel model) {
        AudioContent editedContent = audioContentService.edit(content, model);
        return editedContent;
    }

    public boolean moveUp(Content content) {
        int currentWeight = content.getWeight();

        if(currentWeight == 1) {
            return false;
        }

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() - 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    public boolean moveDown(Content content) {
        int currentWeight = content.getWeight();

        Campaign campaign = content.getCampaign();

        int desiredWeight = content.getWeight() + 1;
        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
        if(contentAtDesiredWeightOpt.isPresent()) {
            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
            contentAtDesiredWeight.setWeight(currentWeight);
            contentRepository.save(contentAtDesiredWeight);
        } else {
            return false;
        }

        content.setWeight(desiredWeight);
        contentRepository.save(content);

        return true;
    }

    /*
    private PanoramaContentService panoramaContentService;
    private SlideshowContentService slideshowContentService;
    private WebviewContentService webviewContentService;
    private UnityContentService unityContentService;
    private AudioContentService audioContentService;
    private MovieContentService movieContentService;

    public ContentService(
            PanoramaContentService panoramaContentService,
            SlideshowContentService slideshowContentService,
            WebviewContentService webviewContentService,
            UnityContentService unityContentService,
            AudioContentService audioContentService,
            MovieContentService movieContentService
    ) {
        this.panoramaContentService = panoramaContentService;
        this.slideshowContentService = slideshowContentService;
        this.webviewContentService = webviewContentService;
        this.unityContentService = unityContentService;
        this.audioContentService = audioContentService;
        this.movieContentService = movieContentService;
    }

    public List<PanoramaContent> getPanoramaContentByCampaign(Campaign campaign) {
        return panoramaContentService.findPanoramaByCampagin(campaign);
    }

    public List<SlideshowContent> getSlideshowContentByCampaign(Campaign campaign) {
        return slideshowContentService.findByCampagin(campaign);
    }

    public List<WebviewContent> getWebviewContentByCampaign(Campaign campaign) {
        return webviewContentService.findByCampagin(campaign);
    }

    public List<UnityContent> getUnityContentByCampaign(Campaign campaign) {
        return unityContentService.findByCampagin(campaign);
    }

    public List<AudioContent> getAudioContentByCampaign(Campaign campaign) {
        return audioContentService.findByCampagin(campaign);
    }

    public List<MovieContent> getMovieContentByCampaign(Campaign campaign) {
        return movieContentService.findByCampagin(campaign);
    }
    */

}
