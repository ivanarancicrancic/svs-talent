package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotBlank;

public class CreateWebviewContentModel extends CreateContentModel {

    @NotBlank
    private String url;

    public CreateWebviewContentModel() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
