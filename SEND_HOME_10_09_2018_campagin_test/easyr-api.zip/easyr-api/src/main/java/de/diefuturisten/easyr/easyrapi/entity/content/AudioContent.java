package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="content_audios")
public class AudioContent extends Content {

    @Column(name="url", nullable = false)
    private String url;

    @Column(name="render_on_tracking_lost", nullable = false)
    private boolean renderOnTrackingLost = false;

    // getter & setter

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public boolean isRenderOnTrackingLost() {
        return renderOnTrackingLost;
    }

    public void setRenderOnTrackingLost(boolean renderOnTrackingLost) {
        this.renderOnTrackingLost = renderOnTrackingLost;
    }
}
