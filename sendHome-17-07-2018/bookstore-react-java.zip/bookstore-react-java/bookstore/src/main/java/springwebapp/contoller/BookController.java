package springwebapp.contoller;

import com.google.gson.Gson;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springwebapp.commands.AuthorCommand;
import springwebapp.commands.BookCommand;
import springwebapp.commands.CategoryCommand;
import org.springframework.beans.factory.annotation.Autowired;
import springwebapp.exceptions.NotFoundException;
import springwebapp.model.Book;
import springwebapp.model.Category;
import springwebapp.model.Difficutly;
import springwebapp.repository.BookRepository;
import springwebapp.repository.CategoryRepository;
import springwebappservice.service.BookService;
import springwebappservice.service.CategoryService;
import springwebappservice.service.TableAttributeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class BookController {

    public static final Logger logger = LoggerFactory.getLogger(BookController.class);
    private static final String BOOK_BOOKFORM_URL = "book/bookform";

    @Autowired
    BookService bookService;

    @Autowired
    CategoryService caategoryService;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    BookRepository bookRepository;

    @Autowired
    TableAttributeService tableAttributeService;

    public BookController(BookService bookService, TableAttributeService tableAttributeService, CategoryRepository categoryRepository, CategoryService categoryService, BookRepository bookRepository) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.categoryRepository = categoryRepository;
        this.caategoryService = categoryService;
        this.bookRepository = bookRepository;
    }

    @GetMapping("/books")
    @ResponseStatus(HttpStatus.OK)
    public String getBooks() throws Exception
    {
        System.out.println("Entered /books");
        List<BookCommand> books = null;
        String book_str = null;
        try{
            books = bookService.getAllBooks();
            for(BookCommand bookCommand: books){

                System.out.println("Authors for Book: ");

                for(AuthorCommand authorCommand: bookCommand.getAuthors())
                    System.out.println("Author: "  + authorCommand.getFirstName() + " " + authorCommand.getLastName());
            }
            Gson gson = new Gson();
            System.out.println(books);

            book_str = gson.toJson(books);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/findByDescription")
    @ResponseStatus(HttpStatus.OK)
    public String getCategoryByDescription() throws  Exception
    {
        System.out.println("Entered /findByDescription");
        Category cagetory = categoryRepository.findByDescription("Drama");
        System.out.println("Category id is: " + cagetory.getId() + ", for description: " + cagetory.getDescription());
         String category_str =null;
        try{
            Gson gson = new Gson();
            category_str = gson.toJson(cagetory);
            System.out.println(category_str);
            return category_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/book/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    public String showById(@PathVariable String id) throws  Exception{
        System.out.println("entered book/show/{id}");
        String book_str =null;
        try{
            Gson gson = new Gson();
            BookCommand bookCommand =  bookService.findById(new Long(id));
            book_str = gson.toJson(bookCommand);
            System.out.println(book_str);
            return book_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/book/create")
    @ResponseStatus(HttpStatus.OK)
    public void createBook() throws Exception{
        Book book = new Book();
        bookRepository.save(book);
        System.out.println("New book ID: " + book.getId());
        BookCommand bookCommand = new BookCommand(book.getId());

    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.CREATED)
    public String createBook(@RequestBody BookCommand bookCommand) throws Exception{
        System.out.println("BEFORE CREATING BOOK: " + bookCommand.getTitle());
        bookCommand.setDifficutly(Difficutly.HARD);
        BookCommand createdBookCommand = bookService.createBook(bookCommand);
        System.out.println("Id of book created:" + createdBookCommand.getId());
        String book_str =null;
        try{
            Gson gson = new Gson();
            book_str = gson.toJson(createdBookCommand);
            System.out.println(book_str);
            return book_str;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("/book/{id}/update")
    @ResponseStatus(HttpStatus.OK)
    public void updateBook(@PathVariable String id){
        System.out.println("BOOK CATEGORIES BEFORE UPDATE: ");
        for(CategoryCommand c: bookService.findById(Long.valueOf(id)).getCategories()){
            System.out.println("CATEGORY: " + c.getDescription());
        }
    }

    @PutMapping("/book")
    @ResponseStatus(HttpStatus.OK)
    public String saveOrUpdate(@RequestBody BookCommand bookCommand) throws  Exception{
        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getId());
        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getCategories());
        BookCommand savedBookCommand = bookService.updateBook(bookCommand);
          System.out.println("Id of book updated:" + savedBookCommand.getId());
        System.out.println("Categories of book updated: ");
        for(CategoryCommand categoryCommand : savedBookCommand.getCategories())
                System.out.println("Category: " +  categoryCommand.getDescription());
        String book_str =null;
        try{
            Gson gson = new Gson();
            book_str = gson.toJson(savedBookCommand);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
    }

    @GetMapping("book/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    public void deleteBook(@PathVariable String id){
        bookService.deleteBook(Long.valueOf(id));
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NotFoundException.class)
    public ModelAndView handleNotFound(Exception exception){
        ModelAndView modelAndView = new ModelAndView();
        System.out.println("Handling not found exception");
        System.out.println("Exception message: " + exception.getMessage());
        modelAndView.setViewName("404error");
        modelAndView.addObject("exception", exception);
        return modelAndView;
    }
}
