package springwebapp.converters;

import springwebapp.commands.PublisherCommand;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Publisher;

@Component
public class PublisherToPublisherCommand implements Converter<Publisher, PublisherCommand> {


    @Override
    public PublisherCommand convert(Publisher source){

        if(source == null){
            return null;
        }

        final PublisherCommand publisher = new PublisherCommand();
        publisher.setId(source.getId());
        publisher.setName(source.getName());
        publisher.setAddress(source.getAddress());
        return publisher;
    }

}
