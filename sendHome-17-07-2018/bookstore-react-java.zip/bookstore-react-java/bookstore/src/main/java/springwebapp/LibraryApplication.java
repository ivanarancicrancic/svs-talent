package springwebapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import springwebapp.model.TableAtrtributes;
import springwebapp.propertybean.DataSourceClass;
import springwebapp.propertybean.SpecialDataSourceClass;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = {"springwebappservice.service", "springwebapp"})

public class LibraryApplication {

    public static void main(String[] args){

      ApplicationContext ctx = SpringApplication.run(LibraryApplication.class, args);

        DataSourceClass dataSourceClass = (DataSourceClass) ctx.getBean(DataSourceClass.class);

        System.out.println(dataSourceClass.getUser());
        System.out.println(dataSourceClass.getPassword());
        System.out.println(dataSourceClass.getUrl());
        System.out.println(dataSourceClass.getMainUser());
        System.out.println(dataSourceClass.getMainPassword());
        System.out.println(dataSourceClass.getMainUrl());

        SpecialDataSourceClass specialDataSourceClass = (SpecialDataSourceClass) ctx.getBean(SpecialDataSourceClass.class);

        System.out.println(specialDataSourceClass.getSpecialUser());
        System.out.println(specialDataSourceClass.getSpecailPassword());
        System.out.println(specialDataSourceClass.getSpecialUrl());

    }

  @Bean
  public WebMvcConfigurer corsConfigurer() {
    return new WebMvcConfigurerAdapter() {
      @Override
      public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**").allowedOrigins("http://localhost:3000");
      }
    };
  }
}