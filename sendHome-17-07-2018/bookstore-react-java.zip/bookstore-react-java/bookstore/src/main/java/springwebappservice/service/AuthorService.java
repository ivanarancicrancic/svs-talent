package springwebappservice.service;

import springwebapp.commands.AuthorCommand;
import springwebapp.model.Author;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface AuthorService {
    public Author creatAuthor(Author libraryuser);
    public List<Author> getAllAuthors();
    public void deleteAuthor(Long id);
    public AuthorCommand findByBookIdAndAuthorId(Long bookId, Long authorId);
    public AuthorCommand findAuthorById(Long authorId);
    public AuthorCommand updateAuthor(AuthorCommand authorCommand);
    //public AuthorCommand createAuthor(AuthorCommand authorCommand);
    public void deleteAuthorFromBook(Long bookId, Long authorId);
    public AuthorCommand addAuthorToBook(Long bookId, AuthorCommand authorCommand);


}
