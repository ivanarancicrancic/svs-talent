package springwebapp.repository;


import org.springframework.data.repository.CrudRepository;
import springwebapp.model.Book;
import org.springframework.stereotype.Component;

@Component
public interface BookRepository extends CrudRepository<Book, Long>{


}
