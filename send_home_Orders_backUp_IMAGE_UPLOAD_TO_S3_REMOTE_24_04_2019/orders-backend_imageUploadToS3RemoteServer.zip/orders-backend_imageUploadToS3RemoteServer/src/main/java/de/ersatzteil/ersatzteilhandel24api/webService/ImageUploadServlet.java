package de.ersatzteil.ersatzteilhandel24api.webService;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import java.io.*;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

@WebServlet("/ersatzteilhandel24apiValid/orderArticle/uploadImage")
@MultipartConfig
public class ImageUploadServlet extends HttpServlet {

    private static final long serialVersionUID = 5619951677845873534L;
    private static final String UPLOAD_DIR = "uploads";
    public ImageUploadServlet() {
        super();
    }

    static String extractPostRequestBody(HttpServletRequest request) throws IOException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            Scanner s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
        return "";
    }

    private String getFileName(final Part part) {
        final String partHeader = part.getHeader("content-disposition");
        for (String content : part.getHeader("content-disposition").split(";")) {
            if (content.trim().startsWith("filename")) {
                return content.substring(
                        content.indexOf('=') + 1).trim().replace("\"", "");
            }
        }
        return null;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String cwd = System.getProperty("user.dir");
        System.out.println("Current working directory : " + cwd);
        String applicationPath = "." + File.separator  +  "target"  + File.separator  + "ServletFileUpload" ;
        // constructs path of the directory to save uploaded file

//        String uploadFilePath = "C:\\Users\\ivana\\Desktop\\orders-backUp-29-03-2019\\orders-backend\\target\\ersatzteilhandel24apiValid\\uploads";

        // creates upload folder if it does not exists
//        File uploadFolder = new File(uploadFilePath);
//        if (!uploadFolder.exists()) {
//            uploadFolder.mkdirs();
//        }
//        PrintWriter writer = response.getWriter();
        // write all files in upload folder
        for (Part part : request.getParts()) {
            if (part != null && part.getSize() > 0) {
//                final String fileName123 = getFileName(part);
//                String nam = fileName123.substring(fileName123.lastIndexOf('\\') + 1);
//                String fileName = 	Paths.get(part.getSubmittedFileName()).getFileName().toString();
//                String contentType = part.getContentType();
//                // allows only JPEG files to be uploaded
//                if (!contentType.equalsIgnoreCase("image/jpeg")) {
//                    continue;
//                }
//                part.write(uploadFilePath + File.separator + fileName);
//                // checks if the request actually contains upload file
//                if (!ServletFileUpload.isMultipartContent(request)) {
//                    return;
//                }
                // configures upload settings
                //get the file chosen by the user
                Part filePart = part;
                String fileName1 = filePart.getSubmittedFileName();
                if(fileName1.endsWith(".jpg") || fileName1.endsWith(".png")){
                    InputStream fileInputStream = filePart.getInputStream();
                    String accessKeyId = "AKIAJ7SKJAPWNWM2UTBQ";
                    String secretAccessKey =  "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";
                    String region = "us-east-1";
                    String bucketName = "ersatzteil-handel";
//                  String subdirectory = "orders/";

                    //AWS Access Key ID and Secret Access Key
                    BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKeyId, secretAccessKey);

                    //This class connects to AWS S3 for us
                    AmazonS3 s3client = AmazonS3ClientBuilder.standard().withRegion(region)
                            .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();

                    //Specify the file's size
                    ObjectMetadata metadata = new ObjectMetadata();
                    metadata.setContentLength(filePart.getSize());

                    //Create the upload request, giving it a bucket name, subdirectory, filename, input stream, and metadata
                    PutObjectRequest uploadRequest = new PutObjectRequest(bucketName, fileName1, fileInputStream, metadata);

                    //Make it public so we can use it as a public URL on the internet
//                  uploadRequest.setCannedAcl(CannedAccessControlList.PublicRead);

                    //Upload the file. This can take a while for big files!
                    s3client.putObject(uploadRequest);

                    //Create a URL using the bucket, subdirectory, and file name
                    String fileUrl = "http://s3.amazonaws.com/" + bucketName + "/" + fileName1;

                    ObjectMapper mapper = new ObjectMapper();
                    try{
                        response.setContentType("application/json");
                        mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
                        DateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss");
                        mapper.setDateFormat(fmt);
                        mapper.writeValue(response.getOutputStream(), fileUrl);
                        return;
                    } catch (AmazonServiceException e) {
                        System.err.println(e.getErrorMessage());
                        System.exit(1);
                    }
                }
                else{
                    //the file was not a JPG or PNG
                    System.out.println("Please only upload JPG or PNG files.");
                }
            }
        }
    }
}
