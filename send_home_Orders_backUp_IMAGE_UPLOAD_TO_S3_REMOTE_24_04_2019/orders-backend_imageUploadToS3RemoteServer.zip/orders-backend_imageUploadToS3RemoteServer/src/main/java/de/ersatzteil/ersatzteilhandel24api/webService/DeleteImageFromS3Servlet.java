package de.ersatzteil.ersatzteilhandel24api.webService;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.ersatzteil.ersatzteilhandel24api.client.ProjectManager;
import de.ersatzteil.ersatzteilhandel24api.model.OrderArticles;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

@WebServlet("/ersatzteilhandel24apiValid/deleteImageFromS3")
public class DeleteImageFromS3Servlet extends HttpServlet {

    static String extractPostRequestBody(HttpServletRequest request) throws IOException {
        if ("POST".equalsIgnoreCase(request.getMethod())) {
            Scanner s = new Scanner(request.getInputStream(), "UTF-8").useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }
        return "";
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        ObjectMapper mapper1 = new ObjectMapper();
        String result = extractPostRequestBody(request);
        JsonNode jsonNode = mapper1.readTree(result);
        String orArId = jsonNode.get("orArId").asText();
        System.out.println("OrArID received: " + orArId);

        OrderArticles orderArticle = new OrderArticles();
        ProjectManager projectManager= new ProjectManager();
        try {
            orderArticle = projectManager.getOrderArticleById(orArId);
        }catch (Exception e){
            System.out.println("Exception");
        }

        String accessKeyId = "AKIAJ7SKJAPWNWM2UTBQ";
        String secretAccessKey =  "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";
        String region = "us-east-1";
        String bucketName = "ersatzteil-handel";
//                  String subdirectory = "orders/";

        //AWS Access Key ID and Secret Access Key
        BasicAWSCredentials awsCreds = new BasicAWSCredentials(accessKeyId, secretAccessKey);

        //This class connects to AWS S3 for us
        AmazonS3 s3client = AmazonS3ClientBuilder.standard().withRegion(region)
                .withCredentials(new AWSStaticCredentialsProvider(awsCreds)).build();


        s3client.deleteObject(new DeleteObjectRequest(bucketName, orderArticle.getImageKey()));


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
