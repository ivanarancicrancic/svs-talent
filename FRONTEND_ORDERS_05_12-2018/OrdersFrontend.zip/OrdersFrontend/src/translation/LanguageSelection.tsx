import * as React from 'react';
import { setLocale } from 'react-redux-i18n';
import { connect } from 'react-redux';
import { Dispatch } from 'redux';
import { IRootState } from '../redux';
import './LanguageSelection.css';
import deIcon from '../assets/images/de.svg';
import enIcon from '../assets/images/en.svg';

export interface ILanguageSelectionProps {
    setLocale: (locale: string) => Dispatch;
}

class LanguageSelection extends React.Component<ILanguageSelectionProps, any>{

    constructor(props: any) {
        super(props);
    }

    public onClickGerman() {
        this.props.setLocale('de');
    }

    public onClickEnglish() {
        this.props.setLocale('en');
    }

    public render() {
        return (
            <div className="langSelection">
                <button onClick={() => { this.onClickEnglish(); }}>
                    <div>
                        <img src={enIcon} />
                    </div>
                </button>
                <button onClick={() => { this.onClickGerman(); }}>
                    <div>
                        <img src={deIcon} />
                    </div>
                </button>
            </div>
        );
    }
}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, { setLocale })(LanguageSelection)