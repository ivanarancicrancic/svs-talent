import { IRootState } from '..'

export const getUserSelfInfo = (state: IRootState) => state.userSelfInfo.data;
export const getUserSelfInfoIsLoading = (state: IRootState) => state.userSelfInfo.loading;
export const getUserSelfInfoHasError = (state: IRootState) => state.userSelfInfo.error;