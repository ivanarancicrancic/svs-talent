export const ORDER_LIST_FETCH = '@@user/order/list/FETCH';
export const ORDER_LIST_SUCCESS = '@@user/order/list/SUCCESS';
export const ORDER_LIST_FAIL = '@@user/order/list/FAIL';

export const ORDER_CREATE_FETCH = '@@order/create/FETCH';
export const ORDER_CREATE_SUCCESS = '@@order/create/SUCCESS';
export const ORDER_CREATE_FAIL = '@@order/create/FAIL';

export interface IOrderResponseModel {
    order_id: number;
    orderDate: string;
    firstName: string;
};