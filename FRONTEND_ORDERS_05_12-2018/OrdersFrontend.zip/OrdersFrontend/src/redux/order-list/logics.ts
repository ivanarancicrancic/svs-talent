import { createLogic } from 'redux-logic';
import axios from 'axios';

import { ORDER_LIST_FETCH, IOrderResponseModel } from './types';
import { orderListFetch, orderListSuccess, orderListFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';

export const orderListFetchLogic = createLogic({
    type: ORDER_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(orderListFetch)(action)) {
            
            axios({
                method: 'get',
                url: API_ROOT + '/Orders'
            }).then(response => {
                const result = response.data as IOrderResponseModel[]
                dispatch(orderListSuccess(result));
            }).catch(error => {
                dispatch(orderListFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    orderListFetchLogic
];
