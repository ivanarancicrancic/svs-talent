import { IRootState } from '..'

export const getOrderList = (state: IRootState) => state.orderList.data;
export const getOrderListIsLoading = (state: IRootState) => state.orderList.loading;
export const getOrderListHasError = (state: IRootState) => state.orderList.error;