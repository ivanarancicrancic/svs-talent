import { createLogic } from 'redux-logic';
import axios from 'axios';

import {  SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FETCH, IProductResponseModel} from './types';
import { searchProductBySectionAndDescriptionFetch, searchProductBySectionAndDescriptionSuccess, searchProductBySectionAndDescriptionFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';


export const searchProductBySectionAndDescriptionFetchLogic = createLogic({
    type: SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        console.log("Entered searchProductBySectionAndDescriptionFetch action");
        if (isActionOf(searchProductBySectionAndDescriptionFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/productBySectionAndDescription/${action.payload.section}/${action.payload.description}`,
                headers: { 
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductResponseModel;
                console.log("PRODUCT SEARCH SUCCESS!");
                dispatch(searchProductBySectionAndDescriptionSuccess(result));
            }).catch(error => {
                console.log("FAIL PRODUCT SEARCH")
                dispatch(searchProductBySectionAndDescriptionFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [

    searchProductBySectionAndDescriptionFetchLogic

];