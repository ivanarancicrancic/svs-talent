import {
    PRODUCT_DETAIL_FETCH,
    PRODUCT_DETAIL_SUCCESS,
    PRODUCT_DETAIL_FAIL,
    
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH,
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_SUCCESS,
    SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FAIL,

    SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_FETCH,
    SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_SUCCESS,
    SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_FAIL,

    SEARCH_PRODUCT_BY_MANUFACTURER_NAME_FETCH,
    SEARCH_PRODUCT_BY_MANUFACTURER_NAME_SUCCESS,
    SEARCH_PRODUCT_BY_MANUFACTURER_NAME_FAIL,

    SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FETCH,
    SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_SUCCESS,
    SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FAIL,

    SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FETCH,
    SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_SUCCESS,
    SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FAIL,

    SEARCH_PRODUCT_BY_DESCRIPTION_FETCH,
    SEARCH_PRODUCT_BY_DESCRIPTION_SUCCESS,
    SEARCH_PRODUCT_BY_DESCRIPTION_FAIL,

    SEARCH_PRODUCT_BY_SECTION_FETCH,
    SEARCH_PRODUCT_BY_SECTION_SUCCESS,
    SEARCH_PRODUCT_BY_SECTION_FAIL,


    SEARCH_PRODUCT_BY_MODEL_FETCH,
    SEARCH_PRODUCT_BY_MODEL_SUCCESS,
    SEARCH_PRODUCT_BY_MODEL_FAIL,

    PRODUCT_CREATE_FETCH,
    PRODUCT_CREATE_SUCCESS,
    PRODUCT_CREATE_FAIL,

    PRODUCT_SAVE_FETCH,
    PRODUCT_SAVE_SUCCESS,
    PRODUCT_SAVE_FAIL,

    PRODUCT_EDIT_FETCH,
    PRODUCT_EDIT_SUCCESS,
    PRODUCT_EDIT_FAIL,

    PRODUCTPART_DELETE_FETCH,
    PRODUCTPART_DELETE_SUCCESS,
    PRODUCTPART_DELETE_FAIL,

    PRODUCTPART_CREATE_FETCH,
    PRODUCTPART_CREATE_SUCCESS,
    PRODUCTPART_CREATE_FAIL,

    PRODUCTPART_EDIT_FETCH,
    PRODUCTPART_EDIT_SUCCESS,
    PRODUCTPART_EDIT_FAIL,
     
    IProductDetailResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IProductRequestModel, IProductResponseModel, PRODUCTPART_RENAME_FETCH, PRODUCTPART_RENAME_SUCCESS, PRODUCTPART_RENAME_FAIL } from './types';

export const searchProductBySectionDescriptionAndManufacturerNameFetch = createStandardAction(SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FETCH)<{section: string,  description: string, manufacturerName: string}>();
export const searchProductBySectionDescriptionAndManufacturerNameSuccess = createStandardAction(SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_SUCCESS)<IProductResponseModel>();
export const searchProductBySectionDescriptionAndManufacturerNameFail = createStandardAction(SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FAIL)<string>();

export const searchProductBySectionAndDescriptionFetch = createStandardAction(SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FETCH)<{section: string,  description: string}>();
export const searchProductBySectionAndDescriptionSuccess = createStandardAction(SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_SUCCESS)<IProductResponseModel>();
export const searchProductBySectionAndDescriptionFail = createStandardAction(SEARCH_PRODUCT_BY_SECTION_AND_DESCRIPTION_FAIL)<string>();

export const searchProductBySectionFetch = createStandardAction(SEARCH_PRODUCT_BY_SECTION_FETCH)<{section: string}>();
export const searchProductBySectionSuccess = createStandardAction(SEARCH_PRODUCT_BY_SECTION_SUCCESS)<IProductResponseModel>();
export const searchProductBySectionFail = createStandardAction(SEARCH_PRODUCT_BY_SECTION_FAIL)<string>();

export const searchProductByDescriptionFetch = createStandardAction(SEARCH_PRODUCT_BY_DESCRIPTION_FETCH)<{description: string}>();
export const searchProductByDescriptionSuccess = createStandardAction(SEARCH_PRODUCT_BY_DESCRIPTION_SUCCESS)<IProductResponseModel>();
export const searchProductByDescriptionFail = createStandardAction(SEARCH_PRODUCT_BY_DESCRIPTION_FAIL)<string>();

export const searchProductByModelFetch = createStandardAction(SEARCH_PRODUCT_BY_MODEL_FETCH)<{mname: string}>();
export const searchProductByModelSuccess = createStandardAction(SEARCH_PRODUCT_BY_MODEL_SUCCESS)<IProductResponseModel>();
export const searchProductByModelFail = createStandardAction(SEARCH_PRODUCT_BY_MODEL_FAIL)<string>();

export const searchProductByManufacturerNumberFetch = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_FETCH)<{mid: number}>();
export const searchProductByManufacturerNumberSuccess = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_SUCCESS)<IProductResponseModel>();
export const searchProductByManufacturerNumberFail = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NUMBER_FAIL)<string>();

export const searchProductByManufacturerNameFetch = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NAME_FETCH)<{selected: string}>();
export const searchProductByManufacturerNameSuccess = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NAME_SUCCESS)<IProductResponseModel>();
export const searchProductByManufacturerNameFail = createStandardAction(SEARCH_PRODUCT_BY_MANUFACTURER_NAME_FAIL)<string>();


export const searchProductByArtileNumberFetch = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH)<{id: number}>();
export const searchProductByArtileNumberSuccess = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_SUCCESS)<IProductResponseModel>();
export const searchProductByArtileNumberFail = createStandardAction(SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FAIL)<string>();

export const productDetailFetch = createStandardAction(PRODUCT_DETAIL_FETCH)<{id: number}>();
export const productDetailSuccess = createStandardAction(PRODUCT_DETAIL_SUCCESS)<IProductDetailResponseModel>();
export const productDetailFail = createStandardAction(PRODUCT_DETAIL_FAIL)<string>();

export const productCreateFetch = createStandardAction(PRODUCT_CREATE_FETCH)();
export const productCreateSuccess = createStandardAction(PRODUCT_CREATE_SUCCESS)<IProductDetailResponseModel>();
export const productCreateFail = createStandardAction(PRODUCT_CREATE_FAIL)<string>();

export const productSaveFetch = createStandardAction(PRODUCT_SAVE_FETCH)<{productId: number, packageId: number}>();
export const productSaveSuccess = createStandardAction(PRODUCT_SAVE_SUCCESS)<IProductDetailResponseModel>();
export const productSaveFail = createStandardAction(PRODUCT_SAVE_FAIL)<string>();

export const productEditFetch = createStandardAction(PRODUCT_EDIT_FETCH)<{id: number, name: string}>();
export const productEditSuccess = createStandardAction(PRODUCT_EDIT_SUCCESS)<IProductDetailResponseModel>();
export const productEditFail = createStandardAction(PRODUCT_EDIT_FAIL)<string>();

export const productPartDeleteFetch = createStandardAction(PRODUCTPART_DELETE_FETCH)<{productId: number}>();
export const productPartDeleteSuccess = createStandardAction(PRODUCTPART_DELETE_SUCCESS)<{productId: number}>();
export const productPartDeleteFail = createStandardAction(PRODUCTPART_DELETE_FAIL)<string>();

export const productPartCreateFetch = createStandardAction(PRODUCTPART_CREATE_FETCH)<{categoryId: number, data: IProductRequestModel}>();
export const productPartCreateSuccess = createStandardAction(PRODUCTPART_CREATE_SUCCESS)<IProductResponseModel>();
export const productPartCreateFail = createStandardAction(PRODUCTPART_CREATE_FAIL)<string>();

export const productPartEditFetch = createStandardAction(PRODUCTPART_EDIT_FETCH)<{data: IProductRequestModel}>();
export const productPartEditSuccess = createStandardAction(PRODUCTPART_EDIT_SUCCESS)<IProductResponseModel>();
export const productPartEditFail = createStandardAction(PRODUCTPART_EDIT_FAIL)<string>();

export const productPartRenameFetch = createStandardAction(PRODUCTPART_RENAME_FETCH)<{productId: number, name: string}>();
export const productPartRenameSuccess = createStandardAction(PRODUCTPART_RENAME_SUCCESS)<IProductResponseModel>();
export const productPartRenameFail = createStandardAction(PRODUCTPART_RENAME_FAIL)<string>();