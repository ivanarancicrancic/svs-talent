import { IRootState } from '..'

export const getProductDetail = (state: IRootState) => state.product.data;
export const getProductDetailIsLoading = (state: IRootState) => state.product.loading;
export const getProductDetailHasError = (state: IRootState) => state.product.error;
export const getProduct = (state: IRootState) => state.product.data;
export const getProductByManufacturerNum = (state: IRootState) => state.productByManufacturerNumber.data;
export const getProductByManufacturerName = (state: IRootState) => state.productByManufacturerName.data;
export const getProductByModel = (state: IRootState) => state.productByModel.data;
export const getProductBySectionDescriptionAndManufacturerName = (state: IRootState) => state.productBySectionDescriptionAndManufacturerName.data;

