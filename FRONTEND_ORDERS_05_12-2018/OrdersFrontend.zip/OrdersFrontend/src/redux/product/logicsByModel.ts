import { createLogic } from 'redux-logic';
import axios from 'axios';

import {  SEARCH_PRODUCT_BY_MODEL_FETCH, IProductResponseModel} from './types';
import { searchProductByModelFetch, searchProductByModelSuccess, productDetailFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';


export const searchProductByModelFetchLogic = createLogic({
    type: SEARCH_PRODUCT_BY_MODEL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        console.log("Entered searchProductByModelFetch action");
        if (isActionOf(searchProductByModelFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/productByModel/${action.payload.mname}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductResponseModel;
                console.log("PRODUCT SEARCH SUCCESS!");
                dispatch(searchProductByModelSuccess(result));
            }).catch(error => {
                console.log("FAIL PRODUCT SEARCH")
                dispatch(productDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [

    searchProductByModelFetchLogic

];