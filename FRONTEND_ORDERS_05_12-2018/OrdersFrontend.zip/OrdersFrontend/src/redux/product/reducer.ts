import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IProductDetailResponseModel, IProductResponseModel } from './types';

export type ProductDetailActions = ActionType<typeof actions>;
export type ProductByArticleNumberActions = ActionType<typeof actions>;
export type ProductDetailByManufacturerNumberActions = ActionType<typeof actions>;
export type ProductDetailByManufacturerNameActions = ActionType<typeof actions>;
export type ProductDetailByModelActions = ActionType<typeof actions>;
export type ProductDetailBySectionDescriptionandManufacturerNameActions =  ActionType<typeof actions>;

export interface IProductDetailState {
    readonly data: IProductDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
    productDataLoading: boolean;
    productDataByManuLoading: boolean;

    readonly createLoading: boolean;
    readonly imageLoading: boolean;
    readonly contentLoading: boolean;

    readonly lastCreatedId: number | null;

    readonly saveLoading: boolean;
    readonly saveError: any | null;
};
  
const INITIAL_STATE: IProductDetailState = {
    data: null,
    loading: false,
    error: null,
    productDataLoading: false,
    productDataByManuLoading: false,

    createLoading: false,
    imageLoading: false,
    contentLoading: false,

    lastCreatedId: null,

    saveLoading: false,
    saveError: null
};
  
export interface IProductByArticleNumberState {
    readonly data: IProductResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
   readonly productDataLoading: boolean;
   readonly productDataByManuLoading: boolean;  
   readonly switchProductDataByManyLoading: boolean;
    readonly switchProductDataLoading: boolean;
  

};

export interface IProductByManufacturerNumberState {
    readonly data: IProductResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
   
  readonly  productDataByManuLoading: boolean;   
   readonly productDataLoading: boolean; 

       
};
  
const INITIAL_PRODUCT_BY_ARTICLE_STATE: IProductByArticleNumberState = {
    data: null,
    loading: false,
    error: null,
    productDataLoading: false,
    productDataByManuLoading: false,
    switchProductDataByManyLoading: false,
    switchProductDataLoading: false,

    
};

// const INITIAL_PRODUCT_BY_MANUFACTURER_STATE: IProductByManufacturerNumberState = {
//     data: null,
//     loading: false,
//     error: null,
//     productDataByManuLoading: false,
//     productDataLoading: false
  
// };


export function searchProductByArtileNumberReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by article number
        case getType(actions.searchProductByArtileNumberFetch):
            return {...state, loading: true, productDataLoading: true, switchProductDataByManyLoading:true, error: null};
        case getType(actions.searchProductByArtileNumberSuccess):
            return {...state, loading: false, productDataLoading: true, switchProductDataByManyLoading:true, error: null, data: action.payload};
        case getType(actions.searchProductByArtileNumberFail):
            return {...state, loading: false, productDataLoading: true, switchProductDataByManyLoading:true, error: action.payload};

        default:
            return state;
    }
}


export function searchProductByManufacturerNumberReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by manufacturer number
        case getType(actions.searchProductByManufacturerNumberFetch):
        return {...state, loading: true, productDataByManuLoading: true, switchProductDataLoading: true, error: null};
        case getType(actions.searchProductByManufacturerNumberSuccess):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: null, data: action.payload};
        case getType(actions.searchProductByManufacturerNumberFail):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: action.payload};

        default:
            return state;
    }
}

export function searchProductByManufacturerNameReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by manufacturer number
        case getType(actions.searchProductByManufacturerNameFetch):
        return {...state, loading: true, productDataByManuLoading: true, switchProductDataLoading: true, error: null};
        case getType(actions.searchProductByManufacturerNameSuccess):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: null, data: action.payload};
        case getType(actions.searchProductByManufacturerNameFail):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: action.payload};

        default:
            return state;
    }
}


export function searchProductBySectionDescriptionAndManufacturerNameReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by manufacturer number
        case getType(actions.searchProductBySectionDescriptionAndManufacturerNameFetch):
        return {...state, loading: true, productDataByManuLoading: true, switchProductDataLoading: true, error: null};
        case getType(actions.searchProductBySectionDescriptionAndManufacturerNameSuccess):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: null, data: action.payload};
        case getType(actions.searchProductBySectionDescriptionAndManufacturerNameFail):
            return {...state, loading: false, productDataByManuLoading: true, switchProductDataLoading: true, error: action.payload};

        default:
            return state;
    }
}

export function searchProductByModelReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE, action: ProductDetailActions): IProductByArticleNumberState  {
    switch (action.type) {

        // get product by model name
        case getType(actions.searchProductByModelFetch):
        return {...state, loading: true, error: null};
        case getType(actions.searchProductByModelSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.searchProductByModelFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}

export function resetProductByManufacturerAndArticleNumberReducer(state: IProductByArticleNumberState = INITIAL_PRODUCT_BY_ARTICLE_STATE): IProductByArticleNumberState  {
   
        return {...state, productDataByManuLoading: false, productDataLoading: false, switchProductDataLoading: false, switchProductDataByManyLoading: false, error: null};
      
    
}

//  function searchProductByManufacturerNumberReducerLoadingArticle(state1: IRootState): IRootState{
//      return {...state1, productDataByManuLoading: true, productDataLoading: false, error: null}

//  }

export function productDetailReducer(state: IProductDetailState = INITIAL_STATE, action: ProductDetailActions): IProductDetailState  {
    switch (action.type) {

        // detail
        case getType(actions.productDetailFetch):
            return {...state, loading: true, error: null};
        case getType(actions.productDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.productDetailFail):
            return {...state, loading: false, error: action.payload};

        // create
        case getType(actions.productCreateFetch):
            return {...state, createLoading: true, error: null};
        case getType(actions.productCreateSuccess):
            return {...state, createLoading: false, error: null, lastCreatedId: action.payload.id};
        case getType(actions.productCreateFail):
            return {...state, createLoading: false, error: action.payload};

        // save
        case getType(actions.productSaveFetch):
            return {...state, saveLoading: true, saveError: null};
        case getType(actions.productSaveSuccess):
            return {...state, saveLoading: false, saveError: null, data: action.payload};
        case getType(actions.productSaveFail):
            return {...state, saveLoading: false, saveError: action.payload};


        // product delete
        case getType(actions.productPartDeleteFetch):
            return {...state, contentLoading: true};

        case getType(actions.productPartDeleteSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false}
            }

            const contentsAfterDelete = state.data.products.filter(x => x.id !== action.payload.productId);

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: contentsAfterDelete
                }
            }
        
        case getType(actions.productPartDeleteFetch):
            return {...state, contentLoading: false};

        // product create
        case getType(actions.productPartCreateFetch):
            return {...state, contentLoading: true};

        case getType(actions.productPartCreateSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: [
                        ...state.data.products,
                        action.payload
                    ]
                }
            };

        case getType(actions.productPartCreateFail):
            return {...state, contentLoading: false};


        // product edit
        case getType(actions.productPartEditFetch):
           return {...state, contentLoading: true};

        case getType(actions.productPartEditSuccess):
        case getType(actions.productPartRenameSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            const elementToUpdate = action.payload;
            const idxOfIdToUpdate = state.data.products.findIndex( x => x.id === elementToUpdate.id );

            if(idxOfIdToUpdate === -1) {
                return state;
            }

            const updatedProducts = [...state.data.products];
            updatedProducts[idxOfIdToUpdate] = action.payload;

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    products: updatedProducts
                }
            };

        case getType(actions.productEditFail):
            return {...state, contentLoading: false};

        default:
            return state;
    }
}