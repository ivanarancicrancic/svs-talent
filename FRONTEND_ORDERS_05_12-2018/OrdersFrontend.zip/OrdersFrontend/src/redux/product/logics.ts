import { createLogic } from 'redux-logic';
import axios from 'axios';

import { PRODUCT_DETAIL_FETCH, SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH, IProductDetailResponseModel, IProductPartResponseModel, PRODUCT_CREATE_FETCH, PRODUCT_SAVE_FETCH, PRODUCT_EDIT_FETCH, PRODUCTPART_CREATE_FETCH, IProductResponseModel, PRODUCTPART_DELETE_FETCH, PRODUCTPART_EDIT_FETCH,  PRODUCTPART_RENAME_FETCH} from './types';
import { productDetailFetch, searchProductByArtileNumberFetch, searchProductByArtileNumberSuccess, productDetailSuccess, productDetailFail, productCreateSuccess, productCreateFail, productCreateFetch, productSaveFetch, productSaveSuccess, productSaveFail, productEditFetch, productPartCreateFetch, productPartCreateSuccess, productPartCreateFail, productPartDeleteFetch, productPartDeleteSuccess, productPartDeleteFail, productPartEditFetch, productPartEditSuccess, productPartEditFail, productPartRenameFetch, productPartRenameFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const searchProductByArtileNumberFetchLogic = createLogic({
    type: SEARCH_PRODUCT_BY_ARTICLE_NUMBER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        console.log("Entered searchProductByArtileNumberFetch action");
        if (isActionOf(searchProductByArtileNumberFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/product/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductResponseModel;
                console.log("PRODUCT SEARCH SUCCESS!");
                dispatch(searchProductByArtileNumberSuccess(result));
            }).catch(error => {
                console.log("FAIL PRODUCT SEARCH")
                dispatch(productDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});


export const productDetailFetchLogic = createLogic({
    type: PRODUCT_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productDetailFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/category/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productDetailSuccess(result));
            }).catch(error => {
                dispatch(productDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productCreateFetchLogic = createLogic({
    type: PRODUCT_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productCreateSuccess(result));
            }).catch(error => {
                dispatch(productCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productSaveFetchLogic = createLogic({
    type: PRODUCT_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productSaveFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.productId}/save`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { packageId: action.payload.packageId }
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productSaveSuccess(result));
            }).catch(error => {
                dispatch(productSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productEditFetchLogic = createLogic({
    type: PRODUCT_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload
            }).then(response => {
                const result = response.data as IProductDetailResponseModel
                dispatch(productSaveSuccess(result));
            }).catch(error => {
                dispatch(productSaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productPartDeleteFetchLogic = createLogic({
    type: PRODUCTPART_DELETE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartDeleteFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'delete',
                url: API_ROOT + `/api/category/product/${action.payload.productId}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                dispatch(productPartDeleteSuccess({productId: action.payload.productId}));
            }).catch(error => {
                dispatch(productPartDeleteFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productPartCreateLogic = createLogic({
    type: PRODUCTPART_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.categoryId}/product`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productPartCreateSuccess(result));
            }).catch(error => {
                dispatch(productPartCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productPartEditLogic = createLogic({
    type: PRODUCTPART_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productPartEditSuccess(result));
            }).catch(error => {
                dispatch(productPartEditFail("fail"));
            });

        } else {
            done();
        }
    }
});


export const productPartRenameLogic = createLogic({
    type: PRODUCTPART_RENAME_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productPartRenameFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.productId}/name`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { name: action.payload.name }
            }).then(response => {
                const result = response.data as IProductPartResponseModel;
              console.log(result);
                // dispatch(productPartRenameSuccess(result));
            }).catch(error => {
                dispatch(productPartRenameFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    productDetailFetchLogic,
    productCreateFetchLogic,
    productSaveFetchLogic,
    productEditFetchLogic,
    productPartDeleteFetchLogic,
    productPartCreateLogic,
    productPartEditLogic,
    productPartRenameLogic,
    searchProductByArtileNumberFetchLogic,


];
