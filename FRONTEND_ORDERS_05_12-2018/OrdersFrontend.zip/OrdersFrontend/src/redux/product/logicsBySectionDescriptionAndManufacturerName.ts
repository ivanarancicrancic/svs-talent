import { createLogic } from 'redux-logic';
import axios from 'axios';

import {  SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FETCH, IProductResponseModel} from './types';
import { searchProductBySectionDescriptionAndManufacturerNameFetch, searchProductBySectionDescriptionAndManufacturerNameSuccess, searchProductBySectionDescriptionAndManufacturerNameFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';


export const searchProductBySectionDescriptionAndManufacturerNameFetchLogic = createLogic({
    type: SEARCH_PRODUCT_BY_SECTION_DESCRIPTION_AND_MANUFACTURER_NAME_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        console.log("Entered searchProductBySectionDescriptionAndManufacturerNameFetch action");
        if (isActionOf(searchProductBySectionDescriptionAndManufacturerNameFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/productBySectionDescriptionAndManufacturerName/${action.payload.section}/${action.payload.description}/${action.payload.manufacturerName}`,
                headers: { 
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IProductResponseModel;
                console.log("PRODUCT SEARCH SUCCESS!");
                dispatch(searchProductBySectionDescriptionAndManufacturerNameSuccess(result));
            }).catch(error => {
                console.log("FAIL PRODUCT SEARCH")
                dispatch(searchProductBySectionDescriptionAndManufacturerNameFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [

    searchProductBySectionDescriptionAndManufacturerNameFetchLogic

];