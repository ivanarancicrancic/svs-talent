export const UI_SHOW_CREATE_CATEGORY = '@@ui/createcategory/SHOW';
export const UI_HIDE_CREATE_CATEGORY = '@@ui/createcategory/HIDE';