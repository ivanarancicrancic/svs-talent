import { ActionType, getType } from 'typesafe-actions';
import { IProductResponseModel } from './types';

import * as actions from './actions';
import { productCreateSuccess } from '../category/actions'

const extActions = {...actions, productCreateSuccess};
export type ProductListActions = ActionType<typeof extActions>;

export interface IProductListState {
    readonly data: IProductResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IProductListState = {
    data: null,
    loading: false,
    error: null
};
  
export function productListReducer(state: IProductListState = INITIAL_STATE, action: ProductListActions): IProductListState  {
    switch (action.type) {
        case getType(extActions.productListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.productListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.productListFail):
            return {...state, loading: false, error: action.payload};

        case getType(extActions.productCreateSuccess):
            return state; 

        default:
            return state;
    }
}