import {
    PRODUCT_LIST_FETCH,
    PRODUCT_LIST_SUCCESS,
    PRODUCT_LIST_FAIL,
    IProductResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const productListFetch = createStandardAction(PRODUCT_LIST_FETCH)<{id: number, cid: number}>();
export const productListSuccess = createStandardAction(PRODUCT_LIST_SUCCESS)<IProductResponseModel[]>();
export const productListFail = createStandardAction(PRODUCT_LIST_FAIL)<string>();
