import { ActionType, getType } from 'typesafe-actions';
import { IManufacturerResponseModel } from './types';

import * as actions from './actions';
import { manufacturerCreateSuccess } from '../manufacturer/actions'

const extActions = {...actions, manufacturerCreateSuccess};
export type ManufacturerListActions = ActionType<typeof extActions>;

export interface IManufacturerListState {
    readonly data: IManufacturerResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IManufacturerListState = {
    data: null,
    loading: false,
    error: null
};
  
export function manufacturerListReducer(state: IManufacturerListState = INITIAL_STATE, action: ManufacturerListActions): IManufacturerListState  {
    switch (action.type) {
        case getType(extActions.manufacturerListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.manufacturerListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.manufacturerListFail):
            return {...state, loading: false, error: action.payload};

        case getType(extActions.manufacturerCreateSuccess):
            return state; 

        default:
            return state;
    }
}