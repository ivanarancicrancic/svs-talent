import { createLogic } from 'redux-logic';
import axios from 'axios';

import { CATEGORY_DETAIL_FETCH, ICategoryDetailResponseModel, CATEGORY_CREATE_FETCH, CATEGORY_SAVE_FETCH, CATEGORY_EDIT_FETCH, PRODUCT_CREATE_FETCH, IProductResponseModel, PRODUCT_DELETE_FETCH, PRODUCT_EDIT_FETCH,  PRODUCT_RENAME_FETCH} from './types';
import { categoryDetailFetch, categoryDetailSuccess, categoryDetailFail, categoryCreateSuccess, categoryCreateFail, categoryCreateFetch, categorySaveFetch, categorySaveSuccess, categorySaveFail, categoryEditFetch, productCreateFetch, productCreateSuccess, productCreateFail, productDeleteFetch, productDeleteSuccess, productDeleteFail, productEditFetch, productEditSuccess, productEditFail, productRenameFetch, productRenameSuccess, productRenameFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const categoryDetailFetchLogic = createLogic({
    type: CATEGORY_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryDetailFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + `/api/category/${action.payload.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categoryDetailSuccess(result));
            }).catch(error => {
                dispatch(categoryDetailFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categoryCreateFetchLogic = createLogic({
    type: CATEGORY_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categoryCreateSuccess(result));
            }).catch(error => {
                dispatch(categoryCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categorySaveFetchLogic = createLogic({
    type: CATEGORY_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categorySaveFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.categoryId}/save`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { packageId: action.payload.packageId }
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categorySaveSuccess(result));
            }).catch(error => {
                dispatch(categorySaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const categoryEditFetchLogic = createLogic({
    type: CATEGORY_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(categoryEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload
            }).then(response => {
                const result = response.data as ICategoryDetailResponseModel
                dispatch(categorySaveSuccess(result));
            }).catch(error => {
                dispatch(categorySaveFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productDeleteFetchLogic = createLogic({
    type: PRODUCT_DELETE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productDeleteFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'delete',
                url: API_ROOT + `/api/category/product/${action.payload.productId}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
            }).then(response => {
                dispatch(productDeleteSuccess({productId: action.payload.productId}));
            }).catch(error => {
                dispatch(productDeleteFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productCreateLogic = createLogic({
    type: PRODUCT_CREATE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productCreateFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'post',
                url: API_ROOT + `/api/category/${action.payload.categoryId}/product`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productCreateSuccess(result));
            }).catch(error => {
                dispatch(productCreateFail("fail"));
            });

        } else {
            done();
        }
    }
});

export const productEditLogic = createLogic({
    type: PRODUCT_EDIT_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productEditFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.data.id}`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: action.payload.data
            }).then(response => {
                const result = response.data as IProductResponseModel
                dispatch(productEditSuccess(result));
            }).catch(error => {
                dispatch(productEditFail("fail"));
            });

        } else {
            done();
        }
    }
});


export const productRenameLogic = createLogic({
    type: PRODUCT_RENAME_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(productRenameFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'put',
                url: API_ROOT + `/api/category/product/${action.payload.productId}/name`,
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                data: { name: action.payload.name }
            }).then(response => {
                const result = response.data as IProductResponseModel;
                dispatch(productRenameSuccess(result));
            }).catch(error => {
                dispatch(productRenameFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    categoryDetailFetchLogic,
    categoryCreateFetchLogic,
    categorySaveFetchLogic,
    categoryEditFetchLogic,
    productDeleteFetchLogic,
    productCreateLogic,
    productEditLogic,
    productRenameLogic
];
