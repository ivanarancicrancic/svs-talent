import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { ICategoryDetailResponseModel } from './types';

export type CategoryDetailActions = ActionType<typeof actions>;

export interface ICategoryDetailState {
    readonly data: ICategoryDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;

    readonly createLoading: boolean;
    readonly imageLoading: boolean;
    readonly contentLoading: boolean;

    readonly lastCreatedId: number | null;

    readonly saveLoading: boolean;
    readonly saveError: any | null;
};
  
const INITIAL_STATE: ICategoryDetailState = {
    data: null,
    loading: false,
    error: null,

    createLoading: false,
    imageLoading: false,
    contentLoading: false,

    lastCreatedId: null,

    saveLoading: false,
    saveError: null
};
  
export function categoryDetailReducer(state: ICategoryDetailState = INITIAL_STATE, action: CategoryDetailActions): ICategoryDetailState  {
    switch (action.type) {

        // detail
        case getType(actions.categoryDetailFetch):
            return {...state, loading: true, error: null};
        case getType(actions.categoryDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.categoryDetailFail):
            return {...state, loading: false, error: action.payload};

        // create
        case getType(actions.categoryCreateFetch):
            return {...state, createLoading: true, error: null};
        case getType(actions.categoryCreateSuccess):
            return {...state, createLoading: false, error: null, lastCreatedId: action.payload.id};
        case getType(actions.categoryCreateFail):
            return {...state, createLoading: false, error: action.payload};

        // save
        case getType(actions.categorySaveFetch):
            return {...state, saveLoading: true, saveError: null};
        case getType(actions.categorySaveSuccess):
            return {...state, saveLoading: false, saveError: null, data: action.payload};
        case getType(actions.categorySaveFail):
            return {...state, saveLoading: false, saveError: action.payload};


        // product delete
        case getType(actions.productDeleteFetch):
            return {...state, contentLoading: true};

        case getType(actions.productDeleteSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false}
            }

            const contentsAfterDelete = state.data.contents.filter(x => x.id !== action.payload.productId);

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: contentsAfterDelete
                }
            }
        
        case getType(actions.productDeleteFail):
            return {...state, contentLoading: false};

        // product create
        case getType(actions.productCreateFetch):
            return {...state, contentLoading: true};

        case getType(actions.productCreateSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: [
                        ...state.data.contents,
                        action.payload
                    ]
                }
            };

        case getType(actions.productCreateFail):
            return {...state, contentLoading: false};


        // product edit
        case getType(actions.productEditFetch):
           return {...state, contentLoading: true};

        case getType(actions.productEditSuccess):
        case getType(actions.productRenameSuccess):
            if(state.data == null) {
                return {...state, contentLoading: false};
            }

            const elementToUpdate = action.payload;
            const idxOfIdToUpdate = state.data.contents.findIndex( x => x.id === elementToUpdate.id );

            if(idxOfIdToUpdate === -1) {
                return state;
            }

            const updatedProducts = [...state.data.contents];
            updatedProducts[idxOfIdToUpdate] = action.payload;

            return {
                ...state,
                contentLoading: false,
                data: {
                    ...state.data,
                    contents: updatedProducts
                }
            };

        case getType(actions.productEditFail):
            return {...state, contentLoading: false};

        default:
            return state;
    }
}