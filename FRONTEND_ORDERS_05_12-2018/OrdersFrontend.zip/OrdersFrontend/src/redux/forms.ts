import { combineForms } from 'react-redux-form';

export interface ILoginFormData {
    username: string;
    password: string;
}

const loginForm: ILoginFormData = {
    username: '',
    password: ''
};

export interface IRegisterFormData {
    title: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    confirmPassword: string;
    phoneNumber: string;
    paymentTitle: string;
    paymentFirstName: string;
    paymentLastName: string;
    companyName: string;
    streetAddress: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
    captcha: string;
};

const registerForm: IRegisterFormData = {
    title: 'male',
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    paymentTitle: 'male',
    paymentFirstName: '',
    paymentLastName: '',
    companyName: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: '',
    captcha: ''
};

export interface IForgotPasswordFormData {
    email: string;
    captcha: string;
}

const forgotPasswordForm: IForgotPasswordFormData = {
    email: '',
    captcha: ''
}

export interface IResetPasswordFormData {
    email: string;
    token: string;
    password: string;
    confirmPassword: string;
}

const resetPasswordForm: IResetPasswordFormData = {
    email: '',
    token: '',
    password: '',
    confirmPassword: ''
}

export interface IInfoFormData {
    name: string;
    package: any;
    check: boolean;
};

const infoForm: IInfoFormData = {
    name: '',
    package: '',
    check: false,
}


export const formsReducer = combineForms({
    login: loginForm,
    register: registerForm,
    forgotpassword: forgotPasswordForm,
    resetpassword: resetPasswordForm,
    info: infoForm,
}, 'forms');