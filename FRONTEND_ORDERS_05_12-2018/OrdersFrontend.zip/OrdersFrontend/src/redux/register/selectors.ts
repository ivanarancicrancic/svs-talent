import { IRootState } from '..'

export const getRegisterIsLoading = (state: IRootState) => state.register.loading;
export const getRegisterHasError = (state: IRootState) => state.register.error;