import {
    CATEGORY_LIST_FETCH,
    CATEGORY_LIST_SUCCESS,
    CATEGORY_LIST_FAIL,
    ICategoryResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const categoryListFetch = createStandardAction(CATEGORY_LIST_FETCH)();
export const categoryListSuccess = createStandardAction(CATEGORY_LIST_SUCCESS)<ICategoryResponseModel[]>();
export const categoryListFail = createStandardAction(CATEGORY_LIST_FAIL)<string>();
