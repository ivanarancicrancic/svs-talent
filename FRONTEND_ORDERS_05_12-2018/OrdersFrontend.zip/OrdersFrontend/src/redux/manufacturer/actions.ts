import {
    MANUFACTURER_DETAIL_FETCH,
    MANUFACTURER_DETAIL_SUCCESS,
    MANUFACTURER_DETAIL_FAIL,
    
    MANUFACTURER_CREATE_FETCH,
    MANUFACTURER_CREATE_SUCCESS,
    MANUFACTURER_CREATE_FAIL,

    MANUFACTURER_SAVE_FETCH,
    MANUFACTURER_SAVE_SUCCESS,
    MANUFACTURER_SAVE_FAIL,

    MANUFACTURER_EDIT_FETCH,
    MANUFACTURER_EDIT_SUCCESS,
    MANUFACTURER_EDIT_FAIL,

    IManufacturerDetailResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const manufacturerDetailFetch = createStandardAction(MANUFACTURER_DETAIL_FETCH)<{id: number}>();
export const manufacturerDetailSuccess = createStandardAction(MANUFACTURER_DETAIL_SUCCESS)<IManufacturerDetailResponseModel>();
export const manufacturerDetailFail = createStandardAction(MANUFACTURER_DETAIL_FAIL)<string>();

export const manufacturerCreateFetch = createStandardAction(MANUFACTURER_CREATE_FETCH)();
export const manufacturerCreateSuccess = createStandardAction(MANUFACTURER_CREATE_SUCCESS)<IManufacturerDetailResponseModel>();
export const manufacturerCreateFail = createStandardAction(MANUFACTURER_CREATE_FAIL)<string>();

export const manufacturerSaveFetch = createStandardAction(MANUFACTURER_SAVE_FETCH)<{id: number, packageId: number}>();
export const manufacturerSaveSuccess = createStandardAction(MANUFACTURER_SAVE_SUCCESS)<IManufacturerDetailResponseModel>();
export const manufacturerSaveFail = createStandardAction(MANUFACTURER_SAVE_FAIL)<string>();

export const manufacturerEditFetch = createStandardAction(MANUFACTURER_EDIT_FETCH)<{id: number, name: string}>();
export const manufacturerEditSuccess = createStandardAction(MANUFACTURER_EDIT_SUCCESS)<IManufacturerDetailResponseModel>();
export const manufacturerEditFail = createStandardAction(MANUFACTURER_EDIT_FAIL)<string>();
