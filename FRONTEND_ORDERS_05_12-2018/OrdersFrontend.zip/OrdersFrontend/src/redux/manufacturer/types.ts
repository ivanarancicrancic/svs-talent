export const MANUFACTURER_DETAIL_FETCH = '@@user/manufacturer/detail/FETCH';
export const MANUFACTURER_DETAIL_SUCCESS = '@@user/manufacturer/detail/SUCCESS';
export const MANUFACTURER_DETAIL_FAIL = '@@user/manufacturer/detail/FAIL';

export const MANUFACTURER_CREATE_FETCH = '@@manufacturer/create/FETCH';
export const MANUFACTURER_CREATE_SUCCESS = '@@manufacturer/create/SUCCESS';
export const MANUFACTURER_CREATE_FAIL = '@@manufacturer/create/FAIL';

export const MANUFACTURER_SAVE_FETCH = '@@manufacturer/save/FETCH';
export const MANUFACTURER_SAVE_SUCCESS = '@@manufacturer/save/SUCCESS';
export const MANUFACTURER_SAVE_FAIL = '@@manufacturer/save/FAIL';

export const MANUFACTURER_EDIT_FETCH = '@@manufacturer/edit/FETCH';
export const MANUFACTURER_EDIT_SUCCESS = '@@manufacturer/edit/SUCCESS';
export const MANUFACTURER_EDIT_FAIL = '@@manufacturer/edit/FAIL';

export const MANUFACTURER_UPLOAD_FETCH = '@@category/manufacturer/upload/FETCH';
export const MANUFACTURER_UPLOAD_SUCCESS = '@@category/manufacturer/upload/SUCCESS';
export const MANUFACTURER_UPLOAD_FAIL = '@@category/manufacturer/upload/FAIL';

export const MANUFACTURER_DELETE_FETCH = '@@category/manufacturer/delete/FETCH';
export const MANUFACTURER_DELETE_SUCCESS = '@@category/manufacturer/delete/SUCCESS';
export const MANUFACTURER_DELETE_FAIL = '@@category/manufacturer/delete/FAIL';

export const PRODUCTPART_DELETE_FETCH = '@@product/productPart/delete/FETCH';
export const PRODUCTPART_DELETE_SUCCESS = '@@product/productPart/delete/SUCCESS';
export const PRODUCTPART_DELETE_FAIL = '@@product/productPart/delete/FAIL';

export const PRODUCTPART_CREATE_FETCH = '@@product/productPart/create/FETCH';
export const PRODUCTPART_CREATE_SUCCESS = '@@product/productPart/create/SUCCESS';
export const PRODUCTPART_CREATE_FAIL = '@@product/productPart/create/FAIL';

export const PRODUCTPART_EDIT_FETCH = '@@product/productPart/edit/FETCH';
export const PRODUCTPART_EDIT_SUCCESS = '@@product/productPart/edit/SUCCESS';
export const PRODUCTPART_EDIT_FAIL = '@@product/productPart/edit/FAIL';

export const PRODUCTPART_RENAME_FETCH = '@@product/productPart/renamePart/FETCH';
export const PRODUCTPART_RENAME_SUCCESS = '@@product/productPart/rename/SUCCESS';
export const PRODUCTPART_RENAME_FAIL = '@@product/productPart/rename/FAIL';

export interface IProductPartResponseModel {
    id: number;
    type: ManufacturerType;
    weight: number;
    name: string;
    subType: ManufacturerSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

// MANUFACTURER
type ManufacturerType =  'KITCHEN';

export interface IManufacturer1ResponseModel {
    id: number;
    type: ManufacturerType;
    name: string;
    weight: number;
}

// MANUFACTURER TYPES
export type ManufacturerSubtype = 'KITCHEN' | 'HOUSE';

interface IManufacturerFields {
    subType: ManufacturerSubtype;
    url: string;
    positionX: number;
    positionY: number;
    positionZ: number;
    rotationX: number;
    rotationY: number;
    rotationZ: number;
    scaleX: number;
    scaleY: number;
    scaleZ: number;
    renderOnTrackingLost: boolean;
    extendedTracking: boolean;
}

export interface IManufacturerResponseModel extends IManufacturer1ResponseModel, IManufacturerFields {}

export interface IManufacturerRequestModel extends IManufacturerFields {
    id?: number;
    name: string;
}


// MANUFACTURER
export interface IManufacturerDetailResponseModel {
    id: number;
    name: string;
    description: string;
    productPart: IProductPartResponseModel[];
    manufacturers: IManufacturerResponseModel[]
    temporary: boolean;
    activePackageId: number | null
};