import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { IManufacturerDetailResponseModel } from './types';

export type ManufacturerDetailActions = ActionType<typeof actions>;

export interface IManufacturerDetailState {
    readonly data: IManufacturerDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;

    readonly createLoading: boolean;
    readonly imageLoading: boolean;
    readonly contentLoading: boolean;

    readonly lastCreatedId: number | null;

    readonly saveLoading: boolean;
    readonly saveError: any | null;
};
  
const INITIAL_STATE: IManufacturerDetailState = {
    data: null,
    loading: false,
    error: null,

    createLoading: false,
    imageLoading: false,
    contentLoading: false,

    lastCreatedId: null,

    saveLoading: false,
    saveError: null
};
  
export function manufacturerDetailReducer(state: IManufacturerDetailState = INITIAL_STATE, action: ManufacturerDetailActions): IManufacturerDetailState  {
    switch (action.type) {

        // detail
        case getType(actions.manufacturerDetailFetch):
            return {...state, loading: true, error: null};
        case getType(actions.manufacturerDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(actions.manufacturerDetailFail):
            return {...state, loading: false, error: action.payload};

        // create
        case getType(actions.manufacturerCreateFetch):
            return {...state, createLoading: true, error: null};
        case getType(actions.manufacturerCreateSuccess):
            return {...state, createLoading: false, error: null, lastCreatedId: action.payload.id};
        case getType(actions.manufacturerCreateFail):
            return {...state, createLoading: false, error: action.payload};

        // save
        case getType(actions.manufacturerSaveFetch):
            return {...state, saveLoading: true, saveError: null};
        case getType(actions.manufacturerSaveSuccess):
            return {...state, saveLoading: false, saveError: null, data: action.payload};
        case getType(actions.manufacturerSaveFail):
            return {...state, saveLoading: false, saveError: action.payload};

        default:
            return state;
    }
}