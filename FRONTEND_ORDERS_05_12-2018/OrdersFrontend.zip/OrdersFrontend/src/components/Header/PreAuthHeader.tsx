import * as React from 'react';
import {NavLink} from "react-router-dom";
import {PATH_DESCRIPTION, PATH_LOGIN, PATH_REFERENCES, PATH_REGISTER, PATH_ROOT} from "../../router/paths";

import LanguageSelection from '../../translation/LanguageSelection'
import { Translate, I18n } from 'react-redux-i18n';



export default class PreAuthHeader extends React.Component<I18n["t"]> {

    public render() {
        return (
            <div className="header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group bp3-align-left">
                            <NavLink to={PATH_ROOT} className="bp3-navbar-heading"> LOGO </NavLink>
                        </div>
                        <div className="bp3-navbar-group bp3-align-right">
                            <NavLink to={PATH_DESCRIPTION} className="bp3-navbar-heading"> <Translate value="header.description" /> </NavLink>
                            <NavLink to={PATH_REFERENCES} className="bp3-navbar-heading"> <Translate value="header.references" /> </NavLink>
                            <NavLink to={PATH_LOGIN} className="bp3-button bp3-minimal logInButton"><Translate value="header.login" /></NavLink>
                            <NavLink to={PATH_REGISTER} className="bp3-button bp3-minimal signUpButton"><Translate value="header.signup" /></NavLink>
                            <LanguageSelection />
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

}