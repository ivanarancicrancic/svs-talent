import * as React from 'react';
import './ProductInfo.css';
import {  searchProductByArtileNumberFetch, searchProductBySectionDescriptionAndManufacturerNameFetch, searchProductByManufacturerNumberFetch, searchProductByManufacturerNameFetch, searchProductByModelFetch } from '../../../redux/product/actions';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct, getProductBySectionDescriptionAndManufacturerName, getProductByManufacturerNum, getProductByManufacturerName, getProductByModel } from '../../../redux/product/selectors';
import { RouteComponentProps } from 'react-router';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';

interface IPropsDispatchMap {
    searchProductByArtileNumberFetch: typeof searchProductByArtileNumberFetch;
    searchProductByManufacturerNumberFetch: typeof searchProductByManufacturerNumberFetch; 
    searchProductByModelFetch: typeof searchProductByModelFetch;
    searchProductByManufacturerNameFetch: typeof searchProductByManufacturerNameFetch;
    searchProductBySectionDescriptionAndManufacturerNameFetch: typeof searchProductBySectionDescriptionAndManufacturerNameFetch;

}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
    productDataByManu: IProductResponseModel | null;
    productDataLoading: boolean; 
    productDataByManuLoading: boolean;
    switchProductDataLoading: boolean;
    switchProductDataByManuLoading: boolean;
    productDataByModel: IProductResponseModel | null;
    productDataByManuName: IProductResponseModel | null;
    productBySectionDescriptionAndManufacturerName: IProductResponseModel | null;

}

interface IProductDataState {
    productDataState: IProductResponseModel | null;
    productDataByManuState: IProductResponseModel | null;
    switchLoadingFalse: boolean;
}


type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{id: number, mid: number, selected: string, manuName: string, mname: string, manufacturerName: string, section: string, description: string }>

 class ProductInfo  extends React.Component<IProps, IProductDataState> {

    constructor(props: any) {
        super(props);
        this.state = {productDataState: null, productDataByManuState: null, switchLoadingFalse: false};
      }

      public componentWillMount() {
          console.log("COMPONENT PRODUCT INFO WILL MOUNT");
        // await this.fetchProduct();
        const idP = this.props.match.params.id;
                  if(idP) 
                {  
                    const id = idP;
                    console.log("calling searchProductByArtileNumberFetch...with id: " + id);
                    // this.setState({ productDataByManuState: null});
                     console.log("this.state.productDataByManuState: " + this.state.productDataByManuState);
                  this.props.searchProductByArtileNumberFetch({id});
                 
                }
                else if (this.props.match.params.mid) {
                    console.log("calling searchProductByManufacturerNumberFetch...with mid: " + this.props.match.params.mid);
                    const mid = this.props.match.params.mid;  
                    // this.setState({productDataState: null });
                    console.log("this.state.productDataState: " + this.state.productDataState);
                    this.props.searchProductByManufacturerNumberFetch({mid}) 
                    }

                 else if(this.props.match.params.selected){
                     console.log("this.props.match.params.selected: " + this.props.match.params.selected);
                    const selected = this.props.match.params.selected; 
                    this.props.searchProductByManufacturerNameFetch({selected}); 
                         }
     
                else if(this.props.match.params.section){
                    console.log("this.props.match.params.section!=null => before calling searchProductBySectionDescriptionAndManufacturerNameFetch: ");
                    const section = this.props.match.params.section;
                    const description = this.props.match.params.description;                    
                    const manufacturerName = this.props.match.params.manufacturerName; 
                    console.log(section + ", " + description + ", " + manufacturerName);
                    this.props.searchProductBySectionDescriptionAndManufacturerNameFetch({section, description, manufacturerName}); 
                        }
             
                
                         else{
                    console.log("calling searchProductByModelFetch...with mname: " + this.props.match.params.mname);
                    const mname = this.props.match.params.mname;   
                    // this.setState({productDataState: null });
                    console.log("this.props.match.params.mname: " + this.props.match.params.mname);
                    this.props.searchProductByModelFetch({mname}) 
                    
                }


    }

public render() {
    console.log("ENTERED!!!");
    console.log("this.props.productDataLoading: " + this.props.productDataLoading);
    console.log("this.props.productDataByManuLoading: " + this.props.productDataByManuLoading);
    
        if(this.props.productData)
        {  
            console.log("HELLOOOOOUU this.props.productData != null");
            if(this.props.productDataByManu)
            {  
                console.log("HIIIIII this.props.productDataByManu != null");
                if(this.props.productDataByManuName)
                {  
                    console.log("ENTERED this.props.productDataByManuName != null");         
                    if(this.props.productDataByModel)
                    {  
                        console.log("this.props.productDataByModel != null");
                     
                        if(this.props.productBySectionDescriptionAndManufacturerName)
                        {
                            console.log("this.props.productBySectionDescriptionAndManufacturerName != null");  
                            console.log("this.props.productBySectionDescriptionAndManufacturerName.searchNum: " + this.props.productBySectionDescriptionAndManufacturerName.searchNum);
                            console.log("this.props.productDataByModel.searchNum: " + this.props.productDataByModel.searchNum);
                            if((this.props.productData.searchNum > this.props.productDataByManu.searchNum) && (this.props.productData.searchNum > this.props.productDataByModel.searchNum) && (this.props.productData.searchNum > this.props.productDataByManuName.searchNum) && (this.props.productData.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum)) 
                          {
                            console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum && this.props.productData.searchNum > this.props.productDataByModel.searchNum && this.props.productData.searchNum > this.props.productDataByManuName.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2> Product by article num: </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productData.name} </b>   
                                </div>
                            )
                           }
                        else if((this.props.productDataByModel.searchNum > this.props.productData.searchNum)&& (this.props.productDataByModel.searchNum >this.props.productDataByManu.searchNum) && (this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum) && (this.props.productDataByModel.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum) ) 
                        {
                            console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by model name:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productDataByModel.name} </b>
                                </div>
                            )
                        }
                        else if((this.props.productDataByManuName.searchNum > this.props.productData.searchNum)&& (this.props.productDataByManuName.searchNum >this.props.productDataByManu.searchNum) && (this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum) && (this.props.productDataByManuName.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum) ) 
                        {
                            console.log("this.props.productDataByManuName.searchNum > this.props.productDataByManu.searchNum && this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum" + this.props.productDataByManuName.searchNum + ", " + this.props.productDataByManu.searchNum + ", " + this.props.productBySectionDescriptionAndManufacturerName.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by model name:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productDataByModel.name} </b>
                                </div>
                            )
                        }
                        else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productData.searchNum)&& (this.props.productBySectionDescriptionAndManufacturerName.searchNum >this.props.productDataByManu.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum) ) 
                        {
                            console.log("this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum && : this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by BySectionDescriptionAndManufacturerName:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                                </div>
                            )
                        }
                        else 
                        {
                            console.log("this.props.productData.searchNum < this.props.productDataByManu.searchNum && this.props.productDataByModel.searchNum < this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by manufacturer num:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productDataByManu.name} </b>
                                </div>
                            )
                        }
                    }


                    else{
                        console.log("this.props.productBySectionDescriptionAndManufacturerName == null");

                        if((this.props.productData.searchNum > this.props.productDataByManu.searchNum) && (this.props.productData.searchNum > this.props.productDataByModel.searchNum) && (this.props.productData.searchNum > this.props.productDataByManuName.searchNum)) 
                        {
                          console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum && this.props.productData.searchNum > this.props.productDataByModel.searchNum && this.props.productData.searchNum > this.props.productDataByManuName.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                          return (
                              <div className="infoBox">
                                  <h2> Product by article num: </h2>
                                  <p> These are product part details.... </p>
                                  <b>{this.props.productData.name} </b>   
                              </div>
                          )
                      }
                      else if((this.props.productDataByModel.searchNum > this.props.productData.searchNum)&& (this.props.productDataByModel.searchNum >this.props.productDataByManu.searchNum) && (this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum) ) 
                      {
                          console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                          return (
                              <div className="infoBox">
                                  <h2>Product by model name:  </h2>
                                  <p> These are product part details.... </p>
                                  <b>{this.props.productDataByModel.name} </b>
                              </div>
                          )
                      }
                      else if((this.props.productDataByManuName.searchNum > this.props.productData.searchNum)&& (this.props.productDataByManuName.searchNum >this.props.productDataByManu.searchNum) && (this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum) ) 
                      {
                          console.log("this.props.productDataByManuName.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                          return (
                              <div className="infoBox">
                                  <h2>Product by model name:  </h2>
                                  <p> These are product part details.... </p>
                                  <b>{this.props.productDataByModel.name} </b>
                              </div>
                          )
                      }
                      else 
                      {
                          console.log("this.props.productData.searchNum < this.props.productDataByManu.searchNum && this.props.productDataByModel.searchNum < this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                          return (
                              <div className="infoBox">
                                  <h2>Product by manufacturer num:  </h2>
                                  <p> These are product part details.... </p>
                                  <b>{this.props.productDataByManu.name} </b>
                              </div>
                          )
                      }  

                    }

                    }
                    else
                    {
                    if(!this.props.productBySectionDescriptionAndManufacturerName)
                     {
                      if((this.props.productData.searchNum > this.props.productDataByManu.searchNum) && (this.props.productData.searchNum > this.props.productDataByManuName.searchNum))
                      {
                        console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2> Product by article num: </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productData.name} </b>   
                            </div>
                        )
                      }
                      else if((this.props.productDataByManu.searchNum > this.props.productData.searchNum) && (this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum))
                      {
                        return (
                            <div className="infoBox">
                                <h2>Product by productDataByManu:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManu.name} </b>
                            </div>
                        )                   
                    } 
                    else 
                    {
                        return (
                            <div className="infoBox">
                                <h2>Product by manufacturer name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManuName.name} </b>
                            </div>
                        )
                    }
                  }
                  else{
                     if((this.props.productData.searchNum > this.props.productDataByManu.searchNum) && (this.props.productData.searchNum > this.props.productDataByManuName.searchNum) && (this.props.productData.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum))
                     {
                       console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                       return (
                           <div className="infoBox">
                               <h2> Product by article num: </h2>
                               <p> These are product part details.... </p>
                               <b>{this.props.productData.name} </b>   
                           </div>
                       )
                     }
                     else if((this.props.productDataByManu.searchNum > this.props.productData.searchNum) && (this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum) && (this.props.productDataByManu.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum))
                     {
                       return (
                           <div className="infoBox">
                               <h2>Product by productDataByManu:  </h2>
                               <p> These are product part details.... </p>
                               <b>{this.props.productDataByManu.name} </b>
                           </div>
                       )                   
                   } 
                   else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productData.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum))
                   {
                     return (
                         <div className="infoBox">
                             <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                             <p> These are product part details.... </p>
                             <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                         </div>
                     )                   
                 } 

                   else 
                   {
                       return (
                           <div className="infoBox">
                               <h2>Product by manufacturer name:  </h2>
                               <p> These are product part details.... </p>
                               <b>{this.props.productDataByManuName.name} </b>
                           </div>
                       )
                   }

                  }
                 }
                }
                else 
                  {
                    console.log("ENTERED this.props.productDataByManuName == null");        
                      if(this.props.productBySectionDescriptionAndManufacturerName){
                        console.log("JUST FISRT ARTICLE SEARCH AND productBySectionDescriptionAndManufacturerName != NULL")
                
                if(this.props.productDataByModel)
                {  
                    console.log("LOL this.props.productDataByManuName == null");
                    console.log("LOL this.props.productDataByModel != null");
                    if((this.props.productDataByModel.searchNum > this.props.productData.searchNum)&& (this.props.productDataByModel.searchNum >this.props.productDataByManu.searchNum && (this.props.productDataByModel.searchNum >this.props.productBySectionDescriptionAndManufacturerName.searchNum))) 
                    {
                        console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by productDataByModel:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByModel.name} </b>
                            </div>
                         )
                    }     
                    else if((this.props.productData.searchNum > this.props.productDataByModel.searchNum)&& (this.props.productData.searchNum >this.props.productDataByManu.searchNum) && (this.props.productData.searchNum >this.props.productBySectionDescriptionAndManufacturerName.searchNum)) 
                    {
                        console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by article:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productData.name} </b>
                            </div>
                        )
                    } 
                    else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum)&& (this.props.productBySectionDescriptionAndManufacturerName.searchNum >this.props.productDataByManu.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum >this.props.productData.searchNum)) 
                    {
                        console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                            </div>
                        )
                    } 

                    else
                    {
                        console.log("this.props.productDataByManu.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by manu name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManu.name} </b>
                            </div>
                        )
                    }
                }
              /////// od tuka nadole
                else if((this.props.productData.searchNum > this.props.productDataByManu.searchNum) && (this.props.productData.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum))
                {   
                    console.log("productDataByModel == null also") 
                    console.log("this.props.productDataByModel == null");
                    console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                    return (
                        <div className="infoBox">
                            <h2>Product by article:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productData.name} </b>
                        </div>
                    )
                } 
                else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productData.searchNum))
                {
                    console.log("this.props.productDataByModel == null");
                    console.log("VLEZE KAJ STO TERBA!!!");
                    console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                    return (
                        <div className="infoBox">
                            <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                        </div>
                    )
                } 

                else 
                {
                    console.log("this.props.productDataByManu.searchNum > this.props.productData.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                    return (
                        <div className="infoBox">
                            <h2>Product by manu:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }

            }
                else{

                    if(this.props.productDataByModel)
                    {  
                        console.log("this.props.productDataByManuName == null");
                        console.log("this.props.productDataByModel != null");
                        if((this.props.productDataByModel.searchNum > this.props.productData.searchNum)&& (this.props.productDataByModel.searchNum >this.props.productDataByManu.searchNum)) 
                        {
                            console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by productDataByModel:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productDataByModel.name} </b>
                                </div>
                             )
                        }     
                        else if((this.props.productData.searchNum > this.props.productDataByModel.searchNum)&& (this.props.productData.searchNum >this.props.productDataByManu.searchNum)) 
                        {
                            console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by article:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productData.name} </b>
                                </div>
                            )
                        } 
                        else
                        {
                            console.log("this.props.productDataByManu.searchNum > this.props.productDataByManu.searchNum && : this.props.productDataByModel.searchNum > this.props.productDataByModel.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                            return (
                                <div className="infoBox">
                                    <h2>Product by manu name:  </h2>
                                    <p> These are product part details.... </p>
                                    <b>{this.props.productDataByManu.name} </b>
                                </div>
                            )
                        }
                    }
                    else if((this.props.productData.searchNum > this.props.productDataByManu.searchNum))
                    {
                        console.log("this.props.productDataByModel == null");
                        console.log("this.props.productData.searchNum > this.props.productDataByManu.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by article:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productData.name} </b>
                            </div>
                        )
                    } 
                    else 
                    {
                        console.log("this.props.productDataByManu.searchNum > this.props.productData.searchNum" + this.props.productData.searchNum + ", " + this.props.productDataByManu.searchNum);
                        return (
                            <div className="infoBox">
                                <h2>Product by manu:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManu.name} </b>
                            </div>
                        )
                    }

                }
            }
            
            }
            else if(this.props.productDataByModel)
            {
                if(!this.props.productBySectionDescriptionAndManufacturerName)
                {
                console.log("HIIIIII this.props.productDataByManu == null");
                console.log("AND this.props.productData AND this.props.productDataByModel != null");
                if((this.props.productData.searchNum > this.props.productDataByModel.searchNum) ) 
                {
                    console.log("this.props.productData.searchNum > this.props.productDataByModel.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByModel.searchNum); 
                    return (
                        <div className="infoBox">
                            <h2> Product by article num: </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productData.name} </b>   
                        </div>
                    )
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by model name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByModel.name} </b>
                        </div>
                    )
                }
            }
            else{
console.log("HIIIIII this.props.productDataByManu == null");
console.log("AND this.props.productData AND this.props.productDataByModel != null AND this.props.productBySectionDescriptionAndManufacturerName != NULL ");
if((this.props.productData.searchNum > this.props.productDataByModel.searchNum) && (this.props.productData.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum) ) 
{
    console.log("this.props.productData.searchNum > this.props.productDataByModel.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByModel.searchNum); 
    return (
        <div className="infoBox">
            <h2> Product by article num: </h2>
            <p> These are product part details.... </p>
            <b>{this.props.productData.name} </b>   
        </div>
    )
}
else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productData.searchNum) ) 
{
    console.log("this.props.productData.searchNum > this.props.productDataByModel.searchNum: " + this.props.productData.searchNum + ", " + this.props.productDataByModel.searchNum); 
    return (
        <div className="infoBox">
            <h2> Product by productBySectionDescriptionAndManufacturerName: </h2>
            <p> These are product part details.... </p>
            <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>   
        </div>
    )
}
else 
{
    return (
        <div className="infoBox">
            <h2>Product by model name:  </h2>
            <p> These are product part details.... </p>
            <b>{this.props.productDataByModel.name} </b>
        </div>
    )
}


            }
            }
            else
            {
                if(this.props.productBySectionDescriptionAndManufacturerName){
                 if(this.props.productBySectionDescriptionAndManufacturerName.searchNum> this.props.productData.searchNum)
                  {
                      console.log("USPEAV");
                    return (
                        <div className="infoBox">
                            <h2> Product by productBySectionDescriptionAndManufacturerName: </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>   
                        </div>
                    )

                  }
                 else
                {                   
                    return (
                        <div className="infoBox">
                            <h2> Product by article num: </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productData.name} </b>   
                        </div>
                    )
            }
        }
        else{
            return (
                <div className="infoBox">
                    <h2> Product by article num: </h2>
                    <p> These are product part details.... </p>
                    <b>{this.props.productData.name} </b>   
                </div>
            )

        }
        }
        }
        else 
        {
            console.log("this.props.productData == NULL VLEZEEEEEE!!!")
          if(!this.props.productBySectionDescriptionAndManufacturerName)  
          {
        if(this.props.productDataByManu)
        {  
            console.log("this.props.productData == null");
            if(this.props.productDataByModel)
            {
                console.log("this.props.productDataByModel != null");
                if(this.props.productDataByManuName)
                {
                    console.log("this.props.productDataByManuName != null");
                    if((this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum ) && (this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum ))
                    {
                        console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by model name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByModel.name} </b>
                            </div>
                        )
                    }
                    else if((this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum ) && (this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ))
                    {
                        console.log("this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum && this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by manu number:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManu.name} </b>
                            </div>
                        )
                    }
                    else 
                    { 
                        console.log("this.props.productDataByManuName > this.props.productDataByManu.searchNum && this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by manu name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManuName.name} </b>
                            </div>
                        )
                    } 
                }
                else if((this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ))
                {
                    console.log("this.props.productDataByManuName == null");
                    console.log("this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ");
                    return (
                        <div className="infoBox">
                            <h2>Product by manu number:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by model name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByModel.name} </b>
                        </div>
                    )
                }
            }   
            else if(this.props.productDataByManuName)
            {
                console.log("this.props.productDataByModel == null");
                if(this.props.productDataByManuName.searchNum > this.props.productDataByManu.searchNum)
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu number:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }
            }
            else 
            {
                return (
                    <div className="infoBox">
                        <h2>Product by manu number:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productDataByManu.name} </b>
                    </div>
                )
            }                
        }
        else if(this.props.productDataByManuName)  
        {
            console.log("this.props.productDataByManu == null"); 
            if(this.props.productDataByModel)
            { 
                if(this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum)
                {    
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )                    
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )
                }
            } 
            else 
            {
                return (
                    <div className="infoBox">
                        <h2>Product by manu name:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productDataByManuName.name} </b>
                    </div>
                )          
            }
        }   
        else if(this.props.productDataByModel)
        { 
            return (
                <div className="infoBox">
                   <h2>Product by model name:  </h2>
                   <p> These are product part details.... </p>
                   <b>{this.props.productDataByModel.name} </b>
                </div>
            )                    
        }
        else
        {
            console.log("RETURNED NULL");
            return null;
        }
    }

    else{
        console.log("this.props.productBySectionDescriptionAndManufacturerName ! = NULL !!! Yeeee")
        if(this.props.productDataByManu)
        {  
            console.log("this.props.productDataByManu != NULL");
            console.log("this.props.productData == null");
            if(this.props.productDataByModel)
            {
                console.log("this.props.productDataByModel != null");
                if(this.props.productDataByManuName)
                {
                    console.log("this.props.productDataByManuName != null");
                    if((this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum ) && (this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum ) && (this.props.productDataByModel.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum ))
                    {
                        console.log("this.props.productDataByModel.searchNum > this.props.productDataByManu.searchNum && this.props.productDataByModel.searchNum > this.props.productDataByManuName.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by model name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByModel.name} </b>
                            </div>
                        )
                    }
                    else if((this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum ) && (this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ) && (this.props.productDataByManu.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum ))
                    {
                        console.log("this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum && this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by manu number:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManu.name} </b>
                            </div>
                        )
                    }
                    else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum ) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum ) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum ))
                    {
                        console.log("this.props.productDataByManu.searchNum > this.props.productDataByManuName.searchNum && this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                            </div>
                        )
                    }

                    else 
                    { 
                        console.log("this.props.productDataByManuName > this.props.productDataByManu.searchNum && this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum");
                        return (
                            <div className="infoBox">
                                <h2>Product by manu name:  </h2>
                                <p> These are product part details.... </p>
                                <b>{this.props.productDataByManuName.name} </b>
                            </div>
                        )
                    } 
                }
                else if((this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ) && (this.props.productDataByManu.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum ))
                {
                    console.log("this.props.productDataByManuName == null");
                    console.log("this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ");
                    return (
                        <div className="infoBox">
                            <h2>Product by manu number:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }

                else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum ) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum ))
                {
                    console.log("this.props.productDataByManuName == null");
                    console.log("this.props.productDataByManu.searchNum > this.props.productDataByModel.searchNum ");
                    return (
                        <div className="infoBox">
                            <h2>Product by manu number:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by model name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByModel.name} </b>
                        </div>
                    )
                }
            }
    
            else if(this.props.productDataByManuName)
            {
                console.log("this.props.productDataByModel == null");
                if((this.props.productDataByManuName.searchNum > this.props.productDataByManu.searchNum)&& (this.props.productDataByManuName.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum))
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )
                }
                else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum)&& (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum))
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                        </div>
                    )
                }
                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu number:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManu.name} </b>
                        </div>
                    )
                }
            }
            else if(this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManu.searchNum) 
            {
                return (
                    <div className="infoBox">
                        <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                    </div>
                )
            }

            else 
            {
                return (
                    <div className="infoBox">
                        <h2>Product by manu number:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productDataByManu.name} </b>
                    </div>
                )
            }                
        }

        else if(this.props.productDataByManuName)  
        {
         
            console.log("this.props.productDataByManu == null"); 
            if(this.props.productDataByModel!= null)
            { 
                if((this.props.productDataByManuName.searchNum > this.props.productDataByModel.searchNum) && (this.props.productDataByManuName.searchNum > this.props.productBySectionDescriptionAndManufacturerName.searchNum))
                {    
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )                    
                }
                else if((this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum) && (this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum))
                {    
                    return (
                        <div className="infoBox">
                            <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                        </div>
                    )                    
                }

                else 
                {
                    return (
                        <div className="infoBox">
                            <h2>Product by manu name:  </h2>
                            <p> These are product part details.... </p>
                            <b>{this.props.productDataByManuName.name} </b>
                        </div>
                    )
                }
            } 
            else if(this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByManuName.searchNum) 
            {

                return (
                    <div className="infoBox">
                        <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                    </div>
                )          
            }
            else {
                return (
                    <div className="infoBox">
                        <h2>Product by manu name:  </h2>
                        <p> These are product part details.... </p>
                        <b>{this.props.productDataByManuName.name} </b>
                    </div>
                )     

            }
        }   
        
        else if(this.props.productDataByModel)
        { 
            if(this.props.productBySectionDescriptionAndManufacturerName.searchNum > this.props.productDataByModel.searchNum){
                return (
                    <div className="infoBox">
                       <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                       <p> These are product part details.... </p>
                       <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                    </div>
                )    
            }
            else{
            return (
                <div className="infoBox">
                   <h2>Product by model name:  </h2>
                   <p> These are product part details.... </p>
                   <b>{this.props.productDataByModel.name} </b>
                </div>
            )    
        }                
        }
      

        else
        {
            console.log("RETURNED productBySectionDescriptionAndManufacturerName");
            return (
                <div className="infoBox">
                   <h2>Product by productBySectionDescriptionAndManufacturerName:  </h2>
                   <p> These are product part details.... </p>
                   <b>{this.props.productBySectionDescriptionAndManufacturerName.name} </b>
                </div>
            )    
            
         }
        
    }
}  
            }

        }
const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state),
    productDataByManu: getProductByManufacturerNum(state),
    productDataByManuName: getProductByManufacturerName(state),
    productDataByModel: getProductByModel(state),
    productDataLoading: state.product.productDataLoading,
    productDataByManuLoading: state.productByManufacturerNumber.productDataByManuLoading,
    switchProductDataLoading: state.productByManufacturerNumber.switchProductDataLoading,
    switchProductDataByManuLoading: state.product.switchProductDataByManyLoading,
    productBySectionDescriptionAndManufacturerName: getProductBySectionDescriptionAndManufacturerName(state)
});

export default connect(mapStateToProps, {searchProductByArtileNumberFetch, searchProductByManufacturerNumberFetch, searchProductByManufacturerNameFetch, searchProductBySectionDescriptionAndManufacturerNameFetch, searchProductByModelFetch})(ProductInfo)