import * as React from 'react';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
import { IRootState } from '../../redux';
import { manufacturerListFetch } from '../../redux/manufacturer-list/actions';
import { IManufacturerResponseModel } from '../../redux/manufacturer-list/types';
import { getManufacturerList } from '../../redux/manufacturer-list/selectors';
import { manufacturerCreateFetch } from '../../redux/manufacturer/actions';
import { RouteComponentProps } from 'react-router';

interface IPropsDispatchMap {
    manufacturerListFetch: typeof manufacturerListFetch;
    manufacturerCreateFetch: typeof manufacturerCreateFetch;
}
interface IPropsStateMap {
    manufacturersData: IManufacturerResponseModel[] | null;
    manufacturerCreating: boolean;
    lastCreatedId: number | null;
}


type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{cid: number}>

class Manufacturers extends React.Component<IProps> {
         
    public componentWillMount() {
        const cid = this.props.match.params.cid;
        this.props.manufacturerListFetch({cid});
      }



    public render():any {

        if(this.props.manufacturersData == null) {
            return null;
        }

        return (

<div className="dashboardTable">
<table className="table bp3-html-table bp3-html-table-bordered">
<tbody>
    <tr>
    {this.props.manufacturersData.map( manufacturer => {
        return (
            <tr key={manufacturer.id}>
               <Link to={`/category/${this.props.match.params.cid}/manufacturer/${manufacturer.id}/products`} > <td><b>{manufacturer.name} Manufacturer</b></td></Link>
                <td>{manufacturer.description} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </td>
                <td><Link to={`/manufacturer/${manufacturer.id}`} className="fontello icon-edit"/> </td>
            </tr>
        )
    })}
  </tr>
    <tr>
    <td colSpan={5} className="text-center" >
        {!this.props.manufacturerCreating && <a onClick={ () => {this.props.manufacturerCreateFetch()} } className="bp3-button bp3-icon-plus bp3-minimal"/>}
    </td>
    </tr>
</tbody>
</table>
</div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    manufacturersData: getManufacturerList(state),
    manufacturerCreating: state.manufacturer.createLoading,
    lastCreatedId: state.manufacturer.lastCreatedId,
});

export default connect(mapStateToProps, {manufacturerListFetch, manufacturerCreateFetch})(Manufacturers)