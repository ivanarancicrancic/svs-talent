import * as React from 'react';
import CreateInfo from './CreateInfo/CreateInfo';


export default class InquiryLayout extends React.Component {

    public render() {
        return (
            <div className="inquiry">
                <CreateInfo />
            </div>
        )
    }

}