import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';
import InquiryImages from '../InquiryImages/InquiryImages';

export default class CreateInfo extends React.Component {
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }
    
      public onSubmit(values:any) {
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        console.log(values)
      }


      

    public render() {
        return (
            <div className="createInfo">

          <table>
              
                 <tr>
                  
                <Form 
                    model="forms.info"
                    method="post"
                    onSubmit={ (info) => this.onSubmit(info) }
                    validators={{
                        name: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                    
                >
                      <div>
                        <label htmlFor="name" className="bp3-file-input"><b>Hersteller</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'Please enter Hersteller',
                            }}
                            show="touched"
                            className="errors"
                        /> <br/>
                    </div>
                   <br/> 
                        <tr>
                     <label htmlFor="name1" className="bp3-file-input"><b>Gerät *</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name1"
                        />
                        <Errors
                            model=".name1"
                            messages={{
                                required: 'Please enter Gerät',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        </tr>
                        <br/>
                        <tr>
                     <label htmlFor="name2" className="bp3-file-input"><b>Modell</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name2"
                        />
                        <Errors
                            model=".name2"
                            messages={{
                                required: 'Please enter Modell',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        </tr>
                        <br/>
                        <tr>
                     <label htmlFor="name3" className="bp3-file-input"><b>Baujahr</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name3"
                        />
                        <Errors
                            model=".name3"
                            messages={{
                                required: 'Please enter Baujahr',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        </tr>
                         <br/>
                      
                      <tr>
                     <label htmlFor="name4" className="bp3-file-input"><b>Ersatzteil *</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name4"
                        />
                        <Errors
                            model=".name4"
                            messages={{
                                required: 'Please enter Ersatzteil',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        </tr>
                          <br/>
                      <tr>
                     <label htmlFor="name5" className="bp3-file-input"><b>Ersatzteil-Nummer</b></label>
                        <Control.text
                            className="bp3-input"
                            model=".name5"
                        />
                        <Errors
                            model=".name5"
                            messages={{
                                required: 'Please enter a Ersatzteil-Nummer',
                            }}
                            show="touched"
                            className="errors" 
                        /> 
                        </tr>
                        <br/>
                        <tr>
                   
                        <Control.text
                            className="bp3-input"
                            model=".name6" placeholder = "weitere Angaben vom Typenschild"
                        />
                        <Errors
                            model=".name6"
                            messages={{
                                required: 'Please enter weitere Angaben vom Typenschild',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        <br/>
                        <label htmlFor="name6" className="bp3-file-input">z.B. Produktions-, F-, Serien-Nr. etc</label>
                        </tr>
                         <br/>
                         <tr>
                            <tr/> <tr/> <tr/>
                        <div className="bp3-input-group">
                        <Control.text
                            className="bp3-input"
                            model=".name7" placeholder = "anrede"
                        />
                          <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".package" 
                            >
                                 <option defaultValue="Basic">Bitte Auswahlen </option>
                                <option value="Advanced">Her </option>
                                <option value="Premium">Frau </option>
                            </Control.select>
                          </div>
                       
                       </div>
                            </tr>
                      <br/>
                        <tr>
                        <label htmlFor="name8" className="bp3-file-input"><b>Firma *</b></label>                   
                        <Control.text
                            className="bp3-input"
                            model=".name8"
                        />
                        <Errors
                            model=".name8"
                            messages={{
                                required: 'Please enter firma',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                      
                        </tr>
                     <br/>
                    <tr>
                        <label htmlFor="name9" className="bp3-file-input"><b>Name *</b></label>                   
                        <Control.text
                            className="bp3-input"
                            model=".name9"
                        />
                        <Errors
                            model=".name9"
                            messages={{
                                required: 'Please enter name',
                            }}
                            show="touched"
                            className="errors"
                        /> 

                        </tr>
                       <br/>
                          <tr>
                        <label htmlFor="name10" className="bp3-file-input"><b>E-Mail *</b></label>                   
                        <Control.text
                            className="bp3-input"
                            model=".name10"
                        />
                        <Errors
                            model=".name10"
                            messages={{
                                required: 'Please enter a e-mail',
                            }}
                            show="touched"
                            className="errors"
                        /> 

                        </tr>

                     <tr>
                        <label htmlFor="name11" className="bp3-file-input"><b>Telefon</b></label>                   
                        <Control.text
                            className="bp3-input"
                            model=".name11"
                        />
                        <Errors
                            model=".name11"
                            messages={{
                                required: 'Please enter telefon',
                            }}
                            show="touched"
                            className="errors"
                        /> 

                        </tr>



    <tr>
                        <Control.text
                            className="bp3-input"
                            model=".name12" placeholder = "Weitere Informationen an uns..."
                        />
                        <Errors
                            model=".name12"
                            messages={{
                                required: 'Please enter an information about us',
                            }}
                            show="touched"
                            className="errors"
                        /> 

                        </tr>
                
                     <br/>

                    <InquiryImages />
                    <br/> <br/>
                        <button type="submit" value="Submit" className="bp3-button bp3-intent-success" > Anfrage absenden >> </button>
   
       </Form>
         </tr>
         </table>
            </div>
        )
       
    }

}