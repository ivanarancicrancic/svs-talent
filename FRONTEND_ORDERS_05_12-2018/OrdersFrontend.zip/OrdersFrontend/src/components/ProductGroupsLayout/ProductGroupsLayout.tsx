import * as React from 'react';
import { connect } from 'react-redux';

import './ProductGroupsLayout.css';
import { IRootState } from '../../redux';
import { categoryListFetch } from '../../redux/category-list/actions';
import { ICategoryResponseModel } from '../../redux/category-list/types';
import { getCategoryList } from '../../redux/category-list/selectors';
import { categoryCreateFetch } from '../../redux/category/actions';

import { history } from '../../router';

interface IPropsDispatchMap {
    categoryListFetch: typeof categoryListFetch;
    categoryCreateFetch: typeof categoryCreateFetch;
}
interface IPropsStateMap {
    categoryData: ICategoryResponseModel[] | null;
    categoryCreating: boolean;
    lastCreatedId: number | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class ProductGroupsLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.categoryListFetch();
      }

    public componentWillReceiveProps(nextProps: IProps) {

        const categoryCreated = this.props.categoryCreating === true && nextProps.categoryCreating === false;
        if(categoryCreated) {
            history.push(`/category/${nextProps.lastCreatedId}`);
        }
    }

    public renderCategoryList() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable" style={{backgroundColor:"#D3D3D3"}} >
              <h1 style={{textAlign:"center"}}> Ersatzteile für Gastronomie-Technik </h1>
                  <tr>Willkommen! Bei uns können Sie aus einem der größten Sortimente Europas Ihr passendes Ersatzteil auswählen. Für fast jeden Hersteller gastronomischer Geräte haben wir beinahe alles im Angebot. Nutzen Sie unsere komfortablen Suchfunktionen oder wenden sich direkt an uns - Ihr Ersatzteil-Handel24.com Team</tr>
                   
                <table className="table" style={{backgroundColor:"#D3D3D3"}}>
                    <thead>
                        <tr/>
                    </thead>
                    <tbody>
                
                    <tr>
                     <td><button style={{backgroundColor:"#DF4444"}}> Warengruppen SchnellSuche></button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Ertzatsteil suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Bilder Suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}>Explosionzeichnungen </button></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        );
    }

    public renderCategoryList2() {

        if(this.props.categoryData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table">
                <tbody>
                    <tr>
                    {this.props.categoryData.map( category => {
                        return (
                            <td key={category.id}>
                                <tr><b>{category.name} Kategorie</b></tr>
                                <tr>{category.numberOfViews} In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </tr>
                            </td>
                        )
                    })}
                  </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
                {this.renderCategoryList()}
                {this.renderCategoryList2()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    categoryData: getCategoryList(state),
    categoryCreating: state.category.createLoading,
    lastCreatedId: state.category.lastCreatedId,
});

export default connect(mapStateToProps, {categoryListFetch, categoryCreateFetch})(ProductGroupsLayout)