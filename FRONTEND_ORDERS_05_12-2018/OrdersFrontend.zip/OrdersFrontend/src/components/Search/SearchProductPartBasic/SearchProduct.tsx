import * as React from 'react';
import SearchByArticleNum from './SearchProductPartBasic';
import SearchByManuNum from './SearchProductPartByManufacturerNum';
import SpecialSearch from './SpecialSearch';
import ExplosionszeichnungenSuche from './ExplosionszeichnungenSuche';
import SearchByModel from './SearchByModel';

export default class SearchProduct extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <SearchByArticleNum />
                <br/>
                        <br/>
                <SearchByManuNum />
                <br/>
                        <br/>
                <SpecialSearch />
                <br/>
                        <br/>
                <ExplosionszeichnungenSuche />
                <br/>
                        <br/>
                <SearchByModel />

            </div>
        )
    }

}