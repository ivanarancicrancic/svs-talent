import * as React from 'react';
import { Form, Control } from 'react-redux-form';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct } from '../../../redux/product/selectors';
import { searchProductByManufacturerNumberFetch } from '../../../redux/product/actions';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';
 import { history } from '../../../router';
//  import axios from 'axios';
//  import { API_ROOT } from '../../../router/api-config';

interface IPropsDispatchMap {
    searchProductByManufacturerNumberFetch: typeof searchProductByManufacturerNumberFetch;
   
}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


class SpecialSearch extends React.Component<IProps> {
    constructor(props: any) {
        super(props);
        this.state = {
            id: 1
          };
        // this.onSubmit = this.onSubmit.bind(this);
        this.onSubmitHersteller = this.onSubmitHersteller.bind(this);

      }
    
      public onSubmitHersteller(values:any) {

        console.log("ENTERED onSubmitSectionDescriptionAndManuName: " + values.manufacturerName);
         

        const manufacturerName = values.manufacturerName;
        console.log("SELECTED MANUFACTURER values.selectedManufacturer: " + values.manufacturerName);
        const section = values.section;
        console.log("SELECTED SECTION values.commercialSelect: " + values.section);
        const description = values.description;
         console.log("SELECTED TECHNICAL DESCRIPTION values.selectedDescription: " + values.description);

        console.log("Checkbox value: " + values.check);
        if(manufacturerName && section && description){
            console.log("Right before calling HERE:  /productBySectionDescriptionAndManufacturer/${commercialSelect}/${dichtungSelect}/${selected}`): " + section + "/" + description + "/" + manufacturerName);
            history.push(`/productBySectionDescriptionAndManufacturer/${section}/${description}/${manufacturerName}`);
        }
       
    //    else if(selected!=null){
    //     console.log("selectedManufacturer != NULL");  
    //     history.push(`/productByManufacturerName/${selected}`);
    //       }
        
    //       else if(dichtungSelect!=null){
    //         console.log("dichtungSelect != NULL");  
    //         history.push(`/productByDichtungSelect/${dichtungSelect}`);
    //           }

          else
            {     
               console.log("THIS EXCPETION"); 
                // history.push(`/productByManufacturer/${commercialSelect}/${selected}`);
            }

      }


    public render() {
        return (
            <div className="createInfo">

          <table>
            
                 
                <Form 
                    model="forms.info"
                    method="post"
                   
                    onSubmit={ (info) => this.onSubmitHersteller(info) }
                    
                >  
 <div className="bp3-input-group">
                        <label htmlFor="package" className="bp3-file-input"><b>Spezial-Suche</b></label>
                        - Kühlgeräte Dichtungen <br/>
                        - Wasserarmaturen, Brausen <br/>
                        - Sanitär und Zubehör
                       <br/>
                       <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".section" 
                            >
                                <option defaultValue="Gewerbekalte wahlen">Gewerbekalte wahlen </option>
                                <option value="Schockfroste">Schockfroste </option>
                                <option value="Sanitar und Armaturen">Sanitar + Armaturen </option>
                            </Control.select>
                        </div>

                       <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".description" 

                            >
                                <option defaultValue="Dichtung">Dichtung </option>
                            </Control.select>
                        </div>

                        <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".manufacturerName" 
                               
                            >
                                <option value="Hersteller wahlen">Hersteller wahlen </option>
                                <option value="Hersteller unbekannt">Hersteller unbekannt </option>
                                <option value="A.R.C">A.R.C </option>
                                <option value="A.B">A.B </option>
                                <option value="ABAT">ABAT </option>
                                <option defaultValue="Electrolux">ABB </option>
                            </Control.select>
                        </div>
                        <br/>
                    </div>
                    <label>
                        <Control.checkbox model=".check" /> ohne Hersteller
                    </label>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

        </Form>
         </table>
     
            </div>
     
    )
    
    }

}

const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state),
});

export default connect(mapStateToProps, {  searchProductByManufacturerNumberFetch })(SpecialSearch)