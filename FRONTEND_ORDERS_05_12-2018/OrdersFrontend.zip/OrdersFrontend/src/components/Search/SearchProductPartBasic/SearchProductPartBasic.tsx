import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';
import { Link } from "react-router-dom";
import { PATH_START } from '../../../router/paths';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct } from '../../../redux/product/selectors';
import { searchProductByArtileNumberFetch, searchProductByManufacturerNumberFetch } from '../../../redux/product/actions';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';
 import { history } from '../../../router';
//  import axios from 'axios';
//  import { API_ROOT } from '../../../router/api-config';

interface IPropsDispatchMap {
    searchProductByArtileNumberFetch: typeof searchProductByArtileNumberFetch;
   
}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


class SearchProductPartBasic extends React.Component<IProps> {
    constructor(props: any) {
        super(props);
        this.state = {
            id: 1
          };
        this.onSubmit = this.onSubmit.bind(this);
        // this.onSubmitHersteller = this.onSubmitHersteller.bind(this);

      }
    
      public onSubmit(values:any) {
            
        // axios({
        //     method: 'get',
        //     url: API_ROOT + '/api/product/' + values.name
        // }).then(response => {
        //     const result = response.data as IProductResponseModel[];
        //     console.log(result);
        //     history.push(`/product/`+ values.name);
        // }).catch(error => {
        //     console.log("Error");
        // });

      
      
      
        // fetch('/api/product/' + values.name, {
        //     method: 'POST',
        //     body: JSON.stringify({
        //         values
        //     }),
        // });
  
       
        // this.props.searchProductByArtileNumberFetch(values.name);
        console.log("Entered onSubmit():|" + values.name);
        const id = values.name;
        history.push(`/product/${id}`);
      }

      public onSubmitHersteller(values:any) {

        console.log("ENTERED onSubmitHersteller: " + values.name1);
        const mid = values.name1;
        history.push(`/product/${mid}`);

      }


    //   public onSubmit1 = ()  => {
    //     this.props.loginUserFetch();
    // }

    public render() {
        return (
            <div className="createInfo">

          <table>
            
                 
                <Form 
                    model="forms.info"
                    method="post"
                   
                    onSubmit={ (info) => this.onSubmit(info) }
                    // onSubmit={ (info) => this.onSubmit1() }
                    // validateOn="submit"
                    
                >   <tr><td>
               
                    <div>
                        <label><b>Suche über Warengruppen. </b>
                        <br/>Nichts gefunden? <br/> Nutzen Sie die Möglichkeit per Warengruppe zu suchen...</label>
                        <br/>
                        <Link to={PATH_START} > <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#B22222"}} > Schnellsuche </button>
                   </Link> </div>
                 
                  
                  </td>

                   <td> 
                   
                    <div >
                        <label><b>Bilder-Suche für einige </b> <br/> Warengruppen</label><br/>
                        Vergleichen Sie Ihr gesuchtes Ersatzteil über Bilder. Wenn Sie die genaue Bezeichnung Ihres Ersatzteils nicht kennen, nutzen Sie diese Suche!
                        <br/> 
                        <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4"}} > Image Search >> </button>               
                    </div>
                  
                    </td>
                    
                   </tr>

                 <tr>
                   <td>
               
                
                        <br/>
                      <div>
                        <label htmlFor="name" className="bp3-file-input"><b>Suche nach Artikelnummer</b></label>
                        <br/>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'Please enter article number!',
                            }}
                            show="touched"
                            className="errors"
                        /> <br/>
                         <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}>  Suchen >> </button> 
                    </div> 
                  
                   </td>
            
         </tr>
       
     
        </Form>
         </table>
     
            </div>
     
    )
    
    }

}

const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state),
});

export default connect(mapStateToProps, { searchProductByArtileNumberFetch, searchProductByManufacturerNumberFetch })(SearchProductPartBasic)