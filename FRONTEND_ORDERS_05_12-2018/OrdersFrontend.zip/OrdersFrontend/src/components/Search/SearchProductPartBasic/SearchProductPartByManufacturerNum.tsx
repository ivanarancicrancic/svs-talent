import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct } from '../../../redux/product/selectors';
import { searchProductByManufacturerNumberFetch } from '../../../redux/product/actions';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';
 import { history } from '../../../router';
//  import axios from 'axios';
//  import { API_ROOT } from '../../../router/api-config';

interface IPropsDispatchMap {
    searchProductByManufacturerNumberFetch: typeof searchProductByManufacturerNumberFetch;
   
}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


class SearchProductPartByManufacturerNum extends React.Component<IProps> {
    constructor(props: any) {
        super(props);
        this.state = {
            id: 1
          };
    
          this.onSubmitHersteller = this.onSubmitHersteller.bind(this);

      }
    
      public onSubmitHersteller(values:any) {

        console.log("ENTERED onSubmitHersteller: " + values.name1);
        const mid = values.name1;
        console.log("SELECTED MANUFACTURER values.selectedManufacturer: " + values.selectedManufacturer);
        const selected = values.selectedManufacturer;
        console.log("Checkbox value: " + values.check);
        if(mid){
            // console.log("Right before calling:  history.push(`/productByManufacturerNumber/${mid}`): " + mid);
            history.push(`/productByManufacturerNumber/${mid}`);
        }
       
       else if(selected){
        console.log("SELECTED != NULL");  
        history.push(`/productByManufacturerName/${selected}`);
          }
        
          else
           {     
               console.log("THIS EXCPETION"); 
                history.push(`/productByManufacturer/${mid}/${selected}`);
            }

       
      }


    public render() {
        return (
            <div className="createInfo">

          <table>
            
                 
                <Form 
                    model="forms.info"
                    method="post"
                   
                    onSubmit={ (info) => this.onSubmitHersteller(info) }
                    // onSubmit={ (info) => this.onSubmit1() }
                    // validateOn="submit"       
                >  
                 <tr>
                     <td>
             
                     <br/>
                    <div className="bp3-input-group">
                        <label htmlFor="package" className="bp3-file-input"><b>Suche nach Herstellernummer</b></label>
                        <div className="bp3-select bp3-fill">
                            <Control.select 
                                model=".selectedManufacturer" 
                            >
                                 <option defaultValue="Basic">Herstellen wahlen </option>
                                <option value="A.D.">A.D. </option>
                                <option value="A.R.C">A.R.C </option>
                                <option value="A.B">A.B </option>
                                <option value="ABAT">ABAT </option>
                                <option value="Electrolux">Electrolux </option>
                            </Control.select>
                        </div>
                        <Control.text
                            className="bp3-input"
                            model=".name1"
                        />
                        <Errors
                            model=".name1"
                            messages={{
                                required: 'Please enter sth in input field',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                    </div>
                    <label>
                        <Control.checkbox model=".check" /> Hersteller unbekannt
                    </label>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}}> Suchen >> </button>
                  
              </td>
            
                        </tr>
     
        </Form>
         </table>
     
            </div>
     
    )
    
    }

}

const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state),
});

export default connect(mapStateToProps, {  searchProductByManufacturerNumberFetch })(SearchProductPartByManufacturerNum)