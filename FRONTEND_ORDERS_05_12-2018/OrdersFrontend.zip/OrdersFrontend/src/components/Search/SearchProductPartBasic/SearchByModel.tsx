import * as React from 'react';
import { Form, Control, Errors } from 'react-redux-form';
import { IProductResponseModel } from '../../../redux/product/types';
import { getProduct } from '../../../redux/product/selectors';
import { searchProductByManufacturerNumberFetch } from '../../../redux/product/actions';
import { IRootState } from '../../../redux';
import { connect } from 'react-redux';
 import { history } from '../../../router';
//  import axios from 'axios';
//  import { API_ROOT } from '../../../router/api-config';

interface IPropsDispatchMap {
    searchProductByManufacturerNumberFetch: typeof searchProductByManufacturerNumberFetch;
   
}
interface IPropsStateMap {
    productData: IProductResponseModel | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


class SearchByModel extends React.Component<IProps> {
    constructor(props: any) {
        super(props);
        this.state = {
            id: 1
          };
        // this.onSubmit = this.onSubmit.bind(this);
        this.onSubmitHersteller = this.onSubmitHersteller.bind(this);

      }
    
    
      public onSubmitHersteller(values:any) {

        console.log("ENTERED onSubmitHersteller: " + values.name3);
        const mname = values.name3;
        history.push(`/productByModel/${mname}`);

      }


    //   public onSubmit1 = ()  => {
    //     this.props.loginUserFetch();
    // }

    public render() {
        return (
            <div className="createInfo">

          <table>
            
                 
                <Form 
                    model="forms.info"
                    method="post"
                   
                    onSubmit={ (info) => this.onSubmitHersteller(info) }
                    // onSubmit={ (info) => this.onSubmit1() }
                    // validateOn="submit"
                    
                >  

     <b>    Suche nach Modell </b><br/>
- Hersteller Angabe zusaetzlich moeglich
                 <Control.text
                            className="bp3-input"
                            model=".name3"
                        />
                        <Errors
                            model=".name3"
                            messages={{
                                required: 'Please enter a Model name',
                            }}
                            show="touched"
                            className="errors"
                        /> 
                        
                        <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Search >> </button>
     
        </Form>
         </table>
     
            </div>
     
    )
    
    }

}

const mapStateToProps = (state: IRootState) => ({
    productData: getProduct(state),
});

export default connect(mapStateToProps, {  searchProductByManufacturerNumberFetch })(SearchByModel)