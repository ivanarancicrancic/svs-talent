import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";

import { RouteComponentProps, Switch, Route } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_LOGIN, PATH_DASHBOARD, PATH_CATEGORY_EDIT, PATH_CREATE_CATEGORY, PATH_PRODUCT_DETAIL, PATH_PRODUCT_BY_MANUFACTURER_NUMBER_DETAIL, PATH_PRODUCT_BY_MANUFACTURER_NAME_DETAIL, PATH_PRODUCT_BY_MODEL, PATH_START, PATH_SEARCH, PATH_INQUIRY, PATH_CATEGORY_DETAIL, PATH_MANUFACTURERS_DETAIL, PATH_PRODUCT_BY_COMERCIALSELECT} from '../../router/paths';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
import EditCategory from '../../components/Category/EditCategory';
import ProductGroupsLayout from '../../components/ProductGroupsLayout/ProductGroupsLayout';
// import StartLayout from '../../components/StartLayout/StartLayout';
 import Products from '../../components/Products/Products';
import SearchLayout from '../../components/SearchLayout/SearchLayout';
import SearchProductPart from '../../components/Search/SearchProductPartBasic/SearchProduct';
import Inquiry from '../../components/InquiryLayout/InquiryLayout';
import StartLayout from '../../components/StartLayout/StartLayout';
import Manufacturers from '../../components/Manufacturer/Manufacturers';
import ProductDetail from '../../components/Product/ProductInfo/ProductInfo';

library.add(faEnvelope, faKey);

interface IPropsStateMap {
  auth: IAuthState
}

type IProps = RouteComponentProps<{}> & IPropsStateMap;

class App extends React.Component<IProps> {

  public componentWillReceiveProps(nextProps: IProps) {
    if(this.props.auth.token != null && nextProps.auth.token == null) {
      this.props.history.replace(PATH_LOGIN);
    }
  }

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_DASHBOARD} exact={true} component={ProductGroupsLayout} />
            <Route path={PATH_SEARCH} exact={true} component={SearchLayout} />
            <Route path={PATH_START} exact={true} component={StartLayout} />
            <Route path={PATH_CATEGORY_EDIT} exact={true} component={EditCategory} />
            <Route path={PATH_CATEGORY_DETAIL} exact={true} component={Products} />
            <Route path={PATH_MANUFACTURERS_DETAIL} exact={true} component={Manufacturers} />
            <Route path={PATH_CREATE_CATEGORY} exact={true} component={SearchProductPart} />
            <Route path={PATH_INQUIRY} exact={true} component={Inquiry} />
            <Route path={PATH_PRODUCT_DETAIL} exact={true} component={ProductDetail} />
            <Route path={PATH_PRODUCT_BY_MANUFACTURER_NUMBER_DETAIL} exact={true} component={ProductDetail} />
            <Route path={PATH_PRODUCT_BY_MANUFACTURER_NAME_DETAIL} exact={true} component={ProductDetail} />
            <Route path={PATH_PRODUCT_BY_MODEL} exact={true} component={ProductDetail} />
            <Route path={PATH_PRODUCT_BY_COMERCIALSELECT} exact={true} component={ProductDetail} />
        
          </Switch>
        </div>
        <Footer />
      </div>
    );
  }


}
const mapStateToProps = (state: IRootState) => ({
  auth: state.auth
});

export default connect(mapStateToProps)(App);