export const PATH_ROOT = '/';

export const PATH_LOGIN = '/login';
export const PATH_FORGOT_PASSWORD_REQUEST = '/forgot-password';
export const PATH_FORGOT_PASSWORD_RESET = '/reset-password/:username/:token?';
export const PATH_REGISTER = '/register';
export const PATH_REGISTER_COMPLETE = '/welcome';
export const PATH_PRIVACY = '/login/privacy';
export const PATH_TERMS = '/login/terms';
export const PATH_IMPRINT = '/login/imprint';
export const PATH_FAQ = '/login/faq';
export const PATH_DESCRIPTION = '/login/description';
export const PATH_REFERENCES = '/login/references';
export const PATH_DASHBOARD = '/dashboard';
export const PATH_CATEGORY_EDIT = '/dashboard/edit';
export const PATH_CREATE_CATEGORY = '/create-category';
export const PATH_CATEGORY_DETAIL = '/category/:cid/manufacturer/:id/products';
export const PATH_MANUFACTURERS_DETAIL = '/category/:cid/manufacturers';
export const PATH_LANDING = '/landing';
export const PATH_ABOUT_US = '/about-us';
export const PATH_PRODUCTS = '/products';
export const PATH_ADMINISTRATION = '/administration';
export const PATH_START = '/start';
export const PATH_SEARCH = '/search';
export const PATH_INQUIRY = '/inquiry';
export const PATH_PRODUCT_DETAIL = '/product/:id';
export const PATH_PRODUCT_BY_MANUFACTURER_NUMBER_DETAIL = '/productByManufacturerNumber/:mid';
export const PATH_PRODUCT_BY_MANUFACTURER_NAME_DETAIL = '/productByManufacturerName/:selected';
export const PATH_PRODUCT_BY_MODEL = '/productByModel/:mname';
export const PATH_PRODUCT_BY_DICHTUNGSELECT = '/productByDichtungSelect/:dichtungSelect';
export const PATH_PRODUCT_BY_COMERCIALSELECT = '/productBySectionDescriptionAndManufacturer/:section/:description/:manufacturerName';




