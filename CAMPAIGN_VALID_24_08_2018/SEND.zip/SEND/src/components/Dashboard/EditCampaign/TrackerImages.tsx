import * as React from 'react';
import './TrackerImages.css';

import { connect } from 'react-redux'
import { editAndGetCampaigns, getListedTrackers} from '../../../redux/actions/localCampaignsActions'
import { ITracker } from '../../../models/CampaignsModelHelper'
import { IRootState } from '../../../redux/index';
// import {Link} from "react-router-dom";

interface ICampaignInfosState {
    entry: string,
    tracker?: ITracker[],
     error?: any

}
interface ICampaignInfosProps {
    getAllTrackers: any,
    editCampaignData: any,
    tracker: any
}

class TrackerImages extends React.Component<ICampaignInfosProps, ICampaignInfosState> {

    constructor(props: ICampaignInfosProps) {
        super(props)
        this.state = {
            entry: ''
        }
    }

    public deleteTracker(event: React.MouseEvent<HTMLButtonElement>) {
        event.preventDefault()
        this.props.editCampaignData(Number(this.state.entry))
        // this.setState({campaignsData: realCampaignData.campaigns})
    }

    /* tslint:disable:no-string-literal */
   public handleAddress(event: React.ChangeEvent<HTMLInputElement>) {
        event.preventDefault()
        const entry1 = event.target.value
        if (entry1 !== 'hello') {
            this.setState({
                entry: entry1
            })
        }
    }
/* tslint:enable:no-string-literal */

    public handleKeyPress = (event: any) => {
        if (event.key === 'Enter') {
            console.log('do thing')
            console.log(this.state)
            this.deleteTracker(event)
        }
    }
    
    public render() {
        return (
            <div className="trackerBox">
            
                <div className="trackerLeft">
                    <div>
                    {
                  this.props.tracker.map((t: ITracker) =>
                  
                  <div key= {t.id}>
                    <img src= {t.url} />
                    <button className="bp3-button bp3-minimal"  onClick={ e => this.deleteTracker(e) }> <span className="bp3-icon-standard bp3-icon-trash" /> </button>
                  </div>
                  )
                    }
                </div>
                    <div>
                    <button className="bp3-button bp3-minimal" ><span className="bp3-icon-standard bp3-icon-add" /> </button>
                    </div>
                </div>
                <div className="trackerRight">
                 
                <div> <img src="http://bioneers.org/wp-content/uploads/2017/11/ext-200x300.jpg" /> </div>
                 
                   <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> </button>
                </div>
            </div>
        )
    }

    public componentDidMount() {
        this.props.getAllTrackers();
    }

    public componentWillReceiveProps(newProps: ICampaignInfosProps) {

        this.setState({
            ...newProps.tracker,
            // ...newProps.contents
        })
        console.log(this.state)
    }
    
}


const mapStateToProps = (state: IRootState) => {
    return {
        // ...state
        tracker: state.allTrackers.trackers,
        // contents: state.allTrackers.realCampaigns,
        // error: state.allTrackers.error
    }
}
const mapDispatchToProps = (dispatch:any) => {
    return {
        getAllTrackers: () => dispatch(getListedTrackers()),
        // getAllContents: () => dispatch(getListedContents()),
        editCampaignData: (entry: number) => dispatch(editAndGetCampaigns(entry))
        
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(TrackerImages)


