import * as React from 'react';

import { Route, Switch } from 'react-router';

import {PATH_ROOT, PATH_FORGOT_PASSWORD_REQUEST, PATH_FORGOT_PASSWORD_RESET, PATH_REGISTER} from './paths';

import LoginContainer from '../containers/PreAuthContainer/LoginContainer'
import ForgotPasswordContainer from '../containers/PreAuthContainer/ForgotPasswordContainer'
import ResetPasswordContainer from '../containers/PreAuthContainer/ResetPasswordContainer'
import RegisterContainer from '../containers/PreAuthContainer/RegisterContainer'

export default class PreLoginRouter extends React.Component {
    public render() {
      return (
        <React.Fragment>
          <Switch>
            <Route exact={true} path={PATH_ROOT} component={LoginContainer} />
            <Route exact={true} path={PATH_FORGOT_PASSWORD_REQUEST} component={ForgotPasswordContainer} />
            <Route exact={true} path={PATH_FORGOT_PASSWORD_RESET} component={ResetPasswordContainer} />
            <Route exact={true} path={PATH_REGISTER} component={RegisterContainer} />
          </Switch>
        </React.Fragment>
      );
    }
  }