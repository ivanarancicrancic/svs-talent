import { IRootState } from '..'

// export const getUserIsLoggedIn = (state: IRootState) => state.auth.token != null

export const getUserIsLoggedIn = (state: IRootState) => state.auth.token == null
