  import { getFromBackend } from '../../api/api'

const getCampaigns = () => {
    const teamURL = '/testCampaigns'
     return getFromBackend(teamURL)
}

const getRealCampaigns = () => {
    const teamURL = '/testCampaigns'
     return getFromBackend(teamURL)
}

export {
     getCampaigns,
     getRealCampaigns
}
