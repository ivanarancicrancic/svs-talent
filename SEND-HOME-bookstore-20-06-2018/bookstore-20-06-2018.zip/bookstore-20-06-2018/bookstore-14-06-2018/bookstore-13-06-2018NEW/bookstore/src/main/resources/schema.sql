
CREATE TABLE category
(
    id int NOT NULL AUTO_INCREMENT,
    description varchar(255),
     PRIMARY KEY (id)
);