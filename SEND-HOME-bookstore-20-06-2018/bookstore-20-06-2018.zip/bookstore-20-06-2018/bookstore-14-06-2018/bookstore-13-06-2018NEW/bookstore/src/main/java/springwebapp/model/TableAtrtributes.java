package springwebapp.model;


import javax.persistence.*;

public class TableAtrtributes {

    private String id;
    private String title;
    private String publisher;
    private String mainTitle;
    private String size;
    private String description;
    private String category;

    public TableAtrtributes(String id, String title, String publisher, String mainTitle, String size, String description, String category) {
        this.id = id;
        this.title = title;
        this.publisher = publisher;
        this.mainTitle= mainTitle;
        this.size = size;
        this.description = description;
        this.category = category;
    }


    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getMainTitle() {
        return mainTitle;
    }

    public void setMainTitle(String mainTitle) {
        this.mainTitle = mainTitle;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
