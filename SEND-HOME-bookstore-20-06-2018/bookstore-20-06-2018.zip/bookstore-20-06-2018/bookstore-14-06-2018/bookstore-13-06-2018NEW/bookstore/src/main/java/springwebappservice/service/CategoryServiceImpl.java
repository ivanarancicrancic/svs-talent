package springwebappservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.commands.CategoryCommand;
import springwebapp.converters.CategoryToCategoryCommand;
import springwebapp.model.Category;
import springwebapp.repository.CategoryRepository;

import java.util.HashSet;
import java.util.Set;

@Service
@Component
public class CategoryServiceImpl implements  CategoryService{

    @Autowired
    CategoryRepository categoryRepository;

    CategoryToCategoryCommand categoryToCategoryCommand;


    public CategoryServiceImpl(CategoryRepository categoryRepository, CategoryToCategoryCommand categoryToCategoryCommand) {
        this.categoryRepository = categoryRepository;
        this.categoryToCategoryCommand = categoryToCategoryCommand;
    }

    public Set<CategoryCommand> getAllCategories(){

        Iterable<Category> categoriesIterable = categoryRepository.findAll();
        Set<Category> categories = new HashSet<>();
        if(categoriesIterable != null){
            for(Category c: categoriesIterable)
            {
                categories.add(c);
            }
        }
        Set<CategoryCommand> categoryCommands = new HashSet<>();
        for(Category cc: categories)
        {
            categoryCommands.add(categoryToCategoryCommand.convert(cc));
            System.out.println("Finished converting!");
        }
        return categoryCommands;
    }
}
