package de.ersatzteil.ersatzteilhandel24api.model;

public class OrderArticles {

      String orderarticle_id;
      String orders_id;
      String articleName;
      String articleDescription;
      String articlePromotion;
      String articleQuantity;

      public OrderArticles(){}

      public OrderArticles(String orderarticle_id, String orders_id, String articleName, String articleDescription, String articlePromotion, String articleQuantity) {
        this.orderarticle_id = orderarticle_id;
        this.orders_id = orders_id;
        this.articleName = articleName;
        this.articleDescription = articleDescription;
        this.articlePromotion = articlePromotion;
        this.articleQuantity = articleQuantity;
    }

    public String getOrderarticle_id() {
        return orderarticle_id;
    }

    public void setOrderarticle_id(String orderarticle_id) {
        this.orderarticle_id = orderarticle_id;
    }

    public String getOrders_id() {
        return orders_id;
    }

    public void setOrders_id(String orders_id) {
        this.orders_id = orders_id;
    }

    public String getArticleName() {
        return articleName;
    }

    public void setArticleName(String articleName) {
        this.articleName = articleName;
    }

    public String getArticleDescription() {
        return articleDescription;
    }

    public void setArticleDescription(String articleDescription) {
        this.articleDescription = articleDescription;
    }

    public String getArticlePromotion() {
        return articlePromotion;
    }

    public void setArticlePromotion(String articlePromotion) {
        this.articlePromotion = articlePromotion;
    }

    public String getArticleQuantity() {
        return articleQuantity;
    }

    public void setArticleQuantity(String articleQuantity) {
        this.articleQuantity = articleQuantity;
    }
}
