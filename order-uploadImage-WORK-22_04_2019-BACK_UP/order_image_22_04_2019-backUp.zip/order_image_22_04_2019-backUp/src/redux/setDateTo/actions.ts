import {
    SET_DATE_TO_FETCH,
    SET_DATE_TO_SUCCESS,
    SET_DATE_TO_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setDateToFetch = createStandardAction(SET_DATE_TO_FETCH)<{newDateTo: Date}>();
export const setDateToSuccess = createStandardAction(SET_DATE_TO_SUCCESS)<Date>();
export const setDateToFail = createStandardAction(SET_DATE_TO_FAIL)<string>();

