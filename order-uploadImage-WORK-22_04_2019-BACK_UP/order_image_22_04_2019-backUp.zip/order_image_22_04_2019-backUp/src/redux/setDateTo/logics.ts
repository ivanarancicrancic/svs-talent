import { createLogic } from 'redux-logic';
import { SET_DATE_TO_FETCH } from './types';
import { setDateToFetch, setDateToSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const setDateToFetchLogic = createLogic({
    type: SET_DATE_TO_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setDateToFetch)(action)) {
            let result = new Date();
            result = new Date(action.payload.newDateTo);
            
            dispatch(setDateToSuccess(result));  
        } else {
            done();
        }
    }
});

export default [
    setDateToFetchLogic
];
