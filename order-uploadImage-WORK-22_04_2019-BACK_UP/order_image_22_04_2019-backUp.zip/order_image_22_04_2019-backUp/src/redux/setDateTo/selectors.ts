import { IRootState } from '..'

export const getDateTo = (state: IRootState) => state.dateTo.data;
export const getDateToLoading = (state: IRootState) => state.dateTo.loading;
export const getDateToHasError = (state: IRootState) => state.dateTo.error;