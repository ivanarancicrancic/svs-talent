export const SET_DATE_TO_FETCH = '@@user/set/dateTo/FETCH';
export const SET_DATE_TO_SUCCESS = '@@user/set/dateTo/SUCCESS';
export const SET_DATE_TO_FAIL = '@@user/set/dateTo/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}


