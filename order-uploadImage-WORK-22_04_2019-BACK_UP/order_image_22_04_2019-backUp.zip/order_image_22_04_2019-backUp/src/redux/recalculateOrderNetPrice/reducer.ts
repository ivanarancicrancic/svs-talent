import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type RecalculateOrderNetPriceActions = ActionType<typeof extActions>;

export interface IRecalculateOrderNetPriceState {
    readonly data: string;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IRecalculateOrderNetPriceState = {
    data: "0",
    loading: false,
    error: null
};
  
export function recalculateOrderNetPriceReducer(state: IRecalculateOrderNetPriceState = INITIAL_STATE, action: RecalculateOrderNetPriceActions): IRecalculateOrderNetPriceState  {
    switch (action.type) {
        case getType(extActions.recalculateOrderNetPriceFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.recalculateOrderNetPriceSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.recalculateOrderNetPriceFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}