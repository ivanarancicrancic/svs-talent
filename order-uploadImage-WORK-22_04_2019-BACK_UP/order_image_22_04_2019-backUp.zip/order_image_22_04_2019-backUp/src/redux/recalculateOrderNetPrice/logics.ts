import { createLogic } from 'redux-logic';
import { RECALCULATE_ORDER_NET_PRICE_FETCH } from './types';
import { recalculateOrderNetPriceFetch, recalculateOrderNetPriceSuccess } from './actions';
import { IRootState } from '../../redux';
import { isActionOf } from 'typesafe-actions';

export const recalculateOrderNetPriceFetchLogic = createLogic({
    type: RECALCULATE_ORDER_NET_PRICE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if((getState() as IRootState).orderDetail.data){
            const orderDetail = (getState() as IRootState).orderDetail.data;
            if(action.payload.flagStart === true){
                if(orderDetail){
                const result = orderDetail.netPrice;
                 const result1 = result.toString();
                dispatch(recalculateOrderNetPriceSuccess(result1));    
                }
            }
            else{
                const ordereNetPrice = (getState() as IRootState).orderDetail.data;
                if(ordereNetPrice){
                    let finNetPrice =  parseInt(ordereNetPrice.netPrice,10);
                    if (isActionOf(recalculateOrderNetPriceFetch)(action)) {
                    const listNetPrices = (getState() as IRootState).listNetPrices.data;
                    const listQuantities = (getState() as IRootState).listQuantities.data;
                    if((getState() as IRootState).orderDetail.data){ 
                        const listOderArticles = (getState() as IRootState).orderArticles.data;
                        if(listOderArticles){ 
                            listOderArticles.map( (orAr, index)=> {   
                                if((parseInt(listQuantities[index],10) > 0) && (parseInt(listNetPrices[index],10) > 0)){        
                                finNetPrice = finNetPrice - parseInt(orAr.articleNetPrice,10) * parseInt(orAr.articleQuantity,10); 
                                finNetPrice = finNetPrice + parseInt(listNetPrices[index],10) * parseInt(listQuantities[index],10);
                                }
                            });
                        }
                    }
                    const result = finNetPrice.toString();
                    dispatch(recalculateOrderNetPriceSuccess(result));  
                    } else {
                        done();
                    }
                }
            }
        }
    }
});

export default [
    recalculateOrderNetPriceFetchLogic
];
