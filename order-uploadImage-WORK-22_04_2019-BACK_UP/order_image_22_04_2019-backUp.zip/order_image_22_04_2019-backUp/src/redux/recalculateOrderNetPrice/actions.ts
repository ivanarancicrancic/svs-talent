import {
    RECALCULATE_ORDER_NET_PRICE_FETCH,
    RECALCULATE_ORDER_NET_PRICE_SUCCESS,
    RECALCULATE_ORDER_NET_PRICE_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const recalculateOrderNetPriceFetch = createStandardAction(RECALCULATE_ORDER_NET_PRICE_FETCH)<{flagStart: boolean}>();
export const recalculateOrderNetPriceSuccess = createStandardAction(RECALCULATE_ORDER_NET_PRICE_SUCCESS)<string>();
export const recalculateOrderNetPriceFail = createStandardAction(RECALCULATE_ORDER_NET_PRICE_FAIL)<string>();

