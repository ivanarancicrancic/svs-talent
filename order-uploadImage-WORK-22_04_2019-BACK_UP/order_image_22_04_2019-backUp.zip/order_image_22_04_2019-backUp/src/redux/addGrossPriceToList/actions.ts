import {
    ADD_GROSS_PRICE_TO_LIST_FETCH,
    ADD_GROSS_PRICE_TO_LIST_SUCCESS,
    ADD_GROSS_PRICE_TO_LIST_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const addGrossPriceToListFetch = createStandardAction(ADD_GROSS_PRICE_TO_LIST_FETCH)<{newGrossPriceValue:string, indexList:number, pushFlag: boolean}>();
export const addGrossPriceToListSuccess = createStandardAction(ADD_GROSS_PRICE_TO_LIST_SUCCESS)<string[]>();
export const addGrossPriceToListFail = createStandardAction(ADD_GROSS_PRICE_TO_LIST_FAIL)<string>();

