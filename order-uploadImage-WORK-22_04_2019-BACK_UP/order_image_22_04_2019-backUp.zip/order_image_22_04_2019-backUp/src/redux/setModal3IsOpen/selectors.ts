import { IRootState } from '..'

export const getModal3IsOpen = (state: IRootState) => state.modal3IsOpen.data;
export const getModal3IsOpenLoading = (state: IRootState) => state.modal3IsOpen.loading;
export const getModal3IsOpenHasError = (state: IRootState) => state.modal3IsOpen.error;