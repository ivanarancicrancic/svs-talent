export const SET_MODAL3_IS_OPEN_FETCH = '@@user/set/modal3IsOpen/FETCH';
export const SET_MODAL3_IS_OPEN_SUCCESS = '@@user/set/modal3IsOpen/SUCCESS';
export const SET_MODAL3_IS_OPEN_FAIL = '@@user/set/modal3IsOpen/FAIL';

