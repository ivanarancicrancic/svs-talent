export const RECALCULATE_TOTAL_PRICES_FETCH = '@@user/recalculate/totalPrices/FETCH';
export const RECALCULATE_TOTAL_PRICES_SUCCESS = '@@user/recalculate/totalPrices/SUCCESS';
export const RECALCULATE_TOTAL_PRICES_FAIL = '@@user/recalculate/totalPrices/FAIL';


export interface ITotalPrices {
    netPrice: number;
    grossPrice: number;
    netPriceWD: number;
    grossPriceWD: number;

}