import { createLogic } from 'redux-logic';
import { FILTER_ORDER_FETCH, IFilterOrderResponseModel } from './types';
import { filterOrderFetch, filterOrderSuccess, filterOrderFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const filterOrderFetchLogic = createLogic({
    type: FILTER_ORDER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(filterOrderFetch)(action)) {  
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/Orders', {
                method: 'POST',
                body: JSON.stringify({
                startDate:  action.payload.startDate.toISOString(),
                endDate:   action.payload.endDate.toISOString()
                })
            })
            .then((response) => response.json())
            .then((responseJson) => {
                dispatch(filterOrderSuccess(responseJson as IFilterOrderResponseModel[]));
            })
            .catch((error) => {
                dispatch(filterOrderFail("fail"))
            });
        } 
        else {
            done();
        }
    }
});

export default [
    filterOrderFetchLogic
];
