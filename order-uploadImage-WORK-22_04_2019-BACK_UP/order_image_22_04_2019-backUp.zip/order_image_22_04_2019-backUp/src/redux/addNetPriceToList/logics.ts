import { createLogic } from 'redux-logic';
import { ADD_NET_PRICE_TO_LIST_FETCH } from './types';
import { addNetPriceToListFetch, addNetPriceToListSuccess } from './actions';
import { IRootState } from '../../redux';
import { isActionOf } from 'typesafe-actions';

export const addNetPriceToListFetchLogic = createLogic({
    type: ADD_NET_PRICE_TO_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(addNetPriceToListFetch)(action)) {
            let result = (getState() as IRootState).listNetPrices.data;   
            if(action.payload.indexList === -1){
                result = [];
                dispatch(addNetPriceToListSuccess(result));
            }
            else{
                if(action.payload.pushFlag === true){ 
                    result.push(action.payload.newNetPriceValue);  
                    dispatch(addNetPriceToListSuccess(result));       
                }
                else{
                    if(result){
                        result.splice(action.payload.indexList, 1, action.payload.newNetPriceValue);
                    } 
                    dispatch(addNetPriceToListSuccess(result));
                }              
            }                
        } 
        else {
            done();
        }
    } 
});

export default [
    addNetPriceToListFetchLogic
];
