import {
    ADD_NET_PRICE_TO_LIST_FETCH,
    ADD_NET_PRICE_TO_LIST_SUCCESS,
    ADD_NET_PRICE_TO_LIST_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const addNetPriceToListFetch = createStandardAction(ADD_NET_PRICE_TO_LIST_FETCH)<{newNetPriceValue:string, indexList:number, pushFlag: boolean}>();
export const addNetPriceToListSuccess = createStandardAction(ADD_NET_PRICE_TO_LIST_SUCCESS)<string[]>();
export const addNetPriceToListFail = createStandardAction(ADD_NET_PRICE_TO_LIST_FAIL)<string>();

