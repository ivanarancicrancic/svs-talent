import { ActionType, getType } from 'typesafe-actions';
import { IOrderArticleResponseModel } from './types';

import * as actions from './actions';

const extActions = {...actions};

export type GetOrderArtictlesActions = ActionType<typeof extActions>;

export interface IOrderArticlesState {
    readonly data: IOrderArticleResponseModel[];
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IOrderArticlesState = {
    data: [],
    loading: false,
    error: null
};
  
export function getOrderArticlesReducer(state: IOrderArticlesState = INITIAL_STATE, action: GetOrderArtictlesActions): IOrderArticlesState  {
    switch (action.type) {
        case getType(extActions.getOrderArticlesFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.getOrderArticlesSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.getOrderArticlesFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}