export const ADD_QUANTITY_TO_LIST_FETCH = '@@user/add/quantity/toList/FETCH';
export const ADD_QUANTITY_TO_LIST_SUCCESS = '@@user/add/quantity/toList/SUCCESS';
export const ADD_QUANTITY_TO_LIST_FAIL = '@@user/add/quantity/toList/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}
