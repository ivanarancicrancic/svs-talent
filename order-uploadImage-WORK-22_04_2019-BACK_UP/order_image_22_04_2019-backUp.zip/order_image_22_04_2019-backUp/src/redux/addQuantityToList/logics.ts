import { createLogic } from 'redux-logic';
import { ADD_QUANTITY_TO_LIST_FETCH } from './types';
import { addQuantityToListFetch, addQuantityToListSuccess } from './actions';
import { IRootState } from '../../redux';
import { isActionOf } from 'typesafe-actions';

export const addQuantityToListFetchLogic = createLogic({
    type: ADD_QUANTITY_TO_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(addQuantityToListFetch)(action)) {
            let result = (getState() as IRootState).listQuantities.data;
            if(action.payload.indexList === -1){
                result = [];
                dispatch(addQuantityToListSuccess(result));
            }
            else{
                if(action.payload.pushFlag === true){
                    result.push(action.payload.newQuantityValue);  
                    dispatch(addQuantityToListSuccess(result));   
                }
                else{
                    if(result){
                        result.splice(action.payload.indexList, 1, action.payload.newQuantityValue);
                    }
                    dispatch(addQuantityToListSuccess(result));
                }
            }     
        } 
        else {
            done();
        }
    }
});

export default [
    addQuantityToListFetchLogic
];
