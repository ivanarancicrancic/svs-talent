import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type AddQuantityToListActions = ActionType<typeof extActions>;

export interface IAddQuantityToListState {
    readonly data: string[];
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IAddQuantityToListState = {
    data: [],
    loading: false,
    error: null
};
  
export function addQuantityToListReducer(state: IAddQuantityToListState = INITIAL_STATE, action: AddQuantityToListActions): IAddQuantityToListState  {
    switch (action.type) {
        case getType(extActions.addQuantityToListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.addQuantityToListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.addQuantityToListFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}