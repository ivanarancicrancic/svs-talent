import { IRootState } from '..'

export const getQuantityList = (state: IRootState) => state.listQuantities.data;
export const getQuantityListyLoading = (state: IRootState) => state.listQuantities.loading;
export const getQuantityListHasError = (state: IRootState) => state.listQuantities.error;