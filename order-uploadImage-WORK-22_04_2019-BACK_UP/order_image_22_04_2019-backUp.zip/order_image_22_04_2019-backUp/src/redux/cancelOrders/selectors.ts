import { IRootState } from '..'

export const getCanceledOrder = (state: IRootState) => state.canceledOrder.data;
export const getCanceledOrderLoading = (state: IRootState) => state.canceledOrder.loading;
export const getCanceledOrderHasError = (state: IRootState) => state.canceledOrder.error;