import { IRootState } from '..'

export const getRecalculatedOrderGrossPrice = (state: IRootState) => state.recalculatedOrderGrossPrice.data;
export const getRecalculatedOrderGrossPriceLoading = (state: IRootState) => state.recalculatedOrderGrossPrice.loading;
export const getRecalculatedOrderGrossPriceHasError = (state: IRootState) => state.recalculatedOrderGrossPrice.error;