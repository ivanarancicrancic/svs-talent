import {
    SET_CURRENT_INDEX_FETCH,
    SET_CURRENT_INDEX_SUCCESS,
    SET_CURRENT_INDEX_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setCurrentIndexFetch = createStandardAction(SET_CURRENT_INDEX_FETCH)<{newIndex: number}>();
export const setCurrentIndexSuccess = createStandardAction(SET_CURRENT_INDEX_SUCCESS)<number>();
export const setCurrentIndexFail = createStandardAction(SET_CURRENT_INDEX_FAIL)<string>();

