import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type SetCurrentIndexActions = ActionType<typeof extActions>;

export interface ISetCurrentIndexState {
    readonly data: number;
    readonly loading: boolean;
    readonly error: string | null;
};
  

const INITIAL_STATE: ISetCurrentIndexState = {
    data: 0,
    loading: false,
    error: null
};
  
export function setCurrentIndexReducer(state: ISetCurrentIndexState = INITIAL_STATE, action: SetCurrentIndexActions): ISetCurrentIndexState  {
    switch (action.type) {
        case getType(extActions.setCurrentIndexFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setCurrentIndexSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setCurrentIndexFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}