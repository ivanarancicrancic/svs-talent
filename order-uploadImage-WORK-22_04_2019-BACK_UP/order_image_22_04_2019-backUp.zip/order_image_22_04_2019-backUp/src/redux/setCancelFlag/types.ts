export const SET_CANCEL_FLAG_FETCH = '@@user/set/cancelFlag/FETCH';
export const SET_CANCEL_FLAG_SUCCESS = '@@user/set/cancelFlag/SUCCESS';
export const SET_CANCEL_FLAG_FAIL = '@@user/set/cancelFlag/FAIL';

