import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type SetCancelFlagActions = ActionType<typeof extActions>;

export interface ISetCancelFlagState {
    readonly data: boolean;
    readonly loading: boolean;
    readonly error: string | null;
};
  

const INITIAL_STATE: ISetCancelFlagState = {
    data: false,
    loading: false,
    error: null
};
  
export function setCancelFlagReducer(state: ISetCancelFlagState = INITIAL_STATE, action: SetCancelFlagActions): ISetCancelFlagState  {
    switch (action.type) {
        case getType(extActions.setCancelFlagFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setCancelFlagSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setCancelFlagFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}