import {
    ADD_IMAGE_URL_TO_LIST_FETCH,
    ADD_IMAGE_URL_TO_LIST_SUCCESS,
    ADD_IMAGE_URL_TO_LIST_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const addImageUrlToListFetch = createStandardAction(ADD_IMAGE_URL_TO_LIST_FETCH)<{newImageUrl:string, indexList:number, pushFlag: boolean}>();
export const addImageUrlToListSuccess = createStandardAction(ADD_IMAGE_URL_TO_LIST_SUCCESS)<string[]>();
export const addImageUrlToListFail = createStandardAction(ADD_IMAGE_URL_TO_LIST_FAIL)<string>();

