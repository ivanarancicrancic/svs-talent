import { IRootState } from '..'

export const getImageUrlList = (state: IRootState) => state.orderArticleImages.data;
export const getImageUrlListLoading = (state: IRootState) => state.orderArticleImages.loading;
export const getImageUrlListHasError = (state: IRootState) => state.orderArticleImages.error;