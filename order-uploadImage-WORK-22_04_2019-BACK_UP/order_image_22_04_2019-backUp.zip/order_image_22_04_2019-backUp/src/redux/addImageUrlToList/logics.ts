import { createLogic } from 'redux-logic';
import { ADD_IMAGE_URL_TO_LIST_FETCH } from './types';
import {  addImageUrlToListFetch, addImageUrlToListSuccess } from './actions';
import { IRootState } from '../../redux';
import { isActionOf } from 'typesafe-actions';

export const addImageUrlToListFetchLogic = createLogic({
    type: ADD_IMAGE_URL_TO_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(addImageUrlToListFetch)(action)) {
            let result = (getState() as IRootState).listGrossPrices.data;
            if(action.payload.indexList === -1){
                result = [];
                dispatch(addImageUrlToListSuccess(result));
            }
            else{
                if(action.payload.pushFlag === true){ 
                    result.push(action.payload.newImageUrl);  
                    dispatch(addImageUrlToListSuccess(result));       
                }
                else{
                    if(result){
                        result.splice(action.payload.indexList, 1, action.payload.newImageUrl);
                    }
                    dispatch(addImageUrlToListSuccess(result));   
                }    
            }         
        } 
        else{
            done();
        }
    }
});

export default [
    addImageUrlToListFetchLogic
];
