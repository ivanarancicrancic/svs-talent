import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type AddImageUrlToListActions = ActionType<typeof extActions>;

export interface IAddImageUrlToListState {
    readonly data: string[];
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IAddImageUrlToListState = {
    data: [],
    loading: false,
    error: null
};
  
export function addImageUrlToListReducer(state: IAddImageUrlToListState = INITIAL_STATE, action: AddImageUrlToListActions): IAddImageUrlToListState  {
    switch (action.type) {
        case getType(extActions.addImageUrlToListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.addImageUrlToListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.addImageUrlToListFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}