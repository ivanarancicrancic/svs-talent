export const ADD_IMAGE_URL_TO_LIST_FETCH = '@@user/add/imageUrl/toList/FETCH';
export const ADD_IMAGE_URL_TO_LIST_SUCCESS = '@@user/add/imageUrl/toList/SUCCESS';
export const ADD_IMAGE_URL_TO_LIST_FAIL = '@@user/add/imageUrl/toList/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;
}
