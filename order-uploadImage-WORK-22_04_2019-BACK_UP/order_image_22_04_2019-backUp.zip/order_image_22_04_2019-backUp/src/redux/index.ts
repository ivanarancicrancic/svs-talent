import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { IOrderListState, OrderListActions, orderListReducer } from './order-list/reducer';
import { IFilteredOrderState, FilterOrderActions, filterOrderReducer } from './filterOrders/reducer';
import { IOrderDetailState, OrderDetailActions, orderDetailReducer } from './order-detail/reducer';
import { IOrderArticlesState, GetOrderArtictlesActions, getOrderArticlesReducer } from './order-articles/reducer';
import { IOrderSaveState, OrderSaveActions, orderSaveReducer } from './order-save/reducer';
import { orderCancelReducer, OrderCancelActions } from './cancelOrders/reducer';
import { IDeleteArticleFromOrderState, DeleteArticleFromOrderActions, deleteArticleFromOrderReducer } from './delete-article/reducer';
import { formsReducer } from './forms';
import { addQuantityToListReducer, AddQuantityToListActions, IAddQuantityToListState } from './addQuantityToList/reducer';
import { ISetCurrentIndexState, setCurrentIndexReducer, SetCurrentIndexActions } from './setCurrentIndex/reducer';
import { IAddNetPriceToListState, AddNetPriceToListActions, addNetPriceToListReducer } from './addNetPriceToList/reducer';
import { IAddGrossPriceToListState, AddGrossPriceToListActions, addGrosstPriceToListReducer } from './addGrossPriceToList/reducer';
import { ISetModal3IsOpenState, SetModal3IsOpenActions, setModal3IsOpenReducer } from './setModal3IsOpen/reducer';
import { IRecalculateOrderNetPriceState, RecalculateOrderNetPriceActions, recalculateOrderNetPriceReducer } from './recalculateOrderNetPrice/reducer';
import { IRecalculateOrderGrossPriceState, RecalculateOrderGrossPriceActions, recalculateOrderGrossPriceReducer } from './recalculateOrderGrossPrice/reducer';
import { ISetDateFromState, setDateFromReducer, SetDateFromStateActions } from './setDateFrom/reducer';
import { ISetDateToState, SetDateToStateActions, setDateToReducer } from './setDateTo/reducer';
import { setCancelFlagReducer, SetCancelFlagActions, ISetCancelFlagState } from './setCancelFlag/reducer';
import { IRecalculateTotalPricesState, RecalculateTotalPricesActions, recalculateTotalPricesReducer } from './recalculateTotalPrices/reducer';
import { IRecalculateFilteredTotalPricesState, RecalculateFilteredTotalPricesActions, recalculateFilteredTotalPricesReducer } from './recalculateFilteredOrdersTotalPrices/reducer';
import { IImageUploadState, ImageUploadActions, imageUploadReducer } from './imageUpload/reducer';
import { IPictureUrlState, SetPictureUrlActions, setPictureUrlFetchReducer } from './setPictureUrl/reducer';
import { IAddImageUrlToListState, AddImageUrlToListActions, addImageUrlToListReducer } from './addImageUrlToList/reducer';

export interface IRootState {
    router: RouterState;
    orderList: IOrderListState;
    filteredOrders: IFilteredOrderState;
    orderDetail: IOrderDetailState;
    savedOrder: IOrderSaveState;
    orderArticles: IOrderArticlesState;
    canceledOrder: IOrderDetailState;  
    forms: any;
    orderWithDeletedArticle: IDeleteArticleFromOrderState;
    listQuantities: IAddQuantityToListState;
    currentIndex: ISetCurrentIndexState;
    listNetPrices: IAddNetPriceToListState;
    listGrossPrices: IAddGrossPriceToListState;
    modal3IsOpen: ISetModal3IsOpenState;
    recalculatedOrderNetPrice: IRecalculateOrderNetPriceState;
    recalculatedOrderGrossPrice: IRecalculateOrderGrossPriceState;
    dateFrom: ISetDateFromState;
    dateTo: ISetDateToState;
    cancelFlag: ISetCancelFlagState;
    recalculatedTotalPrices: IRecalculateTotalPricesState;
    recalculatedFilteredTotalPrices: IRecalculateFilteredTotalPricesState;
    uploadImage: IImageUploadState;
    pictureUrl: IPictureUrlState;
    orderArticleImages: IAddImageUrlToListState;
}

export type RootAction = RouterAction
    | LocationChangeAction
    | OrderListActions
    | FilterOrderActions 
    | OrderDetailActions
    | GetOrderArtictlesActions
    | OrderSaveActions
    | OrderCancelActions
    | DeleteArticleFromOrderActions
    | AddQuantityToListActions
    | SetCurrentIndexActions
    | AddNetPriceToListActions
    | AddGrossPriceToListActions
    | SetModal3IsOpenActions
    | RecalculateOrderNetPriceActions
    | RecalculateOrderGrossPriceActions
    | SetDateFromStateActions
    | SetDateToStateActions
    | SetCancelFlagActions
    | RecalculateTotalPricesActions
    | RecalculateFilteredTotalPricesActions
    | ImageUploadActions
    | SetPictureUrlActions
    | AddImageUrlToListActions

export const reducers = combineReducers<IRootState>({
    router: routerReducer, 
    orderList: orderListReducer,
    filteredOrders: filterOrderReducer,
    orderDetail: orderDetailReducer,
    savedOrder: orderSaveReducer,
    orderArticles: getOrderArticlesReducer,
    canceledOrder: orderCancelReducer,
    forms: formsReducer,
    orderWithDeletedArticle: deleteArticleFromOrderReducer,
    listQuantities: addQuantityToListReducer,
    currentIndex: setCurrentIndexReducer,
    listNetPrices: addNetPriceToListReducer,
    listGrossPrices: addGrosstPriceToListReducer,
    modal3IsOpen: setModal3IsOpenReducer,
    recalculatedOrderNetPrice: recalculateOrderNetPriceReducer,
    recalculatedOrderGrossPrice: recalculateOrderGrossPriceReducer,
    dateFrom: setDateFromReducer,
    dateTo: setDateToReducer,
    cancelFlag: setCancelFlagReducer,
    recalculatedTotalPrices: recalculateTotalPricesReducer,
    recalculatedFilteredTotalPrices: recalculateFilteredTotalPricesReducer,
    uploadImage: imageUploadReducer,
    pictureUrl: setPictureUrlFetchReducer,
    orderArticleImages: addImageUrlToListReducer
});