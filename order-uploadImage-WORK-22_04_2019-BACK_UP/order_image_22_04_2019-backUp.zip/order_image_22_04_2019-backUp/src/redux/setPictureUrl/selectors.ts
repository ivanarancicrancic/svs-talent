import { IRootState } from '..'

export const getSetPictureUrl = (state: IRootState) => state.pictureUrl.data;
export const getSetPictureUrlLoading = (state: IRootState) => state.pictureUrl.loading;
export const getSetPictureUrlHasError = (state: IRootState) => state.pictureUrl.error;