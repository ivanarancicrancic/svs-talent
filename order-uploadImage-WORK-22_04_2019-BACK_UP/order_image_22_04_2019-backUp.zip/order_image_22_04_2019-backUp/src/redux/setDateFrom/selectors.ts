import { IRootState } from '..'

export const getDateFrom = (state: IRootState) => state.dateFrom.data;
export const getDateFromLoading = (state: IRootState) => state.dateFrom.loading;
export const getDateFromHasError = (state: IRootState) => state.dateFrom.error;