import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './ManageOrderLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
// import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { RouteComponentProps } from 'react-router';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null;   
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

class ManageOrder extends React.Component<IProps>{
    constructor(props: any) {
        super(props);
        this.editOrder = this.editOrder.bind(this);
    }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({orderId});
    }

    public editOrder(orderid:any){   
    const orderId = orderid;
    history.push(`/order/edit/${orderId}`);      
    }

    public render() {  
        if(this.props.orderDetailData){
            const orderid= this.props.orderDetailData.order_id;
            if(this.props.orderArticlesData){       
                return (
                    <div className="grid100">
                        <form>
                            <div style={{textAlign: 'left', fontSize: 25, color: "#333"}}>ORDER DETAILS</div>
                            <div className="editableLabels"><label> <b>First name: </b></label> {this.props.orderDetailData.firstName}  </div>
                            <div className="editableLabels"> <label ><b> Last name: </b> </label> {this.props.orderDetailData.lastName} </div>
                            <div className="editableLabels"> <label > <b>Company: </b>  </label> {this.props.orderDetailData.companyName} </div>
                            <div className="editableLabels"><label > <b>Paying method: </b> </label > {this.props.orderDetailData.paymentMethod} </div>
                            <div className="editableLabels"><label ><b>e-mail: </b> </label> {this.props.orderDetailData.email}    </div>
                            <div className="editableLabels"> <label> <b>Order date: </b> </label> {this.props.orderDetailData.orderDate}  </div>
                            <div className="editableLabels"> <label > <b>Phone number: </b> </label > {this.props.orderDetailData.phoneNumber} </div>
                            <div className="editableLabels"> <label> <b>Shipping way: </b> </label > {this.props.orderDetailData.shippingWay}  </div>
                            <div className="editableLabels"><label > <b>Street: </b> </label> {this.props.orderDetailData.street} </div>
                            <div className="editableLabels"><label > <b> House number: </b> </label > {this.props.orderDetailData.houseNumber} </div>
                            <div className="editableLabels"> <label ><b>Postcode: </b> </label> {this.props.orderDetailData.postcode} </div>
                            <div className="editableLabels"> <label ><b>City: </b> </label> {this.props.orderDetailData.city} </div>
                            <div className="editableLabels"><label > <b>Country: </b> </label> {this.props.orderDetailData.country} </div>
                            <div className="editableLabels" ><label> <b>Net price: </b> </label> {this.props.orderDetailData.netPrice}</div>
                            <div className="editableLabels"><label> <b>Gross price: </b> </label> {this.props.orderDetailData.grossPrice}</div>
                            <div className="editableLabels" ><label> <b>Difference: </b> </label> {parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</div>
                            <div className="editableLabels"><label> <b>Net price(without delivery): </b> </label> {this.props.orderDetailData.netPriceWD}</div>
                            <div className="editableLabels" > <label><b>Gross price(without delivery): </b></label> {this.props.orderDetailData.grossPriceWD}</div>
                            <div className="editableLabels"><label><b>Difference(without delivery):</b></label> {parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.grossPriceWD,10)}</div> 
                            <div className = "modalTText" style={{position: "absolute", right: 45, top: 710 }}>
                                <button className="bp3-button" style={{backgroundColor : "#E8BF1E"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
                            </div>
                        </form>
                        {this.props.orderArticlesData.map( (orderArticle, index) => {
                               const imageUrl = orderArticle.articlePictureUrl;
                            return (
                                <div key={orderArticle.orArId}>
                                    {/* <tr><img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130,position: "absolute", right: 160, top: 154 }} /> </tr> */}
                                    <tr> <img className="bp3-button imgl" src= {imageUrl}  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 590, right: 160, top: 165 + index * 185}} /> </tr>
                                    <br/>
                                    <hr className="style13" style={{position: "absolute", left: 590, right: 50, top: 325 + index * 185}}/>     
                                    <tr> <div style={{position: "absolute", left: 748, top: 160 + index * 185}}> <b> ARTICLE:  </b> {orderArticle.articleName}</div></tr>
                                    <tr> <div style={{position: "absolute", left: 748, top: 195 + index * 185}}>  <b> Net price:  </b>  {orderArticle.articleNetPrice} </div></tr>
                                    <tr> <div style={{position: "absolute", left: 748, top: 215 + index * 185}}> <b> Gross price:  </b> {orderArticle.articleGrossPrice} </div></tr>
                                    <tr><div style={{position: "absolute", left: 748, top: 235 + index * 185}}>  <b> Net price WD:  </b> {orderArticle.articleNetPriceWD} </div></tr>
                                    <tr><div style={{position: "absolute", left: 748, top: 255 + index * 185 }} > <b> Gross price WD:  </b> {orderArticle.articleGrossPriceWD} </div></tr>
                                    <tr> <div style={{position: "absolute", left: 748, top: 275 + index * 185}}>  <b> QUANTITY:  </b> {orderArticle.articleQuantity} </div></tr>
                                </div>          
                            )
                        })}
                    </div>
                )
            }
            else{
                return (
                    <div className="grid100">
                        <div className="ordersTable">
                            <div> Order details </div>
                            <div className="editableLabels"><label> <b>First name: </b></label> {this.props.orderDetailData.firstName}  </div>
                            <div className="editableLabels"> <label ><b> Last name: </b> </label> {this.props.orderDetailData.lastName} </div>
                            <div className="editableLabels"> <label > <b>Company: </b>  </label> {this.props.orderDetailData.companyName} </div>
                            <div className="editableLabels"><label > <b>Paying method: </b> </label > {this.props.orderDetailData.paymentMethod} </div>
                            <div className="editableLabels"><label ><b>e-mail: </b> </label> {this.props.orderDetailData.email}    </div>
                            <div className="editableLabels"> <label> <b>Order date: </b> </label> {this.props.orderDetailData.orderDate}  </div>
                            <div className="editableLabels"> <label > <b>Phone number: </b> </label > {this.props.orderDetailData.phoneNumber} </div>
                            <div className="editableLabels"> <label> <b>Shipping way: </b> </label > {this.props.orderDetailData.shippingWay}  </div>
                            <div className="editableLabels"><label > <b>Street: </b> </label> {this.props.orderDetailData.street} </div>
                            <div className="editableLabels"><label > <b> House number: </b> </label > {this.props.orderDetailData.houseNumber} </div>
                            <div className="editableLabels"> <label ><b>Postcode: </b> </label> {this.props.orderDetailData.postcode} </div>
                            <div className="editableLabels"> <label ><b>City: </b> </label> {this.props.orderDetailData.city} </div>
                            <div className="editableLabels"><label > <b>Country: </b> </label> {this.props.orderDetailData.country} </div>
                            <div className="editableLabels" ><label> <b>Net price: </b> </label> {this.props.orderDetailData.netPrice}</div>
                            <div className="editableLabels"><label> <b>Gross price: </b> </label> {this.props.orderDetailData.grossPrice}</div>
                            <div className="orderDetails"> <label> Difference: </label> <p>{parseInt(this.props.orderDetailData.grossPrice,10) - parseInt(this.props.orderDetailData.netPrice,10)}</p></div>
                            <div className="orderDetails"> <label> Net price(without delivery): </label> <p>{this.props.orderDetailData.netPriceWD}</p></div>
                            <div className="orderDetails"> <label> Gross price(without delivery): </label> <p>{this.props.orderDetailData.grossPriceWD}</p></div>
                            <div className="orderDetails"> <label> Difference(without delivery): </label> <p>{parseInt(this.props.orderDetailData.netPriceWD,10) - parseInt(this.props.orderDetailData.netPriceWD,10)}</p></div> 
                            <div className = "modalTText" >
                                <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit order </button>
                            </div>
                            <div  style={{ position: "absolute", left: 748, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
                        </div>
                    </div>
                )
            }
        }
        else {
            return null;
        }
    }
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch})(ManageOrder)