import * as React from 'react';
import {Link } from "react-router-dom";
import {PATH_START} from "../../router/paths";

import './Header';
import logo from '../../assets/images/logo01.png';



export default class PostAuthHeader extends React.Component {

    public render() {
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_START} className="bp3-navbar-heading"> <img src= { logo }  /> </Link>
                            </span>                  
                        </div>         
                        </div>
                </nav>
            </div>
        )
    }

   
}
