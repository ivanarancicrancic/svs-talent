import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './FilteredOrders.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { IOrderCancelRequestModel } from '../../redux/cancelOrders/types';
import { Form, Control } from 'react-redux-form';
import * as Modal from 'react-modal';
import { IFilterOrderResponseModel } from '../../redux/filterOrders/types';
import { RouteComponentProps } from '../../../node_modules/@types/react-router';
import { setDateFromFetch } from 'src/redux/setDateFrom/actions';
import { setDateToFetch } from 'src/redux/setDateTo/actions';
import { setModal3IsOpenFetch } from 'src/redux/setModal3IsOpen/actions';
import { setCancelFlagFetch } from 'src/redux/setCancelFlag/actions';
import { recalculateTotalPricesFetch } from 'src/redux/recalculateTotalPrices/actions';
import { ITotalPrices } from 'src/redux/recalculateTotalPrices/types';
import { getCancelFlag } from 'src/redux/setCancelFlag/selectors';
import { getDateFrom } from '../../redux/setDateFrom/selectors';
import { getDateTo } from '../../redux/setDateTo/selectors';
import { getModal3IsOpen } from '../../redux/setModal3IsOpen/selectors';
import { getRecalculatedTotalPrices } from '../../redux/recalculateTotalPrices/selectors';
import { recalculateFilteredTotalPricesFetch } from '../../redux/recalculateFilteredOrdersTotalPrices/actions';
import { getRecalculatedFIlteredTotalPrices, getRecalculatedFilteredTotalPricesLoading } from '../../redux/recalculateFilteredOrdersTotalPrices/selectors';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
    setDateFromFetch: typeof setDateFromFetch;
    setDateToFetch: typeof setDateToFetch;
    setModal3IsOpenFetch: typeof setModal3IsOpenFetch;
    setCancelFlagFetch: typeof setCancelFlagFetch;
    recalculateTotalPricesFetch: typeof recalculateTotalPricesFetch;
    recalculateFilteredTotalPricesFetch: typeof recalculateFilteredTotalPricesFetch;
}

interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IFilterOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    getDateFromData: Date;
    getDateToData: Date;
    setModal3IsOpenData: boolean;
    setCancelFlagData: boolean;
    recalculateTotalPricesData: ITotalPrices;
    recalculateFilteredTotalPricesData: ITotalPrices; 
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{startDateStr: Date, endDateStr: Date }>

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(132, 132, 132, 0.88)',
      width: '100%'
    }
};

class FilteredOrders extends React.Component<IProps> {
    constructor(props: any) {
        super(props);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        this.handleCancelOrder = this.handleCancelOrder.bind(this);
        this.handleSubmitCancelOrderWithReason = this.handleSubmitCancelOrderWithReason.bind(this);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    public componentWillMount () {
        let date1 = new Date();
        let date2 = new Date();
        date1 = new Date(this.props.getDateFromData);
        date2 = new Date(this.props.getDateToData); 
        this.props.setDateFromFetch({newDateFrom: date1});
        this.props.setDateToFetch({newDateTo: date2});
        this.props.setModal3IsOpenFetch({modal3IsOpen: false});
        this.props.setCancelFlagFetch({cancelFlag: false});    
        this.props.recalculateFilteredTotalPricesFetch();
        this.props.filterOrderFetch({startDate: date1, endDate: date2});
    }
    
    public componentWillReceiveProps(nextProps: IProps) { 
        if(this.props.orderDetailData && this.props.orderDetailData !== nextProps.orderDetailData && nextProps.orderDetailData && this.props.setCancelFlagData === false){    
            const order_id = nextProps.orderDetailData.order_id;
            history.push(`/order/${order_id}`);        
        }
      return ((e:any) => {
            e.preventDefault();       
        });  
    }

    public handleCancelOrder(order:IOrderResponseModel) { 
        const orderId = order.order_id;
        Promise.resolve(this.props.orderDetailFetch({orderId}))
        .then((response)=> {
            Promise.resolve(this.props.setCancelFlagFetch({cancelFlag: true}))
            .then((response1)=> {
                this.props.setModal3IsOpenFetch({modal3IsOpen: true})
            });
        });
    }
 
    public handleSubmitCancelOrderWithReason(value:any) {
        if(this.props.orderDetailData){
            const cancelValues: IOrderCancelRequestModel = {
                order_id: this.props.orderDetailData.order_id,
                cancelReason: value.order_cancel_reason
            }
            this.props.cancelOrderFetch({order_to_cancel: cancelValues});
        }
    }
 
    public closeModal() {
        Promise.resolve(this.props.setModal3IsOpenFetch({modal3IsOpen: false}))
        .then((response)=> {
            this.props.setCancelFlagFetch({cancelFlag: false}); 
        });
    }

    public selectedRowHandel(order: IFilterOrderResponseModel) {
        const order_id = order.order_id;
        
        Promise.resolve(this.props.orderDetailFetch({orderId:order_id}))
        .then((response)=> {
            this.props.getOrderArticlesFetch({orderId:order_id});  
        });  
    }

    public handleFilter(values:any){
        values.preventDefault();
        const startDate = new Date(this.props.getDateFromData);
        const endDate = new Date(this.props.getDateToData);

        Promise.resolve(this.props.recalculateFilteredTotalPricesFetch())
        .then((response)=> {
            this.props.filterOrderFetch({startDate, endDate});
        });  
    };
     
    public handleDateFrom(entryDate: any){          
        this.props.setDateFromFetch({newDateFrom: entryDate});
    };
    
    public handleDateTo(entryDate: any){
        this.props.setDateToFetch({newDateTo: entryDate});
    };
    
    public renderFilteredOrderList() {
        if(this.props.filteredOrderData && this.props.recalculateFilteredTotalPricesData ){
            return(
                <div className="dashboardTable">
                    <table className="table bp3-html-table">
                        <thead>                  
                            <tr>
                                <th>Order ID</th>
                                <th>Oder DATE</th>
                                <th>FirstName </th>
                                <th>LastName </th>
                                <th>Country </th>
                                <th>Company </th>
                                <th>Net price </th>
                                <th>Gross price </th>
                                <th>Status</th>  
                                <th>Cancel reason</th> 
                                <th/>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.filteredOrderData.map(order=>{
                                return(
                                    <tr key={order.order_id}  className = "order_hovered">
                                        <td onClick={(e) => this.selectedRowHandel(order)}><b>{order.order_id}</b></td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.orderDate} </td> 
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.firstName} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.lastName} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.country} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.companyName} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.netPrice} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.grossPrice} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.status} </td>
                                        <td onClick={(e) => this.selectedRowHandel(order)}>{order.cancelReason} </td>
                                        <td><button type="button" onClick={(e) => this.handleCancelOrder(order)} className="bp3-button" > Cancel </button></td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                    <div className="totalPrice">
                        <div>
                            <p>Total net price:</p>
                            <p>{ this.props.recalculateFilteredTotalPricesData.netPrice } </p> 
                        </div>
                        <div>
                            <p>Total gross price:</p>
                            <p>{ this.props.recalculateFilteredTotalPricesData.grossPrice } </p>
                        </div>
                        <div>
                            <p>Total net price (without delivery):</p>
                            <p>{ this.props.recalculateFilteredTotalPricesData.netPriceWD } </p>
                        </div>
                        <div>
                            <p>Total gross price (without delivery):</p>
                            <p>{ this.props.recalculateFilteredTotalPricesData.grossPriceWD } </p>
                        </div>
                    </div>    
                </div>
            )
        }
        else{
            return null;   
        }
    }

    public render(){
        if(this.props.orderDetailData && this.props.setModal3IsOpenData){ 
            return(
                <div className="grid100">
                    <Modal 
                        isOpen={this.props.setModal3IsOpenData}
                        onRequestClose={this.closeModal}
                        style={customStyles}
                        contentLabel="Example Modal"
                    >
                        <div style={{position: 'absolute', top: 3, right: 3}} ><button onClick={this.closeModal}><b>X</b></button></div> 
                        <div style={{textAlign: 'center', fontSize: 25, color: "#333"}}>ORDER TO CANCEL DETAILS: </div>
                        <br/>
                        <Form 
                            model="forms.info"
                            method="post"
                            onSubmit={ (info) => this.handleSubmitCancelOrderWithReason(info) }
                        >   
                            <tr>
                                <td>
                                    <div>
                                        <label hidden={true} htmlFor="orderid" className="bp3-file-input" ><b>Order Id: </b> {this.props.orderDetailData.order_id}</label> &nbsp;  &nbsp; 
                                        <br/>
                                        <label htmlFor="order_cancel_reason" className="bp3-file-input"><b>Reason for canceling: </b></label>  &nbsp;  &nbsp;  
                                        <Control.text
                                            className="bp3-input"
                                            model=".order_cancel_reason" 
                                        /> 
                                        <br/>
                                    </div> 
                                </td>     
                            </tr>
                            <tr>                 
                                <div style={{position: 'absolute', bottom: 23, right: 33}} > <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#E8BF1E"}}  > Cancel this order  </button>
                                </div>
                            </tr>
                        </Form>
                    </Modal>
                    <div className="filter">
                        <p> Filter orders by date range: </p>
                        <b> From: </b>
                        <form onSubmit={ this.handleFilter }>
                            <div className="bp3-input-group datePicker">
                                <b>  From: </b>
                                <DatePicker 
                                    onChange={this.handleDateFrom}
                                    value={new Date(this.props.getDateFromData)} 
                                />   
                                <b> To: </b>
                                <DatePicker 
                                    onChange={this.handleDateTo} 
                                    value={new Date(this.props.getDateToData)} 
                                />
                            </div>
                            <button type="submit" value="Submit" className="submitBtn"> Spezialsuche </button>
                        </form> 
                    </div>  
                </div>
            )
        }
        else{
            if(this.props.orderDetailData){
                if(!this.props.orderArticlesData){
                    return(
                        <div className="grid100">
                            <div className="filter">
                                <p> Filter orders by date range: </p>
                                <form onSubmit={ this.handleFilter }>
                                    <div className="bp3-input-group datePicker">
                                        <b> From: </b> 
                                        <DatePicker 
                                            activeStartDate = {this.props.getDateFromData}
                                            onChange={this.handleDateFrom}
                                            value={new Date(this.props.getDateFromData)} 
                                        />   
                                        <b> To: </b>
                                        <DatePicker 
                                            onChange={this.handleDateTo} 
                                            value={new Date(this.props.getDateToData)} 
                                        />
                                        <button type="submit" value="Submit" className="submitBtn"> Spezialsuche </button>
                                    </div>
                                </form>
                            </div>
                            {this.renderFilteredOrderList()}   
                        </div>
                    )
                }
                else{
                    return(
                        <div className="grid100">
                            <div className="filter">
                                <p> Filter orders by date range: </p>
                                <form onSubmit={ this.handleFilter }>
                                    <div className="bp3-input-group datePicker">
                                        <b>  From: </b> 
                                        <DatePicker 
                                            onChange={this.handleDateFrom}
                                            value={new Date(this.props.getDateFromData)} 
                                        />   
                                        <b> To: </b>
                                        <DatePicker 
                                            onChange={this.handleDateTo} 
                                            value={new Date(this.props.getDateToData)} 
                                        />
                                        <button type="submit" value="Submit" className="submitBtn"> Spezialsuche </button>
                                    </div>
                                </form>
                            </div>
                            {this.renderFilteredOrderList()}   
                        </div>
                    )
                }
            }
            else{
                return(
                    <div className="grid100">
                        <div className="filter">
                            <p> Filter orders by date range: </p>
                            <form onSubmit={ this.handleFilter }>
                                <div className="bp3-input-group datePicker">
                                    <b>  From: </b>
                                    <DatePicker 
                                        onChange={this.handleDateFrom}
                                        value={new Date(this.props.getDateFromData)} 
                                    />   
                                    <b> To: </b>
                                    <DatePicker 
                                        onChange={this.handleDateTo} 
                                        value={new Date(this.props.getDateToData)} 
                                    />
                                    <button type="submit" value="Submit" className="submitBtn"> Spezialsuche </button>
                                </div>
                            </form> 
                        </div>
                        {this.renderFilteredOrderList()}   
                    </div>
                )
            }
        }
    }
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state),
    setCancelFlagData: getCancelFlag(state),
    getDateFromData: getDateFrom(state), 
    getDateToData: getDateTo(state),
    setModal3IsOpenData: getModal3IsOpen(state),
    recalculateTotalPricesData: getRecalculatedTotalPrices(state),
    recalculateFilteredTotalPricesData: getRecalculatedFIlteredTotalPrices(state),
    getRecalculatedFilteredTotalPricesLoading: getRecalculatedFilteredTotalPricesLoading(state)
}); 

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch,  setDateFromFetch,
    setDateToFetch, setModal3IsOpenFetch, setCancelFlagFetch, recalculateTotalPricesFetch, recalculateFilteredTotalPricesFetch})(FilteredOrders)


