import * as React from 'react';
import './DatabaseNotUpdate.css';

class DatabaseNotUpdate extends React.Component<any> {
      constructor(props: any) {
        super(props);
    }

    public render() { 
   return(<div>Database was only patially updated for only valid quantity values!!</div>)
    }
}


export default DatabaseNotUpdate


