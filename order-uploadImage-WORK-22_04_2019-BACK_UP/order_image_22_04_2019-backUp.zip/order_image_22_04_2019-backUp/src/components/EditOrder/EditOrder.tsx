import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './EditOrder.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
// import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
import { getOrderArticlesFetch } from '../../redux/order-articles/actions';
import { IOrderArticleResponseModel } from '../../redux/order-articles/types';
import { getOrderArticles } from '../../redux/order-articles/selectors';
import { Form, Control, Errors } from 'react-redux-form';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { deleteArticleFromOrderFetch } from '../../redux/delete-article/actions'
import { RouteComponentProps } from 'react-router';
import { getSavedOrder, getSavedOrderHasError } from '../../redux/order-save/selectors';
import * as Modal from 'react-modal';
import { addQuantityToListFetch } from '../../redux/addQuantityToList/actions';
import { getQuantityList } from '../../redux/addQuantityToList/selectors';
import { setCurrentIndexFetch } from '../../redux/setCurrentIndex/actions';
import { getCurrentIndex } from '../../redux/setCurrentIndex/selectors';
import { addNetPriceToListFetch } from '../../redux/addNetPriceToList/actions';
import { getNetPriceList } from '../../redux/addNetPriceToList/selectors';
import { addGrossPriceToListFetch } from '../../redux/addGrossPriceToList/actions';
import { setModal3IsOpenFetch } from '../../redux/setModal3IsOpen/actions';
import { recalculateOrderNetPriceFetch } from '../../redux/recalculateOrderNetPrice/actions';
import { getGrossPriceList } from '../../redux/addGrossPriceToList/selectors';
import { getModal3IsOpen } from '../../redux/setModal3IsOpen/selectors';
import { getRecalculatedOrderNetPrice } from '../../redux/recalculateOrderNetPrice/selectors';
import { recalculateOrderGrossPriceFetch } from '../../redux/recalculateOrderGrossPrice/actions'; 
import { getRecalculatedOrderGrossPrice } from '../../redux/recalculateOrderGrossPrice/selectors';
import Dropzone from 'react-dropzone';
import {imageUploadFetch } from '../../redux/imageUpload/actions';
import { setPictureUrlFetch } from '../../redux/setPictureUrl/actions';
import { getSetPictureUrl } from '../../redux/setPictureUrl/selectors';
// import * as isEqual from 'react-fast-compare';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
    getOrderArticlesFetch: typeof getOrderArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
    deleteArticleFromOrderFetch: typeof deleteArticleFromOrderFetch;
    addQuantityToListFetch: typeof addQuantityToListFetch;
    setCurrentIndexFetch: typeof setCurrentIndexFetch;
    addNetPriceToListFetch: typeof addNetPriceToListFetch;
    addGrossPriceToListFetch: typeof addGrossPriceToListFetch;
    setModal3IsOpenFetch: typeof setModal3IsOpenFetch;
    recalculateOrderNetPriceFetch: typeof recalculateOrderNetPriceFetch;
    recalculateOrderGrossPriceFetch: typeof recalculateOrderGrossPriceFetch;
    imageUploadFetch: typeof imageUploadFetch;
    setPictureUrlFetch: typeof setPictureUrlFetch;
    // addImageToListFetch: typeof addImageToList 

}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    orderArticlesData: IOrderArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    decrementQuantityData: IOrderArticleResponseModel | null;
    deleteArticleFromOrderData: IOrderDetailResponseModel | null;
    addQuantityToListData: string[] | null;
    setCurrentIndexData: number;
    addNetPriceToListData: string[] | null;
    addGrossPriceToListData: string[] | null;
    setModal3IsOpenData: boolean; 
    recalculateOrderNetPriceData: string;
    recalculatedOrderGrossPriceData: string;
    getSavedOrderHasError: string;
    setPictureUrlData: string;
    
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(255, 0, 0, 0.7)',
      width: '100%'
    }
  };

class EditOrder extends React.Component<IProps, any>{
    
      constructor(props: any) {
        super(props);
        this.state = {
            files: [],
            maxFiles: 1,
            pic: '',
            currentOrAdId: "-1",
            imageUrl: '',
            imageFiles: [],
            currentOrArIndex: "-1",
            entered: false
          };
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleSetQuantity = this.handleSetQuantity.bind(this);
        this.handleSetCurrentIndex = this.handleSetCurrentIndex.bind(this);
        this.handleDeleteArticleFromOrder = this.handleDeleteArticleFromOrder.bind(this);
        this.handleSetNetPrice = this.handleSetNetPrice.bind(this);
        this.handleSetGrossPrice = this.handleSetGrossPrice.bind(this);
        this.onDrop =  this.onDrop.bind(this);
        this.setCurrentOrArId = this.setCurrentOrArId.bind(this);
        this.onDrop2 = this.onDrop2.bind(this);
        this.handleCurrentOrAdId = this.handleCurrentOrAdId.bind(this);
        this.handleCurrentOrArIndex = this.handleCurrentOrArIndex.bind(this);
       }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        this.props.orderDetailFetch({orderId});
        this.props.getOrderArticlesFetch({orderId}); 
        this.props.recalculateOrderNetPriceFetch({flagStart: true});
        this.props.recalculateOrderGrossPriceFetch({flagStart: true});
             
        if(this.props.orderArticlesData){
            this.props.addQuantityToListFetch({newQuantityValue: "", indexList: -1, pushFlag: false});
            this.props.orderArticlesData.map((orderArticle, index) => {
                this.props.addQuantityToListFetch({newQuantityValue: orderArticle.articleQuantity, indexList: index, pushFlag: true});
            });
            this.props.addNetPriceToListFetch({newNetPriceValue: "", indexList: -1, pushFlag: false});
            this.props.orderArticlesData.map((orderArticle, index) => {
                this.props.addNetPriceToListFetch({newNetPriceValue: orderArticle.articleNetPrice, indexList: index, pushFlag: true});
            });
            this.props.addGrossPriceToListFetch({newGrossPriceValue: "", indexList: -1, pushFlag: false});
            this.props.orderArticlesData.map((orderArticle, index) => {
                this.props.addGrossPriceToListFetch({newGrossPriceValue: orderArticle.articleGrossPrice, indexList: index, pushFlag: true});
            });  
           const numberArray = this.props.orderArticlesData.length;
           for(let i=0; i < numberArray; i++){
            //    this.setState({imageFiles: 0});
           }   

        }   
    }

    public componentWillReceiveProps(nextProps: IProps, nextState: IRootState) {
           if(this.props.setPictureUrlData){
                console.log("THE URL IS:" + this.props.setPictureUrlData);
                const orderId = this.props.match.params.orderId;
                this.props.getOrderArticlesFetch({orderId}); 
           }
        
        if(this.props.orderSavedData){
            if(nextProps.orderSavedData !== this.props.orderSavedData){
                history.push(`/start`); 
            }
        }
        return ((e:any) => {
            e.preventDefault();       
        });  
    }
  
    public handleDeleteArticleFromOrder(orderArticle: any){
        this.props.setModal3IsOpenFetch({modal3IsOpen: true});
    }

    public handleDeleteArticleFromOrderFinal(orArId: any){
        if(this.props.orderDetailData){
            this.props.deleteArticleFromOrderFetch({orArId});        
        }
    }

    public handleSetCurrentIndex  = async(index: any, orArIndex: any) => {
        await this.props.setCurrentIndexFetch({newIndex: index});  
    }
     
    public handleDeleteArticleFromOrderCancel(){
        this.props.setModal3IsOpenFetch({modal3IsOpen: false});
    }


    public handleSetQuantity = async (event: any) => {
        if(event.target.value){     
            if(this.props.addQuantityToListData){
                await this.props.addQuantityToListData.map((qunatity, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addQuantityToListFetch({newQuantityValue: event.target.value, indexList: j, pushFlag:false}))
                            .then((response)=> {
                                this.props.recalculateOrderNetPriceFetch({flagStart: false});
                                this.props.recalculateOrderGrossPriceFetch({flagStart: false});
                            });
                        }
                    }
                });
            }
        }
    }
    
    public handleSetNetPrice= async (event: any) =>{
        if(event.target.value){     
            if(this.props.addNetPriceToListData){
                await this.props.addNetPriceToListData.map((netPrice, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addNetPriceToListFetch({newNetPriceValue: event.target.value, indexList: j, pushFlag: false}))
                            .then((response)=> {
                                this.props.recalculateOrderNetPriceFetch({flagStart: false});
                            });
                        }
                    }
                });
            }
        }
    }
 
    public handleSetGrossPrice= async (event: any) =>{
        if(event.target.value){     
            if(this.props.addGrossPriceToListData){
                await this.props.addGrossPriceToListData.map((grossPrice, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addGrossPriceToListFetch({newGrossPriceValue: event.target.value, indexList: j, pushFlag: false}))
                            .then((response)=> {
                                   this.props.recalculateOrderGrossPriceFetch({flagStart: false});
                             });
                        }
                    }
                });
            }
        }
    }
    
    public handleSubmitSaveOrder(value:any) {
        // console.log("Entered handleSubmitSaveOrder");
        // Promise.resolve(this.state.imageFiles.map((file:any) => {
        //     if(file) {
        //     console.log("Entered mapping");
        //     const formData = new FormData();
        //     const fn = file.name.substring(file.name.lastIndexOf('/')+1);
        //     console.log("Filename123: " + fn);
        //     formData.append("file", file, fn);
        //     console.log("File123: " + JSON.stringify(file));
        //     console.log("Currend orArId: " +  this.state.currentOrAdId);
        //     this.props.setPictureUrlFetch({formData, fileName: fn, currentOrAdId: this.state.currentOrAdId});
        //     }
        this.state.imageFiles.map((file:any) => {console.log("fileeee: " + JSON.stringify(file))})

        Promise.resolve(this.onDrop(this.state.imageFiles)).
           then((response) => {this.props.orderSaveFetch();})
            // }))
        // .then((response)=> {
        //     this.props.orderSaveFetch();
        //  }); 



       
    }

    public setCurrentOrArId = (orArId: any) => {
        this.setState({currentOrAdId: orArId});
    }

    public onDrop = (files:any) => {
        files.map((file:any) => {
            console.log("Entered mapping onDrop");
            const formData = new FormData();
            const fn = file.name.substring(file.name.lastIndexOf('/')+1);
            console.log(fn);
            formData.append("file", file, fn);
            console.log("File on drop: " + JSON.stringify(file));
            this.props.setPictureUrlFetch({formData, fileName: fn, currentOrAdId: this.state.currentOrAdId});
        });
    }

   public onDrop2 = (imageFiles1:any) => {
     console.log("Entered onDrop() with imageFiles: " + imageFiles1[0])
    // let newImages =[];
    // const current = this.state.currentOrAdId;
    // let obj = new Object(id: current, name: ); 
    
    const newImages = this.state.imageFiles;

    const curr = this.state.currentOrArIndex;
    newImages[curr] = imageFiles1[0];
    
    // const obj =  { id: curr, file: imageFiles1[0] }
    //   console.log("The new object is: " + JSON.stringify(obj));

    //  newImages = this.state.imageFiles.concat(obj);
  
    // console.log("NewImages: " + JSON.stringify(newImages[0]));


    ///////////////////////////////////////////////////////////////////////////

        // this.setState((state:any) => {
        
        // const imageFiles = state.imageFiles.map((item:any) => {
        // if (item.id === 1) {
        // return {...item, age:item.age+1}
        // } else {
        // return item;
        // }
        // });
        
        // return {
        //     newImages,
        // };
        // });

        this.setState({imageFiles: newImages});
        



        // this.setState({
        //     imageFiles: this.state.imageFiles[this.state.currentOrAdId].add(imageFiles1
        // })
        console.log(imageFiles1)  
    }

    public handleCurrentOrAdId(orArId:any) {
        this.setState({currentOrAdId: orArId});
  

    }

    public handleCurrentOrArIndex(orArIndex: any){
       this.setState({currentOrArIndex: orArIndex});

    }


    public render() {
        if(this.props.setModal3IsOpenData){
            return(
                <div className="grid100">
                    <Modal isOpen={this.props.setModal3IsOpenData} style={customStyles} contentLabel="Example Modal">
                        <div style={{textAlign: 'center', fontSize: 25, color: "#333"}}>ARE YOU SURE YOU WANT TO REMOVE THIS ARTICLE FROM THE ORDER?  </div>
                        <br/>
                        <br/>
                        <br/>
                        <tr>                 
                            <div style={{position: 'absolute', bottom: 23, right: 533}} > 
                                <button type="button" className="bp3-button" style={{backgroundColor : "green"}} onClick={(e) => { if(this.props.orderArticlesData) { this.handleDeleteArticleFromOrderFinal(this.props.orderArticlesData[this.props.setCurrentIndexData])}}} >Yes  </button>
                            </div>  
                            <div style={{position: 'absolute', bottom: 23, right: 583}} > 
                                <button type="button" className="bp3-button" style={{backgroundColor : "rgb(255,255,0)"}} onClick={(e) => this.handleDeleteArticleFromOrderCancel()} >Cancel  </button>
                            </div>
                        </tr>
                    </Modal>
                </div>
            )
        }
        else{
            const numbers:any = [];
            if(this.props.orderDetailData){
                if(this.props.orderArticlesData){   
                    return (
                        <div className="grid100">
                            <Form  model="forms.info" method="post" onSubmit={ (info) => this.handleSubmitSaveOrder(info) } >   
                                <tr>
                                    <td>
                                        <div >
                                            <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                                            <br/>
                                            <label htmlFor="firstName" className="bp3-file-input"><b>First name:  &nbsp;  &nbsp;  {this.props.orderDetailData.firstName} </b></label>  &nbsp;  &nbsp;  
                                            <br/>             
                                            <label htmlFor="lastName" className="bp3-file-input"><b>Last name:  &nbsp;  &nbsp; {this.props.orderDetailData.lastName}  </b></label>
                                            <br/>
                                            <label htmlFor="companyName" className="bp3-file-input"><b>Company name: &nbsp;  &nbsp; {this.props.orderDetailData.companyName} </b></label> &nbsp;  &nbsp;
                                            <br/>
                                            <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:  &nbsp;  &nbsp; {this.props.orderDetailData.paymentMethod} </b></label> &nbsp;  &nbsp;
                                            <br/>
                                            <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:  &nbsp;  &nbsp; {this.props.orderDetailData.shippingWay} </b></label>
                                            <br/>
                                            <label htmlFor="email" className="bp3-file-input"><b>Email: &nbsp;  &nbsp; {this.props.orderDetailData.email}  </b></label> 
                                            <br/>
                                            <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:  &nbsp;  &nbsp; {this.props.orderDetailData.phoneNumber}</b></label>
                                            <br/>
                                            <label htmlFor="street" className="bp3-file-input"><b>Street:  &nbsp;  &nbsp; {this.props.orderDetailData.street}  </b></label>
                                            <br/>
                                            <label htmlFor="houseNumber" className="bp3-file-input"><b>House number: &nbsp;  &nbsp; {this.props.orderDetailData.houseNumber}  </b></label>
                                            <br/>
                                            <label htmlFor="postcode" className="bp3-file-input"><b>Post code:  &nbsp;  &nbsp;{this.props.orderDetailData.postcode} </b></label> 
                                            <br/>
                                            <label htmlFor="city" className="bp3-file-input"><b>City: &nbsp;  &nbsp; {this.props.orderDetailData.city}</b></label> 
                                            <br/>
                                            <label htmlFor="country" className="bp3-file-input"><b>Country: &nbsp;  &nbsp;  {this.props.orderDetailData.country} </b></label> 
                                            <br/>
                                            <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: &nbsp;  &nbsp; {this.props.recalculateOrderNetPriceData}  </b></label> 
                                            <br/>
                                            <label htmlFor="grossPrice" className="bp3-file-input"><b> Gross price:&nbsp;  &nbsp; {this.props.recalculatedOrderGrossPriceData}  </b></label> 
                                            <br/> 
                                            <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): &nbsp;  &nbsp; {this.props.orderDetailData.netPriceWD}  </b></label> 
                                            <br/>
                                            <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): &nbsp;  &nbsp;  {this.props.orderDetailData.grossPriceWD} </b></label> 
                                            <br/>
                                        </div> 
                                    </td>
                                </tr>
                                <div>
                                    <div style={{ position: "absolute", left: 590, top: 120  }}> <b>PRODUCTTTTS INCLUDED: </b></div>
                                    {this.props.orderArticlesData.map( (orderArticle, index) => { 
                                     

                                        

                                        numbers.push(parseInt(orderArticle.articleQuantity,10));
                                        const imageUrl = orderArticle.articlePictureUrl;
                                        console.log("For orderArticle: " + orderArticle.orArId)
                                        console.log("Image url is: "+ orderArticle.articlePictureUrl);
                                        if(this.props.addQuantityToListData){

                                            return( 
                                              <div>        
                                                <div key={orderArticle.orArId} >
                                                    {/* <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130, position: "absolute", right: 160, top: pos}} /> </tr> */}
                                                    <tr> 
                                                        <img className="bp3-button imgl" src= {imageUrl}  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 750, right: 160, top: 165 + index * 185}} /> 
                                                        <div style={{position: "absolute", left: 500, right: 400, top: 165 + index * 185}}>
                                                            <Dropzone onDrop={this.onDrop}  accept=".jpg, .png, image/*" >
                                                                <div>Try dropping a file here, or click to select a file to upload.</div>
                                                                <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6"}} onClick = {(e) => this.setCurrentOrArId(orderArticle.orArId)}>Change Image 2</button>
                                                            </Dropzone>
                                                        </div>
     <div>
            <Dropzone
                onDrop={this.onDrop2}
                onClick={(e) => this.handleCurrentOrArIndex(index)}
                className='dropzone'
                activeClassName='active-dropzone'
                multiple={false}>
      <div>
      <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6"}} onClick = {(e) => this.setCurrentOrArId(orderArticle.orArId)}>Change Image 1</button>
          Drag and drop or click to select a 550x550px file to upload.</div>
    </Dropzone>

            {/* {this.state.imageFiles.length > 0 ? <div>
    <h2>Uploading {this.state.imageFiles.length} files...</h2>
    {/* <div>{this.state.imageFiles.map((file:any) => <img src={file.preview} /> )}</div> */}
    {/* <img src={this.state.imageFiles[orderArticle.orArId].file.preview} />  */}
    {/* </div> : null} */} 

{
 console.log("We are looking for orderArticleId: " + orderArticle.orArId)


}

{ console.log("ImageFiles list size is: " + this.state.imageFiles.size)}

{   
    console.log("ImageFiles list is: " + JSON.stringify(this.state.imageFiles)) 
}

{        
    
           this.state.imageFiles.map( (imageFile:any, index1:any) => {         
    console.log("Looping through imageFiles.... => ImageFile: " )            
                                        // numbers.push(parseInt(orderArticle.articleQuantity,10));
                                        // const imageUrl = orderArticle.articlePictureUrl;
                                        // console.log("For orderArticle: " + orderArticle.orArId)
                                        // console.log("Image url is: "+ orderArticle.articlePictureUrl);
                                       
                                        // const current = this.state.currentOrArIndex;
                                    
                                        if(this.state.imageFiles[index])
                                        {   
                                            // this.setState({entered: true});
                                            console.log("will be returned image file HERE!");
                                        return( <img src={ this.state.imageFiles[index].preview} />)  
                                        }  

                                      
                                        // (imageFile.id === current) ?  <img src={imageFile.file.preview} /> : 'NO IMAGE HERE';
                                        
                                        
                                        // if(index1 === current && imageFile){
                                        //     // console.log("imageFile.id === current IS: " + imageFile.id === current );
                                        //     // // if(imageFile.id === '3363753R555357jk8937&DDBG'){    
                                        //     console.log("And they are the same, Aren't they?");
                                        //     return( 
                                        //         <div>
                                        //               <img src={imageFile.file.preview} /> 
                                                      
                                        //         </div>
  
                                        //       )
 
                                        // }
                                        else{
                                            // console.log("NOT EQUAL!!!");
                                            return (
                                                <div>
                                                    NO IMAGE HERE
                                               </div>
                                            )
 
                                        }
                                   
                                    } 
                                    )}

        </div>

                                                    </tr>
                                                    <br/>
                                                    <hr className="style13" style={{position: "absolute", left: 880, right: 50, top: 305 + index * 185}}  />     
                                                    <tr> 
                                                        <div style={{position: "absolute", left: 890, top: 155 + index * 185}}> <b> Article:  </b>  &nbsp; {orderArticle.articleName}</div>
                                                    </tr>
                                                    <tr>
                                                        <div style={{position: "absolute", left: 890, top: 180 + index * 185}}> 
                                                            <label className="bp3-file-input"><b>Net price: </b></label>  &nbsp;  &nbsp;  
                                                            <Control.text className="bp3-input" model={'.netPrice' + index}
                                                                validators={{
                                                                    required: (val) => val && val.length,
                                                                    maxLength3: (val) => val && val.length && val.length <= 3 
                                                                }}
                                                                defaultValue = {orderArticle.articleNetPrice}
                                                                onChange={this.handleSetNetPrice}
                                                                onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                                                            />
                                                            <Errors className="arrow_box" 
                                                                model={'.netPrice' + index}
                                                                show="touched"
                                                                messages={{
                                                                    required: 'Net price required!!',
                                                                    maxLength3: ' Please enter valid netPrice with length <= 3!!'
                                                                }}
                                                            />
                                                        </div>
                                                    </tr>
                                                    <tr>
                                                        <div style={{position: "absolute", left: 890, top: 215 + index * 185}}>
                                                            <label className="bp3-file-input"><b>Gross price: </b></label>  &nbsp;  &nbsp;                         
                                                            <Control.text className="bp3-input"
                                                                model={'.grossPrice' + index}
                                                                validators={{
                                                                    required: (val) => val && val.length,
                                                                    maxLength3: (val) => val && val.length && val.length <= 3 
                                                                }}

                                                                defaultValue = {orderArticle.articleGrossPrice}
                                                                onChange={this.handleSetGrossPrice}
                                                                onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                                                            />
                                                             <Errors className="arrow_box"
                                                                model={'.grossPrice' + index}
                                                                show="touched"
                                                                messages={{
                                                                    required: 'Gross price required!!',
                                                                    maxLength3: ' Please enter valid grossPrice with length <= 3!!'
                                                                }}
                                                            />
                                                        </div>
                                                    </tr>
                                                    <tr>
                                                        <div style={{position: "absolute", left: 890, top: 250 + index * 185}}> 
                                                            <b> Quantity to save:  </b> &nbsp; {this.props.addQuantityToListData[index]} 
                                                        </div>
                                                    </tr>   
                                                    <br/>       
                                                    <div style={{position: "absolute", left: 890, top: 255 + index*185}}>
                                                        <br/>
                                                        <label className="bp3-file-input"><b>Strict quantity: </b></label>  &nbsp;  &nbsp;   
                                                        <Control.text
                                                            className="bp3-input"
                                                            model={'.quantity1' + index}
                                                            
                                                            onChange={this.handleSetQuantity}
                                                            onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
                                                        />
                                                    </div>
                                                    <div style={{position: "absolute", right: 45, top: 275 + index*185}}>
                                                        <button type="button"  className="bp3-button" style={{backgroundColor : "#FF6347"}} 
                                                            onClick={(e) => { this.handleSetCurrentIndex(index, orderArticle.orArId); 
                                                                if(window.confirm('Are you sure you want to delete this article from the order?')){
                                                                this.handleDeleteArticleFromOrderFinal(orderArticle.orArId)
                                                                };
                                                            }}>Delete article
                                                        </button>
                                                    </div>
                                                </div>
                                             </div>                              
                                            )
                                        }
                                        else{
                                            return null;
                                        }
                                    })}
                                </div>
                                <tr>
                                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#25B012", position: "absolute", left: 80, top: 650 }} > Save changes  </button>   
                                </tr>
                            </Form>
                            <br/>
                        </div>
                    )
                }           
                else{
                        return (
                            <div className="grid100">
                                <Form  model="forms.info" method="post" onSubmit={ (info) => this.handleSubmitSaveOrder(info)}>   
                                    <tr>
                                        <td>
                                            <div>
                                                <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
                                                <br/>
                                                <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
                                                <Control.text className="bp3-input" model=".firstName"
                                                 validators={{
                                                    required: (val) => val && val.length
                                                }}
                                                defaultValue={this.props.orderDetailData.firstName}/>
                                                <br/>
                                                <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".lastName" defaultValue={this.props.orderDetailData.lastName}/>
                                                <br/>
                                                <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".companyName" defaultValue={this.props.orderDetailData.companyName}/>
                                                <br/>
                                                <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".paymentMethod" defaultValue={this.props.orderDetailData.paymentMethod}/>
                                                <br/>
                                                <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".shippingWay" defaultValue={this.props.orderDetailData.shippingWay}/>
                                                <br/>
                                                <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".email" defaultValue={this.props.orderDetailData.email}/>
                                                <br/>
                                                <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".phoneNumber" defaultValue={this.props.orderDetailData.phoneNumber}/>
                                                <br/>
                                                <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".street" defaultValue={this.props.orderDetailData.street}/>
                                                <br/>
                                                <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".houseNumber" defaultValue={this.props.orderDetailData.houseNumber}/>
                                                <br/>
                                                <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".postcode" defaultValue={this.props.orderDetailData.postcode}/>
                                                <br/>
                                                <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
                                                <Control.text className="bp3-input" model=".city" defaultValue={this.props.orderDetailData.city}/>
                                                <br/>
                                                <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".country" defaultValue={this.props.orderDetailData.country}/>
                                                <br/>
                                                <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".netPrice" defaultValue={String(this.props.recalculateOrderNetPriceData)}/>
                                                <br/>
                                                <label htmlFor="grossPrice" className="bp3-file-input"><b>222222222 Gross price: </b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".grossPrice" defaultValue={String(this.props.recalculatedOrderGrossPriceData)}/>
                                                <br/>
                                                <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".netPriceWD" defaultValue={this.props.orderDetailData.netPriceWD}/>
                                                <br/>                
                                                <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
                                                <Control.text className="bp3-input" model=".grossPriceWD" defaultValue={this.props.orderDetailData.grossPriceWD}/>
                                                <br/>
                                            </div>    
                                        </td>
                                    </tr>
                                    <tr>
                                        <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4", position: "absolute", right: 30, top: 690 }} > Save changes  </button>         
                                    </tr>
                                </Form>
                                <br/>
                            </div>
                        )
                    }
            }
            else {
                return null;
            }
        }
    }
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state),
    orderArticlesData: getOrderArticles(state),
    orderSavedData: getSavedOrder(state),
    addQuantityToListData: getQuantityList(state),
    setCurrentIndexData: getCurrentIndex(state),
    addNetPriceToListData: getNetPriceList(state),
    addGrossPriceToListData: getGrossPriceList(state),
    setModal3IsOpenData: getModal3IsOpen(state),
    recalculateOrderNetPriceData: getRecalculatedOrderNetPrice(state),
    recalculatedOrderGrossPriceData: getRecalculatedOrderGrossPrice(state),
    getSavedOrderHasError: getSavedOrderHasError(state),
    setPictureUrlData: getSetPictureUrl(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch, getOrderArticlesFetch, orderSaveFetch, cancelOrderFetch, deleteArticleFromOrderFetch, addQuantityToListFetch, setCurrentIndexFetch, addNetPriceToListFetch, addGrossPriceToListFetch, setModal3IsOpenFetch, recalculateOrderNetPriceFetch, recalculateOrderGrossPriceFetch, imageUploadFetch, setPictureUrlFetch})(EditOrder)

