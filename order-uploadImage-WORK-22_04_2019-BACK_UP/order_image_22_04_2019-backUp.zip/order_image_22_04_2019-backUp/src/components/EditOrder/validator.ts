

export const maxLength3 = (val:string) => val.length <= 3; 
