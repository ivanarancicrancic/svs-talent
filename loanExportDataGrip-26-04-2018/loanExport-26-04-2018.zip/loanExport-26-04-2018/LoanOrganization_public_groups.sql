INSERT INTO public.groups (groupid, groupname, description) VALUES (1, 'Administrator', 'nekoj opis');
INSERT INTO public.groups (groupid, groupname, description) VALUES (2, 'Users', 'nekoj opis');