INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('10002', null, 'starter', 'admin', null, '10001');
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('10008', 'dev-managers', 'candidate', null, '10007', null);
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('12507', 'dev-managers', 'candidate', null, '12506', null);
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('15002', null, 'starter', 'admin', null, '15001');
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('15008', 'dev-managers', 'candidate', null, '15007', null);
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('30007', 'dev-managers', 'candidate', null, '30006', null);
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('75007', null, 'participant', 'John Doe', null, '75001');
INSERT INTO public.act_hi_identitylink (id_, group_id_, type_, user_id_, task_id_, proc_inst_id_) VALUES ('77507', null, 'participant', 'John Doe', null, '77501');