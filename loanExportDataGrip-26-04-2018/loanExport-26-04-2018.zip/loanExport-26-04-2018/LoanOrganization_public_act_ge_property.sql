INSERT INTO public.act_ge_property (name_, value_, rev_) VALUES ('schema.version', '5.20.0.1', 1);
INSERT INTO public.act_ge_property (name_, value_, rev_) VALUES ('schema.history', 'create(5.20.0.1)', 1);
INSERT INTO public.act_ge_property (name_, value_, rev_) VALUES ('next.dbid', '80001', 33);