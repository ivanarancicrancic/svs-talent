package springwebapp.converters;

import springwebapp.commands.PublisherCommand;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Publisher;

@Component
public class PublisherCommandToPublisher implements Converter<PublisherCommand, Publisher> {

    @Synchronized
    @Override
    public Publisher convert(PublisherCommand source){

        if(source == null){
            return null;
        }

        final Publisher publisher = new Publisher();
        publisher.setId(source.getId());
        publisher.setName(source.getName());
        publisher.setAddress(source.getAddress());
        return publisher;
    }


}
