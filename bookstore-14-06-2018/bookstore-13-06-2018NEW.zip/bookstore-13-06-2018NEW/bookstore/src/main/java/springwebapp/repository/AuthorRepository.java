package springwebapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import springwebapp.model.Author;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface AuthorRepository extends JpaRepository<Author, Long> {
//
//    public List<Author> getAllAuthors();
//
//    public Author getAuthor(Long id);
//
//    public Author createAuthor(Author libraryuser);
//
//    public Author updateAuthor(Long id, Author libraryuser);
//
//    public Author deleteAuthor(Long id);


}
