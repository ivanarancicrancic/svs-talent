package springwebapp.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import springwebapp.propertybean.DataSourceClass;
import springwebapp.propertybean.SpecialDataSourceClass;




@Configuration
//@PropertySource({"classpath:datasource.properties", "classpath:special.properties"})
@PropertySources({
     @PropertySource("classpath:datasource.properties"),
     @PropertySource("classpath:special.properties")
   })

public class PropertyConfiguration {


    @Autowired
    org.springframework.core.env.Environment environment;

    @Value("${springwebapp.username}")
    String user;

    @Value("${springwebapp.password}")
    String password;

    @Value("${springwebapp.dburl}")
    String url;


    @Value("${main.username}")
    String mainUsername;

    @Value("${main.password}")
    String mainPassword;

    @Value("${main.dburl}")
    String mainUrl;



    @Value("${springwebapp.special.username}")
    String specialUser;

    @Value("${springwebapp.special.password}")
    String specialPassword;

    @Value("${springwebapp.special.dburl}")
    String specialUrl;

    @Bean
    public DataSourceClass dataSourceClass(){
        DataSourceClass dataSourceClass = new DataSourceClass();
        dataSourceClass.setUser(environment.getProperty("username"));
        dataSourceClass.setPassword(password);
        dataSourceClass.setUrl(url);
        dataSourceClass.setMainUser(mainUsername);
        dataSourceClass.setMainPassword(mainPassword);
        dataSourceClass.setMainUrl(mainUrl);
        return  dataSourceClass;

    }

    @Bean
    public SpecialDataSourceClass SpecialdataSourceClass(){
        SpecialDataSourceClass specialDataSourceClass = new SpecialDataSourceClass();
        specialDataSourceClass.setSpecialUser(specialUser);
        specialDataSourceClass.setSpecailPassword(specialPassword);
        specialDataSourceClass.setSpecialUrl(specialUrl);
        return  specialDataSourceClass;

    }

    @Bean
    public static PropertySourcesPlaceholderConfigurer properties(){
        PropertySourcesPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertySourcesPlaceholderConfigurer();
        return  propertyPlaceholderConfigurer;

    }

}
