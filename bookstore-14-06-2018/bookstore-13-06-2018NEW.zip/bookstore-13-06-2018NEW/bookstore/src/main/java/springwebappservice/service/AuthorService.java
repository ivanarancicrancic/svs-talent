package springwebappservice.service;

import springwebapp.commands.AuthorCommand;
import springwebapp.model.Author;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface AuthorService {
    public Author creatAuthor(Author libraryuser);
    public List<Author> getAllAuthors();
    //public String getAuthor(Long id);
    public String updateAuthor(Long id, Author libraryuser);
    public String deleteAuthor(Long id);
    //public AuthorCommand findById(Long id);
    public AuthorCommand findByBookIdAndAuthorId(Long bookId, Long authorId);
    public AuthorCommand findAuthorById(Long authorId);

}
