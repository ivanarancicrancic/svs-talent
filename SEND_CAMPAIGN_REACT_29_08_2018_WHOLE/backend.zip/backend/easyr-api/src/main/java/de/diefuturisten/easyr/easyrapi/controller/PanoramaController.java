package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.service.PanoramaContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/campaigns/")
public class PanoramaController {

    private PanoramaContentService panoramaContentService;

    public PanoramaController(PanoramaContentService panoramaContentService) {
        this.panoramaContentService = panoramaContentService;
    }

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public PanoramaContent findById(@PathVariable long panoramaId){
        return panoramaContentService.findPanorama(panoramaId);
    }

    @PostMapping("{id}/panoramas/")
    @ResponseStatus(HttpStatus.CREATED)
    public PanoramaContent postPanoramaByCampaign(@PathVariable long id, @RequestBody PanoramaContent panoramaContent){
        return panoramaContentService.createPanoramaByCampaign(id, panoramaContent);
    }

    @PutMapping("{id}/panoramas/{panoramaId}")
    @ResponseStatus(HttpStatus.OK)
    public PanoramaContent modifyPanoramaContengt(@PathVariable long id, @RequestBody PanoramaContent panoramaContent, @PathVariable long panoramaId){
        return panoramaContentService.saveByCampaign(id, panoramaContent, panoramaId);
    }

    @DeleteMapping("{id}/panoramas/{panoramaId}")
    @ResponseStatus(HttpStatus.OK)
    public void deletePanoramaByCampaign(@PathVariable long id, @PathVariable long panoramaId){
        panoramaContentService.deletePanoramaByCampaign(id, panoramaId);
    }
}
