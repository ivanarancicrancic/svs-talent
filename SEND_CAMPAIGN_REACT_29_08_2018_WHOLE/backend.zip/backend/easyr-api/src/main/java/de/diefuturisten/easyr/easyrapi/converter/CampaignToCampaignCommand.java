package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.stereotype.Component;
import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.converter.UserToUserReturn;
import de.diefuturisten.easyr.easyrapi.converter.TrackerToTrackerReturn;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand;


@Component
public class CampaignToCampaignCommand implements Converter<Campaign, CampaignCommand> {

    ContactInformationToContactInformationReturn contactInformationToContactInformationReturn = new ContactInformationToContactInformationReturn();
    UserToUserReturn userToUserReturn = new UserToUserReturn();
    TrackerToTrackerReturn trackerToTrackerReturn = new TrackerToTrackerReturn();

    public CampaignToCampaignCommand() {
    }

    @Override
    public CampaignCommand convert(Campaign source){
        if(source == null){
            return null;
        }

        CampaignCommand campaignCommand = new CampaignCommand();

        Long id;

        de.diefuturisten.easyr.easyrapi.entity.user.User user;

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> tracker = new java.util.ArrayList<>();

        java.util.List<de.diefuturisten.easyr.easyrapi.entity.content.Content> contents = new java.util.ArrayList<>();

        de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation contact;

        campaignCommand.setId(source.getId());
        campaignCommand.setUser(userToUserReturn.convert(source.getUser()));
        campaignCommand.setContact(contactInformationToContactInformationReturn.convert(source.getContactInformation()));

        if (source.getTracker() != null && source.getTracker().size() > 0){
            source.getTracker()
                    .forEach( tracker1 -> campaignCommand.getTracker().add(trackerToTrackerReturn.convert(tracker1)));
        }

        return campaignCommand;
    }
}
