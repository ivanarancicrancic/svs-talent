package de.diefuturisten.easyr.easyrapi.converter;


import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.response.UserReturn;

public class UserToUserReturn implements Converter<User, UserReturn> {

    public UserToUserReturn(){}

    @Override
    public UserReturn convert(User source) {
        UserReturn userReturn = new UserReturn();

        userReturn.setId(source.getId());
        userReturn.setLanguage(source.getLanguage());
        userReturn.setActive(source.isActive());
        userReturn.setEmail(source.getEmail());
        userReturn.setPassword(source.getPassword());
        userReturn.setGender(source.isGender());
        userReturn.setFirstname(source.getFirstname());
        userReturn.setLastname(source.getLastname());
        return userReturn;
    }


}
