package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.service.UnityContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@RequestMapping("/api/campaigns/")
public class UnityContentController {

    de.diefuturisten.easyr.easyrapi.converter.UnityContentToUnityContentReturn unityContentToUnityContentReturn = new de.diefuturisten.easyr.easyrapi.converter.UnityContentToUnityContentReturn();
    private UnityContentService unityContentService;

    public UnityContentController(UnityContentService unityContentService) {
        this.unityContentService = unityContentService;
    }

    @GetMapping("{unityId}")
    @ResponseStatus(HttpStatus.OK)
    public de.diefuturisten.easyr.easyrapi.model.response.UnityContentReturn getUnity(@PathVariable long unityId){
        return unityContentToUnityContentReturn.convert(unityContentService.findUnityById(unityId));
    }

    @PostMapping("{id}/unities/")
    @ResponseStatus(HttpStatus.CREATED)
    public UnityContent createUnityByCampaign(@PathVariable long id, @RequestBody UnityContent unityContent){
        return unityContentService.createUnityConten(id, unityContent);
    }

    @PutMapping("{id}/unities/{unityId}")
    @ResponseStatus(HttpStatus.OK)
    public UnityContent modifyUnityByCampaign(@PathVariable long id, @RequestBody UnityContent unityContent, @PathVariable long unityId){
        return unityContentService.modifyUnityContent(id, unityContent, unityId);
    }

    @DeleteMapping({"{id}/unities/{unityId}"})
    @ResponseStatus(HttpStatus.OK)
    public void deleteUnityContent(@PathVariable long id, @PathVariable long unityId){
        unityContentService.deleteUnityContent(id, unityId);
    }



}
