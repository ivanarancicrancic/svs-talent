package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import java.util.List;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;

@org.springframework.stereotype.Component
public class CampaignCommandToCampaign implements Converter<CampaignCommand, Campaign> {

    ContactInformationReturnToContactInformation contactInformationReturnToContactInformation = new ContactInformationReturnToContactInformation();
    UserReturnToUser userReturnToUser = new UserReturnToUser();
    TrackerReturnToTracker trackerReturnToTracker = new TrackerReturnToTracker();

    public CampaignCommandToCampaign() {
    }

    @Override
    public Campaign convert(CampaignCommand source){

        if(source == null){
            return null;
        }

        Campaign campaign = new Campaign();

        Long id;

        User user;

        List<Tracker> tracker = new java.util.ArrayList<>();

        List<Content> contents = new java.util.ArrayList<>();

        ContactInformation contact;

        campaign.setId(source.getId());
        campaign.setUser(userReturnToUser.convert(source.getUser()));
        campaign.setContactInformation(contactInformationReturnToContactInformation.convert(source.getContact()));

        if (source.getTracker() != null && source.getTracker().size() > 0){
            source.getTracker()
                    .forEach( tracker1 -> campaign.getTracker().add(trackerReturnToTracker.convert(tracker1)));
        }

        campaign.setTracker(null);
        campaign.setContactInformation(null);

        return campaign;
    }

}



