package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.service.WebviewContentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/campaigns/")
public class WebviewContentController {

    de.diefuturisten.easyr.easyrapi.converter.WebviewContentToWebviewContentReturn webviewContentToWebviewContentReturn = new de.diefuturisten.easyr.easyrapi.converter.WebviewContentToWebviewContentReturn();
   private WebviewContentService webviewContentService;

    public WebviewContentController(WebviewContentService webviewContentService) {
        this.webviewContentService = webviewContentService;
    }

    @PutMapping("{id}/webviews/{webviewId}")
    @ResponseStatus(HttpStatus.OK)
    public WebviewContent updateWebviewByCampaign(@PathVariable long id, @RequestBody WebviewContent webviewContent, @PathVariable long webviewId){
        return  webviewContentService.updateWebviewByCampaign(id, webviewContent, webviewId);
    }

    @PostMapping("{id}/webviews/")
    @ResponseStatus(HttpStatus.CREATED)
    public WebviewContent createWebviewByCampaign(@PathVariable long id, @RequestBody WebviewContent webviewContent){
        return webviewContentService.createWebviewByCampaign(id, webviewContent);
    }

    @DeleteMapping("{id}/webviews/{webviewId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteWebviewByCampaign(@PathVariable long id, @PathVariable long webviewId){
         webviewContentService.deleteWebviewByCampaign(id, webviewId);
    }

    @GetMapping("{webviewId}")
    @ResponseStatus(HttpStatus.OK)
    public de.diefuturisten.easyr.easyrapi.model.response.WebviewContentReturn findwebviewById(@PathVariable long webviewId){
        return webviewContentToWebviewContentReturn.convert(webviewContentService.findWebviewById(webviewId));
    }

}
