import * as React from 'react';

export default class ManufacturerContent extends React.Component {

    public render() {
        return (
            <pre>
                <div>
                        <label>
                        Manufacturer
                        </label>
                 </div>        
            </pre>
        )
    }
}