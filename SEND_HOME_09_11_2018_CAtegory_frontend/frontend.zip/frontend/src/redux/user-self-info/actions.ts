import {
    USER_SELF_INFO_FETCH,
    USER_SELF_INFO_SUCCESS,
    USER_SELF_INFO_FAIL,
    IUserResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const userSelfInfoFetch = createStandardAction(USER_SELF_INFO_FETCH)();
export const userSelfInfoSuccess = createStandardAction(USER_SELF_INFO_SUCCESS)<IUserResponseModel>();
export const userSelfInfoFail = createStandardAction(USER_SELF_INFO_FAIL)<string>();