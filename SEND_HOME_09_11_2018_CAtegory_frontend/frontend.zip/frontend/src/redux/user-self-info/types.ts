export const USER_SELF_INFO_FETCH = '@@user/self/info/FETCH';
export const USER_SELF_INFO_SUCCESS = '@@user/self/info/SUCCESS';
export const USER_SELF_INFO_FAIL = '@@user/self/info/FAIL';

export interface IUserResponseModel {
    id: number;
    name: string;
    rights: string[];
};