import { IRootState } from '..'

export const getCategoryDetail = (state: IRootState) => state.category.data;
export const getCategoryDetailIsLoading = (state: IRootState) => state.category.loading;
export const getCategoryDetailHasError = (state: IRootState) => state.category.error;