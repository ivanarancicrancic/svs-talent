export const MANUFACTURER_LIST_FETCH = '@@user/manufacturer/list/FETCH';
export const MANUFACTURER_LIST_SUCCESS = '@@user/manufacturer/list/SUCCESS';
export const MANUFACTURER_LIST_FAIL = '@@user/manufacturer/list/FAIL';

export const MANUFACTURER_CREATE_FETCH = '@@manufacturer/create/FETCH';
export const MANUFACTURER_CREATE_SUCCESS = '@@manufacturer/create/SUCCESS';
export const MANUFACTURER_CREATE_FAIL = '@@manufacturer/create/FAIL';

export interface IManufacturerResponseModel {
    id: number;
    name: string;
    description: number;
};