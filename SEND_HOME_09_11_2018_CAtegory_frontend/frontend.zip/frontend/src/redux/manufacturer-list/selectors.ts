import { IRootState } from '..'

export const getManufacturerList = (state: IRootState) => state.manufacturerList.data;
export const getManufacturerListIsLoading = (state: IRootState) => state.manufacturerList.loading;
export const getManufacturerListHasError = (state: IRootState) => state.manufacturerList.error;