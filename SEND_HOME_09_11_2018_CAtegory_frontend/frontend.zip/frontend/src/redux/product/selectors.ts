import { IRootState } from '..'

export const getProductDetail = (state: IRootState) => state.product.data;
export const getProductDetailIsLoading = (state: IRootState) => state.product.loading;
export const getProductDetailHasError = (state: IRootState) => state.product.error;
export const getProduct = (state: IRootState) => state.product.data;

