declare module "framework7/framework7.esm.bundle" {
    const Framework7: any;
    export default Framework7;
}