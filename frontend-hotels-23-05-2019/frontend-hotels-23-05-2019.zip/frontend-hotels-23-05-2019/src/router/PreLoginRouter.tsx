import * as React from 'react';

import { Route, Switch } from 'react-router';

import {PATH_ROOT, PATH_REGISTER} from './paths';

import LoginContainer from '../containers/PreAuthContainer/LoginContainer'
import RegisterContainer from '../containers/PreAuthContainer/RegisterContainer'

export default class PreLoginRouter extends React.Component {
    public render() {
      return (
        <React.Fragment>
          <Switch>
            <Route exact={true} path={PATH_ROOT} component={LoginContainer} />
            <Route exact={true} path={PATH_REGISTER} component={RegisterContainer} />
          </Switch>
        </React.Fragment>
      );
    }
  }