import { ActionType, getType } from 'typesafe-actions';

import * as actions from './actions';

const extActions = {...actions};

export type SetPictureUrlActions = ActionType<typeof extActions>;

export interface IPictureUrlState {
    readonly data: string | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IPictureUrlState = {
    data: null,
    loading: false,
    error: null
};
  
export function setPictureUrlFetchReducer(state: IPictureUrlState = INITIAL_STATE, action: SetPictureUrlActions): IPictureUrlState  {
    switch (action.type) {
        case getType(extActions.setPictureUrlFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setPictureUrlSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setPictureUrlFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}