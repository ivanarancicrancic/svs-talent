import { createLogic } from 'redux-logic';
import { SET_PICTURE_URL_FETCH } from './types';
import { setPictureUrlFetch, setPictureUrlSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';
import * as AWS from 'aws-sdk';

export const setPictureUrlFetchLogic = createLogic({
    type: SET_PICTURE_URL_FETCH,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(setPictureUrlFetch)(action)) {  
             
          
            const options = {
                method: 'POST',
                body: action.payload.formData,
                // body: {
                //     file: formData,
                //      orArId: '563753R55357jk8837DDBG'
                //    },
               
                // If you add this, upload won't work
                headers: {
                  'Content-Type': 'multipart/form-data',
                }
              };
              
              delete options.headers['Content-Type'];
    
            fetch(`http://localhost:8080/ersatzteilhandel24apiValid/orderArticle/uploadImage`, options).
            then((response) => response.json()).
            then((response: any) => {
                console.log("response: " + response);
              
                        console.log("Succesed image upload finally");

                        const s3 = new AWS.S3({accessKeyId:'AKIAJLVOOJ5OXSCDQFLA', secretAccessKey:'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', region:'us-east-1'});
         
                        console.log("Image name: " + action.payload.fileName);
                        const params = {Bucket: 'ersatzteil-handel', Key: action.payload.fileName};
         s3.getSignedUrl('getObject', params, (err: any, url:any) => {
             console.log('Your generated pre-signed URL is: ', url + "for orderArId: " + action.payload.currentOrAdId);
            //  this.setState({imageUrl: url});
            
           
             fetch('http://localhost:8080/ersatzteilhandel24apiValid/orderArticle/updateUrl', {
                method: 'POST',
                body: JSON.stringify({
                  orArId: action.payload.currentOrAdId,
                  fileUrl: url
                })
              }).then((response2: any) => {
                  console.log("FInished");
                  
            dispatch(setPictureUrlSuccess(url));
                // const orderId = this.props.match.params.orderId;
                // this.props.getOrderArticlesFetch({orderId}); 

              });

         });

               
    
            })
          
          
    
        } 
        else {
            done();
        }
    }
});

export default [
    setPictureUrlFetchLogic
];
