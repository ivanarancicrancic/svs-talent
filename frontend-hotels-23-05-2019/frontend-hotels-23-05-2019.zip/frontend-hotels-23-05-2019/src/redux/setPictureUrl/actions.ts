import {
    SET_PICTURE_URL_FETCH,
    SET_PICTURE_URL_SUCCESS,
    SET_PICTURE_URL_FAIL,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setPictureUrlFetch = createStandardAction(SET_PICTURE_URL_FETCH)<{formData: FormData, fileName: string, currentOrAdId: string}>();
export const setPictureUrlSuccess = createStandardAction(SET_PICTURE_URL_SUCCESS)<string>();
export const setPictureUrlFail = createStandardAction(SET_PICTURE_URL_FAIL)<string>();
