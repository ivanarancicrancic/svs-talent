import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type AddNetPriceToListActions = ActionType<typeof extActions>;

export interface IAddNetPriceToListState {
    readonly data: string[];
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IAddNetPriceToListState = {
    data: [],
    loading: false,
    error: null
};
  
export function addNetPriceToListReducer(state: IAddNetPriceToListState = INITIAL_STATE, action: AddNetPriceToListActions): IAddNetPriceToListState  {
    switch (action.type) {
        case getType(extActions.addNetPriceToListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.addNetPriceToListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.addNetPriceToListFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}