import { IRootState } from '..'

export const getNetPriceList = (state: IRootState) => state.listNetPrices.data;
export const getNetPriceListLoading = (state: IRootState) => state.listNetPrices.loading;
export const getNetPriceListHasError = (state: IRootState) => state.listNetPrices.error;