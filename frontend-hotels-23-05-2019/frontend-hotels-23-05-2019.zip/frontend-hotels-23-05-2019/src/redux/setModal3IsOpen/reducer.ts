import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';


const extActions = {...actions};

export type SetModal3IsOpenActions = ActionType<typeof extActions>;

export interface ISetModal3IsOpenState {
    readonly data: boolean;
    readonly loading: boolean;
    readonly error: string | null;
};
  

const INITIAL_STATE: ISetModal3IsOpenState = {
    data: false,
    loading: false,
    error: null
};
  
export function setModal3IsOpenReducer(state: ISetModal3IsOpenState = INITIAL_STATE, action: SetModal3IsOpenActions): ISetModal3IsOpenState  {
    switch (action.type) {
        case getType(extActions.setModal3IsOpenFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.setModal3IsOpenSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.setModal3IsOpenFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}