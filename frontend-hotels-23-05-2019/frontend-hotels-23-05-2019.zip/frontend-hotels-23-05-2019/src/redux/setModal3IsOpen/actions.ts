import {
    SET_MODAL3_IS_OPEN_FETCH,
    SET_MODAL3_IS_OPEN_SUCCESS,
    SET_MODAL3_IS_OPEN_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setModal3IsOpenFetch = createStandardAction(SET_MODAL3_IS_OPEN_FETCH)<{modal3IsOpen: boolean}>();
export const setModal3IsOpenSuccess = createStandardAction(SET_MODAL3_IS_OPEN_SUCCESS)<boolean>();
export const setModal3IsOpenFail = createStandardAction(SET_MODAL3_IS_OPEN_FAIL)<string>();

