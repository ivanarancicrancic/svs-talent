import { createLogic } from 'redux-logic';
import axios from 'axios';

import { REGISTER_FETCH } from './types';
import { registerFetch, registerSuccess, registerFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

interface IRegisterRequestModel {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    gender: boolean;
    captcha: {
        id: string;
        answer: string;
    }
};

export const registerFetchLogic = createLogic({
    type: REGISTER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(registerFetch)(action)) {

            const state = getState() as IRootState;
            
            const formValues = action.payload;

            const requestModel: IRegisterRequestModel = {
                email: formValues.email,
	            firstName: formValues.firstName,
	            lastName: formValues.lastName,
                password: formValues.password,
                gender: formValues.title === 'female' ? false : true,
	            captcha: {
		            id: state.captcha.data && state.captcha.data.id || "",
		            answer: formValues.captcha
	            }
            }

            axios({
                method: 'post',
                url: API_ROOT + '/register',
                headers: {"Content-Type": "application/json"},
                data: JSON.stringify(requestModel)
            }).then(response => {
                dispatch(registerSuccess());
            }).catch(error => {
                dispatch(registerFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    registerFetchLogic
];
