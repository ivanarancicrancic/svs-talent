export const GET_HOTEL_ARTICLES_FETCH = '@@user/hotel/articles/FETCH';
export const GET_HOTEL_ARTICLES_SUCCESS = '@@user/hotel/articles/SUCCESS';
export const GET_HOTEL_ARTICLES_FAIL = '@@user/hotel/articles/FAIL';

export interface IHotelArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
    articleNetPrice: string;
    articleGrossPrice: string;
    articleNetPriceWD: string;
    articleGrossPriceWD: string;
    articlePictureUrl: string;
};