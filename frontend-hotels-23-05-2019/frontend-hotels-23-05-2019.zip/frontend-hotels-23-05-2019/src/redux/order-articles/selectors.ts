import { IRootState } from '..'

export const getHotelArticles = (state: IRootState) => state.hotelArticles.data;
export const getHotelArticlesLoading = (state: IRootState) => state.hotelArticles.loading;
export const getHotelArticlesHasError = (state: IRootState) => state.hotelArticles.error;