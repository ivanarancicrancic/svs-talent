import { ActionType, getType } from 'typesafe-actions';
import { IHotelArticleResponseModel } from './types';

import * as actions from './actions';

const extActions = {...actions};

export type GetHotelArtictlesActions = ActionType<typeof extActions>;

export interface IHotelArticlesState {
    readonly data: IHotelArticleResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IHotelArticlesState = {
    data: null,
    loading: false,
    error: null
};
  
export function getHotelArticlesReducer(state: IHotelArticlesState = INITIAL_STATE, action: GetHotelArtictlesActions): IHotelArticlesState  {
    switch (action.type) {
        case getType(extActions.getHotelArticlesFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.getHotelArticlesSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.getHotelArticlesFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}