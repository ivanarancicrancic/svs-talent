import { createLogic } from 'redux-logic';
import { GET_HOTEL_ARTICLES_FETCH, IHotelArticleResponseModel } from './types';
import { getHotelArticlesFetch, getHotelArticlesSuccess, getHotelArticlesFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const getHotelArticlesFetchLogic = createLogic({
    type: GET_HOTEL_ARTICLES_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(getHotelArticlesFetch)(action)) {  
          fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderArticlesServlet', {
            method: 'POST',
            body: JSON.stringify({
              order_id: action.payload.hotelId
            })
          }).then((response) => response.json())
            .then((responseJson) => {
                dispatch(getHotelArticlesSuccess(responseJson as IHotelArticleResponseModel[]));
            })
            .catch((error) => {
                dispatch(getHotelArticlesFail("fail"))
            });

        } else {
            done();
        }
    }
});

export default [
    getHotelArticlesFetchLogic
];
