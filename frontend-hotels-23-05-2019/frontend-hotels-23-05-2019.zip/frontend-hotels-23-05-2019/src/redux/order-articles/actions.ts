import {
    GET_HOTEL_ARTICLES_FETCH,
    GET_HOTEL_ARTICLES_SUCCESS,
    GET_HOTEL_ARTICLES_FAIL,
    IHotelArticleResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const getHotelArticlesFetch = createStandardAction(GET_HOTEL_ARTICLES_FETCH)<{hotelId: string}>();
export const getHotelArticlesSuccess = createStandardAction(GET_HOTEL_ARTICLES_SUCCESS)<IHotelArticleResponseModel[]>();
export const getHotelArticlesFail = createStandardAction(GET_HOTEL_ARTICLES_FAIL)<string>();
