import {
    HOTEL_DETAIL_FETCH,
    HOTEL_DETAIL_SUCCESS,
    HOTEL_DETAIL_FAIL,
    IHotelDetailResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const hotelDetailFetch = createStandardAction(HOTEL_DETAIL_FETCH)<{hotelId: string}>();
export const hotelDetailSuccess = createStandardAction(HOTEL_DETAIL_SUCCESS)<IHotelDetailResponseModel>();
export const hotelDetailFail = createStandardAction(HOTEL_DETAIL_FAIL)<string>();
