export const HOTEL_DETAIL_FETCH = '@@user/hotel/detail/FETCH';
export const HOTEL_DETAIL_SUCCESS = '@@user/hotel/detail/SUCCESS';
export const HOTEL_DETAIL_FAIL = '@@user/hotel/detail/FAIL';


export interface IHotelDetailResponseModel {
    id: string;
    name: string;
    description: string;
};

export interface IHotelArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};