import { ActionType, getType } from 'typesafe-actions';
import { IHotelDetailResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type HotelDetailActions = ActionType<typeof extActions>;

export interface IHotelDetailState {
    readonly data: IHotelDetailResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IHotelDetailState = {
    data: null,
    loading: false,
    error: null
};
  
export function hotelDetailReducer(state: IHotelDetailState = INITIAL_STATE, action: HotelDetailActions): IHotelDetailState  {
    switch (action.type) {
        case getType(extActions.hotelDetailFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.hotelDetailSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.hotelDetailFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}