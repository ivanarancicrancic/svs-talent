import { IRootState } from '..'

export const getHotelDetail = (state: IRootState) => state.hotelDetail.data;
export const getHotelDetailLoading = (state: IRootState) => state.hotelDetail.loading;
export const getHotelDetailHasError = (state: IRootState) => state.hotelDetail.error;