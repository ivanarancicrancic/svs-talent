import { createLogic } from 'redux-logic';
import { HOTEL_DETAIL_FETCH, IHotelDetailResponseModel } from './types';
import { hotelDetailFetch, hotelDetailSuccess, hotelDetailFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { getHotelArticlesFetch } from '../order-articles/actions';
import { setModal3IsOpenFetch } from '../setModal3IsOpen/actions';
import { recalculateFilteredTotalPricesFetch } from '../recalculateFilteredOrdersTotalPrices/actions';
import { IRootState } from '..';

export const orderDetailFetchLogic = createLogic({
    type: HOTEL_DETAIL_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(hotelDetailFetch)(action)) {
            console.log("Before calling fetch of backend!");
            // fetch(`http://localhost:8080/ersatzteilhandel24apiValid/api1/hotel/${action.payload.hotelId}`, {
            //     method: 'GET'
            //   })
              fetch(`http://localhost:8080/api1/hotel/${action.payload.hotelId}`)
            .then(response => response.json())
            .then(data => {
            const result = data as IHotelDetailResponseModel;
            dispatch(hotelDetailSuccess(result));
              })
              .then(data => {
                dispatch(getHotelArticlesFetch({hotelId:action.payload.hotelId}));   
            })
            .then(data => {
                if((getState() as IRootState).cancelFlag.data){
                dispatch(setModal3IsOpenFetch({modal3IsOpen: true}));
           
                }  
            })
            .then(data => {
                if((getState() as IRootState).cancelFlag.data){
                dispatch(recalculateFilteredTotalPricesFetch());    
                }
            })
            .catch(error =>  dispatch(hotelDetailFail("fail")));
        } else {
            done();
        }
    }
});

export default [
    orderDetailFetchLogic
];
