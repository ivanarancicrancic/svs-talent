import { ActionType, getType } from 'typesafe-actions';
import { IFilterOrderResponseModel } from './types';

import * as actions from './actions';

const extActions = {...actions};

export type FilterOrderActions = ActionType<typeof extActions>;

export interface IFilteredOrderState {
    readonly data: IFilterOrderResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IFilteredOrderState = {
    data: null,
    loading: false,
    error: null
};
  
export function filterOrderReducer(state: IFilteredOrderState = INITIAL_STATE, action: FilterOrderActions): IFilteredOrderState  {
    switch (action.type) {
        case getType(extActions.filterOrderFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.filterOrderSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.filterOrderFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}