import {
    SET_CANCEL_FLAG_FETCH,
    SET_CANCEL_FLAG_SUCCESS,
    SET_CANCEL_FLAG_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setCancelFlagFetch = createStandardAction(SET_CANCEL_FLAG_FETCH)<{cancelFlag: boolean}>();
export const setCancelFlagSuccess = createStandardAction(SET_CANCEL_FLAG_SUCCESS)<boolean>();
export const setCancelFlagFail = createStandardAction(SET_CANCEL_FLAG_FAIL)<string>();

