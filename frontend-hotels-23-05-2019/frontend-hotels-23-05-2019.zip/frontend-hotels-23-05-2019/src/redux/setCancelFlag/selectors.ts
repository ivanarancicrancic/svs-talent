import { IRootState } from '..'

export const getCancelFlag = (state: IRootState) => state.cancelFlag.data;
export const getCancelFlagLoading = (state: IRootState) => state.cancelFlag.loading;
export const getCancelFlagHasError = (state: IRootState) => state.cancelFlag.error;