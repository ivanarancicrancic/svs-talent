export const SET_DATE_FROM_FETCH = '@@user/set/dateFromTo/FETCH';
export const SET_DATE_FROM_SUCCESS = '@@user/set/dateFromTo/SUCCESS';
export const SET_DATE_FROM_FAIL = '@@user/set/dateFromTo/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}


