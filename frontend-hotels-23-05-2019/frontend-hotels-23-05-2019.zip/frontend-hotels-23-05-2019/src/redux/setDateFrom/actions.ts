import {
    SET_DATE_FROM_FETCH,
    SET_DATE_FROM_SUCCESS,
    SET_DATE_FROM_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const setDateFromFetch = createStandardAction(SET_DATE_FROM_FETCH)<{newDateFrom: Date}>();
export const setDateFromSuccess = createStandardAction(SET_DATE_FROM_SUCCESS)<Date>();
export const setDateFromFail = createStandardAction(SET_DATE_FROM_FAIL)<string>();

