import { createLogic } from 'redux-logic';
import { ORDER_SAVE_FETCH, IOrderArticleNetPriceRequestModel, IOrderArticleGrossPriceRequestModel } from './types';
import { orderSaveFetch, orderSaveFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { IRootState } from '..';
import { IOrderArticleQuantityRequestModel } from '../addGrossPriceToList/types';

export const orderSaveFetchLogic = createLogic({
    type: ORDER_SAVE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(orderSaveFetch)(action)) {
            if((getState() as IRootState).hotelDetail.data){
                const ordereNetPrice = (getState() as IRootState).recalculatedOrderNetPrice.data;
                if(ordereNetPrice){
                    // const finNetPrice =  parseInt((getState() as IRootState).recalculatedOrderNetPrice.data,10);
                    // const finGrossPrice =  parseInt((getState() as IRootState).recalculatedOrderGrossPrice.data,10);      
                    const listNetPrices = (getState() as IRootState).listNetPrices.data;
                    const listGrossPrices = (getState() as IRootState).listGrossPrices.data;
                    const listQuantities = (getState() as IRootState).listQuantities.data;
                    if((getState() as IRootState).hotelDetail.data){
                        const listOderArticles = (getState() as IRootState).hotelArticles.data;
                        // const valid1 = true;             
                        // let valid = true;
                        if(listOderArticles){ 
                            listOderArticles.map((orAr, index)=>
                             {
                                // const valid2 = true;
                                // const valid3 = true;
                                const item = listQuantities[index];
                                const orderArticle = orAr.orArId;
                                const NEW_QUANTITY_VALUE: IOrderArticleQuantityRequestModel = {
                                    quantity: item,
                                    orArId: orderArticle
                                }
                                    fetch('http://localhost:8080/DecrementArticlesQuantityServlet', {
                                    method: 'POST',
                                    body: JSON.stringify({ newQuantityValue: NEW_QUANTITY_VALUE })
                                })
                                .then(response => 
                                   { if(response.status === 200) {
                                    console.log("Response status: " + response.status);  
                                    response.json()}
                                     else {  
                                    throw new Error('Database update couldnt be processed fully, because of invalid inputs. Check your inputs validation.');    
                                    const item1 = listNetPrices[index];
                                    const orderArticle1 = orAr.orArId;
                                    const NEW_NET_PRICE_VALUE: IOrderArticleNetPriceRequestModel = {
                                        netPrice: item1,
                                        orArId: orderArticle1
                                    }
                                    const item2 = listGrossPrices[index];
                                    const NEW_GROSS_PRICE_VALUE: IOrderArticleGrossPriceRequestModel = {
                                        grossPrice: item2,
                                        orArId: orderArticle1
                                    }
                                   
                                    fetch('http://localhost:8080/ersatzteilhandel24apiValid/UpdateNetPrice', {
                                        method: 'POST',
                                        body: JSON.stringify({ newNetPriceValue: NEW_NET_PRICE_VALUE })
                                    })
                                    .then(response1 => {
                                                fetch('http://localhost:8080/ersatzteilhandel24apiValid/UpdateGrossPrice', {
                                                    method: 'POST',
                                                    body: JSON.stringify({ newGrossPriceValue: NEW_GROSS_PRICE_VALUE })
                                                }) 
                                                .catch(error =>  {
                                                    dispatch(orderSaveFail("fail"))
                                                });
                                       })
                                       .catch(error =>  {
                                        dispatch(orderSaveFail("fail")) 
                                });   
                                        }
                                })
                                // .then(ok => {
                                //     const item1 = listNetPrices[index];
                                //     const orderArticle1 = orAr.orArId;
                                //     const NEW_NET_PRICE_VALUE: IOrderArticleNetPriceRequestModel = {
                                //         netPrice: item1,
                                //         orArId: orderArticle1
                                //     }
                                //     const item2 = listGrossPrices[index];
                                //     const NEW_GROSS_PRICE_VALUE: IOrderArticleGrossPriceRequestModel = {
                                //         grossPrice: item2,
                                //         orArId: orderArticle1
                                //     }
                                //     fetch('http://localhost:8080/ersatzteilhandel24apiValid/UpdateNetPrice', {
                                //         method: 'POST',
                                //         body: JSON.stringify({ newNetPriceValue: NEW_NET_PRICE_VALUE })
                                //     })
                                //     .then(response => {
                                //         if(response.status === 200) {
                                //             response.json()}
                                //              else {  
                                //                  console.log("UpdateNetPrice response.status != 200");
                                //                  valid = false;
                                //                  throw new Error('Database update couldnt be processed fully, because of invalid inputs. Check your inputs validation.'); 
                                //                 fetch('http://localhost:8080/ersatzteilhandel24apiValid/UpdateGrossPrice', {
                                //                     method: 'POST',
                                //                     body: JSON.stringify({ newGrossPriceValue: NEW_GROSS_PRICE_VALUE })
                                //                 }) 
                                //                 .catch(error =>  {
                                //                     dispatch(orderSaveFail("fail"))
                                //                  });
                                //             }
                                //     })
                                //     .then(data2 => {
                                //         fetch('http://localhost:8080/ersatzteilhandel24apiValid/UpdateGrossPrice', {
                                //             method: 'POST',
                                //             body: JSON.stringify({ newGrossPriceValue: NEW_GROSS_PRICE_VALUE })
                                //         })
                                       
                                //         .then(response => {
                                //             if(response.status === 200) {
                                //                 response.json()}
                                //                  else {  
                                //                      console.log("UpdateGrossPrice response.status != 200");
                                //                      valid = false;
                                //                      throw new Error('Database update couldnt be processed fully, because of invalid inputs. Check your inputs validation.'); 
                                //                 }
                                //         })


                                //         .then(data3 => {
                                //             if((getState() as IRootState).hotelDetail){
                                //                 const hotelDetail = (getState() as IRootState).hotelDetail.data;
                                //                 if(hotelDetail){
                                //                     const newValues: IOrderSaveRequestModel = {
                                //                         id: hotelDetail.id,
                                //                         name: hotelDetail.name,
                                //                         description: hotelDetail.description
                                //                     }
                                //                     fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderSave', {
                                //                         method: 'POST',
                                //                         body: JSON.stringify({
                                //                             orderToSave: newValues
                                //                         })
                                //                     })
                                //                     .then(response => response.json())
                                //                     .then(data => {
                                //                         if(valid2 === valid3){
                                //                         const result = data as IOrderDetailResponseModel;
                                //                         dispatch(orderSaveSuccess(result));
                                //                         } 
                                //                     })
                                //                     .then(data => {
                                //                         if(valid2 === valid3){
                                //                         dispatch(getHotelArticlesFetch({hotelId: hotelDetail.id})); 
                                //                         }
                                //                     })
                                //                     .then(data => {     
                                //                             dispatch(hotelListFetch());   
                                //                     })
                                //                     .then(data => {
                                //                         if(valid === valid1){
                                //                             if(valid2 === valid3){
                                //                         history.push(`/start`); 
                                //                             }
                                //                             else { throw new Error('Database update was not ok.'); }
                                //                         }
                                //                         else{ throw new Error('Database update was not ok.'); }
                                                      
                                //                     })
                                              
                                //                 }  
                                //             }
                                //         })
                                //         .catch(error =>  {
                                //             valid = false;
                                //             console.log("should be called history.push(unsuccessfulldb) 1");
                                //             history.push(`/unsuccessfulldb`);  
                                //             dispatch(orderSaveFail("fail"))
                                //             if((getState() as IRootState).hotelDetail){
                                //                 const hotelDetail = (getState() as IRootState).hotelDetail.data;
                                //                 if(hotelDetail){
                                //                     const newValues: IOrderSaveRequestModel = {
                                //                         id: hotelDetail.id,
                                //                         name: hotelDetail.name,
                                //                         description: hotelDetail.description
                                //                     }
                                //                     fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderSave', {
                                //                         method: 'POST',
                                //                         body: JSON.stringify({
                                //                             orderToSave: newValues
                                //                         })
                                //                     })
                                //                     .then(response => response.json())
                                //                     .then(data => {
                                //                         if(valid2 === valid3){
                                //                         const result = data as IOrderDetailResponseModel;
                                //                         dispatch(orderSaveSuccess(result));
                                //                         } 
                                //                     });
                                //                 }  
                                //             }
                                            
                                //     });

                                //     })
                                //     .catch(error =>  {
                                //         valid = false;
                                //         console.log("should be called history.push(unsuccessfulldb) 1");
                                //         history.push(`/unsuccessfulldb`);  
                                //         dispatch(orderSaveFail("fail"))
                                //         if((getState() as IRootState).hotelDetail){
                                //             const hotelDetail = (getState() as IRootState).hotelDetail.data;
                                //             if(hotelDetail){
                                //                 const newValues: IOrderSaveRequestModel = {
                                //                     id: hotelDetail.id, 
                                //                     name: hotelDetail.name, 
                                //                     description: hotelDetail.description
                                //                 }
                                //                 fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderSave', {
                                //                     method: 'POST',
                                //                     body: JSON.stringify({
                                //                         orderToSave: newValues
                                //                     })
                                //                 })
                                //                 .then(response => response.json())
                                //                 .then(data => {
                                //                     if(valid2 === valid3){
                                //                     const result = data as IOrderDetailResponseModel;
                                //                     dispatch(orderSaveSuccess(result));
                                //                     } 
                                //                 });
                                //             }  
                                //         }
                                        
                                // });

                                // })
                            // .catch(error =>  {
                            //                                 valid = false;
                            //                                 console.log("should be called history.push(unsuccessfulldb)");
                            //                                 history.push(`/unsuccessfulldb`);  
                            //                                 dispatch(orderSaveFail("fail"))
                            //                                 if((getState() as IRootState).hotelDetail){
                            //                                     const hotelDetail = (getState() as IRootState).hotelDetail.data;
                            //                                     if(hotelDetail){
                            //                                         const newValues: IOrderSaveRequestModel = {
                            //                                             id: hotelDetail.id, 
                            //                                             name: hotelDetail.name, 
                            //                                             description: hotelDetail.description
                            //                                         }
                            //                                         fetch('http://localhost:8080/ersatzteilhandel24apiValid/OrderSave', {
                            //                                             method: 'POST',
                            //                                             body: JSON.stringify({
                            //                                                 orderToSave: newValues
                            //                                             })
                            //                                         })
                            //                                         .then(response => response.json())
                            //                                         .then(data => {
                            //                                             if(valid2 === valid3){
                            //                                             const result = data as IOrderDetailResponseModel;
                            //                                             dispatch(orderSaveSuccess(result));
                            //                                             } 
                            //                                         });
                            //                                     }  
                            //                                 }
                                                            
                            //                         });
                            });
                        }
                    }       
                } else 
                {
                    done();
                }
            }
        }
    }
});

export default [
    orderSaveFetchLogic
];
