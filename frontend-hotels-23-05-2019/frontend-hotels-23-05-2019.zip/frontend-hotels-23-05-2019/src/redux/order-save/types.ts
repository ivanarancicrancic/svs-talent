export const ORDER_SAVE_FETCH = '@@user/order/save/FETCH';
export const ORDER_SAVE_SUCCESS = '@@user/order/save/SUCCESS';
export const ORDER_SAVE_FAIL = '@@user/order/save/FAIL';


export interface IOrderDetailResponseModel {
    order_id: string;
    orderDate: string;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};



export interface IOrderSaveRequestModel {
    order_id: string;
    orderDate: Date;
    paymentMethod: string;
    shippingWay: string;
    anrede: string;
    firstName: string;
    lastName: string;
    companyName: string;  
    country: string;
    street: string;
    houseNumber: string;
    city: string;
    postcode: string;
    phoneNumber: string; 
    email: string; 
    latest: number;
    netPrice: string;
    grossPrice: string;
    netPriceWD:  string;
    grossPriceWD: string; 
};

export interface IOrderArticleNetPriceRequestModel {
    netPrice: string;
    orArId: string;
}

export interface IOrderArticleGrossPriceRequestModel {
    grossPrice: string;
    orArId: string;
   

}