import { IRootState } from '..'

export const getCurrentIndex = (state: IRootState) => state.currentIndex.data;
export const getCurrentIndexLoading = (state: IRootState) => state.currentIndex.loading;
export const getCurrentIndexHasError = (state: IRootState) => state.currentIndex.error;