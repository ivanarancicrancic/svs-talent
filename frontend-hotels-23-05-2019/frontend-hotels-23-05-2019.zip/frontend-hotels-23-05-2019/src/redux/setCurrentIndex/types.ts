export const SET_CURRENT_INDEX_FETCH = '@@user/set/currentIndex/FETCH';
export const SET_CURRENT_INDEX_SUCCESS = '@@user/set/currentIndex/SUCCESS';
export const SET_CURRENT_INDEX_FAIL = '@@user/set/currentIndex/FAIL';

export interface IOrderArticleResponseModel {
    orArId: string;
    orders_id: string;
    articleName: string;
    articleDescription: string;
    articlePromotion: string;
    articleQuantity: string;
};

export interface IOrderArticleQuantityRequestModel {
    orArId: string;
    quantity: string;

}
