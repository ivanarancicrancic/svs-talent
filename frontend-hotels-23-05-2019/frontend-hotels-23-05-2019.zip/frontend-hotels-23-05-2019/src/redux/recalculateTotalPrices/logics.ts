import { createLogic } from 'redux-logic';
import { RECALCULATE_TOTAL_PRICES_FETCH, ITotalPrices } from './types';
import { recalculateTotalPricesFetch, recalculateTotalPricesSuccess } from './actions';
import { isActionOf } from 'typesafe-actions';

export const recalculateTotalPricesFetchLogic = createLogic({
    type: RECALCULATE_TOTAL_PRICES_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(recalculateTotalPricesFetch)(action)){ 
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/RecalculateTotalPricesServlet')
            .then(response => response.json())
            .then(data => {
                dispatch(recalculateTotalPricesSuccess(data as ITotalPrices));          
            })   
        }
    }
});

export default [
    recalculateTotalPricesFetchLogic
];
