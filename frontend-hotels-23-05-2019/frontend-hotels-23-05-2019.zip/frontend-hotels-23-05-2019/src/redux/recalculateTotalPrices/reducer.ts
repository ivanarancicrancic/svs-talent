import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { ITotalPrices } from './types';


const extActions = {...actions};

export type RecalculateTotalPricesActions = ActionType<typeof extActions>;

export interface IRecalculateTotalPricesState {
    readonly data: ITotalPrices;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const startValues: ITotalPrices = {
    netPrice: 0,
    grossPrice: 0,
    netPriceWD: 0,
    grossPriceWD: 0
}

const INITIAL_STATE: IRecalculateTotalPricesState = {
    data: startValues,
    loading: false,
    error: null
};
  
export function recalculateTotalPricesReducer(state: IRecalculateTotalPricesState = INITIAL_STATE, action: RecalculateTotalPricesActions): IRecalculateTotalPricesState  {
    switch (action.type) {
        case getType(extActions.recalculateTotalPricesFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.recalculateTotalPricesSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.recalculateTotalPricesFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}