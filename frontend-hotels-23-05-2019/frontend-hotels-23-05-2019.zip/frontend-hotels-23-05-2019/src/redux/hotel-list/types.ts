export const HOTEL_LIST_FETCH = '@@user/hotel/list/FETCH';
export const HOTEL_LIST_SUCCESS = '@@user/hotel/list/SUCCESS';
export const HOTEL_LIST_FAIL = '@@user/hotel/list/FAIL';

export interface IHotelResponseModel {
    id: string;
    name: string;
    description: string;
};