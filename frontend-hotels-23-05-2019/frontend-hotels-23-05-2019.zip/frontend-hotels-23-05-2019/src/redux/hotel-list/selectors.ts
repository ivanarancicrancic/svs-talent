import { IRootState } from '..'

export const getHotelList = (state: IRootState) => state.hotelList.data;
export const getHotelListIsLoading = (state: IRootState) => state.hotelList.loading;
export const getHotelListHasError = (state: IRootState) => state.hotelList.error;