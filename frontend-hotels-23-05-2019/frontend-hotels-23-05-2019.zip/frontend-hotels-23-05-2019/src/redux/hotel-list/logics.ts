import { createLogic } from 'redux-logic';
import { HOTEL_LIST_FETCH, IHotelResponseModel } from './types';
import { hotelListFetch, hotelListSuccess, hotelListFail } from './actions';
import { isActionOf } from 'typesafe-actions';

export const hotelListFetchLogic = createLogic({
    type: HOTEL_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(hotelListFetch)(action)) {
            fetch('http://localhost:8080/api/admin/hotels')
            .then(response => response.json())
            .then(data => {
            dispatch(hotelListSuccess(data as IHotelResponseModel[]));
              })
            .catch(error =>
                {  
                    console.log("ERROR WITH FETCH API");
                     dispatch(hotelListFail("fail"))
                });
        } else {
            done();
        }
    }
});

export default [
    hotelListFetchLogic
];
