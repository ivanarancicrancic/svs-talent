import { ActionType, getType } from 'typesafe-actions';
import { IHotelResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type HotelListActions = ActionType<typeof extActions>;

export interface IHotelListState {
    readonly data: IHotelResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IHotelListState = {
    data: null,
    loading: false,
    error: null
};
  
export function hotelListReducer(state: IHotelListState = INITIAL_STATE, action: HotelListActions): IHotelListState  {
    switch (action.type) {
        case getType(extActions.hotelListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.hotelListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.hotelListFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}