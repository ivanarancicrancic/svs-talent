import {
    HOTEL_LIST_FETCH,
    HOTEL_LIST_SUCCESS,
    HOTEL_LIST_FAIL,
    IHotelResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const hotelListFetch = createStandardAction(HOTEL_LIST_FETCH)();
export const hotelListSuccess = createStandardAction(HOTEL_LIST_SUCCESS)<IHotelResponseModel[]>();
export const hotelListFail = createStandardAction(HOTEL_LIST_FAIL)<string>();
