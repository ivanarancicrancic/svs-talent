import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { IFilteredOrderState, FilterOrderActions, filterOrderReducer } from './filterOrders/reducer';
import { IHotelDetailState, HotelDetailActions, hotelDetailReducer } from './order-detail/reducer';
import { IHotelArticlesState, GetHotelArtictlesActions, getHotelArticlesReducer } from './order-articles/reducer';
import { IOrderSaveState, OrderSaveActions, orderSaveReducer } from './order-save/reducer';
import { orderCancelReducer, OrderCancelActions, IOrderDetailState } from './cancelOrders/reducer';
import { IDeleteArticleFromOrderState, DeleteArticleFromOrderActions, deleteArticleFromOrderReducer } from './delete-article/reducer';
import { formsReducer } from './forms';
import { addQuantityToListReducer, AddQuantityToListActions, IAddQuantityToListState } from './addQuantityToList/reducer';
import { ISetCurrentIndexState, setCurrentIndexReducer, SetCurrentIndexActions } from './setCurrentIndex/reducer';
import { IAddNetPriceToListState, AddNetPriceToListActions, addNetPriceToListReducer } from './addNetPriceToList/reducer';
import { IAddGrossPriceToListState, AddGrossPriceToListActions, addGrosstPriceToListReducer } from './addGrossPriceToList/reducer';
import { ISetModal3IsOpenState, SetModal3IsOpenActions, setModal3IsOpenReducer } from './setModal3IsOpen/reducer';
import { IRecalculateOrderNetPriceState, RecalculateOrderNetPriceActions, recalculateOrderNetPriceReducer } from './recalculateOrderNetPrice/reducer';
import { IRecalculateOrderGrossPriceState, RecalculateOrderGrossPriceActions, recalculateOrderGrossPriceReducer } from './recalculateOrderGrossPrice/reducer';
import { ISetDateFromState, setDateFromReducer, SetDateFromStateActions } from './setDateFrom/reducer';
import { ISetDateToState, SetDateToStateActions, setDateToReducer } from './setDateTo/reducer';
import { setCancelFlagReducer, SetCancelFlagActions, ISetCancelFlagState } from './setCancelFlag/reducer';
import { IRecalculateTotalPricesState, RecalculateTotalPricesActions, recalculateTotalPricesReducer } from './recalculateTotalPrices/reducer';
import { IRecalculateFilteredTotalPricesState, RecalculateFilteredTotalPricesActions, recalculateFilteredTotalPricesReducer } from './recalculateFilteredOrdersTotalPrices/reducer';
import { IImageUploadState, ImageUploadActions, imageUploadReducer } from './imageUpload/reducer';
import { IPictureUrlState, SetPictureUrlActions, setPictureUrlFetchReducer } from './setPictureUrl/reducer';
import { IHotelListState, HotelListActions, hotelListReducer } from './hotel-list/reducer';
import { ICaptchaState, CaptchaActions, captchaReducer } from './captcha/reducer';
import { IAuthState, AuthActions, authReducer } from './auth/reducer';
import { registerReducer, IRegistrationState } from './register/reducer';

export interface IRootState {
    router: RouterState;
    // orderList: IOrderListState;
    filteredOrders: IFilteredOrderState;
    hotelDetail: IHotelDetailState;
    savedOrder: IOrderSaveState;
    hotelArticles: IHotelArticlesState;
    canceledOrder: IOrderDetailState;  
    forms: any;
    orderWithDeletedArticle: IDeleteArticleFromOrderState;
    listQuantities: IAddQuantityToListState;
    currentIndex: ISetCurrentIndexState;
    listNetPrices: IAddNetPriceToListState;
    listGrossPrices: IAddGrossPriceToListState;
    modal3IsOpen: ISetModal3IsOpenState;
    recalculatedOrderNetPrice: IRecalculateOrderNetPriceState;
    recalculatedOrderGrossPrice: IRecalculateOrderGrossPriceState;
    dateFrom: ISetDateFromState;
    dateTo: ISetDateToState;
    cancelFlag: ISetCancelFlagState;
    recalculatedTotalPrices: IRecalculateTotalPricesState;
    recalculatedFilteredTotalPrices: IRecalculateFilteredTotalPricesState;
    uploadImage: IImageUploadState;
    pictureUrl: IPictureUrlState;
    hotelList: IHotelListState;
    captcha: ICaptchaState;
    auth: IAuthState;
    register: IRegistrationState;
}

export type RootAction = RouterAction
    | LocationChangeAction
    // | OrderListActions
    | FilterOrderActions 
    | HotelDetailActions
    | GetHotelArtictlesActions
    | OrderSaveActions
    | OrderCancelActions
    | DeleteArticleFromOrderActions
    | AddQuantityToListActions
    | SetCurrentIndexActions
    | AddNetPriceToListActions
    | AddGrossPriceToListActions
    | SetModal3IsOpenActions
    | RecalculateOrderNetPriceActions
    | RecalculateOrderGrossPriceActions
    | SetDateFromStateActions
    | SetDateToStateActions
    | SetCancelFlagActions
    | RecalculateTotalPricesActions
    | RecalculateFilteredTotalPricesActions
    | ImageUploadActions
    | SetPictureUrlActions
    | HotelListActions
    | AuthActions
    | CaptchaActions



export const reducers = combineReducers<IRootState>({
    router: routerReducer, 
    // orderList: orderListReducer,
    filteredOrders: filterOrderReducer,
    hotelDetail: hotelDetailReducer,
    savedOrder: orderSaveReducer,
    hotelArticles: getHotelArticlesReducer,
    canceledOrder: orderCancelReducer,
    forms: formsReducer,
    orderWithDeletedArticle: deleteArticleFromOrderReducer,
    listQuantities: addQuantityToListReducer,
    currentIndex: setCurrentIndexReducer,
    listNetPrices: addNetPriceToListReducer,
    listGrossPrices: addGrosstPriceToListReducer,
    modal3IsOpen: setModal3IsOpenReducer,
    recalculatedOrderNetPrice: recalculateOrderNetPriceReducer,
    recalculatedOrderGrossPrice: recalculateOrderGrossPriceReducer,
    dateFrom: setDateFromReducer,
    dateTo: setDateToReducer,
    cancelFlag: setCancelFlagReducer,
    recalculatedTotalPrices: recalculateTotalPricesReducer,
    recalculatedFilteredTotalPrices: recalculateFilteredTotalPricesReducer,
    uploadImage: imageUploadReducer,
    pictureUrl: setPictureUrlFetchReducer,
    hotelList: hotelListReducer,
    captcha: captchaReducer,
    auth: authReducer,
    register: registerReducer,
});