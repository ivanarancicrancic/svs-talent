import { IRootState } from '..'

export const getRecalculatedOrderNetPrice = (state: IRootState) => state.recalculatedOrderNetPrice.data;
export const getRecalculatedOrderNetPriceLoading = (state: IRootState) => state.recalculatedOrderNetPrice.loading;
export const getRecalculatedOrderNetPriceHasError = (state: IRootState) => state.recalculatedOrderNetPrice.error;