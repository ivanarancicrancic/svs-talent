export const RECALCULATE_ORDER_NET_PRICE_FETCH = '@@user/recalculate/orderNetPrice/FETCH';
export const RECALCULATE_ORDER_NET_PRICE_SUCCESS = '@@user/recalculate/orderNetPrice/SUCCESS';
export const RECALCULATE_ORDER_NET_PRICE_FAIL = '@@user/recalculate/orderNetPrice/FAIL';
