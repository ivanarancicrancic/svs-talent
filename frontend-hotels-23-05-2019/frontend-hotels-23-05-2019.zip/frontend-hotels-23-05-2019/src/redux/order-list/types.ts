export const HOTEL_LIST_FETCH = '@@user/hotel/list/FETCH';
export const HOTEL_LIST_SUCCESS = '@@user/hotel/list/SUCCESS';
export const HOTEL_LIST_FAIL = '@@user/hotel/list/FAIL';

export interface IHotelResponseModel {

    hotel_id: string;
    hotelName: string;
    description: string;
};