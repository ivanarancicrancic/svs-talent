
import { routerMiddleware } from 'react-router-redux';
import { applyMiddleware, createStore, compose } from 'redux';

import thunk from 'redux-thunk';
import { createLogicMiddleware } from 'redux-logic';

import { persistStore, persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

import { reducers } from '.';
import { history } from '../router';

// import orderListLogics from './order-list/logics';
import filterOrderFetchLogic from './filterOrders/logics';
import { orderDetailFetchLogic } from './order-detail/logics';
import { getHotelArticlesFetchLogic } from './order-articles/logics';
import { orderSaveFetchLogic } from './order-save/logics';
import { cancelOrderFetchLogic } from './cancelOrders/logics';
import { deleteArticleFromOrderFetchLogic } from './delete-article/logics';
import { addQuantityToListFetchLogic } from './addQuantityToList/logics';
import { setCurrentIndexFetchLogic } from './setCurrentIndex/logics';
import { addNetPriceToListFetchLogic } from './addNetPriceToList/logics';
import { addGrossPriceToListFetchLogic } from './addGrossPriceToList/logics';
import { setModal3IsOpenFetchLogic } from './setModal3IsOpen/logics';
import { recalculateOrderNetPriceFetchLogic } from './recalculateOrderNetPrice/logics';
import { recalculateOrderGrossPriceFetchLogic } from './recalculateOrderGrossPrice/logics';
import { setDateToFetchLogic } from './setDateTo/logics';
import { setDateFromFetchLogic } from './setDateFrom/logics';
import { setCancelFlagLogic } from './setCancelFlag/logics';
import { recalculateTotalPricesFetchLogic } from './recalculateTotalPrices/logics';
import { recalculateFilteredTotalPricesFetchLogic } from './recalculateFilteredOrdersTotalPrices/logics';
import { imageUploadFetchLogic } from './imageUpload/logics';
import { setPictureUrlFetchLogic } from './setPictureUrl/logics';
import { hotelListFetchLogic } from './hotel-list/logics';

import authLogics from './auth/logics';
import userRegisterLogics from './register/logics';
import captchaLogics from './captcha/logics';

const persistConfig = {
    key: 'root',
    storage,
    whitelist: ['auth']
};

const persistedReducer = persistReducer(persistConfig, reducers);

const composeEnhancers = (
    process.env.NODE_ENV === 'development' && window && (window as any).__REDUX_DEVTOOLS_EXTENSION_COMPOSE__
  ) || compose;

const logicMiddleware = createLogicMiddleware([
    // ...orderListLogics,
    ...filterOrderFetchLogic,
    ...orderDetailFetchLogic,
    ...getHotelArticlesFetchLogic,
    ...orderSaveFetchLogic,
    ...cancelOrderFetchLogic,
    ...deleteArticleFromOrderFetchLogic,
    ...addQuantityToListFetchLogic,
    ...setCurrentIndexFetchLogic,
    ...addNetPriceToListFetchLogic,
    ...addGrossPriceToListFetchLogic,
    ...setModal3IsOpenFetchLogic,
    ...recalculateOrderNetPriceFetchLogic,
    ...recalculateOrderGrossPriceFetchLogic,
    ...setDateToFetchLogic,
    ...setDateFromFetchLogic,
    ...setCancelFlagLogic,
    ...recalculateTotalPricesFetchLogic,
    ...recalculateFilteredTotalPricesFetchLogic,
    ...imageUploadFetchLogic,
    ...setPictureUrlFetchLogic,
    ...hotelListFetchLogic,
    ...authLogics,
    ...userRegisterLogics,
    ...captchaLogics
], {});

const enhancer = composeEnhancers(
    applyMiddleware(routerMiddleware(history), thunk, logicMiddleware)
);

export const store = createStore(persistedReducer, {}, enhancer);
export const persistor = persistStore(store);

