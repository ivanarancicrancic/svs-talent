import { IRootState } from '..'

export const getGrossPriceList = (state: IRootState) => state.listGrossPrices.data;
export const getGrossPriceListLoading = (state: IRootState) => state.listGrossPrices.loading;
export const getGrossPriceListHasError = (state: IRootState) => state.listGrossPrices.error;