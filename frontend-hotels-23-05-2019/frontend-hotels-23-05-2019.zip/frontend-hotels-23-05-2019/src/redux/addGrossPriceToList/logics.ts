import { createLogic } from 'redux-logic';
import { ADD_GROSS_PRICE_TO_LIST_FETCH } from './types';
import { addGrossPriceToListFetch, addGrossPriceToListSuccess } from './actions';
import { IRootState } from '../../redux';
import { isActionOf } from 'typesafe-actions';

export const addGrossPriceToListFetchLogic = createLogic({
    type: ADD_GROSS_PRICE_TO_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(addGrossPriceToListFetch)(action)) {
            let result = (getState() as IRootState).listGrossPrices.data;
            if(action.payload.indexList === -1){
                result = [];
                dispatch(addGrossPriceToListSuccess(result));
            }
            else{
                if(action.payload.pushFlag === true){ 
                    result.push(action.payload.newGrossPriceValue);  
                    dispatch(addGrossPriceToListSuccess(result));       
                }
                else{
                    if(result){
                        result.splice(action.payload.indexList, 1, action.payload.newGrossPriceValue);
                    }
                    dispatch(addGrossPriceToListSuccess(result));   
                }    
            }         
        } 
        else{
            done();
        }
    }
});

export default [
    addGrossPriceToListFetchLogic
];
