import { createLogic } from 'redux-logic';
import { IOrderDetailResponseModel, DELETE_ARTICLE_FROM_ORDER_FETCH } from './types';
import { deleteArticleFromOrderFetch, deleteArticleFromOrderSuccess, deleteArticleFromOrderFail } from './actions';
import { isActionOf } from 'typesafe-actions';
// import { setModal3IsOpenFetch } from '../setModal3IsOpen/actions';
// import { IRootState } from '..';
import { history } from '../../router';

export const deleteArticleFromOrderFetchLogic = createLogic({
    type: DELETE_ARTICLE_FROM_ORDER_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(deleteArticleFromOrderFetch)(action)) {
            fetch('http://localhost:8080/ersatzteilhandel24apiValid/DeleteArticleFromOrderServlet', {
                method: 'POST',
                body: JSON.stringify({
                    orArId: action.payload.orArId,
                })
              })
            .then(response => response.json())
            .then(data => {
            const result = data as IOrderDetailResponseModel;
            dispatch(deleteArticleFromOrderSuccess(result));
              })
            // .then(data => {
            //     if((getState() as IRootState).orderDetail.data){
            //         dispatch(setModal3IsOpenFetch({modal3IsOpen: false}));
                 
            //     }
            // })
            .then(data => {
                history.push(`/start`);
            })
            .catch(error =>  dispatch(deleteArticleFromOrderFail("fail"))); 
        } 
        else {
            done();
        }
    }
});

export default [
    deleteArticleFromOrderFetchLogic
];
