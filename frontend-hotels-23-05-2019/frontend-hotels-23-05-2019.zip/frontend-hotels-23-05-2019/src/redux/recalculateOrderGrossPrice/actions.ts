import {
    RECALCULATE_ORDER_GROSS_PRICE_FETCH,
    RECALCULATE_ORDER_GROSS_PRICE_SUCCESS,
    RECALCULATE_ORDER_GROSS_PRICE_FAIL
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const recalculateOrderGrossPriceFetch = createStandardAction(RECALCULATE_ORDER_GROSS_PRICE_FETCH)<{flagStart: boolean}>();
export const recalculateOrderGrossPriceSuccess = createStandardAction(RECALCULATE_ORDER_GROSS_PRICE_SUCCESS)<string>();
export const recalculateOrderGrossPriceFail = createStandardAction(RECALCULATE_ORDER_GROSS_PRICE_FAIL)<string>();

