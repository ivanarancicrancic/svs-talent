export const RECALCULATE_ORDER_GROSS_PRICE_FETCH = '@@user/recalculate/orderGrossPrice/FETCH';
export const RECALCULATE_ORDER_GROSS_PRICE_SUCCESS = '@@user/recalculate/orderGrossPrice/SUCCESS';
export const RECALCULATE_ORDER_GROSS_PRICE_FAIL = '@@user/recalculate/orderGrossPrice/FAIL';
