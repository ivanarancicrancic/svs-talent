import { createLogic } from 'redux-logic';
import { RECALCULATE_ORDER_GROSS_PRICE_FETCH } from './types';
// import { recalculateOrderGrossPriceFetch, recalculateOrderGrossPriceSuccess } from './actions';
// import { IRootState } from '../../redux';
// import { isActionOf } from 'typesafe-actions';

export const recalculateOrderGrossPriceFetchLogic = createLogic({
    type: RECALCULATE_ORDER_GROSS_PRICE_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
    
    console.log("Entered here!");
        // if((getState() as IRootState).orderDetail.data){
        //     const orderGrossPrice = (getState() as IRootState).orderDetail.data;
        //       if(orderGrossPrice){
        //     if(action.payload.flagStart){
        //         const result = orderGrossPrice.grossPrice.toString();
        //         dispatch(recalculateOrderGrossPriceSuccess(result));        
        //     }
        //      else{
        //         let finGrossPrice =  parseInt(orderGrossPrice.grossPrice,10);
        //         if (isActionOf(recalculateOrderGrossPriceFetch)(action)) {
        //             const listGrossPrices = (getState() as IRootState).listGrossPrices.data;
        //             const listQuantities = (getState() as IRootState).listQuantities.data;
        //             if((getState() as IRootState).orderDetail.data){
        //                 const listOderArticles = (getState() as IRootState).orderArticles.data;
        //                 if(listOderArticles){ 
        //                     listOderArticles.map( (orAr, index)=> {
        //                         if((parseInt(listGrossPrices[index],10) > 0) && (parseInt(listQuantities[index],10) > 0))
        //                        {                                
        //                         finGrossPrice = finGrossPrice - parseInt(orAr.articleGrossPrice,10) * parseInt(orAr.articleQuantity,10); 
        //                         finGrossPrice = finGrossPrice + parseInt(listGrossPrices[index],10) * parseInt(listQuantities[index],10);
        //                        }
        //                     });
        //                 }
        //             }
        //             const result = finGrossPrice.toString();
        //             dispatch(recalculateOrderGrossPriceSuccess(result));     
        //         } else {
        //             done();
        //         }
        //     }
        // }
        // }
    } 
});

export default [
    recalculateOrderGrossPriceFetchLogic
];
