// import { combineForms } from 'react-redux-form';

// export interface IInfoFormData {
//     name: string;
//     package: any;
//     check: boolean;
// };

// const infoForm: IInfoFormData = {
//     name: '',
//     package: '',
//     check: false,
// }

// export const formsReducer = combineForms({
   
//     info: infoForm

// }, 'forms');



import { combineForms } from 'react-redux-form';

export interface ILoginFormData {
    username: string;
    password: string;
}

const loginForm: ILoginFormData = {
    username: '',
    password: ''
};

export interface IRegisterFormData {
    title: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    confirmPassword: string;
    phoneNumber: string;
    paymentTitle: string;
    paymentFirstName: string;
    paymentLastName: string;
    companyName: string;
    streetAddress: string;
    city: string;
    state: string;
    zipCode: string;
    country: string;
    captcha: string;
};

const registerForm: IRegisterFormData = {
    title: 'male',
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    phoneNumber: '',
    paymentTitle: 'male',
    paymentFirstName: '',
    paymentLastName: '',
    companyName: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: '',
    captcha: ''
};

export interface IForgotPasswordFormData {
    email: string;
    captcha: string;
}

const forgotPasswordForm: IForgotPasswordFormData = {
    email: '',
    captcha: ''
}

export interface IResetPasswordFormData {
    email: string;
    token: string;
    password: string;
    confirmPassword: string;
}

const resetPasswordForm: IResetPasswordFormData = {
    email: '',
    token: '',
    password: '',
    confirmPassword: ''
}

export interface IInfoFormData {
    name: string;
    package: any;
    check: boolean;
};

const infoForm: IInfoFormData = {
    name: '',
    package: '',
    check: false,
}

export interface IPanoramaFormData {
    name: string;
    type: any;
    img: any;
};

const panoramaForm: IPanoramaFormData = {
    name: '',
    type: '',
    img: '',
}

export interface IWebviewFormData {
    name: string;
    url: string;
};

const webviewForm: IWebviewFormData = {
    name: '',
    url: '',
}

export interface IAudioFormData {
    name: string;
    audio01: any;
    audio02: any;
    check: boolean;
};

const audioForm: IAudioFormData = {
    name: '',
    audio01: '',
    audio02: '',
    check: false,
}

export interface IVideoFormData {
    name: string;
    type: any;
    video01: any;
    video02: any;
    positionx: string;
    positiony: string;
    positionz: string;
    rotationx: string;
    rotationy: string;
    rotationz: string;
    scalex: string;
    scaley: string;
    scalez: string;
    check01: boolean;
    check02: boolean;
    check03: boolean;
    check04: boolean;
};

const videoForm: IVideoFormData = {
    name: '',
    type: '',
    video01: '',
    video02: '',
    positionx: '',
    positiony: '',
    positionz: '',
    rotationx: '',
    rotationy: '',
    rotationz: '',
    scalex: '',
    scaley: '',
    scalez: '',
    check01: false,
    check02: false,
    check03: false,
    check04: false,
}

export interface IUnityelemFormData {
    name: string;
    file01: any;
    file02: any;
    positionx: string;
    positiony: string;
    positionz: string;
    rotationx: string;
    rotationy: string;
    rotationz: string;
    scalex: string;
    scaley: string;
    scalez: string;
    check01: boolean;
    check02: boolean;
};

const unityelemForm: IUnityelemFormData = {
    name: '',
    file01: '',
    file02: '',
    positionx: '',
    positiony: '',
    positionz: '',
    rotationx: '',
    rotationy: '',
    rotationz: '',
    scalex: '',
    scaley: '',
    scalez: '',
    check01: false,
    check02: false,
}

export interface ISlideshowFormData {
    name: string;
    img01: any;
    img02: any;
    img03: any;
    positionx: string;
    positiony: string;
    positionz: string;
    rotationx: string;
    rotationy: string;
    rotationz: string;
    scalex: string;
    scaley: string;
    scalez: string;
    check01: boolean;
    check02: boolean;
};

const slideshowForm: ISlideshowFormData = {
    name: '',
    img01: '',
    img02: '',
    img03: '',
    positionx: '',
    positiony: '',
    positionz: '',
    rotationx: '',
    rotationy: '',
    rotationz: '',
    scalex: '',
    scaley: '',
    scalez: '',
    check01: false,
    check02: false,
}


export const formsReducer = combineForms({
    login: loginForm,
    register: registerForm,
    forgotpassword: forgotPasswordForm,
    resetpassword: resetPasswordForm,
    info: infoForm,
    panorama: panoramaForm,
    webview: webviewForm,
    audio: audioForm,
    video: videoForm,
    unityelem: unityelemForm,
    slideshow: slideshowForm,
}, 'forms');