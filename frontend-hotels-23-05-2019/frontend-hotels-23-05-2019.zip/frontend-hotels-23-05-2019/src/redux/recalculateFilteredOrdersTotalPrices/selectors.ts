import { IRootState } from '..'

export const getRecalculatedFIlteredTotalPrices = (state: IRootState) => state.recalculatedFilteredTotalPrices.data;
export const getRecalculatedFilteredTotalPricesLoading = (state: IRootState) => state.recalculatedFilteredTotalPrices.loading;
export const getRecalculatedFilteredTotalPricesHasError = (state: IRootState) => state.recalculatedFilteredTotalPrices.error;