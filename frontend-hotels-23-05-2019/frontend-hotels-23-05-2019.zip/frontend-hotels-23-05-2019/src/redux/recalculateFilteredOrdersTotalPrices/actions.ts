import {
    RECALCULATE_FILTERED_TOTAL_PRICES_FETCH,
    RECALCULATE_FILTERED_TOTAL_PRICES_SUCCESS,
    RECALCULATE_FILTERED_TOTAL_PRICES_FAIL,
    ITotalPrices
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const recalculateFilteredTotalPricesFetch = createStandardAction(RECALCULATE_FILTERED_TOTAL_PRICES_FETCH)();
export const recalculateFilteredTotalPricesSuccess = createStandardAction(RECALCULATE_FILTERED_TOTAL_PRICES_SUCCESS)<ITotalPrices>();
export const recalculateFilteredTotalPricesFail = createStandardAction(RECALCULATE_FILTERED_TOTAL_PRICES_FAIL)<string>();

