import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';
import { ITotalPrices } from './types';


const extActions = {...actions};

export type RecalculateFilteredTotalPricesActions = ActionType<typeof extActions>;

export interface IRecalculateFilteredTotalPricesState {
    readonly data: ITotalPrices;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const startValues: ITotalPrices = {
    netPrice: 0,
    grossPrice: 0,
    netPriceWD: 0,
    grossPriceWD: 0
}

const INITIAL_STATE: IRecalculateFilteredTotalPricesState = {
    data: startValues,
    loading: false,
    error: null
};
  
export function recalculateFilteredTotalPricesReducer(state: IRecalculateFilteredTotalPricesState = INITIAL_STATE, action: RecalculateFilteredTotalPricesActions): IRecalculateFilteredTotalPricesState  {
    switch (action.type) {
        case getType(extActions.recalculateFilteredTotalPricesFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.recalculateFilteredTotalPricesSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.recalculateFilteredTotalPricesFail):
            return {...state, loading: false, error: action.payload};
        default:
            return state;
    }

}