import { ActionType, getType } from 'typesafe-actions';
import { IImageResponseModel } from './types';

import * as actions from './actions';

const extActions = {...actions};

export type ImageUploadActions = ActionType<typeof extActions>;

export interface IImageUploadState {
    readonly data: IImageResponseModel | null;
    readonly loading: boolean;
    readonly error: string | null;

};
  
const INITIAL_STATE: IImageUploadState = {
    data: null,
    loading: false,
    error: null,

};
  
export function imageUploadReducer(state: IImageUploadState = INITIAL_STATE, action: ImageUploadActions): IImageUploadState  {
    switch (action.type) {
         // Image upload
         case getType(actions.imageUploadFetch):
         return {...state, loading: true};

     case getType(actions.imageUploadSuccess):
         if(state.data == null) {
             return state;
         }
         console.log("Image upload succeeded!");
         return {
             ...state,
             loading: false
         }
     case getType(actions.imageUploadFail):
         return {...state, loading: false};
        default:
            return state;
    }
}