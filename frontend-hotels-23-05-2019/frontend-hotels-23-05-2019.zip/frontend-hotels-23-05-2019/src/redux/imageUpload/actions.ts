import {
    IMAGE_UPLOAD_FAIL,
    IMAGE_UPLOAD_FETCH,
    IMAGE_UPLOAD_SUCCESS,
    IImageResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const imageUploadFetch = createStandardAction(IMAGE_UPLOAD_FETCH)<{orArId: string, data: FormData}>();
export const imageUploadSuccess = createStandardAction(IMAGE_UPLOAD_SUCCESS)<IImageResponseModel>();
export const imageUploadFail = createStandardAction(IMAGE_UPLOAD_FAIL)<string>();
