import { IRootState } from '..'

export const getUploadedImage = (state: IRootState) => state.uploadImage.data;
export const getUploadedImageLoading = (state: IRootState) => state.uploadImage.loading;
export const getUploadedImageHasError = (state: IRootState) => state.uploadImage.error;