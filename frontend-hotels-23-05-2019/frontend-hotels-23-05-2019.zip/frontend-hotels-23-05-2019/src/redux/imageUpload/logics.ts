import { createLogic } from 'redux-logic';
import { isActionOf } from 'typesafe-actions';
import { IMAGE_UPLOAD_FETCH, IImageResponseModel } from './types';
import { imageUploadFetch, imageUploadSuccess, imageUploadFail } from './actions';

export const imageUploadFetchLogic = createLogic({
    type: IMAGE_UPLOAD_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(imageUploadFetch)(action)) {
               console.log("imageUploadFetch backend api is going to be called");
               console.log("File data: " + JSON.stringify(action.payload.data));
            fetch(`http://localhost:8080/ersatzteilhandel24apiValid/orderArticle/uploadImage`, {
                method: 'POST',
                // headers: {
                //     'Content-Type': 'multipart/form-data'
                //   },
                body: JSON.stringify({
                 file: action.payload.data,
                 orArId: action.payload.orArId
                })
            })
            .then((response) => response.json())
            .then((responseJson) => {
                dispatch(imageUploadSuccess(responseJson.data as IImageResponseModel));
            })
            .catch((error) => {
                dispatch(imageUploadFail("fail"))
            });


        } else {
            done();
        }
    }
});

export default [
    imageUploadFetchLogic
];
