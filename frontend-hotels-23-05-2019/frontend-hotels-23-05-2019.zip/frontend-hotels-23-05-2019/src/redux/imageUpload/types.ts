export const IMAGE_UPLOAD_FETCH = '@@order/article/image/upload/FETCH';
export const IMAGE_UPLOAD_SUCCESS = '@@order/article/image/upload/SUCCESS';
export const IMAGE_UPLOAD_FAIL = '@@order/article/image/upload/FAIL';


// IMAGE
export interface IImageResponseModel {
    id: number;
    url: string;
}