import * as React from 'react';
import { Switch, Route } from 'react-router';
import {
    PATH_LOGIN,
    PATH_REGISTER
} from '../../router/paths';
import LoginContainer from './LoginContainer';
import RegisterContainer from './RegisterContainer';
import PostAuthHeader from '../../components/Header/PostAuthHeader';

import './PreAuthContainer.css';

export default class PreAuthContainer extends React.Component {

    public render() {
        return (
            <div className="appLoginContainer">
                <PostAuthHeader />
                <div className="appContentContainer">
                    <Switch>
                        <Route path={PATH_LOGIN} exact={true} component={LoginContainer} />
                        <Route path={PATH_REGISTER} exact={true} component={RegisterContainer} />
                      </Switch>
                </div>
            </div>
        )
    }

}