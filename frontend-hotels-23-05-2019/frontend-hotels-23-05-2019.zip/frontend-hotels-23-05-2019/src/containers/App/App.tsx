import * as React from 'react';
import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";
import { RouteComponentProps, Switch, Route } from 'react-router';
import { PATH_START, PATH_ORDER_DETAIL, PATH_ORDER_EDIT, PATH_USUCCESSFUL_DB, PATH_HOTEL_DETAIL } from '../../router/paths';
import Header from '../../components/Header/Header';
import './App.css';
import StartLayout from '../../components/StartLayout/StartLayout';
import ManageOrder from '../../components/ManageOrder/ManageOrder';
import EditOrder from '../../components/EditOrder/EditOrder';
// import FilteredOrders from '../../components/FilteredOrders/FilteredOrders';
import DatabaseNotUpdate from '../../components/DatabaseNotUpdate/DatabaseNotUpdate';

const imgUrl = 'https://gaytravel-destinations.s3.amazonaws.com/32477/hawaii-wildlife-and-beaches__large.jpg';

const sectionStyle = {
  width: "100%",
  height: "400px",
  backgroundImage: 'url(' + imgUrl + ')'
};

library.add(faEnvelope, faKey);

type IProps = RouteComponentProps<{}>;

export default class App extends React.Component<IProps> {

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer"   style={ sectionStyle }>
        <Switch>
            <Route path={PATH_START} exact={true} component={StartLayout} />
            <Route path={PATH_USUCCESSFUL_DB} exact={true} component={DatabaseNotUpdate} />
            <Route path={PATH_ORDER_DETAIL} exact={true} component={ManageOrder} />
            <Route path={PATH_ORDER_EDIT} exact={true} component={EditOrder} />
            <Route path={PATH_HOTEL_DETAIL} exact={true} component={ManageOrder} />
            {/* <Route path={PATH_FILTERED_ORDERS} exact={true} component={FilteredOrders} /> */}
           
         </Switch>
        </div>
      </div>
    );
  }
  
}


