import * as React from 'react';

import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
 
export class DemoCarousel extends React.Component {
   public render() {
        return ( 
            <Carousel>
                <div>
                    <img src="https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg" />
                    <p className="legend">Legend 1</p>
                </div>
                <div>
                    <img src="https://i.ytimg.com/vi/vfs7TdYYrGI/maxresdefault.jpg" />
                    <p className="legend">Legend 2</p>
                </div>
                <div>
                    <img src="assets/3.jpeg" />
                    <p className="legend">Legend 3</p>
                </div>
            </Carousel>
        );
    }
};