import * as React from 'react';
import './ReviewsSummary.scss';
// import content from './content';
// import { DemoCarousel } from './DemoCarousel';
import AliceCarousel from 'react-alice-carousel';
import "react-alice-carousel/lib/alice-carousel.css";
 

 export class ReviewsSummary extends React.Component {

  public responsive = {
    0: { items: 1 },
    1024: { items: 1 },
  }

  public handleOnDragStart = (e:any) => {e.preventDefault();}
 

  public setAnimation = (event:any) => {
    this.setState({animation: event.target.value});
}


  public render() { 
    return (
        <div className="reviewsSummary">
            <div className="reviewsSummary__text">
     
            <h2 className="reviewsSummary__text__title"> Fabulous 8.8</h2>
       
       
                {/* <h3 className="reviewsSummary__text__title1"> Newest reviews for Hotel Royal Haveli</h3> */}
               
                {/* <p className="reviewsSummary__text__details">
                    Very trendy<br/>
                    Good-sized beds<br/>
                    Fast check-in
                </p> */}
                <br/><br/>

<div>
<AliceCarousel 
autoPlayInterval={3000}
autoPlayDirection="rtl"
fadeOutAnimation = {true} 
responsive={this.responsive}
autoPlay={true}
mouseDragEnabled={true}
playButtonEnabled={true}
disableAutoPlayOnAction={true}
>

<div  >
  
Very trendy, good-sized beds,  Fast check-in

<br/><br/>
<div  style={{textAlign: 'left', height: 80 }} >

<b>Reviewed: </b> 29 December 2018
<br/>
<b>User name: </b> Amitava
<br/>
{/* <b>Country: </b> India */}
{/* <ul className="review_item_info_tags">
<li className="review_info_tag ">
<span className="bullet"/> Leisure trip
</li>
<li className="review_info_tag ">
<span className="bullet"/> Family with young children
</li>
<li className="review_info_tag ">
<span className="bullet"/> Deluxe Double/Twin Room
</li>
<li className="review_info_tag ">
<span className="bullet"/> Stayed 2 nights
</li>
<li className="review_info_tag ">
<span className="bullet"/> Submitted via mobile
</li>
</ul> */}

            
             </div>
                </div>
                
                <br/>

<div  style={{ height: 80 }}>
<p>Hospitality is great.food is delicious especially the breakfast
   </p>           
                </div>
               <br/>
                <div  style={{ height: 80 }}>
       <p>
                Unfortunately because of a storm, the AC was broken during night along with the electricty si it was very hot in the room. The bathroom could be cleaner or refreshed.
          </p>        
                </div>
                <br/>
 
      {/* <img src="https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg" onDragStart={this.handleOnDragStart} className="yours-custom-class" />
      <img src="https://i.ytimg.com/vi/vfs7TdYYrGI/maxresdefault.jpg" onDragStart={this.handleOnDragStart} className="yours-custom-class" />
      <img src="https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg" onDragStart={this.handleOnDragStart} className="yours-custom-class" />
      <img src="https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg" onDragStart={this.handleOnDragStart} className="yours-custom-class" />
      <img src="https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg" onDragStart={this.handleOnDragStart} className="yours-custom-class" /> */}
    </AliceCarousel>
  {/* <DemoCarousel/> */}
</div>


<div>
    
<ul  style={{height: 48, overflow: "hidden"}}>

Reach out all reviews for this hotel or add your review <a > HERE </a>

</ul>
</div>







            </div>
            <div className="reviewsSummary__count"><span>3,593 Guest Reviews</span></div>
        </div>
    );

    
  }
}

