import * as React from 'react';
import {Link} from "react-router-dom";
import {PATH_LOGIN} from "../../router/paths";
// import {Alignment} from "@blueprintjs/core";





export default class PreAuthHeader extends React.Component{


    public componentWillMount(){
        console.log("COMPONENT LOGIN PREAUTH HEADER MOIUNTED!");
    }

    public render() {
        return (
            // <div className="postHeader header">
           <div>
            <nav className="bp3-navbar">
                <div className="headerNav">
                    <div className="bp3-navbar-group">
                        <span className="logoBox">
                        <Link to={PATH_LOGIN} className="bp3-navbar-heading"> Login </Link>
                        </span>                  
                    </div>         
                    </div>
            </nav>

            LOGIN HERE
        </div>


            
        )
    }

}