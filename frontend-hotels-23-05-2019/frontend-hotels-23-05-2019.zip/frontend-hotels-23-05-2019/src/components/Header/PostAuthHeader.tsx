import * as React from 'react';
// import {Link } from "react-router-dom";
import {PATH_START} from "../../router/paths";

import './Header';
// import logo from '../../assets/images/logo01.png';
// import {  Popover, Menu, MenuItem } from '../../../node_modules/@blueprintjs/core';
import { IRootState } from '../../redux';
import { loginLogout } from '../../redux/auth/actions';
import { IJWToken } from '../../redux/auth/types';
import { connect } from 'react-redux';
import 'reset-css';



import './Header.css'
import NavbarScroller from '../StartLayout/NavbarScroller';
// import NavbarScroller from '../StartLayout/NavbarScroller';


{/* <Link to={PATH_START} className="bp3-navbar-heading"> <img src= { logo }  /> </Link> */}
const navigation = {
    brand: { name: 'Explore yourself', to: PATH_START },
    links: [
      { name: 'Hotels', to: PATH_START },
      { name: 'Rooms', to: '/' },
      { name: 'Reviews', to: '/' },
      { name: 'Item 4', to: '/' },
      { name: 'Item 5', to: '/' },
      { name: 'Item 6', to: '/' },
      { name: 'Item 7', to: '/' },
      { name: 'Item 8', to: '/' }
    ]
  };


interface IPropsDispatchMap {
    loginLogout: typeof loginLogout;
}

interface IPropsStateMap {
    token: IJWToken | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap


 class PostAuthHeader extends React.Component<IProps> {

    public onLogout = () => {
        this.props.loginLogout();
    }
    public render() {
        const { brand, links } = navigation;

        return (
           
         
                <nav className="bp3-navbar">
                   
                     <div className="grid100">
                   <NavbarScroller brand={brand} links={links} />
                 </div>
                      
                        {/* <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_START} className="bp3-navbar-heading"> <img src= { logo }  /> </Link>
                            </span>  
                            <div className="settings">
                                    <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span>
                                    {this.props.token && <Popover content={
                                        <Menu>
                                            <MenuItem text="Logout" className="bp3-icon-standard bp3-icon-log-out" onClick={this.onLogout} />
                                        </Menu>} 
                                        // position={Position.BOTTOM}
                                        >
                                        <span className="bp3-icon-standard bp3-icon-cog" />
                                    </Popover>}
                                </div>                 
                        </div>          */}
                      
                </nav>
           
           
            // <div className="postHeader header">
                // <div className="grid100">
                //     <NavbarScroller brand={brand} links={links} />
                // </div>
            // </div>

        
        )
    }

   
}

const mapStateToProps = (state: IRootState) => ({
    token: state.auth.token
});

// export default connect(mapStateToProps, { loginLogout, pure: false})(PostAuthHeader)
// export default connect(mapStateToProps, { loginLogout, pure: false})(PostAuthHeader)

export default connect(mapStateToProps, {loginLogout})(PostAuthHeader)
