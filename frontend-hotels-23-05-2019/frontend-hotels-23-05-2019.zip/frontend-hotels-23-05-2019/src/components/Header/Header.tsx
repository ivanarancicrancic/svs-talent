import * as React from 'react';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';

import { getUserIsLoggedIn } from '../../redux/auth/selectors';

import PreAuthHeader from './PreAuthHeader';

import './Header.css'
import PostAuthHeader from './PostAuthHeader';

interface IPropsStateMap {
    isLoggedIn: boolean;
  }

type Props = IPropsStateMap;

class Header extends React.Component<Props> {
    public render() {
        const { isLoggedIn } = this.props;
        console.log("IS LOGGED IN: " + isLoggedIn);
        return isLoggedIn ? <PostAuthHeader /> : <PreAuthHeader />
        // return <PreAuthHeader /> 
    }
}

const mapStateToProps = (state: IRootState) => ({
    isLoggedIn: getUserIsLoggedIn(state)
});

export default connect(mapStateToProps, {})(Header)