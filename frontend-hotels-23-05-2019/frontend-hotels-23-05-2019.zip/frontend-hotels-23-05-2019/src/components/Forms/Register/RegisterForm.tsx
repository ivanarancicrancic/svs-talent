import * as React from 'react';
import { connect } from 'react-redux';
import {Control, Errors, Form, actions as formActions} from 'react-redux-form';
import {IRegisterFormData} from '../../../redux/forms';

import { IRootState } from '../../../redux';
import { captchaFetch } from '../../../redux/captcha/actions';

import './Register.css';
import { ICaptchaResponseModel } from '../../../redux/captcha/types';
import { Button } from '@blueprintjs/core';

interface IPropsDispatchMap {
    captchaFetch: typeof captchaFetch;
}
interface IPropsStateMap {
    captcha: ICaptchaResponseModel | null;
    captchaIsLoading: boolean;
    registerIsLoading: boolean;
}

interface IOwnProps {
    onSubmit: (values: IRegisterFormData) => void;
}

type IProps = IOwnProps & IPropsDispatchMap & IPropsStateMap;

class RegisterForm extends React.Component<IProps> {

    private formDispatch: any;

    public componentWillMount() {
        this.props.captchaFetch();
    }

    public componentWillUnmount() {
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.register'));
        }
    }

    public onBeforeSubmit(event: any) {
        console.log(event);
    }

    public renderCaptcha() {

        if(this.props.captchaIsLoading) {
            return (<p>Loading Captcha</p>)
        } else if(this.props.captcha != null) {
            return (
                <React.Fragment>
                    <img style={{width: 200, height: 50}} src={`data:image/png;base64,${this.props.captcha.data}`} />
                    <div className="bp3-input-group">
                        <Control
                            model=".captcha"
                       
                            component={"input"}
                            controlProps={{
                                className: "bp3-input inputButton",
                                placeholder: "Captcha",
                            }}
                        />
                      
                    </div>
                </React.Fragment>
            )
        } else {
            return (<p>Error Loading Captcha</p>)
        }
    }

    public render() {
        return (
            <div className="container">
                <Form
                    model="forms.register"
                    validators={{
                        '': {
                          passwordsMatch: (vals) => vals.password === vals.confirmPassword,
                        },
                      }}
                    validateOn="change"
                    onUpdate={ (form) => {console.log("onUpdate", form);} }
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                <div className="registerBox">
                    <div className="kontoBox">
                        <div className="bottomSeparator">
                            <p>Kontoinformationen</p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16" >
                                <Control.select
                                    model=".title"
                                    className="selectButton inputButton">
                                    <option value="male">Herr</option>
                                    <option value="female">Frau</option>
                                </Control.select>
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".firstName"
                                  
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "Vorname",
                                    }}
                                />
                               
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".lastName"
                                  
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton ",
                                        placeholder: "Nachname",
                                    }}
                                />
                               
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".email"
                                type="email"
                               
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "E-mail",
                                }}

                            />
                           
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".password"
                              
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Passwort",
                                }}
                            />
                            
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".confirmPassword"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "Passwort bestätigen",
                                }}
                            />
                            <Errors className="arrow_box"
                                model="forms.register"
                                show="touched"
                                messages={{
                                    passwordsMatch: 'Passwords do not match.'
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".phoneNumber"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Telefonnumer",
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".phoneNumber"
                                show="touched"
                                messages={{
                                    required: 'This field is required. ',
                                    minLength5: 'Please use at least 5 characters',
                                    maxLength50: 'Phone number is too long'
                                }}
                            />
                        </div>
                    </div>

                    <div className="kontoBox">
                        <div className="bottomSeparator">
                            <p>Zahlungsinformationen</p>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16" >
                            <Control.select
                                    model=".paymentTitle"
                                    className="selectButton inputButton">
                                    <option value="male">Herr</option>
                                    <option value="female">Frau</option>
                                </Control.select>
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".paymentFirstName"
                                  
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "Vorname",
                                    }}
                                />
                              
                            </div>
                            <div className="grid42">
                                <Control
                                    model=".paymentLastName"
                                   
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton grid50",
                                        placeholder: "Nachame",
                                    }}
                                />
                               
                            </div>
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".companyName"
                              
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "Firmenname",
                                }}
                            />
                            
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".streetAddress"
                               
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Straße und Hausnummer",
                                }}
                            />
                           
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid16">
                                <Control
                                    model=".zipCode"
                                    
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        placeholder: "PLZ",
                                    }}
                                />
                               
                            </div>
                            <div className="grid84">
                                <Control
                                    model=".city"
                                   
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        placeholder: "Ort",
                                    }}
                                />
                               
                            </div>
                        </div>
                        <div className="container bp3-input-group">
                            <div className="grid50">
                                <Control.select
                                    model=".country"
                                    className="selectButton inputButton">
                                    <option value="Germany">Deutschland</option>
                                </Control.select>
                            </div>
                            <div className="grid50">
                                <Control.select
                                    model=".state"
                                    className="selectButton inputButton">
                                    <option value="Herr">Bundesland</option>
                                </Control.select>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="container">
                    <div className="kontoBox">
                        <div className="captcha container">
                            <div className="grid50">
                                {this.props.captcha != null && <img style={{width: 200, height: 50}} src={`data:image/png;base64,${this.props.captcha.data}`} />}
                            </div>
                            <div className="grid50">
                                <div className="bp3-input-group">
                                    <Control
                                        model=".captcha"
                                       
                                        component={"input"}
                                        controlProps={{
                                            className: "bp3-input inputButton secondBg",
                                            placeholder: "Captcha",
                                        }}
                                    />
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="kontoBox">
                        <div className="submit container">
                            <div className="grid50">
                            <label className="bp3-control bp3-checkbox bp3-align-right">
                                <input type="checkbox" />
                                <span className="bp3-control-indicator"/>
                                Ich akzeptiere die AGB und die Datenschutzerklärungen.
                            </label>
                            </div>
                            <div className="grid50">
                            <Button type="submit" className="logIn bp3-button bp3-minimal" loading={this.props.registerIsLoading}>Registrieren</Button>
                            </div>
                        </div>
                    </div>
                </div>
                </Form>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        this.formDispatch = dispatch;
    }

}

const mapStateToProps = (state: IRootState) => ({
    captcha: state.captcha.data,
    captchaIsLoading: state.captcha.loading,
    registerIsLoading: state.register.loading
});

export default connect(mapStateToProps, {captchaFetch})(RegisterForm)