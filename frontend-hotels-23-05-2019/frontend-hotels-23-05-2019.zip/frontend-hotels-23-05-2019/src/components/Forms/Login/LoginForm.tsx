import * as React from 'react';
import {Control, actions as formActions, Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import {Icon} from '@blueprintjs/core';

import './LoginForm.css';
import {Link} from "react-router-dom";
import { PATH_REGISTER} from "../../../router/paths";

import { connect } from 'react-redux';
import { IRootState } from '../../../redux';

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
    formActions: typeof formActions;
}

class LoginForm extends React.Component<IProps> {

    private formDispatch?: any;

    public componentWillUnmount(){
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.login'));
        }
    }

    public render() {
        return (
            <div>
                <div className="loginBox">
                    <Form
                        model="forms.login"
                        onSubmit={(values) => this.props.onSubmit(values)}
                        getDispatch={(dispatch: any) => this.formDispatch = dispatch}
                    >
                            <div className="userIcon">
                                <Icon icon="user" iconSize={60}/>
                            </div>
                            <div className="bp3-input-group">
                                <Control
                                    model=".username"
                                   
                                    
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton",
                                        placeholder: "E-Mail"
                                    }}
                                />
                              
                            </div>
                            <div className="bp3-input-group">
                                <Control
                                    model=".password"
                                    
                                    component={"input"}
                                    controlProps={{
                                        className: "bp3-input inputButton secondBg",
                                        type: "password",
                                        placeholder: "Passwort"
                                    }}
                                />
                                
                                <div className="loginBtn">
                                    <button className="logIn">
                                        Anmelden
                                    </button>
                                </div>
                                <div className="inputButton" />
                               
                            </div>
                    </Form>
                </div>

                <div className="signUp">
                    <div> <span> Du hast noch kein Konto? </span> </div>
                    <div> <Link to={PATH_REGISTER} role="button"> Registriere Dich hier! </Link> </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state: IRootState) => ({
    form: state.forms.forms.login
});

const actions = {
    formActions
};

export default connect(mapStateToProps, actions)(LoginForm);