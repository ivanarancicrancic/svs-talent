import * as React from 'react';
import { connect } from 'react-redux';
import { history } from '../../router';
import './ManageOrderLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { hotelListFetch } from '../../redux/order-list/actions';
import { IHotelResponseModel } from '../../redux/order-list/types';
import { getHotelList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
// import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { hotelDetailFetch } from '../../redux/order-detail/actions';
import { IHotelDetailResponseModel } from '../../redux/order-detail/types';
import { getHotelDetail } from '../../redux/order-detail/selectors';
import { getHotelArticlesFetch } from '../../redux/order-articles/actions';
import { IHotelArticleResponseModel } from '../../redux/order-articles/types';
import { getHotelArticles } from '../../redux/order-articles/selectors';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { RouteComponentProps } from 'react-router';
import * as Modal from 'react-modal';
import { ReviewsSummary } from '../ReviewsSummary/ReviewsSummary';
import { DemoCarousel } from '../ReviewsSummary/DemoCarousel';


// import Fullscreen from "react-full-screen";
// import posed from "react-pose";
// import styled from "styled-components";


// const Container = styled.div`
//   height: 100vh;
//   display: flex;
//   align-items: center;
//   justify-content: center;
// `;

// const Square = posed.div({
//   idle: { scale: 1 },
//   hovered: { scale: 1.5 }
// });

// const StyledSquare = styled(Square)`
//   width: 100px;
//   height: 100px;
//   background: red;
// `;

interface IPropsDispatchMap {
    orderListFetch: typeof hotelListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    hotelDetailFetch: typeof hotelDetailFetch;
    getHotelArticlesFetch: typeof getHotelArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
}
interface IPropsStateMap {
    orderData: IHotelResponseModel[] | null;
    filteredOrderData: IHotelResponseModel[] | null;
    hotelDetailData: IHotelDetailResponseModel | null;
    orderSavedData: IHotelDetailResponseModel | null;
    hotelArticlesData: IHotelArticleResponseModel[] | null;
    canceledOrderData: IHotelDetailResponseModel | null;   
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{hotelId: string}>

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(255, 0, 0, 0.7)',
      width: '100%'
    }
  };


class ManageOrder extends React.Component<IProps>{

   public state = { size: [200, 200, 200, 200], isFull: false };


    constructor(props: any) {
        super(props);
       
        this.goFull = this.goFull.bind(this);
        this.editOrder = this.editOrder.bind(this);

    }

  
  public setAnimation = (event:any) => {
       this.setState({animation: event.target.value});
   }

//   public setDuration = (event:any) => {
//        this.setState({duration: parseInt(event.target.value)});
//    }

//   public setStagger = (event:any) => {
//        this.setState({stagger: parseInt(event.target.value)});
//    }

//   public setDistance = (event:any) => {
//        this.setState({distance: parseInt(event.target.value)});
//    }

    public componentWillMount() {
        console.log("Entered mounting HotelView!");
        const hotelId = this.props.match.params.hotelId;
        this.props.hotelDetailFetch({hotelId});
        this.props.getHotelArticlesFetch({hotelId});
    }

    public editOrder(orderid:any){   
    const orderId = orderid;
    history.push(`/order/edit/${orderId}`);      
    }


    public setSize = (size:any, id: any) => {
        console.log("Size will be set to: " );
       let size1 = [];
       size1 =  this.state.size; 
       size1[id] = size;
       console.log("New size will be at id: " + id + ", with value: " + size1[id]);
        this.setState({size: size1});
        console.log("After setting State IS: " + this.state.size[id]);
          
    
       }

  public imageClick = (id: any) => {
    console.log('Click!!!!');
    this.setState({ isFull: true });
    // let size1 = [];
    // size1 =  this.state.size; 
    // size1[id] = 900;
    // this.setState({size: size1});
}       


  
 public goFull = () => {
    this.setState({ isFull: true });
  }


    public render() { 
        
       

        
        if(this.props.hotelDetailData){
            const orderid= this.props.hotelDetailData.id;
            if(this.props.hotelArticlesData){       
                return (
                  


                    <div className="grid100">

     <Modal isOpen={this.state.isFull} style={customStyles} contentLabel="Example Modal">
                        
                        <br/>
                        <br/>
                        <br/>
                        <DemoCarousel/>
                        {/* <img src='https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg'/> */}
                      </Modal>


  {/* <Fullscreen
          enabled={this.state.isFull}
          onChange={isFull => this.setState({isFull})}
        >
          <div className="full-screenable-node">
          <img src='https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg'/>
          </div>
        </Fullscreen> */}

                        <form>
                            <div style={{textAlign: 'left', fontSize: 25, color: 'white', position: "absolute", left: 100, top:  150}}>HOTEL DETAILS</div>
                            {/* <div className="editableLabels"  style={{ position: "absolute", left: 100, top:  200}}><label> <b>Hotel ID: </b></label> {this.props.hotelDetailData.id}  </div> */}
                            <div className="editableLabels" style={{  color: 'white', position: "absolute", left: 100, top:  200, fontSize: 20}}> <label ><b> Hotel: </b> </label> {this.props.hotelDetailData.name} </div>
                            <div className="editableLabels" style={{  color: 'white', position: "absolute", left: 100, top:  240, fontSize: 20}}> <label > <b>Description: </b>  </label> {this.props.hotelDetailData.description} </div>
                            {/* <div> <img className="bp3-button imgl rounded-circle" src= "https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg"  alt="logo"  style={{width: this.state.size, height: this.state.size, position: "absolute", left: 850, top:  185}} /> </div> */}
                            {/* <div > <img className="bp3-button imgl img-circular" src= "https://i.ytimg.com/vi/vfs7TdYYrGI/maxresdefault.jpg"  alt="logo"  style={{width: this.state.size, height: this.state.size, position: "absolute", left: 850, top: 2 * 215}}    */}
                            {/* // onMouseEnter={() => this.setState()   } */}
          {/* onClick={ this.setSize  }/>  <button className="bp3-button" style={{backgroundColor : "#E8BF1E"}} type="button"  onClick={(e) =>  this.setSize()} > CLICK hotel </button> */}
          {/* </div> */}
         <div id= '1'> <img className="bp3-button imgl rounded-circle" src='https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg'  style={{width: this.state.size[1], height: this.state.size[1], position: "absolute", left: 850, top:  185}} onClick={(e) => this.imageClick(1)}  onMouseEnter={(e) => this.setSize(300, 1) }   onMouseLeave={(e) => this.setSize(200, 1)}  /> </div>
        <div id='2'>  <img className="bp3-button imgl rounded-circle" src='https://i.etsystatic.com/7281291/r/il/7115e4/1722048848/il_794xN.1722048848_khgd.jpg'  style={{width: this.state.size[2], height: this.state.size[2], position: "absolute", left: 850, top:  430}} onClick={(e) => this.imageClick(2)} onMouseEnter={(e) => this.setSize(300, 2) }   onMouseLeave={(e) => this.setSize(200, 2)} /> </div>
        <div id='3'>  <img className="bp3-button imgl rounded-circle" src='https://i.ytimg.com/vi/vfs7TdYYrGI/maxresdefault.jpg'  style={{width: this.state.size[3], height: this.state.size[3], position: "absolute", left: 1150, top:  185}} onClick={(e) => this.imageClick(3)} onMouseEnter={(e) => this.setSize(300, 3) }   onMouseLeave={(e) => this.setSize(200, 3)} /> </div>
        <div id='4'>  <img className="bp3-button imgl rounded-circle" src='http://significadosdelossuenos.net/wp-content/uploads/2017/07/So%C3%B1ar-con-bucear.jpg'  style={{width: this.state.size[4], height: this.state.size[4], position: "absolute", left: 1150, top:  430}} onClick={(e) => this.imageClick(4)} onMouseEnter={(e) => this.setSize(300, 4) }   onMouseLeave={(e) => this.setSize(200, 4)} /> </div>
                    
       <br/>
       <br/>

              

 
                            <div style={{ fontSize: 20,  position: "absolute", left: 100, top:  280, width: 650, height: 80 }}  >

                           
<div className="searchContainer__right col-xs-2 col-md-2">
<div style= {{color: "white"}}>  Newest reviews for Hotel Royal Haveli </div>   
<br/> 
                        <div className="container">              
                <section className="searchContainer clearfix">
                    <div className="searchContainer__right col-xs-2 col-md-2">
                        <ReviewsSummary />
                        

                        
                    </div>
                </section>
                
            </div>



                        {/* <Facilities data={data.facilities}/>
                        <Map mapUrl={data.hotelInfo.mapUrl}/> */}
                    </div>

                            {/* <RadialMenu 
          items={items}
          center={center}
        /> HELLOUU111 */}


              
              {/* <Container>
        <StyledSquare
        //   pose={this.state.hovering ? "hovered" : "idle"}
          onMouseEnter={() => this.setState({ hovering: true })}
          onMouseLeave={() => this.setState({ hovering: false })}
        />
      </Container> */}
     
        </div>
                            
                             <div className = "modalTText" style={{position: "absolute", right: 45, top: 710 }}>
                                <button className="bp3-button" style={{backgroundColor : "#E8BF1E"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit hotel </button>
                            </div>
                        </form>
                        {/* {this.props.hotelArticlesData.map( (orderArticle, index) => { */}
                               {/* const imageUrl = orderArticle.articlePictureUrl; */}
                            {/* return ( */}
                                {/* <div key={orderArticle.orArId}> */}
                                    {/* <tr><img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130,position: "absolute", right: 160, top: 154 }} /> </tr> */}
                                    {/* <tr> <img className="bp3-button imgl" src= {imageUrl}  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 590, right: 160, top: 165 + index * 185}} /> </tr> */}
                                    {/* <br/> */}
                                    {/* <hr className="style13" style={{position: "absolute", left: 590, right: 50, top: 325 + index * 185}}/>      */}
                                    {/* <tr> <div style={{position: "absolute", left: 748, top: 160 + index * 185}}> <b> ARTICLE:  </b> {orderArticle.articleName}</div></tr> */}
                                    {/* <tr> <div style={{position: "absolute", left: 748, top: 195 + index * 185}}>  <b> Net price:  </b>  {orderArticle.articleNetPrice} </div></tr> */}
                                    {/* <tr> <div style={{position: "absolute", left: 748, top: 215 + index * 185}}> <b> Gross price:  </b> {orderArticle.articleGrossPrice} </div></tr> */}
                                    {/* <tr><div style={{position: "absolute", left: 748, top: 235 + index * 185}}>  <b> Net price WD:  </b> {orderArticle.articleNetPriceWD} </div></tr> */}
                                    {/* <tr><div style={{position: "absolute", left: 748, top: 255 + index * 185 }} > <b> Gross price WD:  </b> {orderArticle.articleGrossPriceWD} </div></tr> */}
                                    {/* <tr> <div style={{position: "absolute", left: 748, top: 275 + index * 185}}>  <b> QUANTITY:  </b> {orderArticle.articleQuantity} </div></tr> */}
                                {/* </div>           */}
                            {/* ) */}
                        {/* })} */}
                    </div>
                )
            }
            else{
                return (
                    <div className="grid100">
                        <div className="ordersTable">
                            <div> Order details </div>
                            <div className="editableLabels"><label> <b>Hotel id: </b></label> {this.props.hotelDetailData.id}  </div>
                            <div className="editableLabels"> <label ><b> Hotel name: </b> </label> {this.props.hotelDetailData.name} </div>
                            <div className="editableLabels"> <label > <b>Description: </b>  </label> {this.props.hotelDetailData.description} </div>
                           
 <div> <img className="bp3-button imgl" src= "https://r-ak.bstatic.com/images/hotel/max1024x768/146/146404617.jpg"  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 150, top:  185}} /> </div> */}
                            <div> <img className="bp3-button imgl" src= "https://i.ytimg.com/vi/vfs7TdYYrGI/maxresdefault.jpg"  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 150, top: 2 * 185}} /> </div>



                            
                            <div className = "modalTText" >
                                <button className="bp3-button" style={{backgroundColor : "#4682B4"}} type="button"  onClick={(e) => this.editOrder(orderid)} > Edit hotel </button>
                            </div>
                            <div  style={{ position: "absolute", left: 748, top: 140 }}> <b>PRODUCTS INCLUDED: </b></div>
                        </div>
                    </div>
                )
            }
        }
        else {
            return null;
        }
    }
}

const mapStateToProps = (state: IRootState) => ({
    orderData: getHotelList(state),
    filteredOrderData: getFilteredOrder(state),
    hotelDetailData: getHotelDetail(state),
    hotelArticlesData: getHotelArticles(state)
});

export default connect(mapStateToProps, {hotelListFetch, filterOrderFetch, hotelDetailFetch, getHotelArticlesFetch, orderSaveFetch, cancelOrderFetch})(ManageOrder)