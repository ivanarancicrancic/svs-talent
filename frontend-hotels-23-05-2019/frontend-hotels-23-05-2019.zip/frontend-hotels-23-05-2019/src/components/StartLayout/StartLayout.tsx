import * as React from 'react';
import { connect } from 'react-redux';
// import { history } from '../../router';
import './StartLayout.css';
import { IRootState } from '../../redux';
import { hotelListFetch } from '../../redux/hotel-list/actions';
import { IHotelResponseModel } from '../../redux/hotel-list/types';
import { getHotelList } from '../../redux/hotel-list/selectors';
import { history } from '../../router';
import 'reset-css';

// const imgUrl = 'https://3.bp.blogspot.com/-Ag3ocVr9jxY/XGC23Nss7KI/AAAAAAAAGGc/cHxqQ28ZaSUndUhDZGQxYQtra3qp8eGKgCHMYCw/s1600/beaches-beach-beautiful-island-mountains-kauai-summer-emerald.jpg';

// const sectionStyle = {
//   width: "100%",
//   height: "400px",
//   backgroundImage: 'url(' + imgUrl + ')'
// };



// import NavbarScroller from './NavbarScroller';
// import { Navbar, Nav, NavItem, NavDropdown } from "react-bootstrap";

// import { Form } from 'react-redux-form';
// import {
//     MDBNavbar, MDBNavbarBrand, MDBNavbarNav, MDBNavItem, MDBNavLink, MDBNavbarToggler, MDBCollapse, MDBFormInline,
//     MDBDropdown, MDBDropdownToggle, MDBDropdownMenu, MDBDropdownItem
//     } from 'mdbreact';

    // const  MDBNavbar  = require('mdbreact');
    // const MDBNavbarBrand = require('mdbreact');
    // const MDBNavbarNav = require('mdbreact');
    // const MDBNavItem = require('mdbreact');
    // const MDBNavLink = require('mdbreact');
    // const MDBNavbarToggler = require('mdbreact');
    // const MDBCollapse = require('mdbreact');
    // const MDBFormInline = require('mdbreact');
    // const MDBDropdown = require('mdbreact');
    // const MDBDropdownToggle = require('mdbreact');
    // const MDBDropdownMenu = require('mdbreact');
    // const MDBDropdownItem = require('mdbreact');


    // const navigation = {
    //     brand: { name: 'NavScroller', to: '/' },
    //     links: [
    //       { name: 'Item 1', to: '/' },
    //       { name: 'Item 2', to: '/' },
    //       { name: 'Item 3', to: '/' },
    //       { name: 'Item 4', to: '/' },
    //       { name: 'Item 5', to: '/' },
    //       { name: 'Item 6', to: '/' },
    //       { name: 'Item 7', to: '/' },
    //       { name: 'Item 8', to: '/' }
    //     ]
    //   };

interface IPropsDispatchMap {
    hotelListFetch: typeof hotelListFetch;
}

interface IPropsStateMap {
    hotelData: IHotelResponseModel[] | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

// const customStyles = {
//     content : {
//       top                   : '50%',
//       left                  : '50%',
//       right                 : 'auto',
//       bottom                : 'auto',
//       marginRight           : '-50%',
//       transform             : 'translate(-50%, -50%)',
//       backgroundColor: 'rgba(132, 132, 132, 0.88)',
//       width: '100%'
//     }
//   };

class StartLayout extends React.Component<IProps, any> {

   public state = {
        isOpen: false
      };
      
     

      constructor(props: any) {
        super(props);
     
        this.handleViewHotel = this.handleViewHotel.bind(this);

    }

   public toggleCollapse = () => {
        this.setState({ isOpen: !this.state.isOpen });
      }

    public componentWillMount() {
     console.log("COMPONENT HOTELS MOUNTED BU SHOULDNT!");
        this.props.hotelListFetch();
    }

    public handleViewHotel(hotelId: string){
        console.log("handleViewHotel entered with HOTEL NAME: " + hotelId);    
        history.push(`/hotel/${hotelId}`);
    }
 

    public renderOrderList() { 
        if(this.props.hotelData){
            return(
                <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-striped">
                        <thead>                  
                            <tr >
                                <th>Hotel ID</th>   
                                <th>Hotel Name </th>
                                <th>Description </th>
                                <th/>
                            </tr>
                        </thead>
                        <tbody>
                            {this.props.hotelData.map(hotel => {
                                return(
                                    <tr key={hotel.id}  className = "order_hovered">
                                        <td><b>{hotel.id}</b></td>
                                        <td>{hotel.name} </td>
                                        <td>{hotel.description} </td>
                                        <td><button type="button" className="bp3-button" onClick={(e) => this.handleViewHotel(hotel.id)} > View details </button></td>
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>
                {/* <div>
                    <MDBNavbar color="indigo" dark expand="md">
        <MDBNavbarBrand>
          <strong className="white-text">Navbar</strong>
        </MDBNavbarBrand>
        <MDBNavbarToggler onClick={this.toggleCollapse} />
        <MDBCollapse id="navbarCollapse3" isOpen={this.state.isOpen} navbar>
          <MDBNavbarNav left>
            <MDBNavItem active>
              <MDBNavLink to="#!">Home</MDBNavLink>
            </MDBNavItem>
            <MDBNavItem>
              <MDBNavLink to="#!">Features</MDBNavLink>
            </MDBNavItem>
            <MDBNavItem>
              <MDBNavLink to="#!">Pricing</MDBNavLink>
            </MDBNavItem>
            <MDBNavItem>
              <MDBDropdown>
                <MDBDropdownToggle nav caret>
                  <span className="mr-2">Dropdown</span>
                </MDBDropdownToggle>
                <MDBDropdownMenu>
                  <MDBDropdownItem href="#!">Action</MDBDropdownItem>
                  <MDBDropdownItem href="#!">Another Action</MDBDropdownItem>
                  <MDBDropdownItem href="#!">Something else here</MDBDropdownItem>
                  <MDBDropdownItem href="#!">Something else here</MDBDropdownItem>
                </MDBDropdownMenu>
              </MDBDropdown>
            </MDBNavItem>
          </MDBNavbarNav>
          <MDBNavbarNav right>
            <MDBNavItem>
              <MDBFormInline waves>
                <div className="md-form my-0">
                  <input className="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search" />
                </div>
              </MDBFormInline>
            </MDBNavItem>
          </MDBNavbarNav>
        </MDBCollapse>
      </MDBNavbar>
         </div> */}
                </div>
            ) 
        } 
        else 
        { 
            return null;
        }  
    }

    public render() { 

        // const { brand, links } = navigation;


            return (
                <div className="grid100">

{/* <NavbarScroller brand={brand} links={links} /> */}
        {/* <div className="hello">
          <ul>
            <li>React</li>
            <li>TypeScript</li>
            <li>Styled-Components</li>
          </ul>
        </div> */}

                    {this.renderOrderList()}   
                </div>
            )

      
    }
}

const mapStateToProps = (state: IRootState) => ({
    hotelData: getHotelList(state)
});

export default connect(mapStateToProps, {hotelListFetch})(StartLayout)


