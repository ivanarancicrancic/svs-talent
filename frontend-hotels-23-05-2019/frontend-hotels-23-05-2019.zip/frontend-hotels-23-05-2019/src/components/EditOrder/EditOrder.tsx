import * as React from 'react';
import { connect } from 'react-redux';
// import { history } from '../../router';
import './EditOrder.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { hotelListFetch } from '../../redux/order-list/actions';
import { IHotelResponseModel } from '../../redux/order-list/types';
import { getHotelList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
// import article1 from '../../assets/images/563753R55357jk8937DDBG.jpg';
import { hotelDetailFetch } from '../../redux/order-detail/actions';
import { IHotelDetailResponseModel } from '../../redux/order-detail/types';
import { getHotelDetail } from '../../redux/order-detail/selectors';
import { getHotelArticlesFetch } from '../../redux/order-articles/actions';
import { IHotelArticleResponseModel } from '../../redux/order-articles/types';
import { getHotelArticles } from '../../redux/order-articles/selectors';
// import { Form, Control, Errors } from 'react-redux-form';
import { orderSaveFetch } from '../../redux/order-save/actions';
import { cancelOrderFetch } from '../../redux/cancelOrders/actions';
import { deleteArticleFromOrderFetch } from '../../redux/delete-article/actions'
import { RouteComponentProps } from 'react-router';
import { getSavedOrder, getSavedOrderHasError } from '../../redux/order-save/selectors';
import * as Modal from 'react-modal';
import { addQuantityToListFetch } from '../../redux/addQuantityToList/actions';
import { getQuantityList } from '../../redux/addQuantityToList/selectors';
import { setCurrentIndexFetch } from '../../redux/setCurrentIndex/actions';
import { getCurrentIndex } from '../../redux/setCurrentIndex/selectors';
import { addNetPriceToListFetch } from '../../redux/addNetPriceToList/actions';
import { getNetPriceList } from '../../redux/addNetPriceToList/selectors';
import { addGrossPriceToListFetch } from '../../redux/addGrossPriceToList/actions';
import { setModal3IsOpenFetch } from '../../redux/setModal3IsOpen/actions';
import { recalculateOrderNetPriceFetch } from '../../redux/recalculateOrderNetPrice/actions';
import { getGrossPriceList } from '../../redux/addGrossPriceToList/selectors';
import { getModal3IsOpen } from '../../redux/setModal3IsOpen/selectors';
import { getRecalculatedOrderNetPrice } from '../../redux/recalculateOrderNetPrice/selectors';
import { recalculateOrderGrossPriceFetch } from '../../redux/recalculateOrderGrossPrice/actions'; 
import { getRecalculatedOrderGrossPrice } from '../../redux/recalculateOrderGrossPrice/selectors';
// import Dropzone from 'react-dropzone';
// import * as request from "superagent";
import {imageUploadFetch } from '../../redux/imageUpload/actions';
// import * as AWS from 'aws-sdk';
import { setPictureUrlFetch } from '../../redux/setPictureUrl/actions';
import { getSetPictureUrl } from '../../redux/setPictureUrl/selectors';
import { IOrderDetailResponseModel } from '../../redux/cancelOrders/types';
import { IOrderArticleResponseModel } from '../../redux/addGrossPriceToList/types';

interface IPropsDispatchMap {
    hotelListFetch: typeof hotelListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    hotelDetailFetch: typeof hotelDetailFetch;
    getHotelArticlesFetch: typeof getHotelArticlesFetch; 
    orderSaveFetch: typeof orderSaveFetch;
    cancelOrderFetch: typeof cancelOrderFetch;
    deleteArticleFromOrderFetch: typeof deleteArticleFromOrderFetch;
    addQuantityToListFetch: typeof addQuantityToListFetch;
    setCurrentIndexFetch: typeof setCurrentIndexFetch;
    addNetPriceToListFetch: typeof addNetPriceToListFetch;
    addGrossPriceToListFetch: typeof addGrossPriceToListFetch;
    setModal3IsOpenFetch: typeof setModal3IsOpenFetch;
    recalculateOrderNetPriceFetch: typeof recalculateOrderNetPriceFetch;
    recalculateOrderGrossPriceFetch: typeof recalculateOrderGrossPriceFetch;
    imageUploadFetch: typeof imageUploadFetch;
    setPictureUrlFetch: typeof setPictureUrlFetch;
  
}
interface IPropsStateMap {
    hotelData: IHotelResponseModel[] | null;
    filteredOrderData: IHotelResponseModel[] | null;
    hotelDetailData: IHotelDetailResponseModel | null;
    orderSavedData: IOrderDetailResponseModel | null;
    hotelArticlesData: IHotelArticleResponseModel[] | null;
    canceledOrderData: IOrderDetailResponseModel | null; 
    decrementQuantityData: IOrderArticleResponseModel | null;
    deleteArticleFromOrderData: IOrderDetailResponseModel | null;
    addQuantityToListData: string[] | null;
    setCurrentIndexData: number;
    addNetPriceToListData: string[] | null;
    addGrossPriceToListData: string[] | null;
    setModal3IsOpenData: boolean; 
    recalculateOrderNetPriceData: string;
    recalculatedOrderGrossPriceData: string;
    getSavedOrderHasError: string;
    setPictureUrlData: string;
    
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{orderId: string}>

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)',
      backgroundColor: 'rgba(255, 0, 0, 0.7)',
      width: '100%'
    }
  };



  
class EditOrder extends React.Component<IProps, any>{
    
      constructor(props: any) {
        super(props);
        this.state = {
            files: [],
            maxFiles: 1,
            pic: '',
            currentOrAdId: "-1",
            imageUrl: ''
          };
        this.handleSubmitSaveOrder = this.handleSubmitSaveOrder.bind(this);
        this.handleSetQuantity = this.handleSetQuantity.bind(this);
        this.handleSetCurrentIndex = this.handleSetCurrentIndex.bind(this);
        this.handleDeleteArticleFromOrder = this.handleDeleteArticleFromOrder.bind(this);
        this.handleSetNetPrice = this.handleSetNetPrice.bind(this);
        this.handleSetGrossPrice = this.handleSetGrossPrice.bind(this);
        this.onDrop =  this.onDrop.bind(this);
        this.setCurrentOrArId = this.setCurrentOrArId.bind(this);
       }

    public componentWillMount() {
        const orderId = this.props.match.params.orderId;
        this.props.hotelDetailFetch({hotelId: orderId});
        this.props.getHotelArticlesFetch({hotelId: orderId}); 
        this.props.recalculateOrderNetPriceFetch({flagStart: true});
        this.props.recalculateOrderGrossPriceFetch({flagStart: true});
             
        // if(this.props.hotelArticlesData){
        //     this.props.addQuantityToListFetch({newQuantityValue: "", indexList: -1, pushFlag: false});
        //     this.props.hotelArticlesData.map((orderArticle, index) => {
        //         this.props.addQuantityToListFetch({newQuantityValue: orderArticle.articleQuantity, indexList: index, pushFlag: true});
        //     });
        //     this.props.addNetPriceToListFetch({newNetPriceValue: "", indexList: -1, pushFlag: false});
        //     this.props.orderArticlesData.map((orderArticle, index) => {
        //         this.props.addNetPriceToListFetch({newNetPriceValue: orderArticle.articleNetPrice, indexList: index, pushFlag: true});
        //     });
        //     this.props.addGrossPriceToListFetch({newGrossPriceValue: "", indexList: -1, pushFlag: false});
        //     this.props.orderArticlesData.map((orderArticle, index) => {
        //         this.props.addGrossPriceToListFetch({newGrossPriceValue: orderArticle.articleGrossPrice, indexList: index, pushFlag: true});
        //     });  
        // }   
    }

    public componentWillReceiveProps(nextProps: IProps, nextState: IRootState) {

           if(this.props.setPictureUrlData){
                console.log("THE URL IS:" + this.props.setPictureUrlData);
            const orderId = this.props.match.params.orderId;
            this.props.getHotelArticlesFetch({hotelId: orderId}); 

           }
        
        // if(this.props.orderSavedData){
        //     if(nextProps.orderSavedData !== this.props.orderSavedData){
        //         history.push(`/start`); 
        //     }
        // }
        return ((e:any) => {
            e.preventDefault();       
        });  
    }
  
    public handleDeleteArticleFromOrder(orderArticle: any){
        this.props.setModal3IsOpenFetch({modal3IsOpen: true});
    }

    public handleDeleteArticleFromOrderFinal(orArId: any){
        if(this.props.hotelDetailData){
            this.props.deleteArticleFromOrderFetch({orArId});        
        }
    }

    public handleSetCurrentIndex  = async(index: any, orArIndex: any) => {
        await this.props.setCurrentIndexFetch({newIndex: index});  
    }
     
    public handleDeleteArticleFromOrderCancel(){
        this.props.setModal3IsOpenFetch({modal3IsOpen: false});
    }


    public handleSetQuantity = async (event: any) => {
        if(event.target.value){     
            if(this.props.addQuantityToListData){
                await this.props.addQuantityToListData.map((qunatity, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addQuantityToListFetch({newQuantityValue: event.target.value, indexList: j, pushFlag:false}))
                            .then((response)=> {
                                this.props.recalculateOrderNetPriceFetch({flagStart: false});
                                this.props.recalculateOrderGrossPriceFetch({flagStart: false});
                            });
                        }
                    }
                });
            }
        }
    }
    
    public handleSetNetPrice= async (event: any) =>{
        if(event.target.value){     
            if(this.props.addNetPriceToListData){
                await this.props.addNetPriceToListData.map((netPrice, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addNetPriceToListFetch({newNetPriceValue: event.target.value, indexList: j, pushFlag: false}))
                            .then((response)=> {
                                   this.props.recalculateOrderNetPriceFetch({flagStart: false});
                             });
                       
                        }
                    }
                });
            }
        }
    }
 
    public handleSetGrossPrice= async (event: any) =>{
        if(event.target.value){     
            if(this.props.addGrossPriceToListData){
                await this.props.addGrossPriceToListData.map((grossPrice, j) => {
                    if(j === this.props.setCurrentIndexData){
                        if(event.target.value){
                            Promise.resolve(this.props.addGrossPriceToListFetch({newGrossPriceValue: event.target.value, indexList: j, pushFlag: false}))
                            .then((response)=> {
                                   this.props.recalculateOrderGrossPriceFetch({flagStart: false});
                             });
                        }
                    }
                });
            }
        }
    }
    
    public handleSubmitSaveOrder(value:any) {
                this.props.orderSaveFetch();
    }

//     public onDrop = (files:any) => {
       
//     //     const formData = new FormData();
//     //     const file = new Blob([files[0].preview]);
//     //     console.log("New Blob created: " + JSON.stringify(files[0].preview));
//     //     formData.append('file', file);
//     //     // formData.set('file', file, files[0].name);
//     //     console.log("File SELECTED: " + files[0].name);
//     //      if(this.props.orderArticlesData){
//     //     this.props.imageUploadFetch({orArId: this.props.orderArticlesData[0].orArId, data: formData});
//     //      }


//         // const file = files[0]
//         // const reader = new FileReader();
//         // reader.onload = (event: any) => {
//         //   console.log(event.target.result);
//         // };
//         // reader.readAsDataURL(file);

//     console.log("OnDrop entered!");
//         // const file = files[0]
       
//         // const reader = new FileReader();
//             // reader.onload = (event: any) =>  {
//             //   const contents = event.target.result;
//             //   console.log("Contents" + contents);
//               const formData = new FormData();
            
//               const file = new Blob([files[0]], { type: 'image/jpg' });

//               formData.append('file', file);
//               formData.append('filename', files[0].name);
          
//     //     //  formData.set('file', file1, files[0].name);
//     // //     console.log("File SELECTED: " + files[0].name);
//          if(this.props.orderArticlesData){
//         this.props.imageUploadFetch({orArId: this.props.orderArticlesData[0].orArId, data: formData});
//          }
   

// // request.post('http://localhost:8080/ersatzteilhandel24apiValid/orderArticle/uploadImage')
// // .send(formData)
// // .end((err, resp) => {
// //   if (err) {
// //     console.error(err);
// //   }
// //   else {console.log(JSON.stringify(resp));}
// //   return resp;
// // });




//             // };
//             // reader.readAsText(file);
          

//     }


public setCurrentOrArId = (orArId: any) => {
this.setState({currentOrAdId: orArId});

}

    public onDrop = (files:any) => {
       
        //    upload.post('/upload')
        //    .attach('theseNamesMustMatch', files[0])
        //    .end((err: any, res: any) => {
        //      if (err) console.log(err);
        //      alert('File uploaded!');
        //    })
    
       console.log("Entered onDrop");
         files.map((file:any) => {
             console.log("Entered mapping");
            // Initial FormData
            const formData = new FormData();

            const fn = file.name.substring(file.name.lastIndexOf('/')+1);
         console.log(fn);
            formData.append("file", file, fn);
            // formData.append('filename', file.name);
            console.log("File: " + JSON.stringify(file));
            // formData.append("tags", `codeinfuse, medium, gist`);
            // formData.append("upload_preset", "pvhilzh7"); // Replace the preset name with your own
            // formData.append("api_key", "1234567"); // Replace API key with your own Cloudinary key
        //   /  formData.append("timestamp", (Date.now() / 1000) | 0);
            
            // Make an AJAX upload request using Axios (replace Cloudinary URL below with your own)
            // return axios.post("https://api.cloudinary.com/v1_1/codeinfuse/image/upload", formData, {
            //   headers: { "X-Requested-With": "XMLHttpRequest" },
            // }).
            this.props.setPictureUrlFetch({formData, fileName: fn, currentOrAdId: this.state.currentOrAdId});
     
          });
        
        
    
    
        }


    public render() {
        if(this.props.setModal3IsOpenData){
            return(
                <div className="grid100">
                    <Modal isOpen={this.props.setModal3IsOpenData} style={customStyles} contentLabel="Example Modal">
                        <div style={{textAlign: 'center', fontSize: 25, color: "#333"}}>ARE YOU SURE YOU WANT TO REMOVE THIS ARTICLE FROM THE ORDER?  </div>
                        <br/>
                        <br/>
                        <br/>
                        <tr>                 
                            <div style={{position: 'absolute', bottom: 23, right: 533}} > 
                                <button type="button" className="bp3-button" style={{backgroundColor : "green"}} onClick={(e) => { if(this.props.hotelArticlesData) { this.handleDeleteArticleFromOrderFinal(this.props.hotelArticlesData[this.props.setCurrentIndexData])}}} >Yes  </button>
                            </div>  
                            <div style={{position: 'absolute', bottom: 23, right: 583}} > 
                                <button type="button" className="bp3-button" style={{backgroundColor : "rgb(255,255,0)"}} onClick={(e) => this.handleDeleteArticleFromOrderCancel()} >Cancel  </button>
                            </div>
                        </tr>
                    </Modal>
                </div>
            )
        }
        else{

         return null;

        }
//         else{
//             // let start =0;
//             const numbers:any = [];
           
//             if(this.props.orderDetailData){
//                 if(this.props.orderArticlesData){   
//                     return (
//                         <div className="grid100">
//                             <Form  model="forms.info" method="post" onSubmit={ (info) => this.handleSubmitSaveOrder(info) } >   
//                                 <tr>
//                                     <td>
//                                         <div >
//                                             <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
//                                             <br/>
//                                             <label htmlFor="firstName" className="bp3-file-input"><b>First name:  &nbsp;  &nbsp;  {this.props.orderDetailData.firstName} </b></label>  &nbsp;  &nbsp;  
//                                             <br/>             
//                                             <label htmlFor="lastName" className="bp3-file-input"><b>Last name:  &nbsp;  &nbsp; {this.props.orderDetailData.lastName}  </b></label>
//                                             <br/>
//                                             <label htmlFor="companyName" className="bp3-file-input"><b>Company name: &nbsp;  &nbsp; {this.props.orderDetailData.companyName} </b></label> &nbsp;  &nbsp;
//                                             <br/>
//                                             <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:  &nbsp;  &nbsp; {this.props.orderDetailData.paymentMethod} </b></label> &nbsp;  &nbsp;
//                                             <br/>
//                                             <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:  &nbsp;  &nbsp; {this.props.orderDetailData.shippingWay} </b></label>
//                                             <br/>
//                                             <label htmlFor="email" className="bp3-file-input"><b>Email: &nbsp;  &nbsp; {this.props.orderDetailData.email}  </b></label> 
//                                             <br/>
//                                             <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:  &nbsp;  &nbsp; {this.props.orderDetailData.phoneNumber}</b></label>
//                                             <br/>
//                                             <label htmlFor="street" className="bp3-file-input"><b>Street:  &nbsp;  &nbsp; {this.props.orderDetailData.street}  </b></label>
//                                             <br/>
//                                             <label htmlFor="houseNumber" className="bp3-file-input"><b>House number: &nbsp;  &nbsp; {this.props.orderDetailData.houseNumber}  </b></label>
//                                             <br/>
//                                             <label htmlFor="postcode" className="bp3-file-input"><b>Post code:  &nbsp;  &nbsp;{this.props.orderDetailData.postcode} </b></label> 
//                                             <br/>
//                                             <label htmlFor="city" className="bp3-file-input"><b>City: &nbsp;  &nbsp; {this.props.orderDetailData.city}</b></label> 
//                                             <br/>
//                                             <label htmlFor="country" className="bp3-file-input"><b>Country: &nbsp;  &nbsp;  {this.props.orderDetailData.country} </b></label> 
//                                             <br/>
//                                             <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: &nbsp;  &nbsp; {this.props.recalculateOrderNetPriceData}  </b></label> 
//                                             <br/>
//                                             <label htmlFor="grossPrice" className="bp3-file-input"><b> Gross price:&nbsp;  &nbsp; {this.props.recalculatedOrderGrossPriceData}  </b></label> 
//                                             <br/> 
//                                             <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): &nbsp;  &nbsp; {this.props.orderDetailData.netPriceWD}  </b></label> 
//                                             <br/>
//                                             <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): &nbsp;  &nbsp;  {this.props.orderDetailData.grossPriceWD} </b></label> 
//                                             <br/>
//                                         </div> 
//                                     </td>
//                                 </tr>
//                                 <div>
//                                     <div style={{ position: "absolute", left: 590, top: 120  }}> <b>PRODUCTTTTS INCLUDED: </b></div>
//                                     {this.props.orderArticlesData.map( (orderArticle, index) => {                     
//                                         numbers.push(parseInt(orderArticle.articleQuantity,10));
//                                         const imageUrl = orderArticle.articlePictureUrl;
//                                         console.log("For orderArticle: " + orderArticle.orArId)
//                                         console.log("Image url is: "+ orderArticle.articlePictureUrl);
//                                         if(this.props.addQuantityToListData){
//                                             return( 
//                                               <div>
                                                    
//                                                 <div key={orderArticle.orArId} >
//                                                     {/* <tr> <img className="bp3-button imgl" src={article1} alt="logo"  style={{width: 130, height: 130, position: "absolute", right: 160, top: pos}} /> </tr> */}
//                                                     <tr> <img className="bp3-button imgl" src= {imageUrl}  alt="logo"  style={{width: 130, height: 130, position: "absolute", left: 750, right: 160, top: 165 + index * 185}} /> 
//                                                     <div style={{position: "absolute", left: 500, right: 400, top: 165 + index * 185}}>
//                                                     <Dropzone onDrop={this.onDrop}  accept=".jpg, .png, image/*" >
//                                               <div>Try dropping a file here, or click to select a file to upload.</div>
//                                                 <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6"}} onClick = {(e) => this.setCurrentOrArId(orderArticle.orArId)}>Change Image 2</button>
//                                                 </Dropzone>
//                                                      </div>
//                                                     </tr>
                                                 
//                                                    <br/>
                                                 

//                                                    {/* <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6", position: "absolute", left: 590, right: 560, top: 275 + index * 185}}   
//                                                             onClick={(e) => { this.handleSetCurrentIndex(index, orderArticle.orArId); 
//                                                                 if(window.confirm('Are you sure you want to change this article image?')){
//                                                                 this.handleDeleteArticleFromOrderFinal(orderArticle.orArId)
//                                                                 };
//                                                             }}>Change Image 
//                                                         </button> */}

//  <div style={{position: "absolute", left: 750, right: 560, top: 275 + index * 185}}>             
       

//               {/* <ReactDropzone
          
//                          style={{}}
//                          className="dropzone"
//                          accept=".jpg, .png, image/*"
//                         //  accept="image/jpeg, image/png, image/jpg, image/bmp"
//                         inputProps={{ style: {position: 'absolute', top: -10, left: -10, width: 50, height: 50, opacity: 0}}}
                     
//                         onDrop={this.onDrop}
                        
//                         >
//                          <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6"}}>Change Image 2</button>
//                     </ReactDropzone> */}

//   {/* <ReactDropzone
//                         style={{position: "absolute", top: 0, left: 0, right: 0, bottom: 0, display: "flex", justifyContent: "center", alignItems: "center"}}
                       
//                         accept="image/jpeg, image/png, image/jpg, image/bmp"
//                         inputProps={{ style: {opacity: 0}}}
//                         onDrop={ (files) => {
                           
                            
                    
//                                 const formData = new FormData();
                              
//                                   console.log("UPLOAD FILE BEFEORE BE CALLED" + JSON.stringify(files[0]));
//                                   console.log("UPLOAD FILE NAME BEFEORE BE CALLED" + files[0].name);
//                                   const file = new Blob([files[0]], { type: 'image/jpg' });
                              
//                                   formData.append('file', file);
//                                   console.log("File: " + file)
//                                   formData.append('filename', files[0].name);
                              
//                             //   request.post('http://localhost:8080/api/uploadFile')
//                             //   .send(formData)
//                             //   .end((err, resp) => {
//                             //     if (err) {
//                             //       console.error(err);
//                             //     }
//                             //     else {console.log(JSON.stringify(resp));}
//                             //     return resp;
//                             //   });
                              
                              
                            
//                             // const formData = new FormData();
//                             // const file = new Blob([files[0]]);
//                             // formData.append('file', file);
//                             // formData.append('filename', files[0].name);

//                             // // formData.set('file', file, files[0].name);
//                             // console.log(" formData.set executed!");
//                             // console.log(files[0].name);
//                             if(this.props.orderArticlesData){
//                                 this.props.imageUploadFetch({orArId: this.props.orderArticlesData[0].orArId, data: formData});
//                                  }
//                         }}>
//                         THIS IS IT
//                         <button type="button"  className="bp3-button" style={{backgroundColor : "#ADD8E6"}}>Change Image 2</button>
//                     </ReactDropzone> */}

       

//             </div>

//                                                     <hr className="style13" style={{position: "absolute", left: 880, right: 50, top: 305 + index * 185}}  />     
//                                                     <tr> <div style={{position: "absolute", left: 890, top: 155 + index * 185}}> <b> Article:  </b>  &nbsp; {orderArticle.articleName}</div></tr>
//                                                     <tr>

//                                                         <div style={{position: "absolute", left: 890, top: 180 + index * 185}}> 
//                                                             <label className="bp3-file-input"><b>Net price: </b></label>  &nbsp;  &nbsp;  
//                                                             <Control.text className="bp3-input" model={'.netPrice' + index}
//                                                                 validators={{
//                                                                     required: (val) => val && val.length,
//                                                                     maxLength3: (val) => val && val.length && val.length <= 3 
//                                                                 }}
//                                                                 defaultValue = {orderArticle.articleNetPrice}
//                                                                 onChange={this.handleSetNetPrice}
//                                                                 onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
//                                                             />
//                                                             <Errors className="arrow_box" 
//                                                                 model={'.netPrice' + index}
//                                                                 show="touched"
//                                                                 messages={{
//                                                                     required: 'Net price required!!',
//                                                                     maxLength3: ' Please enter valid netPrice with length <= 3!!'
//                                                                 }}
//                                                             />
//                                                         </div>
//                                                     </tr>
//                                                     <tr>
//                                                         <div style={{position: "absolute", left: 890, top: 215 + index * 185}}>
//                                                             <label className="bp3-file-input"><b>Gross price: </b></label>  &nbsp;  &nbsp;                         
//                                                             <Control.text className="bp3-input"
//                                                                 model={'.grossPrice' + index}
//                                                                 validators={{
//                                                                     required: (val) => val && val.length,
//                                                                     maxLength3: (val) => val && val.length && val.length <= 3 
//                                                                 }}

//                                                                 defaultValue = {orderArticle.articleGrossPrice}
//                                                                 onChange={this.handleSetGrossPrice}
//                                                                 onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
//                                                             />
//                                                              <Errors className="arrow_box"
//                                                                 model={'.grossPrice' + index}
//                                                                 show="touched"
//                                                                 messages={{
//                                                                     required: 'Gross price required!!',
//                                                                     maxLength3: ' Please enter valid grossPrice with length <= 3!!'
//                                                                 }}
//                                                             />
//                                                         </div>
//                                                     </tr>
//                                                     <tr>
//                                                         <div style={{position: "absolute", left: 890, top: 250 + index * 185}}> 
//                                                             <b> Quantity to save:  </b> &nbsp; {this.props.addQuantityToListData[index]} 
//                                                         </div>
//                                                     </tr>
                                                  
//                                                     <br/>       
//                                                     <div style={{position: "absolute", left: 890, top: 255 + index*185}}>
//                                                         <br/>
//                                                         <label className="bp3-file-input"><b>Strict quantity: </b></label>  &nbsp;  &nbsp;   
//                                                         <Control.text
//                                                             className="bp3-input"
//                                                             model={'.quantity1' + index}
                                                            
//                                                             onChange={this.handleSetQuantity}
//                                                             onClick={(e) => this.handleSetCurrentIndex(index, orderArticle.orArId)}
//                                                         />
//                                                     {/* <hr className="style13" /> */}
//                                                     </div>
//                                                     <div style={{position: "absolute", right: 45, top: 275 + index*185}}>
//                                                         <button type="button"  className="bp3-button" style={{backgroundColor : "#FF6347"}} 
//                                                             onClick={(e) => { this.handleSetCurrentIndex(index, orderArticle.orArId); 
//                                                                 if(window.confirm('Are you sure you want to delete this article from the order?')){
//                                                                 this.handleDeleteArticleFromOrderFinal(orderArticle.orArId)
//                                                                 };
//                                                             }}>Delete article
//                                                         </button>
//                                                         {/* <hr className="style13" />      */}
//                                                     </div>
                                               
//                                                 </div>
                                               
//                                              </div>                              
//                                             )
//                                         }
//                                         else{
//                                             return null;
//                                         }
//                                         // start ++;
//                                     })}
//                                 </div>
                            


//                                 <tr>
//                                     <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#25B012", position: "absolute", left: 80, top: 650 }} > Save changes  </button>   
//                                 </tr>
//                             </Form>
//                             <br/>
//                         </div>
//                     )
//                 }           
//                 else{
//                         return (
//                             <div className="grid100">
//                                 <Form  model="forms.info" method="post" onSubmit={ (info) => this.handleSubmitSaveOrder(info)}>   
//                                     <tr>
//                                         <td>
//                                             <div>
//                                                 <label htmlFor="order_id" className="bp3-file-input"><b>Order ID: {this.props.orderDetailData.order_id} </b></label>  &nbsp;  &nbsp;  
//                                                 <br/>
//                                                 <label htmlFor="firstName" className="bp3-file-input"><b>First name: </b></label>  &nbsp;  &nbsp;  
//                                                 <Control.text className="bp3-input" model=".firstName"
//                                                  validators={{
//                                                     required: (val) => val && val.length
//                                                 }}
//                                                 defaultValue={this.props.orderDetailData.firstName}/>
//                                                 <br/>
//                                                 <label htmlFor="lastName" className="bp3-file-input"><b>Last name: </b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".lastName" defaultValue={this.props.orderDetailData.lastName}/>
//                                                 <br/>
//                                                 <label htmlFor="companyName" className="bp3-file-input"><b>Company name:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".companyName" defaultValue={this.props.orderDetailData.companyName}/>
//                                                 <br/>
//                                                 <label htmlFor="paymentMethod" className="bp3-file-input"><b>Payment method:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".paymentMethod" defaultValue={this.props.orderDetailData.paymentMethod}/>
//                                                 <br/>
//                                                 <label htmlFor="shippingWay" className="bp3-file-input"><b>Shipping way:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".shippingWay" defaultValue={this.props.orderDetailData.shippingWay}/>
//                                                 <br/>
//                                                 <label htmlFor="email" className="bp3-file-input"><b>Email:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".email" defaultValue={this.props.orderDetailData.email}/>
//                                                 <br/>
//                                                 <label htmlFor="phoneNumber" className="bp3-file-input"><b>Phone number:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".phoneNumber" defaultValue={this.props.orderDetailData.phoneNumber}/>
//                                                 <br/>
//                                                 <label htmlFor="street" className="bp3-file-input"><b>Street:</b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".street" defaultValue={this.props.orderDetailData.street}/>
//                                                 <br/>
//                                                 <label htmlFor="houseNumber" className="bp3-file-input"><b>House number:</b></label>&nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".houseNumber" defaultValue={this.props.orderDetailData.houseNumber}/>
//                                                 <br/>
//                                                 <label htmlFor="postcode" className="bp3-file-input"><b>Post code:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".postcode" defaultValue={this.props.orderDetailData.postcode}/>
//                                                 <br/>
//                                                 <label htmlFor="city" className="bp3-file-input"><b>City:</b></label> &nbsp;  &nbsp;
//                                                 <Control.text className="bp3-input" model=".city" defaultValue={this.props.orderDetailData.city}/>
//                                                 <br/>
//                                                 <label htmlFor="country" className="bp3-file-input"><b>Country: </b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".country" defaultValue={this.props.orderDetailData.country}/>
//                                                 <br/>
//                                                 <label htmlFor="netPrice" className="bp3-file-input"><b>Net price: </b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".netPrice" defaultValue={String(this.props.recalculateOrderNetPriceData)}/>
//                                                 <br/>
//                                                 <label htmlFor="grossPrice" className="bp3-file-input"><b>222222222 Gross price: </b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".grossPrice" defaultValue={String(this.props.recalculatedOrderGrossPriceData)}/>
//                                                 <br/>
//                                                 <label htmlFor="netPriceWD" className="bp3-file-input"><b>Net price (without delivery): </b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".netPriceWD" defaultValue={this.props.orderDetailData.netPriceWD}/>
//                                                 <br/>                
//                                                 <label htmlFor="grossPriceWD" className="bp3-file-input"><b>Gross price (without delivery): </b></label> &nbsp;  &nbsp; 
//                                                 <Control.text className="bp3-input" model=".grossPriceWD" defaultValue={this.props.orderDetailData.grossPriceWD}/>
//                                                 <br/>
//                                             </div>    
//                                         </td>
//                                     </tr>
//                                     <tr>
//                                         <button type="submit" value="Submit" className="bp3-button"  style={{backgroundColor : "#4682B4", position: "absolute", right: 30, top: 690 }} > Save changes  </button>         
//                                     </tr>
//                                 </Form>
//                                 <br/>
//                             </div>
//                         )
//                 }
//             }
//             else {
//                 return null;
//             }
        
     
//         }
    }
}

const mapStateToProps = (state: IRootState) => ({
    hotelData: getHotelList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getHotelDetail(state),
    orderArticlesData: getHotelArticles(state),
    orderSavedData: getSavedOrder(state),
    addQuantityToListData: getQuantityList(state),
    setCurrentIndexData: getCurrentIndex(state),
    addNetPriceToListData: getNetPriceList(state),
    addGrossPriceToListData: getGrossPriceList(state),
    setModal3IsOpenData: getModal3IsOpen(state),
    recalculateOrderNetPriceData: getRecalculatedOrderNetPrice(state),
    recalculatedOrderGrossPriceData: getRecalculatedOrderGrossPrice(state),
    getSavedOrderHasError: getSavedOrderHasError(state),
    setPictureUrlData: getSetPictureUrl(state)
});

export default connect(mapStateToProps, {hotelListFetch, filterOrderFetch, hotelDetailFetch, getHotelArticlesFetch, orderSaveFetch, cancelOrderFetch, deleteArticleFromOrderFetch, addQuantityToListFetch, setCurrentIndexFetch, addNetPriceToListFetch, addGrossPriceToListFetch, setModal3IsOpenFetch, recalculateOrderNetPriceFetch, recalculateOrderGrossPriceFetch, imageUploadFetch, setPictureUrlFetch})(EditOrder)

