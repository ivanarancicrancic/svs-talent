import { ActionType, getType } from 'typesafe-actions';
import { IOrderResponseModel } from './types';

import * as actions from './actions';


const extActions = {...actions};

export type OrderListActions = ActionType<typeof extActions>;

export interface IOrderListState {
    readonly data: IOrderResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IOrderListState = {
    data: null,
    loading: false,
    error: null
};
  
export function orderListReducer(state: IOrderListState = INITIAL_STATE, action: OrderListActions): IOrderListState  {
    switch (action.type) {
        case getType(extActions.orderListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.orderListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.orderListFail):
            return {...state, loading: false, error: action.payload};

        default:
            return state;
    }
}