import { UI_SHOW_CREATE_CATEGORY, UI_HIDE_CREATE_CATEGORY } from './types';

import { createStandardAction } from 'typesafe-actions';

export const uiShowCreateCategory = createStandardAction(UI_SHOW_CREATE_CATEGORY)();
export const uiHideCreateCategory = createStandardAction(UI_HIDE_CREATE_CATEGORY)();