import { IRootState } from '..'

export const getForgotPasswordIsLoading = (state: IRootState) => state.forgotPassword.forgotLoading;
export const getForgotPasswordHasError = (state: IRootState) => state.forgotPassword.forgotError;

export const getResetPasswordIsLoading = (state: IRootState) => state.forgotPassword.resetLoading;
export const getResetPasswordHasError = (state: IRootState) => state.forgotPassword.forgotError;