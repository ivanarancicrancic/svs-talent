import {
    FILTER_ORDER_FETCH,
    FILTER_ORDER_SUCCESS,
    FILTER_ORDER_FAIL,
    IOrderResponseModel,
} from './types';

import { createStandardAction } from 'typesafe-actions';

export const filterOrderFetch = createStandardAction(FILTER_ORDER_FETCH)();
export const filterOrderSuccess = createStandardAction(FILTER_ORDER_SUCCESS)<IOrderResponseModel[]>();
export const filterOrderFail = createStandardAction(FILTER_ORDER_FAIL)<string>();
