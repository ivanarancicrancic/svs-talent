import { IRootState } from '..'

export const getOrderList = (state: IRootState) => state.filteredOrders.data;
export const getOrderListIsLoading = (state: IRootState) => state.filteredOrders.loading;
export const getOrderListHasError = (state: IRootState) => state.filteredOrders.error;