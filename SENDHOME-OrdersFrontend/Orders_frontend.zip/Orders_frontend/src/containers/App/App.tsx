import * as React from 'react';
import { connect } from 'react-redux';

import { IRootState } from '../../redux';

import '@blueprintjs/icons/lib/css/blueprint-icons.css';
import '@blueprintjs/core/lib/css/blueprint.css'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faEnvelope, faKey,  } from '@fortawesome/free-solid-svg-icons';
import "../../assets/fontello/css/fontello.css";

import { RouteComponentProps, Switch, Route } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_START } from '../../router/paths';
import Header from '../../components/Header/Header';
import Footer from '../../components/Footer/Footer';

import './App.css';
import StartLayout from '../../components/StartLayout/StartLayout';

library.add(faEnvelope, faKey);

interface IPropsStateMap {
  auth: IAuthState
}

type IProps = RouteComponentProps<{}> & IPropsStateMap;

class App extends React.Component<IProps> {

  public render() {
    return (
      <div className="appContainer">
        <Header />
        <div className="appContentContainer">
        <Switch>
            <Route path={PATH_START} exact={true} component={StartLayout} />
         </Switch>
        </div>
        <Footer />
      </div>
    );
  }


}
const mapStateToProps = (state: IRootState) => ({
  auth: state.auth
});

export default connect(mapStateToProps)(App);