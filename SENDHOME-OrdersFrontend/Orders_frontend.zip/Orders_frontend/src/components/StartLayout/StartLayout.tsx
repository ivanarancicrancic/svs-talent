import * as React from 'react';
import { connect } from 'react-redux';

import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import DatePicker from 'react-date-picker';
import { Button } from "@blueprintjs/core";

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
    }

    public componentWillMount() {
        this.props.orderListFetch();
        console.log("Date on mount: " + this.state.dateFrom);
    }

    public handleFilter(){
        this.props.filterOrderFetch(); 
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        console.log("State dateFrom: " + this.state.dateFrom)
        
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
     this.setState({dateTo: entryDate}); 
     console.log("State dateFrom: " + this.state.dateTo)
     
  };

 public renderOrderList() {

        if(!this.props.orderData) {
            return null;
        }


        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <thead>                  
                <tr>
                        <th>Order ID</th>
                        <th>Oder DATE</th>
                        <th>Payment Method </th>
                        <th>FirstName </th>
                                <th>LastName </th>
                                <th>CompanyName </th>
                                <th>Country </th>
                                <th>Email </th>
                        </tr>

                </thead>
                <tbody>
                    
                    {this.props.orderData.map( order => {
                        return (
                            <tr key={order.order_id}>
                                <td><b>{order.order_id}</b></td>
                                <td>{order.orderDate} </td> 
                                <td>{order.paymentMethod} </td>
                                <td>{order.firstName} </td>
                                <td>{order.lastName} </td>
                                <td>{order.companyName} </td>
                                <td>{order.country} </td>
                                <td>{order.email} </td>
                                
                            </tr>
                        )
                    })}
                  
                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
              
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>
        <DatePicker
          onChange={this.handleDateFrom}
        /> &nbsp; &nbsp; &nbsp;
        <b>       End date: </b>
                <DatePicker
          onChange={this.handleDateTo}
        />
        &nbsp; &nbsp; &nbsp;

       <Button className="bp3-button" onClick={this.handleFilter }  text="Filter"/>            

      </div>
              <br/>
                {this.renderOrderList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getOrderList(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch})(DashboardLayout)