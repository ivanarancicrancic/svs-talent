import * as React from 'react';
import './HamburgerMenu.css';
import {Link, NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD} from "../../router/paths";
import { Translate } from 'react-redux-i18n';

export default class HamburgerMenu extends React.Component{

    public renderUser() {


        return <span className="userInfo"> 
                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">
                    <i  className="fontello icon-user" />
                </NavLink></span>;
    }


    public render() {
        return (
            <div>
              
                <nav role="navigation">
                <div className="menuToggle">
                    <input type="checkbox" />
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                    <span className="burgerBtn"/>
                        <ul className="menu">
                            {this.renderUser()}
                            <Link to={PATH_ROOT} className="bp3-navbar-heading">1 >> <Translate value="header.account" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">2 >> <Translate value="header.buy-category" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">4 >> <Translate value="header.administration" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">5 >> <Translate value="header.statistics" /></Link>
                            <Link to={PATH_DASHBOARD} className="bp3-navbar-heading">6 <Translate value="header.push" /></Link>
                            <div className="searchBtn"> <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span> </div>
                        </ul>
                </div>
                </nav>
            </div>
        );
    }
}


// export default connect()(HamburgerMenu)