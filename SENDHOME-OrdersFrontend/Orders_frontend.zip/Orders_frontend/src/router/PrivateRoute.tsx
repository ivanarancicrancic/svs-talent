import * as React from "react"
import { Route } from "react-router-dom"
import { RouteComponentProps } from "react-router"
import { connect } from "react-redux";
import { IRootState } from "../redux";
import { IAuthState } from "../redux/auth/reducer";

interface IPrivateRouteProps {
    readonly component: React.ComponentClass<RouteComponentProps<{}>>,
    readonly path: string
}

interface IPropsFromStateMap {
    auth: IAuthState
}

type Props = IPrivateRouteProps & IPropsFromStateMap;

class PrivateRoute extends React.Component<Props> {

    public render() {
        return <Route render={this.renderRoutes}/>
    }

    private renderRoutes = (props: RouteComponentProps<{}>): JSX.Element => {

        const Component = this.props.component;
            return <Component {...props} />
       
    }

}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

export default connect(mapStateToProps, {})(PrivateRoute)