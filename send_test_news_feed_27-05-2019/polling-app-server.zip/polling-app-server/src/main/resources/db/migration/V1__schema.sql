
CREATE TABLE `feeds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `link` varchar(50) NOT NULL,
  `description` longtext NOT NULL,
  `language` varchar(15) NOT NULL,
  `copyright` timestamp DEFAULT CURRENT_TIMESTAMP,
  `pubDate` timestamp DEFAULT CURRENT_TIMESTAMP,



  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `feedmessages` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(40) NOT NULL,
  `description` longtext NOT NULL,
  `link` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
    `guid` varchar(50) NOT NULL,
        `url` varchar(50) NOT NULL,
      `summary` longtext NOT NULL,
  `created_date` timestamp DEFAULT CURRENT_TIMESTAMP,
  `image_saved_url` timestamp DEFAULT CURRENT_TIMESTAMP,
	fk_feed bigint
		constraint fkr61qqo2uywsg0ot73d7dfcxhm
			references feeds,

  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

