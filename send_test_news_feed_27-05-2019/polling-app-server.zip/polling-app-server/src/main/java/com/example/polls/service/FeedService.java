package com.example.polls.service;


import com.example.polls.model.Feed;
import com.example.polls.repository.FeedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedService {


    @Autowired
    private FeedRepository feedRepository;

    public FeedService(FeedRepository feedRepository) {

        this.feedRepository = feedRepository;

    }

    public Feed saveFeed(Feed feed) {

        return feedRepository.save(feed);
    }


}
