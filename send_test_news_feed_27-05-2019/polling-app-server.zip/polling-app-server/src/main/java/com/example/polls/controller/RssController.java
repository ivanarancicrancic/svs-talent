package com.example.polls.controller;

import com.example.polls.model.Feed;
import com.example.polls.model.FeedMessage;
import com.example.polls.service.FeedMessageService;
import com.example.polls.service.FeedService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.xml.stream.XMLInputFactory;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;

import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.Characters;
import javax.xml.stream.events.XMLEvent;
import org.apache.commons.io.FilenameUtils;



@RestController
public class RssController {

	static final String TITLE = "title";
	static final String DESCRIPTION = "description";
	static final String CHANNEL = "channel";
	static final String LANGUAGE = "language";
	static final String COPYRIGHT = "copyright";
	static final String LINK = "link";
	static final String AUTHOR = "author";
	static final String ITEM = "item";
	static final String PUB_DATE = "pubDate";
	static final String GUID = "guid";
	static final String URL = "url";
	static final String ENCLOSURE = "enclosure";
	static final String CREATEDDATE = "createdDate";

	URL url = null;

	@Autowired
	private FeedMessageService feedMessageService;

	@Autowired
	private FeedService feedService;

	public RssController(FeedMessageService feedMessageService, FeedService feedService){

		this.feedMessageService = feedMessageService;
		this.feedService = feedService;
		try {
			this.url =  new URL("http://feeds.nos.nl/nosjournaal?format=xml");
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}

	}

	@GetMapping("/rssfeed")
	@Scheduled(fixedRate=2000)
	public Feed getFeedInRss() {

//		List<SampleContent> items = new ArrayList<SampleContent>();
//
//		SampleContent content  = new SampleContent();
//		content.setTitle("Spring MVC Tutorial 1");
//		content.setUrl("http://www.mkyong.com/spring-mvc/tutorial-1");
//		content.setSummary("Tutorial 1 summary ...");
//		content.setCreatedDate(new Date());
//		items.add(content);
//
//		SampleContent content2  = new SampleContent();
//		content2.setTitle("Spring MVC Tutorial 2");
//		content2.setUrl("http://www.mkyong.com/spring-mvc/tutorial-2");
//		content2.setSummary("Tutorial 2 summary ...");
//		content2.setCreatedDate(new Date());
//		items.add(content2);
//
////		ModelAndView mav = new ModelAndView();
////		mav.setViewName("rssViewer");
////		mav.addObject("feedContent", items);
//		System.out.println(items);
//           for(SampleContent s : items){
//
//			   System.out.println("Content with \n" +
//					   " Title: " + s.getTitle() +
//					   "\n Url: " + s.getUrl() +
//					   "\n Summary: " + s.getSummary() +
//					   "\n createdDate: " + s.getCreatedDate());


		Feed feed = null;
		try {
			boolean isFeedHeader = true;
			// Set header values intial to the empty string
			String description = "";
			String title = "";
			String link = "";
			String language = "";
			String copyright = "";
			String author = "";
			String pubdate = "";
			String guid = "";
			String url = "";
			String summary = "";
			String createdDate = "";
			String imageUrl = "";
			String imageName = "";
			String imageSavedUrl = "";

			// First create a new XMLInputFactory
			XMLInputFactory inputFactory = XMLInputFactory.newInstance();

			inputFactory.setProperty(inputFactory.IS_COALESCING, new Boolean(true));

			// Setup a new eventReader
			InputStream in = read();
			XMLEventReader eventReader = inputFactory.createXMLEventReader(in);
			// read the XML document
			while (eventReader.hasNext()) {
				XMLEvent event = eventReader.nextEvent();
				if (event.isStartElement()) {
					String localPart = event.asStartElement().getName()
							.getLocalPart();
					switch (localPart) {
						case ITEM:
							if (isFeedHeader) {
								isFeedHeader = false;
								feed = new Feed(title, link, description, language,
										copyright, pubdate);
							}
							event = eventReader.nextEvent();
							break;
						case TITLE:
							title = getCharacterData(event, eventReader);
							break;
						case DESCRIPTION:
							event = eventReader.nextEvent();
							if (event.getClass().getName().equals("com.ctc.wstx.evt.CompactStartElement")) {
								description = event.asStartElement().asCharacters().getData();
								System.out.println("D1: " + description);
							} else {
								description = event.asCharacters().getData();
								System.out.println("D2: " + description);
							}

							 summary = description;
//							String all = "<img src=\"http://www.01net.com/images/article/mea/150.100.790233.jpg\""; // shortened it
							String all = description;
							String s = "<img src=\"";
							int ix = all.indexOf(s)+s.length();
							System.out.println("INDEX OF S IS: " + ix);
							if(all.indexOf("\"", ix+1)!= -1){
								System.out.println("END INDEX IS: " + all.indexOf("\"", ix+1));
								imageUrl = all.substring(ix, all.indexOf("\"", ix+1));
								try {
									URL imageUrlURL = new URL(imageUrl);
									imageName = FilenameUtils.getName(imageUrlURL.getPath()); // -> file.xml
									System.out.println("ImageName: " + imageName);
									System.out.println("ImageURL: " + imageUrl);
									imageSavedUrl = downloadFile(imageUrl, imageName);
								}catch (Exception e){
									System.out.println("exception url");
								}
							}
//							description = getCharacterData(event, eventReader);
							break;
						case LINK:
							link = getCharacterData(event, eventReader);
							break;
						case GUID:
							guid = getCharacterData(event, eventReader);
							break;
						case LANGUAGE:
							language = getCharacterData(event, eventReader);
							break;
						case AUTHOR:
							author = getCharacterData(event, eventReader);
							break;
						case PUB_DATE:
							pubdate = getCharacterData(event, eventReader);
							createdDate = pubdate;
							break;
						case COPYRIGHT:
							copyright = getCharacterData(event, eventReader);
							break;

						case URL:
							url = getCharacterData(event, eventReader);
							break;

						case ENCLOSURE:
							Iterator<Attribute> attrs = event.asStartElement().getAttributes();
							summary = "";
							while (attrs.hasNext()) {
								Attribute attr = attrs.next();
								if (attr.getName().toString().equals(URL)) {
									summary = attr.getValue();
									try {
										URL imageUrl1 = new URL(summary);
										imageName = FilenameUtils.getName(imageUrl1.getPath()); // -> file.jpg
										System.out.println("ImageName: " + imageName);
										downloadFile(summary, imageName);
									}catch (Exception e){
										System.out.println("exception url");
									}
								}
							}
							break;

						case CREATEDDATE:
							createdDate = getCharacterData(event, eventReader);
							break;




					}
				} else if (event.isEndElement()) {
					if (event.asEndElement().getName().getLocalPart() == (ITEM)) {

						if(feedMessageService.getFeedMessage(title) != null){
							FeedMessage feedMessage = feedMessageService.getFeedMessage(title);

							feedMessage.setAuthor(author);
							feedMessage.setDescription(description);
							feedMessage.setSummary(summary);
							feedMessage.setGuid(guid);
							feedMessage.setLink(link);
							feedMessage.setTitle(title);
							feedMessage.setUrl(url);
							feedMessage.setImageSavedUrl(imageSavedUrl);
							feedMessage.setCreatedDate(createdDate);

							feedMessageService.saveFeedMessage(feedMessage);

							feed.getMessages().add(feedMessage);
						}
                       else {
							FeedMessage message = new FeedMessage();
							message.setAuthor(author);
							message.setDescription(description);
							message.setSummary(summary);
							message.setGuid(guid);
							message.setLink(link);
							message.setTitle(title);
							message.setUrl(url);
							message.setImageSavedUrl(imageSavedUrl);
							message.setCreatedDate(createdDate);


							feedMessageService.saveFeedMessage(message);
							feed.getMessages().add(message);
						}
//						final String url = enclosure.getUrl();
//						if (url != null) {
//							enclosureElement.setAttribute("url", url);
//						}


						event = eventReader.nextEvent();
						continue;
					}
				}
			}

			feedService.saveFeed(feed);
		} catch (XMLStreamException e) {
			throw new RuntimeException(e);
		}

		System.out.println("Feeds");

		for(FeedMessage message : feed.getMessages()){
			System.out.println("Title: " + message.getTitle());
			System.out.println("Author: " + message.getAuthor());
			System.out.println("Description: " + message.getDescription());
			System.out.println("Link: " + message.getLink());
			System.out.println("URL: " + message.getUrl());
			System.out.println("Enclosure: " + message.getSummary());
			System.out.println("CreatedDate: " + message.getCreatedDate());
		}




		return feed;



//		   }
//		return mav;

	}

	private String getCharacterData(XMLEvent event, XMLEventReader eventReader)
			throws XMLStreamException {
		String result = "";
		event = eventReader.nextEvent();
		if (event instanceof Characters) {
			result = event.asCharacters().getData();
		}
		return result;
	}




	private InputStream read() {
		try {
			return url.openStream();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}


	public String downloadFile(String uRl, String imageName) {

		try {
			URL url = new URL(uRl);
			InputStream in = new BufferedInputStream(url.openStream());
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			byte[] buf = new byte[1024];
			int n = 0;
			while (-1 != (n = in.read(buf))) {
				out.write(buf, 0, n);
			}
			out.close();
			in.close();
			byte[] response = out.toByteArray();


			FileOutputStream fos = new FileOutputStream("C://Users//MIA//Desktop//news-feed-project//news-feed-23-05-2019-all-in-one//" + imageName);
			fos.write(response);
			fos.close();
			return "C://Users//MIA//Desktop//news-feed-project//news-feed-23-05-2019-all-in-one//" + imageName;
		}
		catch (Exception e) {

			System.out.println("Exception!!");
			return null;
		}
	}


	
}