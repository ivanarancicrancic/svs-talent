package com.example.polls.service;

import com.example.polls.model.Feed;
import com.example.polls.model.FeedMessage;
import com.example.polls.repository.FeedMessageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class FeedMessageService {

    @Autowired
    private FeedMessageRepository feedMessageRepository;

    public FeedMessageService(FeedMessageRepository feedMessageRepository) {

        this.feedMessageRepository = feedMessageRepository;
    }

    public FeedMessage saveFeedMessage(FeedMessage feedMessage) {

        return feedMessageRepository.save(feedMessage);
    }


   public FeedMessage getFeedMessage(String title){

        return feedMessageRepository.findByTitle(title);

   }

}


