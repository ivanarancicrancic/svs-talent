package Models;

public class LoanRequestsByParametar {
    Long loanrequestid;
    String firstname;
    String lastname;
    String requestdate;
    String embg;
    String loantypeshortname;

    public LoanRequestsByParametar(Long loanrequestid, String firstname, String lastname, String requestdate, String embg, String loantypeshortname) {
        this.loanrequestid = loanrequestid;
        this.firstname = firstname;
        this.lastname = lastname;
        this.requestdate = requestdate;
        this.embg = embg;
        this.loantypeshortname = loantypeshortname;
    }

    public Long getLoanrequestid() {
        return loanrequestid;
    }

    public void setLoanrequestid(Long loanrequestid) {
        this.loanrequestid = loanrequestid;
    }

    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(String requestdate) {
        this.requestdate = requestdate;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getLoantypeshortname() {
        return loantypeshortname;
    }

    public void setLoantypeshortname(String loantypeshortname) {
        this.loantypeshortname = loantypeshortname;
    }
}
