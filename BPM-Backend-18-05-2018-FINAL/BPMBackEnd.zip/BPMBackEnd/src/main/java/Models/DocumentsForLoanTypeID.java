package Models;

public class DocumentsForLoanTypeID {
    public int getDocumentID() {
        return documentID;
    }

    public void setDocumentID(int documentID) {
        this.documentID = documentID;
    }

    private int documentID;

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentName() {
        return documentName;
    }

    private String documentName;

    public DocumentsForLoanTypeID(int documentID, String documentName) {
        this.documentID = documentID;
        this.documentName = documentName;
    }

    public DocumentsForLoanTypeID() {
    }




}
