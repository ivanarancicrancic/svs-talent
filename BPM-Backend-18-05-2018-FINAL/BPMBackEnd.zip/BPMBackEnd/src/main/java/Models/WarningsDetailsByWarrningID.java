package Models;

public class WarningsDetailsByWarrningID {

 private String warrningType;
 private String sendDate;
 private String warrningDetails;
 private String embg;
 private String fileName;

    public WarningsDetailsByWarrningID() {
    }

    public WarningsDetailsByWarrningID(String warrningType, String sendDate, String warrningDetails, String embg, String fileName) {
        this.warrningType = warrningType;
        this.sendDate = sendDate;
        this.warrningDetails = warrningDetails;
        this.embg = embg;
        this.fileName = fileName;
    }

    public String getWarrningType() {
        return warrningType;
    }

    public void setWarrningType(String warrningType) {
        this.warrningType = warrningType;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getWarrningDetails() {
        return warrningDetails;
    }

    public void setWarrningDetails(String warrningDetails) {
        this.warrningDetails = warrningDetails;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
}

