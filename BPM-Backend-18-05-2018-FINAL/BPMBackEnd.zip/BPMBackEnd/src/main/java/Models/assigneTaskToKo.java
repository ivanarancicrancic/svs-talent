package Models;

public class assigneTaskToKo {
    private int groupid;
    private String assigneFrom;
    private int requestid;

    public assigneTaskToKo() {
    }

    public assigneTaskToKo(int groupid, String assigneFrom, int requestid) {
        this.groupid = groupid;
        this.assigneFrom = assigneFrom;
        this.requestid = requestid;
    }

    public int getGroupid() {
        return groupid;
    }

    public void setGroupid(int groupid) {
        this.groupid = groupid;
    }

    public String getAssigneFrom() {
        return assigneFrom;
    }

    public void setAssigneFrom(String assigneFrom) {
        this.assigneFrom = assigneFrom;
    }

    public int getRequestid() {
        return requestid;
    }

    public void setRequestid(int requestid) {
        this.requestid = requestid;
    }
}
