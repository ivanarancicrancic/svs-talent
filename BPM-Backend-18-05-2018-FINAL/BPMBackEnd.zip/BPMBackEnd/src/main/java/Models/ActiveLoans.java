package Models;

public class ActiveLoans {

   private String status;
   private int brdosie;
    private int brrati;
    private int brplatenirati;
    private int brzadocnetirati;
    private int neplateniznost;
    private String datumposlednoplakanje;
    private String aplicantname;
    private String valuta;
    private int rokOtplata;
    private int grejsPeriod;
    private int iznos;
    private String embg;

    public ActiveLoans(String status, int brdosie, int brrati, int brplatenirati, int brzadocnetirati, int neplateniznost, String datumposlednoplakanje, String aplicantname, String valuta, int rokOtplata, int grejsPeriod, int iznos, String embg) {
        this.status = status;
        this.brdosie = brdosie;
        this.brrati = brrati;
        this.brplatenirati = brplatenirati;
        this.brzadocnetirati = brzadocnetirati;
        this.neplateniznost = neplateniznost;
        this.datumposlednoplakanje = datumposlednoplakanje;
        this.aplicantname = aplicantname;
        this.valuta = valuta;
        this.rokOtplata = rokOtplata;
        this.grejsPeriod = grejsPeriod;
        this.iznos = iznos;
        this.embg = embg;
    }

    public String getEmbg() {
        return embg;
    }

    public void setEmbg(String embg) {
        this.embg = embg;
    }

    public int getIznos() {
        return iznos;
    }

    public void setIznos(int iznos) {
        this.iznos = iznos;
    }

    public String getValuta() {
        return valuta;
    }

    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    public int getRokOtplata() {
        return rokOtplata;
    }

    public void setRokOtplata(int rokOtplata) {
        this.rokOtplata = rokOtplata;
    }

    public int getGrejsPeriod() {
        return grejsPeriod;
    }

    public void setGrejsPeriod(int grejsPeriod) {
        this.grejsPeriod = grejsPeriod;
    }



    public String  getStatus() {
        return status;
    }

    public void setStatus(String  status) {
        this.status = status;
    }

    public int getBrdosie() {
        return brdosie;
    }

    public void setBrdosie(int brdosie) {
        this.brdosie = brdosie;
    }

    public int getBrrati() {
        return brrati;
    }

    public void setBrrati(int brrati) {
        this.brrati = brrati;
    }

    public int getBrplatenirati() {
        return brplatenirati;
    }

    public void setBrplatenirati(int brplatenirati) {
        this.brplatenirati = brplatenirati;
    }

    public int getBrzadocnetirati() {
        return brzadocnetirati;
    }

    public void setBrzadocnetirati(int brzadocnetirati) {
        this.brzadocnetirati = brzadocnetirati;
    }

    public int getNeplateniznost() {
        return neplateniznost;
    }

    public void setNeplateniznost(int neplateniznost) {
        this.neplateniznost = neplateniznost;
    }

    public String getDatumposlednoplakanje() {
        return datumposlednoplakanje;
    }

    public void setDatumposlednoplakanje(String datumposlednoplakanje) {
        this.datumposlednoplakanje = datumposlednoplakanje;
    }

    public String getAplicantname() {
        return aplicantname;
    }

    public void setAplicantname(String aplicantname) {
        this.aplicantname = aplicantname;
    }
}
