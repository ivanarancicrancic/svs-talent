package Models;

public class LoginStatus {

    private Integer status;

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    private String formName;
    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    private String groupName;

    public LoginStatus() {
    }

    public LoginStatus(Integer status,String groupName,String formName) {
        this.status = status;
        this.groupName=groupName;
        this.formName=formName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
