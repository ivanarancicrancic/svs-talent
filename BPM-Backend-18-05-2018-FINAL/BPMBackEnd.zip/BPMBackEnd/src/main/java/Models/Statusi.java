package Models;

public class Statusi {
    private int statusID;
    private String statusName;
    private String formName;

    public String getFormName() {
        return formName;
    }



    public void setFormName(String formName) {
        this.formName = formName;
    }

    public Statusi() {

    }

    public Statusi(int statusID, String statusName, String statusDescription,String formName) {
        this.statusID = statusID;
        this.statusName = statusName;
        this.statusDescription = statusDescription;
        this.formName=formName;
    }

    private String statusDescription;

    public int getStatusID() {
        return statusID;
    }

    public void setStatusID(int statusID) {
        this.statusID = statusID;
    }

    public String getStatusName() {
        return statusName;
    }

    public void setStatusName(String statusName) {
        this.statusName = statusName;
    }

    public String getStatusDescription() {
        return statusDescription;
    }

    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }


}
