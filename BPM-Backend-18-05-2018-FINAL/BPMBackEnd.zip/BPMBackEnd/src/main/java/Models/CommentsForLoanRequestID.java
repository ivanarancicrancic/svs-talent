package Models;

public class CommentsForLoanRequestID {

    private String comment;
    private String komentiranoOd;
    private String datumn;

    public CommentsForLoanRequestID() {
    }

    public CommentsForLoanRequestID(String comment, String komentiranoOd, String datumn) {
        this.comment = comment;
        this.komentiranoOd = komentiranoOd;
        this.datumn = datumn;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getKomentiranoOd() {
        return komentiranoOd;
    }

    public void setKomentiranoOd(String komentiranoOd) {
        this.komentiranoOd = komentiranoOd;
    }

    public String getDatumn() {
        return datumn;
    }

    public void setDatumn(String datumn) {
        this.datumn = datumn;
    }
}
