package Models;

public class AttachedDocumentsForLoanRequestID {

    //private String tipdoc;
   // private String doc_zabeleshka;
   // private String prikaceno_od;
   // private String datum_prikacuvanje;
   // private String file_path;
    private String docTip;
    private String docZabeleshka;
    private String prikachenoOd;
    private String datumNaPrikachuvanje;
    private String filePath;

    public AttachedDocumentsForLoanRequestID() {
    }

    public AttachedDocumentsForLoanRequestID(String docTip, String docZabeleshka, String prikachenoOd, String datumNaPrikachuvanje, String filePath) {
        this.docTip = docTip;
        this.docZabeleshka = docZabeleshka;
        this.prikachenoOd = prikachenoOd;
        this.datumNaPrikachuvanje = datumNaPrikachuvanje;
        this.filePath = filePath;
    }

    public String getDocTip() {
        return docTip;
    }

    public void setDocTip(String docTip) {
        this.docTip = docTip;
    }

    public String getDocZabeleshka() {
        return docZabeleshka;
    }

    public void setDocZabeleshka(String docZabeleshka) {
        this.docZabeleshka = docZabeleshka;
    }

    public String getPrikachenoOd() {
        return prikachenoOd;
    }

    public void setPrikachenoOd(String prikachenoOd) {
        this.prikachenoOd = prikachenoOd;
    }

    public String getDatumNaPrikachuvanje() {
        return datumNaPrikachuvanje;
    }

    public void setDatumNaPrikachuvanje(String datumNaPrikachuvanje) {
        this.datumNaPrikachuvanje = datumNaPrikachuvanje;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }
    //    public AttachedDocumentsForLoanRequestID(String tipdoc, String doc_zabeleshka, String prikaceno_od, String datum_prikacuvanje, String file_path) {
//        this.tipdoc = tipdoc;
//        this.doc_zabeleshka = doc_zabeleshka;
//        this.prikaceno_od = prikaceno_od;
//        this.datum_prikacuvanje = datum_prikacuvanje;
//        this.file_path = file_path;
//    }
//
//    public String getTipdoc() {
//        return tipdoc;
//    }
//
//    public void setTipdoc(String tipdoc) {
//        this.tipdoc = tipdoc;
//    }
//
//    public String getDoc_zabeleshka() {
//        return doc_zabeleshka;
//    }
//
//    public void setDoc_zabeleshka(String doc_zabeleshka) {
//        this.doc_zabeleshka = doc_zabeleshka;
//    }
//
//    public String getPrikaceno_od() {
//        return prikaceno_od;
//    }
//
//    public void setPrikaceno_od(String prikaceno_od) {
//        this.prikaceno_od = prikaceno_od;
//    }
//
//    public String getDatum_prikacuvanje() {
//        return datum_prikacuvanje;
//    }
//
//    public void setDatum_prikacuvanje(String datum_prikacuvanje) {
//        this.datum_prikacuvanje = datum_prikacuvanje;
//    }
//
//    public String getFile_path() {
//        return file_path;
//    }
//
//    public void setFile_path(String file_path) {
//        this.file_path = file_path;
//    }
}
