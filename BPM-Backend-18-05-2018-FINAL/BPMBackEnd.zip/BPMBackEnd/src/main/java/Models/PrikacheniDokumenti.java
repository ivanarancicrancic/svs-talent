package Models;

public class PrikacheniDokumenti {
    private String docTip;
    private String docZabeleshka;
    private String prikachenoOd;
    private String datumNaPrikachuvanje;
    private String filePath;

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    private int requestid;

    public int getRequestid() {
        return requestid;
    }

    public void setRequestid(int requestid) {
        this.requestid = requestid;
    }

    public PrikacheniDokumenti() {
    }

    public String getDocTip() {
        return docTip;
    }

    public void setDocTip(String docTip) {
        this.docTip = docTip;
    }

    public String getDocZabeleshka() {
        return docZabeleshka;
    }

    public void setDocZabeleshka(String docZabeleshka) {
        this.docZabeleshka = docZabeleshka;
    }

    public String getPrikachenoOd() {
        return prikachenoOd;
    }

    public void setPrikachenoOd(String prikachenoOd) {
        this.prikachenoOd = prikachenoOd;
    }

    public String getDatumNaPrikachuvanje() {
        return datumNaPrikachuvanje;
    }

    public void setDatumNaPrikachuvanje(String datumNaPrikachuvanje) {
        this.datumNaPrikachuvanje = datumNaPrikachuvanje;
    }



    public PrikacheniDokumenti(String filePath,String docTip, String docZabeleshka, String prikachenoOd, String datumNaPrikachuvanje, int requestid) {
        this.docTip = docTip;
        this.docZabeleshka = docZabeleshka;
        this.prikachenoOd = prikachenoOd;
        this.datumNaPrikachuvanje = datumNaPrikachuvanje;
        this.requestid = requestid;
        this.filePath=filePath;
    }
}
