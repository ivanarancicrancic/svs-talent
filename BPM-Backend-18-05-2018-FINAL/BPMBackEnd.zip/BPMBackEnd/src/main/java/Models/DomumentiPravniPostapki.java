package Models;

public class DomumentiPravniPostapki {
    private long id;
    private String dokumentipravnipostapki;

    public DomumentiPravniPostapki(long id, String dokumentipravnipostapki) {
        this.id = id;
        this.dokumentipravnipostapki = dokumentipravnipostapki;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getDokumentipravnipostapki() {
        return dokumentipravnipostapki;
    }

    public void setDokumentipravnipostapki(String dokumentipravnipostapki) {
        this.dokumentipravnipostapki = dokumentipravnipostapki;
    }
}
