package Models;

public class ReAssigneModel {
    private String assigneFrom;
    private int requestId;
    private String groupName;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public ReAssigneModel() {
    }

    public ReAssigneModel(String assigneFrom, int requestId,String groupName) {
        this.assigneFrom = assigneFrom;
        this.requestId = requestId;
        this.groupName=groupName;
    }

    public String getAssigneFrom() {
        return assigneFrom;
    }

    public void setAssigneFrom(String assigneFrom) {
        this.assigneFrom = assigneFrom;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }
}
