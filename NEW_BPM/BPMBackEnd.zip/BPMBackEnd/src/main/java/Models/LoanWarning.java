package Models;

public class LoanWarning {

    int warrningid;
    int loanid;
    String warrningdetails;
    int warrningpdfid;
    String warrningdatte;

    public LoanWarning(){}
    public LoanWarning(int warrningid, int loanid, String warrningdetails, int warrningpdfid, String warrningdatte) {
        this.warrningid=warrningid;
        this.loanid = loanid;
        this.warrningdetails = warrningdetails;
        this.warrningpdfid = warrningpdfid;
        this.warrningdatte = warrningdatte;
    }

    public int getWarrningid() {
        return warrningid;
    }

    public void setWarrningid(int warrningid) {
        this.warrningid = warrningid;
    }

    public int getLoanid() {
        return loanid;
    }

    public void setLoanid(int loanid) {
        this.loanid = loanid;
    }

    public String getWarrningdetails() {
        return warrningdetails;
    }

    public void setWarrningdetails(String warrningdetails) {
        this.warrningdetails = warrningdetails;
    }

    public int getWarrningpdfid() {
        return warrningpdfid;
    }

    public void setWarrningpdfid(int warrningpdfid) {
        this.warrningpdfid = warrningpdfid;
    }

    public String getWarrningdatte() {
        return warrningdatte;
    }

    public void setWarrningdatte(String warrningdatte) {
        this.warrningdatte = warrningdatte;
    }
}
