package Models;

public class LoanType {

    private Integer loanTypeID;
    private String loantypeshortname;

    public LoanType() {
    }

    public LoanType(Integer loanTypeID, String loantypeshortname) {
        this.loanTypeID = loanTypeID;
        this.loantypeshortname = loantypeshortname;
    }

    public Integer getLoanTypeID() {
        return loanTypeID;
    }

    public void setLoanTypeID(Integer loanTypeID) {
        this.loanTypeID = loanTypeID;
    }

    public String getLoantypeshortname() {
        return loantypeshortname;
    }

    public void setLoantypeshortname(String loantypeshortname) {
        this.loantypeshortname = loantypeshortname;
    }
}
