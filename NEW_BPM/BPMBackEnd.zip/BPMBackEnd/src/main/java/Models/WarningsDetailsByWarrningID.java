package Models;

public class WarningsDetailsByWarrningID {

    int warrningid;
    String warrningdatte;
    String warrningdetails;
    String pwarrningpath;

    public WarningsDetailsByWarrningID(int warrningid, String warrningdatte, String warrningdetails, String pwarrningpath) {
        this.warrningid = warrningid;
        this.warrningdatte = warrningdatte;
        this.warrningdetails = warrningdetails;
        this.pwarrningpath = pwarrningpath;
    }

    public int getWarrningid() {
        return warrningid;
    }

    public void setWarrningid(int warrningid) {
        this.warrningid = warrningid;
    }

    public String getWarrningdatte() {
        return warrningdatte;
    }

    public void setWarrningdatte(String warrningdatte) {
        this.warrningdatte = warrningdatte;
    }

    public String getWarrningdetails() {
        return warrningdetails;
    }

    public void setWarrningdetails(String warrningdetails) {
        this.warrningdetails = warrningdetails;
    }

    public String getPwarrningpath() {
        return pwarrningpath;
    }

    public void setPwarrningpath(String pwarrningpath) {
        this.pwarrningpath = pwarrningpath;
    }
}
