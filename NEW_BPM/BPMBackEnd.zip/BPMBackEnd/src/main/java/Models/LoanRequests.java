package Models;

public class LoanRequests {

    private long loanrequestid;
    private int loantypeid;
    private String client_embg;
    private String requestdate;
    private int broj_dosie;
    private String tip_komintent;
    private String org_ime;
    private String org_address;
    private String org_oblik;
    private int br_vraboteni;
    private String org_tel;
    private String funckija;
    private String profesija;
    private String strucna_podgotovka;
    private int vkupen_staz;
    private int staz_vo_firma;
    private int lice_dohod_vo_stbbt;
    private String nedviznost;
    private String adresa_nedviznost;
    private int proceneta_vrednost;
    private boolean vozilo;
    private int broj_vozila;
    private int neto_plata;
    private int kirija_p;
    private int drugi_prihodi;
    private int vkupno_prihodi;
    private boolean pod_hipoteka;
    private boolean pol;
    private int pazarna_vrednost;
    private String tip_vozilo;
    private int kirija_r;
    private int osiguruvanje;
    private int ziovtni_trosoci;
    private int vkupno_rashodi;
    private String kreditna_linija;
    private String tip_kredit;
    private int baran_iznos;
    private int rok_otplata;
    private String obezbeduvanje;
    private String opis_obezbeduvanje;
    private String valuta;
    private boolean grejs_period;
    private long docid;
    private long comment_id;
    private String user_embg;

    public LoanRequests(long loanrequestid, int loantypeid, String client_embg, String requestdate, int broj_dosie, String tip_komintent, String org_ime, String org_address, String org_oblik, int br_vraboteni, String org_tel, String funckija, String profesija, String strucna_podgotovka, int vkupen_staz, int staz_vo_firma, int lice_dohod_vo_stbbt, String nedviznost, String adresa_nedviznost, int proceneta_vrednost, boolean vozilo, int broj_vozila, int neto_plata, int kirija_p, int drugi_prihodi, int vkupno_prihodi, boolean pod_hipoteka, boolean pol, int pazarna_vrednost, String tip_vozilo, int kirija_r, int osiguruvanje, int ziovtni_trosoci, int vkupno_rashodi, String kreditna_linija, String tip_kredit, int baran_iznos, int rok_otplata, String obezbeduvanje, String opis_obezbeduvanje, String valuta, boolean grejs_period, long docid, long comment_id, String user_embg) {
        this.loanrequestid = loanrequestid;
        this.loantypeid = loantypeid;
        this.client_embg = client_embg;
        this.requestdate = requestdate;
        this.broj_dosie = broj_dosie;
        this.tip_komintent = tip_komintent;
        this.org_ime = org_ime;
        this.org_address = org_address;
        this.org_oblik = org_oblik;
        this.br_vraboteni = br_vraboteni;
        this.org_tel = org_tel;
        this.funckija = funckija;
        this.profesija = profesija;
        this.strucna_podgotovka = strucna_podgotovka;
        this.vkupen_staz = vkupen_staz;
        this.staz_vo_firma = staz_vo_firma;
        this.lice_dohod_vo_stbbt = lice_dohod_vo_stbbt;
        this.nedviznost = nedviznost;
        this.adresa_nedviznost = adresa_nedviznost;
        this.proceneta_vrednost = proceneta_vrednost;
        this.vozilo = vozilo;
        this.broj_vozila = broj_vozila;
        this.neto_plata = neto_plata;
        this.kirija_p = kirija_p;
        this.drugi_prihodi = drugi_prihodi;
        this.vkupno_prihodi = vkupno_prihodi;
        this.pod_hipoteka = pod_hipoteka;
        this.pol = pol;
        this.pazarna_vrednost = pazarna_vrednost;
        this.tip_vozilo = tip_vozilo;
        this.kirija_r = kirija_r;
        this.osiguruvanje = osiguruvanje;
        this.ziovtni_trosoci = ziovtni_trosoci;
        this.vkupno_rashodi = vkupno_rashodi;
        this.kreditna_linija = kreditna_linija;
        this.tip_kredit = tip_kredit;
        this.baran_iznos = baran_iznos;
        this.rok_otplata = rok_otplata;
        this.obezbeduvanje = obezbeduvanje;
        this.opis_obezbeduvanje = opis_obezbeduvanje;
        this.valuta = valuta;
        this.grejs_period = grejs_period;
        this.docid = docid;
        this.comment_id = comment_id;
        this.user_embg = user_embg;
    }

    public long getLoanrequestid() {
        return loanrequestid;
    }

    public void setLoanrequestid(long loanrequestid) {
        this.loanrequestid = loanrequestid;
    }

    public int getLoantypeid() {
        return loantypeid;
    }

    public void setLoantypeid(int loantypeid) {
        this.loantypeid = loantypeid;
    }

    public String getClient_embg() {
        return client_embg;
    }

    public void setClient_embg(String client_embg) {
        this.client_embg = client_embg;
    }

    public String getRequestdate() {
        return requestdate;
    }

    public void setRequestdate(String requestdate) {
        this.requestdate = requestdate;
    }

    public int getBroj_dosie() {
        return broj_dosie;
    }

    public void setBroj_dosie(int broj_dosie) {
        this.broj_dosie = broj_dosie;
    }

    public String getTip_komintent() {
        return tip_komintent;
    }

    public void setTip_komintent(String tip_komintent) {
        this.tip_komintent = tip_komintent;
    }

    public String getOrg_ime() {
        return org_ime;
    }

    public void setOrg_ime(String org_ime) {
        this.org_ime = org_ime;
    }

    public String getOrg_address() {
        return org_address;
    }

    public void setOrg_address(String org_address) {
        this.org_address = org_address;
    }

    public String getOrg_oblik() {
        return org_oblik;
    }

    public void setOrg_oblik(String org_oblik) {
        this.org_oblik = org_oblik;
    }

    public int getBr_vraboteni() {
        return br_vraboteni;
    }

    public void setBr_vraboteni(int br_vraboteni) {
        this.br_vraboteni = br_vraboteni;
    }

    public String getOrg_tel() {
        return org_tel;
    }

    public void setOrg_tel(String org_tel) {
        this.org_tel = org_tel;
    }

    public String getFunckija() {
        return funckija;
    }

    public void setFunckija(String funckija) {
        this.funckija = funckija;
    }

    public String getProfesija() {
        return profesija;
    }

    public void setProfesija(String profesija) {
        this.profesija = profesija;
    }

    public String getStrucna_podgotovka() {
        return strucna_podgotovka;
    }

    public void setStrucna_podgotovka(String strucna_podgotovka) {
        this.strucna_podgotovka = strucna_podgotovka;
    }

    public int getVkupen_staz() {
        return vkupen_staz;
    }

    public void setVkupen_staz(int vkupen_staz) {
        this.vkupen_staz = vkupen_staz;
    }

    public int getStaz_vo_firma() {
        return staz_vo_firma;
    }

    public void setStaz_vo_firma(int staz_vo_firma) {
        this.staz_vo_firma = staz_vo_firma;
    }

    public int getLice_dohod_vo_stbbt() {
        return lice_dohod_vo_stbbt;
    }

    public void setLice_dohod_vo_stbbt(int lice_dohod_vo_stbbt) {
        this.lice_dohod_vo_stbbt = lice_dohod_vo_stbbt;
    }

    public String getNedviznost() {
        return nedviznost;
    }

    public void setNedviznost(String nedviznost) {
        this.nedviznost = nedviznost;
    }

    public String getAdresa_nedviznost() {
        return adresa_nedviznost;
    }

    public void setAdresa_nedviznost(String adresa_nedviznost) {
        this.adresa_nedviznost = adresa_nedviznost;
    }

    public int getProceneta_vrednost() {
        return proceneta_vrednost;
    }

    public void setProceneta_vrednost(int proceneta_vrednost) {
        this.proceneta_vrednost = proceneta_vrednost;
    }

    public boolean isVozilo() {
        return vozilo;
    }

    public void setVozilo(boolean vozilo) {
        this.vozilo = vozilo;
    }

    public int getBroj_vozila() {
        return broj_vozila;
    }

    public void setBroj_vozila(int broj_vozila) {
        this.broj_vozila = broj_vozila;
    }

    public int getNeto_plata() {
        return neto_plata;
    }

    public void setNeto_plata(int neto_plata) {
        this.neto_plata = neto_plata;
    }

    public int getKirija_p() {
        return kirija_p;
    }

    public void setKirija_p(int kirija_p) {
        this.kirija_p = kirija_p;
    }

    public int getDrugi_prihodi() {
        return drugi_prihodi;
    }

    public void setDrugi_prihodi(int drugi_prihodi) {
        this.drugi_prihodi = drugi_prihodi;
    }

    public int getVkupno_prihodi() {
        return vkupno_prihodi;
    }

    public void setVkupno_prihodi(int vkupno_prihodi) {
        this.vkupno_prihodi = vkupno_prihodi;
    }

    public boolean isPod_hipoteka() {
        return pod_hipoteka;
    }

    public void setPod_hipoteka(boolean pod_hipoteka) {
        this.pod_hipoteka = pod_hipoteka;
    }

    public boolean isPol() {
        return pol;
    }

    public void setPol(boolean pol) {
        this.pol = pol;
    }

    public int getPazarna_vrednost() {
        return pazarna_vrednost;
    }

    public void setPazarna_vrednost(int pazarna_vrednost) {
        this.pazarna_vrednost = pazarna_vrednost;
    }

    public String getTip_vozilo() {
        return tip_vozilo;
    }

    public void setTip_vozilo(String tip_vozilo) {
        this.tip_vozilo = tip_vozilo;
    }

    public int getKirija_r() {
        return kirija_r;
    }

    public void setKirija_r(int kirija_r) {
        this.kirija_r = kirija_r;
    }

    public int getOsiguruvanje() {
        return osiguruvanje;
    }

    public void setOsiguruvanje(int osiguruvanje) {
        this.osiguruvanje = osiguruvanje;
    }

    public int getZiovtni_trosoci() {
        return ziovtni_trosoci;
    }

    public void setZiovtni_trosoci(int ziovtni_trosoci) {
        this.ziovtni_trosoci = ziovtni_trosoci;
    }

    public int getVkupno_rashodi() {
        return vkupno_rashodi;
    }

    public void setVkupno_rashodi(int vkupno_rashodi) {
        this.vkupno_rashodi = vkupno_rashodi;
    }

    public String getKreditna_linija() {
        return kreditna_linija;
    }

    public void setKreditna_linija(String kreditna_linija) {
        this.kreditna_linija = kreditna_linija;
    }

    public String getTip_kredit() {
        return tip_kredit;
    }

    public void setTip_kredit(String tip_kredit) {
        this.tip_kredit = tip_kredit;
    }

    public int getBaran_iznos() {
        return baran_iznos;
    }

    public void setBaran_iznos(int baran_iznos) {
        this.baran_iznos = baran_iznos;
    }

    public int getRok_otplata() {
        return rok_otplata;
    }

    public void setRok_otplata(int rok_otplata) {
        this.rok_otplata = rok_otplata;
    }

    public String getObezbeduvanje() {
        return obezbeduvanje;
    }

    public void setObezbeduvanje(String obezbeduvanje) {
        this.obezbeduvanje = obezbeduvanje;
    }

    public String getOpis_obezbeduvanje() {
        return opis_obezbeduvanje;
    }

    public void setOpis_obezbeduvanje(String opis_obezbeduvanje) {
        this.opis_obezbeduvanje = opis_obezbeduvanje;
    }

    public String getValuta() {
        return valuta;
    }

    public void setValuta(String valuta) {
        this.valuta = valuta;
    }

    public boolean isGrejs_period() {
        return grejs_period;
    }

    public void setGrejs_period(boolean grejs_period) {
        this.grejs_period = grejs_period;
    }

    public long getDocid() {
        return docid;
    }

    public void setDocid(long docid) {
        this.docid = docid;
    }

    public long getComment_id() {
        return comment_id;
    }

    public void setComment_id(long comment_id) {
        this.comment_id = comment_id;
    }

    public String getUser_embg() {
        return user_embg;
    }

    public void setUser_embg(String user_embg) {
        this.user_embg = user_embg;
    }
}
