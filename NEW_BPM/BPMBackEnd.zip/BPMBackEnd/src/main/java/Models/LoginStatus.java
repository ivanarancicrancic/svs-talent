package Models;

public class LoginStatus {

    private Integer status;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    private String groupName;

    public LoginStatus() {
    }

    public LoginStatus(Integer status,String groupName) {
        this.status = status;
        this.groupName=groupName;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }
}
