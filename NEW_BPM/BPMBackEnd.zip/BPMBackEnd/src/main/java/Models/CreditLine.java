package Models;

public class CreditLine {
    private Integer loanLineID;
    private String loanLineName;

    public CreditLine() {
    }

    public CreditLine(Integer loanLineID, String loanLineName) {
        this.loanLineID = loanLineID;
        this.loanLineName = loanLineName;
    }

    public Integer getLoanLineID() {
        return loanLineID;
    }

    public void setLoanLineID(Integer loanLineID) {
        this.loanLineID = loanLineID;
    }

    public String getLoanLineName() {
        return loanLineName;
    }

    public void setLoanLineName(String loanLineName) {
        this.loanLineName = loanLineName;
    }
}
