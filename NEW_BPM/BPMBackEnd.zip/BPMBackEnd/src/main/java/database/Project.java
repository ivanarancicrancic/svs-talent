package database;

import Models.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class Project {

    public LoginStatus getLoginStatus(Connection connection, UserLogin ul) throws Exception
    {
        LoginStatus t_items = new LoginStatus();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getLoginStatus(?,?)");
            ps.setString(1,ul.getUsername() );
            ps.setString(2,ul.getPassword() );
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                t_items.setStatus(rs.getInt(1));
                t_items.setGroupName(rs.getString(2));
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<FormsByUsername> getFormsByUsername(Connection connection, String username) throws Exception
    {
        List<FormsByUsername> t_items = new ArrayList<FormsByUsername>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getformsbyusername(?)");
            ps.setString(1,username);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                FormsByUsername p_eden = new FormsByUsername(
                        rs.getString(1)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<DocumentName> getdocumentnamebyid(Connection connection, int id ) throws Exception
    {
        List<DocumentName> t_items = new ArrayList<DocumentName>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getdocumentnamebyid(?)");
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                DocumentName p_eden = new DocumentName(
                        rs.getString(1)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<LoanRequests> getloanrequests(Connection connection) throws Exception
    {
        List<LoanRequests> t_items = new ArrayList<LoanRequests>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequests()");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequests p_eden = new LoanRequests(
                        rs.getLong (1),
                        rs.getInt (2),
                        rs.getString (3),
                        rs.getString (4),
                        rs.getInt (5),
                        rs.getString (6),
                        rs.getString (7),
                        rs.getString (8),
                        rs.getString (9),
                        rs.getInt (10),
                        rs.getString (11),
                        rs.getString (12),
                        rs.getString (13),
                        rs.getString (14),
                        rs.getInt (15),
                        rs.getInt (16),
                        rs.getInt (17),
                        rs.getString (18),
                        rs.getString (19),
                        rs.getInt (20),
                        rs.getBoolean (21),
                        rs.getInt (22),
                        rs.getInt (23),
                        rs.getInt (24),
                        rs.getInt (25),
                        rs.getInt (26),
                        rs.getBoolean (27),
                        rs.getBoolean (28),
                        rs.getInt (29),
                        rs.getString (30),
                        rs.getInt (31),
                        rs.getInt (32),
                        rs.getInt (33),
                        rs.getInt (34),
                        rs.getString (35),
                        rs.getString (36),
                        rs.getInt (37),
                        rs.getInt (38),
                        rs.getString (39),
                        rs.getString (40),
                        rs.getString (41),
                        rs.getBoolean (42),
                        rs.getLong (43),
                        rs.getLong (44),
                        rs.getString (45)

                        );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<LoanType> GetLoanTypeByLoanLineID(Connection connection, Integer loanLineID) throws Exception
    {
        List<LoanType> t_items = new ArrayList<LoanType>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetLoanTypeByLoanLineID(?)");
            ps.setInt(1,loanLineID);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanType p_eden = new LoanType(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<CreditLine> GetKreditniLini(Connection connection, Integer p_type) throws Exception
    {
        List<CreditLine> t_items = new ArrayList<CreditLine>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetKreditniLini(?)");
            ps.setInt(1,p_type);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                CreditLine p_eden = new CreditLine(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<UsersByUsername> GetUsersByUsername(Connection connection, String p_username) throws Exception
    {
        List<UsersByUsername> t_items = new ArrayList<UsersByUsername>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetUsersByUsername(?)");
            ps.setString(1,p_username);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                UsersByUsername p_eden = new UsersByUsername(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public List<AplicantDetails> GetAplicantDetailsByEmbg(Connection connection, String p_embg ) throws Exception
    {
        List<AplicantDetails> t_items = new ArrayList<AplicantDetails>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from GetAplicantDetailsByEmbg(?)");
            ps.setString(1,p_embg);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                AplicantDetails p_eden = new AplicantDetails(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<UserByGroupId> GetUsersByGrpoupID(Connection connection,Integer p_groupid ) throws Exception
    {
        List<UserByGroupId> t_items = new ArrayList<UserByGroupId>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getusersbygroupid(?)");
            ps.setInt(1,p_groupid);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String fullname1 =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("fullname1 "+fullname1);
                //TreatmentItem p_eden = new TreatmentItem();
                UserByGroupId p_eden = new UserByGroupId(

                        rs.getString(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<ClientType> getClientsType(Connection connection) throws Exception
    {
        List<ClientType> t_items = new ArrayList<ClientType>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getClientsType()");
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                ClientType p_eden = new ClientType(
                        rs.getInt (1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<LoanRequestsByParametar> getloanrequestsbyparametar(Connection connection, String p_type, String p_value) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1,p_type);
            ps.setString(2,p_value);
            ResultSet rs = ps.executeQuery();
            while(rs.next())
            {
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(

                        rs.getLong(1),



                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }
            return t_items;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }




    public List<DocumentsForLoanTypeID> GetDocumentsForLoanTypeID(Connection connection,Integer _loanTypeID) throws Exception
    {
        List<DocumentsForLoanTypeID> t_items = new ArrayList<DocumentsForLoanTypeID>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getdocumentsforloantypeid(?)");
            ps.setInt(1, _loanTypeID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                DocumentsForLoanTypeID p_eden = new DocumentsForLoanTypeID(

                        rs.getInt(1),
                        rs.getString(2)

                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsByLoanID> GetWarningsByLoanID(Connection connection, Integer loanID) throws Exception
    {
        List<WarningsByLoanID> t_items = new ArrayList<WarningsByLoanID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getwarningsbyloanid(?)");
            ps.setInt(1, loanID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsByLoanID p_eden = new WarningsByLoanID(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<WarningsDetailsByWarrningID> GetWarningsDetailsByWarrningID(Connection connection, Integer warningID) throws Exception
    {
        List<WarningsDetailsByWarrningID> t_items = new ArrayList<WarningsDetailsByWarrningID>();
        PreparedStatement ps=null;
        try
        {
            System.out.println("Before try");
            ps = connection.prepareStatement("select * from getwarningsdetailsbywarrningid(?)");
            ps.setInt(1, warningID);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                WarningsDetailsByWarrningID p_eden = new WarningsDetailsByWarrningID(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }


    public List<LoanRequestsByParametar> GetLoanRequestsByParametar(Connection connection, String parametarName, String parametarValue) throws Exception
    {
        List<LoanRequestsByParametar> t_items = new ArrayList<LoanRequestsByParametar>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getloanrequestsbyparametar(?,?)");
            ps.setString(1, parametarName);
            ps.setString(2, parametarValue);
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                LoanRequestsByParametar p_eden = new LoanRequestsByParametar(
                        rs.getLong(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void CreateLoanRequest(Connection connection, LoanRequest loanRequest) throws Exception
    {
        LoanRequest loanRequest1 = new LoanRequest();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from createloanrequest(?,?,?,?)");


            ps.setInt(1, loanRequest.getLoantypeid());
            ps.setString(2, loanRequest.getEmbg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setInt(4, loanRequest.getAmount());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }

    public void AddNewWarningByLoanID(Connection connection, LoanWarning loanWarning) throws Exception
    {
        // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from addnewwarningbyloanid(?,?,?,?)");
            // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanWarning.getLoanid());
            ps.setString(2, loanWarning.getWarrningdetails());
            ps.setInt(3, loanWarning.getWarrningpdfid());
            ps.setString(4, loanWarning.getWarrningdatte());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public LoanRequest UpdateLoanRequestByID(Connection connection, int loanTypeID, LoanRequest loanRequest) throws Exception
    {
       // LoanWarning loanWarning1 = new LoanWarning();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from updateloanrequestbyid(?,?,?,?)");
           // ps.setInt(1, loanWarning.getWarrningid());
            ps.setInt(1, loanTypeID);
            ps.setString(2, loanRequest.getEmbg());
            ps.setString(3, loanRequest.getRequestdate());
            ps.setInt(4, loanRequest.getAmount());
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            loanRequest.setLoantypeid(loanTypeID);
            return loanRequest;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }



    public List<KreditenOdborGroups> GetKreditenOdborGroups(Connection connection) throws Exception
    {
        List<KreditenOdborGroups> t_items = new ArrayList<KreditenOdborGroups>();
        PreparedStatement ps=null;
        try
        {
            ps = connection.prepareStatement("select * from getkreditenodborgroups()");
            System.out.println("Try");

            ResultSet rs = ps.executeQuery();
            System.out.println(rs);
            //System.out.println(rs.getInt(1));
            System.out.println("Finish");
            while(rs.next())
            {
                System.out.println("rs.next");
//                String documentName =new String(rs.getString(2).getBytes("ISO-8859-1"), "UTF-8");
//                System.out.println("documentname"+documentName);
                //TreatmentItem p_eden = new TreatmentItem();
                KreditenOdborGroups p_eden = new KreditenOdborGroups(
                        rs.getInt(1),
                        rs.getString(2)
                );
                t_items.add(p_eden);
            }

            return t_items;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }
        finally {
            ps.close();
            connection.close();
        }
    }





}
