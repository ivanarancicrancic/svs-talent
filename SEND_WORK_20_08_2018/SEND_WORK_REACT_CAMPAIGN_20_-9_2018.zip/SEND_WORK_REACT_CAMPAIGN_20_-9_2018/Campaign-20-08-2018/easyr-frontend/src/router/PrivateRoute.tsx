import * as React from "react"
import { Route, Redirect, } from "react-router-dom"
import { RouteComponentProps } from "react-router"
import { PATH_LOGIN } from "./paths";
import { connect } from "react-redux";
import { IRootState } from "../redux";
import { IAuthState } from "../redux/auth/reducer";

interface IPrivateRouteProps {
    readonly component: React.ComponentClass<RouteComponentProps<{}>>,
    readonly path: string
}

interface IPropsFromStateMap {
    auth: IAuthState
}

type Props = IPrivateRouteProps & IPropsFromStateMap;

class PrivateRoute extends React.Component<Props> {

    public render() {
        return <Route render={this.renderRoutes}/>
    }

    private renderRoutes = (props: RouteComponentProps<{}>): JSX.Element => {

        const loggedIn = this.props.auth.token != null;
        const Component = this.props.component;

        if (loggedIn) {
            return <Component {...props} />
        } else {
            return <Redirect to={{ pathname: PATH_LOGIN, state: { from: props.location } }}/>
        }
    }

}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

export default connect(mapStateToProps, {})(PrivateRoute)