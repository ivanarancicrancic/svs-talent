import * as React from 'react';
import {NavLink} from "react-router-dom";
import {PATH_DESCRIPTION, PATH_LOGIN, PATH_REFERENCES, PATH_REGISTER, PATH_ROOT} from "../../router/paths";
// import {Alignment} from "@blueprintjs/core";

export default class PreAuthHeader extends React.Component {

    public render() {
        return (
            <div className="header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group bp3-align-left">
                            <NavLink to={PATH_ROOT} className="bp3-navbar-heading"> LOGO </NavLink>
                        </div>
                        <div className="bp3-navbar-group bp3-align-right">
                            <NavLink to={PATH_DESCRIPTION} className="bp3-navbar-heading"> DESCRIPTION </NavLink>
                            <NavLink to={PATH_REFERENCES} className="bp3-navbar-heading"> REFERENCES </NavLink>
                            <NavLink to={PATH_LOGIN} className="bp3-button bp3-minimal logInButton">Log in</NavLink>
                            <NavLink to={PATH_REGISTER} className="bp3-button bp3-minimal signUpButton">SIGN
                                UP</NavLink>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

}