import * as React from 'react';
import {Control, /*actions*/ Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import './Register.css';

import {Link} from "react-router-dom";
import {PATH_PRIVACY, PATH_ROOT, PATH_TERMS} from "../../../router/paths";

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
}

export default class PaymentAddress extends React.Component<IProps> {

    // private formDispatch: any;

    public render() {
        return (
            <div className="container">
                <Form
                    model="forms.login"
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                    <div>
                        <div className="bottomSeparator">
                            <p>Payment Address Data </p>
                        </div>
                        <div className="container bp3-input-group">
                            <Control
                                model=".firstName"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "First Name",
                                }}
                            />
                            <Control
                                model=".lastName"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "Last Name",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".companyName"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Company Name",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".streetAddress"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Street Address",
                                }}
                            />
                        </div>
                        <div className="container bp3-input-group">
                            <Control
                                model=".city"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "City",
                                }}
                            />
                            <Control
                                model=".state"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "State",
                                }}
                            />
                        </div>
                        <div className="container bp3-input-group">
                            <Control
                                model=".zipCode"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "Postal/Zip Code",
                                }}
                            />
                            <Control.select
                                model=".country"
                                className="selectButton inputButton grid50">
                                <option value="00">Country</option>
                                <option value="01">Country One</option>
                                <option value="02">Country Two</option>
                                <option value="03">Country Three</option>
                            </Control.select>
                        </div>

                        <div className="submit">
                            <Link to={PATH_ROOT} role="button" type="submit" className="logIn bp3-button bp3-minimal">
                                Sign up
                            </Link>
                            <p>By signing up, you agree to our <Link to={PATH_TERMS}>Terms of Use</Link> and <Link
                                to={PATH_PRIVACY}>Privacy
                                Policy</Link>.</p>
                        </div>
                    </div>
                </Form>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        // this.formDispatch = dispatch;
    }

    /*
    private changeFooToBar = () => {
        this.formDispatch(actions.change('user.foo', 'bar'));
    }
    */
}