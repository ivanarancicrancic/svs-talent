import * as React from 'react';
import {Control, /*actions*/ Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import {Icon} from '@blueprintjs/core';

import './LoginForm.css';
import {Link} from "react-router-dom";
import {PATH_FORGOT_PASSWORD_REQUEST, PATH_REGISTER, PATH_ROOT} from "../../../router/paths";

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
}

export default class LoginForm extends React.Component<IProps> {

    // private formDispatch: any;

    public render() {
        return (
            <div>
                <Form
                    model="forms.login"
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                    <div>
                        <div className="userIcon">
                            <Icon icon="user" iconSize={60}/>
                        </div>
                        <Control
                            model=".username"
                            // validators={{
                            //     required: (val) => val && val.length,
                            //     maxLength50
                            // }}
                            component={"input"}

                            controlProps={{
                                className: "bp3-input inputButton",
                                placeholder: "Benutzername",
                                /*
                                fluid: true,
                                icon: 'user',
                                iconPosition: 'left',
                                placeholder: I18n.t('login.username'),
                                 error: !this.props.form.username.valid && this.props.form.username.touched,
                                */
                            }}
                        />
                    </div>

                    <div>
                        <Control
                            model=".password"
                            // validators={{
                            //     required: (val) => val && val.length,
                            //     minLength5,
                            //     maxLength50
                            // }}
                            component={"input"}
                            controlProps={{
                                className: "bp3-input inputButton",
                                type: "password",
                                placeholder: "Passwort"
                            }}
                        />
                        <div className="forgotPass">
                            <Link to={PATH_FORGOT_PASSWORD_REQUEST}> Forgot your password? </Link>
                        </div>
                    </div>

                    <div>
                        <Link to={PATH_ROOT} role="button" type="submit" className="logIn bp3-button bp3-minimal">
                            Log in
                        </Link>
                    </div>

                </Form>

                <div className="signUp">
                    <p> Don't have an account? </p>
                    <Link to={PATH_REGISTER} role="button" className="bp3-button bp3-minimal"> Sign up </Link>
                </div>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        // this.formDispatch = dispatch;
    }

    /*
    private changeFooToBar = () => {
        this.formDispatch(actions.change('user.foo', 'bar'));
    }
    */
}