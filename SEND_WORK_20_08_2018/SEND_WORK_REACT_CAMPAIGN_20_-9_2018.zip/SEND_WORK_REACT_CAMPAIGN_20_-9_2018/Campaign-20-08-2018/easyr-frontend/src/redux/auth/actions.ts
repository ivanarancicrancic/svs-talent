import {
    LOGIN_USER_FETCH,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,  
    LOGIN_LOGOUT  
} from './types';

import { createStandardAction } from 'typesafe-actions';


export const loginUserFetch = createStandardAction(LOGIN_USER_FETCH)<{username: string, password: string}>();
export const loginUserSuccess = createStandardAction(LOGIN_USER_SUCCESS)<void>();
export const loginUserFail = createStandardAction(LOGIN_USER_FAIL)<void>();
export const loginLogout = createStandardAction(LOGIN_LOGOUT)<void>();

export const loginUser = (username:string, password:string) => {
    console.log("User Data: ", username, password);
    return (dispatch: any) => {
        dispatch(loginUserFetch({username, password}));
        fetch('http://localhost:8080/login', {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                username,
                password
            }),
        })
        .then(response => {
            console.log(response);
            dispatch(loginUserSuccess());
        })
        .catch(err => {
            console.log(err);
            dispatch(loginUserFail());
        });
    }        
};

export default {
    loginUser
}
