import { IRootState } from '../index'

export const getUserIsLoggedIn = (state: IRootState) => state.auth.token != null