
import { HANDLE_GET_ALL_CAMPAIGNS } from './actionTypes'
import { getFromBackend } from '../../api/api'

interface ICampaign {
    id: number
}

const campaignData = {
    "campaigns":[],
}

interface IUser {
    id: string,
    language: string,
    active: string,
    email : string,
    password: string,
    gender: string,
    firstname: string,
    lastname: string
}

interface IContent {
    id: string,
    weight: number,
    name: string
}

interface IContactInformation {
    id: string,
    name: string,
    company: string,
    homepage: string,
    email: string,
    address: string,
    address2: string,
    number: string,
    zip: string,
    city: string
}

interface IRealCampaign {
    id: string,
    user: IUser,
    contents: IContent[],
    contact: IContactInformation;
}

const realCampaignData = {
    "campaigns":[]
}

interface ICampaignsAction<Action> {
    type: string
    payload?: any
}

/* tslint:disable:no-string-literal */
const getAllCampaigns = () => {
    const url: string = '/testCampaigns'
    return (dispatch: any, getState:any) => {

       return getFromBackend(url).then( (response : any) => {
            const campaigns = response
            console.log(campaigns)
            realCampaignData['campaigns'] = campaigns
            console.log("realCampaignData['campaigns']: "+ realCampaignData['campaigns'])
             dispatch(getCampaignsDataSuccess(campaigns))
            })
        .catch(error => {
                dispatch(getCampaignsDataFaied(error))
        });            
        }
    }
    

const getCampaignsDataSuccess = (campaignsData: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: campaignsData
    }
}
const getCampaignsDataFaied = (error: any) => {
    return {
        type: HANDLE_GET_ALL_CAMPAIGNS,
        payload: error
    }
}
/* tslint:enable:no-string-literal */

export {
    getAllCampaigns, ICampaignsAction, campaignData,
    ICampaign,
    IRealCampaign,
    realCampaignData
}
