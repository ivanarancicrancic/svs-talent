import { Action } from 'redux'
import { ICampaignsAction } from '../actions/campaignsActions'
import { HANDLE_GET_ALL_CAMPAIGNS } from '../actions/actionTypes'

const INITIAL_STATE: any = {
    realCampaigns: {}
}

const CampaignsReducer = (state: any = INITIAL_STATE, action: ICampaignsAction<Action>): any => {
    switch(action.type) {
        case HANDLE_GET_ALL_CAMPAIGNS:
            return {
                ...action.payload
            }
        default:
            return state
    }
}
export default CampaignsReducer
