import * as React from 'react'
import { connect } from 'react-redux'
import { getAllCampaigns, ICampaign, realCampaignData ,IRealCampaign} from '../../redux/actions/campaignsActions'

interface ICampaignsProps {
    fetchCampaignsData?: any,
    realCampaigns?: IRealCampaign[]
}
interface ICampaignsState {
    campaigns: ICampaign[],
    realCampaigns: IRealCampaign[]

}

class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        this.state = {
            campaigns: [],
            realCampaigns: []
        }
    }

   public render() {

        return (
            <div>
                {
                    realCampaignData.campaigns.map((campaign: IRealCampaign) =>
                    <div key={campaign.id}>
                   ID:  {campaign.id} 
                  firstname:    {campaign.user.firstname}
                  lastname:    {campaign.user.lastname}
                    </div>
                  )
                 }
            </div>
        )
    }
 public componentDidMount() {
    this.props.fetchCampaignsData()
    }

  public componentWillReceiveProps(newProps: any) {
        this.setState({
            ...newProps.realCampaigns
        })
        console.log(this.state)
    }

}

const mapStateToProps = (state: any) => {
    return {
        ...state
    }
}
const mapDispatchToProps = (dispatch: any) => {
    return {
        fetchCampaignsData: () => dispatch(getAllCampaigns()),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)
