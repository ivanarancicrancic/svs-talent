import * as React from 'react';

import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import { loginUserFetch } from '../../redux/auth/actions';
import { RouteComponentProps } from 'react-router';
import { IAuthState } from '../../redux/auth/reducer';
import { PATH_ROOT } from '../../router/paths';
import LoginForm from '../../components/Forms/Login/LoginForm';
import { ILoginFormData } from '../../redux/forms';
import {loginUser} from '../../redux/auth/actions'

interface IPropsDispatchMap {
    loginUserFetch: typeof loginUserFetch;
}
interface IPropsStateMap {
    auth: IAuthState
}

interface IPropsLogin {
    onloginUser: typeof loginUser;
}
type IProps = IPropsStateMap & IPropsDispatchMap & IPropsLogin & RouteComponentProps<{}>

interface IState { value: string };


class LoginContainer extends React.Component<IProps, IState> {

    public componentWillMount() {
        console.log(this.props);
    }

    public componentWillReceiveProps(nextProps: IProps) {
        // auth token becomes available
        if(this.props.auth.token == null && nextProps.auth.token != null) {
            this.props.history.replace(PATH_ROOT);
        }
    }

    public componentDidMount () {
        this.props.onloginUser('username', 'password');
        console.log(this.props.onloginUser)
    }

    public render() {
        return (
            <div>
                <LoginForm onSubmit={this.onSubmitLoginForm} />
            </div>
        )
    }

    private onSubmitLoginForm = (values: ILoginFormData) => {
        this.props.loginUserFetch(values);
        console.log(loginUserFetch)
        console.log('loginUserFetch')

        // this.props.onloginUser(this.state.value, this.state.value)
    }

}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

const mapDispatchToProps = (dispatch:any) => {
    return {
        onloginUser: (username:string, password:string) => dispatch( loginUser(username, password) )
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(LoginContainer)