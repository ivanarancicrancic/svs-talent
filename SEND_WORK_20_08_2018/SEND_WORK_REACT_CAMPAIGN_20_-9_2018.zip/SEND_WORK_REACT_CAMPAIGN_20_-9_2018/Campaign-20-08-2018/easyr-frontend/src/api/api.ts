
const baseURL = 'http://localhost:8080/api'


const defaultHeaders = {
    headers: {
        'Content-Type': 'application/json'    
    }
}

const getFromBackend = (url: string, headers = defaultHeaders): Promise<any> => {
    const fullURL = baseURL + url
    return fetch(fullURL, {
        method: 'GET',
        headers: {"Content-Type": "application/json"}
    })
    .then(response => response.json())
    .then(response => {
        console.log(response);
        return response 
    })
    .catch(err => {
        console.log(err);
        return err
    });
}


export {
    getFromBackend
}
