
import {createStore, applyMiddleware} from 'redux'
import CampaignsReducer from '../reducers/CampaignsReducer'
import ReduxThunk from 'redux-thunk'
const store = createStore(CampaignsReducer,{}, applyMiddleware(ReduxThunk))

export default store
