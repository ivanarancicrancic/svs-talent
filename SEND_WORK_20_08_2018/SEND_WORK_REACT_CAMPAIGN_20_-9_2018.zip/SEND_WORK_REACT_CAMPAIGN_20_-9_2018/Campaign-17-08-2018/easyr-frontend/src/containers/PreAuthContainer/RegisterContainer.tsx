import * as React from 'react';

import { connect } from 'react-redux';
import { RouteComponentProps } from 'react-router';
import {IAuthState} from "../../redux/auth/reducer";
import {loginUserFetch} from '../../redux/auth/actions';
import {PATH_ROOT} from "../../router/paths";
import AccountRegister from "../../components/Forms/Register/AccountRegister";
import {ILoginFormData} from "../../redux/forms";
import {IRootState} from "../../redux";
import PaymentAddress from "../../components/Forms/Register/PaymentAddress";
import './RegisterContainer.css';


interface IPropsDispatchMap {
    loginUserFetch: typeof loginUserFetch;
}
interface IPropsStateMap {
    auth: IAuthState
}

type IProps = IPropsStateMap & IPropsDispatchMap & RouteComponentProps<{}>

class RegisterContainer extends React.Component<IProps> {

    public componentWillMount() {
        console.log(this.props);
    }

    public componentWillReceiveProps(nextProps: IProps) {
        // auth token becomes available
        if(this.props.auth.token == null && nextProps.auth.token != null) {
            this.props.history.replace(PATH_ROOT);
        }
    }

    public render() {
        return (
            <div className="grid60">
                <div>
                    <AccountRegister onSubmit={this.onSubmitLoginForm} />
                </div>
                <div>
                    <PaymentAddress onSubmit={this.onSubmitLoginForm} />
                </div>
            </div>
        )
    }

    private onSubmitLoginForm = (values: ILoginFormData) => {
        this.props.loginUserFetch(values);
    }

}

const mapStateToProps = (state: IRootState) => ({
    auth: state.auth
});

export default connect(mapStateToProps, {loginUserFetch})(RegisterContainer)