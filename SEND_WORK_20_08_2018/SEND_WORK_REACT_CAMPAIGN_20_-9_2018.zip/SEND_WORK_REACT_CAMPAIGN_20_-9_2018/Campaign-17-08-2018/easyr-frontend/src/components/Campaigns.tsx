import * as React from 'react'
import { connect } from 'react-redux'
// import * as style from 'ts-style' //ts-style is correct one
// import { bindActionCreators } from 'redux'
import { getAllCampaigns } from '../redux/actions/campaignsActions'
// import store from '../redux/store/store'
// import { Office, Official, Division, Election } from '../../types/voteSmartTypes'
import { ICampaign, realCampaignData ,IRealCampaign} from '../models/teamModel'
// import { displayElectionsAndOfficialsByDivision } from './displayElectionsAndOfficialsByDivision'
// import { RECORD } from '@blueprintjs/icons/lib/esm/generated/iconNames';


interface ICampaignsProps {
    fetchCampaignsData?: any,
    realCampaigns?: IRealCampaign[]
}
interface ICampaignsState {
    campaigns: ICampaign[],
    realCampaigns: IRealCampaign[]

}

// const addressInput = () => {
//     return style.create({
//         margin: '10px',
//         textAlign: 'center'
//     })
// }
class Campaigns extends React.Component<ICampaignsProps, ICampaignsState> {
    constructor(props: ICampaignsProps) {
        super(props)
        // this.props = props
        this.state = {
            campaigns: [],
            realCampaigns: []
        }
    }

   public render() {

        return (
            <div>
                {
                    //  campaignData.campaigns.map((campaign: ICampaign) =>
                    //           <div key={campaign.id}>
                    //             {campaign.id}<br/>
                    //           </div>
                    //         )
                    realCampaignData.campaigns.map((campaign: IRealCampaign) =>
                    <div key={campaign.id}>
                      {campaign.id} 
                      {campaign.user.firstname}
                      {campaign.user.lastname}
                      {/* {campaign.contact.address}<br/> */}
                    </div>
                  )

                 
                 }
            </div>
        )
    }
 public componentDidMount() {
    this.props.fetchCampaignsData()
        // this.setState({
        //     //  campaigns: campaignData.campaigns
        //     realCampaigns: realCampaignData.campaigns
        //     // probe: campaignData.returnStr
        // })
    }

  public componentWillReceiveProps(newProps: any) {
        this.setState({
            ...newProps.realCampaigns
        })
        console.log(this.state)
    }

}

const mapStateToProps = (state: any) => {
    return {
        ...state
    }
}
const mapDispatchToProps = (dispatch: any) => {
    return {
        fetchCampaignsData: () => dispatch(getAllCampaigns()),
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Campaigns)
