package springwebapp.converters;

import springwebapp.commands.BookCommand;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Book;


@Component
public class BookCommandToBook implements Converter<BookCommand, Book> {

    private final CategoryCommandToCategory categoryConveter;
    private final CommentCommandToComment commentConverter;
    private final AuthorCommandToAuthor authorConverter;
    private final EvaluationCommandToEvaluation evaluationConverter;
    private final PublisherCommandToPublisher publisherConverter;

    public BookCommandToBook(CategoryCommandToCategory categoryConveter, CommentCommandToComment commentConverter, AuthorCommandToAuthor authorConverter, EvaluationCommandToEvaluation evaluationConverter, PublisherCommandToPublisher publisherConverter) {
        this.categoryConveter = categoryConveter;
        this.commentConverter = commentConverter;
        this.authorConverter = authorConverter;
        this.evaluationConverter = evaluationConverter;
        this.publisherConverter = publisherConverter;
    }

    @Synchronized
    @Override
    public Book convert(BookCommand source){
        if(source == null){
            return null;
        }

        final Book book = new Book();
        book.setId(source.getId());
        book.setTitle(source.getTitle());
        book.setImage(source.getImage());
        book.setDescription(source.getDescription());
        book.setSize(source.getSize());
        book.setUrl(source.getUrl());
        book.setNote(source.getNote());
        book.setStringCategories(source.getStringCategories());
        book.setDifficutly(source.getDifficutly());
        book.setPublisher(publisherConverter.convert(source.getPublisher()));

        if (source.getCategories() != null && source.getCategories().size() > 0){
            source.getCategories()
                    .forEach( category -> book.getCategories().add(categoryConveter.convert(category)));
        }

        if (source.getAuthors() != null && source.getAuthors().size() > 0){
            source.getAuthors()
                    .forEach(author -> book.getAuthors().add(authorConverter.convert(author)));
        }

        if (source.getComments() != null && source.getComments().size() > 0){
            source.getComments()
                    .forEach(comment -> book.getComments().add(commentConverter.convert(comment)));
        }

        book.setEvaluation(evaluationConverter.convert(source.getEvaluation()));

        return book;
    }

}
