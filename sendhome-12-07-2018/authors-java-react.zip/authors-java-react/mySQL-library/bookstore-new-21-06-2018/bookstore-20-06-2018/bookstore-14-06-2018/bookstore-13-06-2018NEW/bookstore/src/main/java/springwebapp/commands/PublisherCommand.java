package springwebapp.commands;

import springwebapp.model.Book;

import java.util.List;

public class PublisherCommand {

    private Long id;
    private String name;
    private String address;
    private List<BookCommand> books;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public List<BookCommand> getBooks() {
        return books;
    }

    public void setBooks(List<BookCommand> books) {
        this.books = books;
    }
}
