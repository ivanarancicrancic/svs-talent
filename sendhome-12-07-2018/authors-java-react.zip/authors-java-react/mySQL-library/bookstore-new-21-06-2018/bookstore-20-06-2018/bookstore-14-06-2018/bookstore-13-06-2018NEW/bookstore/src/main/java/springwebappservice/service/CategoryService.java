package springwebappservice.service;



import org.springframework.stereotype.Component;
import springwebapp.commands.CategoryCommand;
import java.util.Set;

@Component
public interface CategoryService {

    public Set<CategoryCommand> getAllCategories();

}
