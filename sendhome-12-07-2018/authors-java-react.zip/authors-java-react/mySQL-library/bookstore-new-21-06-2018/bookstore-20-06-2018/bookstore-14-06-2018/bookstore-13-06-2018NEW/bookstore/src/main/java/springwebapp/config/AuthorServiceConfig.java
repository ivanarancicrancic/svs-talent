package springwebapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.annotation.Order;
import springwebapp.converters.AuthorCommandToAuthor;
import springwebapp.converters.AuthorToAuthorCommand;
import springwebapp.repository.AuthorRepository;
import springwebapp.repository.BookRepository;
import springwebapp.repository.TableAttributeRepository;
import springwebappservice.service.*;

@Configuration
@Order(1)
public class AuthorServiceConfig {

    @Bean
    AuthorService authorServiceFactory(AuthorRepository repository, AuthorCommandToAuthor authorCommandToAuthor, AuthorToAuthorCommand authorToAuthorCommand, BookRepository bookRepository){
        return new AuthorServiceImpl(repository, authorCommandToAuthor, authorToAuthorCommand, bookRepository) {
        };
    }

    @Bean
    @Primary
    @Profile({"default", "en"})
    TableAttributeService primaryGreetingService(TableAttributeRepository repository){
        return new TableAttributeServiceEn(repository) {
        };
    }

    @Bean
    @Primary
    @Profile("de")
    TableAttributeService primaryGermanGreetingService(TableAttributeRepository repository){
        return new TableAttributeServiceGerman(repository) {
        };
    }

    @Bean
    @Primary
    @Profile("es")
    TableAttributeService primarySpanishGreetingService(TableAttributeRepository repository){
        return new TableAttributeServiceSpanish(repository) {
        };
    }

}
