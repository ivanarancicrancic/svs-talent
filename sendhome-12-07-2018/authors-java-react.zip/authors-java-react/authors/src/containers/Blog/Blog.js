import React, { Component } from 'react';

import Post from '../../components/Post/Post';
import FullPost from '../../components/FullPost/FullPost';
import NewPost from '../../components/NewPost/NewPost';
import './Blog.css';

class Blog extends Component {
    //
    // state = {
    //     posts: []
    // }

    constructor(props){
        super(props);
        console.log('[Blog.js] Entered Constructor', props)
        this.state =  {
            books: [
            ]
        }

    }


    componentDidMount() {
        fetch('http://localhost:9575/books')
            .then(response => response.json())
            .then(data =>
            {
                this.setState({books: data})}
            );


    }

    render () {
        const books = this.state.books.map(book => {return <Post key={book.id} title={book.title}/>});

        return (
            <div>
                <section className="Posts">
                    {books}
                </section>
                <section>
                    <FullPost />
                </section>
                <section>
                    <NewPost />
                </section>
            </div>
        );
    }
}

export default Blog;