package springwebapp.contoller;



import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import springwebapp.commands.AuthorCommand;
import springwebapp.converters.AuthorToAuthorCommand;
import springwebapp.model.Author;
import springwebappservice.service.AuthorService;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

import java.util.ArrayList;
import java.util.List;

@RestController
@Order(1)
@CrossOrigin(origins = "http://localhost:3000")
public class AuthorController {
    private AuthorService authorService;

    AuthorToAuthorCommand authorToAuthorCommand;

    @Autowired
    private BookService bookService;

    @Autowired
    TableAttributeService tableAttributeService;

    public AuthorController(AuthorService authorService, BookService bookService, TableAttributeService tableAttributeService, AuthorToAuthorCommand authorToAuthorCommand) {
        this.authorService = authorService;
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.authorToAuthorCommand = authorToAuthorCommand;
    }


    @GetMapping("/authors")
    @ResponseStatus(HttpStatus.OK)
    public String getAuthors() throws Exception{

        List<Author> authors = null;
        String author_str = null;

       // model.addAttribute("authors", authorService.getAllAuthors());
        //return "authors";


        try{
            authors = authorService.getAllAuthors();
            Gson gson = new Gson();
            System.out.println(authors);

            List<AuthorCommand> authorCommands = new ArrayList<>();
            for(Author a: authors){
                AuthorCommand authorCommand = new AuthorCommand();
                authorCommand = authorToAuthorCommand.convert(a);
                authorCommands.add(authorCommand);
            }
            author_str = gson.toJson(authorCommands);
            System.out.println(author_str);
            return author_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }






    }


    @GetMapping("/book/{bookId}/authors")
    @ResponseStatus(HttpStatus.OK)
    public void listAuthors(@PathVariable String bookId){

        //model.addAttribute("book", bookService.findById(Long.valueOf(bookId)));
         //return "book/author/list";
    }

    @GetMapping("/book/{bookId}/author/{authorId}/show")
    @ResponseStatus(HttpStatus.OK)
    public AuthorCommand viewAuthor(@PathVariable String bookId, @PathVariable String authorId){
 System.out.println("Book id: " + bookId);
       System.out.println("AuthorId: " + authorId);

       //  model.addAttribute("author", authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId)));
       // return "book/author/show";

   return authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId));
    }

    @GetMapping("/book/{bookId}/author/{authorId}/delete")
    @ResponseStatus(HttpStatus.OK)
    public void removeAuthor(@PathVariable String bookId, @PathVariable String authorId){
        authorService.deleteAuthorFromBook(Long.valueOf(bookId), Long.valueOf(authorId));

        //model.addAttribute("translate", tableAttributeService.translate());
        //model.addAttribute("books", bookService.getAllBooks());
        //return "redirect:/book/" + bookId + "/authors";
    }

    @GetMapping("/book/{bookId}/author/{authorId}/update")
    @ResponseStatus(HttpStatus.OK)
    public String openEditAuthor(@PathVariable String bookId, @PathVariable String authorId){
        AuthorCommand authorCommand = authorService.findByBookIdAndAuthorId(Long.valueOf(bookId), Long.valueOf(authorId));
        authorCommand.setBookId(Long.valueOf(bookId));
        System.out.println("Book id:" + authorCommand.getBookId());

        //model.addAttribute("author", authorCommand);
        return "book/author/editauthor";
    }

    @PutMapping("authoredit")
    @ResponseStatus(HttpStatus.OK)
    @PostMapping("")
    public void saveOrUpdate(@RequestBody AuthorCommand authorCommand){
        System.out.println("Before updating author! Author UPDATE CALLED WITH ID:" + authorCommand.getId() + "AND BOOK ID: " + authorCommand.getBookId());
        AuthorCommand savedAuthorCommand = authorService.updateAuthor(authorCommand);
        System.out.println("Id of author updated:" + savedAuthorCommand.getId());
        //model.addAttribute("translate", tableAttributeService.translate());
        //model.addAttribute("books", bookService.getAllBooks());

       // return "redirect:/book/" + authorCommand.getBookId() + "/authors";

    }

    @PostMapping("createAuthor")
    @ResponseStatus(HttpStatus.CREATED)
    public void createAuthor(@RequestBody AuthorCommand authorCommand){
        System.out.println("BEFORE CREATING AUTHOR");
        AuthorCommand createAuthorCommand = authorService.addAuthorToBook(authorCommand.getBookId(), authorCommand);
        System.out.println("Id of author created:" + createAuthorCommand.getId() + "for book with id:" + authorCommand.getBookId());

        // model.addAttribute("translate", tableAttributeService.translate());
       // model.addAttribute("authors", authorService.getAllAuthors());
        //return "redirect:/book/" + authorCommand.getBookId() + "/authors";

    }

    @GetMapping("/book/{bookId}/author/create")
    @ResponseStatus(HttpStatus.OK)
    public String openCreateAuthor(@PathVariable String bookId){
        AuthorCommand authorCommand = new AuthorCommand();
        authorCommand.setBookId(Long.valueOf(bookId));
        System.out.println("Book id set: " + authorCommand.getBookId());

        //model.addAttribute("author", authorCommand) ;
        return "book/author/createAuthor";
    }


}
