package springwebappservice.service;

import springwebapp.commands.BookCommand;
import springwebapp.converters.BookCommandToBook;
import springwebapp.converters.BookToBookCommand;
import springwebapp.exceptions.NotFoundException;
import springwebapp.model.Book;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springwebapp.repository.BookRepository;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service("bookService")
@Component
public class BooServiceImpl implements BookService {

    @Autowired
    BookRepository repository;

    private final BookCommandToBook commandToBook;

   private final BookToBookCommand bookToBookCommand;

    public BooServiceImpl(BookRepository repository, BookCommandToBook commandToBook, BookToBookCommand bookToBookCommand) {
        this.repository = repository;
        this.commandToBook = commandToBook;
        this.bookToBookCommand = bookToBookCommand;
    }

    @Override
    public BookCommand createBook(BookCommand bookCommand){

        Book book = commandToBook.convert(bookCommand);
       Book savedBook = repository.save(book);

        return bookToBookCommand.convert(savedBook);
    }

    @Override
    public List<BookCommand> getAllBooks(){
        String status = "getting all books";
        System.out.println(status);
       // return status;
        Iterable<Book> iterable = repository.findAll();
        System.out.println("Taken books!");
        List<Book> list = new ArrayList<Book>();
        if(iterable != null) {
            for(Book e: iterable) {
               // System.out.println(e.toString());
                list.add(e);
            }
        }

        List<BookCommand> bookCommands = new ArrayList<>();
        for(Book b: list)
        {
            System.out.println("Book info before converting: " + b.toString());
              bookCommands.add(bookToBookCommand.convert(b));
            System.out.println("Finished converting!");
        }
        return bookCommands;
    }


//    @Override
//    @Transactional
//    public String getBook(Long id){
//        String status = "getting book";
//        System.out.println(status);
//        return status; }

    @Override
    public BookCommand updateBook(BookCommand bookCommand) {
        String status = "updating Book";
        System.out.println(status);
        Book book =  commandToBook.convert(bookCommand);

        repository.save(book);

        return bookCommand;
    }

    @Override
    public void deleteBook(Long id){
        String status = "deleting book";
        System.out.println(status);
        repository.deleteById(id);

    }


    @Override
    public BookCommand findById(Long id){
        String status = "getting command book";
        System.out.println(status);
        Optional<Book> bookOptional =  repository.findById(id);

        if (!bookOptional.isPresent()) {
            //throw new RuntimeException("Recipe Not Found!");
            throw new NotFoundException("Recipe Not Found for id:" + id.toString());
        }




        BookCommand bookCommand = bookToBookCommand.convert(bookOptional.get());

        return bookCommand;
    }


    @Override
    public BookCommand getAuthorsByBook(Long id){
        String status = "getting command book";
        System.out.println(status);
        Optional<Book> bookOptional =  repository.findById(id);

        BookCommand bookCommand = bookToBookCommand.convert(bookOptional.get());

        return bookCommand;
    }



}
