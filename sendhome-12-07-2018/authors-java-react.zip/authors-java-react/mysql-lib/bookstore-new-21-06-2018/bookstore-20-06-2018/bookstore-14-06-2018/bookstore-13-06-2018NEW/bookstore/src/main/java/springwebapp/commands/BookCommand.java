package springwebapp.commands;

import org.hibernate.validator.constraints.URL;
import springwebapp.model.*;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.HashSet;
import java.util.Set;

public class BookCommand {

    private Long id;
    private String title;

    private Byte[] image;

    private EvalutationCommand evaluation;
    private Set<CommentCommand> comments = new HashSet<>();

    @NotBlank
    @Size(min = 3, max = 255)
    public String description;

    @Min(1)
    @Max(999)
    private String size;

    @URL
    private String url;

    @NotBlank
    private String note;

    private PublisherCommand publisher;

    private Difficutly difficutly;

    public Set<CategoryCommand> categories = new HashSet<>();

    private String stringCategories;

    private Set<AuthorCommand> authors = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Byte[] getImage() {
        return image;
    }

    public void setImage(Byte[] image) {
        this.image = image;
    }

    public EvalutationCommand getEvaluation() {
        return evaluation;
    }

    public void setEvaluation(EvalutationCommand evaluation) {
        this.evaluation = evaluation;
    }

    public Set<CommentCommand> getComments() {
        return comments;
    }

    public void setComments(Set<CommentCommand> comments) {
        this.comments = comments;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public PublisherCommand getPublisher() {
        return publisher;
    }

    public void setPublisher(PublisherCommand publisher) {
        this.publisher = publisher;
    }

    public Difficutly getDifficutly() {
        return difficutly;
    }

    public void setDifficutly(Difficutly difficutly) {
        this.difficutly = difficutly;
    }

    public Set<CategoryCommand> getCategories() {
        return this.categories;
    }

    public void setCategories(Set<CategoryCommand> categories) {
        this.categories = categories;
    }

    public String getStringCategories() {
        return stringCategories;
    }

    public void setStringCategories(String stringCategories) {
        this.stringCategories = stringCategories;
    }

    public Set<AuthorCommand> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<AuthorCommand> authors) {
        this.authors = authors;
    }

    public BookCommand(Long id) {
        this.id = id;
    }

    public BookCommand(){}
}
