package springwebapp.model;

public enum Difficutly {

    EASY, MODERATE, KIND_OF_HARD, HARD

}
