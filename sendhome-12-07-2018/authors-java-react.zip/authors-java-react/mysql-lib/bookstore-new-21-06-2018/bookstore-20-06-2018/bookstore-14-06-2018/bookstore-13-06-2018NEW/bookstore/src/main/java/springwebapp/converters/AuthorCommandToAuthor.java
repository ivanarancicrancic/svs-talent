package springwebapp.converters;


import springwebapp.commands.AuthorCommand;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Author;

@Component
public class AuthorCommandToAuthor implements Converter<AuthorCommand, Author> {

    @Override
    public Author convert(AuthorCommand source){

        if(source == null){
            return null;
        }

        final Author author = new Author();
        if(source.getId() != null){
        author.setId(source.getId());
        }
        author.setFirstName(source.getFirstName());
        author.setLastName(source.getLastName());
         return author;
    }





}
