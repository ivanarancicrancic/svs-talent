package springwebapp.contoller;

import com.google.gson.Gson;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import springwebapp.commands.BookCommand;
import springwebapp.commands.CategoryCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import springwebapp.exceptions.NotFoundException;
import springwebapp.model.Book;
import springwebapp.model.Category;
import springwebapp.model.Difficutly;
import springwebapp.repository.BookRepository;
import springwebapp.repository.CategoryRepository;
import springwebappservice.service.BookService;
import springwebappservice.service.CategoryService;
import springwebappservice.service.TableAttributeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.validation.Valid;
import java.util.List;

@RestController
public class BookController {

    public static final Logger logger = LoggerFactory.getLogger(BookController.class);
    private static final String BOOK_BOOKFORM_URL = "book/bookform";

    @Autowired
    BookService bookService;

    @Autowired
    CategoryService caategoryService;

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    BookRepository bookRepository;

    @Autowired
    TableAttributeService tableAttributeService;

    public BookController(BookService bookService, TableAttributeService tableAttributeService, CategoryRepository categoryRepository, CategoryService categoryService, BookRepository bookRepository) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.categoryRepository = categoryRepository;
        this.caategoryService = categoryService;
        this.bookRepository = bookRepository;
    }

    @GetMapping("/books")
    @ResponseStatus(HttpStatus.OK)
    public String getBooks() throws Exception
    {
        System.out.println("Entered /books");
//        List<BookCommand> books = bookService.getAllBooks();
//        if(books==null) {System.out.println("EMPTY BOOKLIST");}
//        for(BookCommand b:books){
//            System.out.println("Check books");
//            if(b.getCategories()==null){System.out.println("Empty categories");}
//            for(CategoryCommand c: b.getCategories())
//            System.out.println("Book category:" + c.getDescription());
//        }

//        model.addAttribute("translate", tableAttributeService.translate());
//        model.addAttribute("books", bookService.getAllBooks());
//        return "books";

        List<BookCommand> books = null;
        String book_str = null;

        // model.addAttribute("authors", authorService.getAllAuthors());
        //return "authors";

        try{
            books = bookService.getAllBooks();
            Gson gson = new Gson();
            System.out.println(books);

            book_str = gson.toJson(books);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }


    }

    @GetMapping("/findByDescription")
    @ResponseStatus(HttpStatus.OK)
    public String getCategoryByDescription() throws  Exception
    {
        System.out.println("Entered /findByDescription");
        Category cagetory = categoryRepository.findByDescription("Drama");
        System.out.println("Category id is: " + cagetory.getId() + ", for description: " + cagetory.getDescription());

        //model.addAttribute("translate", tableAttributeService.translate());
        //model.addAttribute("books", bookService.getAllBooks());
        //return "books";

         String category_str =null;

        try{
            Gson gson = new Gson();

            category_str = gson.toJson(cagetory);
            System.out.println(category_str);
            return category_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }

    @GetMapping("/book/show/{id}")
    @ResponseStatus(HttpStatus.OK)
    public String showById(@PathVariable String id) throws  Exception{
        System.out.println("entered book/show/{id}");

       // model.addAttribute("book", bookService.findById(new Long(id)));
      //  return "book/show";

        String book_str =null;

        try{
            Gson gson = new Gson();
            BookCommand bookCommand =  bookService.findById(new Long(id));
            book_str = gson.toJson(bookCommand);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }


    }


    @GetMapping("book/create")
    @ResponseStatus(HttpStatus.OK)
    public void createBook() throws Exception{
        Book book = new Book();
        bookRepository.save(book);
        System.out.println("New book ID: " + book.getId());
        BookCommand bookCommand = new BookCommand(book.getId());

//        model.addAttribute("book", bookCommand);
//        return "book/createbookform";


    }

    @PostMapping("create")
    @ResponseStatus(HttpStatus.CREATED)
    public String createBook(@RequestBody BookCommand bookCommand) throws Exception{
        System.out.println("BEFORE CREATING BOOK");
        bookCommand.setDifficutly(Difficutly.HARD);
        bookCommand.setTitle("NEW");
        BookCommand createdBookCommand = bookService.createBook(bookCommand);
        System.out.println("Id of book created:" + createdBookCommand.getId());
//        model.addAttribute("translate", tableAttributeService.translate());
//        model.addAttribute("books", bookService.getAllBooks());

      //  model.addAttribute("translate", tableAttributeService.translate());
       // model.addAttribute("books", bookService.getAllBooks());
       // return "books";
        String book_str =null;
        try{
            Gson gson = new Gson();
            book_str = gson.toJson(createdBookCommand);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }

    }


    @GetMapping("book/{id}/update")
    @ResponseStatus(HttpStatus.OK)
    public void updateBook(@PathVariable String id){

        System.out.println("BOOK CATEGORIES BEFORE UPDATE: ");
        for(CategoryCommand c: bookService.findById(Long.valueOf(id)).getCategories()){
            System.out.println("CATEGORY: " + c.getDescription());
        }

        //model.addAttribute("categories", caategoryService.getAllCategories());
//        model.addAttribute("book", bookService.findById(Long.valueOf(id)));
//        return "book/bookform";
    }


    @PutMapping("book")
    @ResponseStatus(HttpStatus.OK)
    public String saveOrUpdate(@RequestBody BookCommand bookCommand) throws  Exception{

        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getId());
        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getCategories());
        BookCommand savedBookCommand = bookService.updateBook(bookCommand);
        //BookCommand savedBookCommand = bookService.createBook(bookCommand);
          System.out.println("Id of book updated:" + savedBookCommand.getId());
        System.out.println("Categories of book updated: ");
        for(CategoryCommand categoryCommand : savedBookCommand.getCategories())
                System.out.println("Category: " +  categoryCommand.getDescription());

        String book_str =null;
        try{
            Gson gson = new Gson();
            book_str = gson.toJson(savedBookCommand);
            System.out.println(book_str);
            return book_str;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            throw e;
        }


        // return "redirect:/book/show/" + savedBookCommand.getId();
    }


    @GetMapping("book/{id}/delete")
    @ResponseStatus(HttpStatus.OK)
    public void deleteBook(@PathVariable String id){
        bookService.deleteBook(Long.valueOf(id));

       // model.addAttribute("translate", tableAttributeService.translate());
        //model.addAttribute("books", bookService.getAllBooks());
       // return "books";

    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NotFoundException.class)
    public ModelAndView handleNotFound(Exception exception){
        ModelAndView modelAndView = new ModelAndView();
        System.out.println("Handling not found exception");
        System.out.println("Exception message: " + exception.getMessage());
        modelAndView.setViewName("404error");
        modelAndView.addObject("exception", exception);
        return modelAndView;
    }

//    @ResponseStatus(HttpStatus.BAD_REQUEST)
//    @ExceptionHandler(NumberFormatException.class)
//    public ModelAndView handleNumberFormatException(Exception exception){
//        ModelAndView modelAndView = new ModelAndView();
//        System.out.println("Handling number format exception");
//        System.out.println("Exception message: " + exception.getMessage());
//        modelAndView.setViewName("400error");
//        modelAndView.addObject("exception", exception);
//        return modelAndView;
//    }
}
