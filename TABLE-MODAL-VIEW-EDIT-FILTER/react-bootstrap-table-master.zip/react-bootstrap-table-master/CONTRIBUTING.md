`react-bootstrap-table` will stop develop new feature and move to [react-bootstrap-table2](https://github.com/react-bootstrap-table/react-bootstrap-table2/tree/develop), but keep to fix critical bugs.   

`react-bootstrap-table2` still work in progress, we will drop a first release ASAP.   
In addition, I don't think `react-bootstrap-table` is a good table component for developer, but I trust `react-bootstrap-table2` will be in the future.   

If you face too many issues to feel it's hard to custom or work with remote data, I'll suggest you to not use `react-bootstrap-table`.

Allen