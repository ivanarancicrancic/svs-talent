import React from 'react';

class GettingStarted extends React.Component {
  render() {
    return (
      <div>
        <h1>Getting started</h1>
        <code>npm i react-bootstrap-table --save</code>
      </div>
    );
  }
}

export default GettingStarted;
