import React from 'react';

class PageNotFound extends React.Component {
  render() {
    return (
      <div>Page Not Found</div>
    );
  }
}

export default PageNotFound;
