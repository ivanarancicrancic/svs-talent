#!/bin/bash
cp nginx.conf /usr/local/etc/nginx
cat /usr/local/etc/nginx/nginx.conf
