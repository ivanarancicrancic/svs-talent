Typescript React Webpack build.
1. Clone repo
2. `npm install` in the cloned directory
3. `npm run build`
4. Open Web browser to localhost:4000 
