images = [
    {
        'name': 'autum_trees.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/autum_trees.jpg'
    },
    {
        'name': 'jmstudiosbackground.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/jmstudiosbackground.jpg'
    },
    {
        'name': 'me.jpg',
        'type': 'team',
        'path': 'db_setup_scripts/setup_data/me.jpg'
    },
    {
        'name': 'bridge-over-the-river.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/bridge-over-the-river.jpg'
    },
    {
        'name': 'milky-way.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/milky-way.jpg'
    },
    {
        'name': 'mountains_landscape.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/mountains_landscape.jpg'
    },
    {
        'name': 'no_image.jpg',
        'type': 'common',
        'path': 'db_setup_scripts/setup_data/no_image.jpg'
    },
    {
        'name': 'profilepic.jpg',
        'type': 'team',
        'path': 'db_setup_scripts/setup_data/profilepic.jpg'
    },
    {
        'name': 'space-background.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/space-background.jpg'
    },
    {
        'name': 'space-earth-stratosphere-wallpaper-1.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/space-earth-stratosphere-wallpaper-1.jpg'
    },
    {
        'name': 'water-drop-wallpaper-3.jpg',
        'type': 'parallax',
        'path': 'db_setup_scripts/setup_data/water-drop-wallpaper-3.jpg'
    }
]
