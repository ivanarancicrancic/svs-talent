*** Backend for JMStudios

Python3 project
1. Install project dependencies from requirements.txt file


Backend Tests
1. Can run individules tests or just run setup.py in unittests to run all tests
