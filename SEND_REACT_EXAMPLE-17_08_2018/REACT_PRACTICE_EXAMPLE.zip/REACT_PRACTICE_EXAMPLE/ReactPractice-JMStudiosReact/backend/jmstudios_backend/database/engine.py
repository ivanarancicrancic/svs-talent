
class Engine():
    def __init__(self, meta, con):
        self.meta = meta
        self.con = con
