const projectConfig = {
    'baseURL': ''
}

export default projectConfig
