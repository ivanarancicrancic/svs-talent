package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;

public class BuyPackageRequestModel {

    @NotNull
    private Long packageId;

    private String couponCode;
    private Long couponId;

    public BuyPackageRequestModel() {
    }

    @AssertTrue
    private boolean isCouponOk() {
        return (!(couponCode != null && couponId != null));
    }

    public Long getPackageId() {
        return packageId;
    }

    public void setPackageId(Long packageId) {
        this.packageId = packageId;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public Long getCouponId() {
        return couponId;
    }

    public void setCouponId(Long couponId) {
        this.couponId = couponId;
    }

    public boolean hasCoupon() {
        return couponCode != null || couponId != null;
    }

}
