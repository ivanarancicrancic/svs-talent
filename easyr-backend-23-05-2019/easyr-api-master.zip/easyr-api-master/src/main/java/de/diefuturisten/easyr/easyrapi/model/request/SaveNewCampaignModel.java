package de.diefuturisten.easyr.easyrapi.model.request;

import javax.validation.constraints.NotNull;

public class SaveNewCampaignModel {

    @NotNull
    private Long packageId;

    public SaveNewCampaignModel() {
    }

    public long getPackageId() {
        return packageId;
    }

    public void setPackageId(long packageId) {
        this.packageId = packageId;
    }
}
