package de.diefuturisten.easyr.easyrapi.model.request;

public class EditContentNameModel {

    private String name;

    public EditContentNameModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
