package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.InvalidCaptchaException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordModel;
import de.diefuturisten.easyr.easyrapi.model.request.ForgotPasswordResetModel;
import de.diefuturisten.easyr.easyrapi.service.CaptchaService;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import it.ozimov.springboot.mail.service.exception.CannotSendEmailException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.validation.Valid;
import java.util.NoSuchElementException;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AccountController {

    private final CaptchaService captchaService;
    private final UserService userService;

    public AccountController(UserService userService, CaptchaService captchaService) {
        this.userService = userService;
        this.captchaService = captchaService;
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public ResponseEntity createAccount(@Valid @RequestBody CreateAccountModel model) {
        boolean approved = captchaService.verifyCaptcha(model.getCaptcha());
        if(approved) {
            userService.create(model);
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "/forgotpw", method = RequestMethod.POST)
    public ResponseEntity forgotPassword(@Valid @RequestBody ForgotPasswordModel model) throws InvalidCaptchaException {
        boolean approved = captchaService.verifyCaptcha(model.getCaptcha());

        if(!approved) {
            throw new InvalidCaptchaException();
        }
        try {
            userService.forgotPassword(model);

        } catch(NoSuchElementException ex){
            return new ResponseEntity(HttpStatus.OK);
        } catch(CannotSendEmailException ex){
            return new ResponseEntity(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping("/resetpw")
    public ResponseEntity resetPasswordRequest(@Valid @RequestBody ForgotPasswordResetModel model) {
        try {
            User user = userService.getUserByUsername(model.getEmail());

            boolean check = userService.resetPassword(user, model.getToken(), model.getNewPassword());
            if(!check){
                return new ResponseEntity<>(HttpStatus.FORBIDDEN);
            } else {
                return new ResponseEntity<>(HttpStatus.OK);
            }

        } catch(NoSuchElementException ex){
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        } catch(CannotSendEmailException e){
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
