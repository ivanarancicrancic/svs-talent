package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.exceptions.MyFileNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.ProbablyNotAnImageException;
import de.diefuturisten.easyr.easyrapi.exceptions.ValidationException;
import de.diefuturisten.easyr.easyrapi.model.response.TrackerModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.FileStorageService;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.IOException;
import org.springframework.security.access.prepost.PreAuthorize;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TrackerController {

    private final AuthenticationFacade authenticationFacade;
    private final TrackerService trackerService;
    private final CampaignService campaignService;
    private final FileStorageService fileStorageService;

    public TrackerController(AuthenticationFacade authenticationFacade, TrackerService trackerService, CampaignService campaignService, FileStorageService fileStorageService) {
        this.authenticationFacade = authenticationFacade;
        this.trackerService = trackerService;
        this.campaignService = campaignService;
        this.fileStorageService = fileStorageService;
    }

    @PostMapping("/campaign/{campaignId}/tracker")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_CREATE)
    public ResponseEntity createTracker(@PathVariable long campaignId, @RequestParam("file") MultipartFile multipartFile) throws IOException, ProbablyNotAnImageException {
        System.out.println("1 before calling fileStorageService.storeTemporaryTrackerFile(multipartFile)");
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

//        if(!campaign.getUser().equals(user)) {
//            throw new ForbiddenException();
//        }

        System.out.println("before calling fileStorageService.storeTemporaryTrackerFile(multipartFile)");
        // save as temporary file
        System.out.println("MultFile: " + multipartFile.toString());
        File convertedFile = fileStorageService.storeTemporaryTrackerFile(multipartFile);

        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        // upload magic
        System.out.println("Before calling trackerService.createTrackerForCampaign with convertedFile: " + convertedFile.toString());
        Tracker tracker = trackerService.createTrackerForCampaign(campaign, convertedFile);
        System.out.println("trackerService.createTrackerForCampaign(campaign, convertedFile) executed!!! With tracker: " + tracker.toString());
//        return new TrackerModel(tracker);
        return ResponseEntity.ok(new TrackerModel(tracker));
    }

    @PostMapping("/campaign/tracker/{trackerId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_EDIT)
    public ResponseEntity updateTracker(@PathVariable long trackerId, @RequestParam("file") MultipartFile multipartFile) throws ProbablyNotAnImageException {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

          // allow only files with PNG or JPG extension
        String extension = FileStorageService.GetFileExtension(multipartFile.getOriginalFilename());
        if( !(extension.equals(".png") || extension.equals(".jpg")) ) {
            throw new ValidationException();
        }
          // 2MB limit
        if(multipartFile.getSize() > 2097152) {
            throw new ValidationException();
        }

        // save as temporary file
        File convertedFile = fileStorageService.storeTemporaryTrackerFile(multipartFile);
        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        Tracker editedTracker = trackerService.editTracker(tracker, convertedFile);

        if(editedTracker != null) {
            return ResponseEntity.ok(new TrackerModel(tracker));
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/campaign/tracker/{trackerId}")
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.TRACKER_DELETE)
    public ResponseEntity deleteTracker(@PathVariable long trackerId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        boolean res = trackerService.deleteTracker(tracker);

        if(res) {
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }




}
