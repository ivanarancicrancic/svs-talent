package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.user.ResetPasswordToken;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ResetPasswordTokenRepository extends JpaRepository<ResetPasswordToken, Long> {
    Optional<ResetPasswordToken> findByUser(User user);
    Optional<ResetPasswordToken> findByUserAndToken(User user, String tokenValue);
}
