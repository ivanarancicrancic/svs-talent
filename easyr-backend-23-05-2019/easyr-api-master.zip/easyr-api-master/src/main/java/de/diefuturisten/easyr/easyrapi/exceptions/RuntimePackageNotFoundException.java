package de.diefuturisten.easyr.easyrapi.exceptions;

public class RuntimePackageNotFoundException extends Throwable {
}
