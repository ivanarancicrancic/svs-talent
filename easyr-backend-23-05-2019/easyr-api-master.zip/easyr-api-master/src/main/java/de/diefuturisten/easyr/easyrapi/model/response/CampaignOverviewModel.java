package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;

import java.util.Date;

public class CampaignOverviewModel {

    private long id;
    private String name;
    private String trackerUrl;
    private long numberOfViews;
    private Date expirationDate;

    public CampaignOverviewModel() {
    }

    public CampaignOverviewModel(Campaign campaign) {
        this.id = campaign.getId();
        this.name = campaign.getName();

        this.trackerUrl = campaign.getTracker()
                .stream()
                .map(Tracker::getUrl)
                .findFirst().orElse(null);

        this.numberOfViews = campaign.getTotalTrackings();

        this.expirationDate = campaign.getRuntimes()
                .stream().sorted((o1, o2) -> o2.getEnd().compareTo(o1.getEnd())).map(Runtime::getEnd).findFirst().orElse(null);
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTrackerUrl() {
        return trackerUrl;
    }

    public void setTrackerUrl(String trackerUrl) {
        this.trackerUrl = trackerUrl;
    }

    public long getNumberOfViews() {
        return numberOfViews;
    }

    public void setNumberOfViews(long numberOfViews) {
        this.numberOfViews = numberOfViews;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }
}
