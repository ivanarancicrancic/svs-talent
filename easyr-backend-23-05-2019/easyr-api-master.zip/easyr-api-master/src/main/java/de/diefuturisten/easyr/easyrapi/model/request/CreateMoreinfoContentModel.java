package de.diefuturisten.easyr.easyrapi.model.request;

public class CreateMoreinfoContentModel extends CreateContentModel {

    private String url;

    public CreateMoreinfoContentModel() {
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
