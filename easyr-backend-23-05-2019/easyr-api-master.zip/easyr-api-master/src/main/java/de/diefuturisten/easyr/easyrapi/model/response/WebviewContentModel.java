package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;

public class WebviewContentModel extends ContentModel {

    private String url;

    public WebviewContentModel() {}

    public WebviewContentModel(WebviewContent content) {
        super(content, "webview");

        this.url = content.getUrl();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
