package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.exceptions.ProbablyNotAnImageException;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Transparency;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Iterator;

@Service
public class FileStorageService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    public static String GetFileExtension(String name) {
        int lastIndexOf = name.lastIndexOf(".");
        if (lastIndexOf == -1) {
            return "";
        }
        return name.substring(lastIndexOf);
    }

    public static BufferedImage fillTransparentPixels(BufferedImage image, Color fillColor) {
        int w = image.getWidth();
        int h = image.getHeight();
        BufferedImage image2 = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = image2.createGraphics();
        g.setColor(fillColor);
        g.fillRect(0,0,w,h);
        g.drawRenderedImage(image, null);
        g.dispose();
        return image2;
    }

    public File compressFile(File file, int interation) throws IOException, ProbablyNotAnImageException {
        log.info(String.format("Will compress: %s , iteration: %d", file.getName(), interation));

        BufferedImage image = ImageIO.read(file);
        if(image == null) {
            throw new ProbablyNotAnImageException();
        }

        if(image.getColorModel().getTransparency() != Transparency.OPAQUE) {
            image = fillTransparentPixels(image, Color.WHITE);
        }

        File compressedTempFile = File.createTempFile("tmp-", ".jpg");
        OutputStream os = new FileOutputStream(compressedTempFile);

        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
        ImageWriter writer = writers.next();

        ImageOutputStream ios = ImageIO.createImageOutputStream(os);
        writer.setOutput(ios);

        ImageWriteParam param = writer.getDefaultWriteParam();

        param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
        param.setCompressionQuality( (10 - interation) / 10);  // Change the quality value you prefer

        IIOImage newImage = new IIOImage(image, null, null);
        writer.write(null, newImage, param);

        file.delete();

        return compressedTempFile;
    }

    public File storeTemporaryTrackerFile(MultipartFile file) throws ProbablyNotAnImageException {

        System.out.println("entered storeTemporaryTrackerFile service with file:" + file.toString());
        String extension = GetFileExtension(file.getOriginalFilename());
        System.out.println("extension: " + extension + ", fileName: " + file.getName());

        try {
//            File tempFile = File.createTempFile("tmp-", "jpg");
//            Files.copy(file.getInputStream(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            System.out.println("File tmp-jpg created!");
            Path folder = Paths.get("./src/main/resources");
            System.out.println("Path found!");
            String filename = FilenameUtils.getBaseName(file.getName());
            System.out.println(" FilenameUtils.getBaseName(file.getName()) executed!!!");
//            String extension = "jpg";
            String workingDir = System.getProperty("user.dir");
            System.out.println("WorkingDir: " + workingDir);

            Path file1 = Files.createTempFile(folder,filename + "-", ".jpg");
            System.out.println("Files.createTempFile(folder, filename + \"-\", \".jpg\") executed!!!");
            Files.copy(file.getInputStream(), file1, StandardCopyOption.REPLACE_EXISTING);

//            File tempFile = new File(folder + "/" + filename + ".jpg");
            File tempFile = new File(file1.toString());
            System.out.println("After file copy-paste on path: " + file1);
//            int iteration = 0;
//            do {
//                tempFile = compressFile(tempFile, iteration++);
//            } while(tempFile.length() > 2097152 && iteration < 10);
            System.out.println("tempFile to return: " + tempFile.toString());
            return tempFile;

        } catch (IOException e) {
            return null;
        }
    }

}
