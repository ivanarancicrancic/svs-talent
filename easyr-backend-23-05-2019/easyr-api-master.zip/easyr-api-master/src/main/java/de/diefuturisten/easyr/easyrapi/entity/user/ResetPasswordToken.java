package de.diefuturisten.easyr.easyrapi.entity.user;

import java.util.Date;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="reset_password_tokens")
public class ResetPasswordToken {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_token")
    private long id;

    @ManyToOne(cascade = CascadeType.MERGE)
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="expires", nullable = false)
    private Date expires;

    @Column(name="token", nullable = false)
    private String token;

    public ResetPasswordToken() {

    }

    public ResetPasswordToken(User user, Date expires, String token) {
        this.setUser(user);
        this.setExpires(expires);
        this.setToken(token);
    }

    // getter & setter

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date getExpires() {
        return expires;
    }

    public void setExpires(Date expires) {
        this.expires = expires;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
