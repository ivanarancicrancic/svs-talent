package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import java.util.Optional;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import  de.diefuturisten.easyr.easyrapi.service.ContentService;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import de.diefuturisten.easyr.easyrapi.controller.ContentController;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAudioContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreatePanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateUnityContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditPanoramaContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditUnityContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;

public class ContentControllerTest {
    private MockMvc mockMvc;
    private ContentController contentController;
    private AuthenticationFacade authenticationFacade;
    private ContentService contentService;
    private CampaignService campaignService;
    private SlideshowImageService slideshowImageService;
    private ObjectMapper mapper;
    private Campaign mockCampaign;
    private User user;
    private AudioContent audioContent;
    private MovieContent movie;
    private WebviewContent webviewContent;
    private PanoramaContent mockPanorama;
    private UnityContent mockUnity;
    private SlideshowContent mockSlideshowContent;
    private SlideshowImage mockSlideshowImage;
    private User user1;

    @Before
    public void setUp() {
        contentService = mock(ContentService.class);
        campaignService = mock(CampaignService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        slideshowImageService = mock(SlideshowImageService.class);
        contentController = new ContentController(authenticationFacade, contentService, campaignService, slideshowImageService);
        mockCampaign = mock(Campaign.class);
        user = mock(User.class);
        user1 = mock(User.class);
        audioContent = mock(AudioContent.class);
        movie = mock(MovieContent.class);
        webviewContent = mock(WebviewContent.class);
        mockPanorama = mock(PanoramaContent.class);
        mockUnity = mock(UnityContent.class);
        mockSlideshowContent = mock(SlideshowContent.class);
        mockSlideshowImage = mock(SlideshowImage.class);
        mockMvc = MockMvcBuilders.standaloneSetup(contentController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void deleteContent() throws Exception {
        Content content = audioContent;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.deleteContent(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/content/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        //verify that the delete method has been invoked
        verify(contentService).deleteContent(Mockito.any(Content.class));
    }

    @Test
    public void deleteContentNoContent() throws Exception {
        Content content = audioContent;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.deleteContent(Mockito.any(Content.class))).thenReturn(true);
        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/content/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void deleteContentUserNotEqualToUser() throws  Exception{
        Content content = audioContent;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.deleteContent(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.delete(
                "/api/campaign/content/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveContentUp() throws Exception {
        Content content = movie;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.moveUp(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/up").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    }

    @Test
    public void moveContentUpNoContent() throws Exception {
        Content content = movie;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.moveUp(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/up").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveContentUpUserNotEqual() throws Exception {
        Content content = movie;
         Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.moveUp(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/up").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveContentDown() throws Exception {
        Content content = movie;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.moveDown(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/down").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        //verify that the movrDown method has been invoked
        verify(contentService).moveDown(Mockito.any(Content.class));
    }

    @Test
    public void moveContentDownNoContent() throws Exception {
        Content content = movie;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.moveUp(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/down").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveContentDownUserNotEqual() throws Exception {
        Content content = movie;

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(content));
        Mockito.when(content.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.moveUp(Mockito.any(Content.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.put(
                "/api/campaign/content/" + 1 + "/down").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createWebviewContent() throws Exception {
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("blahsth");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createWebviewContent(Mockito.any(Campaign.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/webview")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createWebviewContentNullCampaign() throws Exception {
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("blahsth");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createWebviewContent(Mockito.any(Campaign.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/webview")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createWebviewContentUserNotEqual() throws Exception {
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("blahsth");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.createWebviewContent(Mockito.any(Campaign.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/webview")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editWebviewContent() throws Exception {
        CreateWebviewContentModel editWebviewContentModel = new CreateWebviewContentModel();
        editWebviewContentModel.setUrl("new blahsth");
        editWebviewContentModel.setName("edited webview name");
        editWebviewContentModel.setWeight(5);
        editWebviewContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(webviewContent));
        Mockito.when(webviewContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editWebviewContent(Mockito.any(WebviewContent.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/webview/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editWebviewContentContentNull() throws Exception {
        CreateWebviewContentModel editWebviewContentModel = new CreateWebviewContentModel();
        editWebviewContentModel.setUrl("new blahsth");
        editWebviewContentModel.setName("edited webview name");
        editWebviewContentModel.setWeight(5);
        editWebviewContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(webviewContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editWebviewContent(Mockito.any(WebviewContent.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/webview/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editWebviewContentUserNotEqual() throws Exception {
        CreateWebviewContentModel editWebviewContentModel = new CreateWebviewContentModel();
        editWebviewContentModel.setUrl("new blahsth");
        editWebviewContentModel.setName("edited webview name");
        editWebviewContentModel.setWeight(5);
        editWebviewContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(webviewContent));
        Mockito.when(webviewContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.editWebviewContent(Mockito.any(WebviewContent.class), Mockito.any(CreateWebviewContentModel.class))).thenReturn(webviewContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/webview/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editWebviewContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createAudioContent() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createAudioContent(Mockito.any(Campaign.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/audio")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createAudioContentCampaignNull() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createAudioContent(Mockito.any(Campaign.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/audio")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createAudioContentUserNotEqual() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.createAudioContent(Mockito.any(Campaign.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1 + "/audio")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editAudioContent() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(audioContent));
        Mockito.when(audioContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editAudioContent(Mockito.any(AudioContent.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/audio/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editAudioContent_ContentNull() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(audioContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editAudioContent(Mockito.any(AudioContent.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/audio/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editAudioContentUserNotEqual() throws Exception {
        CreateAudioContentModel createAudioContentModel = new CreateAudioContentModel();
        createAudioContentModel.setUrl("blahsth");
        createAudioContentModel.setName("webview name");
        createAudioContentModel.setWeight(1);
        createAudioContentModel.setRenderOnTrackingLost(true);
        createAudioContentModel.setType("type");
        createAudioContentModel.setId(1L);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(audioContent));
        Mockito.when(audioContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.editAudioContent(Mockito.any(AudioContent.class), Mockito.any(CreateAudioContentModel.class))).thenReturn(audioContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/audio/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createAudioContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createMovieContent() throws Exception {
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("blahsth");
        createMovieContentModel.setName("webview name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("type");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.createMovieContent(Mockito.any(Campaign.class), Mockito.any(CreateMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/movie")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createMovieContentUserNotEqual() throws Exception {
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("blahsth");
        createMovieContentModel.setName("webview name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("type");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.createMovieContent(Mockito.any(Campaign.class), Mockito.any(CreateMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/movie")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createMovieContentCampaignNull() throws Exception {
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("blahsth");
        createMovieContentModel.setName("webview name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("type");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.createMovieContent(Mockito.any(Campaign.class), Mockito.any(CreateMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/movie")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createPanoramaContent() throws Exception {
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("blahsth");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);
        Mockito.when(contentService.createPanoramaContent(Mockito.any(Campaign.class), Mockito.any(CreatePanoramaContentModel.class))).thenReturn(mockPanorama);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/panorama")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createPanoramaContentCampaignNull() throws Exception {
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("blahsth");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);
        Mockito.when(contentService.createPanoramaContent(Mockito.any(Campaign.class), Mockito.any(CreatePanoramaContentModel.class))).thenReturn(mockPanorama);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/panorama")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createPanoramaContentUserNotEqual() throws Exception {
        CreatePanoramaContentModel createPanoramaContentModel = new CreatePanoramaContentModel();
        createPanoramaContentModel.setUrl("blahsth");
        createPanoramaContentModel.setName("webview name");
        createPanoramaContentModel.setWeight(1);
        createPanoramaContentModel.setType("type");
        createPanoramaContentModel.setId(1L);
        createPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);
        Mockito.when(contentService.createPanoramaContent(Mockito.any(Campaign.class), Mockito.any(CreatePanoramaContentModel.class))).thenReturn(mockPanorama);
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/panorama")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createUnityContent() throws Exception {
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("webview name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("type");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createUnityContent(Mockito.any(Campaign.class), Mockito.any(CreateUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/unity")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createUnityContentCampaignNull() throws Exception {
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("webview name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("type");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createUnityContent(Mockito.any(Campaign.class), Mockito.any(CreateUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/unity")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createUnityContentUserNotEqual() throws Exception {
        CreateUnityContentModel createUnityContentModel = new CreateUnityContentModel();
        createUnityContentModel.setName("webview name");
        createUnityContentModel.setWeight(1);
        createUnityContentModel.setType("type");
        createUnityContentModel.setId(1L);
        createUnityContentModel.setAndroidUrl("sthandroid");
        createUnityContentModel.setExtendedTracking(true);
        createUnityContentModel.setIosUrl("sthios");
        createUnityContentModel.setPositionX(1);
        createUnityContentModel.setPositionY(2);
        createUnityContentModel.setPositionZ(3);
        createUnityContentModel.setRotationX(1);
        createUnityContentModel.setRotationY(2);
        createUnityContentModel.setRotationZ(3);
        createUnityContentModel.setScaleX(1);
        createUnityContentModel.setScaleY(2);
        createUnityContentModel.setScaleZ(3);
        createUnityContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.createUnityContent(Mockito.any(Campaign.class), Mockito.any(CreateUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/unity")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }


    @Test
    public void createSlideshowContent() throws Exception {
        CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
        createSlideshowContentModel.setName("webview name");
        createSlideshowContentModel.setWeight(1);
        createSlideshowContentModel.setType("type");
        createSlideshowContentModel.setId(1L);
        createSlideshowContentModel.setExtendedTracking(true);
        createSlideshowContentModel.setPositionX(1);
        createSlideshowContentModel.setPositionY(2);
        createSlideshowContentModel.setPositionZ(3);
        createSlideshowContentModel.setRotationX(1);
        createSlideshowContentModel.setRotationY(2);
        createSlideshowContentModel.setRotationZ(3);
        createSlideshowContentModel.setScaleX(1);
        createSlideshowContentModel.setScaleY(2);
        createSlideshowContentModel.setScaleZ(3);
        createSlideshowContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockSlideshowContent.getType()).thenReturn(SlideshowContent.Type.NORMAL);
        Mockito.when(contentService.createSlideshowContent(Mockito.any(Campaign.class), Mockito.any(CreateSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/slideshow")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void createSlideshowContentCampaignNull() throws Exception {
        CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
        createSlideshowContentModel.setName("webview name");
        createSlideshowContentModel.setWeight(1);
        createSlideshowContentModel.setType("type");
        createSlideshowContentModel.setId(1L);
        createSlideshowContentModel.setExtendedTracking(true);
        createSlideshowContentModel.setPositionX(1);
        createSlideshowContentModel.setPositionY(2);
        createSlideshowContentModel.setPositionZ(3);
        createSlideshowContentModel.setRotationX(1);
        createSlideshowContentModel.setRotationY(2);
        createSlideshowContentModel.setRotationZ(3);
        createSlideshowContentModel.setScaleX(1);
        createSlideshowContentModel.setScaleY(2);
        createSlideshowContentModel.setScaleZ(3);
        createSlideshowContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.createSlideshowContent(Mockito.any(Campaign.class), Mockito.any(CreateSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/slideshow")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createSlideshowContentUserNotEqual() throws Exception {
        CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
        createSlideshowContentModel.setName("webview name");
        createSlideshowContentModel.setWeight(1);
        createSlideshowContentModel.setType("type");
        createSlideshowContentModel.setId(1L);
        createSlideshowContentModel.setExtendedTracking(true);
        createSlideshowContentModel.setPositionX(1);
        createSlideshowContentModel.setPositionY(2);
        createSlideshowContentModel.setPositionZ(3);
        createSlideshowContentModel.setRotationX(1);
        createSlideshowContentModel.setRotationY(2);
        createSlideshowContentModel.setRotationZ(3);
        createSlideshowContentModel.setScaleX(1);
        createSlideshowContentModel.setScaleY(2);
        createSlideshowContentModel.setScaleZ(3);
        createSlideshowContentModel.setRenderOnTrackingLost(true);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.createSlideshowContent(Mockito.any(Campaign.class), Mockito.any(CreateSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign/" + 1  + "/slideshow")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void createImageToSlideshowContent() throws Exception {
        CreateSlideshowImageModel createSlideshowImageModel = new CreateSlideshowImageModel();
        createSlideshowImageModel.setName("image name");
        createSlideshowImageModel.setWeight(1);
        createSlideshowImageModel.setType("type");
        createSlideshowImageModel.setUrl("sthUrl");

        Mockito.when(contentService.createSlideshowImage(Mockito.anyLong(), Mockito.any(CreateSlideshowImageModel.class))).thenReturn(mockSlideshowImage);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/slideshow/" + mockSlideshowContent.getId())
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createSlideshowImageModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void deleteImageFromSlideshowContent() throws Exception {

        Mockito.when(contentService.deleteSlideshowImage(Mockito.anyLong())).thenReturn(mockSlideshowImage);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .delete("/api/slideshowimage/" + 1)
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editMovieContent() throws Exception {
        EditMovieContentModel editMovieContentModel = new EditMovieContentModel();
        editMovieContentModel.setUrl("blahsth");
        editMovieContentModel.setName("newMovie name");
        editMovieContentModel.setWeight(1);
        editMovieContentModel.setRenderOnTrackingLost(true);
        editMovieContentModel.setType("type");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(movie));
        Mockito.when(movie.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.editMovieContent(Mockito.any(MovieContent.class), Mockito.any(EditMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/movie/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editMovieContentContentNull() throws Exception {
        EditMovieContentModel editMovieContentModel = new EditMovieContentModel();
        editMovieContentModel.setUrl("blahsth");
        editMovieContentModel.setName("newMovie name");
        editMovieContentModel.setWeight(1);
        editMovieContentModel.setRenderOnTrackingLost(true);
        editMovieContentModel.setType("type");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        doThrow(new ForbiddenException()).when(contentService).getById(Mockito.anyLong());
        Mockito.when(movie.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.editMovieContent(Mockito.any(MovieContent.class), Mockito.any(EditMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/movie/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editMovieContentUserNotEqual() throws Exception {
        EditMovieContentModel editMovieContentModel = new EditMovieContentModel();
        editMovieContentModel.setUrl("blahsth");
        editMovieContentModel.setName("newMovie name");
        editMovieContentModel.setWeight(1);
        editMovieContentModel.setRenderOnTrackingLost(true);
        editMovieContentModel.setType("type");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(movie));
        Mockito.when(movie.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(movie.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.Type.SPHERE);
        Mockito.when(contentService.editMovieContent(Mockito.any(MovieContent.class), Mockito.any(EditMovieContentModel.class))).thenReturn(movie);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/movie/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editMovieContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editPanoramaContent() throws Exception {
        EditPanoramaContentModel editPanoramaContentModel = new EditPanoramaContentModel();
        editPanoramaContentModel.setUrl("blahsth");
        editPanoramaContentModel.setName("newMovie name");
        editPanoramaContentModel.setWeight(1);
        editPanoramaContentModel.setType("type");
        editPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockPanorama));
        Mockito.when(contentService.editPanoramaContent(Mockito.any(PanoramaContent.class), Mockito.any(EditPanoramaContentModel.class))).thenReturn(mockPanorama);
        Mockito.when(mockPanorama.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/panorama/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editPanoramaContent_ContentNull() throws Exception {
        EditPanoramaContentModel editPanoramaContentModel = new EditPanoramaContentModel();
        editPanoramaContentModel.setUrl("blahsth");
        editPanoramaContentModel.setName("newMovie name");
        editPanoramaContentModel.setWeight(1);
        editPanoramaContentModel.setType("type");
        editPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(contentService.editPanoramaContent(Mockito.any(PanoramaContent.class), Mockito.any(EditPanoramaContentModel.class))).thenReturn(mockPanorama);
        Mockito.when(mockPanorama.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/panorama/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);
        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editPanoramaContentUserNotEqual() throws Exception {
        EditPanoramaContentModel editPanoramaContentModel = new EditPanoramaContentModel();
        editPanoramaContentModel.setUrl("blahsth");
        editPanoramaContentModel.setName("newMovie name");
        editPanoramaContentModel.setWeight(1);
        editPanoramaContentModel.setType("type");
        editPanoramaContentModel.setSubType("SPHERE");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockPanorama));
        Mockito.when(contentService.editPanoramaContent(Mockito.any(PanoramaContent.class), Mockito.any(EditPanoramaContentModel.class))).thenReturn(mockPanorama);
        Mockito.when(mockPanorama.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(mockPanorama.getType()).thenReturn(de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent.Type.SPHERE);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/panorama/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editPanoramaContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
    }

    @Test
    public void editUnityContent() throws Exception {
        EditUnityContentModel editUnityContentModel = new EditUnityContentModel();
        editUnityContentModel.setName("newMovie name");
        editUnityContentModel.setWeight(1);
        editUnityContentModel.setType("type");
        editUnityContentModel.setRenderOnTrackingLost(true);
        editUnityContentModel.setExtendedTracking(false);
        editUnityContentModel.setScaleX(1);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleZ(2);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setRotationX(1);
        editUnityContentModel.setRotationY(2);
        editUnityContentModel.setRotationZ(2);
        editUnityContentModel.setPositionX(2);
        editUnityContentModel.setPositionY(3);
        editUnityContentModel.setPositionZ(3);
        editUnityContentModel.setAndroidUrl("sthUrl android");
        editUnityContentModel.setIosUrl("sthUrl ios");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockUnity));
        Mockito.when(mockUnity.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editUnityContent(Mockito.any(UnityContent.class), Mockito.any(EditUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/unity/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editUnityContent_ContentNull() throws Exception {
        EditUnityContentModel editUnityContentModel = new EditUnityContentModel();
        editUnityContentModel.setName("newMovie name");
        editUnityContentModel.setWeight(1);
        editUnityContentModel.setType("type");
        editUnityContentModel.setRenderOnTrackingLost(true);
        editUnityContentModel.setExtendedTracking(false);
        editUnityContentModel.setScaleX(1);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleZ(2);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setRotationX(1);
        editUnityContentModel.setRotationY(2);
        editUnityContentModel.setRotationZ(2);
        editUnityContentModel.setPositionX(2);
        editUnityContentModel.setPositionY(3);
        editUnityContentModel.setPositionZ(3);
        editUnityContentModel.setAndroidUrl("sthUrl android");
        editUnityContentModel.setIosUrl("sthUrl ios");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockUnity.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editUnityContent(Mockito.any(UnityContent.class), Mockito.any(EditUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/unity/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());

    }

    @Test
    public void editUnityContentUserNotEqual() throws Exception {
        EditUnityContentModel editUnityContentModel = new EditUnityContentModel();
        editUnityContentModel.setName("newMovie name");
        editUnityContentModel.setWeight(1);
        editUnityContentModel.setType("type");
        editUnityContentModel.setRenderOnTrackingLost(true);
        editUnityContentModel.setExtendedTracking(false);
        editUnityContentModel.setScaleX(1);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleX(2);
        editUnityContentModel.setScaleZ(2);
        editUnityContentModel.setScaleY(1);
        editUnityContentModel.setRotationX(1);
        editUnityContentModel.setRotationY(2);
        editUnityContentModel.setRotationZ(2);
        editUnityContentModel.setPositionX(2);
        editUnityContentModel.setPositionY(3);
        editUnityContentModel.setPositionZ(3);
        editUnityContentModel.setAndroidUrl("sthUrl android");
        editUnityContentModel.setIosUrl("sthUrl ios");

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockUnity));
        Mockito.when(mockUnity.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.editUnityContent(Mockito.any(UnityContent.class), Mockito.any(EditUnityContentModel.class))).thenReturn(mockUnity);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/unity/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editUnityContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }


    @Test
    public void editSlideshowContent() throws Exception {
        EditSlideshowContentModel  editSlideshowContentModel = new EditSlideshowContentModel();
        editSlideshowContentModel.setName("newMovie name");
        editSlideshowContentModel.setWeight(1);
        editSlideshowContentModel.setType("type");
        editSlideshowContentModel.setRenderOnTrackingLost(true);
        editSlideshowContentModel.setExtendedTracking(false);
        editSlideshowContentModel.setScaleX(1);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleZ(2);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setRotationX(1);
        editSlideshowContentModel.setRotationY(2);
        editSlideshowContentModel.setRotationZ(2);
        editSlideshowContentModel.setPositionX(2);
        editSlideshowContentModel.setPositionY(3);
        editSlideshowContentModel.setPositionZ(3);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockSlideshowContent));
        Mockito.when(mockSlideshowContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(mockSlideshowContent.getType()).thenReturn(SlideshowContent.Type.NORMAL);
        Mockito.when(contentService.editSlideshowContent(Mockito.any(SlideshowContent.class), Mockito.any(EditSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/slideshow/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void editSlideshowContent_ContentNull() throws Exception {
        EditSlideshowContentModel editSlideshowContentModel = new EditSlideshowContentModel();
        editSlideshowContentModel.setName("newMovie name");
        editSlideshowContentModel.setWeight(1);
        editSlideshowContentModel.setType("type");
        editSlideshowContentModel.setRenderOnTrackingLost(true);
        editSlideshowContentModel.setExtendedTracking(false);
        editSlideshowContentModel.setScaleX(1);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleZ(2);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setRotationX(1);
        editSlideshowContentModel.setRotationY(2);
        editSlideshowContentModel.setRotationZ(2);
        editSlideshowContentModel.setPositionX(2);
        editSlideshowContentModel.setPositionY(3);
        editSlideshowContentModel.setPositionZ(3);
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.empty());
        Mockito.when(mockSlideshowContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(contentService.editSlideshowContent(Mockito.any(SlideshowContent.class), Mockito.any(EditSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/slideshow/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void editSlideshowContent_UserNotEqual() throws Exception {
        EditSlideshowContentModel editSlideshowContentModel = new EditSlideshowContentModel();
        editSlideshowContentModel.setName("newMovie name");
        editSlideshowContentModel.setWeight(1);
        editSlideshowContentModel.setType("type");
        editSlideshowContentModel.setRenderOnTrackingLost(true);
        editSlideshowContentModel.setExtendedTracking(false);
        editSlideshowContentModel.setScaleX(1);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleZ(2);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setRotationX(1);
        editSlideshowContentModel.setRotationY(2);
        editSlideshowContentModel.setRotationZ(2);
        editSlideshowContentModel.setPositionX(2);
        editSlideshowContentModel.setPositionY(3);
        editSlideshowContentModel.setPositionZ(3);

        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(contentService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockSlideshowContent));
        Mockito.when(mockSlideshowContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user1);
        Mockito.when(contentService.editSlideshowContent(Mockito.any(SlideshowContent.class), Mockito.any(EditSlideshowContentModel.class))).thenReturn(mockSlideshowContent);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign/slideshow/" + 1)
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(editSlideshowContentModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveImageUp() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(mockSlideshowImage.getSlideshow()).thenReturn(mockSlideshowContent);
        Mockito.when(mockSlideshowContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(slideshowImageService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockSlideshowImage));
        Mockito.when(mockSlideshowContent.getType()).thenReturn(SlideshowContent.Type.NORMAL);
        Mockito.when(slideshowImageService.moveDown(Mockito.any(SlideshowImage.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/slideshow/image/" + 2 + "/up")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void moveImageUpImageNull() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(slideshowImageService.moveUp(Mockito.any(SlideshowImage.class))).thenReturn(true);
        doThrow(new ForbiddenException()).when(slideshowImageService).getById(Mockito.anyLong());

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/slideshow/image/" + 1 + "/up")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

    @Test
    public void moveImageDown() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(mockSlideshowImage.getSlideshow()).thenReturn(mockSlideshowContent);
        Mockito.when(mockSlideshowContent.getCampaign()).thenReturn(mockCampaign);
        Mockito.when(mockCampaign.getUser()).thenReturn(user);
        Mockito.when(slideshowImageService.getById(Mockito.anyLong())).thenReturn(Optional.of(mockSlideshowImage));
        Mockito.when(mockSlideshowContent.getType()).thenReturn(SlideshowContent.Type.NORMAL);
        Mockito.when(slideshowImageService.moveDown(Mockito.any(SlideshowImage.class))).thenReturn(true);

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/slideshow/image/" + 2 + "/down")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());
    }

    @Test
    public void moveImageDownImageNull() throws Exception {
        Mockito.when(authenticationFacade.getAuthenticatedUser()).thenReturn(user);
        Mockito.when(slideshowImageService.moveDown(Mockito.any(SlideshowImage.class))).thenReturn(true);
        doThrow(new ForbiddenException()).when(slideshowImageService).getById(Mockito.anyLong());

        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/slideshow/image/" + 1 + "/down")
                .accept(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.FORBIDDEN.value(), response.getStatus());
    }

}
