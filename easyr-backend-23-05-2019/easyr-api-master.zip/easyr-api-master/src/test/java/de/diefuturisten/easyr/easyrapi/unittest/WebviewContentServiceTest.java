package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.service.WebviewContentService;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.model.request.CreateWebviewContentModel;

public class WebviewContentServiceTest {
    private Content content;
    private Campaign campaign;
    private ContentRepository contentRepository;
    private WebviewContentService webviewContentService;
    private WebviewContent webviewContent;

    @Before
    public void setUp() {
        campaign = mock(Campaign.class);
        contentRepository = mock(ContentRepository.class);
        content = mock(Content.class);
        webviewContent = mock(WebviewContent.class);
        webviewContentService = new WebviewContentService(contentRepository);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("http://example.com/");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent.class))).thenReturn(webviewContent);
        assertNotNull(webviewContentService.create(campaign, createWebviewContentModel));
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("http://example.com/");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent.class))).thenReturn(webviewContent);
        assertNotNull(webviewContentService.create(campaign, createWebviewContentModel));
    }

    @Test
    public void edit() {
        CreateWebviewContentModel createWebviewContentModel = new CreateWebviewContentModel();
        createWebviewContentModel.setUrl("http://example.com/");
        createWebviewContentModel.setName("webview name");
        createWebviewContentModel.setWeight(1);

        Mockito.when(contentRepository.save(Mockito.any(WebviewContent.class))).thenReturn(webviewContent);
        assertNotNull(webviewContentService.edit(webviewContent, createWebviewContentModel));
    }
}
