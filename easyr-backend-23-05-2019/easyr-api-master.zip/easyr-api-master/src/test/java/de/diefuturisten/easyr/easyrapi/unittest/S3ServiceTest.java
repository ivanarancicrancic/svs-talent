package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.UploadRepository;
import com.amazonaws.services.s3.AmazonS3;
import de.diefuturisten.easyr.easyrapi.service.S3Service;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import de.diefuturisten.easyr.easyrapi.entity.content.Upload;
import java.net.URL;
import java.io.File;
import com.amazonaws.services.s3.model.DeleteObjectRequest;

public class S3ServiceTest {
    private AmazonS3 s3client;
    private UploadRepository uploadRepository;
    private S3Service s3Service;
    private User user;
    private Upload upload;
    private String s3Region = "Region";
    private String bucketName = "Name";

    @Before
    public void setUp() {
        uploadRepository = mock(UploadRepository.class);
        s3client = mock(AmazonS3.class);
        user = mock(User.class);
        upload = mock(Upload.class);
        s3Service = new S3Service(s3client, uploadRepository);
    }

    @Test
    public void signUploadRequest() throws java.net.MalformedURLException {
        URL url= new URL("https://mattermost.build.app-logik.de/app-logik/channels/easyr");
        Mockito.when(s3client.generatePresignedUrl(Mockito.any(GeneratePresignedUrlRequest.class))).thenReturn(url);
        Mockito.when(uploadRepository.save(Mockito.any(Upload.class))).thenReturn(upload);
        assertNotNull(s3Service.signUploadRequest(user, "Name"));
    }

    @Test
    public void getTrackerUploadPath(){
        assertNotNull(s3Service.getTrackerUploadPath("5636447757"));
    }

    @Test
    public void uploadTracker(){
        File file = new File("src/test/resources/Rotating_earth.gif");
        assertNotNull(s3Service.uploadTracker("3544646757", file));
    }

    @Test
    public void deleteTracker(){
        doNothing().when(s3client).deleteObject(Mockito.any(DeleteObjectRequest.class));
        s3Service.deleteTracker("53435436464");
    }
}
