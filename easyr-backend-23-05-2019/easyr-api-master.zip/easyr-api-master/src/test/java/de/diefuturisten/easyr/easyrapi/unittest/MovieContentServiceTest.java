package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import de.diefuturisten.easyr.easyrapi.model.request.CreateMovieContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditMovieContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import java.util.Optional;

public class MovieContentServiceTest {

    private ContentRepository contentRepository;
    private Campaign campaign;
    private Content content;
    private MovieContentService movieContentService;
    private MovieContent movieContent;

    @Before
    public void setUp() {
        contentRepository = mock(ContentRepository.class);
        campaign = mock(Campaign.class);
        content = mock(Content.class);
        movieContent = mock(MovieContent.class);
        movieContentService = new MovieContentService(contentRepository);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("blahsth");
        createMovieContentModel.setName("name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("NORMAL");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);
        createMovieContentModel.setSubType("NORMAL");

        org.mockito.Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(org.mockito.Mockito.any(Campaign.class))).thenReturn(java.util.Optional.of(content));
        org.mockito.Mockito.when(contentRepository.save(org.mockito.Mockito.any(MovieContent.class))).thenReturn(movieContent);

        movieContentService.create(campaign, createMovieContentModel);
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreateMovieContentModel createMovieContentModel = new CreateMovieContentModel();
        createMovieContentModel.setUrl("blahsth");
        createMovieContentModel.setName("webview name");
        createMovieContentModel.setWeight(1);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setType("type");
        createMovieContentModel.setId(1L);
        createMovieContentModel.setExtendedTracking(true);
        createMovieContentModel.setRenderOnTrackingLost(true);
        createMovieContentModel.setPositionX(1);
        createMovieContentModel.setPositionY(2);
        createMovieContentModel.setPositionZ(3);
        createMovieContentModel.setRotationX(1);
        createMovieContentModel.setRotationY(2);
        createMovieContentModel.setRotationZ(3);
        createMovieContentModel.setScaleX(1);
        createMovieContentModel.setScaleY(2);
        createMovieContentModel.setScaleZ(3);
        createMovieContentModel.setSubType("NORMAL");

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(MovieContent.class))).thenReturn(movieContent);

        assertNotNull(movieContentService.create(campaign, createMovieContentModel));
    }

    @Test
    public void edit(){
        EditMovieContentModel editMovieContentModel = new EditMovieContentModel();
        editMovieContentModel.setUrl("blahsth");
        editMovieContentModel.setName("newMovie name");
        editMovieContentModel.setWeight(1);
        editMovieContentModel.setRenderOnTrackingLost(true);
        editMovieContentModel.setType("type");

       Mockito.when(contentRepository.save(Mockito.any(de.diefuturisten.easyr.easyrapi.entity.content.MovieContent.class))).thenReturn(movieContent);
       assertNotNull(movieContentService.edit(movieContent, editMovieContentModel));

    }

}
