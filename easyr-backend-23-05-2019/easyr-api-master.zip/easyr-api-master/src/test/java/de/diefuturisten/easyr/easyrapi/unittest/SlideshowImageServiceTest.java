package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import java.util.List;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowImageRepository;

public class SlideshowImageServiceTest {
    private SlideshowContent slideshowContent;
    private SlideshowImageService slideshowImageService;
    private SlideshowImage slideshowImage1;
    private SlideshowImage slideshowImage2;
    private SlideshowContentRepository slideshowContentRepository;
    private SlideshowImageRepository slideshowImageRepository;

    @Before
    public void setUp() {
        slideshowContent = mock(SlideshowContent.class);
        slideshowImage1 = mock(SlideshowImage.class);
        slideshowImage2 = mock(SlideshowImage.class);
        slideshowContentRepository = mock(SlideshowContentRepository.class);
        slideshowImageRepository = mock(SlideshowImageRepository.class);
        slideshowImageService = new SlideshowImageService(slideshowImageRepository, slideshowContentRepository);
    }

    @Test
    public void getById(){
        Mockito.when(slideshowImageRepository.findById(Mockito.anyLong())).thenReturn(java.util.Optional.of(slideshowImage1));
        assertNotNull(slideshowImageService.getById(1L));
    }

    @Test
    public void create_contentWithHeighestWeightIsPresent(){
        CreateSlideshowImageModel createSlideshowImageModel1 = new CreateSlideshowImageModel();
        createSlideshowImageModel1.setId(1L);
        createSlideshowImageModel1.setUrl("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        createSlideshowImageModel1.setWeight(1);
        createSlideshowImageModel1.setName("name");
        createSlideshowImageModel1.setType("NORMAL");

        Mockito.when(slideshowContentRepository.findById(Mockito.anyLong())).thenReturn(java.util.Optional.of(slideshowContent));
        Mockito.when(slideshowImageRepository.findFirstBySlideshowOrderByWeightDesc(Mockito.any(SlideshowContent.class))).thenReturn(java.util.Optional.of(slideshowImage1));
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertNotNull(slideshowImageService.create(1L, createSlideshowImageModel1));
    }

    @Test
    public void create_contentWithHeighestWeightNotPresent(){
        CreateSlideshowImageModel createSlideshowImageModel1 = new CreateSlideshowImageModel();
        createSlideshowImageModel1.setId(1L);
        createSlideshowImageModel1.setUrl("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        createSlideshowImageModel1.setWeight(1);
        createSlideshowImageModel1.setName("name");
        createSlideshowImageModel1.setType("NORMAL");

        Mockito.when(slideshowContentRepository.findById(Mockito.anyLong())).thenReturn(java.util.Optional.of(slideshowContent));
        Mockito.when(slideshowImageRepository.findFirstBySlideshowOrderByWeightDesc(Mockito.any(SlideshowContent.class))).thenReturn(java.util.Optional.empty());
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertNotNull(slideshowImageService.create(1L, createSlideshowImageModel1));
    }

    @Test
    public void delete_byId() {
        Mockito.when(slideshowImageRepository.findById(Mockito.anyLong())).thenReturn(java.util.Optional.of(slideshowImage1));
        doNothing().when(slideshowImageRepository).delete(Mockito.any(SlideshowImage.class));
        assertNotNull(slideshowImageService.delete(1L));
    }

    @Test
    public void delete_byImage() {
        doNothing().when(slideshowImageRepository).delete(Mockito.any(SlideshowImage.class));
        slideshowImageService.delete(slideshowImage1);
    }

    @Test
    public void delete_imagesList() {
        List<SlideshowImage> slideshowImageList = new ArrayList<>();
        slideshowImageList.add(slideshowImage1);
        slideshowImageList.add(slideshowImage2);
        doNothing().when(slideshowImageRepository).deleteAll(Mockito.anyList());
        slideshowImageService.delete(slideshowImageList);
    }

    @Test
    public void edit() {
        CreateSlideshowImageModel createSlideshowImageModel = new CreateSlideshowImageModel();
        createSlideshowImageModel.setName("image name");
        createSlideshowImageModel.setWeight(1);
        createSlideshowImageModel.setType("NORMAL");
        createSlideshowImageModel.setUrl("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");

        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertNotNull(slideshowImageService.edit(slideshowImage1, createSlideshowImageModel));
    }

    @Test
    public void moveUp_currentWeightEqual1() {
        Mockito.when(slideshowImage1.getWeight()).thenReturn(1);
        assertFalse(slideshowImageService.moveUp(slideshowImage1));
    }

    @Test
    public void moveUp_contentAtDesiredWeightOptNotPresent() {

        Mockito.when(slideshowImage1.getWeight()).thenReturn(2);
        Mockito.when(slideshowImageRepository.findFirstBySlideshowAndWeight(Mockito.any(SlideshowContent.class), Mockito.anyInt())).thenReturn(java.util.Optional.empty());
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertTrue(slideshowImageService.moveUp(slideshowImage1));
    }

    @Test
    public void moveUp_contentAtDesiredWeightOptPresent() {

        Mockito.when(slideshowImage1.getWeight()).thenReturn(2);
        Mockito.when(slideshowImageRepository.findFirstBySlideshowAndWeight(Mockito.any(SlideshowContent.class), Mockito.anyInt())).thenReturn(java.util.Optional.of(slideshowImage1));
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertTrue(slideshowImageService.moveUp(slideshowImage1));
    }

    @Test
    public void moveDown_contentAtDesiredWeightOptIsPresent() {
        Mockito.when(slideshowImage1.getWeight()).thenReturn(1);
        Mockito.when(slideshowImage1.getSlideshow()).thenReturn(slideshowContent);
        Mockito.when(slideshowImageRepository.findFirstBySlideshowAndWeight(Mockito.any(SlideshowContent.class), Mockito.anyInt())).thenReturn(java.util.Optional.of(slideshowImage1));
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertTrue(slideshowImageService.moveDown(slideshowImage1));
    }

    @Test
    public void moveDown_contentAtDesiredWeightOptNotPresent() {
        Mockito.when(slideshowImage1.getWeight()).thenReturn(1);
        Mockito.when(slideshowImage1.getSlideshow()).thenReturn(slideshowContent);
        Mockito.when(slideshowImageRepository.findFirstBySlideshowAndWeight(Mockito.any(SlideshowContent.class), Mockito.anyInt())).thenReturn(java.util.Optional.empty());
        Mockito.when(slideshowImageRepository.save(Mockito.any(SlideshowImage.class))).thenReturn(slideshowImage1);
        assertFalse(slideshowImageService.moveDown(slideshowImage1));
    }

}
