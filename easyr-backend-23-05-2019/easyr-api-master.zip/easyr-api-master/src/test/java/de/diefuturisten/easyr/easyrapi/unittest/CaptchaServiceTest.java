package de.diefuturisten.easyr.easyrapi.unittest;

public class CaptchaServiceTest {

}
