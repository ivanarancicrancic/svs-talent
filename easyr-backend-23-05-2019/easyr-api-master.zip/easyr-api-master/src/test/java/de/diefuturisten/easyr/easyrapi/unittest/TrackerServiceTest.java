package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import de.diefuturisten.easyr.easyrapi.service.VuforiaService;
import de.diefuturisten.easyr.easyrapi.service.S3Service;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.exceptions.InvalidTrackerImageException;
import java.io.File;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import java.util.Optional;

public class TrackerServiceTest {
    private Campaign campaign;
    private TrackerRepository trackerRepository;
    private VuforiaService vuforiaService;
    private S3Service s3Service;
    private Tracker tracker;
    private TrackerService trackerService;

    @Before
    public void setUp() {
        trackerRepository = mock(TrackerRepository.class);
        vuforiaService = mock(VuforiaService.class);
        s3Service = mock(S3Service.class);
        campaign = mock(Campaign.class);
        tracker = mock(Tracker.class);
        trackerService = new TrackerService(trackerRepository, vuforiaService, s3Service);
    }

    @Test
    public void createTrackerForCampaign() throws InvalidTrackerImageException {
        File file1 = new File("src/test/resources/Rotating_earth.gif");
        Mockito.when(vuforiaService.postTarget(Mockito.anyString(), Mockito.any(File.class), Mockito.any())).thenReturn("1L");
        Mockito.when(s3Service.uploadTracker(Mockito.anyString(), Mockito.any(File.class))).thenReturn("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        Mockito.when(trackerRepository.save(tracker)).thenReturn(tracker);
        assertNotNull(trackerService.createTrackerForCampaign(campaign, file1));
    }

    @Test(expected = RuntimeException.class)
    public void createTrackerForCampaign_InvalidTrackerImageException() throws RuntimeException, InvalidTrackerImageException {
        File file1 = new File("src/test/resources/Rotating_earth.gif");
        Mockito.doThrow(new InvalidTrackerImageException()).when(vuforiaService).postTarget(Mockito.anyString(), Mockito.any(File.class), Mockito.any());
        Mockito.when(s3Service.uploadTracker(Mockito.anyString(), Mockito.any(File.class))).thenReturn("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        Mockito.when(trackerRepository.save(tracker)).thenReturn(tracker);
        trackerService.createTrackerForCampaign(campaign, file1);
    }

    @Test
    public void editTrackerResultTrue() {
        File file = new File("src/test/resources/boat.jpg");
        Mockito.when(tracker.getVuforiaId()).thenReturn("1L");
        Mockito.when(vuforiaService.updateTarget(Mockito.anyString(), Mockito.any(File.class))).thenReturn(true);
        Mockito.when(s3Service.uploadTracker(Mockito.anyString(), Mockito.any(File.class))).thenReturn("src/test/resources/boat.jpg");
        Mockito.when(trackerRepository.save(Mockito.any(Tracker.class))).thenReturn(tracker);
        assertNotNull(trackerService.editTracker(tracker, file));
    }

    @Test
    public void editTrackerResultFalse() {
        File file = new File("src/test/resources/boat.jpg");
        Mockito.when(tracker.getVuforiaId()).thenReturn("1L");
        Mockito.when(vuforiaService.updateTarget(Mockito.anyString(), Mockito.any(File.class))).thenReturn(false);
        Mockito.when(s3Service.uploadTracker(Mockito.anyString(), Mockito.any(File.class))).thenReturn("src/test/resources/boat.jpg");
        Mockito.when(trackerRepository.save(Mockito.any(Tracker.class))).thenReturn(tracker);
        assertNull(trackerService.editTracker(tracker, file));
    }

    @Test
    public void getTrackerByVuforiaId() {
        Mockito.when(trackerRepository.findByVuforiaId(Mockito.anyString())).thenReturn(Optional.of(tracker));
         assertNotNull(trackerService.getTrackerByVuforiaId("5346575733GG"));
    }

    @Test
    public void getTrackerById() {
        Mockito.when(trackerRepository.findById(Mockito.anyLong())).thenReturn(Optional.of(tracker));
        assertNotNull(trackerRepository.findById(5733L));
    }

    @Test
    public void deleteTracker_resultFalse() {
        Mockito.when(vuforiaService.deleteTarget(Mockito.anyString())).thenReturn(false);
        assertFalse(trackerService.deleteTracker(tracker));
    }

    @Test
    public void deleteTracker_resultTrue() {
        Mockito.when(vuforiaService.deleteTarget(Mockito.anyString())).thenReturn(true);
        Mockito.when(tracker.getVuforiaId()).thenReturn("738355634869");
        Mockito.doNothing().when(s3Service).deleteTracker(Mockito.anyString());
        Mockito.doNothing().when(trackerRepository).delete(tracker);
        assertTrue(trackerService.deleteTracker(tracker));
    }

    @Test
    public void incrementTrackings() {
        Mockito.when(tracker.getTrackings()).thenReturn(new Long(3));
        Mockito.when(trackerRepository.save(Mockito.any(Tracker.class))).thenReturn(tracker);
        assertNotNull(trackerService.incrementTrackings(tracker));
    }
}
