package de.diefuturisten.easyr.easyrapi.unittest;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.Test;
import org.mockito.Mockito;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.repository.ContentRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.service.SlideshowImageService;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditSlideshowContentModel;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import java.util.List;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.model.request.CreateSlideshowImageModel;

public class SlideshowContentServiceTest {
    private Content content;
    private Campaign campaign;
    private ContentRepository contentRepository;
    private SlideshowContentService slideshowContentService;
    private SlideshowContent slideshowContent;
    private SlideshowImageService slideshowImageService;
    private SlideshowImage slideshowImage1;
    private SlideshowImage slideshowImage2;

    @Before
    public void setUp() {
        campaign = mock(Campaign.class);
        contentRepository = mock(ContentRepository.class);
        content = mock(Content.class);
        slideshowContent = mock(SlideshowContent.class);
        slideshowImage1 = mock(SlideshowImage.class);
        slideshowImage2 = mock(SlideshowImage.class);
        slideshowImageService = mock(SlideshowImageService.class);
        slideshowContentService = new SlideshowContentService(contentRepository, slideshowImageService);
    }

    @Test
    public void create_contentWithHighestWeightPresent(){
        CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
        createSlideshowContentModel.setName("webview name");
        createSlideshowContentModel.setWeight(1);
        createSlideshowContentModel.setType("type");
        createSlideshowContentModel.setId(1L);
        createSlideshowContentModel.setExtendedTracking(true);
        createSlideshowContentModel.setPositionX(1);
        createSlideshowContentModel.setPositionY(2);
        createSlideshowContentModel.setPositionZ(3);
        createSlideshowContentModel.setRotationX(1);
        createSlideshowContentModel.setRotationY(2);
        createSlideshowContentModel.setRotationZ(3);
        createSlideshowContentModel.setScaleX(1);
        createSlideshowContentModel.setScaleY(2);
        createSlideshowContentModel.setScaleZ(3);
        createSlideshowContentModel.setRenderOnTrackingLost(true);
        createSlideshowContentModel.setSubType("NORMAL");

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.of(content));
        Mockito.when(contentRepository.save(Mockito.any(SlideshowContent.class))).thenReturn(slideshowContent);
        assertNotNull(slideshowContentService.create(campaign, createSlideshowContentModel));
    }

    @Test
    public void create_contentWithHighestWeightNotPresent(){
        CreateSlideshowContentModel createSlideshowContentModel = new CreateSlideshowContentModel();
        createSlideshowContentModel.setName("webview name");
        createSlideshowContentModel.setWeight(1);
        createSlideshowContentModel.setType("type");
        createSlideshowContentModel.setId(1L);
        createSlideshowContentModel.setExtendedTracking(true);
        createSlideshowContentModel.setPositionX(1);
        createSlideshowContentModel.setPositionY(2);
        createSlideshowContentModel.setPositionZ(3);
        createSlideshowContentModel.setRotationX(1);
        createSlideshowContentModel.setRotationY(2);
        createSlideshowContentModel.setRotationZ(3);
        createSlideshowContentModel.setScaleX(1);
        createSlideshowContentModel.setScaleY(2);
        createSlideshowContentModel.setScaleZ(3);
        createSlideshowContentModel.setRenderOnTrackingLost(true);
        createSlideshowContentModel.setSubType("NORMAL");

        Mockito.when(contentRepository.findFirstByCampaignOrderByWeightDesc(Mockito.any(Campaign.class))).thenReturn(java.util.Optional.empty());
        Mockito.when(contentRepository.save(Mockito.any(SlideshowContent.class))).thenReturn(slideshowContent);
        assertNotNull(slideshowContentService.create(campaign, createSlideshowContentModel));
    }

    @Test
    public void edit() {
        List<SlideshowImage> slideshowImageList = new ArrayList<>();
        slideshowImageList.add(slideshowImage1);
        slideshowImageList.add(slideshowImage2);

        EditSlideshowContentModel editSlideshowContentModel = new EditSlideshowContentModel();
        editSlideshowContentModel.setName("newMovie name");
        editSlideshowContentModel.setWeight(1);
        editSlideshowContentModel.setType("NORMAL");
        editSlideshowContentModel.setRenderOnTrackingLost(true);
        editSlideshowContentModel.setExtendedTracking(false);
        editSlideshowContentModel.setScaleX(1);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleX(2);
        editSlideshowContentModel.setScaleZ(2);
        editSlideshowContentModel.setScaleY(1);
        editSlideshowContentModel.setRotationX(1);
        editSlideshowContentModel.setRotationY(2);
        editSlideshowContentModel.setRotationZ(2);
        editSlideshowContentModel.setPositionX(2);
        editSlideshowContentModel.setPositionY(3);
        editSlideshowContentModel.setPositionZ(3);

        Mockito.when(slideshowContent.getImages()).thenReturn(slideshowImageList);
        doNothing().when(slideshowImageService).delete(Mockito.anyList());
        Mockito.when(contentRepository.save(Mockito.any(SlideshowContent.class))).thenReturn(slideshowContent);
        assertNotNull(slideshowContentService.edit(slideshowContent, editSlideshowContentModel));
    }


    @Test
    public void createImages() {
        CreateSlideshowImageModel createSlideshowImageModel1 = new CreateSlideshowImageModel();
        createSlideshowImageModel1.setId(1L);
        createSlideshowImageModel1.setUrl("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        createSlideshowImageModel1.setWeight(1);
        createSlideshowImageModel1.setName("name");
        createSlideshowImageModel1.setType("NORMAL");

        CreateSlideshowImageModel createSlideshowImageModel2 = new CreateSlideshowImageModel();
        createSlideshowImageModel2.setId(1L);
        createSlideshowImageModel2.setUrl("https://i.pinimg.com/236x/37/e7/51/37e751e12b23033e3cd65e857e8b6cb7--sharpei-dog-shar-pei.jpg");
        createSlideshowImageModel2.setWeight(1);
        createSlideshowImageModel2.setName("name");
        createSlideshowImageModel2.setType("NORMAL");

        List<CreateSlideshowImageModel> createSlideshowImageModelList = new ArrayList<>();
        createSlideshowImageModelList.add(createSlideshowImageModel1);
        createSlideshowImageModelList.add(createSlideshowImageModel2);

        assertNotNull(slideshowContentService.createImages(slideshowContent, createSlideshowImageModelList));
    }
}
