import * as React from 'react';
import './LandingPage.css';
import easyIR from '../../assets/images/easyIR.png';


export default class Products extends React.Component{

  
    public render() {
        return (
            <div className="products pageBox">
                <span className="bp3-icon-standard bp3-icon-menu burger-menu" />
                <div className="desktop">
                    <div className="NW"> <div className="centered">
                        <img src={easyIR} />
                        <button><span className="bp3-icon-standard bp3-icon-play" /></button>
                    </div> </div>
                    <div className="NE"> <div className="centered"> 
                        <h4> Virtueller Messekatalog </h4>
                        <button><span className="bp3-icon-standard bp3-icon-play" /></button>
                    </div> </div>
                    <div className="SW"> <div className="centered"> 
                        <img src={easyIR} />
                        <button>Preise</button>
                    </div> </div>
                    <div className="SE"> <div className="centered">
                        <h4> Virtueller Messekatalog </h4>
                        <button>Preise</button>
                    </div> </div>
                </div>

                <div className="mobile">
                    <h5> EasyIR </h5>
                    <button><span className="bp3-icon-standard bp3-icon-play" /></button>
                    <button>Preise</button>
                    <hr />
                    <h5> Virtueller Messekatalog  </h5>
                    <button><span className="bp3-icon-standard bp3-icon-play" /></button>
                    <button>Preise</button>
                    <hr />
                </div>

                <div className="centered">
                    <p> DIE<span>_</span>FUTURISTEN </p>
                    <p> Produkte & Preise </p>
                </div>
                
            </div>
        )
    }
}  