import * as React from 'react';
import ReactDropzone from 'react-dropzone';
import * as request from "superagent";

export default class MainTracker extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            files: [],
            maxFiles: 1,
          };
    }

    public onDrop = (files:any) => {
        // POST to a test endpoint for demo purposes
        const req = request.post('https://httpbin.org/post');
        files.forEach((file:any) => {
          req.attach(file.name, file);
        });
    
        req.end();
    }
    
    public onPreviewDrop = (files:any) => {
        this.setState({
            files: this.state.files.concat(files),
            });
    }

    public render() {

        const previewStyle = {
            width: 200,
            height: 200,
          };

        return (
            <div className="trackerRight">             
                <ReactDropzone 
                        className="mainImg"
                        accept=".jpg, .png, image/*"
                        onDrop={this.onPreviewDrop}
                >
                <span className=" bp3-icon-standard bp3-icon-add" />
                    {this.state.files.map((file:any) => (
                        <img
                        alt="Preview"
                        key={file.preview}
                        src={file.preview}
                        style={previewStyle}
                        />
                    ))}
                </ReactDropzone>
                <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-edit" /> 
                </button>
            </div>
        )
    }
}