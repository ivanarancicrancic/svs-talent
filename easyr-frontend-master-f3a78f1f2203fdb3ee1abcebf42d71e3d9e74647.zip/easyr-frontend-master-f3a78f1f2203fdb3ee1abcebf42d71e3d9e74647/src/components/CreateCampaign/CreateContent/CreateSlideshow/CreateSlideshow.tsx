import * as React from 'react';
import '../../CreateCampaign.css'
import { Form, Control, Errors } from 'react-redux-form';
import { Tooltip, Position } from '@blueprintjs/core';

export default class CreateSlideshow extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }

      public onSubmit(values:any) {
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        alert('Campaign is created')
      }
    
    public render() {
        return (
            <div className="createBox">
                <Form
                    model="forms.slideshow"
                    method="post"
                    onSubmit={ (slideshow) => this.onSubmit(slideshow) }
                    validators={{
                        name: { required: (val:any) => val && val.length },
                        img01: { required: (val:any) => val && val.length },
                        img02: { required: (val:any) => val && val.length },
                        img03: { required: (val:any) => val && val.length },
                        positionx: { required: (val:any) => val && val.length },
                        positiony: { required: (val:any) => val && val.length },
                        positionz: { required: (val:any) => val && val.length },
                        rotationx: { required: (val:any) => val && val.length },
                        rotationy: { required: (val:any) => val && val.length },
                        rotationz: { required: (val:any) => val && val.length },
                        scalex: { required: (val:any) => val && val.length },
                        scaley: { required: (val:any) => val && val.length },
                        scalez: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                >
                    <div className="bp3-input-group">
                        <label htmlFor="name" className="bp3-file-input">Name</label>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'This field is required',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                        <label className="bp3-file-input">
                            <Control.file
                                model=".img01" name="img01" 
                            />
                          <span className="bp3-file-upload-input">Select image...</span>
                        </label>
                        <Errors
                            model=".img01"
                            messages={{
                                required: 'Please select a file',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                        <label className="bp3-file-input">
                            <Control.file
                                model=".img02" name="img02" 
                            />
                          <span className="bp3-file-upload-input">Select image...</span>
                        </label>
                        <Errors
                            model=".img02"
                            messages={{
                                required: 'Please select a file',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                        <label className="bp3-file-input">
                            <Control.file
                                model=".img03" name="img03" 
                            />
                          <span className="bp3-file-upload-input">Select image...</span>
                        </label>
                        <Errors
                            model=".img03"
                            messages={{
                                required: 'Please select a file',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="positions bp3-inline">
                        <label htmlFor="position" className="bp3-file-input">Position</label>
                        <div className="bp3-input-group bp3-inline">
                            <label htmlFor="position" className="bp3-file-input">x</label>
                            <Control.text
                                className="bp3-input"
                                model=".positionx"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">y</label>
                            <Control.text
                                className="bp3-input"
                                model=".positiony"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">z</label>
                            <Control.text
                                className="bp3-input"
                                model=".positionz"
                                defaultValue="0"
                            />
                        </div>
                    </div>
                    <div className="positions bp3-inline">
                        <label htmlFor="rotation" className="bp3-file-input">Rotation: </label>
                        <div className="bp3-input-group bp3-inline">
                            <label htmlFor="rotation" className="bp3-file-input">x</label>
                            <Control.text
                                className="bp3-input"
                                model=".rotationx"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">y</label>
                            <Control.text
                                className="bp3-input"
                                model=".rotationy"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">z</label>
                            <Control.text
                                className="bp3-input"
                                model=".rotationz"
                                defaultValue="0"
                            />
                        </div>
                    </div>
                    <div className="positions bp3-inline">
                        <label htmlFor="scale" className="bp3-file-input">Scale: </label>
                        <div className="bp3-input-group bp3-inline">
                            <label htmlFor="scale" className="bp3-file-input">x</label>
                            <Control.text
                                className="bp3-input"
                                model=".scalex"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">y</label>
                            <Control.text
                                className="bp3-input"
                                model=".scaley"
                                defaultValue="0"
                            />
                            <label htmlFor="name" className="bp3-file-input">z</label>
                            <Control.text
                                className="bp3-input"
                                model=".scalez"
                                defaultValue="0"
                            />
                        </div>
                    </div>

                    <div className="checkboxes bp3-inline">
                        <label>
                            <Control.checkbox model=".check01" /> Checkbox 01
                            <Tooltip content="Some info here!" position={Position.TOP}>
                                <span className="bp3-icon-standard bp3-icon-info-sign" />
                            </Tooltip>
                        </label>

                        <label>
                            <Control.checkbox model=".check02" /> Checkbox 02
                            <Tooltip content="Some info here!" position={Position.TOP}>
                                <span className="bp3-icon-standard bp3-icon-info-sign" />
                            </Tooltip>
                        </label>
                    </div>
                    <button className="bp3-button saveBtn"> <span className="bp3-icon-standard bp3-icon-tick-circle" /> </button>
                </Form>
            </div>
        )
    }
}