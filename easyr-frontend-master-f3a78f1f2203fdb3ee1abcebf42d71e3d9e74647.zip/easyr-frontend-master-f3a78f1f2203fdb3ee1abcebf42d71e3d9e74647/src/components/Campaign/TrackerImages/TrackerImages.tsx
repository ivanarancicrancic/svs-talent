import * as React from 'react';
import './TrackerImages.css';

import ReactDropzone from 'react-dropzone';
import * as request from "superagent";
import MainTracker from './MainTracker';

export default class TrackerImages extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            files: [],
            maxFiles: 1,
          };
    }

    public onDrop = (files:any) => {
        // POST to a test endpoint for demo purposes
        const req = request.post('https://httpbin.org/post');
        files.forEach((file:any) => {
          req.attach(file.name, file);
        });
    
        req.end();
    }
    
    public onPreviewDrop = (files:any) => {
        this.setState({
            files: this.state.files.concat(files),
            });
    }

    public render() {
        const previewStyle = {
            width: 100,
            height: 100,
          };

        return (
            <div className="trackerBox">
                <div className="trackerLeft">
                    <div>
                        {this.state.files.length > 0 &&
                        <div>
                            {this.state.files.map((file:any) => (
                        <div>
                            <img
                            alt="Preview"
                            key={file.preview}
                            src={file.preview}
                            style={previewStyle}
                            />
                         <button className="bp3-button bp3-minimal" > <span className="bp3-icon-standard bp3-icon-trash" /> </button>                           
                        </div>
                            ))}
                        </div>
                        }
                    </div>
                    <div className="bp3-button bp3-minimal" >
                        <label className="bp3-file-input .modifier addImg">
                            <ReactDropzone 
                                className="dropzone"
                                accept=".jpg, .png, image/*"
                                onDrop={this.onPreviewDrop}
                            >
                            <span className="bp3-file-upload-input bp3-icon-standard bp3-icon-add" />
                            </ReactDropzone>
                        </label>
                    </div>
                </div>
                <MainTracker /> 
            </div>
        )
    }

}