import * as React from 'react';
import './Slideshow.css';

export default class SlideshowConfig extends React.Component {

    public render() {
        return (
            <pre>
                <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
                    <tbody >
                        <tr>
                            <td><input type="file" name="pic" accept="image/*"/></td>
                            <td><img src="https://loremflickr.com/60/50" /></td>
                            <td><button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /></button></td>
                            <td><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                            <td><input type="file" name="pic" accept="image/*"/></td>
                            <td><img src="https://loremflickr.com/60/50" /></td>
                            <td><button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /></button></td>
                            <td><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                        <td><input type="file" name="pic" accept="image/*"/></td>
                            <td><img src="https://loremflickr.com/60/50" /></td>
                            <td><button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /></button></td>
                            <td><button className="bp3-button bp3-minimal"><span className="bp3-icon-standard bp3-icon-trash" /></button></td>
                        </tr>
                        <tr>
                            <td colSpan={5} className="text-center" >
                                <a className="bp3-button bp3-icon-add bp3-minimal"/>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </pre>
        )
    }

}