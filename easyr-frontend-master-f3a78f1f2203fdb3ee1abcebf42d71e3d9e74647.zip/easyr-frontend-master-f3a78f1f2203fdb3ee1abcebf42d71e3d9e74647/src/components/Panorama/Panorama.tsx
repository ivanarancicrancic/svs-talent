import * as React from 'react';

import { Button, Collapse  } from "@blueprintjs/core";
import PanoramaContent from './PanoramaContent';
import './Panorama.css';

export interface ICollapseExampleState {
    isOpen?: boolean;
};

export default class Panorama extends React.Component<{}, ICollapseExampleState> {

    public state = {
        isOpen: false,
    };

    public render():any {
        return (
            <div className="editBtn">
                 <div>
                <Button className="bp3-button bp3-minimal" onClick={this.handleClick}>
                <i className="fontello icon-edit" />
                </Button>
                <Collapse isOpen={this.state.isOpen}>
                    <div className="slideshow">
                    <PanoramaContent />
                    </div>
                    <button className="confirmBtn"> <span className="bp3-icon-standard bp3-icon-tick-circle" /> </button>
                </Collapse>
            </div>
            </div>
        )
    }

    private handleClick = () => {
        this.setState({ isOpen: !this.state.isOpen });
    }

}  