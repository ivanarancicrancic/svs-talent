import * as React from 'react';
import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import { LocalForm, Control, actions } from 'react-redux-form';

import { IWebviewContentResponseModel, IWebviewContentRequestModel } from '../../redux/campaign/types';
import { contentWebviewCreateFetch, contentWebviewEditFetch } from '../../redux/campaign/actions';

import './Forms.css';

interface IPropsStateMap {
    loading: boolean;
}

interface IPropsDispatchMap {
    contentWebviewCreateFetch: typeof contentWebviewCreateFetch;
    contentWebviewEditFetch: typeof contentWebviewEditFetch;
}

interface IDirectProps {
    token: string;
    content: IWebviewContentResponseModel | null;
    campaignId: number;
}

type IProps = IPropsDispatchMap & IPropsStateMap &  IDirectProps;

interface IState {
    touched: boolean;
}

interface IWebviewContentForm {
    url: string;
}

class WebviewContentForm extends React.Component<IProps, IState> {

    public formDispatch: any;

    constructor(props: IProps) {
        super(props);

        this.state = {
            touched: false
        }
    }

    public componentWillMount() {
        console.log("WebviewContentForm componentWillMount");
    }

    public componentDidUpdate(prevProps: IProps) {
        console.log("WebviewContentForm componentDidUpdate");
        if(this.props.content !== prevProps.content) {
            this.updateForm();
        }
    }

    public updateForm() {
        console.log("updateForm", this.props.content != null);
        if(this.props.content != null) {
            this.formDispatch(actions.change('local.url', this.props.content.url || ''));
            this.setState({touched: false});
        } else {
            this.formDispatch(actions.change('local.url', ''));
            this.setState({touched: false});
        }
    }

    public componentDidMount() {
        this.updateForm();
    }

    public onSubmit(values: IWebviewContentForm) {

        const newValues: IWebviewContentRequestModel = {
            id: this.props.content && this.props.content.id || undefined,
            url: values.url,
            name: "Webview"
        }

        if(this.props.content === null) {
            this.props.contentWebviewCreateFetch({
                campaignId: this.props.campaignId,
                data: newValues
            });
        } else {
            this.props.contentWebviewEditFetch({data: newValues});
        }

        console.log("onSubmit", this.props.content, newValues);

        this.formDispatch(actions.setUntouched('local'));
    }

    public attachDispatch(dispatch: any) {
        this.formDispatch = dispatch;
    }

    public render() {
        return (
            <div>
                <LocalForm
                    className={"formz1"}
                    onUpdate={(form) => {console.log("onUpdate", form); this.setState({touched: form.$form.touched}) }}
                    onChange={(values) => {console.log("onChange", values)}}
                    onSubmit={(values) => { this.onSubmit(values); }}
                    getDispatch={(dispatch) => this.attachDispatch(dispatch)}
                >
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, height: 45, backgroundColor: '#fdf2f0'}}>
                    <Control.text type="text" placeholder={"http://"} style={{paddingLeft: 5, width: 180, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249'}} name="url" model=".url" />
                    </div>
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', width: 190*3, height: 45, backgroundColor: '#fdf2f0'}} />
                </LocalForm>
                {this.state.touched && <div onClick={ () => { this.formDispatch(actions.submit('local')); } } style={{cursor: 'pointer', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', border: '2px solid #e51249', borderTop: '0px', backgroundColor: '#e51249', marginRight: 1, padding: 5}}>
                    <span style={{color: '#FFFFFF', fontSize: 11}}>Änderungen speichern</span>
                </div>}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    loading: state.campaign.contentLoading
});

export default connect(mapStateToProps, {contentWebviewCreateFetch, contentWebviewEditFetch})(WebviewContentForm);