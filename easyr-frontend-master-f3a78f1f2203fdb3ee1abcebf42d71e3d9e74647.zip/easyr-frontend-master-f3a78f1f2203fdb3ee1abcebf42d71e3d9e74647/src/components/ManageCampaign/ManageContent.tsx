import * as React from 'react';
import { connect } from 'react-redux';
import { IRootState } from '../../redux/index';
import { IContentResponseModel, IVideoContentResponseModel, IPanoramaContentResponseModel, IWebviewContentResponseModel, IAudioContentResponseModel, IUnityContentResponseModel, ISlideshowContentResponseModel, ISlideshowContentRequestModel, IMoreinfoContentResponseModel } from '../../redux/campaign/types';

import VideoContentForm from './VideoContentForm';

import videoContentIcon from '../../assets/images/video_content_icon.svg';
import greenscreenContentIcon from '../../assets/images/greenscreen_content_icon.svg';
import video360Icon from '../../assets/images/video360_content_icon.svg';
import threedIcon from '../../assets/images/3d_content_icon.svg';
import wheelIcon from '../../assets/images/wheel_content_icon.svg';
import panorama180Icon from '../../assets/images/180panorama_content_icon.svg';
import panorama360Icon from '../../assets/images/360panorama_content_icon.svg';
import sphereIcon from '../../assets/images/sphere_content_icon.svg';
import slideShowIcon from '../../assets/images/slideshow_content_icon.svg';
import webviewIcon from '../../assets/images/webview_content_icon.svg';
import audioIcon from '../../assets/images/audio_content_icon.svg';
import moreinfoIcon from '../../assets/images/moreinfo_content_icon.svg';

import bigPlusImg from '../../assets/images/big_plus.svg';
import { contentDeleteFetch, contentRenameFetch } from '../../redux/campaign/actions';
import PanoramaContentForm from './PanoramaContentForm';
import WebviewContentForm from './WebviewContentForm';
import AudioContentForm from './AudioContentForm';
import UnityContentForm from './UnityContentForm';
import SlideshowContentForm from './SlideshowContentForm';
import MoreInfoContentForm from './MoreInfoContentForm';

import { ContentTab } from './ContentTab';


interface IPropsDispatchMap {
    contentDeleteFetch: typeof contentDeleteFetch;
    contentRenameFetch: typeof contentRenameFetch;
}

interface IPropsStateMap {
    token: string;
}


interface IDirectProps {
    contents: IContentResponseModel[];
    campaignId: number;
}

type IProps = IPropsDispatchMap & IPropsStateMap & IDirectProps;

interface IState {
    selectedContentIndex: number | null;
    selectedContentType: number | null;
    manageNew: number | null;
    additionalContents: number;
}

class ManageContent extends React.Component<IProps, IState> {

    public contentToScroll: any;

    constructor(props: IProps) {
        super(props);
        this.state = {
            selectedContentIndex: null,
            selectedContentType: null,
            manageNew: null,
            additionalContents: 0
        }
    }

    public componentDidMount() {
        if(this.props.contents.length > 0) {
            this.setState({selectedContentIndex: this.state.selectedContentIndex || 0});
        } else {
            this.setState({selectedContentIndex: null, manageNew: 0});
        }
    }

    public componentDidUpdate(prevProps: IProps) {
        console.log("componentDidUpdate");
        if(this.props.contents !== prevProps.contents) {
            if(this.props.contents.length > 0) {
                this.setState({selectedContentIndex: this.state.selectedContentIndex != null ? this.state.selectedContentIndex : this.props.contents.length-1, manageNew: null});
            } else if(this.props.contents.length > this.props.contents.length) {
                this.setState({additionalContents: Math.max(0, this.state.additionalContents - 1)});
            } else {
                this.setState({selectedContentIndex: null, manageNew: 0});
            }
        }
    }

    public renderEmpty(emptyId: number) {
        return (
            <div
                key={`empty-${emptyId}`}
                onClick={ () => {
                    if(this.state.manageNew === emptyId) {
                        // this.setState({manageNew: null});
                    } else {
                        this.setState({manageNew: emptyId, selectedContentIndex: null})
                    }
                } }
                style={{
                    cursor: 'pointer',
                    display: 'flex',
                    flexShrink: 0,
                    alignItems: 'center',
                    borderRight: this.props.contents.length < 3 ? '2px solid #e51349' : undefined,
                    width: 188, height: 39,
                    backgroundColor: this.state.manageNew === emptyId ? '#e51349' : '#FFFFFF'}}
                >
                    <span style={{ paddingLeft: 13, paddingRight: 5, color: this.state.manageNew === emptyId ? '#FFFFFF' : '#e51349', fontSize: 13, fontWeight: 500}}>Inhalt {this.props.contents.length+emptyId+1}</span>
            </div>
        )
    }

    public renderNew() {
        return (
            <div
                key={'new'}
                onClick={ () => {
                    this.setState({additionalContents: this.state.additionalContents + 1}, () => {
                        this.contentToScroll.scrollIntoView({ behavior: "smooth" });
                    });
                } }
                style={{
                    cursor: 'pointer',
                    display: 'flex',
                    flexShrink: 0,
                    alignItems: 'center',
                    width: 188, height: 39,
                    backgroundColor: '#FFFFFF'}}
                >
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center'}}>
                        <img style={{marginLeft: 13, width: 15, height: 15}} src={bigPlusImg} />
                        <span style={{ paddingLeft: 13, paddingRight: 5, color: '#e51349', fontSize: 13, fontWeight: 500}}>zusätzlicher Inhalt</span>
                    </div>
            </div>
        )
    }

    public renderContents() {
        const contents = this.props.contents.map( (content, index) => {
           return (
           <ContentTab
                key={index}
                index={index}
                content={content}
                isSelected={this.state.selectedContentIndex === index}
                onSelect={() => { this.setState({selectedContentIndex: index, manageNew: null}) }}
                onDelete={() => {
                    this.setState({selectedContentIndex: null}, () => {
                        this.props.contentDeleteFetch({contentId: content.id});
                    });
                }}
                onRename={(name: string) => {
                    this.props.contentRenameFetch({contentId: content.id, name});
                }}
            />
           )
        })

        const emptyContentsToAdd = Math.max(0, (3 - this.props.contents.length));
        for(let i = 0 ; i < emptyContentsToAdd + this.state.additionalContents ; ++i) {
            contents.push(this.renderEmpty(i));
        }
        contents.push(<div key="dummy_content_end" ref={(el) => { this.contentToScroll = el; }} />)   
        // contents.push(this.renderNew());

        return contents;
    }
   
    public renderVideoContentForm(content: IVideoContentResponseModel | null) {
        return <VideoContentForm subtype="NORMAL" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderGreenscreenContentForm(content: IVideoContentResponseModel | null) {
        return <VideoContentForm subtype="GREENSCREEN" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderSphereContentForm(content: IVideoContentResponseModel | null) {
        return <VideoContentForm subtype="SPHERE" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public render180PanoramaContentForm(content: IPanoramaContentResponseModel | null) {
        return <PanoramaContentForm subtype="X180" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public render360PanoramaContentForm(content: IPanoramaContentResponseModel | null) {
        return <PanoramaContentForm subtype="X360" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderSpherePanoramaContentForm(content: IPanoramaContentResponseModel | null) {
        return <PanoramaContentForm subtype="SPHERE" campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderWebviewContentForm(content: IWebviewContentResponseModel | null) {
        return <WebviewContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderAudioContentForm(content: IAudioContentResponseModel | null) {
        return <AudioContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }
    
    public renderUnityContentForm(content: IUnityContentResponseModel | null) {
        return <UnityContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderSlideshowContentForm(content: ISlideshowContentRequestModel | null) {
        return <SlideshowContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} subType={"NORMAL"} />
    }

    public renderWheelContentForm(content: ISlideshowContentRequestModel | null) {
        return <SlideshowContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} subType={"WHEEL"} />
    }

    public renderMoreinfoContentForm(content: IMoreinfoContentResponseModel | null) {
        return <MoreInfoContentForm campaignId={this.props.campaignId} token={this.props.token} content={content} />
    }

    public renderContentEditArea() {
        if(this.state.selectedContentIndex == null) {
            if(this.state.selectedContentType != null) {
                switch(this.state.selectedContentType) {
                    case 0: return this.renderVideoContentForm(null);
                    case 1: return this.renderGreenscreenContentForm(null);
                    case 2: return this.renderSphereContentForm(null);
                    case 3: return this.renderUnityContentForm(null);
                    case 4: return this.renderWheelContentForm(null);
                    case 5: return this.render180PanoramaContentForm(null);
                    case 6: return this.render360PanoramaContentForm(null);
                    case 7: return this.renderSpherePanoramaContentForm(null);
                    case 8: return this.renderSlideshowContentForm(null);
                    case 9: return this.renderWebviewContentForm(null);
                    case 10: return this.renderAudioContentForm(null);
                    case 11: return this.renderMoreinfoContentForm(null);
                    default: return null;
                }
            } else {
                return null;
            }
        } else {
            const content = this.props.contents[this.state.selectedContentIndex];
            if(content != null) {
                switch(content.type) {
                    case "movie":
                        const movie = content as IVideoContentResponseModel;
                        switch(movie.subType) {
                            case "NORMAL": return this.renderVideoContentForm(movie);
                            case "GREENSCREEN": return this.renderGreenscreenContentForm(movie);
                            case "SPHERE": return this.renderSphereContentForm(movie);
                            default: this.renderVideoContentForm(movie);
                        }
                        return null;
                    case "panorama":
                        const panorama = content as IPanoramaContentResponseModel;
                        switch(panorama.subType) {
                            case "X180": return this.render180PanoramaContentForm(panorama);
                            case "X360": return this.render360PanoramaContentForm(panorama);
                            case "SPHERE": return this.renderSpherePanoramaContentForm(panorama);
                            default: this.render180PanoramaContentForm(panorama);
                        }
                        return null;
                    case "webview":
                        return this.renderWebviewContentForm(content as IWebviewContentResponseModel);
                    case "audio":
                        return this.renderAudioContentForm(content as IAudioContentResponseModel);
                    case "unity":
                        return this.renderUnityContentForm(content as IUnityContentResponseModel);
                    case "slideshow":
                        const slideshow = content as ISlideshowContentResponseModel;
                        switch(slideshow.subType) {
                            case "NORMAL": return this.renderSlideshowContentForm(content as ISlideshowContentResponseModel);
                            case "WHEEL": return this.renderWheelContentForm(content as ISlideshowContentResponseModel);
                            default: this.renderSlideshowContentForm(content as ISlideshowContentResponseModel);
                        }
                        return 
                    case "moreinfo":
                        return this.renderMoreinfoContentForm(content as IMoreinfoContentResponseModel);
                    default:
                        return null;
                }
            } else {
                // TODO: this should not happen
                return null;
            }
            
        }

    }

    public renderContentTypeSelection() {

        if(this.state.selectedContentIndex !== null) {
            return;
        }

        return (
            <div style={{position: 'relative', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderTop: '2px solid #e51349', width: 191*4, height: 47, overflowX: 'auto', overflowY: 'hidden', backgroundColor: '#fdf2f0'}}>
                <div onClick={ () => { this.setState({selectedContentType: 0}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 0 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 22, height: 36, marginLeft: 13, marginRight: 13}} src={videoContentIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 1}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 1 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 45, height: 36, marginLeft: 13, marginRight: 13}} src={greenscreenContentIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 2}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 2 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 35, height: 36, marginLeft: 13, marginRight: 13}} src={video360Icon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 3}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 3 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 23, height: 36, marginLeft: 13, marginRight: 13}} src={threedIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 4}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 4 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 26, height: 36, marginLeft: 13, marginRight: 13}} src={wheelIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 5}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 5 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 51, height: 36, marginLeft: 13, marginRight: 13}} src={panorama180Icon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 6}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 6 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 52, height: 36, marginLeft: 13, marginRight: 13}} src={panorama360Icon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 7}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 7 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 23, height: 36, marginLeft: 13, marginRight: 13}} src={sphereIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 8}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 8 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 37, height: 36, marginLeft: 13, marginRight: 13}} src={slideShowIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 9}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 9 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 29, height: 36, marginLeft: 13, marginRight: 13}} src={webviewIcon} />
                </div>

                <div onClick={ () => { this.setState({selectedContentType: 10}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 10 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 26, height: 36, marginLeft: 13, marginRight: 13}} src={audioIcon} />
                </div>

                {(this.props.contents.find( x => x.type === "moreinfo" ) === undefined) && <div onClick={ () => { this.setState({selectedContentType: 11}) } } style={{cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', height: 47, backgroundColor: this.state.selectedContentType === 11 ? '#FFFFFF' : undefined}}>
                    <img style={{width: 36, height: 36, marginLeft: 13, marginRight: 13}} src={moreinfoIcon} />
                </div>}
            </div>
        )
    }

    public render() {
        return (
            <div style={{position: 'relative', display: 'flex', flexDirection: 'column', border: '2px solid #e51349', width: 191*4, overflowX: 'hidden', overflowY: 'hidden', marginTop: 13}}>
                <div style={{display: 'flex', flexDirection: 'row', overflowX: 'hidden', overflowY: 'hidden'}}>
                    <div style={{position: 'relative', display: 'flex', flexDirection: 'row', width: 194*3, overflowX: 'auto', overflowY: 'hidden', boxSizing: 'content-box'}}>
                        {this.renderContents()}
                    </div>
                    {this.renderNew()}
                </div>
                {this.renderContentTypeSelection()}
                {this.renderContentEditArea()}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    token: state.auth.token && state.auth.token.token || ''
});

export default connect(mapStateToProps, {contentDeleteFetch, contentRenameFetch})(ManageContent);