import * as React from 'react';

import {NavLink} from "react-router-dom";
import {PATH_FAQ, PATH_IMPRINT, PATH_PRIVACY, PATH_ROOT, PATH_TERMS} from "../../router/paths";
import LanguageSelection from '../../translation/LanguageSelection';
import { Translate } from 'react-redux-i18n';

export default class PostAuthFooter extends React.Component {

    public render() {
        return (
            <div className="postFooter footer">
                <nav className="bp3-navbar">
                    <div className="footerNav">
                        <div className="bp3-navbar-group bp3-align-left">
                            <div className="bp3-navbar-heading">&copy; DIE_FUTURISTEN </div>
                        </div>
                        <div className="bp3-navbar-group">
                            <NavLink to={PATH_FAQ} className="bp3-navbar-heading"><Translate value="footer.faq" /></NavLink>
                            <NavLink to={PATH_ROOT} className="bp3-navbar-heading"><Translate value="footer.contact" /></NavLink>
                            <NavLink to={PATH_IMPRINT} className="bp3-navbar-heading"><Translate value="footer.impresum" /></NavLink>
                            <NavLink to={PATH_PRIVACY} className="bp3-navbar-heading"><Translate value="footer.privacy" /></NavLink>
                            <NavLink to={PATH_TERMS} className="bp3-navbar-heading"><Translate value="footer.terms" /></NavLink>
                        </div>
                        <div className="bp3-navbar-group bp3-align-right">
                            <LanguageSelection />
                            <div className="socialMedia">
                                <i className="fontello icon-instagram" />
                                <i className="fontello icon-twitter" />
                                <i className="fontello icon-facebook" />
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

}