import * as React from 'react';
import {Link, NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD} from "../../router/paths";

import './Header';
import { userSelfInfoFetch } from '../../redux/user-self-info/actions';
import { getUserSelfInfo } from '../../redux/user-self-info/selectors';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { IUserResponseModel } from '../../redux/user-self-info/types';
import {  Menu, MenuItem, Popover, Position } from "@blueprintjs/core";
import { loginLogout } from '../../redux/auth/actions';
import logoImg from '../../assets/images/logo.png';
import { campaignCreateFetch } from '../../redux/campaign/actions';

import { history } from '../../router';
import { IJWToken } from '../../redux/auth/types';
import { Translate } from 'react-redux-i18n';

import HamburgerMenu from './HamburgerMenu';

interface IPropsDispatchMap {
    userSelfInfoFetch: typeof userSelfInfoFetch;
    campaignCreateFetch: typeof campaignCreateFetch;
    loginLogout: typeof loginLogout;
}

interface IPropsStateMap {
    userInfo: IUserResponseModel | null;
    campaignCreating: boolean;
    lastCreatedId: number | null;
    token: IJWToken | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class PostAuthHeader extends React.Component<IProps> {

    public componentWillMount() {
        if(this.props.token != null) {
            this.props.userSelfInfoFetch();
        }
    }

    public renderUser() {

        if(this.props.userInfo == null) {
            return;
        }

        return <span className="userInfo"> 
                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">{this.props.userInfo.name} 
                    <i  className="fontello icon-user" />
                </NavLink></span>;
    }

    public componentWillReceiveProps(nextProps: IProps) {

        const campaignCreated = this.props.campaignCreating === true && nextProps.campaignCreating === false;
        if(campaignCreated) {
            history.push(`/campaign/${nextProps.lastCreatedId}`);
        }
    }

    public render() {
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_ROOT} className="bp3-navbar-heading"> <img src={logoImg} /> </Link>
                            </span>
                            <div className="headerBox">
                                <Link to={PATH_ROOT} className="bp3-navbar-heading"> <span> 1 >> </span><Translate value="header.account" /></Link>
                                <Link to={PATH_DASHBOARD} className="bp3-navbar-heading"> <span> 2 >> </span><Translate value="header.buy-campaign" /></Link>
                                {this.props.campaignCreating && <a className="bp3-navbar-heading" onClick={(e) => { e.preventDefault(); }}> <span> 3 >> </span><Translate value="header.create-campaign" /></a> || <a className="bp3-navbar-heading" onClick={(e) => { e.preventDefault(); if(this.props.token != null) { this.props.campaignCreateFetch() } }}> <span> 3 >> </span><Translate value="header.create-campaign" /></a>}
                                <Link to={PATH_DASHBOARD} className="bp3-navbar-heading"> <span> 4 >> </span><Translate value="header.administration" /></Link>
                                <Link to={PATH_DASHBOARD} className="bp3-navbar-heading"> <span> 5 >> </span><Translate value="header.statistics" /></Link>
                                <Link to={PATH_DASHBOARD} className="bp3-navbar-heading"> <span> 6 </span><Translate value="header.push" /></Link>
                                <div className="settings">
                                    <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span>
                                    {this.props.token && <Popover content={
                                        <Menu>
                                            <MenuItem text="Logout" className="bp3-icon-standard bp3-icon-log-out" onClick={this.onLogout} />
                                        </Menu>} 
                                        position={Position.BOTTOM}>
                                        <span className="bp3-icon-standard bp3-icon-cog" />
                                    </Popover>}
                                </div>                       
                                {this.props.token && this.renderUser()}
                            </div>
                                <div className="hamburgerMenu">
                                    <HamburgerMenu />
                                </div>
                        </div>
                    </div>
                </nav>
            </div>
        )
    }

    private onLogout = () => {
        this.props.loginLogout();
    }
}

const mapStateToProps = (state: IRootState) => ({
    userInfo: getUserSelfInfo(state),
    campaignCreating: state.campaign.createLoading,
    lastCreatedId: state.campaign.lastCreatedId,
    token: state.auth.token
});

export default connect(mapStateToProps, {userSelfInfoFetch, campaignCreateFetch, loginLogout, pure: false})(PostAuthHeader)