import * as React from 'react';

import { connect } from 'react-redux';
import {IRootState} from "../../redux";
import { registerFetch } from '../../redux/register/actions';
import { RouteComponentProps } from 'react-router';
import { Link } from 'react-router-dom';
import { PATH_ROOT } from '../../router/paths';

type IProps = RouteComponentProps<{}>;

class RegisterCompleteContainer extends React.Component<IProps> {

    public render() {
        return (
            <div>
                <h1>Welcome</h1>
                <p>Your account was created successfully. You can <Link to={PATH_ROOT}>Login</Link> now</p>
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
});

export default connect(mapStateToProps, {registerFetch})(RegisterCompleteContainer)