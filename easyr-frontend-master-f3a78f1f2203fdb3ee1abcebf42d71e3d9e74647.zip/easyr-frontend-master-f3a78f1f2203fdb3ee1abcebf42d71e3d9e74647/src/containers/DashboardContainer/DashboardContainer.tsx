import * as React from 'react';
import DashboardLayout from '../../components/Dashboard/DashboardLayout';


export default class DashboardContainer extends React.Component {

    public render():any {
        return (
            <div>
                <DashboardLayout />
            </div>
        )
    }
}