import * as React from 'react';
import { Translate } from 'react-redux-i18n';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';

import ReactS3Uploader from 'react-s3-uploader'
import { API_ROOT } from '../../router/api-config';

 class DashboardContainerExample extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            token: ""
        }
    }

    public render() {
        return (
            <div>
            <Translate value="test" /><br />
            Token: <input type="text" value={this.state.token} onChange={ (e) => this.setState({token: e.target.value}) } />
            <ReactS3Uploader
                signingUrl="/s3/sign/"
                signingUrlMethod="POST"
                accept="image/*"
                s3path="/"
                // preprocess={ () => {console.log("preprocess")} }
                // onSignedUrl={ () => {console.log("onSignedUrl")} }
                // onProgress={ () => {console.log("onProgress")} }
                // onError={ () => {console.log("onError")} }
                // onFinish={ () => {console.log("onFinish")} }
                signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.state.token }}
                // signingUrlQueryParams={{ additional: query-params }}
                signingUrlWithCredentials={false}      // in case when need to pass authentication credentials via CORS
                uploadRequestHeaders={{}}  // this is the default
                // contentDisposition="auto"
                // scrubFilename={(filename: string) => filename.replace(/[^\w\d_\-.]+/ig, '')}
                server={API_ROOT}
                // inputRef={cmp => this.uploadInput = cmp}
                autoUpload={true}
                />
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, {})(DashboardContainerExample)