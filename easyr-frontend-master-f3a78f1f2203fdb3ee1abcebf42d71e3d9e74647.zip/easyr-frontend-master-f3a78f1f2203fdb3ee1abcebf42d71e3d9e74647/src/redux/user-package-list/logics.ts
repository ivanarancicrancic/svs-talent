import { createLogic } from 'redux-logic';
import axios from 'axios';

import { USER_PACKAGE_LIST_FETCH, IPackagesResponseModel } from './types';
import { userPackageListFetch, userPackageListSuccess, userPackageListFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const userPackageListFetchLogic = createLogic({
    type: USER_PACKAGE_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(userPackageListFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + '/api/packages/own',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as IPackagesResponseModel
                dispatch(userPackageListSuccess(result));
            }).catch(error => {
                dispatch(userPackageListFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    userPackageListFetchLogic
];
