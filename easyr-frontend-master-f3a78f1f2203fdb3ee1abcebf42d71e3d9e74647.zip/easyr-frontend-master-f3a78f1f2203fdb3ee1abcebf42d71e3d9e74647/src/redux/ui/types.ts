export const UI_SHOW_CREATE_CAMPAIGN = '@@ui/createcampaign/SHOW';
export const UI_HIDE_CREATE_CAMPAIGN = '@@ui/createcampaign/HIDE';