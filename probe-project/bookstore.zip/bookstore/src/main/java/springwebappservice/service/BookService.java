package springwebappservice.service;


import springwebapp.model.Book;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface BookService {

    public Book createBook(Book book);
    public List<Book> getAllBooks();
    public String getBook(Long id);
    public String updateBook(Long id, Book book);
    public String deleteBook(Long id);



}
