package springwebapp.contoller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebappservice.service.AuthorService;

/**
 * Created by jt on 5/18/17.
 */
@Controller

public class AuthorController {
    private AuthorService authorService;

    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    @RequestMapping("/authors")
    public String getAuthors(Model model){

        model.addAttribute("authors", authorService.getAllAuthors());

        return "authors";
    }
}
