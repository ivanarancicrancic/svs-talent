package springwebapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springwebapp.repository.AuthorRepository;
import springwebappservice.service.AuthorService;
import springwebappservice.service.AuthorServiceImpl;

@Configuration
public class AuthorServiceConfig {

    @Bean
    AuthorService authorServiceFactory(AuthorRepository repository){
        return new AuthorServiceImpl(repository) {
        };
    }
}
