package springwebapp.contoller;

import org.springframework.context.annotation.Primary;
import springwebapp.commands.BookCommand;
import springwebapp.commands.CategoryCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebapp.model.Category;
import springwebapp.model.Difficutly;
import springwebapp.repository.CategoryRepository;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

import java.util.List;

/**
 * Created by jt on 5/18/17.
 */
@Controller
public class BookController {

    @Autowired
    BookService bookService;


    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    TableAttributeService tableAttributeService;

    public BookController(BookService bookService, TableAttributeService tableAttributeService, CategoryRepository categoryRepository) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.categoryRepository = categoryRepository;
    }

    @RequestMapping("/books")
    public String getBooks(Model model)
    {
        System.out.println("Entered /books");
//        List<BookCommand> books = bookService.getAllBooks();
//        if(books==null) {System.out.println("EMPTY BOOKLIST");}
//        for(BookCommand b:books){
//            System.out.println("Check books");
//            if(b.getCategories()==null){System.out.println("Empty categories");}
//            for(CategoryCommand c: b.getCategories())
//            System.out.println("Book category:" + c.getDescription());
//        }
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }

    @RequestMapping("/findByDescription")
    public String getCategoryByDescription(Model model)
    {
        System.out.println("Entered /findByDescription");
        Category cagetory = categoryRepository.findByDescription("Drama");
        System.out.println("Category id is: " + cagetory.getId() + ", for description: " + cagetory.getDescription());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }

    @RequestMapping("/book/show/{id}")
    public String showById(@PathVariable String id, Model model){
        System.out.println("entered book/show/{id}");
        model.addAttribute("book", bookService.findById(new Long(id)));
        return "book/show";
    }


    @RequestMapping("book/create")
    public String createBook(Model model){
        model.addAttribute("book", new BookCommand()) ;
        return "book/createbookform";
    }

    @PostMapping("create")
    public String createBook(@ModelAttribute BookCommand bookCommand, Model model){
        System.out.println("BEFORE CREATING BOOK");
        bookCommand.setDifficutly(Difficutly.HARD);
        bookCommand.setTitle("NEW");
        BookCommand createdBookCommand = bookService.createBook(bookCommand);
        System.out.println("Id of book created:" + createdBookCommand.getId());
//        model.addAttribute("translate", tableAttributeService.translate());
//        model.addAttribute("books", bookService.getAllBooks());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }


    @RequestMapping("book/{id}/update")
    public String updateBook(@PathVariable String id, Model model){

        model.addAttribute("book", bookService.findById(Long.valueOf(id)));
        return "book/bookform";
    }


    @PostMapping("book")
    public String saveOrUpdate(@ModelAttribute BookCommand bookCommand){
        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getId());
        BookCommand savedBookCommand = bookService.updateBook(bookCommand);
        //BookCommand savedBookCommand = bookService.createBook(bookCommand);
          System.out.println("Id of book updated:" + savedBookCommand.getId());
        return "redirect:/book/show/" + savedBookCommand.getId();
    }


    @RequestMapping("book/{id}/delete")
    public String deleteBook(@PathVariable String id, Model model){
        bookService.deleteBook(Long.valueOf(id));
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }



}
