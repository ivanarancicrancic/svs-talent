
INSERT INTO category (description) VALUES ('Education');
INSERT INTO category (description) VALUES ('Advanture');
INSERT INTO category (description) VALUES ('Psychological');
INSERT INTO category (description) VALUES ('Mystery');