package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.service.SphereContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@RequestMapping("/api/campaigns")
public class SphereContentController {

    de.diefuturisten.easyr.easyrapi.converter.SphereContentToSphereContentReturn sphereContentToSphereContentReturn = new de.diefuturisten.easyr.easyrapi.converter.SphereContentToSphereContentReturn();
    private SphereContentService sphereContentService;

    public SphereContentController(SphereContentService sphereContentService) {
        this.sphereContentService = sphereContentService;
    }

    @GetMapping("{sphereId}")
    @ResponseStatus(HttpStatus.OK)
    public de.diefuturisten.easyr.easyrapi.model.response.SphereContentReturn getSphereById(@PathVariable long sphereId){
        return sphereContentToSphereContentReturn.convert(sphereContentService.findSphereById(sphereId));
    }

    @PostMapping("{id}/spheres/")
    @ResponseStatus(HttpStatus.CREATED)
    public SphereContent postSphereByCampaign(@PathVariable long id, @RequestBody SphereContent sphereContent){
        return sphereContentService.createSphereContent(id, sphereContent);
    }

    @PutMapping("{id}/spheres/{sphereId}")
    @ResponseStatus(HttpStatus.OK)
    public SphereContent modifySphereByCampaign(@PathVariable long id,@RequestBody SphereContent sphereContent,@PathVariable long sphereId){
        return sphereContentService.modifySphereContent(id,sphereContent,sphereId);
    }

    @DeleteMapping("{id}/spheres/{sphereId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteSpherebyCampaign(@PathVariable long id, @PathVariable long sphereId){
        sphereContentService.deleteSphereContent(id, sphereId);
    }
}
