package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.model.response.ContactInformationReturn;
import org.springframework.core.convert.converter.Converter;
import java.util.List;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import java.util.ArrayList;

public class ContactInformationReturnToContactInformation implements Converter<ContactInformationReturn, ContactInformation> {

    public ContactInformationReturnToContactInformation(){}

    @Override
    public ContactInformation convert(ContactInformationReturn source) {
        if(source == null){
            return null;
        }
        ContactInformation contactInformation = new ContactInformation();
        List<Campaign> campaigns = new ArrayList<>();

        contactInformation.setId(source.getId());
        contactInformation.setCampaigns(campaigns);
        contactInformation.setName(source.getName());
        contactInformation.setCompany(source.getCompany());
        contactInformation.setHomepage(source.getHomepage());
        contactInformation.setEmail(source.getEmail());
        contactInformation.setAddress(source.getAddress());
        contactInformation.setAddress2(source.getAddress2());
        contactInformation.setName(source.getNumber());
        contactInformation.setZip(source.getZip());
        contactInformation.setCity(source.getCity());

        return contactInformation;
    }

}
