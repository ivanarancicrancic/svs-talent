package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.SphereContentRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class SphereContentService {

    private SphereContentRepository sphereContentRepository;
    private CampaignRepository campaignRepository;

    public SphereContentService(SphereContentRepository sphereContentRepository, CampaignRepository campaignRepository) {
        this.sphereContentRepository = sphereContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public List<SphereContent> findAllSpheres() {
        return sphereContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public SphereContent findSphereById(long sphereId) {
        return sphereContentRepository.findById(sphereId).get();
    }

    public SphereContent createSphereContent(long id, SphereContent sphereContent) {
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().add(sphereContent);
        campaignRepository.save(campaignOptional.get());
        sphereContentRepository.save(sphereContent);
        return sphereContent;
    }

    public SphereContent modifySphereContent(long id, SphereContent sphereContent, long sphereId) {
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().remove(sphereContentRepository.findById(sphereId).get());
        campaignOptional.get().getContents().add(sphereContent);
        campaignRepository.save(campaignOptional.get());
        return sphereContent;
    }

    public void deleteSphereContent(long id, long sphereId) {
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().remove(sphereContentRepository.findById(sphereId).get());
        campaignRepository.save(campaignOptional.get());
    }
}
