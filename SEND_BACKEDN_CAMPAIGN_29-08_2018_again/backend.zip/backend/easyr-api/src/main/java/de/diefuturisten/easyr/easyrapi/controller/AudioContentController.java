package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.service.AudioContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/campaigns/")
public class AudioContentController {

    private final AudioContentService audioContentService;

    public AudioContentController(AudioContentService audioContentService) {
        this.audioContentService = audioContentService;
    }

    @PutMapping("{id}/audios/{audioId}")
    @ResponseStatus(HttpStatus.OK)
    public void saveAudioByCampaign(@PathVariable long id, @PathVariable long audioId, @RequestBody AudioContent audioContent){
        audioContentService.saveAudioByCampaign(id,audioContent, audioId);
    }

    @DeleteMapping("{id}/audios/{audioId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteAudioByCampaign(@PathVariable long id, @PathVariable long audioId){
        audioContentService.deleteAudioByCampaign(id, audioId);
    }

    @GetMapping("{id}/audios/{audioId}")
    @ResponseStatus(HttpStatus.OK)
    public AudioContent getAudioByCmapaign(@PathVariable long id, @PathVariable long audioId){
       return audioContentService.findAudioByCampaign(id,audioId);
    }

    @PostMapping("{id}/audios/")
    @ResponseStatus(HttpStatus.CREATED)
    public AudioContent createAudioByCampaign(@PathVariable long id, @RequestBody AudioContent audioContent){
        return  audioContentService.createAudioByCampaign(id, audioContent);
    }


}