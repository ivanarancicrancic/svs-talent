package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.model.response.UnityContentReturn;

public class UnityContentToUnityContentReturn implements Converter<UnityContent, UnityContentReturn>{

    public UnityContentToUnityContentReturn(){}

    @Override
    public UnityContentReturn convert(UnityContent source) {
        UnityContentReturn unityContentReturn = new UnityContentReturn();
        unityContentReturn.setId(source.getId());
        unityContentReturn.setWeight(source.getWeight());
        unityContentReturn.setName(source.getName());
        unityContentReturn.setIosUrl(source.getIosUrl());
        unityContentReturn.setAndroidUrl(source.getAndroidUrl());
        unityContentReturn.setPositionX(source.getPositionX());
        unityContentReturn.setPositionY(source.getRotationY());
        unityContentReturn.setPositionZ(source.getRotationZ());
        unityContentReturn.setRotationX(source.getRotationX());
        unityContentReturn.setRotationY(source.getRotationY());
        unityContentReturn.setRotationZ(source.getRotationZ());
        unityContentReturn.setScaleX(source.getScaleX());
        unityContentReturn.setScaleY(source.getScaleY());
        unityContentReturn.setScaleZ(source.getScaleZ());
        if(source.isRenderOnTrackingLost() == true)
            unityContentReturn.setRenderOnTrackingLost("true");
        else
            unityContentReturn.setRenderOnTrackingLost("false");

        if(source.isExtendedTracking() == true)
            unityContentReturn.setExtendedTracking("true");
        else
            unityContentReturn.setExtendedTracking("false");

        return unityContentReturn;
    }

}
