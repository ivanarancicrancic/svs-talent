package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.model.response.SphereContentReturn;
import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;

public class SphereContentReturnToSphereContent implements Converter<SphereContentReturn, SphereContent> {

    public SphereContentReturnToSphereContent(){}

    @Override
    public SphereContent convert(SphereContentReturn source) {
        SphereContent sphereContent = new SphereContent();
        sphereContent.setId(source.getId());
        sphereContent.setWeight(source.getWeight());
        sphereContent.setName(source.getName());
        sphereContent.setUrl(source.getUrl());
        return sphereContent;
    }

}
