package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.response.SlideshowImageReturn;

public class SlideshowImageToSlideshowImageReturn implements Converter<SlideshowImage, SlideshowImageReturn> {

    public SlideshowImageToSlideshowImageReturn(){}

    @Override
    public SlideshowImageReturn convert(SlideshowImage source) {
        SlideshowImageReturn slideshowImageReturn = new SlideshowImageReturn();
        slideshowImageReturn.setId(source.getId());
        slideshowImageReturn.setWeight(source.getWeight());
        return slideshowImageReturn;
    }
}
