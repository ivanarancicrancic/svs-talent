package de.diefuturisten.easyr.easyrapi.entity.content;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="content_spheres")
public class SphereContent extends Content {

    @Column(name="url", nullable = false)
    private String url;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
