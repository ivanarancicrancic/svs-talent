package org.authenticationUserRightRole.service;

import org.authenticationUserRightRole.model.RightsReturn;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface RightService {
    public List<RightsReturn> getAllRights();

    public List<RightsReturn> getRightsForRole(int id);

    public List<RightsReturn> getRightByID(int id);

    public void createRight(RightsReturn right);
}
