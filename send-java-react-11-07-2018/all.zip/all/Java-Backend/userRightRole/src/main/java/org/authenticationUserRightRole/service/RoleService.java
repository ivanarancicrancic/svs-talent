package org.authenticationUserRightRole.service;

import org.authenticationUserRightRole.model.RoleReturn;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface RoleService {

    public List<RoleReturn> getAllRoles();

    public List<RoleReturn> getRolesForUser(int id);

    public RoleReturn getRoleByID(int id);

    public void addRightToRole(int right_id, int roleID);

    public void removeRightFromRole(int right_id, int role_id);
}
