package org.authenticationUserRightRole.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
@Order(1)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
       auth
          .inMemoryAuthentication()
          .withUser("jimi").password("hendrix").roles("USER")
               .and()
               .withUser("admin123").password("admin123").roles("USER", "ADMIN");

    }

    @Override
    protected void configure(HttpSecurity http)throws Exception{
       super.configure(http);
        http
                .csrf().disable()
                .requestMatchers()
                .antMatchers( "/secret")
                .and()
                .authorizeRequests()
                .antMatchers("/api/*").permitAll();

    }

    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring().antMatchers("/api/**");

    }

}
