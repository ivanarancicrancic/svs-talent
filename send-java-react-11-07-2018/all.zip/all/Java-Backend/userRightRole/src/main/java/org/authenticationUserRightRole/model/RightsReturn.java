package org.authenticationUserRightRole.model;

public class RightsReturn {
    private int id;
    private String right_name;
    private String description;

    public RightsReturn(){}
    public RightsReturn(int id, String right_name, String description) {
        this.id = id;
        this.right_name = right_name;
        this.description = description;
    }
    public RightsReturn(String right_name, String description) {
        this.right_name = right_name;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRight_name() {
        return right_name;
    }

    public void setRight_name(String right_name) {
        this.right_name = right_name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
