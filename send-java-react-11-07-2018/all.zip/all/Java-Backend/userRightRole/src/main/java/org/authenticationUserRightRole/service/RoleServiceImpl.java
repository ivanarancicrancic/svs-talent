package org.authenticationUserRightRole.service;

import org.authenticationUserRightRole.model.*;
import org.authenticationUserRightRole.repository.RightRepository;
import org.authenticationUserRightRole.repository.RoleRepository;
import org.authenticationUserRightRole.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("roleService")
@Component
public class RoleServiceImpl implements RoleService{

    @Autowired
    RoleRepository role_repository;

    @Autowired
    UserRepository user_repository;

    @Autowired
    RightRepository right_repository;

    public List<RoleReturn> getAllRoles(){
        List<Role> roles = new ArrayList<Role>();
        roles =  role_repository.findAll();
        //String result = "";
        List<RoleReturn> returnRoles = new ArrayList<RoleReturn>();
        for(Role role : roles) {
            RoleReturn roleReturn = new RoleReturn(role.getId(), role.getUserrole(), role.getDescription());
           returnRoles.add(roleReturn);
            // result = result + role.toString() + "*";
        }
        return returnRoles;


//        roles =  role_repository.findAll();
//        return roles;

    }

    public List<RoleReturn> getRolesForUser(int userID){
        List<RoleReturn> roles_return = new ArrayList<RoleReturn>();
        for(User user:user_repository.findAll()) {
            if(user.getId() == userID)
            {
                for (Role role: user.getRoles())
                {
                    RoleReturn role_return = new RoleReturn(role.getId(), role.getUserrole(), role.getDescription());
                    roles_return.add(role_return);
                }
            }
        }
        return roles_return;
    }

    public RoleReturn getRoleByID(int id){
        Role role = role_repository.findById(id);
        RoleReturn roleReturn = new RoleReturn(role.getId(), role.getUserrole(), role.getDescription());
        return roleReturn;
     }

    public void addRightToRole(int right_id, int roleID){
        List<Role> roles = new ArrayList<Role>();
        roles =  role_repository.findAll();
        System.out.println("Required role id:" + roleID);
        for(Role role : roles){
            System.out.println("Listed roles ids compared:" + role.getId() + "==" + roleID + "?");
            if(role.getId() == roleID)
            {
                Rights right = right_repository.getOne(right_id);
                List<Rights> role_rights = role.getRights();
                System.out.println("Before update of rights list: ");
                for(Rights right1 : role_rights){
                System.out.println(right.getRight_name());}
                role_rights.add(right);
                role.setRights(role_rights);
                role_repository.save(role);
                System.out.println("After update of rights list: ");
                for(Rights right1 : role.getRights()){
                    System.out.println(right.getRight_name());}

            }
        }

    }


    public void removeRightFromRole(int right_id, int id){
        List<Role> roles = new ArrayList<Role>();
        roles =  role_repository.findAll();
        for(Role role : roles){
            if(role.getId() == id)
            {
                Rights right = right_repository.getOne(right_id);
                List<Rights> role_rights = role.getRights();
                role_rights.remove(right);
                role.setRights(role_rights);
                role_repository.save(role);
            }
        }
    }

}
