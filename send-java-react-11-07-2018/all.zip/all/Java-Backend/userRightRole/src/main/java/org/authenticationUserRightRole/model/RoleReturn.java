package org.authenticationUserRightRole.model;

public class RoleReturn {
    private int id;
    private String userrole;
    private String description;

    public RoleReturn(){}

    public RoleReturn(int id, String userrole, String description) {
        this.id = id;
        this.userrole = userrole;
        this.description = description;
    }

    public RoleReturn(String userrole, String description) {
        this.userrole = userrole;
        this.description = description;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserrole() {
        return userrole;
    }

    public void setUserrole(String userrole) {
        this.userrole = userrole;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
