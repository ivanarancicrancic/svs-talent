import * as React from 'react';
import { connect } from 'react-redux';

import './StartLayout.css';
import { IRootState } from '../../redux';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;

}

type IProps = IPropsDispatchMap & IPropsStateMap

class DashboardLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.orderListFetch();
    }

 public renderOrderList() {

        if(this.props.orderData == null) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <tbody>
                    <tr>
                    {this.props.orderData.map( order => {
                        return (
                            <tr key={order.order_id}>
                                <td><b>{order.order_id} Order</b></td>
                                <td>{order.orderDate} This is the order date. </td> 
                            </tr>
                        )
                    })}
                  </tr>
                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>}
                    </td>
                    </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
              
                {this.renderOrderList()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),

});

export default connect(mapStateToProps, {orderListFetch})(DashboardLayout)