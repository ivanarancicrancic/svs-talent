import * as React from 'react';
import {Link, NavLink} from "react-router-dom";
import {PATH_ROOT, PATH_DASHBOARD, PATH_START} from "../../router/paths";

import './Header';
import { userSelfInfoFetch } from '../../redux/user-self-info/actions';
import { getUserSelfInfo } from '../../redux/user-self-info/selectors';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { IUserResponseModel } from '../../redux/user-self-info/types';
import {  Menu, MenuItem, Popover, Position } from "@blueprintjs/core";
import { loginLogout } from '../../redux/auth/actions';
import logo from '../../assets/images/logo.png';
import { IJWToken } from '../../redux/auth/types';

import HamburgerMenu from './HamburgerMenu';

interface IPropsDispatchMap {
    loginLogout: typeof loginLogout;
}

interface IPropsStateMap {
    userInfo: IUserResponseModel | null;
    token: IJWToken | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap

class PostAuthHeader extends React.Component<IProps> {

    public renderUser() {

    
        return <span className="userInfo"> 
                <NavLink to={PATH_DASHBOARD} className="bp3-navbar-heading">
                    <i  className="fontello icon-user" />
                </NavLink></span>;
    }


    public render() {
        console.log("entered render in postAuthHeader")
        return (
            <div className="postHeader header">
                <nav className="bp3-navbar">
                    <div className="headerNav">
                        <div className="bp3-navbar-group">
                            <span className="logoBox">
                            <Link to={PATH_ROOT} className="bp3-navbar-heading"> <img src= { logo } /> </Link>
                            </span>
                            <div className="headerBox">
                                <Link to={PATH_START} className="bp3-navbar-heading">Orders</Link>
                                    <span className="bp3-navbar-heading"> <i  className="fontello icon-search" /> </span>
                                    {this.props.token && <Popover content={
                                        <Menu>
                                            <MenuItem text="Logout" className="bp3-icon-standard bp3-icon-log-out" onClick={this.onLogout} />
                                        </Menu>} 
                                        position={Position.BOTTOM}>
                                        <span className="bp3-icon-standard bp3-icon-cog" />
                                    </Popover>}
                                </div>                       
                                {this.props.token && this.renderUser()}
                            </div>
                                <div className="hamburgerMenu">
                                    <HamburgerMenu />
                                </div>
                        </div>
                </nav>
            </div>
        )
    }

    private onLogout = () => {
        this.props.loginLogout();
    }
}

const mapStateToProps = (state: IRootState) => ({
    userInfo: getUserSelfInfo(state),
    token: state.auth.token
});

export default connect(mapStateToProps, {userSelfInfoFetch, loginLogout, pure: false})(PostAuthHeader)