import * as React from 'react';
import CategoryProducts from './CategoryProducts/Category';
import CategoryInfo from './CategoryInfo/CategoryInfo';

export default class EditCategory extends React.Component {

    public render() {
        return (
            <div className="grid100">
                <CategoryInfo />
                <CategoryProducts />
            </div>
        )
    }

}