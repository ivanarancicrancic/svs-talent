import * as React from 'react';
import './CategoryInfo.css';

export default class CategoryInfo extends React.Component {

    public render() {
        return (
            <div className="infoBox">
                <h2> Kategorie </h2>
                <p> In der Top Kategorie Kochtechnik finden Sie Heizungen, Kochplatten und viele weitere wichtige Ersatzteile nach Hersteller und Warengruppen sortiert. Sollten Sie Ihr Ersatzteil nicht auf anhieb finden können, stehen Ihnen unsere Suchfunktionen zur Verfügung. </p>
            </div>
        )
    }

}