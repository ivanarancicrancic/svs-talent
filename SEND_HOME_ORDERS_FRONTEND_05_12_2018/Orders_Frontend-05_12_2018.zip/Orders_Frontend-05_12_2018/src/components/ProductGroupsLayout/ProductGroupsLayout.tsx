import * as React from 'react';
import { connect } from 'react-redux';

import './ProductGroupsLayout.css';
import { IRootState } from '../../redux';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
  }

type IProps = IPropsDispatchMap & IPropsStateMap

class ProductGroupsLayout extends React.Component<IProps> {

    public componentWillMount() {
        this.props.orderListFetch();
      }

    public renderCategoryList() {

        if(this.props.orderData == null) {
            return null;
        }

        return (
            <div className="dashboardTable" style={{backgroundColor:"#D3D3D3"}} >
              <h1 style={{textAlign:"center"}}> Orders </h1>
                  <tr>Willkommen! </tr>
                   
                <table className="table" style={{backgroundColor:"#D3D3D3"}}>
                    <thead>
                        <tr/>
                    </thead>
                    <tbody>
                
                    <tr>
                     <td><button style={{backgroundColor:"#DF4444"}}> Warengruppen SchnellSuche></button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Ertzatsteil suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}> Bilder Suche </button></td>
                     <td><button style={{backgroundColor:"#2D81B1"}}>Explosionzeichnungen </button></td>
                    </tr>
                    </tbody>
                </table>
            </div>
        );
    }

    public renderCategoryList2() {

        if(!this.props.orderData) {
            return null;
        }

        return (
            <div className="dashboardTable">
                <table className="table">
                <tbody>
                    <tr>
                    {this.props.orderData.map( order => {
                        return (
                            <td key={order.order_id}>
                                <tr><b>{order.order_id} - Order ID</b></tr>
                                <tr>{order.orderDate} - Order datetime </tr>
                            </td>
                        )
                    })}
                  </tr>
                </tbody>
                </table>
            </div>
        )
    }

    public render() {
        return (
            <div className="grid100">
                {this.renderCategoryList()}
                {this.renderCategoryList2()}   
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state)
});

export default connect(mapStateToProps, {orderListFetch })(ProductGroupsLayout)