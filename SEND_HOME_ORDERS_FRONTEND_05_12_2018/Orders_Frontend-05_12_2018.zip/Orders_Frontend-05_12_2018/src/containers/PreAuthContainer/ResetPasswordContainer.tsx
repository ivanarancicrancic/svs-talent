import * as React from 'react';
import { Form, Control, Errors, actions as formActions } from 'react-redux-form';
import { isEmail, maxLength50 } from '../../components/Forms/validator';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { resetPasswordFetch } from '../../redux/forgot-password/actions';
import { IResetPasswordFormData } from '../../redux/forms';
import { RouteComponentProps } from 'react-router';
import { PATH_FORGOT_PASSWORD_RESET } from '../../router/paths';
import { getResetPasswordIsLoading, getResetPasswordHasError } from '../../redux/forgot-password/selectors';
import { Button } from '@blueprintjs/core';

interface IPropsDispatchMap {
    resetPasswordFetch: typeof resetPasswordFetch
}
interface IPropsStateMap {
    resetPasswordIsLoading: boolean;
    resetPasswordHasError: string | null;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{username: string, token?: string}>;

class ResetPasswordContainer extends React.Component<IProps> {

    private formDispatch: any;

    public componentWillUnmount() {
        if (this.formDispatch) {
            this.formDispatch(formActions.reset('forms.resetpassword'));
        }
    }

    public componentWillReceiveProps(nextProps: IProps) {
        const loadingFinished = (this.props.resetPasswordIsLoading === true && nextProps.resetPasswordIsLoading === false);
        const withoutErrors = nextProps.resetPasswordHasError == null;
        if(loadingFinished && withoutErrors) {
            this.props.history.replace(PATH_FORGOT_PASSWORD_RESET);
        }
    }

    public onSubmit(values: IResetPasswordFormData) {
        console.log(values);
        this.props.resetPasswordFetch(values);
    }

    public render() {
        return (
            <div>
                <Form
                    model="forms.resetpassword"
                    onSubmit={(values) => this.onSubmit(values)}
                    // getDispatch={(dispatch: any) => this.formDispatch = dispatch}
                    validators={{
                        '': {
                            passwordsMatch: (vals: IResetPasswordFormData) => vals.password === vals.confirmPassword,
                        }
                    }}
                    getDispatch={(dispatch: any) => {
                        this.formDispatch = dispatch;
                        
                        const { username, token } = this.props.match.params;

                        if (username) {
                            dispatch(
                                formActions.change('forms.resetpassword.email', username)
                            );
                        }

                        if (token) {
                            dispatch(
                                formActions.change('forms.resetpassword.token', token)
                            );
                        }
                    }}
                >
                     <div className="passwordBox">
                        <div className="title">
                            <p>Passwort Vergessen</p>
                        </div>
                        <div className="position">
                            <Control
                                model=".email"
                                validators={{
                                    required: (val) => val && val.length,
                                    isEmail
                                }}
                                component={"input"}

                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "E-Mail"
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".email"
                                show="touched"
                                messages={{
                                    required: 'This field is required',
                                    isEmail: 'Vaid E-Mail required',
                                }}
                            />
                        </div>
                        <div className="position">
                            <Control
                                model=".token"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    placeholder: "Token"
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".token"
                                show="touched"
                                messages={{
                                    required: 'This field is required',
                                }}
                            />
                        </div>
                        <div className="position">
                            <Control
                                model=".password"
                                validators={{
                                    required: (val) => val && val.length,
                                    /* minLength5, */
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    type: "password",
                                    placeholder: "Passwort"
                                }}
                            />
                            <Errors className="arrow_box"
                                model=".password"
                                show="touched"
                                messages={{
                                    required:'This field is required',
                                    maxLength50: 'Password is too long'
                                }}
                            />
                        </div>
                        <div className="position">
                            <Control
                                model=".confirmPassword"
                                validators={{
                                    required: (val) => val && val.length,
                                    /* minLength5, */
                                    maxLength50
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton secondBg",
                                    type: "password",
                                    placeholder: "Passwort wiederholen"
                                }}
                            />
                            <Errors
                                className="arrow_box"
                                model="forms.resetpassword"
                                show="touched"
                                messages={{
                                    passwordsMatch: 'Passworter stimmen nicht überein',
                                }}
                            />
                        </div>
                    </div>
                    <div className="submitPassword">
                        <Button type="submit" loading={this.props.resetPasswordIsLoading}>Neues Passwort setzen</Button>
                    </div>

                </Form>
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    resetPasswordIsLoading: getResetPasswordIsLoading(state),
    resetPasswordHasError: getResetPasswordHasError(state)
});

export default connect(mapStateToProps, {resetPasswordFetch})(ResetPasswordContainer)