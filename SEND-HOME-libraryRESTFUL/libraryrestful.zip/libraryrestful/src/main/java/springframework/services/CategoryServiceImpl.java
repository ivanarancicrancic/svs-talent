package springframework.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import springframework.api.v1.mapper.CategoryToCategoryDTOMapper;
import springframework.api.v1.model.CategoryDTO;
import springframework.respositories.CategoryRepo;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Component
public class CategoryServiceImpl  implements CategoryService {

    @Autowired
    private final CategoryToCategoryDTOMapper categoryMapper;

    @Autowired
    private final CategoryRepo categoryRepository;


    public CategoryServiceImpl(CategoryToCategoryDTOMapper categoryMapper, CategoryRepo categoryRepository) {
        this.categoryMapper = categoryMapper;
        this.categoryRepository = categoryRepository;
    }

    @Override
    public List<CategoryDTO> getAllCategories() {

        return categoryRepository.findAll()
                .stream()
                .map(categoryMapper::convert)
                .collect(Collectors.toList());
    }

    @Override
    public CategoryDTO getCategoryByName(String name) {
        return categoryMapper.convert(categoryRepository.findByName(name));
    }




}
