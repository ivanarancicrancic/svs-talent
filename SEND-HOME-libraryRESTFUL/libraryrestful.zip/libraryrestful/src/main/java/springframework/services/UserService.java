package springframework.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import springframework.api.v1.model.UserDTO;
import springframework.api.v1.model.UserListDTO;

import java.util.List;

@Component
public interface UserService {
    List<UserListDTO> getAllCustomers();

    UserDTO getCustomerById(Long id);


}
