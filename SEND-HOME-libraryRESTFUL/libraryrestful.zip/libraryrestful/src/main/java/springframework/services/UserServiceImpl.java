package springframework.services;

import org.springframework.stereotype.Service;
import springframework.api.v1.mapper.UserDTOToUserMapper;
import springframework.api.v1.model.UserDTO;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserDTOToUserMapper userMapper;
    private final UserRepository userRepository;

    public UserServiceImpl(UserMapper userMapper, UserRepository userRepository) {
        this.userMapper = userMapper;
        this.userRepository = userRepository;
    }

    @Override
    public List<UserDTO> getAllCustomers() {
        return userRepository
                .findAll()
                .stream()
                .map(user -> {
                    UserDTO userDTO = userMapper.userToUserDTO(user);
                    userDTO.setCustomerUrl("/api/v1/customers/" + user.getId());
                    return userDTO;
                })
                .collect(Collectors.toList());
    }

    @Override
    public UserDTO getCustomerById(Long id) {

        return userRepository.findById(id)
                .map(userMapper::convert)
                .orElseThrow(RuntimeException::new);
    }
}
