package springframework.services;


import org.springframework.stereotype.Component;
import springframework.api.v1.model.CategoryDTO;

import java.util.List;

@Component
public interface CategoryService {

    List<CategoryDTO> getAllCategories();

    CategoryDTO getCategoryByName(String name);
}
