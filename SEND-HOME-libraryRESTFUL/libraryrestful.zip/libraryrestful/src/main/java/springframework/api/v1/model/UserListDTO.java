package springframework.api.v1.model;

import java.util.List;

public class UserListDTO {

    List<UserListDTO> categories;

    public List<UserListDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<UserListDTO> categories) {
        this.categories = categories;
    }

    public UserListDTO(List<UserListDTO> categories) {
        this.categories = categories;
    }

    public UserListDTO(){}

}
