package springframework.api.v1.model;


import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CategoryListDTO {

    List<CategoryDTO> categories;

    public List<CategoryDTO> getCategories() {
        return categories;
    }

    public void setCategories(List<CategoryDTO> categories) {
        this.categories = categories;
    }

    public CategoryListDTO(List<CategoryDTO> categories) {
        this.categories = categories;
    }

    public CategoryListDTO(){}
}

