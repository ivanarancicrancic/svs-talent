package springframework.bootstrap;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import springframework.domain.Category;
import springframework.respositories.CategoryRepo;

@Component
public class Bootstrap implements CommandLineRunner {
    private CategoryRepo categoryRepository;

    public Bootstrap(CategoryRepo categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        Category music = new Category();
        music.setName("Jazz");

        Category rock = new Category();
        music.setName("Alternative Rock");

        Category pop = new Category();
        pop.setName("Pop");

        Category hiphop = new Category();
        hiphop.setName("Hiphop");

        Category blues = new Category();
        blues.setName("Blues");

        Category soul = new Category();
        soul.setName("Soul");

        Category opera = new Category();
        opera.setName("Opera");


        Category reggae = new Category();
        reggae.setName("Reggae");

        Category clasical = new Category();
        clasical.setName("Clasical music");


        Category techno = new Category();
        techno.setName("Techno");


        Category funk = new Category();
        funk.setName("Funk");


        Category punk = new Category();
        punk.setName("Punk");

              Category country = new Category();
        country.setName("Country music");

        categoryRepository.save(music);
        categoryRepository.save(rock);
        categoryRepository.save(pop);
        categoryRepository.save(hiphop);
        categoryRepository.save(blues);
        categoryRepository.save(soul);
        categoryRepository.save(opera);
        categoryRepository.save(reggae);
        categoryRepository.save(clasical);
        categoryRepository.save(techno);
        categoryRepository.save(funk);
        categoryRepository.save(punk);
        categoryRepository.save(pop);
        categoryRepository.save(country);

        System.out.println("Data Loaded = " + categoryRepository.count() );

    }

}
