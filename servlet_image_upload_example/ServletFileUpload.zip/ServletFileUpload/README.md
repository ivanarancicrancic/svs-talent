For code explanation and additional configurations read the tutorial at https://javatutorial.net/java-servlet-file-upload
