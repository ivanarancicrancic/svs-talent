package de.diefuturisten.easyr.easyrapi.model.request;

import java.util.List;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;

public class TrackerList {

    private List<Tracker> trackerList;

    public TrackerList(List<Tracker> trackerList) {
        this.trackerList = trackerList;
    }

    public List<Tracker> getTrackerList() {
        return trackerList;
    }

    public void setTrackerList(List<Tracker> trackerList) {
        this.trackerList = trackerList;
    }
}
