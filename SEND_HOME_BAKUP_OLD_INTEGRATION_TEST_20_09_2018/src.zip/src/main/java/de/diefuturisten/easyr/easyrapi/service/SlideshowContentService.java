package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowImageList;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowContentRepository;
import de.diefuturisten.easyr.easyrapi.repository.SlideshowImageRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class SlideshowContentService {

    private SlideshowContentRepository slideshowContentRepository;
    private SlideshowImageRepository slideshowImageRepository;

    public SlideshowContentService(SlideshowContentRepository slideshowContentRepository, SlideshowImageRepository slideshowImageRepository) {
        this.slideshowContentRepository = slideshowContentRepository;
        this.slideshowImageRepository = slideshowImageRepository;
    }

    public List<SlideshowContent> findAllSlides(){
        return slideshowContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public SlideshowContent findById(long id){
      return slideshowContentRepository.findById(id).get();
    }

    public SlideshowContent findByName(String name){
        return slideshowContentRepository.findByName(name).get();
    }

    public SlideshowContent saveSlideShowContent(SlideshowContent slideshowContent){
        slideshowContentRepository.save(slideshowContent);
        return slideshowContent;
    }

    public void deleteSlideShowContent(SlideshowContent slideshowContent){
        slideshowContentRepository.delete(slideshowContent);
    }

    public void deleteSlideShowContentById(long id){
        slideshowContentRepository.deleteById(id);
    }

    public SlideshowImageList getImagesBySlide(long id){
        return new SlideshowImageList(slideshowContentRepository.findById(id).get().getImages().stream().collect(Collectors.toList()));
    }

    public void createImageBySlide(long id, SlideshowImage slideshowImage){
        slideshowContentRepository.findById(id).get().getImages().add(slideshowImage);
        slideshowImageRepository.save(slideshowImage);
    }

    public void deleteImageBySlide(long id, long imageId){

        slideshowContentRepository.findById(id).get().getImages().remove(slideshowImageRepository.findById(imageId).get());
    }







}
