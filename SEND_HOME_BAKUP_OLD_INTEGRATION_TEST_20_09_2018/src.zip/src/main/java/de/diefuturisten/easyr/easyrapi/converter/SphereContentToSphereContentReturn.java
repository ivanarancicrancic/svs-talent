package de.diefuturisten.easyr.easyrapi.converter;

import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.model.request.SphereContentReturn;
import org.springframework.core.convert.converter.Converter;

public class SphereContentToSphereContentReturn implements Converter<SphereContent, SphereContentReturn> {

    public SphereContentToSphereContentReturn(){}

    @Override
    public SphereContentReturn convert(SphereContent source) {
        SphereContentReturn sphereContentReturn = new SphereContentReturn();
        sphereContentReturn.setId(source.getId());
        sphereContentReturn.setWeight(source.getWeight());
        sphereContentReturn.setName(source.getName());
        sphereContentReturn.setUrl(source.getUrl());
     return sphereContentReturn;
    }


    }
