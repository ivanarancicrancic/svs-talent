package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.repository.MovieContentRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class MovieContentService {

    private MovieContentRepository movieContentRepository;

    public MovieContentService(MovieContentRepository movieContentRepository) {
        this.movieContentRepository = movieContentRepository;
    }

    public List<MovieContent> findAllMovies() {
        return movieContentRepository.findAll().stream().collect(Collectors.toList());
    }

}
