package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.repository.AudioContentRepository;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class AudioContentService {

    private AudioContentRepository audioContentRepository;

    public AudioContentService(AudioContentRepository audioContentRepository) {
        this.audioContentRepository = audioContentRepository;
    }

    public List<AudioContent> findAllAudios() {
        return audioContentRepository.findAll().stream().collect(Collectors.toList());
    }

}
