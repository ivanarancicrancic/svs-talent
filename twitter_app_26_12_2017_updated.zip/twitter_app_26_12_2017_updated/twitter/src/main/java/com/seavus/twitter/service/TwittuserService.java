package com.seavus.twitter.service;

import com.seavus.twitter.model.Twittuser;
import org.springframework.stereotype.Component;


import java.util.List;

@Component
public interface TwittuserService {

    public List<String> getAllTwittusers();

    public String getAllTwittFollowers(int twittuser);

    public String getAllTwittFollowing(int twittuser);

    public Twittuser getUser(int id);

    public Twittuser createUser(Twittuser twittuser);

    public Twittuser updateUser(int id, Twittuser twittuser);

    public String followUser(int twittuser_id, String userToFollow_mail);

    public Twittuser unfollowUser(int twittuser_id, String userToFollow_mail);

    public Twittuser checkTwittuser(String mail);

    public Twittuser deleteTwittuser(int id);


}
