package com.seavus.twitter.service;

import com.seavus.twitter.model.Twittuser;
import com.seavus.twitter.repository.TwittuserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service("twittuserService")
@Component

public class TwittuserServiceImpl implements TwittuserService {
    @Autowired
    TwittuserRepository twittuserRepository;

//    public List<Twittuser> getAllTwittusers(){
        public List<String> getAllTwittusers(){
       // String result = "";
         List<String> result = new ArrayList<>();
        for (Twittuser twittuser:twittuserRepository.findAll()){

           // System.out.println("entering newline..");
           // String newLine = System.getProperty("line.separator");//This will retrieve line separator dependent on OS.
          //  result = result + twittuser.toString() + newLine;
            result.add(twittuser.toString());
        }
         //System.out.println("Result: " + result);

//        return twittuserRepository.findAll();
       return  result;
    }

    public String getAllTwittFollowers(int twittuser_id){
       Twittuser twittuser = twittuserRepository.findOne(twittuser_id);
        return twittuser.followerNames();
    }

    public String getAllTwittFollowing(int twittuser_id){
        Twittuser twittuser = twittuserRepository.findOne(twittuser_id);
        return twittuser.followingNames();
    }

    public Twittuser getUser(int id){
        return twittuserRepository.findOne(id);
    }

    public String followUser(int twittuser_id, String userToFollow_mail){
        Twittuser twittuser = twittuserRepository.findOne(twittuser_id);
        System.out.println(twittuser.toString());
        Twittuser userToFollow = twittuserRepository.findByMail(userToFollow_mail);
        System.out.println(userToFollow.toString());
       List<Twittuser> following = new ArrayList<>();
        System.out.println("Current following list for this user is: ");
        following = twittuser.getFollowing();
       for(Twittuser t: following) {
           System.out.println(t.toString());
       }
        System.out.println("Adding new following user to this list");
       following.add(userToFollow);
        twittuser.setFollowing(following);
        System.out.println("List of following updated!");
      //  updateUser(twittuser.getId(),twittuser);
        twittuserRepository.saveAndFlush(twittuser);
        System.out.println("List of following saved!");
        return twittuserRepository.findOne(twittuser_id).toString();
    }

    public Twittuser unfollowUser(int twittuser_id, String userToUnfollow_mail){
        Twittuser twittuser = twittuserRepository.findOne(twittuser_id);
        Twittuser userToUnfollow = twittuserRepository.findByMail(userToUnfollow_mail);
        List<Twittuser> following = new ArrayList<>();
        following = twittuser.getFollowers();
        following.remove(userToUnfollow);
        twittuser.setFollowing(following);
        twittuserRepository.save(twittuser);
//        updateUser(twittuser.getId(),twittuser);
        return twittuser;
    }

    public Twittuser createUser(Twittuser twittuser){
        return twittuserRepository.save(twittuser);

    }

   public Twittuser checkTwittuser(String mail){
        Twittuser twittuser = twittuserRepository.findByMail(mail);
        return twittuser;
   }


    public Twittuser updateUser(int id, Twittuser twittuser){
            Twittuser userToUpdate = twittuserRepository.findOne(id);
            userToUpdate.setMail(twittuser.getMail());

//            for(Twittuser current_following: userToUpdate.getFollowing()){
//                if(twittuser.getFollowing().contains(current_following)){
//                    continue;
//                }
//                else{
//                    List<Twittuser> updatedFollowers = current_following.getFollowers();
//                    updatedFollowers.remove(userToUpdate);
//                    current_following.setFollowers(updatedFollowers);
//                    twittuserRepository.save(current_following);
//                }
//            }
//
//            for(Twittuser new_following: twittuser.getFollowing()){
//                if(userToUpdate.getFollowing().contains(new_following))
//                {
//                    continue;
//                }
//                else{
//                    List<Twittuser> followers = new_following.getFollowers();
//                    followers.add(userToUpdate);
//                    new_following.setFollowers(followers);
//                    twittuserRepository.save(new_following);
//                }
//            }

            userToUpdate.setFollowing(twittuser.getFollowing());
            userToUpdate.setFollowers(twittuser.getFollowers());
            //preparing to update followers
//         for(Twittuser current_follower: userToUpdate.getFollowers()){
//            if(twittuser.getFollowers().contains(current_follower)){
//                continue;
//            }
//            else{
//                List<Twittuser> updatedFollowing = current_follower.getFollowing();
//                updatedFollowing.remove(userToUpdate);
//                current_follower.setFollowing(updatedFollowing);
//                message_repository.save(current_follower);
//            }
//        }
           // userToUpdate.setFollowers(twittuser.getFollowers());


            userToUpdate.setCreatedmessages(twittuser.getCreatedmessages());
            userToUpdate.setMessages(twittuser.getMessages());
            twittuserRepository.save(userToUpdate);
            return userToUpdate;
    }

    public Twittuser deleteTwittuser(int id){

        Twittuser user = twittuserRepository.findOne(id);
        twittuserRepository.delete(id);
        return user;
    }


}
