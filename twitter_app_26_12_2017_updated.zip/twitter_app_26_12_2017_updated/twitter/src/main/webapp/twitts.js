function Twitts($scope, $http) {
    $http.get('http//localhost:8080/api/v1/twitts').
          success(function(data) {
          $scope.events = data;
          });
}