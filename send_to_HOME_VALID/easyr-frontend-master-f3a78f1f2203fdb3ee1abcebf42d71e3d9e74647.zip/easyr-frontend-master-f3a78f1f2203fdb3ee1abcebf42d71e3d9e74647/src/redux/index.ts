import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';

import { ICaptchaState, CaptchaActions, captchaReducer } from './captcha/reducer';
import { IAuthState, AuthActions, authReducer } from './auth/reducer';
import { IUserCampaignListState, UserCampaignListActions, userCampaignListReducer } from './user-campaign-list/reducer';
import { IUserPackageListState, UserPackageListActions, userPackageListReducer } from './user-package-list/reducer';
import { IUserSelfInfoState, UserSelfInfoActions, userSelfInfoReducer } from './user-self-info/reducer';
import { IRegistrationState, RegistrationActions, registerReducer } from './register/reducer';
import { IForgotPasswordState, ForgotPasswordActions, forgotPasswordReducer } from './forgot-password/reducer';
import { ICampaignDetailState, CampaignDetailActions, campaignDetailReducer } from './campaign/reducer';
import { IUIState, UIActions, uiReducer } from './ui/reducer';
import { IMessageState, MessageActions, messageReducer } from './messages/reducer';

import { formsReducer } from './forms';
export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    ui: IUIState;
    messages: IMessageState;
    captcha: ICaptchaState;
    auth: IAuthState;
    userCampaignList: IUserCampaignListState;
    campaign: ICampaignDetailState;
    userPackageList: IUserPackageListState;
    userSelfInfo: IUserSelfInfoState;
    register: IRegistrationState;
    forgotPassword: IForgotPasswordState;
    forms: any;
}

export type RootAction = RouterAction
    | LocationChangeAction
    | AuthActions
    | UserCampaignListActions
    | CampaignDetailActions
    | UserPackageListActions
    | UserSelfInfoActions
    | RegistrationActions
    | CaptchaActions
    | ForgotPasswordActions
    | UIActions
    | MessageActions;

export const reducers = combineReducers<IRootState>({
    i18n: i18nReducer,
    router: routerReducer,
    ui: uiReducer,
    messages: messageReducer,
    captcha: captchaReducer,
    auth: authReducer,
    userCampaignList: userCampaignListReducer,
    campaign: campaignDetailReducer,
    userPackageList: userPackageListReducer,
    userSelfInfo: userSelfInfoReducer,
    register: registerReducer,
    forgotPassword: forgotPasswordReducer,
    forms: formsReducer,
});