import { IRootState } from '..'

export const getUserCampaignDetail = (state: IRootState) => state.campaign.data;
export const getUserCampaignDetailIsLoading = (state: IRootState) => state.campaign.loading;
export const getUserCampaignDetailHasError = (state: IRootState) => state.campaign.error;