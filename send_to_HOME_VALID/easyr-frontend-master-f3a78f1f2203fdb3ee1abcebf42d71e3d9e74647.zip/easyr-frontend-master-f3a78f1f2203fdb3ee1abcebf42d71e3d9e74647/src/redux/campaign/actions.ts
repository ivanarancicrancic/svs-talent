import {
    USER_CAMPAIGN_DETAIL_FETCH,
    USER_CAMPAIGN_DETAIL_SUCCESS,
    USER_CAMPAIGN_DETAIL_FAIL,
    
    CAMPAIGN_CREATE_FETCH,
    CAMPAIGN_CREATE_SUCCESS,
    CAMPAIGN_CREATE_FAIL,

    CAMPAIGN_SAVE_FETCH,
    CAMPAIGN_SAVE_SUCCESS,
    CAMPAIGN_SAVE_FAIL,

    CAMPAIGN_EDIT_FETCH,
    CAMPAIGN_EDIT_SUCCESS,
    CAMPAIGN_EDIT_FAIL,

    TRACKER_UPLOAD_FAIL,
    TRACKER_UPLOAD_FETCH,
    TRACKER_UPLOAD_SUCCESS,

    TRACKER_DELETE_FAIL,
    TRACKER_DELETE_FETCH,
    TRACKER_DELETE_SUCCESS,

    CONTENT_DELETE_FETCH,
    CONTENT_DELETE_SUCCESS,
    CONTENT_DELETE_FAIL,

    CONTENT_VIDEO_CREATE_FETCH,
    CONTENT_VIDEO_CREATE_SUCCESS,
    CONTENT_VIDEO_CREATE_FAIL,

    CONTENT_VIDEO_EDIT_FETCH,
    CONTENT_VIDEO_EDIT_SUCCESS,
    CONTENT_VIDEO_EDIT_FAIL,

    ICampaignDetailResponseModel,
    ITrackerResponseModel,
    IPanoramaContentResponseModel,
    CONTENT_WEBVIEW_EDIT_FETCH,
    CONTENT_WEBVIEW_EDIT_FAIL,
    IWebviewContentResponseModel,
    IContentResponseModel
} from './types';

import { createStandardAction } from 'typesafe-actions';
import { IVideoContentRequestModel, IVideoContentResponseModel, CONTENT_PANORAMA_CREATE_FETCH, CONTENT_PANORAMA_CREATE_SUCCESS, CONTENT_PANORAMA_CREATE_FAIL, CONTENT_PANORAMA_EDIT_FETCH, CONTENT_PANORAMA_EDIT_SUCCESS, CONTENT_PANORAMA_EDIT_FAIL, IPanoramaContentRequestModel, CONTENT_WEBVIEW_CREATE_FETCH, CONTENT_WEBVIEW_CREATE_SUCCESS, CONTENT_WEBVIEW_CREATE_FAIL, CONTENT_WEBVIEW_EDIT_SUCCESS, IWebviewContentRequestModel, CONTENT_AUDIO_CREATE_FETCH, CONTENT_AUDIO_CREATE_SUCCESS, CONTENT_AUDIO_CREATE_FAIL, CONTENT_AUDIO_EDIT_FETCH, CONTENT_AUDIO_EDIT_SUCCESS, CONTENT_AUDIO_EDIT_FAIL, IAudioContentResponseModel, IAudioContentRequestModel, CONTENT_UNITY_CREATE_FETCH, CONTENT_UNITY_CREATE_SUCCESS, CONTENT_UNITY_CREATE_FAIL, CONTENT_UNITY_EDIT_FETCH, CONTENT_UNITY_EDIT_SUCCESS, CONTENT_UNITY_EDIT_FAIL, IUnityContentRequestModel, IUnityContentResponseModel, CONTENT_SLIDESHOW_CREATE_SUCCESS, CONTENT_SLIDESHOW_CREATE_FAIL, CONTENT_SLIDESHOW_CREATE_FETCH, CONTENT_SLIDESHOW_EDIT_FETCH, CONTENT_SLIDESHOW_EDIT_SUCCESS, CONTENT_SLIDESHOW_EDIT_FAIL, ISlideshowContentRequestModel, ISlideshowContentResponseModel, CONTENT_SLIDESHOW_IMAGEUP_FETCH, CONTENT_SLIDESHOW_IMAGEUP_SUCCESS, CONTENT_SLIDESHOW_IMAGEUP_FAIL, CONTENT_SLIDESHOW_IMAGEDOWN_FETCH, CONTENT_SLIDESHOW_IMAGEDOWN_SUCCESS, CONTENT_SLIDESHOW_IMAGEDOWN_FAIL, CONTENT_RENAME_FETCH, CONTENT_RENAME_SUCCESS, CONTENT_RENAME_FAIL, IMoreinfoContentResponseModel, IMoreinfoContentRequestModel, CONTENT_MOREINFO_CREATE_FETCH, CONTENT_MOREINFO_CREATE_SUCCESS, CONTENT_MOREINFO_CREATE_FAIL, CONTENT_MOREINFO_EDIT_FETCH, CONTENT_MOREINFO_EDIT_SUCCESS, CONTENT_MOREINFO_EDIT_FAIL } from './types';

export const userCampaignDetailFetch = createStandardAction(USER_CAMPAIGN_DETAIL_FETCH)<{id: number}>();
export const userCampaignDetailSuccess = createStandardAction(USER_CAMPAIGN_DETAIL_SUCCESS)<ICampaignDetailResponseModel>();
export const userCampaignDetailFail = createStandardAction(USER_CAMPAIGN_DETAIL_FAIL)<string>();

export const campaignCreateFetch = createStandardAction(CAMPAIGN_CREATE_FETCH)();
export const campaignCreateSuccess = createStandardAction(CAMPAIGN_CREATE_SUCCESS)<ICampaignDetailResponseModel>();
export const campaignCreateFail = createStandardAction(CAMPAIGN_CREATE_FAIL)<string>();

export const campaignSaveFetch = createStandardAction(CAMPAIGN_SAVE_FETCH)<{campaignId: number, packageId: number}>();
export const campaignSaveSuccess = createStandardAction(CAMPAIGN_SAVE_SUCCESS)<ICampaignDetailResponseModel>();
export const campaignSaveFail = createStandardAction(CAMPAIGN_SAVE_FAIL)<string>();

export const campaignEditFetch = createStandardAction(CAMPAIGN_EDIT_FETCH)<{id: number, name: string}>();
export const campaignEditSuccess = createStandardAction(CAMPAIGN_EDIT_SUCCESS)<ICampaignDetailResponseModel>();
export const campaignEditFail = createStandardAction(CAMPAIGN_EDIT_FAIL)<string>();

export const trackerUploadFetch = createStandardAction(TRACKER_UPLOAD_FETCH)<{campaignId: number, data: FormData}>();
export const trackerUploadSuccess = createStandardAction(TRACKER_UPLOAD_SUCCESS)<ITrackerResponseModel>();
export const trackerUploadFail = createStandardAction(TRACKER_UPLOAD_FAIL)<string>();

export const trackerDeleteFetch = createStandardAction(TRACKER_DELETE_FETCH)<{trackerId: number}>();
export const trackerDeleteSuccess = createStandardAction(TRACKER_DELETE_SUCCESS)<{trackerId: number}>();
export const trackerDeleteFail = createStandardAction(TRACKER_DELETE_FAIL)<string>();

export const contentDeleteFetch = createStandardAction(CONTENT_DELETE_FETCH)<{contentId: number}>();
export const contentDeleteSuccess = createStandardAction(CONTENT_DELETE_SUCCESS)<{contentId: number}>();
export const contentDeleteFail = createStandardAction(CONTENT_DELETE_FAIL)<string>();

export const contentVideoCreateFetch = createStandardAction(CONTENT_VIDEO_CREATE_FETCH)<{campaignId: number, data: IVideoContentRequestModel}>();
export const contentVideoCreateSuccess = createStandardAction(CONTENT_VIDEO_CREATE_SUCCESS)<IVideoContentResponseModel>();
export const contentVideoCreateFail = createStandardAction(CONTENT_VIDEO_CREATE_FAIL)<string>();

export const contentVideoEditFetch = createStandardAction(CONTENT_VIDEO_EDIT_FETCH)<{data: IVideoContentRequestModel}>();
export const contentVideoEditSuccess = createStandardAction(CONTENT_VIDEO_EDIT_SUCCESS)<IVideoContentResponseModel>();
export const contentVideoEditFail = createStandardAction(CONTENT_VIDEO_EDIT_FAIL)<string>();

export const contentPanoramaCreateFetch = createStandardAction(CONTENT_PANORAMA_CREATE_FETCH)<{campaignId: number, data: IPanoramaContentRequestModel}>();
export const contentPanoramaCreateSuccess = createStandardAction(CONTENT_PANORAMA_CREATE_SUCCESS)<IPanoramaContentResponseModel>();
export const contentPanoramaCreateFail = createStandardAction(CONTENT_PANORAMA_CREATE_FAIL)<string>();

export const contentPanoramaEditFetch = createStandardAction(CONTENT_PANORAMA_EDIT_FETCH)<{data: IPanoramaContentRequestModel}>();
export const contentPanoramaEditSuccess = createStandardAction(CONTENT_PANORAMA_EDIT_SUCCESS)<IPanoramaContentResponseModel>();
export const contentPanoramaEditFail = createStandardAction(CONTENT_PANORAMA_EDIT_FAIL)<string>();

export const contentWebviewCreateFetch = createStandardAction(CONTENT_WEBVIEW_CREATE_FETCH)<{campaignId: number, data: IWebviewContentRequestModel}>();
export const contentWebviewCreateSuccess = createStandardAction(CONTENT_WEBVIEW_CREATE_SUCCESS)<IWebviewContentResponseModel>();
export const contentWebviewCreateFail = createStandardAction(CONTENT_WEBVIEW_CREATE_FAIL)<string>();

export const contentWebviewEditFetch = createStandardAction(CONTENT_WEBVIEW_EDIT_FETCH)<{data: IWebviewContentRequestModel}>();
export const contentWebviewEditSuccess = createStandardAction(CONTENT_WEBVIEW_EDIT_SUCCESS)<IWebviewContentResponseModel>();
export const contentWebviewEditFail = createStandardAction(CONTENT_WEBVIEW_EDIT_FAIL)<string>();

export const contentMoreinfoCreateFetch = createStandardAction(CONTENT_MOREINFO_CREATE_FETCH)<{campaignId: number, data: IMoreinfoContentRequestModel}>();
export const contentMoreinfoCreateSuccess = createStandardAction(CONTENT_MOREINFO_CREATE_SUCCESS)<IMoreinfoContentResponseModel>();
export const contentMoreinfoCreateFail = createStandardAction(CONTENT_MOREINFO_CREATE_FAIL)<string>();

export const contentMoreinfoEditFetch = createStandardAction(CONTENT_MOREINFO_EDIT_FETCH)<{data: IMoreinfoContentRequestModel}>();
export const contentMoreinfoEditSuccess = createStandardAction(CONTENT_MOREINFO_EDIT_SUCCESS)<IMoreinfoContentResponseModel>();
export const contentMoreinfoEditFail = createStandardAction(CONTENT_MOREINFO_EDIT_FAIL)<string>();

export const contentAudioCreateFetch = createStandardAction(CONTENT_AUDIO_CREATE_FETCH)<{campaignId: number, data: IAudioContentRequestModel}>();
export const contentAudioCreateSuccess = createStandardAction(CONTENT_AUDIO_CREATE_SUCCESS)<IAudioContentResponseModel>();
export const contentAudioCreateFail = createStandardAction(CONTENT_AUDIO_CREATE_FAIL)<string>();

export const contentAudioEditFetch = createStandardAction(CONTENT_AUDIO_EDIT_FETCH)<{data: IAudioContentRequestModel}>();
export const contentAudioEditSuccess = createStandardAction(CONTENT_AUDIO_EDIT_SUCCESS)<IAudioContentResponseModel>();
export const contentAudioEditFail = createStandardAction(CONTENT_AUDIO_EDIT_FAIL)<string>();

export const contentUnityCreateFetch = createStandardAction(CONTENT_UNITY_CREATE_FETCH)<{campaignId: number, data: IUnityContentRequestModel}>();
export const contentUnityCreateSuccess = createStandardAction(CONTENT_UNITY_CREATE_SUCCESS)<IUnityContentResponseModel>();
export const contentUnityCreateFail = createStandardAction(CONTENT_UNITY_CREATE_FAIL)<string>();

export const contentUnityEditFetch = createStandardAction(CONTENT_UNITY_EDIT_FETCH)<{data: IUnityContentRequestModel}>();
export const contentUnityEditSuccess = createStandardAction(CONTENT_UNITY_EDIT_SUCCESS)<IUnityContentResponseModel>();
export const contentUnityEditFail = createStandardAction(CONTENT_UNITY_EDIT_FAIL)<string>();

export const contentSlideshowCreateFetch = createStandardAction(CONTENT_SLIDESHOW_CREATE_FETCH)<{campaignId: number, data: ISlideshowContentRequestModel}>();
export const contentSlideshowCreateSuccess = createStandardAction(CONTENT_SLIDESHOW_CREATE_SUCCESS)<ISlideshowContentResponseModel>();
export const contentSlideshowCreateFail = createStandardAction(CONTENT_SLIDESHOW_CREATE_FAIL)<string>();

export const contentSlideshowEditFetch = createStandardAction(CONTENT_SLIDESHOW_EDIT_FETCH)<{data: ISlideshowContentRequestModel}>();
export const contentSlideshowEditSuccess = createStandardAction(CONTENT_SLIDESHOW_EDIT_SUCCESS)<ISlideshowContentResponseModel>();
export const contentSlideshowEditFail = createStandardAction(CONTENT_SLIDESHOW_EDIT_FAIL)<string>();

export const contentSlideshowImageUpFetch = createStandardAction(CONTENT_SLIDESHOW_IMAGEUP_FETCH)<{imageId: number}>();
export const contentSlideshowImageUpSuccess = createStandardAction(CONTENT_SLIDESHOW_IMAGEUP_SUCCESS)<ISlideshowContentResponseModel>();
export const contentSlideshowImageUpFail = createStandardAction(CONTENT_SLIDESHOW_IMAGEUP_FAIL)<string>();

export const contentSlideshowImageDownFetch = createStandardAction(CONTENT_SLIDESHOW_IMAGEDOWN_FETCH)<{imageId: number}>();
export const contentSlideshowImageDownSuccess = createStandardAction(CONTENT_SLIDESHOW_IMAGEDOWN_SUCCESS)<ISlideshowContentResponseModel>();
export const contentSlideshowImageDownFail = createStandardAction(CONTENT_SLIDESHOW_IMAGEDOWN_FAIL)<string>();

export const contentRenameFetch = createStandardAction(CONTENT_RENAME_FETCH)<{contentId: number, name: string}>();
export const contentRenameSuccess = createStandardAction(CONTENT_RENAME_SUCCESS)<IContentResponseModel>();
export const contentRenameFail = createStandardAction(CONTENT_RENAME_FAIL)<string>();