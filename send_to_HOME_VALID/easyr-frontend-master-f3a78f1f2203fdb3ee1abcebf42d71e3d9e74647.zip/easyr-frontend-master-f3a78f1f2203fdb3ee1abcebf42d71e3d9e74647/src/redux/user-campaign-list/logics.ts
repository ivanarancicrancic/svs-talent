import { createLogic } from 'redux-logic';
import axios from 'axios';

import { USER_CAMPAIGN_LIST_FETCH, ICampaignResponseModel } from './types';
import { userCampaignListFetch, userCampaignListSuccess, userCampaignListFail } from './actions';
import { isActionOf } from 'typesafe-actions';
import { API_ROOT } from '../../router/api-config';
import { IRootState } from '..';

export const userCampaignListFetchLogic = createLogic({
    type: USER_CAMPAIGN_LIST_FETCH,
    latest: true,
    process({getState, action}: any, dispatch: any, done: any) {
        if (isActionOf(userCampaignListFetch)(action)) {

            const token = (getState() as IRootState).auth.token!.token;
            
            axios({
                method: 'get',
                url: API_ROOT + '/api/campaigns',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            }).then(response => {
                const result = response.data as ICampaignResponseModel[]
                dispatch(userCampaignListSuccess(result));
            }).catch(error => {
                dispatch(userCampaignListFail("fail"));
            });

        } else {
            done();
        }
    }
});

export default [
    userCampaignListFetchLogic
];
