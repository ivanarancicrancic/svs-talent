import { ActionType, getType } from 'typesafe-actions';
import { ICampaignResponseModel } from './types';

import * as actions from './actions';
import { campaignCreateSuccess } from '../campaign/actions'

const extActions = {...actions, campaignCreateSuccess};
export type UserCampaignListActions = ActionType<typeof extActions>;

export interface IUserCampaignListState {
    readonly data: ICampaignResponseModel[] | null;
    readonly loading: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IUserCampaignListState = {
    data: null,
    loading: false,
    error: null
};
  
export function userCampaignListReducer(state: IUserCampaignListState = INITIAL_STATE, action: UserCampaignListActions): IUserCampaignListState  {
    switch (action.type) {
        case getType(extActions.userCampaignListFetch):
            return {...state, loading: true, error: null};
        case getType(extActions.userCampaignListSuccess):
            return {...state, loading: false, error: null, data: action.payload};
        case getType(extActions.userCampaignListFail):
            return {...state, loading: false, error: action.payload};

        case getType(extActions.campaignCreateSuccess):
            return state; // jurassic code

        default:
            return state;
    }
}