export const USER_CAMPAIGN_LIST_FETCH = '@@user/campaign/list/FETCH';
export const USER_CAMPAIGN_LIST_SUCCESS = '@@user/campaign/list/SUCCESS';
export const USER_CAMPAIGN_LIST_FAIL = '@@user/campaign/list/FAIL';

export const CAMPAIGN_CREATE_FETCH = '@@campaign/create/FETCH';
export const CAMPAIGN_CREATE_SUCCESS = '@@campaign/create/SUCCESS';
export const CAMPAIGN_CREATE_FAIL = '@@campaign/create/FAIL';

export interface ICampaignResponseModel {
    id: number;
    name: string;
    trackerUrl: string | null;
    numberOfViews: number;
    expirationDate: string | null;
};