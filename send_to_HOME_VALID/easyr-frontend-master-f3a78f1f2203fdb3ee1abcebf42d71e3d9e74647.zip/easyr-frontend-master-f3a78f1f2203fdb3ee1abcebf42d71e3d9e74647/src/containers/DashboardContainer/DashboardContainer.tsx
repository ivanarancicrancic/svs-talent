import * as React from 'react';
import ProductGroupsLayout from '../../components/ProductGroupsLayout/ProductGroupsLayout';


export default class DashboardContainer extends React.Component {

    public render():any {
        return (
            <div>
                <ProductGroupsLayout />
            </div>
        )
    }
}