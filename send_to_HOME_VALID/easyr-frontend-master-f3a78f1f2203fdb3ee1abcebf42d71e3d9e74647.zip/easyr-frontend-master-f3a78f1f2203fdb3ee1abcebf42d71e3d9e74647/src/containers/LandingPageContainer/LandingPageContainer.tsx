import * as React from 'react';
import LandingPage from '../../components/LandingPage/LandingPage';


export default class LandingPageContainer extends React.Component {

    public render() {
        return (
            <div>
                <LandingPage />
            </div>
        )
    }
}