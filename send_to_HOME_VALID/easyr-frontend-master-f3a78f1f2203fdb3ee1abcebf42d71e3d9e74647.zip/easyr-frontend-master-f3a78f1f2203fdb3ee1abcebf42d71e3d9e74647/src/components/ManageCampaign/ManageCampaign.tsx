import * as React from 'react';
// import { Button, Collapse  } from "@blueprintjs/core";

import './ManageCampaign.css';
import { RouteComponentProps } from 'react-router';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import { userCampaignDetailFetch, trackerUploadFetch, trackerDeleteFetch, campaignSaveFetch, campaignEditFetch } from '../../redux/campaign/actions';
import { ICampaignDetailResponseModel, /*ITrackerResponseModel*/ } from '../../redux/campaign/types';
import { getUserCampaignDetail, getUserCampaignDetailIsLoading } from '../../redux/campaign/selectors';
import ReactDropzone from 'react-dropzone';

// import { history } from '../../router';

import editPencilImg from '../../assets/images/edit_pencil.svg';
import bigPlusImg from '../../assets/images/big_plus.svg';
import paperbinRedImg from '../../assets/images/paperbin_red.svg';

import { userPackageListFetch } from '../../redux/user-package-list/actions';
import { IPackagesResponseModel } from '../../redux/user-package-list/types';

import ManageContent from './ManageContent';

interface IPropsDispatchMap {
    userCampaignDetailFetch: typeof userCampaignDetailFetch;
    userPackageListFetch: typeof userPackageListFetch;
    trackerUploadFetch: typeof trackerUploadFetch;
    trackerDeleteFetch: typeof trackerDeleteFetch;
    campaignSaveFetch: typeof campaignSaveFetch;
    campaignEditFetch: typeof campaignEditFetch;
}
interface IPropsStateMap {
    campaign: ICampaignDetailResponseModel | null;
    campaignLoading: boolean;

    packages: IPackagesResponseModel | null;

    trackerLoading: boolean;
}

type IProps = IPropsDispatchMap & IPropsStateMap & RouteComponentProps<{id: number}>;

interface IState {
    campaignName: string;
    width: number;
    height: number;

    helpFormSend: boolean;
    packageSelected: number | null;
}

class ManageCampaign extends React.Component<IProps, IState> {

    // public unblocker: any;

    constructor(props: any) {
        super(props);

        this.state = {
            campaignName: "",
            width: 0,
            height: 0,
            helpFormSend: false,
            packageSelected: null,
        }
    }

    public updateWindowDimensions = () => {
        this.setState({ width: window.innerWidth, height: window.innerHeight });
    }

    public componentWillMount() {
        const id = this.props.match.params.id;
        this.props.userCampaignDetailFetch({id});
        this.props.userPackageListFetch();

        /*
        this.unblocker = history.block(targetLocation => {
            console.log(targetLocation);
            alert("Campaign is not saved yet, please select a campaign package.");
            return;
        })
        */
    }

    public componentDidMount() {
        this.updateWindowDimensions();
        window.addEventListener('resize', this.updateWindowDimensions);
    }

    public componentWillUnmount() {
        // this.unblocker();
        window.removeEventListener('resize', this.updateWindowDimensions);
    }

    public componentWillReceiveProps(nextProps: IProps) {
        if(nextProps.location.key !== this.props.location.key) {
            this.props.userCampaignDetailFetch({id: nextProps.match.params.id});
        }

        if(nextProps.campaign !== this.props.campaign && nextProps.campaign !== null) {
            this.setState({campaignName: nextProps.campaign.name, packageSelected: nextProps.campaign.activePackageId});
            this.props.userPackageListFetch();
        }
    }


    // tracker stuff
    public renderTracker() {

        if(this.props.trackerLoading) {
            return (
                <div style={{position: 'relative', display: 'flex', flexDirection: 'row', border: '2px solid #e51249', width: 191*4, height: 114 }}>
                    <div style={{position: 'absolute', display: 'flex', alignItems: 'center', justifyContent: 'center', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#e51249', opacity: 0.9}}>
                        <span style={{fontSize: 16, color: '#FFFFFF'}}>Tracker werden verarbeitet ...</span>
                    </div>
                </div>
            )
        }

        return (
            <div style={{position: 'relative', display: 'flex', flexDirection: 'row', border: '2px solid #e51249', width: 191*4, height: 114, overflowX: 'auto'}}>

                {this.props.campaign!.tracker.map( (tracker, index) => {
                    return (<div
                        key={tracker.id}
                        style={{
                            position: 'relative',
                            minWidth: 191,
                            borderRight: '2px solid #e51249',
                            backgroundImage: `url(${tracker.url})`,
                            backgroundSize: 'cover',
                        }}
                    >
                        <div style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: 'rgba(255,255,255,0.5)'}} />

                        <div style={{position: 'absolute', top: 5, left: 10}}>
                            <span style={{color: '#e51249', fontSize: 13, fontWeight: 600}}>Erkennungsbild {index+1}</span>
                        </div>

                        <img
                            style={{cursor: 'pointer', position: 'absolute', bottom: 5, right: 5, width: 13, height: 16}} src={paperbinRedImg}
                            onClick={ () => { this.props.trackerDeleteFetch({trackerId: tracker.id}); } }
                        />
                    </div>)
                })}

                <div style={{
                    cursor: 'pointer',
                    position: 'relative',
                    display: 'flex',
                    flexShrink: 0,
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 191,
                    borderRight: this.props.campaign!.tracker.length < 3 ? '2px solid #e51249' : undefined,
                    backgroundColor: '#fdf2f0'}}>

                    <div style={{position: 'absolute', top: 5, left: 10}}>
                        <span style={{color: '#e51249', fontSize: 13, fontWeight: 600}}>Erkennungsbild {this.props.campaign!.tracker.length + 1}</span>
                    </div>

                    <ReactDropzone
                        style={{}}
                        accept="image/jpeg, image/png, image/jpg, image/bmp"
                        inputProps={{ style: {position: 'absolute', top: -10, left: -10, width: 50, height: 50, opacity: 0}}}
                        onDrop={ (files) => {
                            const formData = new FormData();
                            const file = new Blob([files[0]]);
                            formData.set('file', file, files[0].name);
                            console.log(files[0].name);
                            this.props.trackerUploadFetch({campaignId: this.props.campaign!.id, data: formData});
                        }}>
                        <img style={{width: 27, height: 27}} src={bigPlusImg} />
                    </ReactDropzone>

                </div>

            </div>
        )
    }

    // header stuff
    public onPackageSelected(packageId: number) {
        this.setState({packageSelected: packageId});
    }

    public onPackageSave = () => {
        this.props.campaignSaveFetch({campaignId: this.props.campaign!.id, packageId: this.state.packageSelected!});
    }

    public onNameChanged(name: string) {
        this.props.campaignEditFetch({id: this.props.campaign!.id, name});
    }

    public renderPackages() {

        const { packages } = this.props;

        if(packages == null) {
            return <div style={{display: 'flex', width: 188*3, height: 43, backgroundColor: '#fdf2f0'}} />
        }

        const onPackageClick = (id: number) => {
            if(this.props.campaign!.temporary) {
                this.onPackageSelected(id);
            }
        }

        return (
            <React.Fragment>
                {packages.available.map( (pkg, index) => {
                    return (
                        <div
                            onClick={ () => {if(pkg.count > 0) {onPackageClick(pkg.id)}} }
                            key={pkg.id}
                            style={{
                                cursor: 'pointer',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                borderRight: index === packages.available.length-1 ? undefined : '2px solid #e51249',
                                width: 191, height: 43,
                                backgroundColor: this.state.packageSelected === pkg.id ? '#e51249' : '#fdf2f0'}}
                            >
                                <span style={{
                                    color: this.state.packageSelected === pkg.id ? '#FFFFFF' : '#e51249',
                                    fontSize: 13,
                                    fontWeight: 500
                                    }}>
                                    {`Kampagnenart: "${pkg.name}"`}
                                </span>
                                {this.props.campaign!.temporary === true && <span style={{
                                    color: this.state.packageSelected === pkg.id ? '#FFFFFF' : '#e51249',
                                    fontSize: 11,
                                    fontWeight: 500
                                    }}>
                                    {`${pkg.count} verfügbar`}
                                </span>}
                        </div>
                    );
                })}
            </React.Fragment>
        )
    }

    public renderHeader() {
        return (
            <div style={{display: 'flex', flexDirection: 'column', border: '2px solid #e51249', marginBottom: 15}}>
                <div style={{display: 'flex', flexDirection: 'row'}}>
                    <div style={{display: 'flex', alignItems: 'center', borderRight: '2px solid #e51249', width: 188, height: 43}}>
                        <input value={this.state.campaignName || ""} onChange={ (e) => { this.setState({campaignName: e.target.value}) } } onBlur={ () => { this.onNameChanged(this.state.campaignName); } } style={{flex: 1, paddingLeft: 5, border: '0px', outline: 'none', color: '#e51249', fontSize: 14, fontWeight: 500, width: '100'}} placeholder={"Kampagnen Name"} type='text' />
                        <img style={{width: 24, height: 24, marginRight: 5}} src={editPencilImg} />
                    </div>

                    {this.renderPackages()}
                </div>
                {this.props.campaign!.temporary === true && this.state.packageSelected !== null && <div onClick={this.onPackageSave} style={{cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e51249', paddingTop: 5, paddingBottom: 5}}>
                    <span style={{color: '#FFFFFF', fontSize: 11}}>Kampagne mit dem ausgewählten Paket erstellen</span>
                </div>}
            </div>
        )
    }

    public renderFooter() {
        return (
            <div style={{display: 'flex', border: '2px solid #e51249', marginBottom: 15, marginTop: 15}}>
                <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', flex: 1, height: 43}}>
                    <span style={{
                            paddingLeft: 15, paddingRight: 15,
                            color: '#e51249',
                            fontSize: 11
                            }}>
                    Sie benötigen Inhalte oder Hilfe bei ihrer Erstellung? Bitte kontaktieren Sie uns - wir helfen!
                    </span>
                </div>

                <div onClick={ () => { this.setState({helpFormSend: true}) } } style={{cursor: !this.state.helpFormSend ? 'pointer' : undefined, display: 'flex', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e51249', width: 190, height: 43}}>
                    <span style={{
                        paddingLeft: 15, paddingRight: 15,
                        color: '#FFFFFF',
                        fontSize: 13
                        }}>{this.state.helpFormSend ? '✓' : 'Absenden' }</span>
                </div>
            </div>
        )
    }

    public getScale = () => {
        if((this.state.width - 200) >= (this.state.height)) {
            return (this.state.height - 100) / 580.0;
        } else {
            return (this.state.width) / 765.0 * 0.9;
        }
    }

    // render
    public render() {

        if(this.props.campaign === null) {
            return null;
        }

        return (
            <div style={{display: 'flex', flexDirection: 'column', transform: `scale(${this.getScale()})`}}>
                {this.renderHeader()}
                {this.renderTracker()}
                <ManageContent campaignId={this.props.campaign.id} contents={this.props.campaign!.contents} />
                {this.renderFooter()}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    campaign: getUserCampaignDetail(state),
    campaignLoading: getUserCampaignDetailIsLoading(state),
    trackerLoading: state.campaign.trackerLoading,
    packages: state.userPackageList.data
});

export default connect(mapStateToProps, {userCampaignDetailFetch, userPackageListFetch, campaignSaveFetch, campaignEditFetch, trackerUploadFetch, trackerDeleteFetch})(ManageCampaign);
