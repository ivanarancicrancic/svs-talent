import * as React from 'react';
import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import ReactS3Uploader from 'react-s3-uploader';
import { LocalForm, actions } from 'react-redux-form';

import { PanoramaSubtype, IPanoramaContentRequestModel } from '../../redux/campaign/types';
import { contentPanoramaEditFetch, contentPanoramaCreateFetch } from '../../redux/campaign/actions';

import './Forms.css';
import { API_ROOT } from '../../router/api-config';

interface IPropsStateMap {
    loading: boolean;
}

interface IPropsDispatchMap {
    contentPanoramaCreateFetch: typeof contentPanoramaCreateFetch;
    contentPanoramaEditFetch: typeof contentPanoramaEditFetch;
}

interface IDirectProps {
    token: string;
    content: IPanoramaContentRequestModel | null;
    campaignId: number;
    subtype: PanoramaSubtype;
}

type IProps = IPropsDispatchMap & IPropsStateMap &  IDirectProps;

interface IState {
    uploading: boolean,
    uploadingProgress: number;
    uploadingError: boolean;
    url: string | null,
    touched: boolean;
}

/*
interface IPanoramaContentForm {
    //would be empty
}
*/

class PanoramaContentForm extends React.Component<IProps, IState> {

    public formDispatch: any;

    constructor(props: IProps) {
        super(props);

        this.state = {
            uploading: false,
            uploadingProgress: 0,
            uploadingError: false,
            url: null,
            touched: false
        }
    }

    public componentWillMount() {
        console.log("PanoramaContentForm componentWillMount");
    }

    public componentDidUpdate(prevProps: IProps) {
        console.log("PanoramaContentForm componentDidUpdate");
        if(this.props.content !== prevProps.content) {
            this.updateForm();
        }
    }

    public updateForm() {
        console.log("updateForm", this.props.content != null);
        if(this.props.content != null) {
            this.setState({url: this.props.content.url, touched: false});
        } else {
            this.setState({url: null, touched: false});
        }
    }

    public componentDidMount() {
        this.updateForm();
    }

    public onUploadComplete(url: string) {
        console.log("onUploadComplete", url);
        this.setState({uploading: false, uploadingProgress: 0, uploadingError: false, url: url.split("?")[0]}, () => {
            this.formDispatch(actions.submit('local'));
        });
    }

    public renderUploadButton() {
        if(this.state.uploading) {
            return (
                <div style={{position: 'relative', backgroundColor: '#e51249', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                        Datei wird hochgeladen ...
                    </span>
                    <div style={{position: 'absolute', bottom: 0, left: 0, height: 5, width: `${this.state.uploadingProgress}%`, backgroundColor: '#FFFFFF'}}/>
                </div>
            );
        } else if(this.state.url != null) {
            return (
                <div
                    style={{cursor: 'pointer', backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}
                    onClick={ () => { window.open(this.state.url!, '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes'); } }
                >
                    <span style={{color: '#e51249', fontSize: 10, fontWeight: 500}}>
                        Inhalt öffnen
                    </span>
                </div>
            );
        } else {
            return (
                <div style={{backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#e51249', fontSize: 10, fontWeight: 500}}>
                        Foto - Datei auswählen
                    </span>
                    <div style={{marginLeft: 5, width: 53, height: 16, backgroundColor: '#e51249', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                        <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                            hochladen
                        </span>
                    </div>

                    <ReactS3Uploader
                        style={{cursor: 'pointer', position: 'absolute', width: 173, height: 28, opacity: 0}}
                        signingUrl="/api/s3/sign/"
                        signingUrlMethod="POST"
                        accept="image/*"
                        s3path="/"
                        preprocess={ (file: any, next: any) => { this.setState({uploading: true}, () => { next(file); }) } }
                        onSignedUrl={ () => { return; } }
                        onProgress={ (progress: any) => { console.log("onProgress", progress); this.setState({uploadingProgress: progress}); } }
                        onError={ () => { console.log("onError"); this.setState({uploading: false, uploadingError: true}); } }
                        onFinish={ (signResult: {signedUrl: string}) => { this.onUploadComplete(signResult.signedUrl); } }
                        signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.props.token }}
                        signingUrlWithCredentials={false}
                        uploadRequestHeaders={{}}
                        server={API_ROOT}
                        autoUpload={true}
                    />
                </div>
            );
        }
    }

    public onSubmit(values: {}) {

        const newValues: IPanoramaContentRequestModel = {
            id: this.props.content && this.props.content.id || undefined,
            subType: this.props.subtype,
            url: this.state.url!,
            renderOnTrackingLost: false,
            extendedTracking: false,
            name: this.props.subtype === "SPHERE" ? "Sphere Panorama" : this.props.subtype === "X180" ? "180° Panorama" : "360° Panorama"
        }

        if(this.props.content === null) {
            this.props.contentPanoramaCreateFetch({
                campaignId: this.props.campaignId,
                data: newValues
            });
        } else {
            console.log("TODO: edit");
            this.props.contentPanoramaEditFetch({data: newValues});
        }

        console.log("onSubmit", this.props.content, newValues);

        this.formDispatch(actions.setUntouched('local'));
    }

    public attachDispatch(dispatch: any) {
        this.formDispatch = dispatch;
    }

    public render() {
        return (
            <div>
                <LocalForm
                    className={"formz1"}
                    onUpdate={(form) => {console.log("onUpdate", form); this.setState({touched: form.$form.touched}) }}
                    onChange={(values) => {console.log("onChange", values)}}
                    onSubmit={(values) => { this.onSubmit(values); }}
                    getDispatch={(dispatch) => this.attachDispatch(dispatch)}
                >
                    <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, height: 45, backgroundColor: '#fdf2f0'}}>
                        {this.renderUploadButton()}
                    </div>
                    <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', width: 190*3, height: 45, backgroundColor: '#fdf2f0'}} />
                </LocalForm>
                {this.state.touched && this.state.url && <div onClick={ () => { this.formDispatch(actions.submit('local')); } } style={{cursor: 'pointer', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', border: '2px solid #e51249', borderTop: '0px', backgroundColor: '#e51249', marginRight: 1, padding: 5}}>
                    <span style={{color: '#FFFFFF', fontSize: 11}}>Änderungen speichern</span>
                </div>}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    loading: state.campaign.contentLoading
});

export default connect(mapStateToProps, {contentPanoramaCreateFetch, contentPanoramaEditFetch})(PanoramaContentForm);