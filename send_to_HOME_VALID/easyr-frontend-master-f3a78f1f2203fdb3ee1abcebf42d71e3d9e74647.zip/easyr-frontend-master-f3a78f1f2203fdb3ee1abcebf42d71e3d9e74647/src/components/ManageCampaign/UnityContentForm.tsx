import * as React from 'react';
import { connect } from 'react-redux';
import { IRootState } from '../../redux';
import ReactS3Uploader from 'react-s3-uploader';
import { LocalForm, Control, actions } from 'react-redux-form';

import { IUnityContentResponseModel, IUnityContentRequestModel } from '../../redux/campaign/types';
import { contentUnityCreateFetch, contentUnityEditFetch } from '../../redux/campaign/actions';

import './Forms.css';
import { API_ROOT } from '../../router/api-config';


interface IPropsStateMap {
    loading: boolean;
}

interface IPropsDispatchMap {
    contentUnityCreateFetch: typeof contentUnityCreateFetch;
    contentUnityEditFetch: typeof contentUnityEditFetch;
}

interface IDirectProps {
    token: string;
    content: IUnityContentResponseModel | null;
    campaignId: number;
}

type IProps = IPropsDispatchMap & IPropsStateMap &  IDirectProps;

interface IState {
    uploadingAndroid: boolean,
    uploadingProgressAndroid: number;
    uploadingErrorAndroid: boolean;

    uploadingIOS: boolean,
    uploadingProgressIOS: number;
    uploadingErrorIOS: boolean;


    iosUrl: string | null,
    androidUrl: string | null,
    touched: boolean;

    showMoreOptions: boolean;
}

interface IUnityContentForm {
    positionX: string;
    positionY: string;
    positionZ: string;
    rotationX: string;
    rotationY: string;
    rotationZ: string;
    scaleX: string;
    scaleY: string;
    scaleZ: string;
}

class UnityContentForm extends React.Component<IProps, IState> {

    public formDispatch: any;

    constructor(props: IProps) {
        super(props);

        this.state = {
            uploadingAndroid: false,
            uploadingProgressAndroid: 0,
            uploadingErrorAndroid: false,

            uploadingIOS: false,
            uploadingProgressIOS: 0,
            uploadingErrorIOS: false,


            iosUrl: null,
            androidUrl: null,
            touched: false,

            showMoreOptions: false
        }
    }

    public componentWillMount() {
        console.log("UnityContentForm componentWillMount");
    }

    public componentDidUpdate(prevProps: IProps) {
        console.log("UnityContentForm componentDidUpdate");
        if(this.props.content !== prevProps.content) {
            this.updateForm();
        }
    }

    public updateForm() {
        console.log("updateForm", this.props.content != null);
        if(this.props.content != null) {
            this.formDispatch(actions.change('local.positionX', this.props.content.positionX || ''));
            this.formDispatch(actions.change('local.positionY', this.props.content.positionY || ''));
            this.formDispatch(actions.change('local.positionZ', this.props.content.positionZ || ''));
            this.formDispatch(actions.change('local.rotationX', this.props.content.rotationX || ''));
            this.formDispatch(actions.change('local.rotationY', this.props.content.rotationY || ''));
            this.formDispatch(actions.change('local.rotationZ', this.props.content.rotationZ || ''));
            this.formDispatch(actions.change('local.scaleX', this.props.content.scaleX || ''));
            this.formDispatch(actions.change('local.scaleY', this.props.content.scaleY || ''));
            this.formDispatch(actions.change('local.scaleZ', this.props.content.scaleZ || ''));
            this.formDispatch(actions.change('local.scaleY', this.props.content.scaleY || ''));
            this.formDispatch(actions.change('local.scaleZ', this.props.content.scaleZ || ''));
            this.setState({iosUrl: this.props.content.iosUrl, androidUrl: this.props.content.androidUrl, touched: false});
        } else {
            this.formDispatch(actions.change('local.positionX', ''));
            this.formDispatch(actions.change('local.positionY', ''));
            this.formDispatch(actions.change('local.positionZ', ''));
            this.formDispatch(actions.change('local.rotationX', ''));
            this.formDispatch(actions.change('local.rotationY', ''));
            this.formDispatch(actions.change('local.rotationZ', ''));
            this.formDispatch(actions.change('local.scaleX', ''));
            this.formDispatch(actions.change('local.scaleY', ''));
            this.formDispatch(actions.change('local.scaleZ', ''));
            this.formDispatch(actions.change('local.scaleY', ''));
            this.formDispatch(actions.change('local.scaleZ', ''));
            this.setState({iosUrl: null, androidUrl: null, touched: false});
        }
    }

    public componentDidMount() {
        this.updateForm();
    }

    public onIOSUploadComplete(url: string) {
        console.log("onIOSUploadComplete", url);
        this.setState({uploadingIOS: false, uploadingProgressIOS: 0, uploadingErrorIOS: false, iosUrl: url.split("?")[0]}, () => {
            this.formDispatch(actions.submit('local'));
        });
    }

    public onAndroidUploadComplete(url: string) {
        console.log("onAndroidUploadComplete", url);
        this.setState({uploadingAndroid: false, uploadingProgressAndroid: 0, uploadingErrorAndroid: false, androidUrl: url.split("?")[0]}, () => {
            this.formDispatch(actions.submit('local'));
        });
    }

    public renderIOSUploadButton() {
        if(this.state.uploadingIOS) {
            return (
                <div style={{position: 'relative', backgroundColor: '#e51249', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                        Datei wird hochgeladen ...
                    </span>
                    <div style={{position: 'absolute', bottom: 0, left: 0, height: 5, width: `${this.state.uploadingProgressIOS}%`, backgroundColor: '#FFFFFF'}}/>
                </div>
            );
        } else if(this.state.iosUrl != null) {
            return (
                <div
                    style={{cursor: 'pointer', backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}
                    onClick={ () => { window.open(this.state.iosUrl!, '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes'); } }
                >
                    <span style={{color: '#e51249', fontSize: 10, fontWeight: 500}}>
                        iOS - Inhalt öffnen
                    </span>
                </div>
            );
        } else {
            return (
                <div style={{backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#e51249', fontSize: 8, fontWeight: 500}}>
                        iOS - Datei auswählen
                    </span>
                    <div style={{marginLeft: 5, width: 53, height: 16, backgroundColor: '#e51249', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                        <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                            hochladen
                        </span>
                    </div>

                    <ReactS3Uploader
                        style={{position: 'absolute', width: 173, height: 28, opacity: 0}}
                        signingUrl="/api/s3/sign/"
                        signingUrlMethod="POST"
                        accept="*"
                        s3path="/"
                        preprocess={ (file: any, next: any) => { this.setState({uploadingIOS: true}, () => { next(file); }) } }
                        onSignedUrl={ () => { return; } }
                        onProgress={ (progress: any) => { console.log("onProgress", progress); this.setState({uploadingProgressIOS: progress}); } }
                        onError={ () => { console.log("onError"); this.setState({uploadingIOS: false, uploadingErrorIOS: true}); } }
                        onFinish={ (signResult: {signedUrl: string}) => { this.onIOSUploadComplete(signResult.signedUrl); } }
                        signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.props.token }}
                        signingUrlWithCredentials={false}
                        uploadRequestHeaders={{}}
                        server={API_ROOT}
                        autoUpload={true}
                    />
                </div>
            );
        }
    }

    public renderAndroidUploadButton() {
        if(this.state.uploadingAndroid) {
            return (
                <div style={{position: 'relative', backgroundColor: '#e51249', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                        Datei wird hochgeladen ...
                    </span>
                    <div style={{position: 'absolute', bottom: 0, left: 0, height: 5, width: `${this.state.uploadingProgressAndroid}%`, backgroundColor: '#FFFFFF'}}/>
                </div>
            );
        } else if(this.state.androidUrl != null) {
            return (
                <div
                    style={{cursor: 'pointer', backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}
                    onClick={ () => { window.open(this.state.androidUrl!, '_blank', 'location=yes,height=570,width=520,scrollbars=yes,status=yes'); } }
                >
                    <span style={{color: '#e51249', fontSize: 10, fontWeight: 500}}>
                        Android - Inhalt öffnen
                    </span>
                </div>
            );
        } else {
            return (
                <div style={{backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                    <span style={{color: '#e51249', fontSize: 8, fontWeight: 500}}>
                        Android - Datei auswählen
                    </span>
                    <div style={{marginLeft: 5, width: 53, height: 16, backgroundColor: '#e51249', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                        <span style={{color: '#FFFFFF', fontSize: 10, fontWeight: 500}}>
                            hochladen
                        </span>
                    </div>

                    <ReactS3Uploader
                        style={{position: 'absolute', width: 173, height: 28, opacity: 0}}
                        signingUrl="/api/s3/sign/"
                        signingUrlMethod="POST"
                        accept="*"
                        s3path="/"
                        preprocess={ (file: any, next: any) => { this.setState({uploadingAndroid: true}, () => { next(file); }) } }
                        onSignedUrl={ () => { return; } }
                        onProgress={ (progress: any) => { console.log("onProgress", progress); this.setState({uploadingProgressAndroid: progress}); } }
                        onError={ () => { console.log("onError"); this.setState({uploadingAndroid: false, uploadingErrorAndroid: true}); } }
                        onFinish={ (signResult: {signedUrl: string}) => { this.onAndroidUploadComplete(signResult.signedUrl); } }
                        signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.props.token }}
                        signingUrlWithCredentials={false}
                        uploadRequestHeaders={{}}
                        server={API_ROOT}
                        autoUpload={true}
                    />
                </div>
            );
        }
    }

    public renderMoreOptions() {

        const onClick = () => { this.setState({showMoreOptions: !this.state.showMoreOptions}); }

        return (
            <div onClick={onClick} style={{cursor: 'pointer', backgroundColor: '#FFFFFF', width: 173, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <span style={{color: '#e51249', fontSize: 10, fontWeight: 500}}>
                    Weitere Optionen {this.state.showMoreOptions ? 'ausblenden' : 'anzeigen'}
                </span>
            </div>
        )
    }

    public onSubmit(values: IUnityContentForm) {

        const newValues: IUnityContentRequestModel = {
            id: this.props.content && this.props.content.id || undefined,
            iosUrl: this.state.iosUrl!,
            androidUrl: this.state.androidUrl!,
            positionX: parseFloat(values.positionX) || 0,
            positionY: parseFloat(values.positionY) || 0,
            positionZ: parseFloat(values.positionZ) || 0,
            rotationX: parseFloat(values.rotationX) || 0,
            rotationY: parseFloat(values.rotationY) || 0,
            rotationZ: parseFloat(values.rotationZ) || 0,
            scaleX: parseFloat(values.scaleX) || 0,
            scaleY: parseFloat(values.scaleY) || 0,
            scaleZ: parseFloat(values.scaleZ) || 0,
            renderOnTrackingLost: false,
            extendedTracking: false,
            name: "3D"
        }

        if(this.props.content === null) {
            this.props.contentUnityCreateFetch({
                campaignId: this.props.campaignId,
                data: newValues
            });
        } else {
            this.props.contentUnityEditFetch({data: newValues});
        }

        console.log("onSubmit", this.props.content, newValues);

        this.formDispatch(actions.setUntouched('local'));
    }

    public attachDispatch(dispatch: any) {
        this.formDispatch = dispatch;
    }

    public render() {
        return (
            <div>
                <LocalForm
                    className={"formz3"}
                    onUpdate={(form) => {console.log("onUpdate", form); this.setState({touched: form.$form.touched}) }}
                    onChange={(values) => {console.log("onChange", values)}}
                    onSubmit={(values) => { this.onSubmit(values); }}
                    getDispatch={(dispatch) => this.attachDispatch(dispatch)}
                >
                    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, alignSelf: 'stretch', backgroundColor: '#fdf2f0'}}>
                        <div style={{marginBottom: 10}}>
                            {this.renderIOSUploadButton()}
                        </div>
                        {this.renderAndroidUploadButton()}
                        <div style={{marginTop: 10}}>
                            {this.renderMoreOptions()}
                        </div>
                    </div>

                    <div style={{display: this.state.showMoreOptions ? 'flex' : 'none', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, alignSelf: 'stretch', backgroundColor: '#fdf2f0'}}>
                        <span style={{color: '#e51249', fontSize: 11, fontWeight: 500, marginLeft: 10, marginRight: 5}}>Position</span>
                        <div style={{display: 'flex', flexDirection: 'row', marginTop: 5}}>
                            <Control.text type="number" step="0.1" placeholder={"x: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249'}} name="positionX" model=".positionX" />
                            <Control.text type="number" step="0.1" placeholder={"y: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="positionY" model=".positionY" />
                            <Control.text type="number" step="0.1" placeholder={"z: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="positionZ" model=".positionZ" />
                        </div>
                    </div>
                    <div style={{display: this.state.showMoreOptions ? 'flex' : 'none', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', borderRight: '2px solid #e51249', width: 190, alignSelf: 'stretch', backgroundColor: '#fdf2f0'}}>
                        <span style={{color: '#e51249', fontSize: 11, fontWeight: 500, marginLeft: 10, marginRight: 5}}>Rotation</span>
                        <div style={{display: 'flex', flexDirection: 'row', marginTop: 5}}>
                            <Control.text type="number" step="0.1" placeholder={"x: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249'}} name="rotationX" model=".rotationX" />
                            <Control.text type="number" step="0.1" placeholder={"y: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="rotationY" model=".rotationY" />
                            <Control.text type="number" step="0.1" placeholder={"z: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="rotationZ" model=".rotationZ" />
                        </div>
                    </div>
                    <div style={{display: this.state.showMoreOptions ? 'flex' : 'none', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', width: 190, alignSelf: 'stretch', backgroundColor: '#fdf2f0'}}>
                        <span style={{color: '#e51249', fontSize: 11, fontWeight: 500, marginLeft: 10, marginRight: 5}}>Größe</span>
                        <div style={{display: 'flex', flexDirection: 'row', marginTop: 5}}>
                            <Control.text type="number" step="0.1" placeholder={"x: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249'}} name="scaleX" model=".scaleX" />
                            <Control.text type="number" step="0.1" placeholder={"y: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="scaleY" model=".scaleY" />
                            <Control.text type="number" step="0.1" placeholder={"z: 0"} style={{paddingLeft: 5, width: 50, height: 28, border: '1px solid #e51249', backgroundColor: '#FFFFFF', color: '#e51249', borderLeft: '0px'}} name="scaleZ" model=".scaleZ" />
                        </div>
                    </div>
                </LocalForm>
                {this.state.touched && this.state.androidUrl && this.state.iosUrl && <div onClick={ () => { this.formDispatch(actions.submit('local')); } } style={{cursor: 'pointer', display: 'flex', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', border: '2px solid #e51249', borderTop: '0px', backgroundColor: '#e51249', marginRight: 1, padding: 5}}>
                    <span style={{color: '#FFFFFF', fontSize: 11}}>Änderungen speichern</span>
                </div>}
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    loading: state.campaign.contentLoading
});

export default connect(mapStateToProps, {contentUnityEditFetch, contentUnityCreateFetch})(UnityContentForm);