import * as React from 'react';
import './LandingPage.css';

export default class AboutUs extends React.Component{

  
    public render() {
        return (
            <div className="aboutUs pageBox">
                <span className="bp3-icon-standard bp3-icon-menu burger-menu" />
                <div className="NW"> <div className="centered">
                    Augmented, Virtual, Cross REALITY:
                    Wir bringen S(s)ie zusammen.
                    <span> ALLE Ihre Wünsche werden REALITÄT! </span>
                </div> </div>
                <div className="NE"> <div className="centered"> 
                    Wir sind: anders als ALLE Anderen.
                    Einfacher, besser, schneller, preiswerter, flexibler
                    und fast immer:  <span> in 10 Minuten einsetzbar. </span>
                </div> </div>
                <div className="SW"> <div className="centered"> 
                    Alle Erfolge sind messbar. 
                    Wir erstellen Auswertungen,
                    <span> die keine Fragen offen lassen. </span>
                </div> </div>
                <div className="SE"> <div className="centered">
                    P.S.: Allen „führenden“ Anbietern sind wir ein 
                    Stück voraus! (auch Apple, Google & Co.) 
                    <span> Wieso – Weshalb – Warum? Fragen Sie uns! </span>
                </div> </div>

                <div className="centered">
                    <p> DIE<span>_</span>FUTURISTEN </p>
                    <p className="title"> Warum wir? </p>
                </div>
            </div>
        )
    }
}  