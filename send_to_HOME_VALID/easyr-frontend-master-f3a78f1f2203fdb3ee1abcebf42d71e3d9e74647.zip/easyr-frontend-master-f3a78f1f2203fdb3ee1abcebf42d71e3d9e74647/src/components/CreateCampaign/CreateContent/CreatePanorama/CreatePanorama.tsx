import * as React from 'react';
import '../../CreateCampaign.css'
import { Form, Control, Errors } from 'react-redux-form';

export default class CreatePanorama extends React.Component<any, any> {
    constructor(props: any) {
        super(props);
        this.onSubmit = this.onSubmit.bind(this);
      }
    
      public onSubmit(values:any) {
        fetch('/test', {
            method: 'POST',
            body: JSON.stringify({
                values
            }),
        });
        console.log(values)
      }

    public render() {
        return (
            <div className="createBox">
                <Form
                    model="forms.panorama"
                    method="post"
                    onSubmit={ (panorama) => this.onSubmit(panorama) }
                    validators={{
                        name: { required: (val:any) => val && val.length },
                        type: { required: (val:any) => val && val.length },
                        img: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                >
                    <div className="bp3-input-group">
                        <label htmlFor="name" className="bp3-file-input">Name</label>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'This field is required',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-select bp3-fill">
                        <Control.select 
                            model=".type" 
                        >
                            <option defaultValue="0">Choose Type </option>
                            <option value="180&#176;">180&#176; </option>
                            <option value="360&#176;">360&#176; </option>
                            <option value="Sphere">Sphere </option>
                        </Control.select>
                        <Errors
                            model=".type"
                            messages={{
                                required: 'Please choose a type',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <div className="bp3-input-group ">
                         <label className="bp3-file-input">
                            <Control.file
                                model=".img" name="file" accept=".jpg, .png, image/*"
                            />
                          <span className="bp3-file-upload-input">Please select an image...</span>
                        </label>

                        <Errors
                            model=".name"
                            messages={{
                                required: 'Please select an image',
                            }}
                            show="touched"
                            className="errors"
                        />
                    </div>
                    <button className="bp3-button saveBtn"> <span className="bp3-icon-standard bp3-icon-tick-circle" /> </button>
                </Form>
            </div>
        )
    }
}