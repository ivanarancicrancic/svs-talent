import * as React from 'react';
import '../CreateCampaign.css';
import { Form, Control, Errors } from 'react-redux-form';

export default class CreateWebview extends React.Component {
    constructor(props: any) {
        super(props);
      }

    public render() {
        return (
            <div className="createBox">
                <Form
                    model="forms.webview"
                    method="post"
                    validators={{
                        name: { required: (val:any) => val && val.length },
                        url: { required: (val:any) => val && val.length },
                      }}
                    validateOn="submit"
                >
                    <div className="bp3-input-group">
                        <label htmlFor="name" className="bp3-file-input">Webview Name</label>
                        <Control.text
                            className="bp3-input"
                            model=".name"
                        />
                        <Errors
                            model=".name"
                            messages={{
                                required: 'This field is required',
                            }}
                            show="touched"
                        />
                    </div>
                    <div className="bp3-input-group">
                        <label htmlFor="name" className="bp3-file-input">Enter URL</label>
                        <Control.text
                            className="bp3-input"
                            model=".url"
                            type="url"
                        />
                        <Errors
                            model=".url"
                            messages={{
                                required: 'This field is required',
                            }}
                            show="touched"
                        />
                    </div>
                </Form>
            </div>
        )
    }
}