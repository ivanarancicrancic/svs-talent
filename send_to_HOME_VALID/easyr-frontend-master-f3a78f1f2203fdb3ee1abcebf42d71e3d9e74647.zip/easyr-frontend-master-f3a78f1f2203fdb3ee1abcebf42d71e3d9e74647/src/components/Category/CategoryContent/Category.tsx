import * as React from 'react';
import './Category.css';

import Slideshow from '../../Slideshow/Slideshow';
import Panorama from '../../Panorama/Panorama';
import Webview from '../../Webview/Webview';
import UnityElement from '../../UnityElement/UnityElement';
import Audio from '../../Audio/Audio';
import Movies from '../../Movies/Movies';

export default class CampaignContent extends React.Component<any, any> {

    constructor(props: any) {
        super(props);

        this.state = {
            files: [],
          };
    }
    
    public render() {

        
        return (
            <div className="grid100 campaignBox">
                <table className="grid100 table bp3-html-table bp3-html-table-bordered">
                    <tbody >
                        <tr>
                            <td> 
                                <button className="circle"> <span className="fontello icon-slideshow" /> </button> Slideshow     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Slideshow />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <button className="circle"> <span className="fontello icon-audio" /> </button> Audio     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Audio />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button> Video     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Movies />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <button className="circle"> <span className="fontello icon-3d" /> </button> Unity Element     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <UnityElement />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <button className="circle"> <span className="fontello icon-panorama" /> </button> Panorama     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Panorama />
                            </td>
                        </tr>
                        <tr>
                            <td> 
                                <button className="circle"> <span className="fontello icon-webview" /> </button> Webview     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <i className="fontello icon-trash" /> </button>
                                </span>
                                <Webview />
                            </td>
                        </tr>
                        <tr>
                            {this.state.files.length > 0 &&
                            <div>
                                {this.state.files.map((file:any) => (
                            <div>
                                <button className="circle"> <span className="bp3-icon-standard bp3-icon-globe-network" /> </button> Webview     
                                <span className="btnDelete">
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-double-caret-vertical" /> </button>
                                    <button className="bp3-button bp3-minimal"> <span className="bp3-icon-standard bp3-icon-trash" /></button>
                                </span>
                                <Audio />
                            </div>
                                ))}
                            </div>
                            }
                        </tr>
                        <tr>
                        <td> 
                            <button className="circle"> <span className="fontello icon-slideshow" /> </button>
                            <button className="circle"> <span className="fontello icon-audio" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="fontello icon-3d" /> </button>
                            <button className="circle"> <span className="fontello icon-panorama" /> </button>
                            <button className="circle"> <span className="fontello icon-webview" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                            <button className="circle"> <span className="bp3-icon-standard bp3-icon-play" /> </button>
                        </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        )
    }
}
