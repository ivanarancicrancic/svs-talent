import * as React from 'react';
import './Movies.css';

export default class MoviesConfig extends React.Component {

    public render() {
        return (
            <pre>
                <div className="videoBox">
                    <div className="bp3-select ">
                                <select>
                                    <option value="1">Normal </option>
                                    <option value="2">Green Screen </option>
                                    <option value="3">Sphere/360&#176; </option>
                                </select>
                            </div>
                    <table className="table bp3-html-table bp3-html-table-bordered bp3-interactive">
                        <tbody >
                            <tr>
                                <td>
                                    <form className="webviewForm">
                                        <input type="file" name="video" accept="video/mp4,video/x-m4v,video/*"  />
                                    </form>
                                </td>
                                <td><img src="https://dummyimage.com/60x50/000/fff" /></td>
                            </tr>
                            <tr>
                                <td>
                                    <form className="webviewForm">
                                        <input type="file" name="video" accept="video/mp4,video/x-m4v,video/*"  />
                                    </form>
                                </td>
                                <td><img src="https://dummyimage.com/60x50/000/fff" /></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </pre>
        )
    }

}