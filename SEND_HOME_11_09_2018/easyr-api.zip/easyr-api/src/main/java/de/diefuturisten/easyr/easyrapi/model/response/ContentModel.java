package de.diefuturisten.easyr.easyrapi.model.response;

import de.diefuturisten.easyr.easyrapi.entity.content.Content;

public class ContentModel {

    private String type;
    private long id;
    private String name;
    private int weight;

    public ContentModel() {

    }

    public ContentModel(Content content, String type) {
        this.id = content.getId();
        this.name = content.getName();
        this.weight = content.getWeight();

        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
