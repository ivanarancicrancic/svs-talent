package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

@Service
public class FileStorageService {

    public static String GetFileExtension(String name) {
        int lastIndexOf = name.lastIndexOf(".");
        if (lastIndexOf == -1) {
            return "";
        }
        return name.substring(lastIndexOf);
    }

    public File storeTemporaryFile(MultipartFile file) {

        String extension = GetFileExtension(file.getOriginalFilename());

        try {
            File tempFile = File.createTempFile("tmp-", extension);
            Files.copy(file.getInputStream(), tempFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return tempFile;
        } catch (IOException e) {
            return null;
        }
    }

}
