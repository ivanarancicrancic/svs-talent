package de.diefuturisten.easyr.easyrapi.service;

import com.amazonaws.services.s3.model.PutObjectResult;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.exceptions.InvalidTrackerImageException;
import de.diefuturisten.easyr.easyrapi.model.response.TrackerModel;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

@Service
@Transactional
public class TrackerService {

    private TrackerRepository trackerRepository;
    private VuforiaService vuforiaService;
    private S3Service s3Service;

    public TrackerService(TrackerRepository trackerRepository,
                          VuforiaService vuforiaService,
                          S3Service s3Service) {
        this.trackerRepository = trackerRepository;
        this.vuforiaService = vuforiaService;
        this.s3Service = s3Service;
    }

    public CompletableFuture<Tracker> createTrackerForCampaign(Campaign campaign, File trackerFile) {

        CompletableFuture<Tracker> result = new CompletableFuture<>();

        final Tracker tracker = new Tracker();
        tracker.setCampaign(campaign);

        String targetName = UUID.randomUUID().toString();

        try {
            vuforiaService.postTarget(targetName, trackerFile, tid -> {
                tracker.setVuforiaId(tid);
                String url = s3Service.uploadTracker(tid, trackerFile);
                tracker.setUrl(url);
                trackerRepository.save(tracker);
                result.complete(tracker);
            });
        } catch (InvalidTrackerImageException e) {
            result.completeExceptionally(e);
        }

        return result;
    }

    public Tracker editTracker(Tracker tracker, File trackerFile) {
        boolean result = vuforiaService.updateTarget(tracker.getVuforiaId(), trackerFile);
        if(result) {
            String url = s3Service.uploadTracker(tracker.getVuforiaId(), trackerFile);
            tracker.setUrl(url);
            return trackerRepository.save(tracker);
        } else {
            return null;
        }
    }

    public Optional<Tracker> getTrackerByVuforiaId(String vuforiaId) {
        return trackerRepository.findByVuforiaId(vuforiaId);
    }

    public Optional<Tracker> getTrackerById(long trackerId) {
        return trackerRepository.findById(trackerId);
    }

    public boolean deleteTracker(Tracker tracker) {
        boolean result = vuforiaService.deleteTarget(tracker.getVuforiaId());
        if(result) {
            s3Service.deleteTracker(tracker.getVuforiaId());
            trackerRepository.delete(tracker);
            return true;
        } else {
            return false;
        }
    }
}
