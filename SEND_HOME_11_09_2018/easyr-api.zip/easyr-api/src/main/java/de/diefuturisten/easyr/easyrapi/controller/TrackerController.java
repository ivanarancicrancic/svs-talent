package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.exceptions.MyFileNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.ValidationException;
import de.diefuturisten.easyr.easyrapi.model.response.TrackerModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.service.FileStorageService;
import de.diefuturisten.easyr.easyrapi.service.TrackerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api")
public class TrackerController {

    @Autowired
    private AuthenticationFacade authenticationFacade;

    @Autowired
    private TrackerService trackerService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private FileStorageService fileStorageService;

    public TrackerController(AuthenticationFacade authenticationFacade, TrackerService trackerService, CampaignService campaignService, FileStorageService fileStorageService) {
        this.authenticationFacade = authenticationFacade;
        this.trackerService = trackerService;
        this.campaignService = campaignService;
        this.fileStorageService = fileStorageService;
    }

    @PostMapping("/campaign/{campaignId}/tracker")
    @ResponseStatus(HttpStatus.CREATED)
    public DeferredResult<TrackerModel> createTracker(@PathVariable long campaignId, @RequestParam("file") MultipartFile multipartFile) throws IOException {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(campaignId).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        // allow only files with PNG or JPG extension
        String extension = FileStorageService.GetFileExtension(multipartFile.getOriginalFilename());
        if( !(extension.equals(".png") || extension.equals(".jpg")) ) {
            throw new ValidationException();
        }

        // 2MB limit
        if(multipartFile.getSize() > 2097152) {
            throw new ValidationException();
        }

        // save as temporary file
        File convertedFile = fileStorageService.storeTemporaryFile(multipartFile);
        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        // upload magic
        DeferredResult<TrackerModel> result = new DeferredResult<>();
        CompletableFuture<Tracker> newTracker = trackerService.createTrackerForCampaign(campaign, convertedFile);
        newTracker.thenApply(tracker ->
                result.setResult(new TrackerModel(tracker))
        ).exceptionally(result::setErrorResult);

        return result;
    }

    @PutMapping("/campaign/tracker/{trackerId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity updateTracker(@PathVariable long trackerId, @RequestParam("file") MultipartFile multipartFile) {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        // allow only files with PNG or JPG extension
        String extension = FileStorageService.GetFileExtension(multipartFile.getOriginalFilename());
        if( !(extension.equals(".png") || extension.equals(".jpg")) ) {
            throw new ValidationException();
        }

        // 2MB limit
        if(multipartFile.getSize() > 2097152) {
            throw new ValidationException();
        }

        // save as temporary file
        File convertedFile = fileStorageService.storeTemporaryFile(multipartFile);
        if(convertedFile == null) {
            throw new MyFileNotFoundException("");
        }

        Tracker editedTracker = trackerService.editTracker(tracker, convertedFile);

        if(editedTracker != null) {
            return ResponseEntity.ok(new TrackerModel(tracker));
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/campaign/tracker/{trackerId}")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity deleteTracker(@PathVariable long trackerId) {
        User user = authenticationFacade.getAuthenticatedUser();
        Tracker tracker = trackerService.getTrackerById(trackerId).orElseThrow(ForbiddenException::new);
        Campaign campaign = tracker.getCampaign();

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        boolean res = trackerService.deleteTracker(tracker);

        if(res) {
            return new ResponseEntity(HttpStatus.OK);
        } else {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }
    }


}
