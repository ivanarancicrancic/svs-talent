package de.diefuturisten.easyr.easyrapi.service;


import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class SlideshowContentService {
    // TODO: rewrite service
}