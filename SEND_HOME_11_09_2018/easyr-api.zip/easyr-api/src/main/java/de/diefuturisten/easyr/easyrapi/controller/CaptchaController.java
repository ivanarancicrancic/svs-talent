package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.model.response.CaptchaModel;
import de.diefuturisten.easyr.easyrapi.service.CaptchaService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
public class CaptchaController {

    private CaptchaService captchaService;

    public CaptchaController(CaptchaService captchaService) {
        this.captchaService = captchaService;
    }

    @RequestMapping(value = {"/captcha", "/captcha/{lastId}"}, method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public CaptchaModel createCaptcha(@PathVariable() Optional<String> lastId) {
        lastId.ifPresent(s -> captchaService.deleteCaptcha(s));
        return captchaService.generateCaptcha();
    }

}
