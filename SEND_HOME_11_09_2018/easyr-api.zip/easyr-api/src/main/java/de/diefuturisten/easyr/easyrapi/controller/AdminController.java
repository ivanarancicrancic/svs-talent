package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserModelForAdmin;
import de.diefuturisten.easyr.easyrapi.service.AdminService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.model.response.CouponModel;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import org.springframework.security.access.prepost.PreAuthorize;

@RestController
@RequestMapping("/api")
public class AdminController {

    private AdminService adminService;

    private CampaignService campaignService;

    private CampaignRuntimeService campaignRuntimeService;

    public AdminController(AdminService adminService, CampaignService campaignService, CampaignRuntimeService campaignRuntimeService) {
        this.adminService = adminService;
        this.campaignService = campaignService;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    // TODO: add check for admin role/rules to all requests

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/users", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<UserModelForAdmin> listUsers() {
        return adminService.getAllUsers().stream()
                .map(UserModelForAdmin::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/campaigns", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<CampaignOverviewModel> listAllCampaigns() {
        return campaignService.findAllCampaigns().stream()
                .map(CampaignOverviewModel::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/campaigns/{userId}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public List<CampaignOverviewModel> listCampaignsForUser(@PathVariable long userId) {
        User user = adminService.getUserByID(userId).orElseThrow(NoSuchElementException::new);
        return campaignService.getCampaignsForUser(user).stream()
                .map(CampaignOverviewModel::new)
                .collect(Collectors.toList());
    }

    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.ADMIN_RIGHT)
    @RequestMapping(value = "/admin/coupon", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.OK)
    public CouponModel createCouponForGivenUserAndPackage(@Valid @RequestBody CreateCouponAdminModel model) {
        Coupon coupon = campaignRuntimeService.createCoupon(model);
        return new CouponModel(coupon);
    }
}
