package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Coupon;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.CouponNotFoundException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoMoneyException;
import de.diefuturisten.easyr.easyrapi.exceptions.RuntimePackageNotFoundException;
import de.diefuturisten.easyr.easyrapi.model.request.BuyPackageRequestModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesCountModel;
import de.diefuturisten.easyr.easyrapi.model.response.UserPackagesModel;
import de.diefuturisten.easyr.easyrapi.repository.CouponRepository;
import de.diefuturisten.easyr.easyrapi.repository.PackageBuyRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import de.diefuturisten.easyr.easyrapi.repository.RuntimeRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCouponAdminModel;
import de.diefuturisten.easyr.easyrapi.model.response.CouponModel;

@Service
public class CampaignRuntimeService {

    private RuntimePackageRepository runtimePackageRepository;
    private CouponRepository couponRepository;
    private PackageBuyRepository packageBuyRepository;
    private RuntimeRepository runtimeRepository;
    private AdminService adminService;

    public CampaignRuntimeService(RuntimePackageRepository runtimePackageRepository, CouponRepository couponRepository, PackageBuyRepository packageBuyRepository, RuntimeRepository runtimeRepository, AdminService adminService) {
        this.runtimePackageRepository = runtimePackageRepository;
        this.couponRepository = couponRepository;
        this.packageBuyRepository = packageBuyRepository;
        this.runtimeRepository = runtimeRepository;
        this.adminService = adminService;
    }

    public List<RuntimePackage> getAllPackages() {
        return runtimePackageRepository.findAll();
    }

    private Coupon checkCoupon(User user, RuntimePackage runtimePackage, BuyPackageRequestModel model) throws CouponNotFoundException {
        if(model.hasCoupon()) {
            Coupon coupon;

            if(model.getCouponId() != null) {
                coupon = couponRepository.findById(model.getCouponId()).orElseThrow(CouponNotFoundException::new);
            } else {
                coupon = couponRepository.findFirstByCode(model.getCouponCode()).orElseThrow(CouponNotFoundException::new);
            }

            if(!coupon.getUser().equals(user)) {
                throw new CouponNotFoundException();
            }

            if(!coupon.getRuntimePackage().equals(runtimePackage)) {
                throw new CouponNotFoundException();
            }

            if(coupon.getPackageBuy() != null) {
                throw new CouponNotFoundException();
            }

            return coupon;
        }

        return null;
    }

    public Coupon createCoupon(CreateCouponAdminModel model) throws NoSuchElementException {
        Coupon coupon = new Coupon();
        Optional<User> user = adminService.getUserByID(model.getUserId());

        coupon.setUser(user.orElseThrow(NoSuchElementException::new));
        coupon.setRuntimePackage(runtimePackageRepository.findById(model.getPackageId()).orElseThrow(NoSuchElementException::new));

        coupon.setDiscountPercentage(model.getPercentage());
        return couponRepository.save(coupon);
    }



    public PackageBuy buyPackage(User user, BuyPackageRequestModel model) throws CouponNotFoundException, NoMoneyException, RuntimePackageNotFoundException {

        RuntimePackage runtimePackage = runtimePackageRepository.findById(model.getPackageId()).orElseThrow(RuntimePackageNotFoundException::new);
        Coupon coupon = checkCoupon(user, runtimePackage, model);

        if(coupon != null) {

            if(coupon.getDiscountPercentage() != 100) {
                throw new NoMoneyException();
            }

            PackageBuy packageBuy = new PackageBuy();
            packageBuy.setUser(user);
            packageBuy.setRuntimePackage(runtimePackage);
            packageBuy.setUsedCoupon(coupon);
            packageBuy.setBoughtAt(new Date());
            return packageBuyRepository.save(packageBuy);

        } else {
            throw new NoMoneyException();
        }

    }

    public PackageBuy userHasPackageAvailable(User user, long packageId) {
        RuntimePackage runtimePackage = runtimePackageRepository.findById(packageId).orElse(null);
        if(runtimePackage == null) {
            return null;
        } else {
            return packageBuyRepository.findFirstByUserAndRuntimePackageAndUsedOnRuntimeIsNull(user, runtimePackage).orElse(null);
        }
    }

    public UserPackagesModel getPackagesForUser(User user) {
        UserPackagesModel userPackagesModel = new UserPackagesModel();

        userPackagesModel.setAvailable(
                getAllPackages().stream()
                        .map( x -> {
                            long count = packageBuyRepository.countAvailable(user, x);
                            return new UserPackagesCountModel(x.getId(), x.getName(), count);
                        })
                        .collect(Collectors.toList())
        );


        userPackagesModel.setUsed(
                getAllPackages().stream()
                        .map( x -> {
                            long count = packageBuyRepository.countUsed(user, x);
                            return new UserPackagesCountModel(x.getId(), x.getName(), count);
                        })
                        .collect(Collectors.toList())
        );

        return userPackagesModel;
    }

    public Runtime createRuntime(Campaign campaign, PackageBuy availablePackage) {
        Runtime runtime = new Runtime();
        runtime.setCampaign(campaign);
        runtime.setPackageBuy(availablePackage);

        Date begin = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(begin);
        calendar.add(Calendar.DATE, availablePackage.getRuntimePackage().getLengthInDays());
        Date end = calendar.getTime();

        runtime.setBegin(begin);
        runtime.setEnd(end);

        availablePackage.setUsedOnRuntime(runtime);

        return runtimeRepository.save(runtime);
    }
}
