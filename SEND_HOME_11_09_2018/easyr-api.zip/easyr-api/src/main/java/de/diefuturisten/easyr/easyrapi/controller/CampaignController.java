package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.runtime.PackageBuy;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.exceptions.ForbiddenException;
import de.diefuturisten.easyr.easyrapi.exceptions.NoRuntimePackageAvailableException;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignOverviewModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.security.BuiltInRightsForPreAuthorizeHavingAuthority;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.stream.Stream;

@RestController
@RequestMapping("/api")
public class CampaignController {


    private CampaignService campaignService;
    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;

    public CampaignController(CampaignService campaignService, AuthenticationFacade authenticationFacade, CampaignRuntimeService campaignRuntimeService) {
        this.campaignService = campaignService;
        this.authenticationFacade = authenticationFacade;
        this.campaignRuntimeService = campaignRuntimeService;
    }

    @GetMapping("/campaigns")
    @ResponseStatus(HttpStatus.OK)
    @PreAuthorize(BuiltInRightsForPreAuthorizeHavingAuthority.CAMPAIGN_LIST)
    public Stream<CampaignOverviewModel> getAllCampaignsForUser() {
        User user = authenticationFacade.getAuthenticatedUser();

        return campaignService
                .getCampaignsForUser(user)
                .stream()
                .map(CampaignOverviewModel::new);
    }

    @GetMapping("/campaign/{id}")
    public CampaignDetailModel getCampaign(@PathVariable long id) throws ForbiddenException {
        User user = authenticationFacade.getAuthenticatedUser();
        Campaign campaign = campaignService.getCampaign(id).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        // TODO: include contact information?
        return new CampaignDetailModel(campaign);
    }


    @PostMapping("/campaign")
    @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
    public void createCampaign(@Valid @RequestBody CreateCampaignModel createCampaignModel) throws NoRuntimePackageAvailableException {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign createdCampaign = this.campaignService.createCampaignForUser(createCampaignModel, user);
//        return new CampaignDetailModel(createdCampaign);
    }

    @PutMapping("/campaign")
    @ResponseStatus(HttpStatus.OK)
    public CampaignDetailModel editCampaign(@Valid @RequestBody EditCampaignModel editCampaignModel) throws ForbiddenException {
        User user = authenticationFacade.getAuthenticatedUser();

        Campaign campaign = campaignService.getCampaign(editCampaignModel.getId()).orElseThrow(ForbiddenException::new);

        if(!campaign.getUser().equals(user)) {
            throw new ForbiddenException();
        }

        Campaign editedCampaign = campaignService.editCampaign(campaign, editCampaignModel);

        return new CampaignDetailModel(editedCampaign);
    }


}
