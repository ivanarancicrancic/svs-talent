package de.diefuturisten.easyr.easyrapi.unittest.controller;

import de.diefuturisten.easyr.easyrapi.controller.CampaignController;
import org.junit.Before;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;

public class CampaignControllerTest {

    private CampaignController campaignController;
    private CampaignService campaignService;
    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;
    private CampaignRepository campaignRepository;
    private ContactInformationRepository contactInformationRepository;
    private de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage runtimePackage;
    private EditCampaignModel campaign;
    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        campaignService = mock(CampaignService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        campaignRepository = mock(de.diefuturisten.easyr.easyrapi.repository.CampaignRepository.class);
        contactInformationRepository =  mock(de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository.class);
        runtimePackage =  mock(de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage.class);
        campaign = mock(EditCampaignModel.class);


        de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository runtimePackageRepository = mock(de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository.class);
        campaignController =new CampaignController(campaignService, authenticationFacade, campaignRuntimeService);

        CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
         campaignDetailModel.setName("CAMPAIGN LALA");
         campaignDetailModel.setDescription("This is campaign about...");

        mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void getAllCampaignsForUser() throws Exception {
        mockMvc.perform(get("/api/campaigns/")
                .contentType("application/json")).
                andExpect(status().isOk());

    }


    @Test
    public void getCampaign() throws Exception {
        mockMvc.perform(get("/api/campaign/" + 1L)
                .contentType("application/json")).
                andExpect(status().isForbidden());
    }


    @Test
    public void test_createCampaign() throws Exception {

        CreateCampaignModel createCampaignModel = new CreateCampaignModel();
        createCampaignModel.setPackageId(runtimePackage.getId());
        System.out.println(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                .writeValueAsString(createCampaignModel));
        mockMvc.perform((post("/api/campaign").
                contentType("application/json")).
                content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createCampaignModel))).
                andExpect(status().isCreated());
    }

    @Test
    public void test_editCampaignModel() throws Exception {
        EditCampaignModel editCampaignModel = new EditCampaignModel();
        editCampaignModel.setId(campaign.getId());
        editCampaignModel.setDescription(campaign.getDescription());
        editCampaignModel.setName(campaign.getName());
//        System.out.println("CAMPAIGN ID: " + editCampaignModel.getId());
//        System.out.println("BEFORE CALL: " + mapper.writeValueAsString(editCampaignModel));
        mockMvc.perform((put("/api/campaign").
                contentType("application/json")).
                content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL).writeValueAsString(editCampaignModel)));
    }

}
