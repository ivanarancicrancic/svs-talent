package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRespository;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@org.springframework.stereotype.Service
@org.springframework.transaction.annotation.Transactional
public class CampaignService {

    private final CampaignRespository campaignRepository;
    private final UserRepository userRepository;

    public CampaignService(de.diefuturisten.easyr.easyrapi.repository.CampaignRespository campaignRepository, de.diefuturisten.easyr.easyrapi.repository.UserRepository userRepository) {
        this.campaignRepository = campaignRepository;
        this.userRepository = userRepository;
    }

    public Campaign createCampaign(Campaign campaign) {
        System.out.println("Creating campaign with: "  + campaign.getUser().getName());
        campaignRepository.save(campaign);
        de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign savedCampaign = campaignRepository.findById(campaign.getId()).get();
        return savedCampaign;
    }

    public java.util.List<Campaign> getAllCampaigns() {
        return campaignRepository.findAll().stream().collect(java.util.stream.Collectors.toList());
    }

    public de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign updateCampaign(de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign campaign) {
        userRepository.save(campaign.getUser());
        campaignRepository.save(campaign);
        de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign savedCampaign = campaignRepository.findById(campaign.getId()).get();
        return savedCampaign;
    }

    public void deleteCampaign(Long id) {
        campaignRepository.deleteById(id);
    }

    public de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign findById(Long id) {
        java.util.Optional<de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign> campaignOptional = campaignRepository.findById(id);
        return campaignOptional.get();
    }
}
