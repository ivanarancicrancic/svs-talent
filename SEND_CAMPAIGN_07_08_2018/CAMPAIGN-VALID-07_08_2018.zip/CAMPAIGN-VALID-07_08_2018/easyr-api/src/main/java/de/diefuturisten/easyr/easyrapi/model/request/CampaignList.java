package de.diefuturisten.easyr.easyrapi.model.request;


import java.util.List;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

public class CampaignList {

    List<Campaign> campaigns;

    public List<Campaign> getCampaigns() {
        return campaigns;
    }

    public void setCampaigns(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignList(List<Campaign> campaigns) {
        this.campaigns = campaigns;
    }

    public CampaignList() {
    }
}
