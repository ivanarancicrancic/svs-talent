package de.diefuturisten.easyr.easyrapi.entity.campaign;

import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.user.User;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="campaigns")
public class Campaign {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_campaign")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @OneToMany(mappedBy="campaign")
    private List<Tracker> tracker = new ArrayList<>();

    @OneToMany(mappedBy="campaign")
    private List<Content> contents = new ArrayList<>();

    @ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="fk_contact", nullable = true)
    private ContactInformation contact;

    // getter & setter

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Tracker> getTracker() {
        return tracker;
    }

    public void setTracker(List<Tracker> tracker) {
        this.tracker = tracker;
    }

    public List<Content> getContents() {
        return contents;
    }

    public void setContents(List<Content> contents) {
        this.contents = contents;
    }

    public ContactInformation getContactInformation() {
        return contact;
    }

    public void setContactInformation(ContactInformation contactInformation) {
        this.contact = contactInformation;
    }
}
