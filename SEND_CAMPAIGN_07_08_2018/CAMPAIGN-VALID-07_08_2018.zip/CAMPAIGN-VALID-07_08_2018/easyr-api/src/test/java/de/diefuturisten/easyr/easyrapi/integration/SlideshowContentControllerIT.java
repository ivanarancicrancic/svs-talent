package de.diefuturisten.easyr.easyrapi.integration;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.controller.SlideshowContentController;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.model.request.SlideshowImageList;
import de.diefuturisten.easyr.easyrapi.repository.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import static org.junit.Assert.assertNotNull;




@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class SlideshowContentControllerIT {

    @Autowired
    private MockMvc mvc;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ContactInformationRepository contactInformationRepository;
    @Autowired
    private CampaignRepository campaignRepository;
    @Autowired
    private SlideshowContentRepository slideshowContentRepository;
    @Autowired
    private SlideshowImageRepository slideshowImageRepository;
    @Autowired
    private UserRoleRepository userRoleRepository;
    @Autowired
    private UserRightRepository userRightRepository;

    private Campaign campaign;
    private SlideshowContent slideshowContent;
    private SlideshowContent slideshowContentToPost;
    private SlideshowImage slideshowImage;

    private ObjectMapper mapper;
    private String token;


    @Before
    public void prepare(){
        IntegrationTestHelper.prepareUserData(userRepository, userRoleRepository, userRightRepository);
        IntegrationTestHelper.prepareContactData(contactInformationRepository);
        System.out.println("user's id is"+userRepository.findByEmail("ivica.taskovski@app-logik.de").get().getId());
        IntegrationTestHelper.prepareCampaignData(campaignRepository, userRepository.findByEmail("ivica.taskovski@app-logik.de"),contactInformationRepository.findByEmail("ivica.taskovski@app-logik.de") );
        System.out.println("so we have a campaign saved if a numbers shows after "+campaignRepository.findAll().size());
        this.campaign = campaignRepository.findAll().stream().findFirst().get();
        System.out.println("Campaign's number is"+campaignRepository.findAll().stream().findFirst().get().getId());
        this.slideshowContent = new SlideshowContent();
        slideshowContent.setCampaign(campaign);
        slideshowContent.setWeight(3);
        slideshowContent.setName("Neu Slideshow");
        slideshowContent.setExtendedTracking(true);
        slideshowContent.setPositionX(0);
        slideshowContent.setPositionY(1);
        slideshowContent.setPositionZ(0);
        slideshowContent.setRotationX(3);
        slideshowContent.setRotationY(2);
        slideshowContent.setRotationZ(1);
        slideshowContent.setRenderOnTrackingLost(false);

        this.slideshowContentToPost = new SlideshowContent();
        slideshowContentToPost.setCampaign(campaign);
        slideshowContentToPost.setWeight(3);
        slideshowContentToPost.setName("Zweite Slideshow");
        slideshowContentToPost.setExtendedTracking(true);
        slideshowContentToPost.setPositionX(0);
        slideshowContentToPost.setPositionY(1);
        slideshowContentToPost.setPositionZ(0);
        slideshowContentToPost.setRotationX(3);
        slideshowContentToPost.setRotationY(2);
        slideshowContentToPost.setRotationZ(1);
        slideshowContentToPost.setRenderOnTrackingLost(false);

        slideshowContentRepository.save(slideshowContent);
        System.out.println("we have a slideshow content if number shows after"+ slideshowContentRepository.findByName("Neu Slideshow").get().getId());
        this.slideshowImage = new SlideshowImage();
        slideshowImage.setSlideshow(slideshowContent);
        slideshowImage.setWeight(4);


        slideshowImageRepository.save(slideshowImage);
        System.out.println("we have a slideshow image saved if number shows after"+ slideshowImageRepository.findAll().stream().findFirst().get().getId());
        System.out.println("with a slide show id"+slideshowImage.getSlideshow().getId());

        mapper = new ObjectMapper();
        token = IntegrationTestHelper.createLoginToken(userRepository.findByEmail("ivica.taskovski@app-logik.de").get());


    }


    @Test
    @Transactional
    public void testContent(){
        slideshowContentRepository.findByName("Neu Slideshow").get();
    }

    @Test
    @Transactional
    public void testSlideById() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = get("/api/slideshows/"+slideshowContent.getId()).header("Content-Type", "application/json").header("Authorization", token);
        this.mvc.perform(request).andExpect(status().isOk());
    }

    @Test
    @Transactional
    public void testPostSlide() throws Exception{
        this.mvc.perform((post(SlideshowContentController.BASE_URL).
                contentType("application/json")).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
                        .writeValueAsString(slideshowContentToPost)))
                .andExpect(status().isForbidden());

    }
    @Test
    @Transactional
    public void testImagesBySlide() throws Exception{
        assertNotNull(token);
        MockHttpServletRequestBuilder request = get("/api/slideshows/"+slideshowContent.getId()+"/images").header("Content-Type", "application/json").header("Authorization", token);
        this.mvc.perform(request).andExpect(status().isOk());
    }
    @Test
    @Transactional
    public void postImageBySlide() throws Exception{
        assertNotNull(token);
        this.mvc.perform((post("/api/slideshows/"+slideshowImage.getSlideshow().getId()+"/images").
                contentType("application/json").header("Authorization", token)).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL).
                    writeValueAsString(slideshowImage)))
                .andExpect(status().isCreated());
    }


    @Test
    @Transactional
    public void deleteImageBySlide() throws Exception{
        assertNotNull(token);
        this.mvc.perform((delete("/api/slideshows/"+slideshowImage.getSlideshow().
                getId()+"/images/"+slideshowImage.getId())
                .contentType("application/json").header("Authorization", token)).content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .writeValueAsString(slideshowImage))).andExpect(status().isOk());
    }

    @After
    public void cleanup(){
        SlideshowImageList slideshowImageList = new SlideshowImageList(slideshowContentRepository.findById(slideshowImage.getSlideshow().getId()).get().getImages());
        System.out.println("how many images per slideshow we have, after what we've done "+slideshowImageList.getSlideshowImageList().size());


    }

}
