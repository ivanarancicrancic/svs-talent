package de.diefuturisten.easyr.easyrapi.unit_testing;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.service.CampaignService;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.CampaignRuntimeService;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.ContactInformationRepository;
import de.diefuturisten.easyr.easyrapi.entity.runtime.RuntimePackage;
import de.diefuturisten.easyr.easyrapi.model.request.EditCampaignModel;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import static org.mockito.Mockito.*;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignDetailModel;
import de.diefuturisten.easyr.easyrapi.repository.RuntimePackageRepository;
import de.diefuturisten.easyr.easyrapi.controller.CampaignController;
import de.diefuturisten.easyr.easyrapi.model.request.CreateCampaignModel;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.ArrayList;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.entity.content.Content;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.runtime.Runtime;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import java.util.Optional;

public class CampaignControllerTest {

//    @Autowired
    private MockMvc mockMvc;

    Campaign mockCampaign = new Campaign("CAMPAIGN LALA", "This is campaign about...");

    String exampleCampaignJson = "{\"name\":\"Spring\",\"description\":\"10Steps\"}";

    private CampaignController campaignController;
    //    @MockBean
    private CampaignService campaignService;
    private AuthenticationFacade authenticationFacade;
    private CampaignRuntimeService campaignRuntimeService;
    private CampaignRepository campaignRepository;
    private ContactInformationRepository contactInformationRepository;
    private RuntimePackage runtimePackage;
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        campaignService = mock(CampaignService.class);
        authenticationFacade = mock(AuthenticationFacade.class);
        campaignRuntimeService = mock(CampaignRuntimeService.class);
        campaignRepository = mock(CampaignRepository.class);
        contactInformationRepository =  mock(ContactInformationRepository.class);
        runtimePackage =  mock(RuntimePackage.class);

        RuntimePackageRepository runtimePackageRepository = mock(RuntimePackageRepository.class);
        campaignController =new CampaignController(campaignService, authenticationFacade,campaignRuntimeService);

        CampaignDetailModel campaignDetailModel = new CampaignDetailModel();
        campaignDetailModel.setName("CAMPAIGN LALA");
        campaignDetailModel.setDescription("This is campaign about...");

        mockMvc = MockMvcBuilders.standaloneSetup(campaignController).build();
        mapper= new ObjectMapper();
    }

    @Test
    public void getDetailsForCampaign() throws Exception {
        Campaign mockCampaign = new Campaign("CAMPAIGN LALA", "This is campaign about...");

        User user = new User();
        user.setFirstname("Ivana");
        user.setLastname("Rancic");
        user.setActive(true);
        user.setPassword("boom");
        user.setEmail("ivana.rancic@app-logik.de");
        user.setGender(true);
        user.setLanguage("en");

        ContactInformation contactInformation = new ContactInformation();
        contactInformation.setZip("1000");
        contactInformation.setNumber("723893589");
        contactInformation.setHomepage("sth");
        contactInformation.setCompany("Logik");
        contactInformation.setEmail("ivana.rancic@app-logik.de");
        contactInformation.setCity("Skopje");
        contactInformation.setAddress("address1");
        contactInformation.setAddress2("address 2...");
        contactInformation.setName("Name");

        List<Tracker> trackerList = new ArrayList<>();

        Tracker tracker = new Tracker();
        tracker.setUrl("URL tracker");
        tracker.setVuforiaId("vuf");
        tracker.setId(1L);

        trackerList.add(tracker);
        tracker.setUrl("URL tracker2");
        tracker.setVuforiaId("vuf2");
        tracker.setId(2L);

        trackerList.add(tracker);
        tracker.setUrl("URL tracker3");
        tracker.setVuforiaId("vuf3");
        tracker.setId(3L);

        trackerList.add(tracker);

        List<Content> contentList = new ArrayList<>();
        MovieContent movie = new MovieContent();
        movie.setWeight(1);
        movie.setRotationX(1);
        movie.setRotationY(2);
        movie.setPositionZ(3);
        movie.setRotationY(1);
        movie.setRotationY(2);
        movie.setRotationZ(3);
        movie.setScaleX(1);
        movie.setScaleY(2);
        movie.setScaleZ(3);
        movie.setType(MovieContent.Type.GREENSCREEN);
        movie.setName("My movie");
        movie.setRenderOnTrackingLost(true);
        movie.setDownload(false);
        movie.setSeekbar(true);
        movie.setExtendedTracking(true);
        movie.setUrl("some url..");
        movie.setId(1L);

        Content content = movie;
        contentList.add(content);

        AudioContent audio = new AudioContent();
        audio.setId(2L);
        audio.setUrl("Audio url");
        audio.setWeight(2);
        audio.setRenderOnTrackingLost(true);
        audio.setName("My audio");

        content = audio;
        contentList.add(content);
        mockCampaign.setContents(contentList);

        Runtime runtime = new Runtime();
        runtime.setId(3L);
        runtime.setBegin(new java.util.Date());
        runtime.setEnd(new java.util.Date());
        List<Runtime> runtimeList = new java.util.ArrayList<>();
        runtimeList.add(runtime);

        mockCampaign.setUser(user);
        mockCampaign.setContactInformation(contactInformation);
        mockCampaign.setTracker(trackerList);
        mockCampaign.setContents(contentList);
        mockCampaign.setRuntimes(runtimeList);
        mockCampaign.setId(1L);

        Mockito.when(
                authenticationFacade.getAuthenticatedUser()).thenReturn(user);

        Mockito.when(
                campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaign/" + 1).accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        System.out.println(result.getResponse());

//        String expected = "{name:CAMPAIGN LALA,description:This is campaign about...,{firstname:Ivana,lastname:Rancic,active:true,password:boom,email:ivana.rancic@app-logik.de,gender:true,language:en}}";
//        org.skyscreamer.jsonassert.JSONAssert.assertEquals(expected, result.getResponse()
//                .getContentAsString(), false);
    }


    @Test
    public void getAllCampaignsForUser() throws Exception {
        Campaign mockCampaign = new Campaign("CAMPAIGN LALA", "This is campaign about...");
        Campaign mockCampaign1 = new Campaign("CAMPAIGN LALA", "This is campaign about...");
        Campaign mockCampaign2 = new Campaign("CAMPAIGN LALA", "This is campaign about...");
        List<Campaign> campaignList = new java.util.ArrayList<>();
        campaignList.add(mockCampaign);
        campaignList.add(mockCampaign1);
        campaignList.add(mockCampaign2);


        User user = new User();
        user.setFirstname("Ivana");
        user.setLastname("Rancic");
        user.setActive(true);
        user.setPassword("boom");
        user.setEmail("ivana.rancic@app-logik.de");
        user.setGender(true);
        user.setLanguage("en");

        mockCampaign.setUser(user);

        Mockito.when(
                authenticationFacade.getAuthenticatedUser()).thenReturn(user);

        Mockito.when(
                campaignService.getCampaignsForUser(Mockito.any(User.class))).thenReturn(campaignList);

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
                "/api/campaigns").accept(
                MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        System.out.println(result.getResponse());
        String expected = "[{name:CAMPAIGN LALA,description:This is campaign about...},{name:CAMPAIGN LALA,description:This is campaign about...},{name:CAMPAIGN LALA,description:This is campaign about...}]";
//        JSONAssert.assertEquals(expected, result.getResponse().getContentAsString(), false);
    }


    @Test
    public void createCampaign() throws Exception {
        Campaign mockCampaign = new Campaign("CAMPAIGN NAME", "CAMPAIGN DESCR");

        CreateCampaignModel createCampaignModel = new CreateCampaignModel();
        createCampaignModel.setPackageId(runtimePackage.getId());

        User user = new User();
        user.setFirstname("Ivana");
        user.setLastname("Rancic");
        user.setActive(true);
        user.setPassword("boom");
        user.setEmail("ivana.rancic@app-logik.de");
        user.setGender(true);
        user.setLanguage("en");

        // campaignService.createCampaignForUser to respond back with mockCampaign
        Mockito.when(
                campaignService.createCampaignForUser(Mockito.any(CreateCampaignModel.class), Mockito.any(User.class))).thenReturn(mockCampaign);

        Mockito.when(
                authenticationFacade.getAuthenticatedUser()).thenReturn(user);

        // Send campaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .post("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(createCampaignModel))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();

        MockHttpServletResponse response = result.getResponse();

        assertEquals(HttpStatus.CREATED.value(), response.getStatus());

    }


    @Test
    public void editCampaign() throws Exception {

        EditCampaignModel campaignEdit = new EditCampaignModel();
        campaignEdit.setId(1L);
        campaignEdit.setName("Edited campaign name");
        campaignEdit.setDescription("Some edited campaign desc..");

        Campaign mockCampaign = new Campaign("CAMPAIGN NAME", "CAMPAIGN DESCR");
        User user = new User();
        user.setFirstname("Ivana");
        user.setLastname("Rancic");
        user.setActive(true);
        user.setPassword("boom");
        user.setEmail("ivana.rancic@app-logik.de");
        user.setGender(true);
        user.setLanguage("en");

        mockCampaign.setUser(user);

        ContactInformation contactInformation = new ContactInformation();
        contactInformation.setZip("1000");
        contactInformation.setNumber("723893589");
        contactInformation.setHomepage("sth");
        contactInformation.setCompany("Logik");
        contactInformation.setEmail("ivana.rancic@app-logik.de");
        contactInformation.setCity("Skopje");
        contactInformation.setAddress("address1");
        contactInformation.setAddress2("address 2...");
        contactInformation.setName("Name");

        mockCampaign.setContactInformation(contactInformation);

        List<Tracker> trackerList = new ArrayList<>();
        Tracker tracker = new Tracker();
        tracker.setUrl("URL tracker");
        tracker.setVuforiaId("vuf");
        tracker.setId(1L);
        trackerList.add(tracker);

        tracker.setUrl("URL tracker2");
        tracker.setVuforiaId("vuf2");
        tracker.setId(2L);
        trackerList.add(tracker);

        tracker.setUrl("URL tracker3");
        tracker.setVuforiaId("vuf3");
        tracker.setId(3L);
        trackerList.add(tracker);

        mockCampaign.setTracker(trackerList);

        List<Content> contentList = new ArrayList<>();
        MovieContent movie = new MovieContent();
        movie.setWeight(1);
        movie.setRotationX(1);
        movie.setRotationY(2);
        movie.setPositionZ(3);
        movie.setRotationY(1);
        movie.setRotationY(2);
        movie.setRotationZ(3);
        movie.setScaleX(1);
        movie.setScaleY(2);
        movie.setScaleZ(3);
        movie.setType(MovieContent.Type.GREENSCREEN);
        movie.setName("My movie");
        movie.setRenderOnTrackingLost(true);
        movie.setDownload(false);
        movie.setSeekbar(true);
        movie.setExtendedTracking(true);
        movie.setUrl("some url..");
        movie.setId(1L);

        Content content = movie;
        contentList.add(content);

        AudioContent audio = new AudioContent();
        audio.setId(2L);
        audio.setUrl("Audio url");
        audio.setWeight(2);
        audio.setRenderOnTrackingLost(true);
        audio.setName("My audio");

        content = audio;
        contentList.add(content);
        mockCampaign.setContents(contentList);

        Runtime runtime = new Runtime();
        runtime.setId(3L);
        runtime.setBegin(new java.util.Date());
        runtime.setEnd(new java.util.Date());
        List<Runtime> runtimeList = new java.util.ArrayList<>();
        runtimeList.add(runtime);

        mockCampaign.setRuntimes(runtimeList);

        mockCampaign.setId(1L);

        Mockito.when(
                authenticationFacade.getAuthenticatedUser()).thenReturn(user);

        Mockito.when(
                campaignService.getCampaign(Mockito.anyLong())).thenReturn(Optional.of(mockCampaign));

        // campaignService.editCampaign to respond back with mockCampaign
        Mockito.when(
                campaignService.editCampaign(Mockito.any(Campaign.class), Mockito.any(EditCampaignModel.class))).thenReturn(mockCampaign);

        // Send editCampaign as body to /api/campaign
        RequestBuilder requestBuilder = MockMvcRequestBuilders
                .put("/api/campaign")
                .accept(MediaType.APPLICATION_JSON).content(mapper.setSerializationInclusion(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
                        .writeValueAsString(campaignEdit))
                .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder).andReturn();
        MockHttpServletResponse response = result.getResponse();
        assertEquals(HttpStatus.OK.value(), response.getStatus());

    }


}
