package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.model.response.UserModel;
import de.diefuturisten.easyr.easyrapi.security.AuthenticationFacade;
import de.diefuturisten.easyr.easyrapi.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {

    private AuthenticationFacade authenticationFacade;
    private UserService userService;

    public UserController(AuthenticationFacade authenticationFacade, UserService userService) {
        this.userService = userService;
        this.authenticationFacade = authenticationFacade;
    }

    @RequestMapping(value = "/user", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public UserModel createAccount() {
        return new UserModel(authenticationFacade.getAuthenticatedUser());
    }

}
