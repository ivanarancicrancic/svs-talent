package de.diefuturisten.easyr.easyrapi.model.request;

import de.diefuturisten.easyr.easyrapi.model.response.CaptchaResponseModel;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class ForgotPasswordModel {

    @NotBlank
    @Email
    private String email;

    @NotNull
    private CaptchaResponseModel captcha;

    public ForgotPasswordModel() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CaptchaResponseModel getCaptcha() {
        return captcha;
    }

    public void setCaptcha(CaptchaResponseModel captcha) {
        this.captcha = captcha;
    }
}
