package de.diefuturisten.easyr.easyrapi.entity.runtime;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="runtimes")
public class Runtime {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_runtime")
    private long id;

    @ManyToOne()
    @JoinColumn(name = "fk_campaign", nullable = false)
    private Campaign campaign;

    @OneToOne()
    @JoinColumn(name = "fk_packagebuy")
    private PackageBuy packageBuy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start", nullable = false)
    private Date begin;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ende", nullable = false)
    private Date end;

    public Runtime() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public Date getBegin() {
        return begin;
    }

    public void setBegin(Date begin) {
        this.begin = begin;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

    public PackageBuy getPackageBuy() {
        return packageBuy;
    }

    public void setPackageBuy(PackageBuy packageBuy) {
        this.packageBuy = packageBuy;
    }
}
