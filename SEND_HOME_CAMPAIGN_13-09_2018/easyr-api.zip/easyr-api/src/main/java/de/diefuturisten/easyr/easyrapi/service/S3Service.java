package de.diefuturisten.easyr.easyrapi.service;

import com.amazonaws.HttpMethod;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.File;
import java.net.URL;
import java.nio.file.Path;
import java.util.UUID;

@Service
public class S3Service {

    private AmazonS3 s3client;

    @Value("${jsa.s3.region}")
    private String s3Region;

    @Value("${jsa.s3.bucket}")
    private String bucketName;

    public S3Service(AmazonS3 s3client) {
        this.s3client = s3client;
    }

    public URL signUploadRequest() {

        // Set the pre-signed URL to expire after one hour.
        java.util.Date expiration = new java.util.Date();
        long expTimeMillis = expiration.getTime();
        expTimeMillis += 1000 * 60 * 60;
        expiration.setTime(expTimeMillis);

        // Generate the pre-signed URL.
        GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, UUID.randomUUID().toString())
                .withMethod(HttpMethod.PUT)
                .withExpiration(expiration);
        URL url = s3client.generatePresignedUrl(generatePresignedUrlRequest);

        return url;
    }

    private String getTrackerUploadPath(String vuforiaId) {
        return new File("tracker", vuforiaId).toString();
    }

    public String uploadTracker(String vuforiaId, File file) {
        PutObjectRequest request = new PutObjectRequest(bucketName, getTrackerUploadPath(vuforiaId), file);
        s3client.putObject(request);
        String result = String.format("https://s3.%s.amazonaws.com/%s/tracker/%s", s3Region, bucketName, vuforiaId);
        return result;
    }

    public void deleteTracker(String vuforiaId) {
        DeleteObjectRequest request = new DeleteObjectRequest(bucketName, getTrackerUploadPath(vuforiaId));
        s3client.deleteObject(request);
    }

}
