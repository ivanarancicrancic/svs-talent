package de.diefuturisten.easyr.easyrapi.unittest.controller;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import de.diefuturisten.easyr.easyrapi.controller.SlideshowContentController;
import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.comparesEqualTo;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

import static org.mockito.Mockito.mock;


public class SlideshowContentControllerTest {

    private SlideshowContentController slideshowContentController;
    private SlideshowContentService slideshowContentService;
    private MockMvc mockMvc;
    private ObjectMapper mapper;

    @Before
    public void setUp() throws Exception {
        slideshowContentService = mock(SlideshowContentService.class);
        slideshowContentController =new SlideshowContentController(slideshowContentService);
        mockMvc = MockMvcBuilders.standaloneSetup(slideshowContentController).build();
        mapper= new ObjectMapper();

    }

    @Test
    public void getAllSlideShows() throws Exception {
        mockMvc.perform(get(SlideshowContentController.BASE_URL)
                .contentType("application/json")).
                andExpect(status().isOk());
    }
    @Test
    public void test_default() throws Exception {
        SlideshowContent slideshowContent = new SlideshowContent();
        slideshowContent.setName("ErsteSlideShow");
        //slideshowContent.setWeight(12);
        System.out.println(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .writeValueAsString(slideshowContent));
        mockMvc.perform((post(SlideshowContentController.BASE_URL).
                contentType("application/json")).
                content(mapper.setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .writeValueAsString(slideshowContent))).
                andExpect(status().isCreated()).
                andExpect(jsonPath("$.weight",comparesEqualTo(0)));
    }
}