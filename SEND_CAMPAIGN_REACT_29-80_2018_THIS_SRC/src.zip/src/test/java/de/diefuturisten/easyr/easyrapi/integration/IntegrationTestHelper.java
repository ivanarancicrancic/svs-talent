package de.diefuturisten.easyr.easyrapi.integration;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.campaign.ContactInformation;
import de.diefuturisten.easyr.easyrapi.entity.content.AudioContent;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.entity.content.PanoramaContent;
import de.diefuturisten.easyr.easyrapi.entity.content.WebviewContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SphereContent;
import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRight;
import de.diefuturisten.easyr.easyrapi.entity.user.UserRole;
import de.diefuturisten.easyr.easyrapi.repository.*;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.EXPIRATION_TIME;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.SECRET;
import static de.diefuturisten.easyr.easyrapi.security.SecurityConstants.TOKEN_PREFIX;

public class IntegrationTestHelper {
        private static  User user;
        private static ContactInformation contactInfo;

    public static String createLoginToken(User user){
        Date expirationTime = new Date(System.currentTimeMillis() + EXPIRATION_TIME);
        String token = Jwts.builder().
                setSubject(user.getUsername()).
                setExpiration(expirationTime).
                signWith(SignatureAlgorithm.HS512, SECRET.getBytes()).
                compact();
        return  TOKEN_PREFIX + token;
    }

    public static void prepareUserData(UserRepository userRepository, UserRoleRepository userRoleRepository, UserRightRepository userRightRepository){
        UserRight userRight = new UserRight("Admin role");
        UserRight userRight1 = new UserRight("CAMPAIGN_CREATE");
        UserRight updateUserRight = new UserRight("CAMPAIGN_EDIT");
        UserRight listMoviesRight = new UserRight("MOVIES_LIST");
        UserRight listAudiosRight = new UserRight("AUDIO_LIST");
        UserRight listSphereRight = new UserRight("SPHERE_LIST");
        UserRight listPanoramasRight = new UserRight("PANORAMA_LIST");
        UserRight listSlideshowsRight = new UserRight("SLIDESHOWS_LIST");
        UserRight viewCampaignRight = new UserRight("CAMPAIGN_VIEW");

        userRightRepository.save(userRight);
        userRightRepository.save(userRight1);
        userRightRepository.save(updateUserRight);
        userRightRepository.save(listMoviesRight);
        userRightRepository.save(listAudiosRight);
        userRightRepository.save(listPanoramasRight);
        userRightRepository.save(listSlideshowsRight);
        userRightRepository.save(listSphereRight);
        userRightRepository.save(viewCampaignRight);

        UserRole userRole1 = new UserRole("User");
        userRole1.addRight(userRight);
        userRole1.addRight(userRight1);
        userRole1.addRight(updateUserRight);
        userRole1.addRight(listMoviesRight);
        userRole1.addRight(listAudiosRight);
        userRole1.addRight(listPanoramasRight);
        userRole1.addRight(listSlideshowsRight);
        userRole1.addRight(listSphereRight);
        userRole1.addRight(viewCampaignRight);

        userRoleRepository.save(userRole1);

        UserRole userRole = new UserRole("Admin");
        userRole.addRight(userRight);
        userRoleRepository.save(userRole);
        User user = new User();
        user.setFirstname("Ivica");
        user.setLastname("Taskovski");
        user.setEmail("ivica.taskovski@app-logik.de");
        user.setGender(true);
        user.setActive(false);
        //user.setId(new Long(1));
        user.addRole(userRole);
        user.addRole(userRole1);
        user.setPassword("$2a$04$ZVfI05WO6.Dz5JrXL2HJT.uROP4TFstjI/lZsJVY7bDirAmRRuLcq");
        user.setLanguage("EN");

        userRepository.save(user);
    }
    public static void prepareContactData(ContactInformationRepository contactInformationRepository){
        ContactInformation contactInfo = new ContactInformation();
        contactInfo.setCity("Berlin");
        contactInfo.setCompany("some-company");
        contactInfo.setEmail("ivica.taskovski@app-logik.de");
        contactInfo.setHomepage("companyInBerlin.de");
        contactInfo.setAddress("Klingeln Strasse");
        contactInfo.setAddress2("Blingeln Strasse");
        contactInfo.setNumber("+3456789012");
        contactInfo.setZip("1234");

        contactInformationRepository.save(contactInfo);

    }

    public static void prepareCampaignData(CampaignRepository campaignRepository, Optional<User> userOptional, Optional<ContactInformation> contactInformationOptional){

        Campaign campaign = new Campaign();
        campaign.setContactInformation(contactInformationOptional.get());
        campaign.setUser(userOptional.get());
        //campaign.setId(new Long(1));

        campaignRepository.save(campaign);
    }

    public static void prepareAudioData(CampaignRepository campaignRepository, AudioContentRepository audioContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        AudioContent audioContent = new AudioContent();
        audioContent.setName("New Audio content");
        audioContent.setUrl("giveitatry.mak");
        audioContent.setRenderOnTrackingLost(true);
        audioContent.setCampaign(campaign);
        audioContent.setWeight(5);

        AudioContent audioContentToSave = new AudioContent();
        audioContentToSave.setName("Audio To Save");
        audioContentToSave.setUrl("giveitatry.mak");
        audioContentToSave.setRenderOnTrackingLost(true);
        audioContentToSave.setCampaign(campaign);
        audioContentToSave.setWeight(5);
        audioContentRepository.saveAll(new ArrayList<>(Arrays.asList(audioContent, audioContentToSave)));
    }

    public static  void prepareWebvies(CampaignRepository campaignRepository, WebviewContentRepository webviewContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        WebviewContent webviewContent = new WebviewContent();
        webviewContent.setUrl("giveitatry.mak");
        webviewContent.setName("New webView");
        webviewContent.setCampaign(campaign);
        webviewContent.setWeight(1);

        WebviewContent webviewContentToSave = new WebviewContent();
        webviewContentToSave.setUrl("giveitatry.mak");
        webviewContentToSave.setName("webView to be saved");
        webviewContentToSave.setCampaign(campaign);
        webviewContentToSave.setWeight(1);

        webviewContentRepository.saveAll(new ArrayList<>(Arrays.asList(webviewContent, webviewContentToSave)));
    }

    public static void praparePanoramas(CampaignRepository campaignRepository, PanoramaContentRepository panoramaContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        PanoramaContent panoramaContent = new PanoramaContent();
        panoramaContent.setType(PanoramaContent.Type.X180);
        panoramaContent.setUrl("giveitatry.mak");
        panoramaContent.setName("New Panorama");
        panoramaContent.setWeight(4);
        panoramaContent.setCampaign(campaign);

        PanoramaContent panoramaContentToSave = new PanoramaContent();
        panoramaContentToSave.setType(PanoramaContent.Type.X180);
        panoramaContentToSave.setUrl("giveitatry.mak");
        panoramaContentToSave.setName("Panorama to be saved");
        panoramaContentToSave.setWeight(4);
        panoramaContentToSave.setCampaign(campaign);

        panoramaContentRepository.saveAll(new ArrayList<>(Arrays.asList(panoramaContent, panoramaContentToSave)));
    }

    public static void prepareMovies(CampaignRepository campaignRepository, MovieContentRepository movieContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        MovieContent movieContent = new MovieContent();
        movieContent.setDownload(false);
        movieContent.setExtendedTracking(true);
        movieContent.setPositionX(0);
        movieContent.setPositionY(1);
        movieContent.setPositionZ(0);
        movieContent.setRenderOnTrackingLost(true);
        movieContent.setRotationX(0);
        movieContent.setName("new movie");
        movieContent.setRotationY(1);
        movieContent.setPositionZ(0);
        movieContent.setType(MovieContent.Type.NORMAL);
        movieContent.setScaleX(0);
        movieContent.setScaleY(1);
        movieContent.setScaleZ(0);
        movieContent.setSeekbar(false);
        movieContent.setCampaign(campaign);
        movieContent.setUrl("giveitatry.mak");

        MovieContent movieContentToSave = new MovieContent();
        movieContentToSave.setDownload(false);
        movieContentToSave.setExtendedTracking(true);
        movieContentToSave.setPositionX(0);
        movieContentToSave.setPositionY(1);
        movieContentToSave.setPositionZ(0);
        movieContentToSave.setRenderOnTrackingLost(true);
        movieContentToSave.setRotationX(0);
        movieContentToSave.setName("movie to save");
        movieContentToSave.setRotationY(1);
        movieContentToSave.setPositionZ(0);
        movieContentToSave.setType(MovieContent.Type.NORMAL);
        movieContentToSave.setScaleX(0);
        movieContentToSave.setScaleY(1);
        movieContentToSave.setScaleZ(0);
        movieContentToSave.setSeekbar(false);
        movieContentToSave.setCampaign(campaign);
        movieContentToSave.setUrl("giveitatry.mak");

        movieContentRepository.saveAll(new ArrayList<>(Arrays.asList(movieContent, movieContentToSave)));

    }

    public static  void prepareSpheres(CampaignRepository campaignRepository, SphereContentRepository sphereContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        SphereContent sphereContent = new SphereContent();
        sphereContent.setCampaign(campaign);
        sphereContent.setName("new sphere");
        sphereContent.setWeight(4);
        sphereContent.setUrl("giveitatry.mak");

        SphereContent sphereContentToSave = new SphereContent();
        sphereContentToSave.setCampaign(campaign);
        sphereContentToSave.setName("sphere to save");
        sphereContentToSave.setWeight(4);
        sphereContentToSave.setUrl("giveitatry.mak");
        sphereContentRepository.saveAll(new ArrayList<>(Arrays.asList(sphereContent, sphereContentToSave)));
    }

    public static void prepareUnities(CampaignRepository campaignRepository, UnityContentRepository unityContentRepository){
        Campaign campaign = campaignRepository.findAll().stream().findFirst().get();
        UnityContent unityContent = new UnityContent();
        unityContent.setAndroidUrl("android-url");
        unityContent.setExtendedTracking(true);
        unityContent.setIosUrl("ios-url");
        unityContent.setPositionX(0);
        unityContent.setPositionY(1);
        unityContent.setRotationZ(0);
        unityContent.setPositionZ(0);
        unityContent.setRotationX(0);
        unityContent.setRotationY(1);
        unityContent.setRenderOnTrackingLost(false);
        unityContent.setScaleX(0);
        unityContent.setScaleY(1);
        unityContent.setScaleZ(0);
        unityContent.setName("new Unity");
        unityContent.setWeight(3);
        unityContent.setCampaign(campaign);

        UnityContent unityContentToSave = new UnityContent();
        unityContentToSave.setAndroidUrl("android-url");
        unityContentToSave.setExtendedTracking(true);
        unityContentToSave.setIosUrl("ios-url");
        unityContentToSave.setPositionX(0);
        unityContentToSave.setPositionY(1);
        unityContentToSave.setRotationZ(0);
        unityContentToSave.setPositionZ(0);
        unityContentToSave.setRotationX(0);
        unityContentToSave.setRotationY(1);
        unityContentToSave.setRenderOnTrackingLost(false);
        unityContentToSave.setScaleX(0);
        unityContentToSave.setScaleY(1);
        unityContentToSave.setScaleZ(0);
        unityContentToSave.setName("Unity to save");
        unityContentToSave.setWeight(3);
        unityContentToSave.setCampaign(campaign);

        unityContentRepository.saveAll(new ArrayList<>(Arrays.asList(unityContent, unityContentToSave)));
    }



    public static void cleanupUserData(UserRepository userRepository){
        userRepository.deleteAll();
        userRepository.flush();
    }

    public static void cleanupContactData(ContactInformationRepository contactInformationRepository){
        contactInformationRepository.deleteAll();
        contactInformationRepository.flush();
    }

    public static void cleanupCampaign(CampaignRepository campaignRepository){
        campaignRepository.deleteAll();
        campaignRepository.flush();
    }
}
