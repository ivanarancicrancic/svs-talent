package de.diefuturisten.easyr.easyrapi.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import de.diefuturisten.easyr.easyrapi.repository.TrackerRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import java.util.List;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;

@org.springframework.stereotype.Service
@org.springframework.transaction.annotation.Transactional
public class TrackerService {

    private final TrackerRepository trackerRepository;
    private final CampaignRepository campaignRepository;

    public TrackerService(de.diefuturisten.easyr.easyrapi.repository.TrackerRepository trackerRepository, de.diefuturisten.easyr.easyrapi.repository.CampaignRepository campaignRepository) {
        this.trackerRepository = trackerRepository;
        this.campaignRepository = campaignRepository;
    }

    public java.util.List<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> getAllTrackers() {
        return trackerRepository.findAll().stream().collect(java.util.stream.Collectors.toList());
    }

    public de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker createTrackerToCampaign(Long campaignId, de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker tracker) {
        tracker.setCampaign(campaignRepository.findById(campaignId).get());
        trackerRepository.save(tracker);
        System.out.println("Tracker saved");

        de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker savedTracker = trackerRepository.findById(tracker.getId()).get();
        System.out.println("ID of saved Tracker: " + tracker.getId());
        System.out.println("ID of saved Tracker vuf: " + tracker.getVuforiaId());
        System.out.println("Saved Tracker URL: " + tracker.getUrl());
        System.out.println("ID of saved Tracker Campaign: " + tracker.getCampaign().getId());

        de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign campaign = campaignRepository.findById(campaignId).get();
        System.out.println("ID of found campaign: " + campaign.getId());
        campaign.getTracker().add(tracker);
        campaign.setTracker(campaign.getTracker());
        System.out.println("Updated tracker list of campaign: ");
        for(de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker t: campaign.getTracker()){
            System.out.println("Tracker id: " + t.getId());
        }

        return tracker;
    }


    public de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker updateTracker(de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker tracker) {
        String status = "updating tracker";
        System.out.println(status);
        trackerRepository.save(tracker);
        return tracker;
    }

    public void deleteTracker(Long id) {
        String status = "deleting tracker";
        System.out.println(status);
        trackerRepository.deleteById(id);

    }

    public de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker findById(Long id) {
        String status = "getting tracker";
        System.out.println(status);
        java.util.Optional<de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker> trackerOptional = trackerRepository.findById(id);
        return trackerOptional.get();
    }


}
