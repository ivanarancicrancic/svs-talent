package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.service.MovieContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/campaigns/")
public class MovieContentController {

    private MovieContentService movieContentService;

    public MovieContentController(MovieContentService movieContentService) {
        this.movieContentService = movieContentService;
    }
    @GetMapping("{movieId}")
    @ResponseStatus(HttpStatus.OK)
    public MovieContent findMovieById(@PathVariable long movieId){
       return movieContentService.findMovieById(movieId);
    }

    @PostMapping({"{id}/movies/"})
    @ResponseStatus(HttpStatus.CREATED)
    public MovieContent createMovieByCampaign(@PathVariable long id, @RequestBody MovieContent movieContent){
        return movieContentService.createMovieByCampaign(id, movieContent);
    }
    @PutMapping({"{id}/movies/{movieId}"})
    @ResponseStatus(HttpStatus.OK)
    public  MovieContent modifyMovieByCampaign(@PathVariable long id, @RequestBody MovieContent movieContent, @PathVariable long movieId){
        return movieContentService.modifyMovieByCampaign(id, movieContent, movieId);
    }
    @DeleteMapping("{id}/movies/{movieId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteMovieByCampaign(@PathVariable long id, @PathVariable long movieId){
        movieContentService.deleteMovieByCampaign(id, movieId);
    }

}
