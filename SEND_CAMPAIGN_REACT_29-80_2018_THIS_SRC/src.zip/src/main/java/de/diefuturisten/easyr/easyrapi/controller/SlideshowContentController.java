package de.diefuturisten.easyr.easyrapi.controller;

import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent;
import de.diefuturisten.easyr.easyrapi.entity.content.SlideshowImage;
import de.diefuturisten.easyr.easyrapi.service.SlideshowContentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(SlideshowContentController.BASE_URL)
public class SlideshowContentController {

    de.diefuturisten.easyr.easyrapi.converter.SlideshowContentToSlideshowContentReturn slideshowContentToSlideshowContentReturn = new de.diefuturisten.easyr.easyrapi.converter.SlideshowContentToSlideshowContentReturn();
    de.diefuturisten.easyr.easyrapi.converter.SlideshowImageToSlideshowImageReturn slideshowImageToSlideshowImageReturn = new de.diefuturisten.easyr.easyrapi.converter.SlideshowImageToSlideshowImageReturn();
    public static final String BASE_URL = "/api/slideshows/";
    private final SlideshowContentService slideshowContentService;

    public SlideshowContentController(SlideshowContentService slideshowContentService) {
        this.slideshowContentService = slideshowContentService;
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public java.util.List<de.diefuturisten.easyr.easyrapi.entity.content.SlideshowContent> getAllSlideShows(){
        return slideshowContentService.findAllSlides();
    }
    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.OK)
    public de.diefuturisten.easyr.easyrapi.model.response.SlideshowContentReturn getSlideShowById(@PathVariable long id) {return slideshowContentToSlideshowContentReturn.convert(slideshowContentService.findById(id));}
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SlideshowContent saveSlideShow(@RequestBody SlideshowContent slideshowContent){
        slideshowContentService.saveSlideShowContent(slideshowContent);
        return slideshowContent;
    }
    @GetMapping("{id}/images")
    @ResponseStatus(HttpStatus.OK)
    public java.util.List<de.diefuturisten.easyr.easyrapi.model.response.SlideshowImageReturn> showImagesBySlideshow(@PathVariable long id){
        java.util.List<de.diefuturisten.easyr.easyrapi.model.response.SlideshowImageReturn> slideshowContentReturnList = new java.util.ArrayList<>();
        for(SlideshowImage image: slideshowContentService.getImagesBySlide(id)){
            slideshowContentReturnList.add(slideshowImageToSlideshowImageReturn.convert(image));

        }
        return slideshowContentReturnList;
    }

    @PostMapping("{id}/images")
    @ResponseStatus(HttpStatus.CREATED)
    public void postImageBySlide(@PathVariable long id, @RequestBody SlideshowImage slideshowImage){
        slideshowContentService.createImageBySlide(id, slideshowImage);
    }

    @DeleteMapping("{id}/images/{imageId}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteImageBySlide(@PathVariable long id, @PathVariable long imageId){
         slideshowContentService.deleteImageBySlide(id, imageId);
    }


}

