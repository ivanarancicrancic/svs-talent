package de.diefuturisten.easyr.easyrapi.repository;

import de.diefuturisten.easyr.easyrapi.entity.content.UnityContent;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UnityContentRepository extends JpaRepository<UnityContent, Long> {
    Optional<UnityContent> findByName(String name);
}
