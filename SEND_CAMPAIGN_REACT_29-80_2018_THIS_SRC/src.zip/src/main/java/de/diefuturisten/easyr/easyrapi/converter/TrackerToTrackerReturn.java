package de.diefuturisten.easyr.easyrapi.converter;

import org.springframework.core.convert.converter.Converter;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Tracker;
import de.diefuturisten.easyr.easyrapi.model.response.TrackerReturn;

public class TrackerToTrackerReturn implements Converter<Tracker, TrackerReturn> {

    public TrackerToTrackerReturn(){}

    @Override
    public TrackerReturn convert(Tracker source) {
        TrackerReturn trackerReturn = new TrackerReturn();
        trackerReturn.setId(source.getId());
        trackerReturn.setUrl(source.getUrl());
        trackerReturn.setVuforiaId(source.getVuforiaId());
        return trackerReturn;
    }


}
