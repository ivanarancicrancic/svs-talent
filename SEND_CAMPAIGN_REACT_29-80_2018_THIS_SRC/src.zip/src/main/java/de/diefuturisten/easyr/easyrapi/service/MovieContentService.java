package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.entity.content.MovieContent;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import de.diefuturisten.easyr.easyrapi.repository.MovieContentRepository;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class MovieContentService {

    private MovieContentRepository movieContentRepository;
    private CampaignRepository campaignRepository;

    public MovieContentService(MovieContentRepository movieContentRepository, CampaignRepository campaignRepository) {
        this.movieContentRepository = movieContentRepository;
        this.campaignRepository = campaignRepository;
    }

    public List<MovieContent> findAllMovies() {
        return movieContentRepository.findAll().stream().collect(Collectors.toList());
    }

    public MovieContent findMovieById(long movieId){
        return movieContentRepository.findById(movieId).get();
    }
    public MovieContent createMovieByCampaign(long id, MovieContent movieContent){
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().add(movieContent);
        campaignRepository.save(campaignOptional.get());
        movieContentRepository.save(movieContent);
        return movieContent;
    }

    public MovieContent modifyMovieByCampaign(long id, MovieContent movieContent, long movieId){
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().remove(movieContentRepository.findById(movieId).get());
        campaignOptional.get().getContents().add(movieContent);
        campaignRepository.save(campaignOptional.get());
        return movieContent;
    }

    public void deleteMovieByCampaign(long id, long movieId){
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);
        campaignOptional.get().getContents().remove(movieContentRepository.findById(movieId).get());
        campaignRepository.save(campaignOptional.get());

    }



}
