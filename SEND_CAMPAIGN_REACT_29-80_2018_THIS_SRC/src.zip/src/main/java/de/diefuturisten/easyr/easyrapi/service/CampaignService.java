package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.converter.CampaignCommandToCampaign;
import de.diefuturisten.easyr.easyrapi.converter.CampaignToCampaignCommand;
import de.diefuturisten.easyr.easyrapi.entity.campaign.Campaign;
import de.diefuturisten.easyr.easyrapi.model.response.CampaignCommand;
import de.diefuturisten.easyr.easyrapi.repository.CampaignRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CampaignService {

    private final CampaignRepository campaignRepository;
    private final CampaignCommandToCampaign commandToCampaign;
    private final CampaignToCampaignCommand campaignToCampaignCommand;

    public CampaignService(CampaignRepository campaignRepository, CampaignCommandToCampaign commandToCampaign, CampaignToCampaignCommand campaignToCampaignCommand) {
        this.campaignRepository = campaignRepository;
        this.commandToCampaign = commandToCampaign;
        this.campaignToCampaignCommand = campaignToCampaignCommand;
    }

    public Campaign createCampaign(Campaign campaignCommand) {
        campaignRepository.save(campaignCommand);
        Campaign savedCampaign = campaignRepository.findById(campaignCommand.getId()).get();
        return savedCampaign;
    }

    public List<CampaignCommand> getAllCampaigns() {
        String status = "getting all campaigns";
        System.out.println(status);
        Iterable<Campaign> iterable = campaignRepository.findAll();
        System.out.println("Taken campaigns!");
        List<Campaign> list = new ArrayList<Campaign>();
        if( iterable != null ){
            for( Campaign e : iterable ){
                list.add(e);
            }
        }

        List<CampaignCommand> campaignCommands = new ArrayList<>();
        for( Campaign c : list ){
            System.out.println("Campaign info before converting: " + c.toString());
            campaignCommands.add(campaignToCampaignCommand.convert(c));
            System.out.println("Finished converting!");
        }
        return campaignCommands;
    }

    public Campaign updateCampaign(Campaign campaign) {
        String status = "updating campaign";
        System.out.println(status);
        campaignRepository.save(campaign);
        return campaign;
    }

    public void deleteCampaign(Long id) {
        String status = "deleting campaign";
        System.out.println(status);
        campaignRepository.deleteById(id);

    }

    public CampaignCommand findById(Long id) {
        String status = "getting command campaign";
        System.out.println(status);
        Optional<Campaign> campaignOptional = campaignRepository.findById(id);

        if( !campaignOptional.isPresent() ){
            // throw new NotFoundException("Campaign Not Found for id:" + id.toString());
        }
        CampaignCommand campaignCommand = campaignToCampaignCommand.convert(campaignOptional.get());

        return campaignCommand;
    }

}
