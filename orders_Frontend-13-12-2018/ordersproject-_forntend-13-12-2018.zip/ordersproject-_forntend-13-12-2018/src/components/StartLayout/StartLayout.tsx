import * as React from 'react';
import { connect } from 'react-redux';
import { Link } from "react-router-dom";
// import { history } from '../../router';
import './StartLayout.css';
import { IRootState } from '../../redux';
import { filterOrderFetch } from '../../redux/filterOrders/actions';
import { orderListFetch } from '../../redux/order-list/actions';
import { IOrderResponseModel } from '../../redux/order-list/types';
import { getOrderList } from '../../redux/order-list/selectors';
import { getFilteredOrder } from '../../redux/filterOrders/selectors';
import DatePicker from 'react-date-picker';
import deIcon from '../../assets/images/edit_pencil.svg';
import * as Modal from 'react-modal';
import { orderDetailFetch } from '../../redux/order-detail/actions';
import { IOrderDetailResponseModel } from '../../redux/order-detail/types';
import { getOrderDetail } from '../../redux/order-detail/selectors';
// import { Button } from "@blueprintjs/core";

interface IPropsDispatchMap {
    orderListFetch: typeof orderListFetch;
    filterOrderFetch: typeof filterOrderFetch;
    orderDetailFetch: typeof orderDetailFetch;
}
interface IPropsStateMap {
    orderData: IOrderResponseModel[] | null;
    filteredOrderData: IOrderResponseModel[] | null;
    orderDetailData: IOrderDetailResponseModel | null;
}

// Modal.setAppElement(StartLayout)


type IProps = IPropsDispatchMap & IPropsStateMap

const customStyles = {
    content : {
      top                   : '50%',
      left                  : '50%',
      right                 : 'auto',
      bottom                : 'auto',
      marginRight           : '-50%',
      transform             : 'translate(-50%, -50%)'
    }
  };


class StartLayout extends React.Component<IProps> {
   public state = {
           dateFrom: new Date(),
           dateTo: new Date(),
           filteredOrders: [],
           sum: 0,
           modalIsOpen: false,
           currentOrder: null
      }
    
      constructor(props: any) {
        super(props);
        this.handleDateFrom = this.handleDateFrom.bind(this);
        this.handleDateTo = this.handleDateTo.bind(this);
        this.handleFilter = this.handleFilter.bind(this);
        this.selectedRowHandel = this.selectedRowHandel.bind(this);
        // this.openModal = this.openModal.bind(this);
        // this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    public componentWillMount() {
        Modal.setAppElement('body');

        this.props.orderListFetch();        
        console.log("Date on mount: " + this.state.dateFrom);
    
    }


    public componentWillReceiveProps(nextProps: IProps) {

            this.setState({filteredOrders: nextProps.filteredOrderData});
            this.setState({currentOrder: nextProps.orderDetailData})
            console.log("Filtered orders: " + this.state.filteredOrders);
            
           
    }

    public selectedRowHandel(order: IOrderResponseModel){
        console.log("SELECTED ORDER: " + order.firstName + order.order_id);
        const order_id = order.order_id;
        // history.push(`/orderDetails/${order}`);
        
        this.props.orderDetailFetch({order_id})
            setTimeout(()=>this.setState({modalIsOpen: true}), 3000);
        
            // this.setState({modalIsOpen: true}); 
       

        
    //    this.openModal(this.props.orderDetailFetch);

    }


    public handleFilter(values:any){
        console.log("entered handle filter");
       
        values.preventDefault();
        // console.log("this.state.dateFrom on handleFilter: "  + this.state.dateFrom);
        const startDate = this.state.dateFrom;
        const endDate = this.state.dateTo;
        this.props.filterOrderFetch({startDate, endDate});
         
      



//        if(this.props.filteredOrderData)
//        {
//            console.log("this.props.filteredOrderData != null");
//         // for (var counter=0; counter < this.props.filteredOrderData.length; counter++){
//         //     this.setState({sum: this.state.sum + parseInt(this.props.filteredOrderData[counter].amount)});
//         // }

//        const orders = this.props.filteredOrderData.map( order => {
//             return (
//                 parseInt(order.amount, 10)
//             )
//         })
//     //   const currSum = orders.reduce( (acc, currentValue) => { return acc + currentValue; }, 0 );

//     //   const reducer = (sum: any, orderAmount:any) => {return sum + orderAmount; };
   
   
//     // const totalCount =  orders.reduce((acc, n) => acc + n, 0);
   
   
//     //   const totalCount = orders.reduce(reducer);

//    const summingReducer = (acc:any, n:any) => acc + n;
//    const totalCount = orders.reduce(summingReducer, 0);


//         this.setState({sum: totalCount});

//      }
//      else {this.setState({sum: 0})}      
        // history.push(`/start`);
        // this.setState({filteredOrders: this.props.filteredOrderData});
        // this.forceUpdate();
      };
 

   public handleDateFrom(entryDate: any){
       console.log("Date: " + entryDate);
        this.setState({dateFrom: entryDate}); 
        this.setState({
            dateFrom: entryDate
          }, () => console.log(this.state.dateFrom));
        
        console.log("State for selected dateFrom: " + this.state.dateFrom)
        
     };

     
   public handleDateTo(entryDate: any){
    console.log("Date: " + entryDate);
    //  this.setState({dateTo: entryDate}); 
    
     this.setState({
        dateTo: entryDate
      }, () => console.log(this.state.dateTo)); 
     console.log("State for selected dateTo: " + this.state.dateTo)
 
  };


//   public openModal(orderDetails: any) {
//     this.setState({modalIsOpen: true});
//     this.setState({currentOrder: orderDetails});

//   }



//   afterOpenModal() {
//     // references are now sync'd and can be accessed.
//     this.subtitle.style.color = '#f00';
//   }

  public closeModal() {
    this.setState({modalIsOpen: false});
  }


 public renderOrderList() {

    let totalNetPrice = 0;
    let totalGrossPrice = 0;
    let totalNetPriceWD = 0;
    let totalGrossPriceWD = 0;
    if(this.props.filteredOrderData)
            {
                console.log("this.props.filteredOrderData != null");
             // for (var counter=0; counter < this.props.filteredOrderData.length; counter++){
             //     this.setState({sum: this.state.sum + parseInt(this.props.filteredOrderData[counter].amount)});
             // }
     
            const ordersNetPrices = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPrice, 10)
                 )
             })

             const ordersGrossPrices = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.grossPrice, 10)
                 )
             })
            
             const ordersNetPricesWD = this.props.filteredOrderData.map( order => {
                return (
                    parseInt(order.netPriceWD, 10)
                 )
             })

             const ordersGrossPricesWD = this.props.filteredOrderData.map( order => {
                // final = final + parseInt(order.grossPriceWD, 10);
                return (
                    parseInt(order.grossPriceWD, 10)
                 )
             })

             //   const currSum = orders.reduce( (acc, currentValue) => { return acc + currentValue; }, 0 );
     
         //   const reducer = (sum: any, orderAmount:any) => {return sum + orderAmount; };
        
        
         // const totalCount =  orders.reduce((acc, n) => acc + n, 0);
        
        
         //   const totalCount = orders.reduce(reducer);
     
        const summingReducer = (acc:any, n:any) => acc + n;
        totalNetPrice = ordersNetPrices.reduce(summingReducer, 0);
        const summingReducer1 = (acc1:any, n1:any) => acc1 + n1;
        totalGrossPrice = ordersGrossPrices.reduce(summingReducer1, 0);
        const summingReducer2 = (acc2:any, n2:any) => acc2 + n2;
        totalNetPriceWD = ordersNetPricesWD.reduce(summingReducer2, 0);
        const summingReducer3 = (acc3:any, n3:any) => acc3 + n3;
        totalGrossPriceWD = ordersGrossPricesWD.reduce(summingReducer3, 0);

        // this.setState({sum: totalCount});
     
          }
          else {
            totalNetPrice = 10;
            totalGrossPrice = 20;
            totalNetPriceWD = 30;
            totalGrossPriceWD = 40;
    
            //   this.setState({sum: 20})
            }      
            console.log("FInal totalNetPrice: " + totalNetPrice);
            console.log("FInal totalGrossPrice: " + totalGrossPrice);
            console.log("FInal totalNetPriceWD: " + totalNetPriceWD);
            console.log("FInal totalGrossPriceWD: " + totalGrossPriceWD);


        if(!this.props.orderData && !this.props.filteredOrderData) 
         {    
             console.log("this.props.orderData: " + this.props.orderData);
            console.log("this.props.orderData and this.props.filteredOrderData is null");
            return null;
         }
         else if(!this.props.orderData)
             {
                 if(this.props.filteredOrderData)
                 {
                     if(this.props.filteredOrderData[0].latest === 0){
                         return(
                              <div>NO FOUND</div>

                         )
                     }
                    else{
            return (
                <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>Country </th>
                                    <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Difference </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    <th>Difference (without delivery)</th>
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)}>
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td>
                                
                                </tr>
                            )
                        })}
                      
                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr>

                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
            ) 
        }
           }
             else { return null;} 
        }

        else if(!this.props.filteredOrderData)
        {
            if(this.props.orderData)
            {
       return (
           <div className="dashboardTable">
               <table className="table bp3-html-table bp3-html-table-bordered">
               <thead>                  
               <tr >
                       <th>Order ID</th>
                       <th>Oder DATE</th>
                       <th>FirstName </th>
                               <th>LastName </th>
                               <th>Country </th>
                               <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Difference </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    <th>Difference (without delivery)</th>
                       </tr>

               </thead>
               <tbody>
                   
                   {this.props.orderData.map( order => {
                       return (
                           <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)}>
                               <td><b>{order.order_id}</b></td>
                               <td>{order.orderDate} </td> 
                               <td>{order.firstName} </td>
                               <td>{order.lastName} </td>
                               <td>{order.country} </td>
                               <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td>
                           </tr>
                       )
                   })}
                 
                  
                 <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr>
                   <tr>
                   <td colSpan={5} className="text-center" >
                      <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                   </td>
                   </tr>
               </tbody>
               </table>
           </div>
       ) 
      }
        else { return null;} 
   }
        
         else {
            console.log("!this.props.filteredOrderData =! NULL !!!!!!!!!!!!!!!!! AND this.props.orderData =! NULL");
           
            if(this.props.filteredOrderData[0].latest === 0){
                console.log("LATEST 0!!!");
                return(
                    <div className="dashboardTable">
                    <table className="table bp3-html-table bp3-html-table-bordered">
                    <thead>                  
                    <tr>
                            <th>Order ID</th>
                            <th>Oder DATE</th>
                            <th>FirstName </th>
                                    <th>LastName </th>
                                    <th>Country </th>
                                    <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Difference </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    <th>Difference (without delivery)</th>
                            </tr>
    
                    </thead>
                    <tbody>
                        
                        {this.props.filteredOrderData.map( order => {
                            return (
                                <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)}> 
                                    <td><b>{order.order_id}</b></td>
                                    <td>{order.orderDate} </td> 
                                    <td>{order.firstName} </td>
                                    <td>{order.lastName} </td>
                                    <td>{order.country} </td>
                                    <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td>
                                   

                                </tr>
                            )
                        })}
                      
                      
                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr>

                        <tr>
                        <td colSpan={5} className="text-center" >
                           <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                        </td>
                        </tr>
                    </tbody>
                    </table>
                </div>
                )
            }
           else{
             if(this.props.orderData[0].latest> this.props.filteredOrderData[0].latest)
      {
          console.log("this.props.orderData[0].latest> this.props.filteredOrderData[0].latest !!!!!!!!!!");
             return (
            <div className="dashboardTable">
                <table className="table bp3-html-table bp3-html-table-bordered">
                <thead>                  
                <tr>
                        <th>Order ID</th>
                        <th>Oder DATE</th>
                        <th>FirstName </th>
                                <th>LastName </th>
                                <th>Country </th>
                                <th>Net price </th>
                                    <th>Gross price </th>
                                    <th>Difference </th>
                                    <th>Net price (without delivery) </th>
                                    <th>Gross price (without delivery)</th>
                                    <th>Difference (without delivery)</th>
                        </tr>

                </thead>
                <tbody>
                    
                    {this.props.orderData.map( order => {
                        return (
                            <tr key={order.order_id} onClick={(e) =>  this.selectedRowHandel(order)}>
                                <td><b>{order.order_id}</b></td>
                                <td>{order.orderDate} </td> 
                                <td>{order.firstName} </td>
                                <td>{order.lastName} </td>
                                <td>{order.country} </td>
                                <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td>
                                
                            </tr>
                        )
                    })}
                  

                    
                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price:
                      { totalNetPrice
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price:
                      { totalGrossPrice
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference:
                      { totalGrossPrice - totalGrossPrice
                      } 
                      
                    </td>
                    </tr>

                      <tr>
                    <td colSpan={5} className="text-center" >
                       Total net price (without delivery):
                      { totalNetPriceWD
                      } 
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Total gross price (without delivery):
                      { totalGrossPriceWD
                      } 

                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       Difference (without delivery):
                      { totalNetPriceWD - totalGrossPriceWD
                      } 
                      
                    </td>
                    </tr>

                    <tr>
                    <td colSpan={5} className="text-center" >
                       <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                    </td>
                    </tr>
                </tbody>

                </table>
            </div>
        )
    }
    else {

        console.log("this.props.orderData[0].latest < this.props.filteredOrderData[0].latest");
        return (
            <div className="dashboardTable">
            <table className="table bp3-html-table bp3-html-table-bordered"  >
            <thead>                  
            <tr>
                    <th>Ooorder ID</th>
                    <th>Oder DATE</th>
                    <th>FirstName </th>
                    <th>LastName </th>
                     <th>Country </th>
                    <th>Net price </th>
                            <th>Gross price </th>
                            <th>Difference </th>
                            <th>Net price (without delivery) </th>
                            <th>Gross price (without delivery)</th>
                            <th>Difference (without delivery)</th>
                    </tr>

            </thead>
            <tbody>
                
                {this.props.filteredOrderData.map( order => {
                    return (
                        <tr key={order.order_id} onClick={(e) => this.selectedRowHandel(order)} className = "order_hovered">
                            <td><b>{order.order_id}</b></td>
                            <td>{order.orderDate} </td> 
                            <td>{order.firstName} </td>
                            <td>{order.lastName} </td>
                            <td>{order.country} </td>
                            <td>{order.netPrice} </td>
                                    <td>{order.grossPrice} </td>
                                    <td>{parseInt(order.netPrice,10) - parseInt(order.grossPrice,10)} </td>
                                    <td>{order.netPriceWD} </td>
                                    <td>{order.grossPriceWD} </td>
                                    <td>{parseInt(order.netPriceWD,10) - parseInt(order.grossPriceWD,10)} </td>
                                    {/* <td><Link to={`/product/${order.order_id}`} className="fontello icon-edit"> <img src={logo} className="App-logo" alt="logo" /> </Link></td> */}
                                    <td><Link to={`/order/${order.order_id}`}> <img className="bp3-button imgs" src={deIcon} alt="logo" /> </Link></td>


                        </tr>
                    )
                })}
              
              <tr>
            <td colSpan={5} className="text-center" >
               Total net price:  &nbsp;
              { totalNetPrice
              } 
            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center" >
               Total gross price: &nbsp;
              { totalGrossPrice
              } 

            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center" >
               Difference: &nbsp;
              { totalNetPrice - totalGrossPrice
              } 
              
            </td>
            </tr>

              <tr>
            <td colSpan={5} className="text-center" >
               Total net price (without delivery): &nbsp;
              { totalNetPriceWD
              } 
            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center" >
               Total gross price (without delivery): &nbsp;
              { totalGrossPriceWD
              } 

            </td>
            </tr>

            <tr>
            <td colSpan={5} className="text-center" >
               Difference (without delivery): &nbsp;
              { totalNetPriceWD - totalGrossPriceWD
              } 
              
            </td>
            </tr>

                <tr>
                <td colSpan={5} className="text-center" >
                   <a className="bp3-button bp3-icon-plus bp3-minimal"/>
                </td>
                </tr>
            </tbody>
            </table>
        </div>
        )
    }
    }
}
}

    public render() {
        if(!this.props.orderDetailData){
            console.log("!!!!  this.props.orderDetailData = NULL");
        return (
            <div className="grid100">
        

        
             <b> Filter orders by date range: </b> <br/>
             <div>
               <b>  Start date: </b>

     <form onSubmit={ this.handleFilter }>
               
         <div className="bp3-input-group">
         
          <DatePicker 
          onChange={this.handleDateFrom}
          value={this.state.dateFrom}
          />   
          &nbsp; &nbsp; &nbsp;
          <b> End date: </b>
          <DatePicker 
       onChange={this.handleDateTo} 
       value={this.state.dateTo} 
       />
          &nbsp; &nbsp; &nbsp;
                    </div>
                    <br/>
                    <button type="submit" value="Submit" className="bp3-button" style={{backgroundColor : "#4682B4"}} > Spezialsuche >> </button>

        </form>

      </div>
              <br/>
                {this.renderOrderList()}   
            </div>
        )
    }
    else {
return(
    <div>
    {/* <button onClick={this.openModal}>Open Modal</button> */}
    <Modal
      isOpen={this.state.modalIsOpen}
    //   onAfterOpen={this.afterOpenModal}
      onRequestClose={this.closeModal}
      style={customStyles}
      contentLabel="Example Modal"
    >

      {/* <h2 ref={subtitle => this.subtitle = subtitle}>Hello</h2> */}
      <button onClick={this.closeModal}>close</button>
      <div>Order details</div>
      <br/>
     <div> First name:  &nbsp; {this.props.orderDetailData.firstName}</div>
     <div>Last name:  &nbsp; {this.props.orderDetailData.lastName}</div>
     <div>Company:  &nbsp; {this.props.orderDetailData.companyName}</div>
     <div>Paying method:  &nbsp; {this.props.orderDetailData.paymentMethod}</div>
     <div>e-mail:  &nbsp; {this.props.orderDetailData.email}</div>
     <div>Order date:  &nbsp; {this.props.orderDetailData.orderDate}</div>
     <div>Phone number:  &nbsp; {this.props.orderDetailData.phoneNumber}</div>
     <div>Shipping way:  &nbsp; {this.props.orderDetailData.shippingWay}</div>
     <div>Street:  &nbsp; {this.props.orderDetailData.street}</div>
     <div>House number:  &nbsp; {this.props.orderDetailData.houseNumber}</div>
     <div>Postcode:  &nbsp; {this.props.orderDetailData.postcode}</div>
     <div>City:  &nbsp; {this.props.orderDetailData.city}</div>
     <div>Country:  &nbsp; {this.props.orderDetailData.country}</div>
     <div>Gross price:  &nbsp; {this.props.orderDetailData.grossPrice}</div>
     <div>Gross price(without delivery):  &nbsp; {this.props.orderDetailData.grossPriceWD}</div>
     <div>Net price:  &nbsp; {this.props.orderDetailData.netPrice}</div>
     <div>Net price(without delivery):  &nbsp; {this.props.orderDetailData.netPriceWD}</div>

      <form>
        <input />
        <button>tab navigation</button>
        <button>stays</button>
        <button>inside</button>
        <button>the modal</button>
      </form>
    </Modal>
  </div>

)

    }
}

}

const mapStateToProps = (state: IRootState) => ({
    orderData: getOrderList(state),
    filteredOrderData: getFilteredOrder(state),
    orderDetailData: getOrderDetail(state)
});

export default connect(mapStateToProps, {orderListFetch, filterOrderFetch, orderDetailFetch})(StartLayout)