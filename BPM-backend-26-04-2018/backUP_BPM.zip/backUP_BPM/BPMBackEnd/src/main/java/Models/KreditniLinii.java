package Models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


public class KreditniLinii {


    public void setKreditniliniiname(String kreditniliniiname) {
        this.kreditniliniiname = kreditniliniiname;
    }

    private String kreditniliniiname;

        private String kreditniliniidescription;



        public KreditniLinii() {

        }

    public String getKreditniliniidescription() {
        return kreditniliniidescription;
    }

    public void setKreditniliniidescription(String kreditniliniidescription) {
        this.kreditniliniidescription = kreditniliniidescription;
    }

    public KreditniLinii(String kreditniliniiname, String kreditniliniidescription) {
            this.kreditniliniiname = kreditniliniiname;
            this.kreditniliniidescription = kreditniliniidescription;

        }

}
