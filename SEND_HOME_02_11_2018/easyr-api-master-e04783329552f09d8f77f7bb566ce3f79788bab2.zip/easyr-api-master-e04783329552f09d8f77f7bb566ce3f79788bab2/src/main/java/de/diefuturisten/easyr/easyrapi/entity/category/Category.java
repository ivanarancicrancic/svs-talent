package de.diefuturisten.easyr.easyrapi.entity.category;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="categories")
public class Category {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name="key_category")
    private long id;

    @ManyToOne
    @JoinColumn(name="fk_user", nullable = false)
    private User user;

    @Column(name="name")
    private String name;

    @Column(name="description")
    private String description;

//    @OneToMany(mappedBy="category")
//    private List<CategoryImage> images = new java.util.ArrayList<>();

//    @OneToMany(mappedBy="campaign")
//    private List<Product> products = new java.util.ArrayList<>();

    // getter & setter
    public Category(){}

    public Category(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

//    @JsonIgnore
//    public List<CategoryImage> getCategoryImages() {
//        return images;
//    }
//
//    public void setCategoryImages(List<CategoryImage> images) {
//        this.images = images;
//    }

//    public List<Product> getProducts() {
//        return products;
//    }
//
//    public void setProducts(List<Product> products) {
//        this.products = products;
//    }

}
