package de.diefuturisten.easyr.easyrapi.model.request;

public class EditProductNameModel {

    private String name;

    public EditProductNameModel() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
