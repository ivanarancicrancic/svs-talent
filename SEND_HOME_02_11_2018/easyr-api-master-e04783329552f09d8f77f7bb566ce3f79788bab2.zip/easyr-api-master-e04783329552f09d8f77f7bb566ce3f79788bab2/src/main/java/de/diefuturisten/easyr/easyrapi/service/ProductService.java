package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.product.Product;
import de.diefuturisten.easyr.easyrapi.repository.ProductRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Optional;

@Service
@Transactional
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(
            ProductRepository contentRepository
   ) {
        this.productRepository = contentRepository;
    }

    public Optional<Product> getById(long id) {
        return this.productRepository.findById(id);
    }

    public boolean deleteProduct(Product product) {
        this.productRepository.delete(product);
        return true;
    }

//    /* Movie */
//    public MovieContent createMovieProduct(Category campaign, @Valid CreateMovieProductModel model) {
//        MovieProduct product = movieContentService.create(campaign, model);
//        return content;
//    }
//
//    public MovieContent editMovieContent(MovieContent content, @Valid EditMovieContentModel model) {
//        MovieContent editedContent = movieContentService.edit(content, model);
//        return editedContent;
//    }

//    /* Slideshow */
//    public SlideshowContent createSlideshowContent(Campaign campaign, @Valid CreateSlideshowContentModel model) {
//        SlideshowContent content = slideshowContentService.create(campaign, model);
//        return content;
//    }
//
//    public SlideshowContent editSlideshowContent(SlideshowContent content, @Valid EditSlideshowContentModel model) {
//        SlideshowContent editedContent = slideshowContentService.edit(content, model);
//        return editedContent;
//    }
//
//    /* SlideshowImage */
//    public SlideshowImage createSlideshowImage(long slideshowID, @Valid CreateSlideshowImageModel model) {
//        SlideshowImage content = slideshowImageService.create(slideshowID, model);
//        return content;
//    }
//
//    public SlideshowImage deleteSlideshowImage(long imageID) {
//        SlideshowImage content = slideshowImageService.delete(imageID);
//        return content;
//    }
//
//    public boolean moveUp(Content content) {
//        int currentWeight = content.getWeight();
//
//        if( currentWeight == 1 ){
//            return false;
//        }
//
//        Campaign campaign = content.getCampaign();
//
//        int desiredWeight = content.getWeight() - 1;
//        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
//        if( contentAtDesiredWeightOpt.isPresent() ){
//            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
//            contentAtDesiredWeight.setWeight(currentWeight);
//            contentRepository.save(contentAtDesiredWeight);
//        }
//
//        content.setWeight(desiredWeight);
//        contentRepository.save(content);
//
//        return true;
//    }
//
//    public boolean moveDown(Content content) {
//
//        int currentWeight = content.getWeight();
//
//        Campaign campaign = content.getCampaign();
//
//        int desiredWeight = content.getWeight() + 1;
//        Optional<Content> contentAtDesiredWeightOpt = contentRepository.findFirstByCampaignAndWeight(campaign, desiredWeight);
//        if( contentAtDesiredWeightOpt.isPresent() ){
//            Content contentAtDesiredWeight = contentAtDesiredWeightOpt.get();
//            contentAtDesiredWeight.setWeight(currentWeight);
//            contentRepository.save(contentAtDesiredWeight);
//        } else {
//            return false;
//        }
//
//        content.setWeight(desiredWeight);
//        contentRepository.save(content);
//
//        return true;
//    }
//
//    public Content rename(Content content, de.diefuturisten.easyr.easyrapi.model.request.EditProductNameModel model) {
//        content.setName(model.getName());
//        return contentRepository.save(content);
//    }

}
