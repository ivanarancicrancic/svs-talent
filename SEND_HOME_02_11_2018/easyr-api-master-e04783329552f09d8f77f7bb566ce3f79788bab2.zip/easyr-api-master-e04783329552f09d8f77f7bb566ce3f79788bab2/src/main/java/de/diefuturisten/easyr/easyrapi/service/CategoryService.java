package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.EditCategoryModel;
import de.diefuturisten.easyr.easyrapi.model.request.SaveNewCategoryModel;
import de.diefuturisten.easyr.easyrapi.repository.CategoryRepository;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.stream.Collectors;
import de.diefuturisten.easyr.easyrapi.entity.category.Category;

@Service
@Transactional
public class CategoryService {

    private final CategoryRepository categoryRepository;

    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }


    public List<Category> findAllCategories() {
        return categoryRepository.findAll().stream().collect(Collectors.toList());
    }

    public List<Category> getCategoriesForUser(User user) {
        return categoryRepository.findByUser(user).stream().collect(Collectors.toList());
    }

    public Optional<Category> getCategory(long id) {
        return this.categoryRepository.findById(id);
    }


    public Category createEmptyCategory(User user) {
        Category category = new Category();
        category.setUser(user);
        return this.categoryRepository.save(category);
    }

    public Category saveNewCategory(Category category, SaveNewCategoryModel model, User user) {

        this.categoryRepository.save(category);
        return category;
    }

    public Category editCategory(Category category, EditCategoryModel editCategoryModel) {
        category.setName(editCategoryModel.getName());
        return this.categoryRepository.save(category);
    }

}
