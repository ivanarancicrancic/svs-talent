package de.diefuturisten.easyr.easyrapi.service;

import de.diefuturisten.easyr.easyrapi.entity.user.User;
import de.diefuturisten.easyr.easyrapi.model.request.CreateAccountModel;
import de.diefuturisten.easyr.easyrapi.repository.UserRepository;
import de.diefuturisten.easyr.easyrapi.repository.UserRoleRepository;
import de.diefuturisten.easyr.easyrapi.security.SecurityConstants;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class UserService {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;

    private final UserRoleRepository userRoleRepository;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder, UserRoleRepository userRoleRepository) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;

        this.userRoleRepository = userRoleRepository;
    }

    public User getUserByUsername(String username) {
        return userRepository.findByEmail(username).orElseThrow(NoSuchElementException::new);
    }


    public Optional<User> getUserByUserId(long userId) {
        return userRepository.findById(userId);
    }

    public User create(CreateAccountModel model) {
        User user = new User();

        user.setActive(true);
        user.setFirstname(model.getFirstName());
        user.setLastname(model.getLastName());
        user.setEmail(model.getEmail());
        user.setPassword(passwordEncoder.encode(model.getPassword()));
        user.setLanguage(model.getLanguage());
        user.setGender(model.getGender());

        userRoleRepository.findByName("Standard").ifPresent(defaultRole -> {
            user.addRole(defaultRole);
        });
        userRepository.save(user);

        return user;
    }


    public List<User> getAllUser() {
        return userRepository.findAll();
    }
}
