package springwebapp.converters;

import springwebapp.commands.BookCommand;
import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.model.Book;
import springwebapp.model.Category;

import java.util.ArrayList;
import java.util.List;


@Component
public class BookCommandToBook implements Converter<BookCommand, Book> {

    private final CategoryCommandToCategory categoryConveter;
    private final CommentCommandToComment commentConverter;
    private final AuthorCommandToAuthor authorConverter;
    private final EvaluationCommandToEvaluation evaluationConverter;
    private final PublisherCommandToPublisher publisherConverter;

    public BookCommandToBook(CategoryCommandToCategory categoryConveter, CommentCommandToComment commentConverter, AuthorCommandToAuthor authorConverter, EvaluationCommandToEvaluation evaluationConverter, PublisherCommandToPublisher publisherConverter) {
        this.categoryConveter = categoryConveter;
        this.commentConverter = commentConverter;
        this.authorConverter = authorConverter;
        this.evaluationConverter = evaluationConverter;
        this.publisherConverter = publisherConverter;
    }

    @Synchronized
    @Override
    public Book convert(BookCommand source){
        if(source == null){
            return null;
        }
        System.out.println("Entered bookToBookCommand");
        final Book book = new Book();
        book.setId(source.getId());
        System.out.println("Entered bookToBookCommand, set bookID: " + source.getId());
        book.setTitle(source.getTitle());
        System.out.println("Entered bookToBookCommand, set book title: " + source.getTitle());
        book.setImage(source.getImage());
        book.setDescription(source.getDescription());
        System.out.println("Entered bookToBookCommand, set book description: " + source.getDescription());
        book.setSize(source.getSize());
        System.out.println("Entered bookToBookCommand, set book description: " + source.getUrl());
        book.setUrl(source.getUrl());
        book.setNote(source.getNote());
        System.out.println("Entered bookToBookCommand, set book note: " + source.getNote());
        book.setStringCategories(source.getStringCategories());
        System.out.println("Entered bookToBookCommand, set book stringCategories: " + source.getCategories());
        book.setDifficutly(source.getDifficutly());
        System.out.println("Entered bookToBookCommand, set book difficulty: " + source.getDifficutly());
        book.setPublisher(publisherConverter.convert(source.getPublisher()));
        System.out.println("Entered bookToBookCommand, set book publisher: " + source.getPublisher());
        if (source.getCategories() != null){
            List<Category> categoryList = new ArrayList<>();
            book.setCategories(categoryList);
            if(book.getCategories()==null){System.out.println("book.getCategories() == NULL !!!! ");}
            System.out.println("source.getCategories() != null");
            source.getCategories()
                    .forEach( category -> book.getCategories().add(categoryConveter.convert(category)));
        }
        System.out.println("Entered bookToBookCommand, added categories");
        if (source.getAuthors() != null && source.getAuthors().size() > 0){
            source.getAuthors()
                    .forEach(author -> book.getAuthors().add(authorConverter.convert(author)));
        }
        System.out.println("Entered bookToBookCommand, added book authors");
        if (source.getComments() != null && source.getComments().size() > 0){
            source.getComments()
                    .forEach(comment -> book.getComments().add(commentConverter.convert(comment)));
        }
        System.out.println("Entered bookToBookCommand, set book comments");
        book.setEvaluation(evaluationConverter.convert(source.getEvaluation()));
        System.out.println("Entered bookToBookCommand, set book evaluation: " + source.getEvaluation());
        return book;
    }

}
