package springwebapp.converters;

import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import springwebapp.commands.DifficultyCommand;
import springwebapp.model.DifficultyDescription;

public class DifficultyCommandToDificulty implements Converter<DifficultyCommand, DifficultyDescription> {
    @Synchronized
    @Override
    public DifficultyDescription convert(DifficultyCommand source){

        if(source == null){
            return null;
        }
        final DifficultyDescription difficultyDescription = new DifficultyDescription();
        difficultyDescription.setId(source.getId());
        difficultyDescription.setDescription(source.getDescription());
        difficultyDescription.setBooks(source.getBooks());
        return difficultyDescription;
    }


}
