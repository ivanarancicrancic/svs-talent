package springwebapp.repository;

import org.springframework.stereotype.Component;
import springwebapp.model.TableAtrtributes;

@Component
public class TableAttributeRepositoryImpl implements TableAttributeRepository {

    @Override
    public TableAtrtributes getEnglishTableAttributes() {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Title", "Publisher", "Book List", "Size", "Description", "Category");
        return tableAtrtributes;
    }

    @Override
    public TableAtrtributes getSpanishTableAttributes()
    {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Título", "Publicador", "lista de libros", "número de páginas", "descripción", "Categoría");
        return tableAtrtributes;
    }

    @Override
    public TableAtrtributes getGermanTableAttributes() {
        TableAtrtributes tableAtrtributes = new TableAtrtributes("ID", "Titel", "Verleger", "Buchliste", "Anzahl der Seiten", "Beschreibung", "Kategorie");
        return tableAtrtributes;

    }

}
