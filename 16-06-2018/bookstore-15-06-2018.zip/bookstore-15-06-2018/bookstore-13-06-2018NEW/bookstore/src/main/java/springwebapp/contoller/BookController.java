package springwebapp.contoller;

import org.springframework.context.annotation.Primary;
import springwebapp.commands.BookCommand;
import springwebapp.commands.CategoryCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import springwebapp.converters.BookCommandToBook;
import springwebapp.converters.BookToBookCommand;
import springwebapp.model.Book;
import springwebapp.model.Category;
import springwebapp.model.DifficultyDescription;
import springwebapp.model.Difficutly;
import springwebapp.repository.CategoryRepository;
import springwebapp.repository.DifficultyDescriptionRepository;
import springwebappservice.service.BookService;
import springwebappservice.service.TableAttributeService;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jt on 5/18/17.
 */
@Controller
public class BookController {

    @Autowired
    BookService bookService;

    @Autowired
    CategoryRepository categoryRepository;

    DifficultyDescriptionRepository difficultyDescriptionRepository;

    @Autowired
    TableAttributeService tableAttributeService;

    BookCommandToBook bookConvertor;

    BookToBookCommand bookToBookCommand;

    public BookController(BookService bookService, TableAttributeService tableAttributeService, CategoryRepository categoryRepository, DifficultyDescriptionRepository difficultyDescriptionRepository, BookCommandToBook bookConvertor, BookToBookCommand bookToBookCommand) {
        this.bookService = bookService;
        this.tableAttributeService = tableAttributeService;
        this.categoryRepository = categoryRepository;
        this.bookConvertor = bookConvertor;
        this.difficultyDescriptionRepository = difficultyDescriptionRepository;
        this.bookToBookCommand = bookToBookCommand;
    }

    @RequestMapping("/books")
    public String getBooks(Model model)
    {
        System.out.println("Entered /books");
//        List<BookCommand> books = bookService.getAllBooks();
//        if(books==null) {System.out.println("EMPTY BOOKLIST");}
//        for(BookCommand b:books){
//            System.out.println("Check books");
//            if(b.getCategories()==null){System.out.println("Empty categories");}
//            for(CategoryCommand c: b.getCategories())
//            System.out.println("Book category:" + c.getDescription());
//        }
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }

    @RequestMapping("/findByDescription")
    public String getCategoryByDescription(Model model)
    {
        System.out.println("Entered /findByDescription");
        Category cagetory = categoryRepository.findByDescription("Drama");
        System.out.println("Category id is: " + cagetory.getId() + ", for description: " + cagetory.getDescription());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());
        return "books";
    }

    @RequestMapping("/book/show/{id}")
    public String showById(@PathVariable String id, Model model){
        System.out.println("entered book/show/{id}");
        model.addAttribute("book", bookService.findById(new Long(id)));
        return "book/show";
    }


    @RequestMapping("book/create")
    public String createBook(Model model){
        model.addAttribute("book", new BookCommand()) ;
        return "book/createbookform";
    }

    @PostMapping("create")
    public String createBook(@ModelAttribute BookCommand bookCommand, Model model){
        System.out.println("BEFORE CREATING BOOK");
        bookCommand.setDifficutly(Difficutly.HARD);
        bookCommand.setTitle("NEW");
        BookCommand createdBookCommand = bookService.createBook(bookCommand);
        System.out.println("Id of book created:" + createdBookCommand.getId());
//        model.addAttribute("translate", tableAttributeService.translate());
//        model.addAttribute("books", bookService.getAllBooks());
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }


    @RequestMapping("book/{id}/update")
    public String updateBook(@PathVariable String id, Model model){
        System.out.println("Entered book/{id}/update");

        List<DifficultyDescription> diff = new ArrayList<>();
          DifficultyDescription diffDescription = new DifficultyDescription();
          System.out.println("Entered book/{id}/update, SET DIFFICULTY HARD and added to diffList");
          diffDescription.setDescription("HARD");

          difficultyDescriptionRepository.save(diffDescription);
          List<Book> books = new ArrayList<>();
          Book book = bookConvertor.convert(bookService.findById(Long.valueOf(id)));
          System.out.println("Found book with id: " + bookService.findById(Long.valueOf(id)));
          books.add(book);
          List<Book> bookList = new ArrayList<>();

//          diffDescription.setBooks(bookList);
          for (Book b : books) {
//              diffDescription.getBooks().add(b);
               bookList.add(b);
          }
           diffDescription.setBooks(bookList);
        difficultyDescriptionRepository.save(diffDescription);
        System.out.println("HArd difficulty description ID: " + difficultyDescriptionRepository.findByDescription(diffDescription.getDescription()).getId());
        Book book1 = bookConvertor.convert(bookService.findById(Long.valueOf(id)));
        book1.setDifficultyDescription(diffDescription);
        bookService.updateBook(bookToBookCommand.convert(book1));
          diff.add(diffDescription);
          diffDescription.setDescription("EASY");
          System.out.println("Entered book/{id}/update, ADDED EASY DIFFICULTY");
          difficultyDescriptionRepository.save(diffDescription);
          diff.add(difficultyDescriptionRepository.findByDescription(diffDescription.getDescription()));
          diffDescription.setDescription("MODERATE");
          System.out.println("Entered book/{id}/update, ADDED MODERATE DIFFICULTY");
          difficultyDescriptionRepository.save(diffDescription);
          diff.add(difficultyDescriptionRepository.findByDescription(diffDescription.getDescription()));
          diffDescription.setDescription("KIND_OF_HARD");
          System.out.println("Entered book/{id}/update, ADDED KIND_OF_HARD DIFFICULTY");
          difficultyDescriptionRepository.save(diffDescription);
          diff.add(difficultyDescriptionRepository.findByDescription(diffDescription.getDescription()));
          diff = difficultyDescriptionRepository.findAll();

          System.out.println("Book diffciculty ID: " + bookService.findById(Long.valueOf(id)));
         Book bookToSave = bookConvertor.convert(bookService.findById(Long.valueOf(id)));

          System.out.println("difficultyDescriptionRepository.findByDescription(HARD): " + difficultyDescriptionRepository.findByDescription("HARD"));
          System.out.println("bookToSave.getDifficultyDescription(): " + bookToSave.getDifficultyDescription());

                 bookToSave.getDifficultyDescription().setId(difficultyDescriptionRepository.findByDescription("HARD").getId());
         bookService.updateBook(bookToBookCommand.convert(bookToSave));

        model.addAttribute("book", bookService.findById(Long.valueOf(id)));
        model.addAttribute("difficulties", diff);
        return "book/bookform";
    }


    @PostMapping("book")
    public String saveOrUpdate(@ModelAttribute BookCommand bookCommand){
        System.out.println("Before updating book! BOOK UPDATE CALLED WITH ID:" + bookCommand.getId());
        BookCommand savedBookCommand = bookService.updateBook(bookCommand);
        //BookCommand savedBookCommand = bookService.createBook(bookCommand);
          System.out.println("Id of book updated:" + savedBookCommand.getId());
        return "redirect:/book/show/" + savedBookCommand.getId();
    }


    @RequestMapping("book/{id}/delete")
    public String deleteBook(@PathVariable String id, Model model){
        bookService.deleteBook(Long.valueOf(id));
        model.addAttribute("translate", tableAttributeService.translate());
        model.addAttribute("books", bookService.getAllBooks());

        return "books";
    }



}
