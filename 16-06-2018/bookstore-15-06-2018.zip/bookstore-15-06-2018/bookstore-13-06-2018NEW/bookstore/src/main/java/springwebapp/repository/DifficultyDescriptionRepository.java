package springwebapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import springwebapp.model.DifficultyDescription;

@Component
public interface DifficultyDescriptionRepository  extends JpaRepository<DifficultyDescription, Long> {

    public DifficultyDescription findByDescription(String description);

}
