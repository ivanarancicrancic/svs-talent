package springwebapp.converters;

import lombok.Synchronized;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import springwebapp.commands.CategoryCommand;
import springwebapp.commands.DifficultyCommand;
import springwebapp.model.Category;
import springwebapp.model.DifficultyDescription;

@Component
public class DifficultydDscriptionToCommand implements Converter<DifficultyDescription, DifficultyCommand> {
    @Synchronized
    @Override
    public DifficultyCommand convert(DifficultyDescription source){

        if(source == null){
            return null;
        }

        final DifficultyCommand difficultyCommand = new DifficultyCommand();
        difficultyCommand.setId(source.getId());
        difficultyCommand.setDescription(source.getDescription());
        difficultyCommand.setBooks(source.getBooks());
        return difficultyCommand;
    }

}
