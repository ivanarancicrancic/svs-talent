export const EDIT_CAMPAIGN = 'EDIT_CAMPAIGN';
export type EDIT_CAMPAIGN = typeof EDIT_CAMPAIGN;

export const DELETE_CAMPAIGN = 'DELETE_CAMPAIGN';
export type DELETE_CAMPAIGN = typeof DELETE_CAMPAIGN;

export const BUY_CAMPAIGN = 'BUY_CAMPAIGN';
export type BUY_CAMPAIGN = typeof BUY_CAMPAIGN;