import * as React from 'react';
import { Translate } from 'react-redux-i18n';
import { IRootState } from '../../redux';
import { connect } from 'react-redux';
import ReactS3Uploader from 'react-s3-uploader'



interface Campaign {
    id: number,
    numberOfCampaigns: number;
}
  interface CampaignsProps {
  }
  
  interface CampaignsState {
    campaigns: Campaign[],
    isLoading: boolean;
    token: string;
  }
  

 class DashboardContainer extends React.Component<CampaignsProps, CampaignsState> {

    constructor(props: any) {
        super(props);

        this.state = {
            token: "",
            campaigns: [],
            isLoading: false
        }
    }

    public componentDidMount() {
        this.setState({isLoading: true});
        
         fetch('http://localhost:8080/api/testCampaigns')
                .then(response => response.json())
                .then(data =>
                {
                  this.setState({campaigns: data, isLoading: false});
          // console.log("CALLED JAVA API with data: " + data);
          }
                    );
      }

    public render() {
        const {campaigns, isLoading} = this.state;
  
        if (isLoading) {
          return <p>Loading...</p>;
        }
        return (
            <div>
            <Translate value="test" /><br />
            Token: <input type="text" value={this.state.token} onChange={ (e) => this.setState({token: e.target.value}) } />
            <ReactS3Uploader
                signingUrl="/s3/sign/"
                signingUrlMethod="POST"
                accept="image/*"
                s3path="/"
                // preprocess={ () => {console.log("preprocess")} }
                // onSignedUrl={ () => {console.log("onSignedUrl")} }
                // onProgress={ () => {console.log("onProgress")} }
                // onError={ () => {console.log("onError")} }
                // onFinish={ () => {console.log("onFinish")} }
                signingUrlHeaders={{ 'Authorization': 'Bearer ' + this.state.token }}
                // signingUrlQueryParams={{ additional: query-params }}
                signingUrlWithCredentials={false}      // in case when need to pass authentication credentials via CORS
                uploadRequestHeaders={{}}  // this is the default
                // contentDisposition="auto"
                // scrubFilename={(filename: string) => filename.replace(/[^\w\d_\-.]+/ig, '')}
                server="http://127.0.0.1:8080"
                // inputRef={cmp => this.uploadInput = cmp}
                autoUpload={true}
                />

                 <div>
          <h2>Campaign List</h2>
          {campaigns.map((campaign: Campaign) =>
            <div key={campaign.id}>
              {campaign.id}<br/>
            </div>
          )}
        </div>
             
            </div>
        )
    }

}

const mapStateToProps = (state: IRootState) => ({
    i18n: state.i18n,
});

export default connect(mapStateToProps, {})(DashboardContainer)