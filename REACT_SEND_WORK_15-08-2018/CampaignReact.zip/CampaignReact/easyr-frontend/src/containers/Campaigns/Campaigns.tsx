import * as React from 'react';

interface Campaign {
    id: number,
    numberOfCampaigns: number;
}
  interface CampaignsProps {
  }
  
  interface CampaignsState {
    campaigns: Campaign[],
    isLoading: boolean;
  }
  
  class Campaigns extends React.Component<CampaignsProps, CampaignsState> {
    constructor(props: CampaignsProps) {
      super(props);
  
      this.state = {
        campaigns: [],
        isLoading: false
      };
    }
  
   public componentDidMount() {
      this.setState({isLoading: true});
      
       fetch('http://localhost:8080/api/testCampaigns')
              .then(response => response.json())
              .then(data =>
              {
                this.setState({campaigns: data, isLoading: false});
        // console.log("CALLED JAVA API with data: " + data);
        }
                  );
    }
  
    // mapStateToProps({ numberOfCampaigns, id }: StoreState) {
    //     return {
    //       numberOfCampaigns,
    //       id: id,
    //     };
    //   }
      

    // mapDispatchToProps(dispatch: Dispatch<actions.CampaignAction>) {
    //     return {
    //     onEdit: () => dispatch(actions.editCampaign()),
    //     onDelete: () => dispatch(actions.deleteCampaign()),
    //     onBuy: () => dispatch(actions.buyCampaign()) 
    //     };
    //     }
        
   public render() {
      const {campaigns, isLoading} = this.state;
  
      if (isLoading) {
        return <p>Loading...</p>;
      }
  
      return (
        <div>
          <h2>Campaign List</h2>
          {campaigns.map((campaign: Campaign) =>
            <div key={campaign.id}>
              {campaign.id}<br/>
            </div>
          )}
        </div>
      );
    }
  }
  
  export default Campaigns;
  