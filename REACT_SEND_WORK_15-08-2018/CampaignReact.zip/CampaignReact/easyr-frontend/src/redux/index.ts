import { combineReducers } from 'redux';
import { LocationChangeAction, RouterAction, routerReducer, RouterState, } from 'react-router-redux';
import { i18nReducer, I18nState } from 'react-redux-i18n';
import { IAuthState, AuthActions, authReducer } from './auth/reducer';

import { formsReducer } from './forms';

export interface IRootState {
    router: RouterState;
    i18n: I18nState;
    auth: IAuthState;
    forms: any;
}

export type RootAction = RouterAction
    | LocationChangeAction
    | AuthActions;

export const reducers = combineReducers<IRootState>({
    i18n: i18nReducer,
    router: routerReducer,
    auth: authReducer,
    forms: formsReducer,
});