import { ActionType, getType } from 'typesafe-actions';
import * as actions from './actions';

export type AuthActions = ActionType<typeof actions>;

export interface IAuthState {
    readonly token: string | null;
    readonly loggingIn: boolean;
    readonly error: string | null;
};
  
const INITIAL_STATE: IAuthState = {
    error: null,
    loggingIn: false,
    token: null,
};
  
export function authReducer(state: IAuthState = INITIAL_STATE, action: AuthActions): IAuthState  {
    switch (action.type) {
        case getType(actions.loginUserFetch):
            return state;
        case getType(actions.loginUserSuccess):
            return {...state, token: "123faketoken"};
        case getType(actions.loginUserFail):
            return state;
        case getType(actions.loginLogout):
            return {...state, token: null}
        default:
            return state;
    }
}