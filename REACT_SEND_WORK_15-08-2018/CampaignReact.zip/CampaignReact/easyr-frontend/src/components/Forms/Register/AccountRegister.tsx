import * as React from 'react';
import {Control, Form} from 'react-redux-form';
import {ILoginFormData} from '../../../redux/forms';
import './Register.css';

interface IProps {
    onSubmit: (values: ILoginFormData) => void;
}

export default class AccountRegister extends React.Component<IProps> {

    // private formDispatch: any;

    public render() {
        return (
            <div className="container">
                <Form
                    model="forms.login"
                    onSubmit={this.props.onSubmit}
                    getDispatch={this.attachDispatch}
                >
                    <div>
                        <div className="bottomSeparator">
                            <p>Account Credentials</p>
                        </div>
                        <div className="container bp3-input-group">
                            <Control
                                model=".firstName"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                validateOn="blur"
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "First Name",
                                }}
                            />
                            <Control
                                model=".lastName"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton grid50",
                                    placeholder: "Last Name",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".email"
                                type="email"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Email",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".password"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Password",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                type="password"
                                model=".confirmPassword"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Confirm Password",
                                }}
                            />
                        </div>
                        <div className="bp3-input-group">
                            <Control
                                model=".phoneNumber"
                                validators={{
                                    required: (val) => val && val.length,
                                }}
                                component={"input"}
                                controlProps={{
                                    className: "bp3-input inputButton",
                                    placeholder: "Phone Number",
                                }}
                            />
                        </div>
                    </div>
                </Form>
            </div>
        )
    }

    private attachDispatch = (dispatch: any) => {
        // this.formDispatch = dispatch;
    };



    /*
    private changeFooToBar = () => {
        this.formDispatch(actions.change('user.foo', 'bar'));
    }
    */
}