import * as React from 'react';

export default class PostAuthFooter extends React.Component {

    public render() {
        return (
            <div className="footer">
                Post-auth Footer
            </div>
        )
    }

}