import * as React from 'react';
import './Campaign.css';

export interface Props {
  id: number;
  numberOfCampaigns?: number;
  onEdit?: () => void;
  onDelete?: () => void;
  onBuy?: () => void;
}

function Campaign({ id, numberOfCampaigns = 0, onEdit, onDelete, onBuy }: Props) {
  if (numberOfCampaigns <= 0) {
    throw new Error('Please add some new campaign. :D');
  }

  return (
    <div>
      <div className="campaign">
        Hello {id + getExclamationMarks(numberOfCampaigns)}
      </div>
      <div>
        <button onClick={onEdit}>Edit</button>
        <button onClick={onDelete}>Delete</button>
        <button onClick={onBuy}>Buy</button>
      </div>
    </div>
  );
}

export default Campaign;

// helpers
function getExclamationMarks(numChars: number) {
  return Array(numChars + 1).join('!');
}